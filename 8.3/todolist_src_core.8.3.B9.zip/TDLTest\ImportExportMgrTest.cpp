// ImportExportMgrTest.cpp: implementation of the CImportExportMgrTest class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TDLTest.h"
#include "ImportExportMgrTest.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CImportExportMgrTest::CImportExportMgrTest(const CTestUtils& utils) : CTDLTestBase(utils)
{

}

CImportExportMgrTest::~CImportExportMgrTest()
{

}

TESTRESULT CImportExportMgrTest::Run()
{
	return TESTRESULT();
}
