// TDLQuickFindComboBox.cpp : implementation file
//

#include "stdafx.h"
#include "TDLQuickFindComboBox.h"


// CTDLQuickFindComboBox

IMPLEMENT_DYNAMIC(CTDLQuickFindComboBox, CAutoComboBox)

CTDLQuickFindComboBox::CTDLQuickFindComboBox(DWORD dwFlags) : CAutoComboBox(dwFlags)
{
}

CTDLQuickFindComboBox::~CTDLQuickFindComboBox()
{
}


BEGIN_MESSAGE_MAP(CTDLQuickFindComboBox, CAutoComboBox)
END_MESSAGE_MAP()



// CTDLQuickFindComboBox message handlers


