

using System;
using System.Collections.Generic;
using System.Text;

namespace Calendar
{
    public enum SelectionType
    {
        DateRange,
        Appointment,
        None
    }
}
