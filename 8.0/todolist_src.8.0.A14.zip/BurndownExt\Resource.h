//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BurndownExt.rc
//
#define IDR_BURNDOWN                    1000
#define IDR_STATISTICS                  1000
#define IDC_DISPLAY                     1015
#define IDC_OPTIONS                     1016
#define IDS_BURNDOWN_TITLE              6001
#define IDS_TIME_AXIS                   6002
#define IDS_TASK_AXIS                   6003
#define IDS_DISPLAY_BURNDOWN_YAXIS      6003
#define IDS_DISPLAY_INCOMPLETE          6003
#define IDS_DISPLAY_BURNDOWN            6004
#define IDS_DISPLAY_SPRINT              6005
#define IDS_DISPLAY_SPRINT_YAXIS        6006
#define IDS_DISPLAY_REMAINING           6006
#define IDS_DISPLAY_BURNDOWN2           6007
#define IDS_TOOLTIP_INCOMPLETE          6007
#define IDS_TOOLTIP_REMAINING           6008
#define IDS_TOOLTIP_ESTIMATEDSPENT      6009
#define IDS_TOOLTIP_ATTRIBFREQUENCY     6010
#define IDD_PREFERENCES_DIALOG          16002
#define IDD_PREFERENCES_PAGE            16003
#define IDR_TOOLBAR                     16006
#define IDC_PPHOST                      16019
#define IDC_TB_PLACEHOLDER              16024
#define IDC_ACTIVEDATERANGE_LABEL       16028
#define IDC_ACTIVEDATERANGE             16034
#define IDD_BURNDOWN_DLG                17000
#define IDD_STATISTICS_DLG              17000
#define IDC_GRAPH                       17002
#define IDB_TOOLBAR_STD                 17002
#define IDC_FRAME                       17003
#define IDI_ICON1                       17003
#define IDI_HELP_BUTTON                 17003
#define IDC_DIVIDER                     17004
#define IDC_GRAPHCOLORS                 17007
#define ID_BURNDOWN_PREF                32771
#define IDS_ACTIVEDATERANGE             57688
#define IDS_TOOLTIP_STARTEDCOMPLETED    57689
#define IDS_TOOLTIP_STARTEDENDED        57689
#define IDS_DISPLAY_STARTEDCOMPLETED    57690
#define IDS_DISPLAY_STARTEDENDED        57690
#define IDS_DISPLAY_ESTIMATEDSPENTDAYS  57691
#define IDS_DISPLAY_ESTIMATEDSPENTCOST  57692
#define IDS_TREND_BESTFIT               57693
#define IDS_TREND_7DAYAVERAGE           57694
#define IDS_TREND_30DAYAVERAGE          57695
#define IDS_TREND_NONE                  57696
#define IDS_NONE                        57696
#define IDS_FREQUENCYDIST               57697
#define IDS_TIMESERIES                  57698
#define IDS_FREQUENCY_CATEGORY          57699
#define IDS_FREQUENCY_STATUS            57700
#define IDS_FREQUENCY_ALLOCBY           57701
#define IDS_FREQUENCY_ALLOCTO           57702
#define IDS_FREQUENCY_VERSION           57703
#define IDS_FREQUENCY_TAGS              57704
#define IDS_FREQUENCY_PRIORITY          57705
#define IDS_FREQUENCY_RISK              57706
#define IDS_TREND_90DAYAVERAGE          57707

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        17004
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         17008
#define _APS_NEXT_SYMED_VALUE           17000
#endif
#endif
