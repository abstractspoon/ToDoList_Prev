﻿namespace Gma.CodeCloud.Controls.TextAnalyses.Stemmers
{
    public interface IWordStemmer
    {
        string GetStem(string word);
    }
}
