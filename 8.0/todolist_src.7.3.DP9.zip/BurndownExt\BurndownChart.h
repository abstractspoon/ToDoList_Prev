#pragma once

#include "BurndownStruct.h"

#include "..\Shared\HMXChartEx.h"

/////////////////////////////////////////////////////////////////////////////

class CGraphBase;

/////////////////////////////////////////////////////////////////////////////
// CBurndownChart

class CBurndownChart : public CHMXChartEx
{
public:
	CBurndownChart(const CStatsItemArray& data);
	virtual ~CBurndownChart();

	CString GetGraphTitle(BURNDOWN_CHARTTYPE nType) const;
	BOOL SetActiveGraph(BURNDOWN_CHARTTYPE nType);
	void SetTodayColour(COLORREF color);
	BOOL SaveToImage(CBitmap& bmImage);

	void RebuildGraph(const COleDateTimeRange& dtExtents);

protected:
	const CStatsItemArray& m_data;
	CArray<CGraphBase*, CGraphBase*> m_graphs;

	COleDateTimeRange m_dtExtents;
	CStatsItemCalculator m_calculator;
	COLORREF m_crToday;

	BURNDOWN_CHARTTYPE m_nChartType;
	BURNDOWN_CHARTSCALE m_nScale;

protected:
	void OnSize(UINT nType, int cx, int cy);
	void PreSubclassWindow();

	DECLARE_MESSAGE_MAP()

protected:
	void RebuildXScale();
	BURNDOWN_CHARTSCALE CalculateRequiredXScale() const;
	BOOL IsValidType(BURNDOWN_CHARTTYPE nType) const;

	// virtual overrides
	CString GetTooltip(int nHit) const;
	int HitTest(const CPoint& ptClient) const;
	void DoPaint(CDC& dc, BOOL bPaintBkgnd);

};

