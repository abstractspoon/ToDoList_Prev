TR szLookFor, CStringArray& aWords)
{
	aWords.RemoveAll();
	
	// parse on spaces unless enclosed in double-quotes
	int nLen = lstrlen(szLookFor);
	BOOL bInQuotes = FALSE, bAddWord = FALSE;
	CString sWord;
	
	for (int nPos = 0; nPos < nLen; nPos++)
	{
		switch (szLookFor[nPos])
		{
		case ' ': // word break
			if (bInQuotes)
				sWord += szLookFor[nPos];
			else
				bAddWord = TRUE;
			break;
			
		case '\"':
			// whether its the start or end we add the current word
			// and flip bInQuotes
			bInQuotes = !bInQuotes;
			bAddWord = TRUE;
			break;
			
		default: // everything else
			sWord += szLookFor[nPos];
			
			// also if its the last char then add it
			bAddWord = (nPos == nLen - 1);
			break;
		}
		
		if (bAddWord)
		{
			sWord.TrimLeft();
			sWord.TrimRight();
			
			if (!sWord.IsEmpty())
				aWords.Add(sWord);
			
			sWord.Empty(); // next word
		}
	}
	
	return aWords.GetSize();
}

CString Misc::Format(double dVal, int nDecPlaces)
{
	char* szLocale = _strdup(setlocale(LC_NUMERIC, NULL)); // current locale
	setlocale(LC_NUMERIC, ""); // local default

	CString sValue;
	sValue.Format("%.*f", nDecPlaces, dVal);
				
	// restore locale
	setlocale(LC_NUMERIC, szLocale);
	free(szLocale);

	return sValue;
}

CString Misc::Format(int nVal)
{
	CString sValue;
	sValue.Format("%ld", nVal);

	return sValue;
}

CString Misc::FormatCost(double dCost)
{
	CString sValue;
	sValue.Format("%.6f", dCost);

	char* szLocale = _strdup(setlocale(LC_NUMERIC, NULL)); // current locale
	setlocale(LC_NUMERIC, ""); // local default

	const UINT BUFSIZE = 100;
	char szCost[BUFSIZE + 1];

	GetCurrencyFormat(NULL, 0, sValue, NULL, szCost, BUFSIZE);
	sValue = szCost;
				
	// restore locale
	setlocale(LC_NUMERIC, szLocale);
	free(szLocale);

	return sValue;
}

BOOL Misc::KeyIsPressed(DWORD dwVirtKey) 
{ 
	return (GetKeyState(dwVirtKey) & 0x8000); 
}

BOOL Misc::IsCursorKeyPressed(DWORD dwKeys)
{
	if (dwKeys & MKC_LEFTRIGHT)
	{
		if (KeyIsPressed(VK_RIGHT) || KeyIsPressed(VK_LEFT) ||
			KeyIsPressed(VK_HOME) || KeyIsPressed(VK_END))
			return TRUE;
	}
	
	if (dwKeys & MKC_UPDOWN)
	{
		if (KeyIsPressed(VK_NEXT) || KeyIsPressed(VK_DOWN) ||
			KeyIsPressed(VK_UP) || KeyIsPressed(VK_PRIOR))
			return TRUE;
	}
	
	// else 
	return FALSE;
}

BOOL Misc::IsCursorKey(DWORD dwVirtKey, DWORD dwKeys)
{
	if (dwKeys & MKC_LEFTRIGHT)
	{
		switch (dwVirtKey)
		{
		case VK_RIGHT:
		case VK_LEFT:
		case VK_HOME:
		case VK_END:
			return TRUE;
		}
	}
	
	if (dwKeys & MKC_UPDOWN)
	{
		switch (dwVirtKey)
		{
		case VK_NEXT:  
		case VK_DOWN:
		case VK_UP:
		case VK_PRIOR: 
			return TRUE;
		}
	}
	
	// else 
	return FALSE;
}

BOOL Misc::ModKeysArePressed(DWORD dwKeys) 
{
	// test for failure
	if (dwKeys & MKS_CTRL)
	{
		if (!KeyIsPressed(VK_CONTROL))
			return FALSE;
	}
	else if (KeyIsPressed(VK_CONTROL))
			return FALSE;

	if (dwKeys & MKS_SHIFT)
	{
		if (!KeyIsPressed(VK_SHIFT))
			return FALSE;
	}
	else if (KeyIsPressed(VK_SHIFT))
			return FALSE;

	if (dwKeys & MKS_ALT)
	{
		if (!KeyIsPressed(VK_MENU))
			return FALSE;
	}
	else if (KeyIsPressed(VK_MENU))
			return FALSE;

	return TRUE;
}

BOOL Misc::HasFlag(DWORD dwFlags, DWORD dwFlag) 
{ 
	if ((dwFlags & dwFlag) == dwFlag)
		return TRUE;
	else
		return FALSE; 
}

// private method for implementing the bubblesort
BOOL CompareAndSwap(CStringArray& array, int pos, BOOL bAscending)
{
   CString temp;
   int posFirst = pos;
   int posNext = pos + 1;

   CString sFirst = array.GetAt(posFirst);
   CString sNext = array.GetAt(posNext);

   int nCompare = sFirst.CompareNoCase(sNext);

   if ((bAscending && nCompare > 0) || (!bAscending && nCompare < 0))
   {
      array.SetAt(posFirst, sNext);
      array.SetAt(posNext, sFirst);

      return TRUE;

   }
   return FALSE;
}

void Misc::SortArray(CStringArray& array, BOOL bAscending)
{
	BOOL bNotDone = TRUE;
	
	while