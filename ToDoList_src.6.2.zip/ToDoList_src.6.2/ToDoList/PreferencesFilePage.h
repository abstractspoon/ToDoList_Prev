        <p>filename 2: <xsl:value-of select="$filename"/></p>
        -->
        
        <table 
            class="finished"
            cellspacing="0"
            cellpadding="5">
        
        <xsl:call-template name="get_Header"/>
        
        <xsl:choose>
            <xsl:when test="$sortby='prio'">
                <!-- first take all tasks with a due date -->
                <xsl:for-each select="//TASK[($dueuntil = 0 or @DUEDATE &lt; $dueuntil) and ($showflagged != 'only' or @FLAG) and (@CALCTIMESPENT)]">
                    <xsl:sort 
                        select="@PRIORITY" 
                        data-type="number"
                        order="descending"
                        />
                    <xsl:sort 
                        select="@STARTDATE" 
                        data-type="number"
                        />
                    <xsl:sort 
                        select="@DUEDATE" 
                        data-type="number"
                        />
                    <xsl:sort 
                        select="@ID" 
                        data-type="number"
                        />
                    
                    <!--<xsl:if test="not(@DONEDATESTRING)"> -->
                        <xsl:call-template name="get_Task"/>
                    <!--</xsl:if> -->
                </xsl:for-each>
            </xsl:when>
            <xsl:otherwise>
                <!-- sort first by due date then by prio -->
                <xsl:for-each select="//TASK[@DUEDATE and ($dueuntil = 0 or @DUEDATE &lt; $dueuntil) and ($showflagged != 'only' or @FLAG) and (@CALCTIMESPENT)]">
                    <xsl:sort 
                        select="@CALCTIMESPENT" 
                        data-type="number"
                        />
                    <xsl:sort 
                        select="@STARTDATE" 
                        data-type="number"
                        />
                    <xsl:sort 
                        select="@DUEDATE" 
                        data-type="number"
                        />
                    <xsl:sort 
                        select="@PRIORITY" 
                        data-type="number"
                        order="descending"
                        />
                    <xsl:sort 
                        select="@ID" 
                        data-type="number"
                        />
                    
                    <!--<xsl:if test="not(@DONEDATESTRING)"> -->
                        <xsl:call-template name="get_Task"/>
                    <!--</xsl:if> -->
                </xsl:for-each>
                
                <!-- then take all tasks without a due date -->
                <xsl:if test="$dueuntil = 0">
                <xsl:for-each select="//TASK[not(@DUEDATE) and ($showflagged != 'only' or @FLAG) and (@CALCTIMESPENT)]">
                    <xsl:sort 
                        select="@PRIORITY" 
                        data-type="number"
                        order="descending"
                        />
                    <xsl:sort 
                        select="@ID" 
                        data-type="number"
                        />
                    
                    <xsl:if test="not(@DONEDATESTRING)">
                        <xsl:call-template name="get_Task"/>
                    </xsl:if>
                </xsl:for-each>
                </xsl:if>
            </xsl:otherwise>
        </xsl:choose>
        </table>
        </body>
        </html>
    </xsl:template>


    <!-- 20 - header of table - titles of c