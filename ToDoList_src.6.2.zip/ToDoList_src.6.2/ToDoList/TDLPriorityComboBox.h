#if !defined(AFX_SPELLCHECKDLG_H__796FCD48_463A_4291_9261_69EA5122ABA0__INCLUDED_)
#define AFX_SPELLCHECKDLG_H__796FCD48_463A_4291_9261_69EA5122ABA0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SpellCheckDlg.h : header file
//

#include "runtimedlg.h"
#include "richeditncborder.h"
#include "richeditspellcheck.h"
#include "RichEditBaseCtrl.h"

#include "..\3rdparty\statlink.h"

/////////////////////////////////////////////////////////////////////////////
// CSpellCheckDlg dialog

const int IDNOERRORS = 20; // can be returned from DoModal

class ISpellChecker;
class ISpellCheck;

enum // control IDs
{
	SCD_TITLE = 0,
	// don't put anything here else it will clash with IDOK, etc

	IDC_SCD_DICTIONARIES = 1001,
	IDC_SCD_DICTLABEL,
	IDC_SCD_BROWSE,
	IDC_SCD_DOWNLOADLABEL,
	IDC_SCD_CHECKINGLABEL,
	IDC_SCD_SUGGESTIONS,
	IDC_SCD_TEXT,
	IDC_SCD_MISSPELTWORD,
	IDC_SCD_REPLACELABEL,
	IDC_SCD_WITHLABEL,
	IDC_SCD_REPLACE,
	IDC_SCD_NEXT,
	IDC_SCD_RESTART,
	IDC_SCD_URL,

	DLG_SCD_BROWSETITLE = 10001,
	DLG_SCD_SETUPMSG,
	DLG_SCD_DICTFILTER,
	DLG_SCD_ENGINEFILTER,
	DLG_SCD_ENGINETITLE,
};

class CSpellCheckDlg : public CRuntimeDlg
{
// Construction
public:
	CSpellCheckDlg(LPCTSTR szDictionaryPath = NULL, ISpellCheck* pSpellCheck = NULL, LPCTSTR szText = NULL, CWnd* pParent = NULL);   // standard constructor
	virtual ~CSpellCheckDlg();

	BOOL IsInitialized() { return ((m_pSpellCheck || !m_sText.IsEmpty()) && m_pSpellChecker); }
	int DoModal(BOOL bEndOnNoErrors = FALSE);

	void SetSpellCheck(ISpellCheck* pSpellCheck);
	void SetDictionaryDownloadUrl(LPCTSTR szUrl);

	void SetText(LPCTSTR szText);
	CString GetCorrectedText() { return m_sText; 