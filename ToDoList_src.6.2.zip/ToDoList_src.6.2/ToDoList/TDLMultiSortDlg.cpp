// MenuIconMgr.h: interface for the CMenuIconMgr class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MENUICONMGR_H__0FF0228C_515C_4E93_A957_1952AFD0F3A1__INCLUDED_)
#define AFX_MENUICONMGR_H__0FF0228C_515C_4E93_A957_1952AFD0F3A1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\shared\Subclass.h"
#include <afxtempl.h>

class CMenuIconMgr : public CSubclassWnd  
{
public:
	CMenuIconMgr();
	virtual ~CMenuIconMgr();
	
	BOOL Initialize(CWnd* pWnd);

	BOOL AddImage(UINT nCmdID, HICON hIcon); // hIcon will be copied
	BOOL SetImage(UINT nCmdID, HICON hIcon); // hIcon will be cleaned up

	BOOL AddImage(UINT nCmdID, const CImageList& il, int nImage);
	int AddImages(const CToolBar& toolbar);
	int AddImages(const CUIntArray& aCmdIDs, const CImageList& il);
	int AddImages(const CUIntArray& aCmdIDs, UINT nIDBitmap, int nCx, COLORREF crMask);
	
	BOOL ChangeImageID(UINT nCmdID, UINT nNewCmdID);
	void DeleteImage(UINT nCmdID);
	
	void ClearImages();
	
protected:
	CMap<UINT, UINT, HICON, HICON> m_mapID2Icon;
	
	virtual LRESULT WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp);
	
	BOOL OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpdis);
	void OnInitMenuPopup(CMenu* pMenu);
	BOOL OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpmis);
	
	HICON LoadItemImage(UINT nCmdID);
};

#endif // !defined(AFX_MENUICONMGR_H__0FF0228C_515C_4E93_A957_1952AFD0F3A1__INCLUDED_)
                                        	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTDLMultiSortDlg message handlers

BOOL CTDLMultiSortDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	BuildCombos();

	// disable 3rd combo if 2nd combo not set
	m_cbSortBy3.EnableWindow(m_nSortBy2 != TDC_UNSORTED);
	
	GetDlgItem(IDC_ASCENDING3)->EnableWindow(m_nSortBy2 != TDC_UNSORTED && m_nSortBy3 != TDC_UNSORTED);
	GetDlgItem(IDC_ASCENDING2)->EnableWindow(m_nSortBy2 != TDC_UNSORTED);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTDLMultiSortDlg::BuildCombos()
{
	for (int nCol = 0; nCol < NUM_COLUMNS; nCol++)
	{
		TDCCOLUMN& col = COLUMNS[nCol];

		if (col.nSortBy != TDC_UNSORTED)
		{
			// is this column visible
			if (IsColumnVisible(col.nColID))
			{
				int nIndex = m_cbSortBy1.AddString(CEnString(col.nIDLongName));
				m_cbSortBy1.SetItemData(nIndex, col.nSortBy);

				if (m_nSortBy1 == col.nSortBy)
					m_cbSortBy1.SetCurSel(nIndex);

				nIndex = m_cbSortBy2.AddString(CEnString(col.nIDLongName));
				m_cbSortBy2.SetItemData(nIndex, col.nSortBy);

				if (m_nSortBy2 == col.nSortBy)
					m_cbSortBy2.SetCurSel(nIndex);

				nIndex = m_cbSortBy3.AddString(CEnString(col.nIDLongName));
				m_cbSortBy3.SetItemData(nIndex, col.nSortBy);

				if (m_nSortBy3 == col.nSortBy)
					m_cbSortBy3.SetCurSel(nIndex);
			}
		}
	}

	// add blank item at top of 2nd and 3rd combo
	int nIndex = m_cbSortBy2.InsertString(0, "");
	m_cbSortBy2.SetItemData(nIndex, TDC_UNSORTED);
	
	if (m_nSortBy2 == TDC_UNSORTED)
		m_cbSortBy2.SetCurSel(nIndex);
	
	nIndex = m_cbSortBy3.InsertString(0, "");
	m_cbSortBy3.SetItemData(nIndex, TDC_UNSORTED);
	
	if (m_nSortBy3 == TDC_UNSORTED)
		m_cbSortBy3.SetCurSel(nIndex);

	// set selection to first item if first combo selection is not set
	if (m_cbSortBy1.GetCurSel() == -1)
	{
		m_cbSortBy1.SetCurSel(0);
		m_nSortBy1 = (TDC_SORTBY)m_cbSortBy1.GetItemData(0);
	}
}

BOOL CTDLMultiSortDlg::IsColumnVisible(TDC_COLUMN col) const
{
	// special case:
	if (col == TDCC_CLIENT)
		return TRUE;

	int nCol = m_aVisibleColumns.GetSize();

	while (nCol--)
	{
		if (col == m_aVisibleColumns[nCol])
			return TRUE;
	}

	// not found
	return FALSE;
}

void CTDLMultiSortDlg::OnSelchangeSortby1() 
{
	UpdateData();
	
	int nSel = m_cbSortBy1.GetCurSel();
	m_nSortBy1 = (TDC_SORTBY)m_cbSortBy1.GetItemData(nSel);
}// Misc.cpp: implementation of the CMisc class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Misc.h"

#include <Lmcons.h>
#include <math.h>
#include <locale.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////

void Misc::CopyTexttoClipboard(const CString& sText, HWND hwnd) 
{
	if (!::OpenClipboard(hwnd)) 
		return; 
	
    ::EmptyClipboard(); 
	
    // Allocate a global memory object for the text. 
	HGLOBAL hglbCopy = GlobalAlloc(GMEM_MOVEABLE, (sText.GetLength() + 1) * sizeof(TCHAR)); 
	
	if (!hglbCopy) 
	{ 
		CloseClipboard(); 
		return; 
	} 
	
	// Lock the handle and copy the text to the buffer. 
	LPTSTR lptstrCopy = (LPTSTR)GlobalLock(hglbCopy); 
	
	memcpy(lptstrCopy, (LPVOID)(LPCTSTR)sText, sText.GetLength() * sizeof(TCHAR)); 
	
	lptstrCopy[sText.GetLength()] = (TCHAR) 0;    // null character 
	GlobalUnlock(hglbCopy); 
	
	// Place the handle on the clipboard. 
	::SetClipboardData(