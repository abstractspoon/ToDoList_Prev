(BUFLEN), BUFLEN - 1);
		sSep.ReleaseBuffer();
		
		// Trim extra spaces
		sSep.TrimLeft();
		sSep.TrimRight();
		
		// If none found, use a comma
		if (!sSep.GetLength())
			sSep = ',';
	}

	return sSep;
}

CString Misc::FormatArray(const CStringArray& array, LPCTSTR szSep)
{
	int nCount = array.GetSize();

	if (nCount == 0)
		return "";

	CString sSep(szSep);

	if (!szSep)
		sSep = GetListSeparator() + ' ';

	CString sText;

	for (int nItem = 0; nItem < nCount; nItem++)
	{
		if (nItem > 0 && array[nItem].GetLength())
			sText += sSep;

		sText += array[nItem];
	}

	return sText;
}

CString Misc::FormatArray(const CDWordArray& array, LPCTSTR szSep)
{
	int nCount = array.GetSize();

	if (nCount == 0)
		return "";

	CString sSep(szSep);

	if (!szSep)
		sSep = GetListSeparator() + ' ';

	CString sText;

	for (int nItem = 0; nItem < nCount; nItem++)
	{
		CString sItem;
		sItem.Format("%ld", array[nItem]);

		if (nItem > 0)
			sText += sSep;

		sText += sItem;
	}

	return sText;
}

void Misc::Trace(const CStringArray& array)
{
	int nCount = array.GetSize();

	for (int nItem = 0; nItem < nCount; nItem++)
		TRACE("%s, ", array[nItem]);

	TRACE("\n");
}

int Misc::ParseIntoArray(const CString& sText, CStringArray& array, BOOL bAllowEmpty, CString sSep)
{
	array.RemoveAll();

	if (sSep.IsEmpty())
		sSep = GetListSeparator();

	int nSepPrev = -1;
	int nSep = sText.Find(sSep);
	
	while (nSep != -1)
	{
		CString sItem = sText.Mid(nSepPrev + 1, nSep - (nSepPrev + 1));
		sItem.TrimLeft();
		sItem.TrimRight();
		
		if (bAllowEmpty || !sItem.IsEmpty())
			array.Add(sItem);
		
		nSepPrev = nSep;
		nSep = sText.Find(sSep, nSepPrev + 1);
	}
	
	// handle whatever's left so long as a separator was found
	// or th