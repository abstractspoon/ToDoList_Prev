
	if (m_pNext)
	{
		if (m_pNext->m_pSubclasser)
			return m_pNext->m_pSubclasser->ScWindowProc(m_hWndHooked, msg, wp, lp);
		else
			return m_pNext->WindowProc(m_hWndHooked, msg, wp, lp);
	}
	else	
		return ::CallWindowProc(m_pOldWndProc, m_hWndHooked, msg, wp, lp);
}

//////////////////
// Like calling base class WindowProc, but with no args, so individual
// message handlers can do the default thing. Like CWnd::Default
//
LRESULT CSubclassWnd::Default()
{
	ASSERT (::IsWindow(m_hWndHooked));

	if (!::IsWindow(m_hWndHooked))
		return 0;

	// MFC stores current MSG in thread state
	MSG& curMsg = AfxGetThreadState()->m_lastSentMsg;

	// Note: must explicitly call CSubclassWnd::WindowProc to avoid infinite
	// recursion on virtual function
	return CSubclassWnd::WindowProc(m_hWndHooked, curMsg.message, curMsg.wParam, curMsg.lParam);
}

const MSG* CSubclassWnd::GetCurrentMessage()
{
	static MSG curMsg;
	
	curMsg = AfxGetThreadState()->m_lastSentMsg;
	return &curMsg;
}

//////////////////
// Subclassed window proc for message hooks. Replaces AfxWndProc (or whatever
// else was there before.)
//
LRESULT CALLBACK CSubclassWnd::HookWndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
	// If this is a non-extension DLL, dynamically linked to MFC
	// then we need to set up MFC state
#if defined(_WINDLL) && defined(_AFXDLL) && !defined(_AFXEXT)
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
#endif

	// Set up MFC message state just in case anyone wants it
	// This is just like AfxCallWindowProc, but we can't use that because
	// a CSubclassWnd is not a CWnd.
	//
	MSG& curMsg = AfxGetThreadState()->m_lastSentMsg;
	MSG  oldMsg = curMsg;   // save for nesting
	curMsg.hwnd		= hwnd;
	curMsg.message = msg;
	curMsg.wParam  = wp;
	curMsg.lParam  = lp;

	// Get hook object for this window. Get from hook map
	CSubclassWnd* pSubclassWnd = theHookMap.Lookup(hwnd);

	if (!pSubclassWnd)
		return 0;

	// see if this is a re-entrant call
	BOOL bInHookWndProc = FALSE;

	VERIFY (theSafeMap.Lookup((void*)pSubclassWnd, (void*&)bInHookWndProc));
	ASSERT (!bInHookWndProc);

	LRESULT lr;

	if (msg == WM_NCDESTROY) 
	{
#ifdef _DEBUG
		char szClass[30];
		GetClassName(hwnd, szClass, 30);
//		TRACE ("CSubclassWnd::HookWndProc(%s, WM_NCDESTROY)\n", szClass);
#endif

		// Window is being destroyed: unhook all hooks (for this window)
		// and pass msg to orginal window proc
		WNDPROC wndproc = pSubclassWnd->m_pOldWndProc;
		theHookMap.RemoveAll(hwnd);

		lr = ::CallWindowProc(wndproc, hwnd, msg, wp, lp);

		if (s_pCallback)
			s_pCallback->PostNcDestroy(hwnd);
	} 
	else 
	{
		if (pSubclassWnd->m_pSubclasser)
		{
			// pass to msg hook
			lr = pSubclassWnd->m_pSubclasser->ScWindowProc(pSubclassWnd->GetHwnd(), msg, wp, lp);
		}
		else
		{
			if (msg == WM_DESTROY)
			{
				//CWnd* pWnd = CWnd::FromHandle(hwnd);
			}
			// pass to msg hook
			lr = pSubclassWnd->WindowProc(pSubclassWnd->GetHwnd(), msg, wp, lp);
		}
	}

	theSafeMap[(void*)pSubclassWnd] = NULL;

	curMsg = oldMsg;			// pop state
	return lr;
}

BOOL CSubclassWnd::PostMessage(UINT message, WPARAM wParam, LPARAM lParam) const
{
	if (IsValid())
		return ::PostMessage(m_hWndHooked, message, wParam, lParam);

	// else
	return FALSE;
}

BOOL CSubclassWnd::SendMessage(UINT message, WPARAM wParam, LPARAM lParam) const
{
	if (IsValid())
		return ::SendMessage(m_hWndHooked, message, wParam, lParam);

	// else
	return FALSE;
}

CMapPtrToPtr& CSubclassWnd::GetValidMap()
{
	// By creating theMap here, C++ doesn't instantiate it until/unless
	// it's ever used! This is a good trick to use in C++, to
	// instantiate/initialize a static object the first time it's used.
	//
	static CMapPtrToPtr theMap;
	return theMap;
}

BOOL CSubclassWnd::IsValid(const CSubclassWnd* pScWnd)
{
	void* pResult;

	return theSafeMap.Lookup((void*)pScWnd, pResult);
}

void CSubclassWnd::ClientToWindow(LPRECT pRect) const
{
	ClientToWindow((LPPOINT)pRect);
	ClientToWindow(((LPPOINT)pRect) + 1);
}

void CSubclassWnd::ScreenToClient(LPRECT pRect) const
{
	ScreenToClient((LPPOINT)pRect);
	ScreenToClient(((LPPOINT)pRect) + 1);
}

void CSubclassWnd::ClientToScreen(LPRECT pRect) const
{
	ClientToScreen((LPPOINT)pRect);
	ClientToScreen(((LPPOINT)pRect) + 1);
}

void CSubclassWnd::ScreenToWindow(LPRECT pRect) const
{
	CRect rWindow;
	GetWindowRect(rWindow);
	::OffsetRect(pRect, -rWindow.left, -rWindow.top);
}