ent name="br"/>
                <xsl:call-template name="fix-breaks">
                    <xsl:with-param name="text">
                        <xsl:value-of select="substring-after($text,'&#13;&#10;')" />
                    </xsl:with-param>
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$text" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    
    
    <!-- 70 - generate CSS styles -->
    <xsl:template name="style">
        <xsl:element name="style">
            <xsl:attribute name="type">text/css</xsl:attribute>
            <xsl:text>
table.finished{
    border-bottom: 1px solid Black;
    border-right: 1px solid Black;
    border-top: 2px solid Black;
    border-left: 2px solid Black;
    width: 100%;
    vertical-align: top;
}
tr.header{
    background-color: #33ccff;
    font-weight: bold;
}
tr.lead{
    font-weight: bold;
}
td.header{
    border-bottom: 2px solid Black;
    border-right: 1px solid Black;
    font-size: small;
    padding: 1px;
}
td.headerid{
    text-align:right;
}
td.headerprior{
    text-align:center;
}
td.headerprogress{
    text-align:center;
}
td.bbasic{
    border-bottom: 1px solid Black;
    border-right: 1px solid Black;
    font-size: small;
    padding-top: 1px;
    padding-bottom: 1px;
    padding-left: 2px;
    padding-right: 2px;
    vertical-align: top;
}
td.taskid{
    text-align:right;
}
td.due{
    text-align:right;
}
td.progress{
    text-align:center;
}
td.prior{
    text-align:center;
    color: white;
}
td.category{
    text-align:left;
}
td.status{
    text-align:left;
}
td.task{
    text-align:left;
}
td.to{
    text-align:left;
}
td.empty{
    color:black;
    text-align:center;
}
td.spent{
    color:green;
    text-align:right;
}

a.flagged{
    font-weight:bold;
}
a { color:black; }
a:link { text-decoration:none; }
a:visited { text-decoration:none; }
a:hover { text-decoration:underline; }
a:active { text-decoration:underline; }

span.tab{
    padding-left:20px;
    margin: 0 0 0 0;
}
.noborder{
    margin: 0 5 0 0;
}
div.commentbox{
    width: 95%;
    float: right;
    margin: 1 1 1 1;
    padding:2px;
    font-style: italic;
    font-size: x-small;
    display: block;
    border: 1px dotted Black;
}
body {
    font-family: Arial;
}</xsl:text>
        </xsl:element>
    </xsl:template>

</xsl:stylesheet>
                              FileCheck.SelectString(-1, "10");
		}
	}
}


BEGIN_MESSAGE_MAP(CPreferencesMultiUserPage, CPreferencesPageBase)
	//{{AFX_MSG_MAP(CPreferencesMultiUserPage)
	ON_BN_CLICKED(IDC_CHECKINONNOEDIT, OnCheckinonnoedit)
	ON_BN_CLICKED(IDC_USE3RDPARTYSOURCECTRL, OnUse3rdpartysourcectrl)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_ENABLESOURCECONTROL, OnEnablesourcecontrol)
	ON_BN_CLICKED(IDC_PROMPTRELOADONWRITABLE, OnPromptreloadonwritable)
	ON_BN_CLICKED(IDC_PROMPTRELOADONCHANGE, OnPromptreloadontimestamp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesMultiUserPage message handlers

BOOL CPreferencesMultiUserPage::OnInitDialog() 
{
	CPreferencesPageBase::OnInitDialog();

	GetDlgItem(IDC_ENABLESOURCECONTROL)->EnableWindow(!m_bUse3rdPartySourceControl);
	GetDlgItem(IDC_SOURCECONTROLLANONLY)->EnableWindow(m_bEnableSourceControl && !m_bUse3rdPartySourceControl);
	GetDlgItem(IDC_AUTOCHECKOUT)->EnableWindow(m_bEnableSourceControl && !m_bUse3rdPartySourceControl);
	GetDlgItem(IDC_CHECKOUTONCHECKIN)->EnableWindow(m_bEnableSourceControl && !m_bUse3rdPartySourceControl);
	GetDlgItem(IDC_CHECKINONCLOSE)->EnableWindow(m_bEnableSourceControl && !m_bUse3rdPartySourceControl);
	GetDlgItem(IDC_CHECKINONNOEDIT)->EnableWindow(m_bEnableSourceControl && !m_bUse3rdPartySourceControl);
	GetDlgItem(IDC_INCLUDEUSERINCHECKOUT)->EnableWindow(m_bEnableSourceControl && !m_bUse3rdPartySourceControl);
	GetDlgItem(IDC_NOCHANGETIME)->EnableWindow(m_bEnableSourceCon﻿<?xml version="1.0" encoding="UTF-8"?>
<!--
    $Id: flat_sorted_todolist.xsl 6917 2008-05-20 08:15:32Z tandler $
    
    Flat task list sorted by priority and due date, 
    Peter Tandler, 2008, http://digital-moderation.com

    parameters for the XSL:
    
        dueuntil=nnnnn - specifies the date until which due tasks 
            should be shown (in MS OLE format as used internally 
            by TDL, days since 30/12/1899)
            if nnnnn = 0, select all tasks
        
        sortby=prio - first sort by prio then by due
        sortby=duedate - first sort by due then by prio
        
        showcomments=1 - show comments, otherwise hide
        
        showflagged=bold    - show flagged tasks in bold
        showflagged=only    - show flagged tasks only, hide others
        
        filename  - the name of the TDL file (used to generate links)
        projectname - the name of the project, per default TODOLIST/@PROJECTNAME otherwise the filename
-->


<!-- copied lots of stuff from ToDoListTableStylesheet_v1.0 by xabatcha@seznam.cz, 2006-10-17 -->
<!-- Feel free to use it or change it. -->
<!-- Transform ToDoList to html, using table layout -->
<!-- Only unfinished tasks are shown, restriction is specified in section 10 -->
<!-- To add other columns to output table please change section 20 and section 32 plus add appropriate part,which load atribute from todolist -->

<!-- ********************************************************** -->
<!-- 2011-03-08, Modifications made by cadraktiv: based on flat_sorted_todolist.xsl by Peter Tandler (see above) -->
<!-- USE WITH CARE - NO WARRANTY. Modified with simple Copy&Paste and Try&Error. -->
<!-- This file is made to generate a simple list of data, extracted from the TDL-files of software "ToDoList"-->
<!-- This file displays 
        ALL         done tasks
        SORTED      by done-date
        WITH        "Done date / Allocated to / Task name"    -->
<!-- For more configuration with the "params" see describtion above. -->
<!-- There is a lot of unused and copy-paste-trash-designed code inside. You are invited to clean it up.-->
<!-- ********************************************************** -->
<!-- ********************************************************** -->
<xsl:stylesheet version="2.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:strip-space elements="*"/>
    <xsl:output method="html" indent="yes" doctype-public="-//W3C//DTD HTML 4.01 Transitional//EN" encoding="utf-8"/>

    <!--<xsl:param name="sortby" select="'prio'" />-->
    <xsl:param name="sortby" select="'donedate'" />
    <xsl:param name="dueuntil" select="0" />
    <xsl:param name="showcomments" select="0" />
    <xsl:param name="showflagged" select="'bold'" />
    
    <xsl:param name="filename" select="TODOLIST/@FILENAME"/>
    <xsl:param name="projectname">
        <xsl:choose>
            <xsl:when test="string-length(TODOLIST/@PROJECTNAME) &gt; 0">
                <xsl:value-of select="TODOLIST/@PROJECTNAME"/>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$filename"/>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:param>
    
    
        
    <xsl:template match="TODOLIST">
        <html>
        <head>
                <title>Project Report 'Done-Dates': <xsl:value-of select="@PROJECTNAME" /></title>
            <xsl:call-template name="style"/>
        </head>
        <body>
        <xsl:element name="h2">Project Report 'Done-Dates': <xsl:value-of select="@PROJECTNAME"/></xsl:element>
        Date of Report: <xsl:value-of select="@REPORTDATE" />
        <p>Fileversion <xsl:value-of select="@FILEVERSION" /> from <xsl:value-of select="@LASTMODIFIED" /> (sorry, only current date)</p>

        <!--
        <p>filename 1: <xsl:value-of select="@FILENAME"/></p>
        <p>filename 2: <xsl:value-of select="$filename"/></p>
        -->
        
        <table 
            class="finished"
            cellspacing="0"
            cellpadding="5">
        
        <xsl:call-template name="get_Header"/>
        
                <!-- first take all tasks with a due date -->
                <xsl:for-each select="//TASK">
                    <xsl:sort 
                        select="@DONEDATE" 
                        data-type="number"
                        />
                    <xsl:if test="@DONEDATESTRING">
                        <xsl:call-template name="get_Task"/>
                    </xsl:if>
                </xsl:for-each>
        </table>
        </body>
        </html>
    </xsl:template>


    <!-- 20 - header of table - titles of columns -->
    <xsl:template name="get_Header">
        <xsl:element name="tr">
            <xsl:attribute name="class">header</xsl:attribute>
<!--
            <xsl:element name="td">
                <xsl:attribute name="class">header headerid</xsl:attribute>
                <xsl:attribute name="width">15</xsl:attribute>
                <xsl:text>ID</xsl:text>
            </xsl:element>
            <xsl:element name="td">
                <xsl:attribute name="class">header headerprior</xsl:attribute>
                <xsl:attribute name="width">15</xsl:attribute>
                <xsl:text>!</xsl:text>
            </xsl:element>
            <xsl:element name="td">
                <xsl:attribute name="class">header headerprogress</xsl:attribute>
                <xsl:attribute name="width">25</xsl:attribute>
                <xsl:text>%</xsl:text>
            </xsl:element>
-->
      