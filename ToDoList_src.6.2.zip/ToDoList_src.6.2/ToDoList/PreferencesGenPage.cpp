sl:element name="td">
                <xsl:attribute name="class">header headerprior</xsl:attribute>
                <xsl:attribute name="width">15</xsl:attribute>
                <xsl:text>!</xsl:text>
            </xsl:element>
            <xsl:element name="td">
                <xsl:attribute name="class">header headerprogress</xsl:attribute>
                <xsl:attribute name="width">25</xsl:attribute>
                <xsl:text>%</xsl:text>
            </xsl:element>
-->
            <xsl:element name="td">
                <xsl:attribute name="class">header</xsl:attribute>
                <xsl:attribute name="width">100</xsl:attribute>
                <xsl:text>Spent time</xsl:text>
            </xsl:element>
            <xsl:element name="td">
                <xsl:attribute name="class">header</xsl:attribute>
                <xsl:attribute name="width">30</xsl:attribute>
                <xsl:text>Done</xsl:text>
            </xsl:element>
            <xsl:element name="td">
                <xsl:attribute name="class">header</xsl:attribute>
                <xsl:attribute name="width">120</xsl:attribute>
                <xsl:text>Allocated to</xsl:text>
            </xsl:element>
<!--
            <xsl:element name="td">
                <xsl:attribute name="class">header</xsl:attribute>
                <xsl:attribute name="width">50</xsl:attribute>
                <xsl:text>Category</xsl:text>
            </xsl:element>
            <xsl:element name="td">
                <xsl:attribute name="class">header</xsl:attribute>
                <xsl:attribute name="width">50</xsl:attribute>
                <xsl:text>Status</xsl:text>
            </xsl:element>
-->
            <xsl:element name="td">
                <xsl:attribute name="class">header</xsl:attribute>
                <xsl:text>Task</xsl:text>
            </xsl:element>
        </xsl:element>
    </xsl:template>


    <!-- 31- single task -->
    <xsl:template name="get_Task">
            <xsl:element name="tr">
            <xsl:call-template name="get_Task_Details"/>
            </xsl:element>
    </xsl:template>




    <!--32 - detail of single task -->  
    <xsl:template name="get_Task_Details">
<!--
        <xsl:call-template name="get_ID"/>
        <xsl:call-template name="get_Priority"/>
        <xsl:call-template name="get_Progress"/>
        <xsl:call-template name="get_due"/>
        -->
        <xsl:call-template name="get_spent"/>
        <xsl:call-template name="get_done"/>
        <xsl:call-template name="get_to"/>
<!--
        <xsl:call-template name="get_Category"/>
        <xsl:call-template name="get_Status"/>
        -->
        <xsl:call-template name="get_Task_title"/>
    </xsl:template>
    
    <!-- 40 - @PERCENTDONE as progress -->  
    <xsl:template name="get_Progress">
        <xsl:element name="td">
            <xsl:attribute name="class">progress bbasic</xsl:attribute>
            <xsl:value-of select="@PERCENTDONE"/>
        </xsl:element>
    </xsl:template>
    
    <!-- 41 - @DUEDATESTRING if exists -->
    <xsl:template name="get_due">
        <xsl:element name="td">
            <xsl:choose>
                <xsl:when test="(@DUEDATESTRING)">
                    <xsl:attribute name="class">due bbasic</xsl:attribute>
                    <xsl:value-of select="@DUEDATESTRING"/>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:attribute name="class">due bbasic empty</xsl:attribute>
                    <xsl:text>.</xsl:text>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>
    
    <!-- 41b - @STARTDATESTRING if exists -->
    <xsl:template name="get_start">
        <xsl:element name="td">
            <xsl:choose>
                <xsl:when test="(@STARTDATESTRING)">
                    <xsl:attribute name="class">start bbasic</xsl:attribute>
                    <xsl:value-of select="@STARTDATESTRING"/>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:attribute name="class">start bbasic empty</xsl:attribute>
                    <xsl:text>.</xsl:text>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>
    
    <!-- 41c - @CALCTIMESPENT if exists -->
    <xsl:template name="get_spent">
        <xsl:element name="td">
            <xsl:choose>
                <xsl:when test="(@CALCTIMESPENT)">
                    <xsl:attribute name="class">start bbasic spent</xsl:attribute>
                    <xsl:value-of select='format-number((@CALCTIMESPENT), "#.00")'/>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:attribute name="class">start bbasic empty</xsl:attribute>
                    <xsl:text>"---"</xsl:text>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>
    
    <!-- 41c - Done or not-->
    <xsl:template name="get_done">
        <xsl:element name="td">
            <xsl:choose>
                <xsl:when test="(@DONEDATESTRING)">
                    <xsl:attribute name="class">start bbasic empty</xsl:attribute>
                    <xsl:text>X</xsl:text>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:attribute name="class">start bbasic empty</xsl:attribute>
                    <xsl:text>-</xsl:text>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>
    
    <!-- 42 - @PRIORITY as colored priority -->
    <xsl:template name="get_Priority">
        <xsl:choose>
            <xsl:when test="@PRIORITY &lt; 0">
                <xsl:element name="td">
                    <xsl:attribute name="class">prior bbasic empty</xsl:attribute>
                    <xsl:text>.</xsl:text>
                </xsl:element>
            </xsl:when>
            <xsl:otherwise>
                <xsl:element name="td">
                    <xsl:attribute name="class">prior bbasic</xsl:attribute>
                    <xsl:attribute name="style">background-color: <xsl:value-of select="@PRIORITYWEBCOLOR"/>;</xsl:attribute>
                    <xsl:value-of select="@PRIORITY"/>
                </xsl:element>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    
    <!-- 43 - @PERSON as person who should do a work -->    
<xsl:template name="get_to">
		<xsl:element name="td">
			<xsl:choose>
				<xsl:when test="(@PERSON)">
					<xsl:attribute name="class">to bbasic</xsl:attribute>
					<xsl:value-of select="@PERSON"/>
					<!-- actually it would be good to check NUMPERSON and have a loop here (2011-02-25-pt) -->
					<xsl:if test="@PERSON1">; <xsl:value-of select="@PERSON1" />
					</xsl:if>
					<xsl:if test="@PERSON2">; <xsl:value-of select="@PERSON2" />
					</xsl:if>
					<xsl:if test="@PERSON3">; <xsl:value-of select="@PERSON3" />
					</xsl:if>
					<xsl:if test="@PERSON4">; <xsl:value-of select="@PERSON4" />
			