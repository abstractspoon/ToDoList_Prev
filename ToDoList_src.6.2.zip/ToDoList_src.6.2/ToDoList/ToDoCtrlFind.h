// ToDoCtrlData.h: interface for the CToDoCtrlData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TODOCTRLTREEDATA_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_)
#define AFX_TODOCTRLTREEDATA_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "tdcstruct.h"

class TODOITEM;
class TODOSTRUCTURE;
class CToDoCtrlData;

class CToDoCtrlFind  
{
public:
	CToDoCtrlFind(CTreeCtrl& tree, const CToDoCtrlData& data);
	virtual ~CToDoCtrlFind();
	
	HTREEITEM GetItem(DWORD dwID) const;
	DWORD GetTaskID(HTREEITEM hti) const;
	TODOITEM* GetTask(HTREEITEM hti) const;

	// Gets
	CString GetLongestVisibleExternalID() const;
	CString GetLongestVisibleCategory() const;
	CString GetLongestVisibleAllocTo() const;
	CString GetLongestVisibleTimeEstimate(int nDefUnits) const;
	CString GetLongestVisibleTimeSpent(int nDefUnits) const;
	CString GetLongestVisibleRecurrence() const;

	BOOL FindVisibleTaskWithDueTime() const;
	BOOL FindVisibleTaskWithStartTime() const;
	BOOL FindVisibleTaskWithDoneTime() const;

	int FindTasks(const SEARCHPARAMS& params, CResultArray& aResults) const;
	DWORD FindFirstTask(const SEARCHPARAMS& params, SEARCHRESULT& result) const;
	DWORD FindNextTask(DWORD dwStart, const SEARCHPARAMS& params, SEARCHRESULT& result, BOOL bNext = TRUE) const;
	
protected:
	CTreeCtrl& m_tree; 
	const CToDoCtrlData& m_data;

protected:
	void FindTasks(HTREEITEM hti, const SEARCHPARAMS& params, CResultArray& aResults) const;
	DWORD FindFirstTask(HTREEITEM htiStart, const SEARCHPARAMS& params, SEARCHRESULT& result) const;

	CString GetLongestVisibleExternalID(HTREEITEM hti) const;
	CString GetLongestVisibleCategory(HTREEITEM hti) const;
	CString GetLongestVisibleAllocTo(HTREEITEM hti) const;
	CString GetLongestVisibleTime(HTREEITEM hti, int nDefUnits, BOOL bTimeEst) const;
	CString GetLongestVisibleRecurrence(HTREEITEM hti) const;

	BOOL FindVisibleTaskWithDueTime(HTREEITEM hti) const;
	BOOL FindVisibleTaskWithStartTime(HTREEITEM hti) const;
	BOOL FindVisibleTaskWithDoneTime(HTREEITEM hti) const;

	CString GetLongestVisibleExternalID(HTREEITEM hti, const TODOITEM* pTDI) const;
	CString GetLongestVisibleCategory(HTREEITEM hti, const TODOITEM* pTDI) const;
	CString GetLongestVisibleAllocTo(HTREEITEM hti, const TODOITEM* pTDI) const;
	CString GetLongestVisibleTime(HTREEITEM hti, const TODOITEM* pTDI, const TODOSTRUCTURE* pTDS, int nDefUnits, BOOL bTimeEst) const;
	CString GetLongestVisibleRecurrence(HTREEITEM hti, const TODOITEM* pTDI) const;
};

#endif // !defined(AFX_TODOCTRLTREEDATA_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_)
