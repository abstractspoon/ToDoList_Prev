bitmap.CreateCompatibleBitmap(&dc, nImWidth * nNumStates, nImHeight))
		{
			CGdiObject* pOld = dcBack.SelectObject(&bitmap);
			dcBack.FillSolidRect(0, 0, nImWidth * nNumStates, nImHeight, crMask);
			
			CRect rState(BORDER, BORDER, size.cx + BORDER, size.cy + BORDER);

			for (int nState = 0; nState < nNumStates; nState++)
			{
				if (nStates[nState] != -1)
					DrawBackground(&dcBack, nPart, nStates[nState], rState);
				
				// next state
				rState.OffsetRect(nImWidth, 0);
			}
			
			dcBack.SelectObject(pOld);
			
			// create imagelist
			if (il.Create(nImWidth, nImHeight, ILC_COLOR32 | ILC_MASK, 0, 1))
				il.Add(&bitmap, crMask);
		}
	}
	
	return (il.GetSafeHandle() != NULL);
}

COLORREF CThemed::GetThemeColor(int nPart, int nState, int nProp)
{
	ASSERT (m_hTheme);

	COLORREF color;
	
	if (GetThemeColor(nPart, nState, nProp, &color))
		return color;

	return 0; // black
}

BOOL CThemed::GetThemeBackgroundContentRect(CDC* pDC, int nPart, int nState, const CRect& rBounding, CRect& rContent)
{
	ASSERT (m_hTheme);
	ASSERT_VALID (pDC);

	return GetThemeBackgroundContentRect(pDC->GetSafeHdc(), nPart, nState, rBounding, rContent);
}

// -----------------------------------------------------------------------------------------------------------

BOOL CThemed::IsThemeActive()
{
	if (s_hUxTheme)
	{
		PFNISTHEMEACTIVE fnIsThemeActive = (PFNISTHEMEACTIVE)GetProcAddress(s_hUxTheme, "IsThemeActive");
		
		if (fnIsThemeActive)
			return fnIsThemeActive();
	}
	
	return FALSE;
}

DWORD CThemed::GetAppThemeProperties()
{
	if (s_hUxTheme)
	{
		PFNGETTHEMEAPPPROPERTIES fnGetThemeAppProperties = (PFNGETTHEMEAPPPROPERTIES)GetProcAddress(s_hUxTheme, "GetThemeAppProperties");
		
		if (fnGetThemeAppProperties)
			return fnGetThemeAppProperties();
	}
	
	return 0;
}

HTHEME CThemed::OpenThemeData(HWND hwnd, LPCWSTR pszClassList)
{
	if (s_hUxTheme)
	{
		PFNOPENTHEMEDATA fnOpenThemeData = (PFNOPENTHEMEDATA)GetProcAddress(s_hUxTheme, "OpenThemeData");
		
		if (fnOpenThemeData)
			return fnOpenThemeData(hwnd, pszClassList);
	}
	
	return NULL;
}

BOOL CThemed::CloseThemeData(HTHEME hTheme)
{
	if (s_hUxTheme && hTheme)
	{
		PFNCLOSETHEMEDATA fnCloseThemeData = (PFNCLOSETHEMEDATA)GetProcAddress(s_hUxTheme, "CloseThemeData");
		
		if (fnCloseThemeData)
			return SUCCEEDED(fnCloseThemeData(m_hTheme));
	}
	
	return FALSE;
}

BOOL CThemed::DrawThemeBackground(HDC hdc, int iPartId, int iStateId, const RECT *pRect,
								  const RECT *pClipRect)
{
	if (s_hUxTheme && m_hTheme)
	{
		PFNDRAWTHEMEBACKGROUND fnDrawThemeBackground = (PFNDRAWTHEMEBACKGROUND)GetProcAddress(s_hUxTheme, "DrawThemeBackground");
		
		if (fnDrawThemeBackground)
			return (SUCCEEDED(fnDrawThemeBackground(m_hTheme, hdc, iPartId, iStateId, pRect, pClipRect)));
	}
	
	return FALSE;
}

BOOL CThemed::DrawThemeParentBackground(HWND hWnd, HDC hdc, RECT *pRect)
{
	if (s_hUxTheme && m_hTheme)
	{
		PFNDRAWTHEMEPARENTBACKGROUND fnDrawThemeParentBackground = (PFNDRAWTHEMEPARENTBACKGROUND)GetProcAddress(s_hUxTheme, "DrawThemeParentBackground");
		
		if (fnDrawThemeParentBackground)
			return (SUCCEEDED(fnDrawThemeParentBackground(hWnd, hdc, pRect)));
	}
	
	return FALSE;
}

BOOL CThemed::DrawThemeText(HDC hdc, int iPartId, int iStateId, LPCWSTR pszText, int iCharCount, 
							DWORD dwTextFlags, DWORD dwTextFlags2, const RECT *pRect)
{
	if (s_hUxTheme && m_hTheme)
	{
		PFNDRAWTHEMETEXT fnDrawThemeText = (PFNDRAWTHEMETEXT)GetProcAddress(s_hUxTheme, "DrawThemeText");
		
		if (fnDrawThemeText)
			return (SUCCEEDED(fnDrawThemeText(m_hTheme, hdc, iPartId, iStateId, pszText, iCharCount, dwTextFlags, dwTextFlags2, pRect)));
	}
	
	return FALSE;
}

BOOL CThemed::DrawThemeEdge(HDC hdc, int iPartId, int iStateId, const RECT *pDestRect, UINT uEdge, 
							UINT uFlags, RECT *pContentRect)
{
	if (s_hUxTheme && m_hTheme)
	{
		PFNDRAWTHEMEEDGE fnDrawThemeEdge = (PFNDRAWTHEMEEDGE)GetProcAddress(s_hUxTheme, "DrawThemeEdge");
		
		if (fnDrawThemeEdge)
			return (SUCCEEDED(fnDrawThemeEdge(m_hTheme, hdc, iPartId, iStateId, pDestRect, uEdge, uFlags, pContentRect)));
	}
	
	return FALSE;
}

BOOL CThemed::DrawThemeIcon(HDC hdc, int iPartId, int iStateId, const RECT *pRect, HIMAGELIST himl, 
							int iImageIndex)
{
	if (s_hUxTheme && m_hTheme)
	{
		PFNDRAWTHEMEICON fnDrawThemeIcon = (PFNDRAWTHEMEICON)GetProcAddress(s_hUxTheme, "DrawThemeIcon");
		
		if (fnDrawThemeIcon)
			return (SUCCEEDED(fnDrawThemeIcon(m_hTheme, hdc, iPartId, iStateId, pRect, himl, iImageIndex)));
	}
	
	return FALSE;
}

BOOL CThemed::DrawThemeBorder(HDC hdc, int iStateId, const RECT *pRect)
{
	if (s_hUxTheme && m_hTheme)
	{
		PFNDRAWTHEMEBORDER fnDrawThemeBorder = (PFNDRAWTHEMEBORDER)GetProcAddress(s_hUxTheme, "DrawThemeBorder");
		
		if (fnDrawThemeBorder)
			return (SUCCEEDED(fnDrawThemeBorder(m_hTheme, hdc, iStateId, pRect)));
	}
	
	return FALSE;
}

BOOL CThemed::GetThemePartSize(int iPartId, int iStateId, THEMESIZE eSize, SIZE *psz)
{
	if (s_hUxTheme && m_hTheme)
	{
		PFNGETTHEMEPARTSIZE fnGetThemePartSize = (PFNGETTHEMEPARTSIZE)GetProcAddress(s_hUxTheme, "GetThemePartSize");
		
		if (fnGetThemePartSize)
			return (SUCCEEDED(fnGetThemePartSize(m_hTheme, NULL, iPartId, iStateId, NULL, eSize, psz)));
	}
	
	return FALSE;
}

BOOL CThemed::GetThemeTextExtent(HDC hdc, int iPartId, int iStateId, LPCWSTR pszText, int iCharCount, 
								DWORD dwTextFlags, const RECT *pBoundingRect, RECT *pExtentRect)
{
	if (s_hUxTheme && m_hTheme)
	{
		PFNGETTHEMETEXTEXTENT fnGetThemeTextExtent = (PFNGETTHEMETEXTEXTENT)GetProcAddress(s_hUxTheme, "GetThemeTextExtent");
		
		if (fnGetThemeTextExtent)
			return (SUCCEEDED(fnGetThemeTextExtent(m_hTheme, hdc, iPartId, iStateId, pszText, iCharCount, dwTextFlags, pBoundingRect, pExtentRect)));
	}
	
	return FALSE;
}

BOOL CThemed::GetThemeColor(int iPartId, int iStateId, int iPropId, COLORREF *pColor)
{
	if (s_hUxTheme && m_hTheme)
	{
		PFNGETTHEMECOLOR fnGetThemeColor = (PFNGETTHEMECOLOR)GetProcAddress(s_hUxTheme, "GetThemeColor");
		
		if (fnGetThemeColor)
			return (SUCCEEDED(fnGetThemeColor(m_hTheme, iPartId, iStateId, iPropId, pColor)));
	}
	
	return FALSE;
}

BOOL CThemed::GetThemeBackgroundContentRect(HDC hdc, int iPartId, int iStateId, LPCRECT pBoundingRect, LPRECT pContentRect)
{
	if (s_hUxTheme && m_hTheme)
	{
		PFNGETTHEMEBACKGROUNDCONTENTRECT fnGetContentRect = (PFNGETTHEMEBACKGROUNDCONTENTRECT)
															GetProcAddress(s_hUxTheme, "GetThemeBackgroundContentRect");
		
		if (fnGetContentRect)
			return (SUCCEEDED(fnGetContentRect(m_hTheme, hdc, iPartId, iStateId, pBoundingRect, pContentRect)));
	}
	
	return FALSE;
}

// -----------------------------------------------------------------------------------------------------------

BOOL CThemed::GetThemeClassPartState(int nType, int nState, CString& sThClass, int& nThPart, int& nThState)
{
	sThClass.Empty();
	nThPart = 0;
	nThState = 0;
	
	switch (nType)
	{
	case DFC_BUTTON:
		{
			sThClass = "BUTTON";
			nThState = PBS_NORMAL;
			
			if (nState & DFCS_BUTTONPUSH) 
			{
				nThPart = BP_PUSHBUTTON;
				
				if (nState & (DFCS_CHECKED | DFCS_PUSHED))
					nThState = PBS_PRESSED;
				
				else if (nState & DFCS_INACTIVE)
					nThState = PBS_DISABLED;
				
				else if (nState & DFCS_HOT)
					nThState = PBS_HOT;
			}
			/*			else if (nState & DFCS_BUTTONRADIO) 
			{
			nThPart = BP_RADIOBUTTON;
			}*/
			else if ((nState & DFCS_BUTTONCHECK) == DFCS_BUTTONCHECK) 
			{
				nThPart = BP_CHECKBOX;
				
				if (nState & (DFCS_CHECKED | DFCS_PUSHED))
				{
					if (nState & DFCS_INACTIVE)
						nThState = CBS_CHECKEDDISABLED;

					else if (nState & DFCS_HOT)
						nThState = CBS_CHECKEDHOT;
					else
						nThState = CBS_CHECKEDNORMAL;
				}
				else
				{
					if (nState & DFCS_INACTIVE)
						nThState = CBS_UNCHECKEDDISABLED;

					else if (nState & DFCS_HOT)
						nThState = CBS_UNCHECKEDHOT;
					else
						nThState = CBS_UNCHECKEDNORMAL;
				}
			}
			else 
				return FALSE;
		}
		break;
		
	case DFC_CAPTION:
		break;
		
	case DFC_MENU:
		break;
		
	case DFC_POPUPMENU:
		break;
		
	case DFC_SCROLL:
		{
			if (nState & DFCS_SCROLLCOMBOBOX) 
			{
				sThClass = "COMBOBOX";
				nThPart = CP_DROPDOWNBUTTON;
				nThState = CBXS_NORMAL;
				
				if (nState & (DFCS_CHECKED | DFCS_PUSHED))
					nThState = CBXS_PRESSED;
				
				else if (nState & DFCS_INACTIVE)
					nThState = CBXS_DISABLED;
				
				else if (nState & DFCS_HOT)
					nThState = CBXS_HOT;
			}
			else if (nState & DFCS_SCROLLSIZEGRIP)
			{
				sThClass = "SCROLLBAR";
				nThPart = SBP_SIZEBOX;
				nThState = (nState & DFCS_SCROLLLEFT) ? SZB_LEFTALIGN : SZB_RIGHTALIGN;
			}
			// else
		}
		break;
	}
	
	return (!sThClass.IsEmpty() && (nThPart && nThState));
}
                                                                                                                                                                                                                                                   (CF_HDROP, *this))
	{
		if (::OpenClipboard(*this))
		{
			HANDLE hData = ::GetClipboardData(CF_HDROP);
			ASSERT(hData);

			CStringArray aFiles;
			Misc::GetDropFilePaths((HDROP)hData, aFiles);

			::CloseClipboard();

			if (aFiles.GetSize())
				return CRichEditHelper::PasteFiles(*this, aFiles, REP_ASFILEURL);
		}
	}

	// else
	CUrlRichEditCtrl::Paste();
	return TRUE;
}

BOOL CToDoCommentsCtrl::CanPaste()
{
	// for reasons that I'm not entirely clear on even if we 
	// return that CF_HDROP is okay, the richedit itself will
	// veto the drop. So I'm experimenting with handling this ourselves
	if (Misc::ClipboardHasFormat(CF_HDROP, *this))
		return TRUE;

	return CUrlRichEditCtrl::CanPaste(CF_TEXT);
}


BOOL CToDoCommentsCtrl::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// bit of a hack but this is what we get just before the context
	// menu appears so we set the cursor back to the arrow
	if (nHitTest == HTCAPTION)
	{
		SetCursor(AfxGetApp()->LoadStandardCursor(MAKEINTRESOURCE(IDC_ARROW)));
		return TRUE;
	}
	
	return CUrlRichEditCtrl::OnSetCursor(pWnd, nHitTest, message);
}

BOOL CToDoCommentsCtrl::IsTDLClipboardEmpty() const 
{ 
	// try for any clipboard first
	ITaskList* pClipboard = (ITaskList*)GetParent()->SendMessage(WM_TDCM_GETCLIPBOARD, 0, FALSE);
	ITaskList4* pClip4 = GetITLInterface<ITaskList4>(pClipboard, IID_TASKLIST4);

	if (pClip4)
		return (pClipboard->GetFirstTask() == NULL);

	// else try for 'our' clipboard only
	return (!GetParent()->SendMessage(WM_TDCM_HASCLIPBOARD, 0, TRUE)); 
}

LRESULT CToDoCommentsCtrl::SendNotifyCustomUrl(LPCTSTR szUrl) const
{
	CString sUrl(szUrl);
	sUrl.MakeLower();

	if (sUrl.Find(TDL_PROTOCOL) != -1 || sUrl.Find(TDL_EXTENSION) != -1)
	{
		return GetParent()->SendMessage(WM_TDCM_TASKLINK, 0, (LPARAM)(LPCTSTR)sUrl);
	}

	return 0;
}

void CToDoCommentsCtrl::PreSubclassWindow() 
{
	EnableToolTips();
	
	CUrlRichEditCtrl::PreSubclassWindow();
}

void CToDoCommentsCtrl::SavePreferences(IPreferences* pPrefs, LPCTSTR szKey) const
{
	pPrefs->WriteProfileInt(szKey, "WordWrap", m_bWordWrap);
}

void CToDoCommentsCtrl::LoadPreferences(const IPreferences* pPrefs, LPCTSTR szKey)
{
	BOOL bWordWrap = pPrefs->GetProfileInt(szKey, "WordWrap", TRUE);

	// we need to post the wordwrap initialization else the richedit
	// get very confused about something and doesn't repaint properly
	// when resizing
	PostMessage(WM_SETWORDWRAP, bWordWrap, (LPARAM)GetSafeHwnd());
}

LRESULT CToDoCommentsCtrl::OnSetWordWrap(WPARAM wp, LPARAM lp)
{
	UNREFERENCED_PARAMETER (lp);
	ASSERT (lp == (LPARAM)GetSafeHwnd());
	
	SetWordWrap(wp);
	return 0L;
}

int CToDoCommentsCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CUrlRichEditCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;

	CAutoFlag af(m_bAllowNotify, FALSE); // else we can get a false edit change

	// set max edit length
	LimitText(1024 * 1024 * 1024); // one gigabyte

	// set text mode to plain text
//	SendMessage(EM_S// Themed.h: interface for the CThemed class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_THEMED_H__2FA586FE_B790_4315_93B9_01000725B68A__INCLUDED_)
#define AFX_THEMED_H__2FA586FE_B790_4315_93B9_01000725B68A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\3rdparty\uxtheme.h"

#if _MSC_VER >= 1400
#include <vsstyle.h>
#else
#include "..\3rdparty\TmSchema.h" // for part and state enumerations
#endif

#if (WINVER < 0x0500)
#	define DFCS_TRANSPARENT        0x0800
#	define DFCS_HOT                0x1000
#	define DFC_POPUPMENU           5
#endif

class CThemed  
{
public:
	CThemed(CWnd* pWnd = NULL, LPCTSTR szClassList = NULL);
	virtual ~CThemed();
	
	static BOOL AreControlsThemed();
	static BOOL IsNonClientThemed();
	static BOOL IsWebContentThemed();
	static BOOL IsThemeActive();
	static BOOL SupportsTheming(int nFlag);
	
	static BOOL DrawFrameControl(const CWnd* pWnd, CDC* pDC, LPRECT pRect, UINT nType, UINT nState, LPCRECT prClip = NULL);
	static BOOL DrawEdge(const CWnd* pWnd, CDC* pDC, LPRECT pRect, UINT nType, UINT nState, UINT nEdge, UINT nFlags);
	static BOOL DrawCaption(const CWnd* pWnd, CDC* pDC, LPRECT pRect, UINT nFlags);
	
	BOOL Open(const CWnd* pWnd, LPCTSTR szClassList);
	BOOL IsValid() { return (