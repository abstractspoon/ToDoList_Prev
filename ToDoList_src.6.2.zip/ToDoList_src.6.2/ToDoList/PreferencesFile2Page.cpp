// PreferencesFilePage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesFile2Page.h"

#include "..\shared\enstring.h"
#include "..\shared\dialoghelper.h"
#include "..\shared\filemisc.h"
#include "..\shared\importexportmgr.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesFile2Page property page

IMPLEMENT_DYNCREATE(CPreferencesFile2Page, CPreferencesPageBase)

CPreferencesFile2Page::CPreferencesFile2Page(const CImportExportMgr* pExportMgr) : 
		CPreferencesPageBase(CPreferencesFile2Page::IDD),
		m_eExportFolderPath(FES_FOLDERS | FES_COMBOSTYLEBTN | FES_RELATIVEPATHS),
		m_eSaveExportStylesheet(FES_COMBOSTYLEBTN | FES_RELATIVEPATHS, CEnString(IDS_XSLFILEFILTER)),
		m_pExportMgr(pExportMgr),
		m_eBackupLocation(FES_FOLDERS | FES_COMBOSTYLEBTN | FES_RELATIVEPATHS)
{
//	m_psp.dwFlags &= ~PSP_HASHELP;

	//{{AFX_DATA_INIT(CPreferencesFile2Page)
	m_nKeepBackups = 50;
	m_bExportFilteredOnly = FALSE;
	//}}AFX_DATA_INIT
	m_bOtherExport = FALSE;
	m_nOtherExporter = 1;
	m_bBackupOnSave = FALSE;
	m_nKeepBackups = 0;
	m_bExportFilteredOnly = FALSE;
	m_bExportToFolder = FALSE;
	m_nAutoSaveFrequency = 5;
	m_bAutoSave = TRUE;
	m_bAutoExport = FALSE;
	m_bAutoSaveOnSwitchTasklist = FALSE;
	m_bAutoSaveOnSwitchApp = FALSE;
	m_bOtherExport = FALSE;
	m_nOtherExporter = -1;
	m_bUseStylesheetForSaveExport = FALSE;
}

CPreferencesFile2Page::~CPreferencesFile2Page()
{
}

void CPreferencesFile2Page::DoDataExchange(CDataExchange* pDX)
{
	CPreferencesPageBase::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesFile2Page)
	DDX_Control(pDX, IDC_NUMBACKUPSTOKEEP, m_cbKeepBackups);
	DDX_Control(pDX, IDC_BACKUPLOCATION, m_eBackupLocation);
	DDX_Check(pDX, IDC_BACKUPONSAVE, m_bBackupOnSave);
	DDX_Text(pDX, IDC_BACKUPLOCATION, m_sBackupLocation);
	DDX_CBIndex(pDX, IDC_NUMBACKUPSTOKEEP, m_nKeepBackups);
	DDX_Check(pDX, IDC_EXPORTFILTERED, m_bExportFilteredOnly);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_OTHEREXPORTERS, m_cbOtherExporters);
	DDX_Control(pDX, IDC_SAVEEXPORTSTYLESHEET, m_eSaveExportStylesheet);
	DDX_Control(pDX, IDC_EXPORTFOLDER, m_eExportFolderPath);
	DDX_Check(pDX, IDC_EXPORTTOFOLDER, m_bExportToFolder);
	DDX_Text(pDX, IDC_EXPORTFOLDER, m_sExportFolderPath);
	DDX_Text(pDX, IDC_SAVEEXPORTSTYLESHEET, m_sSaveExportStylesheet);
	DDX_Check(pDX, IDC_USESTYLESHEETFORSAVE, m_bUseStylesheetForSaveExport);
	DDX_Check(pDX, IDC_AUTOSAVEONSWITCHTASKLIST, m_bAutoSaveOnSwitchTasklist);
	DDX_Check(pDX, IDC_AUTOSAVEONSWITCHAPP, m_bAutoSaveOnSwitchApp);
	DDX_Radio(pDX, IDC_HTMLEXPORT, m_bOtherExport);
	DDX_CBIndex(pDX, IDC_OTHEREXPORTERS, m_nOtherExporter);
	DDX_Control(pDX, IDC_AUTOSAVEFREQUENCY, m_cbAutoSave);
	DDX_Check(pDX, IDC_AUTOEXPORT, m_bAutoExport);
	DDX_Check(pDX, IDC_AUTOSAVE, m_bAutoSave);

	// custom
	if (pDX->m_bSaveAndValidate)
	{
		m_nKeepBackups = CDialogHelper::GetSelectedItemAsValue(m_cbKeepBackups);

		if (m_bAutoSave)
			m_nAutoSaveFrequency = CDialogHelper::GetSelectedItemAsValue(m_cbAutoSave);
		else
			m_nAutoSaveFrequency = 0;
	}
	else
	{
		if (!CDialogHelper::SelectItemByValue(m_cbKeepBackups, m_nKeepBackups))
		{
			if (m_nKeepBackups == 0) // all
				m_cbKeepBackups.SelectString(-1, "All");
			else
			{
				m_nKeepBackups = 10;
				m_cbKeepBackups.SelectString(-1, "10");
			}
		}

		if (m_bAutoSave)
		{
			if (!CDialogHelper::SelectItemByValue(m_cbAutoSave, m_nAutoSaveFrequency))
			{
				m_nAutoSaveFrequency = 5;
				m_cbAutoSave.SelectString(-1, "5");
			}
		}
		else
			m_cbAutoSave.SetCurSel(2);
	}
}


BEGIN_MESSAGE_MAP(CPreferencesFile2Page, CPreferencesPageBase)
	//{{AFX_MSG_MAP(CPreferencesFile2Page)
	ON_BN_CLICKED(IDC_BACKUPONSAVE, OnBackuponsave)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_EXPORTTOFOLDER, OnExporttofolder)
	ON_BN_CLICKED(IDC_AUTOEXPORT, OnAutoexport)
	ON_BN_CLICKED(IDC_USESTYLESHEETFORSAVE, OnUsestylesheetforsave)
	ON_BN_CLICKED(IDC_HTMLEXPORT, OnHtmlexport)
	ON_BN_CLICKED(IDC_OTHEREXPORT, OnOtherexport)
	ON_BN_CLICKED(IDC_AUTOSAVE, OnAutosave)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesFile2Page message handlers

BOOL CPreferencesFile2Page::OnInitDialog() 
{
	CPreferencesPageBase::OnInitDialog();

	m_mgrGroupLines.AddGroupLine(IDC_BACKUPGROUP, *this);
	m_mgrGroupLines.AddGroupLine(IDC_SAVEGROUP, *this);
	
	m_eExportFolderPath.SetFolderPrompt(CEnString(IDS_PFP_SELECTFOLDER));

	GetDlgItem(IDC_BACKUPLOCATION)->EnableWindow(m_bBackupOnSave);
	GetDlgItem(IDC_BACKUPLOCATIONLABEL)->EnableWindow(m_bBackupOnSave);

	GetDlgItem(IDC_BACKUPCOUNTLABEL)->EnableWindow(m_bBackupOnSave);
	GetDlgItem(IDC_NUMBACKUPSTOKEEP)->EnableWindow(m_bBackupOnSave);
	GetDlgItem(IDC_BACKUPCOUNTTRAIL)->EnableWindow(m_bBackupOnSave);

	GetDlgItem(IDC_AUTOSAVEFREQUENCY)->EnableWindow(m_bAutoSave);
	GetDlgItem(IDC_EXPORTTOFOLDER)->EnableWindow(m_bAutoExport);
	GetDlgItem(IDC_EXPORTFOLDER)->EnableWindow(m_bAutoExport && m_bExportToFolder);
	GetDlgItem(IDC_HTMLEXPORT)->EnableWindow(m_bAutoExport);
	GetDlgItem(IDC_USESTYLESHEETFORSAVE)->EnableWindow(m_bAutoExport && !m_bOtherExport);
	GetDlgItem(IDC_SAVEEXPORTSTYLESHEET)->EnableWindow(m_bAutoExport && !m_bOtherExport && m_bUseStylesheetForSaveExport);
	GetDlgItem(IDC_OTHEREXPORT)->EnableWindow(m_bAutoExport);
	GetDlgItem(IDC_OTHEREXPORTERS)->EnableWindow(m_bAutoExport && m_bOtherExport);
	GetDlgItem(IDC_EXPORTFILTERED)->EnableWindow(m_bAutoExport);

	// build the exporter format comboxbox
	ASSERT(m_pExportMgr);

	for (int nExp = 0; nExp < m_pExportMgr->GetNumExporters(); nExp++)
		m_cbOtherExporters.AddString(m_pExportMgr->GetExporterMenuText(nExp));

	m_cbOtherExporters.SetCurSel(m_nOtherExporter);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreferencesFile2Page::LoadPreferences(const CPreferences& prefs)
{
	m_bBackupOnSave = prefs.GetProfileInt("Preferences", "BackupOnSave", TRUE);
	m_sBackupLocation = prefs.GetProfileString("Preferences", "BackupLocation", "backup");
	m_nKeepBackups = prefs.GetProfileInt("Preferences", "KeepBackups", 10);

	// saving
	m_nAutoSaveFrequency = prefs.GetProfileInt("Preferences", "AutoSaveFrequency", 1);
	m_bAutoExport = prefs.GetProfileInt("Preferences", "AutoHtmlExport", FALSE);
	m_sExportFolderPath = prefs.GetProfileString("Preferences", "ExportFolderPath");
	m_sSaveExportStylesheet = prefs.GetProfileString("Preferences", "SaveExportStylesheet");
	m_bAutoSaveOnSwitchTasklist = prefs.GetProfileInt("Preferences", "AutoSaveOnSwitchTasklist", FALSE);
	m_bAutoSaveOnSwitchApp = prefs.GetProfileInt("Preferences", "AutoSaveOnSwitchApp", FALSE);
	m_bOtherExport = prefs.GetProfileInt("Preferences", "OtherExport", FALSE);
	m_nOtherExporter = prefs.GetProfileInt("Preferences", "OtherExporter", 1);
	m_bExportFilteredOnly = prefs.GetProfileInt("Preferences", "ExportFilteredOnly", FALSE);

	// these are dependent on the values they control for backward compat
	m_bUseStylesheetForSaveExport = prefs.GetProfileInt("Preferences", "UseStylesheetForSaveExport", !m_sSaveExportStylesheet.IsEmpty());
	m_bExportToFolder = prefs.GetProfileInt("Preferences", "ExportToFolder", !m_sExportFolderPath.IsEmpty());

	m_sExportFolderPath.TrimLeft();
	m_sExportFolderPath.TrimRight();

	m_bAutoSave = (m_nAutoSaveFrequency > 0);

	// set file edit directories and make paths relative
	CString sFolder = FileMisc::GetAppFolder();

	m_eExportFolderPath.SetCurrentFolder(sFolder);
	m_sExportFolderPath = FileMisc::GetRelativePath(m_sExportFolderPath, sFolder, TRUE);

	m_eBackupLocation.SetCurrentFolder(sFolder);
	m_sBackupLocation = FileMisc::GetRelativePath(m_sBackupLocation, sFolder, TRUE);

	sFolder = FileMisc::GetAppResourceFolder();

	m_eSaveExportStylesheet.SetCurrentFolder(sFolder);
	m_sSaveExportStylesheet = FileMisc::GetRelativePath(m_sSaveExportStylesheet, sFolder, FALSE);

//	m_b = prefs.GetProfileInt("Preferences", "", FALSE);
}

void CPreferencesFile2Page::SavePreferences(CPreferences& prefs)
{
	// save settings
	prefs.WriteProfileInt("Preferences", "BackupOnSave", m_bBackupOnSave);
	prefs.WriteProfileString("Preferences", "BackupLocation", m_sBackupLocation);
	prefs.WriteProfileInt("Preferences", "KeepBackups", m_nKeepBackups);

	// saving
	prefs.WriteProfileInt("Preferences", "AutoSaveFrequency", m_nAutoSaveFrequency);
	prefs.WriteProfileInt("Preferences", "AutoHtmlExport", m_bAutoExport);
	prefs.WriteProfileInt("Preferences", "ExportToFolder", m_bExportToFolder);
	prefs.WriteProfileString("Preferences", "ExportFolderPath", m_sExportFolderPath);
	prefs.WriteProfileInt("Preferences", "UseStylesheetForSaveExport", m_bUseStylesheetForSaveExport);
	prefs.WriteProfileString("Preferences", "SaveExportStylesheet", m_sSaveExportStylesheet);
	prefs.WriteProfileInt("Preferences", "AutoSaveOnSwitchTasklist", m_bAutoSaveOnSwitchTasklist);
	prefs.WriteProfileInt("Preferences", "AutoSaveOnSwitchApp", m_bAutoSaveOnSwitchApp);
	prefs.WriteProfileInt("Preferences", "OtherExport", m_bOtherExport);
	prefs.WriteProfileInt("Preferences", "OtherExporter", m_nOtherExporter);
	prefs.WriteProfileInt("Preferences", "ExportFilteredOnly", m_bExportFilteredOnly);

//	prefs.WriteProfileInt("Preferences", "", m_b);
}

void CPreferencesFile2Page::OnBackuponsave() 
{
	UpdateData();

	GetDlgItem(IDC_BACKUPLOCATION)->EnableWindow(m_bBackupOnSave);
	GetDlgItem(IDC_BACKUPLOCATIONLABEL)->EnableWindow(m_bBackupOnSave);

	GetDlgItem(IDC_BACKUPCOUNTLABEL)->EnableWindow(m_bBackupOnSave);
	GetDlgItem(IDC_NUMBACKUPSTOKEEP)->EnableWindow(m_bBackupOnSave);
	GetDlgItem(IDC_BACKUPCOUNTTRAIL)->EnableWindow(m_bBackupOnSave);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesFile2Page::OnAutosave() 
{
	UpdateData();

	GetDlgItem(IDC_AUTOSAVEFREQUENCY)->EnableWindow(m_bAutoSave);

	if (m_bAutoSave && !m_nAutoSaveFrequency)
	{
		m_nAutoSaveFrequency = 5;
		m_cbAutoSave.SetCurSel(2);
	}

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesFile2Page::OnExporttofolder() 
{
	UpdateData();

	GetDlgItem(IDC_EXPORTFOLDER)->EnableWindow(m_bAutoExport && m_bExportToFolder);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesFile2Page::OnAutoexport() 
{
	UpdateData();	

	GetDlgItem(IDC_EXPORTTOFOLDER)->EnableWindow(m_bAutoExport);
	GetDlgItem(IDC_HTMLEXPORT)->EnableWindow(m_bAutoExport);
	GetDlgItem(IDC_OTHEREXPORT)->EnableWindow(m_bAutoExport);
	GetDlgItem(IDC_EXPORTFOLDER)->EnableWindow(m_bAutoExport && m_bExportToFolder);
	GetDlgItem(IDC_USESTYLESHEETFORSAVE)->EnableWindow(m_bAutoExport && !m_bOtherExport);
	GetDlgItem(IDC_SAVEEXPORTSTYLESHEET)->EnableWindow(m_bAutoExport && !m_bOtherExport && m_bUseStylesheetForSaveExport);
	GetDlgItem(IDC_OTHEREXPORTERS)->EnableWindow(m_bAutoExport && m_bOtherExport);
	GetDlgItem(IDC_EXPORTFILTERED)->EnableWindow(m_bAutoExport);

	CPreferencesPageBase::OnControlChange();
}

CString CPreferencesFile2Page::GetAutoExportFolderPath() const 
{ 
	if (m_bAutoExport && m_bExportToFolder && !m_sExportFolderPath.IsEmpty())
		return FileMisc::GetFullPath(m_sExportFolderPath, FileMisc::GetAppFolder());
	
	// else
	return "";
}

void CPreferencesFile2Page::OnUsestylesheetforsave() 
{
	UpdateData();
	
	GetDlgItem(IDC_USESTYLESHEETFORSAVE)->EnableWindow(m_bAutoExport);
	GetDlgItem(IDC_SAVEEXPORTSTYLESHEET)->EnableWindow(m_bAutoExport && m_bUseStylesheetForSaveExport);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesFile2Page::OnHtmlexport() 
{
	UpdateData();	

	GetDlgItem(IDC_USESTYLESHEETFORSAVE)->EnableWindow(m_bAutoExport && !m_bOtherExport);
	GetDlgItem(IDC_SAVEEXPORTSTYLESHEET)->EnableWindow(m_bAutoExport && !m_bOtherExport && m_bUseStylesheetForSaveExport);
	GetDlgItem(IDC_OTHEREXPORTERS)->EnableWindow(m_bAutoExport && m_bOtherExport);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesFile2Page::OnOtherexport() 
{
	UpdateData();	

	GetDlgItem(IDC_USESTYLESHEETFORSAVE)->EnableWindow(m_bAutoExport && !m_bOtherExport);
	GetDlgItem(IDC_SAVEEXPORTSTYLESHEET)->EnableWindow(m_bAutoExport && !m_bOtherExport && m_bUseStylesheetForSaveExport);
	GetDlgItem(IDC_OTHEREXPORTERS)->EnableWindow(m_bAutoExport && m_bOtherExport);

	CPreferencesPageBase::OnControlChange();
}

CString CPreferencesFile2Page::GetSaveExportStylesheet() const 
{ 
	if (m_bUseStylesheetForSaveExport && !m_sSaveExportStylesheet.IsEmpty())
		return FileMisc::GetFullPath(m_sSaveExportStylesheet, FileMisc::GetAppResourceFolder()); 

	// else
	return "";
}

CString CPreferencesFile2Page::GetBackupLocation() const 
{ 
	if (m_bBackupOnSave)
		return FileMisc::GetFullPath(m_sBackupLocation, FileMisc::GetAppFolder());

	// else
	return "";
}
