turn SupportsTheming(STAP_ALLOW_NONCLIENT);
}

BOOL CThemed::IsWebContentThemed()
{
	return SupportsTheming(STAP_ALLOW_WEBCONTENT);
}

// static 
BOOL CThemed::DrawFrameControl(const CWnd* pWnd, CDC* pDC, LPRECT pRect, UINT nType, UINT nState, LPCRECT pClip)
{
	CThemed th;
	
	if (th.SupportsTheming(STAP_ALLOW_CONTROLS) && th.SupportsTheming(STAP_ALLOW_NONCLIENT))
	{
		// determine the appropriate class, part and state
		CString sThClass;
		int nThPart = 0, nThState = 0;
		
		if (!th.GetThemeClassPartState(nType, nState, sThClass, nThPart, nThState))
			return FALSE;
		
		if (!th.Open(pWnd, sThClass))
			return FALSE;
		
		th.DrawParentBackground(pWnd, pDC, (LPRECT)(pClip ? pClip : pRect));
		th.DrawBackground(pDC, nThPart, nThState, pRect, pClip);
		
		return TRUE;
	}
	else
		return pDC->DrawFrameControl(pRect, nType, nState);
}

BOOL CThemed::DrawEdge(const CWnd* pWnd, CDC* pDC, LPRECT pRect, UINT nType, UINT nState, UINT nEdge, UINT nFlags)
{
	CThemed th;
	
	if (th.SupportsTheming(STAP_ALLOW_CONTROLS) && th.SupportsTheming(STAP_ALLOW_NONCLIENT))
	{
		// determine the appropriate class, part and state
		CString sThClass;
		int nThPart = 0, nThState = 0;
		
		if (!th.GetThemeClassPartState(nType, nState, sThClass, nThPart, nThState))
			return FALSE;
		
		if (!th.Open(pWnd, sThClass))
			return FALSE;
		
		th.DrawEdge(pDC, nThPart, nThState, pRect, nEdge, nFlags);
		
		return TRUE;
	}
	else
		return pDC->DrawFrameControl(pRect, nType, nState);
}

BOOL CThemed::DrawBackground(CDC* pDC, int nPart, int nState, const CRect& rect, LPCRECT prClip)
{
	ASSERT (m_hTheme);
	ASSERT_VALID (pDC);
	
	return DrawThemeBackground(*pDC, nPart, nState, rect, prClip);
}

BOOL CTh