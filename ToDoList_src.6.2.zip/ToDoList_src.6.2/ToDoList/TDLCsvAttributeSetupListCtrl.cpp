sColor(COLOR_HIGHLIGHT);
		else
			return ::GetSysColor(COLOR_BTNFACE);
	} 
	else if (bDropHighlighted)
		return ::GetSysColor(COLOR_HIGHLIGHT);

	// else
	COLORREF crBack = GetTextBkColor(); 

	crBack = (crBack != 0xff000000) ? crBack : ::GetSysColor(COLOR_WINDOW);

//	if (m_bAlternateRowColoring && nItem % 2)
//		crBack = BdeTools::Darker(crBack, 0.95f);

	return crBack;
}

int CEnListCtrl::GetImageStyle(BOOL bSelected, BOOL bDropHighlighted, BOOL bWndFocus) const
{
	int nStyle = ILD_TRANSPARENT;

	if (bSelected && bWndFocus)
		nStyle |= ILD_BLEND25;

	else if (bDropHighlighted)
		nStyle |= ILD_BLEND25;
	
	// else
	return nStyle;
}

void CEnListCtrl::EnableHeaderTracking(BOOL bAllow)
{
	ASSERT (m_hWnd);

	if (m_header.m_hWnd == NULL)
		VERIFY(m_header.SubclassDlgItem(0, this));

	m_header.EnableTracking(bAllow);
}

void CEnListCtrl::EnableTooltipCtrl(BOOL bEnable)
{
	ASSERT (m_hWnd);

	if (m_ttCtrl.m_hWnd == NULL)
		m_ttCtrl.Create(this);
	
	m_bTooltipsEnabled = bEnable;
	m_ttCtrl.Activate(bEnable);
}

BOOL CEnListCtrl::SetTooltipCtrlText(CString sText)
{
	ASSERT (m_hWnd);

	if (sText.IsEmpty())
		return FALSE;

	if (m_ttCtrl.m_hWnd == NULL)
		m_ttCtrl.Create(this);
	
	m_ttCtrl.AddTool(this, sText);

	return TRUE;
}

void CEnListCtrl::OnLButtonDown(UINT nFlags, CPoint point)
{
	int nSel;
	BOOL bChangedEditLabels = FALSE;

	// if the list is in report mode AND supports label editing then
	// clicking anywhere on the item when its already selected will
	// edit the label of column one which is not what we want. 
	// so we selectively disable it
	if ((nSel = HitTest(point)) != -1 && m_nCurView == LVS_REPORT)
	{
		if (GetStyle() & LVS_EDITLABELS)
		{
			int nCol0Start, nCol0End;
			GetColumnExtents(0, nCol0Start, nCol0End);

			if (GetImageList(LVSIL_SMALL))
				nCol0Start += 19;

			if (GetImageList(LVSIL_STATE))
				nCol0Start += 19;

			if (point.x < nCol0Start || point.x > nCol0End)
			{
				ModifyStyle(LVS_EDITLABELS, 0);
				bChangedEditLabels = TRUE;
			}
		}
	}


	CListCtrl::OnLButtonDown(nFlags, point);

	if (nSel != -1) // user clicked on an item
	{
		// determine whether a sel change has occured
		// and tell our parent if it has
		NotifySelChange();
	}

	if (bChangedEditLabels)
		ModifyStyle(0, LVS_EDITLABELS);
}

void CEnListCtrl::SetColumnColor(int nCol, COLORREF color)
{
	CColumnData* pData = CreateColumnData(nCol);

	if (pData)
	{
		pData->crText = color;

		if (m_hWnd)
			Invalidate(); // redraw
	}
}

COLORREF CEnListCtrl::GetColumnColor(int nCol) const
{
	const CColumnData* pData = GetColumnData(nCol);

	if (pData)
		return pData->crText;

	// else
	COLORREF crBack = GetTextBkColor();
	return crBack != 0x00E0E0E0 ? crBack : ::GetSysColor(COLOR_WINDOWTEXT);
}

void CEnListCtrl::SetColumnFormat(int nCol, int nFormat)
{
	CColumnData* pData = CreateColumnData(nCol);

	if (pData)
	{
		pData->nFormat = nFormat;

		if (m_hWnd)
			Invalidate(); // redraw
	}
}

int CEnListCtrl::GetColumnFormat(int nCol) const
{
	const CColumnData* pData = GetColumnData(nCol);

	if (pData)
		return pData->nFormat;

	// else return most appropriate
	LV_COLUMN lvc;
	lvc.mask = LVCF_FMT;
		
	if (GetColumn(nCol, &lvc))
	{
		if ((lvc.fmt & LVCFMT_JUSTIFYMASK) == LVCFMT_RIGHT)
			return ES_START;
	}

	// else
	return ES_END;
}

void CEnListCtrl::ShowGrid(BOOL bVert, BOOL bHorz)
{
	m_bVertGrid = bVert;
	m_bHorzGrid = bHorz;

	if (m_hWnd)
		Invalidate(); // redraw
}

void CEnListCtrl::SetView(int nView)
{
	CRect rClient;

	ASSERT (nView == LVS_ICON || nView == LVS_LIST ||
			nView == LVS_SMALLICON || nView == LVS_REPORT);

	ASSERT (m_hWnd);
	
	if (!(nView == LVS_ICON || nView == LVS_LIST ||
		nView == LVS_SMALLICON || nView == LVS_REPORT))
		return;

	// Get the current window style. 
	DWORD dwStyle = GetWindowLong(GetSafeHwnd(), GWL_STYLE); 
 
    // Only set the window style if the view bits have changed. 
    if ((dwStyle & LVS_TYPEMASK) != (DWORD)nView) 
		SetWindowLong(GetSafeHwnd(), GWL_STYLE, (dwStyle & ~LVS_TYPEMASK) | (DWORD)nView); 

	// if we are in report view then we want to be ownerdraw 
	// so we can take advatage of the special drawing
	if (nView == LVS_REPORT)
	{
		// make ownerdraw
		if (!(dwStyle & LVS_OWNERDRAWFIXED))
			ModifyStyle(0, LVS_OWNERDRAWFIXED); 
	}
	// else we want default drawing
	else
	{
		// make non-ownerdraw
		if (dwStyle & LVS_OWNERDRAWFIXED)
			ModifyStyle(LVS_OWNERDRAWFIXED, 0); 
	}

	m_nCurView = nView;
	Invalidate(FALSE);

	// force a resize to ensure that the column headers are correct
	WINDOWPOS wp = { GetSafeHwnd(), NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER };
	PostMessage(WM_WINDOWPOSCHANGED, 0, (LPARAM)&wp); 
}

int CEnListCtrl::GetImageIndex(int nItem, int nSubItem) const
{
	LV_ITEM lvi;

	lvi.mask = LVIF_IMAGE;
	lvi.iItem = nItem;
	lvi.iSubItem = nSubItem;
	
	GetItem(&lvi);

	return lvi.iImage;
}

void CEnListCtrl::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	BOOL bCtrlDown;

	// check if user did a cut, copy, paste or delete and we're not readonly query parent
	// if parent returns TRUE then do action
	bCtrlDown = ((::GetKeyState(VK_CONTROL) & 0x8000) == 0x8000);
	m_nmhdr.hwndFrom = m_hWnd;
	m_nmhdr.idFrom = GetDlgCtrlID();

	switch (nChar)
	{
		// copy = ctrl + 'c'
		case 'C':
		case 'c':
		{
			if (!bCtrlDown)
				return;

			m_nmhdr.code = LVN_COPY;

			if (!IsReadOnly() && !GetParent()->SendMessage(WM_NOTIFY, (WPARAM)GetDlgCtrlID(), (LPARAM)&m_nmhdr))
				Copy();
			break;
		}

		// paste = ctrl + 'v'
		case 'V':
		case 'v':
		{
			if (!bCtrlDown)
				return;

			m_nmhdr.code = LVN_PASTE;

			if (!IsReadOnly() && !GetParent()->SendMessage(WM_NOTIFY, (WPARAM)GetDlgCtrlID(), (LPARAM)&m_nmhdr))
				Paste();
			break;
		}

		// cut = ctrl + 'x'
		case 'X':
		case 'x':
		{
			if (!bCtrlDown)
				return;

			m_nmhdr.code = LVN_CUT;

			if (!IsReadOnly() && !GetParent()->SendMessage(WM_NOTIFY, (WPARAM)GetDlgCtrlID(), (LPARAM)&m_nmhdr))
				Cut();
			break;
		}

		// delete
		case VK_DELETE:
		{	
			m_nmhdr.code = LVN_DELETE;

			if (!IsReadOnly() && !GetParent()->SendMessage(WM_NOTIFY, (WPARAM)GetDlgCtrlID(), (LPARAM)&m_nmhdr))
				Delete();
			break;
		}
	}
	
	// otherwise do default processing 
	CListCtrl::OnKeyUp(nChar, nRepCnt, nFlags);
	UpdateWindow();
	
	// and determine whether a sel change has occured
	// and tell our parent if it has
	if (GetCurSel() != -1)
		NotifySelChange();
}

UINT CEnListCtrl::OnGetDlgCode()
{
	return CListCtrl::OnGetDlgCode();//DLGC_WANTCHARS;
}

void CEnListCtrl::OnKillFocus(CWnd* pNewWnd)
{
	CListCtrl::OnKillFocus(pNewWnd);
}

void CEnListCtrl::SetLastColumnStretchy(BOOL bStretchy)
{
//	ASSERT (m_nCurView == LVS_REPORT);

	m_bLastColStretchy = bStretchy;
	m_bFirstColStretchy = FALSE;

	// invoke a resize to update last column
	if (m_bLastColStretchy && m_nCurView == LVS_REPORT && GetSafeHwnd())
	{
		WINDOWPOS wp = { GetSafeHwnd(), NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER };
		PostMessage(WM_WINDOWPOSCHANGED, 0, (LPARAM)&wp); 
	}
}

void CEnListCtrl::SetFirstColumnStretchy(BOOL bStretchy)
{
//	ASSERT (m_nCurView == LVS_REPORT);

	m_bFirstColStretchy = bStretchy;
	m_bLastColStretchy = FALSE;

	// invoke a resize to update first column
	if (m_bFirstColStretchy && m_nCurView == LVS_REPORT && GetSafeHwnd())
	{
		WINDOWPOS wp = { GetSafeHwnd(), NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER };
		PostMessage(WM_WINDOWPOSCHANGED, 0, (LPARAM)&wp); 
	}
}

void CEnListCtrl::OnTimer(UINT nIDEvent)
{
	CListCtrl::OnTimer(nIDEvent);
}

void CEnListCtrl::OnSize(UINT nType, int cx, int cy)
{
	static BOOL bInOnSize = FALSE;

	if (bInOnSize)
		return;

	bInOnSize = TRUE;

	CRect rClient, rPrev;
//	HD_LAYOUT   hdLayout;
	WINDOWPOS   wpos;

	GetClientRect(rPrev);

	CListCtrl::OnSize(nType, cx, cy);

	// get header state
/*
	if (m_header.GetSafeHwnd())
	{
		GetClientRect(rClient);
		hdLayout.prc = &rClient;
		hdLayout.pwpos = &wpos;
		Header_Layout(GetHeader()->GetSafeHwnd(), &hdLayout);
	}
*/

	// stretch the appropriate columns if in report mode
	if (m_nCurView == LVS_REPORT)
	{
		int nCol, nNumCols, nColStart = 0, nColEnd = 0;
		GetClientRect(rClient);

		// get the start of 