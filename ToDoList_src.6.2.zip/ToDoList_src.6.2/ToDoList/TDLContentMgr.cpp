++)
		SetItemState(nIndex, bSelect ? LVIS_SELECTED : 0, LVIS_SELECTED);

	// if we have the focus then update parent 
	if (GetFocus() == this && bNotifyParent)
		NotifySelChange();
}

void CEnListCtrl::SetItemFocus(int nIndex, BOOL bFocused)
{
//	ASSERT (nIndex >= 0 && nIndex < GetItemCount());
	
	if (!(nIndex >= 0 && nIndex < GetItemCount()))
		return;
	
	// set focus
	SetItemState(nIndex, bFocused ? LVIS_FOCUSED : 0, LVIS_FOCUSED);
}

void CEnListCtrl::SelectAll()
{
	if (GetItemCount())
		SetMulSel(0, GetItemCount() - 1, TRUE);

	// if we have the focus then update parent 
	if (GetFocus() == this)
		NotifySelChange();
}

void CEnListCtrl::ClearAll()
{
	if (GetItemCount())
		SetMulSel(0, GetItemCount() - 1, FALSE);

	// if we have the focus then update parent 
	if (GetFocus() == this)
		NotifySelChange();
}

int CEnListCtrl::SetCurSel(int nIndex, bool bNotifyParent)
{
	ASSERT (nIndex >= -1 && nIndex < GetItemCount());
	
	int nCurSel, nRes;
	UINT nState, nMask;
	CRect rItem;
	
	nState = nMask = LVIS_SELECTED | LVIS_FOCUSED;

	nCurSel = GetFirstSel();

	if (nCurSel != -1)
	{
		SetItemState(nCurSel, 0, nMask);
		Update(nCurSel);
	}
	SetItemState(nIndex, nState, nMask);
	nRes = Update(nIndex);

	// if we have the focus then update parent 
	if (GetFocus() == this && bNotifyParent)
		NotifySelChange();

	return nRes;
}

int CEnListCtrl::GetCountPerPage() const
{
	CRect rList, rItem;

	if (GetItemCount() == 0)
		return 0;

	GetClientRect(&rList);
	GetItemRect(0, &rItem, LVIR_BOUNDS);
	
	ASSERT (!rList.IsRectEmpty() && !rItem.IsRectEmpty());

	return	rList.Height() / rItem.Height();
}

void CEnListCtrl::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	CDC* pDC;
	CRect rText, rItem, rClient, rHeader;
	COLORREF crOldText, crOldBack;
	CSize sizeText;
	LV_COLUMN lvc;
//	CPen* pOldPen;
	CImageList* pImageList;
	CIma