 <xsl:value-of select="@PERSON2" />
					</xsl:if>
					<xsl:if test="@PERSON3">; <xsl:value-of select="@PERSON3" />
					</xsl:if>
					<xsl:if test="@PERSON4">; <xsl:value-of select="@PERSON4" />
					</xsl:if>
					<xsl:if test="@PERSON5">; <xsl:value-of select="@PERSON5" />
					</xsl:if>
					<xsl:if test="@PERSON6">; <xsl:value-of select="@PERSON6" />
					</xsl:if>
					<xsl:if test="@PERSON7">; <xsl:value-of select="@PERSON7" />
					</xsl:if>
					<xsl:if test="@PERSON8">; <xsl:value-of select="@PERSON8" />
					</xsl:if>
					<xsl:if test="@PERSON9">; <xsl:value-of select="@PERSON9" />
					</xsl:if>
					
				</xsl:when>
				<xsl:otherwise>
					<xsl:attribute name="class">to bbasic empty</xsl:attribute>
					<xsl:text>.</xsl:text>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:element>
	</xsl:template>
    
    <!-- 44 - @CATEGORY if exists -->   
    <xsl:template name="get_Category">
        <xsl:element name="td">
            <xsl:choose>
                <xsl:when test="(@CATEGORY)">
                    <xsl:attribute name="class">category bbasic</xsl:attribute>
                    <xsl:value-of select="@CATEGORY"/>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:attribute name="class">category bbasic empty</xsl:attribute>
                    <xsl:text>.</xsl:text>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- 44b - @STATUS if exists -->    
    <xsl:template name="get_Status">
        <xsl:element name="td">
            <xsl:choose>
                <xsl:when test="(@STATUS)">
                    <xsl:attribute name="class">status bbasic</xsl:attribute>
                    <xsl:value-of select="@STATUS"/>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:attribute name="class">status bbasic empty</xsl:attribute>
                    <xsl:text>.</xsl:text>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- 45 - @TITLE as title +  @COMMENTS if exists-->
    <xsl:template name="get_Task_title">
        <xsl:element name="td">
            <xsl:attribute name="class">task bbasic</xsl:attribute>
            <!-- <xsl:call-template name="tab"/> -->
            <xsl:element name="a">
                <xsl:attribute name="href">tdl://<xsl:value-of select="$filename"/>?<xsl:value-of select="@ID"/></xsl:attribute>
                <xsl:if test="@FLAG and $showflagged='bold'">
                    <xsl:attribute name="class">flagged</xsl:attribute>
                </xsl:if>
                <xsl:value-of select="@TITLE"/>
            </xsl:element>
            <xsl:call-template name="get_Task_Ancestors"/>
            <xsl:if test="$showcomments and (@COMMENTS | @FILEREFPATH)">
                <xsl:element name="br"/>
                <!-- <xsl:call-template name="tab"/> -->
                <xsl:element na