ange has occured
		// and tell our parent if it has
		m_nmhdr.hwndFrom = m_hWnd;
		m_nmhdr.idFrom = GetDlgCtrlID();
		m_nmhdr.code = LVN_USERSELCHANGEDBLCLK;
		GetParent()->SendMessage(WM_NOTIFY, (WPARAM)GetDlgCtrlID(), (LPARAM)&m_nmhdr);
	}
}

BOOL CEnListCtrl::SelectDropTarget(int nItem)
{
	int nCurDropHilited;

	// remove current drop selection provided item was not 
	// originally selected
	nCurDropHilited = GetNextItem(-1, LVNI_DROPHILITED);

	if (nCurDropHilited != -1 && nCurDropHilited != nItem)
	{
		SetItemState(nCurDropHilited, 0, LVIS_DROPHILITED);
		RedrawItems(nCurDropHilited, nCurDropHilited);
		UpdateWindow();
	}

	if (nItem < 0 || nItem >= GetItemCount())
		return FALSE;

	// set new drop selection provided hilite has changed and
	// the item isn't already selected
	if ((nCurDropHilited != nItem) && 
		((GetItemState(nItem, LVIS_SELECTED) & LVIS_SELECTED) != LVIS_SELECTED))
	{
		SetItemState(nItem, LVIS_DROPHILITED, LVIS_DROPHILITED);
		RedrawItems(nItem, nItem);
		UpdateWindow();
	}

	return TRUE;
}

void CEnListCtrl::SetItemImage(int nItem, int nImage)
{
	if (nItem < 0 || nItem >= GetItemCount())
		return;

	SetItem(nItem, 0, LVIF_IMAGE, "", nImage, 0, 0, 0L);
}

/*
void CEnListCtrl::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	CPopupMenu menu;
	int nItem;
	CPoint ptClient;

	SetFocus();

	ptClient = point;
	ScreenToClient(&ptClient);
	nItem = HitTest(ptClient);

	// select (even if -1)
	if (nItem == -1 || !IsItemSelected(nItem))
		SetCurSel(nItem);
	// else set the focus to this item
	else
		SetMulSel(nItem, nItem, TRUE); // doesnt notify parent

	// display menu
	if (m_bContextPopupEnabled)
	{
		if (PreparePopupMenu(&m_popupMenu, nItem)) // derived classes provide override
		{
			m_ptPopupPos = point;
			PostMessage(WM_SHOWPOPUPMENU);
		}
	}
}

BOOL CEnListCtrl::PreparePopupMenu(CPopupMenu* pMenu, int nItem)
{
	return pMenu->LoadMenu(IDR_ENLISTCTRL_CONTEXT);
}

*/
BOOL CEnListCtrl::IsItemSelected(int nItem) const
{
	ASSERT (nItem >= 0 && nItem < GetItemCount());

	return (GetItemState(nItem, LVIS_SELECTED) == LVIS_SELECTED);
}

void CEnListCtrl::GetCellRect(int nRow, int nCol, CRect& rCell) const
{
	CRect rItem;
	GetItemRect(nRow, rItem, LVIR_BOUNDS); // item rect in current view

	int nColStart, nColEnd;
	GetColumnExtents(nCol, nColStart, nColEnd); // relative positions of column in client coords

	rCell.SetRect(nColStart, rItem.top, nColEnd, rItem.bottom);
}

void CEnListCtrl::GetCellEditRect(int nRow, int nCol, CRect& rCell) const
{
	GetCellRect(nRow, nCol, rCell);
	rCell.OffsetRect(-2, 0);
}

void CEnListCtrl::OnRButtonDow