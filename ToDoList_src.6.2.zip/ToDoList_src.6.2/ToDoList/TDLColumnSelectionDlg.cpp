// EnListCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "EnListCtrl.h" 
#include "EnHeaderCtrl.h"
#include "dlgunits.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEnListCtrl

IMPLEMENT_DYNAMIC(CEnListCtrl, CListCtrl)

#define IDC_HEADERCTRL 10001
#define WM_SHOWPOPUPMENU (WM_APP+1001)
#define ID_TIMER_HEADERPOS 1
const int MAX_HEADING_SIZE = 100;

CEnListCtrl::CEnListCtrl()
{
	m_bVertGrid = m_bHorzGrid = FALSE;
	m_mapColumnData.RemoveAll();
	m_nCurView = 0;
	m_bLastColStretchy = FALSE;
	m_bFirstColStretchy = FALSE;
	m_nItemHeight = 20;//16;
	m_bReadOnly = FALSE;
	m_nItemDropHilite = -1;
	m_bDropHiliteItemSelected = FALSE;
	m_bContextPopupEnabled = FALSE;
	m_bUserSelChange = FALSE;
	m_bSortingEnabled = TRUE;
	m_nSortColumn = 0;
	m_bSortAscending = TRUE;
	m_bInitColumns = FALSE;
	m_bAlternateRowColoring = FALSE;
}

CEnListCtrl::~CEnListCtrl()
{
	DeleteAllColumnData();
}


BEGIN_MESSAGE_MAP(CEnListCtrl, CListCtrl)
	//{{AFX_MSG_MAP(CEnListCtrl)
	ON_WM_LBUTTONDOWN()
	ON_WM_KEYUP()
	ON_WM_KILLFOCUS()
	ON_WM_SIZE()
	ON_WM_MEASUREITEM_REFLECT()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_RBUTTONDOWN()
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
	ON_WM_GETDLGCODE()
	ON_WM_TIMER()
	ON_NOTIFY_REFLECT(LVN_COLUMNCLICK, OnColumnClick)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEnListCtrl message handlers


void CEnListCtrl::OnPaint() 
{
	// if no items or in report mode draw to back buffer then blt
	if (GetItemCount() && GetView() != LVS_REPORT)
		Default();

	else
	{
		CPaintDC cleanup(this);

		CHeaderCtrl* pHeader = GetHeader();
		CDC& paintdc = *GetDC();

		CDC dc;
		dc.CreateCompatibleDC(&paintdc);
		
		CRect rClient;
		GetClientRect( &rClient );
		
		CBitmap bitmap;
		bitmap.CreateCompatibleBitmap(&paintdc, rClient.right, rClien