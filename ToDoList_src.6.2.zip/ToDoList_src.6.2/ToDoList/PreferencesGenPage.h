           <xsl:attribute name="class">category bbasic empty</xsl:attribute>
                    <xsl:text>.</xsl:text>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- 44b - @STATUS if exists -->    
    <xsl:template name="get_Status">
        <xsl:element name="td">
            <xsl:choose>
                <xsl:when test="(@STATUS)">
                    <xsl:attribute name="class">status bbasic</xsl:attribute>
                    <xsl:value-of select="@STATUS"/>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:attribute name="class">status bbasic empty</xsl:attribute>
                    <xsl:text>.</xsl:text>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:element>
    </xsl:template>

    <!-- 45 - @TITLE as title +  @COMMENTS if exists-->
    <xsl:template name="get_Task_title">
        <xsl:element name="td">
            <xsl:attribute name="class">task bbasic</xsl:attribute>
            <!-- <xsl:call-template name="tab"/> -->
            <xsl:element name="a">
                <xsl:attribute name="href">tdl://<xsl:value-of select="$filename"/>?<xsl:value-of select="@ID"/></xsl:attribute>
                <xsl:if test="@FLAG and $showflagged='bold'">
                    <xsl:attribute name="class">flagged</xsl:attribute>
                </xsl:if>
                <xsl:value-of select="@TITLE"/>
            </xsl:element>
            <xsl:call-template name="get_Task_Ancestors"/>
            <xsl:if test="$showcomments and (@COMMENTS | @FILEREFPATH)">
                <xsl:element name="br"/>
                <!-- <xsl:call-template name="tab"/> -->
                <xsl:element name="div">
                    <xsl:attribute name="class">commentbox</xsl:attribute>
                    <xsl:call-template name="fix-breaks">
                        <xsl:with-param name="text">
                            <xsl:value-of select="@COMMENTS"/>
                        </xsl:with-param>
                    </xsl:call-template>
                    <xsl:if test="@FILEREFPATH">
                        <p>
                            <xsl:element name="a">
                                <xsl:attribute name="href"><xsl:value-of select="@FILEREFPATH"/></xsl:attribute>
                                <xsl:value-of select="@FILEREFPATH"/>
                            </xsl:element>
                        </p>
                    </xsl:if>
                </xsl:element>
            </xsl:if>
        </xsl:element>
    </xsl:template>
    
    <!-- 46 - @ID -->
    <xsl:template name="get_ID">
        <xsl:element name="td">
            <xsl:attribute name="class">bbasic taskid</xsl:attribute>
            <xsl:value-of select="@ID"/>
        </xsl:element>
    </xsl:template>
    
    
    
    <!-- 50 - It puts a space in -->
    <xsl:template name="tab">
        <xsl:if test="count(ancestor::TASK)>0">
            <xsl:for-each select="(ancestor::TASK)">
                <xsl:element name="span">
                    <xsl:attribute name="class">tab</xsl:attribute>
                </xsl:element>
            </xsl:for-each>
        </xsl:if>
    </xsl:template>
    
    
    <!-- 51 - Write Task's Ancesor Path in paren