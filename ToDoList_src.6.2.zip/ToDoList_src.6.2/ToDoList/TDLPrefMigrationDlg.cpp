	if (sItem.CompareNoCase(szItem) == 0)
				return nItem;
		}
	}

	return -1;
}

int Misc::RemoveItems(const CStringArray& aItems, CStringArray& aFrom, BOOL bCaseSensitive)
{
	int nRemoved = 0; // counter
	int nItem = aItems.GetSize();

	while (nItem--)
	{
		int nFind = Find(aFrom, aItems[nItem], bCaseSensitive);

		if (nFind != -1)
		{
			aFrom.RemoveAt(nFind);
			nRemoved++;
		}
	}

	return nRemoved;
}

int Misc::AddUniqueItems(const CStringArray& aItems, CStringArray& aTo, BOOL bCaseSensitive)
{
	int nAdded = 0; // counter
	int nItem = aItems.GetSize();

	while (nItem--)
	{
		if (AddUniqueItem(aItems[nItem], aTo, bCaseSensitive))
			nAdded++;
	}

	return nAdded;
}

BOOL Misc::AddUniqueItem(const CString& sItem, CStringArray& aTo, BOOL bCaseSensitive)
{
	if (sItem.IsEmpty())
		return FALSE;

	int nFind = Find(aTo, sItem, bCaseSensitive);

	if (nFind == -1) // doesn't already exist
	{
		aTo.Add(sItem);
		return TRUE;
	}

	return FALSE; // not added
}

CString Misc::GetAM()
{
	static CString sAM;
	const int BUFLEN = 10;

	if (sAM.IsEmpty()) // init first time only
	{
		GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_S1159, sAM.GetBuffer(BUFLEN), BUFLEN - 1);
		sAM.ReleaseBuffer();
	}

	return sAM;
}

CString Misc::GetPM()
{
	static CString sPM;
	const int BUFLEN = 10;

	if (sPM.IsEmpty()) // init first time only
	{
		GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_S2359, sPM.GetBuffer(BUFLEN), BUFLEN - 1);
		sPM.ReleaseBuffer();
	}

	return sPM;
}

CString Misc::GetTimeFormat(BOOL bIncSeconds)
{
	static CString sFormat;
	const int BUFLEN = 100;

	if (sFormat.IsEmpty()) // init first time only
	{
		GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_STIMEFORMAT, sFormat.GetBuffer(BUFLEN), B