// CMiniCalendarCtrl
// Author:	Matt Gullett
//			gullettm@yahoo.com
// Copyright (c) 2001
//
// This is a user-interface componenet similar to the MS outlook mini
// calendar control.  (The one used in date picker control and the
// appointment (day view)).
//
// You may freely use this source code in personal, freeware, shareware
// or commercial applications provided that 1) my name is recognized in the
// code and if this code represents a substantial portion of the application
// that my name be included in the credits for the application (about box, etc)
//
// Use this code at your own risk.  This code is provided AS-IS.  No warranty
// is granted as to the correctness, usefulness or value of this code.
//
// Special thanks to Keith Rule for the CMemDC class
// http://www.codeproject.com/KB/GDI/flickerfree.aspx
//
// Original file written by Matt Gullett (http://www.codeproject.com/KB/miscctrl/minicalendar.aspx)
// Rewritten for the ToDoList (http://www.codeproject.com/KB/applications/todolist2.aspx)
// Design and latest version - http://www.codeproject.com/KB/applications/TDL_Calendar.aspx
// by demon.code.monkey@googlemail.com
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CalendarData.h"
#include "CalendarDefines.h"
#include "CalendarUtils.h"
#include "MiniCalendarCtrl.h"
#include "MemDC.h"
#include "MiniCalendarMonthPicker.h"
#include "locale.h"
#include "..\..\CalendarExt\CalendarFrameWnd.h"
#include "..\..\Shared\DateHelper.h"
#include "..\..\Shared\GraphicsMisc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//fonts
#define MINICAL_FONT_NAME						"Tahoma"
#define MINICAL_FONT_SIZE						8

#define MINICAL_NUM_CELLS						42

#define MINICAL_HEADER_TIMER_ID					1001
#define MINICAL_HEADER_TIMER_INTERVAL			30

#define MINICALENDAR_HEIGHT						133

#define MINICAL_COLOUR_HEADERFONT				RGB(40,40,255)
#define MINICAL_COLOUR_DAY						RGB(0,0,0)
#define MINICAL_COLOUR_DAY_DIFFERENTMONTH		RGB(130,130,130)
#define MINICAL_COLOUR_HIDDEN_WEEKEND_DAY		RGB(190,190,190)
#define MINICAL_COLOUR_IMPORTANTDAY_BACKGROUND	RGB(255,255,100)


/////////////////////////////////////////////////////////////////////////////
// CMiniCalendarCtrl
CMiniCalendarCtrl::CMiniCalendarCtrl()
:	m_bSizeComputed(FALSE),
	m_bTracking(FALSE),
	m_bHeaderTracking(FALSE),
	m_pCalendarData(NULL),
	m_pFrameWnd(NULL),
	m_pHeaderList(NULL),
	m_pHeaderCell(NULL),
	m_parCells(NULL),
	m_pFont(NULL),
	m_pFontBold(NULL),
	m_iHeaderTimerID(0),
	m_iRows(0),
	m_iFirstDayOfWeek(0),
	m_iHeaderHeight(0),
	m_iIndividualDayWidth(0),
	m_iDaysOfWeekHeight(0),
	m_iDaysHeight(0),
	m_iCurrentMonth(0),
	m_iCurrentYear(0),
	m_cBackColor(0)
{
	m_cBackColor = ::GetSysColor(COLOR_WINDOW);

	m_szMonthSize = CSize(0,0);

	m_rectScrollLeft.SetRectEmpty();
	m_rectScrollRight.SetRectEmpty();

	CCalendarUtils::GetToday(m_dateSelected);

	m_iCurrentMonth = m_dateSelected.GetMonth();
	m_iCurrentYear = m_dateSelected.GetYear();
	ASSERT((m_iCurrentYear >= 100) && (m_iCurrentYear <= 9999)); //From MSDN: The COleDateTime class handles
	ASSERT((m_iCurrentMonth >= 1) && (m_iCurrentMonth <= 12));	 //dates from 1 January 100 to 31 December 9999.

	SetRows(1);

	// set month names
	for (int i = 0; i < 12; i++)
	{
		CString strMonthName = CDateHelper::GetMonth(i+1, FALSE);
		m_arrMonthNames[i] = strMonthName;
	}

	// set days of week names
	SetFirstDayOfWeek(CDateHelper::FirstDayOfWeek());

	m_pFont = new CFont;
	GraphicsMisc::CreateFont(*m_pFont, MINICAL_FONT_NAME, MINICAL_FONT_SIZE);

	m_pFontBold = new CFont;
	GraphicsMisc::CreateFont(*m_pFontBold, MINICAL_FONT_NAME, MINICAL_FONT_SIZE, MFS_BOLD);
}

CMiniCalendarCtrl::~CMiniCalendarCtrl()
{
	ClearHotSpots();

	if (m_parCells)
		delete[] m_parCells;

	if (m_pHeaderList)
	{
		m_pHeaderList->DestroyWindow();
		delete m_pHeaderList;
	}

	if (m_iHeaderTimerID != 0)
		KillTimer(m_iHeaderTimerID);

	m_pFont->DeleteObject();
	m_pFontBold->DeleteObject();
	delete m_pFont;
	delete m_pFontBold;
}

void CMiniCalendarCtrl::Initialize(CCalendarFrameWnd* _pFrameWnd,
								   CCalendarData* _pCalendarData)
{
	m_pCalendarData = _pCalendarData;
	m_pFrameWnd = _pFrameWnd;
}


BEGIN_MESSAGE_MAP(CMiniCalendarCtrl, CWnd)
	//{{AFX_MSG_MAP(CMiniCalendarCtrl)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_DEVMODECHANGE()
	ON_WM_FONTCHANGE()
	ON_WM_PALETTECHANGED()
	ON_WM_SETTINGCHANGE()
	ON_WM_TIMECHANGE()
	ON_WM_SYSCOLORCHANGE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_MOUSEMOVE()
	ON_WM_MOUSEWHEEL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CMiniCalendarCtrl::GetSelectedDate(COleDateTime& _date) const
{
	_date = m_dateSelected;
}

CString CMiniCalendarCtrl::GetMonthName(int _iMonth) const
{
	if (_iMonth > 0 && _iMonth <= 12)
		return m_arrMonthNames[_iMonth-1];

	ASSERT(FALSE);
	return "";
}

CFont* CMiniCalendarCtrl::GetDaysFont()
{
	return m_pFont;
}

void CMiniCalendarCtrl::Repopulate()
{
	TasklistUpdated();
}

//returns TRUE if the new date set is different from the previous one
BOOL CMiniCalendarCtrl::SelectDate(const COleDateTime& _date) 
{
	BOOL bReturn = FALSE;
	if (_date.GetStatus() == COleDateTime::valid)
	{
		if (m_dateSelected != _date)
		{
			bReturn = TRUE;
			m_dateSelected = _date;
		}
	}
	else
	{
		m_dateSelected.SetStatus(COleDateTime::invalid);
	}

	if (bReturn)
	{
		Invalidate(TRUE);
	}

	if (!IsDateVisible(m_dateSelected))
	{
		m_iCurrentYear = m_dateSelected.GetYear();
		m_iCurrentMonth = m_dateSelected.GetMonth();
		RedrawWindow();
	}

	return bReturn;
}

void CMiniCalendarCtrl::TasklistUpdated()
{
	//just refresh the data in the view
	Invalidate();
}

BOOL CMiniCalendarCtrl::PreTranslateMessage(MSG* pMsg)
{
	if (m_bHeaderTracking && m_pHeaderList)
		m_pHeaderList->ForwardMessage(pMsg);

	return CWnd::PreTranslateMessage(pMsg);
}

BOOL CMiniCalendarCtrl::IsToday(const COleDateTime& _date) const
{
	BOOL bReturn = FALSE;

	COleDateTime dtToday;
	CCalendarUtils::GetToday(dtToday);

	if (_date == dtToday)
	{
		bReturn = TRUE;
	}

	return bReturn;
}

BOOL CMiniCalendarCtrl::IsDateSelected(const COleDateTime& _date) const
{
	BOOL bReturn = FALSE;

	if (m_dateSelected.GetStatus() == COleDateTime::valid)
	{
		if (_date == m_dateSelected)
		{
			bReturn = TRUE;
		}
	}

	return bReturn;
}

BOOL CMiniCalendarCtrl::IsDateVisible(const COleDateTime& _date) const
{
	for (int iRow = 0; iRow < m_iRows; iRow++)
	{
		for (int iDay = 0; iDay < MINICAL_NUM_CELLS; iDay++)
		{
			if (_date == m_parCells[iRow].GetHotSpot(iDay)->m_date)
			{
				return TRUE;
			}
		}
	}
	return FALSE;
}

//1st day = 1-sun, return true for 1-sun and 7-sat
//1st day = 2-mon, return true for 7-sun and 6-sat
//1st day = 3-tue, return true for 6-sun and 5-sat
//etc
BOOL CMiniCalendarCtrl::IsWeekendDay(int _iDayOfWeek) const
{
	int nSat = 8 - m_iFirstDayOfWeek;
	int nSun = nSat + 1;
	if (nSun > 7)
	{
		nSun = 1;
	}

	if ((_iDayOfWe