 want
		CRect rItem;

		GetItemRect(0, rItem, LVIR_BOUNDS); // item rect in current view
		nColEnd = nColStart = rItem.left - 2;

		for (nColItem = 0; nColItem <= nCol; nColItem++)
		{
			// calc col end in client coordinates
			nColStart = nColEnd;
			nColEnd += GetColumnWidth(nColItem);
		}

		return;
	}

	// nCol invalid
	nColStart = -1;
	nColEnd = -1;
}

void CEnListCtrl::OnColumnClick(NMHDR* pNMHDR, LPARAM* /*lParam*/)
{
	NM_LISTVIEW* pNMLV = (NM_LISTVIEW*)pNMHDR;

	if (m_bSortingEnabled)
		SetSortColumn(pNMLV->iSubItem);
}

void CEnListCtrl::SetSortColumn(int nColumn, BOOL bResort)
{
	if (!m_bSortingEnabled)
		return;

	if (nColumn != m_nSortColumn)
	{
		m_nSortColumn = nColumn;
		m_bSortAscending = TRUE;
	}
	else
		m_bSortAscending = !m_bSortAscending;

	if (bResort)
		Sort();
}

void CEnListCtrl::Sort()
{
	// rebuild sort map
	BuildSortMap(m_nSortColumn);

	// do sort
	SortItems(CompareProc, (LPARAM)this);

	// cleanup
	m_mapSortStrings.RemoveAll();
}

int CALLBACK CEnListCtrl::CompareProc(LPARAM lParam1, LPARAM lParam2, LPARAM lParam)
{
	CEnListCtrl* pListCtrl;
	int nResult;

	pListCtrl = (CEnListCtrl*)lParam;
	ASSERT (pListCtrl->IsKindOf(RUNTIME_CLASS(CEnListCtrl)));

	nResult = pListCtrl->CompareItems(lParam1, lParam2, pListCtrl->m_nSortColumn);

	if (!pListCtrl->m_bSortAscending)
		nResult = -nResult;

	return nResult;
}

void CEnListCtrl::BuildSortMap(int nCol)
{
	// because we can't reliably get back from the itemdata to the item index
	// during a sort, we map the itemdata of each item index directly to
	// the column string
	m_mapSortStrings.RemoveAll();
	int nNumItems = GetItemCount();

	while (nNumItems--)
		m_mapSortStrings.SetAt(GetItemData(nNumItems), GetItemText(nNumItems, nCol));
}

int CEnListCtrl::CompareItems(DWORD dwItemData1, DWORD dwItemData2, int /*nSortColumn*/)
{
	// -1 if dwItemData1 should go BEFORE dwItemData2
	//  1 if dwItemData1 should go AFTER dwItemData2
	//  0 if it doesn't matter

	// default comparison just compares text
	CString sItem1, sItem2;

	m_mapSortStrings.Lookup(dwItemData1, sItem1); // this is quicker than helper method
	m_mapSortStrings.Lookup(dwItemData2, sItem2);

	// empty items always appear AFTER others
	if (sItem1.IsEmpty())
		return m_bSortAscending ? 1 : -1;

	else if (sItem2.IsEmpty())
		return m_bSortAscending ? -1 : 1;

	// else
	return sItem1.CompareNoCase(sItem2);
}

CString CEnListCtrl::GetSortText(DWORD dwItemData) const // this is for derived classes
{
	CString sText;

	m_mapSortStrings.Lookup(dwItemData, sText);

	return sText;
}

BOOL CEnListCtrl::SetColumnText(int nCol, LPCTSTR szText)
{
	LV_COLUMN lvc;
	ZeroMemory(&lvc, sizeof(lvc));

	lvc.mask = LVCF_TEXT;
	lvc.pszText = (LPSTR)(LPTSTR)szText;

	return SetColumn(nCol, &lvc);
}

void CEnListCtrl::OnDestroy() 
{
	CListCtrl::OnDestroy();
	
	m_bInitColumns = FALSE;
}

/*
void CEnListCtrl::Print(CDC* pDC, PRINT_ATTRIBUTES* pPrintSettings, int nNumCols, UINT* pColumns, UINT* pColWidths)
{
	int nRes;
	DOCINFO di;
	CFont font;
	CFont* pOldFont;
	TEXTMETRIC tm;
	int nIndexItem, nPage, nLine, nCopy, nPrintedLines;
	int nLineHeight;
	int nNumPages, nNumLinesPage;
	CPoint ptPrint;
	CString sPrint, sMessage;
	int nEndLine;
	CCancelDlg dialogCancel;
	int nNumCopies;
	BOOL bCollate;
	BOOL bSelection;
	int nStartLine, nStartItem;
	int nPrintFlags;
	int nLinesToPrint;
	CSize sizePrint, sElement;
	CRect rText;
	BOOL bDCDelete = FALSE;

	ASSERT (!nNumCols || pColumns || (pColWidths && nNumCols == GetColumnCount()));

	if( pDC == NULL)
	{

		// set print flags
		nPrintFlags = PD_NOPAGENUMS | PD_HIDEPRINTTOFILE | PD_NONETWORKBUTTON;

		//If no rows selected then disable the selection on the dlg
		if ( GetSelectedCount() == 0)
			nPrintFlags |= PD_NOSELECTION;
		else
			nPrintFlags |= PD_SELECTION; 

		// show dialog
		CPrintDialog dialogPrint(FALSE, nPrintFlags);

		nRes = dialogPrint.DoModal();

		if (nRes != IDOK)
			return;

		// get printer device context
		pDC = CDC::FromHandle(dialogPrint.GetPrinterDC());

		if (!pDC)
		{
			ASSERT (0);
			return;
		}
		else
			bDCDelete = TRUE;

		// get number of required copies and collation and Selection
		nNumCopies = dialogPrint.m_pd.nCopies;
		bCollate = dialogPrint.m_pd.Flags & PD_COLLATE;
		bSelection = dialogPrint.PrintSelection();
		pDC->m_bPrinting = TRUE;


		// this is very important
		::GlobalFree(dialogPrint.m_pd.hDevMode);
		::GlobalFree(dialogPrint.m_pd.hDevNames);
	}
	else
	{
		ASSERT(pPrintSettings!=NULL);

		nNumCopies = pPrintSettings->nNumCopies;
		bCollate = pPrintSettings->bCollate;
		bSelection = pPrintSettings->bSelection;
	}

	// create 8 point Arial font to be used for printing
	font.CreatePointFont(80, "Arial", pDC);

	// create cancel dialog
	dialogCancel.Create(this);
	dialogCancel.SetWindowText("Printing");
	dialogCancel.CenterWindow();
	dialogCancel.SetFirstTextLine("Printing...");
	dialogCancel.Update();

	AfxGetMainWnd()->EnableWindow(FALSE); // why?

	// get printable size in mm
	sizePrint.cx = pDC->GetDeviceCaps(HORZRES);
	sizePrint.cy = pDC->GetDeviceCaps(VERTRES);

	//Trim Print area to within Margins
	sizePrint.cx -= 2 * PRINTING_MARGIN;
	sizePrint.cy -= 2 * PRINTING_MARGIN;
	sizePrint.cy -=	HEADER_SIZE;
	sizePrint.cy -= FOOTER_SIZE;

	//Set the print region
	CRect rPrintRng(PRINTING_MARGIN, PRINTING_MARGIN, 
			sizePrint.cx + PRINTING_MARGIN,sizePrint.cy + PRINTING_MARGIN);

	CRgn rgnClip;
	rgnClip.CreateRectRgnIndirect(rPrintRng);
//	pDC->SelectClipRgn(&rgnClip);
	rgnClip.DeleteObject();

	// calculate line height and various page aspects
	pOldFont = pDC->SelectObject(&font);
	pDC->GetTextMetrics(&tm);
	pDC->SetTextAlign(TA_LEFT | TA_TOP);

	nLineHeight = tm.tmHeight + tm.tmExternalLeading;

	if(bSelection)
		//selected text only
		nLinesToPrint = GetSelectedCount();
	else							
		//All the text
		nLinesToPrint = GetItemCount();

	nNumLinesPage = (sizePrint.cy - (2 * nLineHeight)) / nLineHeight;
	nNumPages = nLinesToPrint / nNumLinesPage;

	if (nLinesToPrint % nNumLinesPage)
		nNumPages++;

	// start document
	CString sAppName = AfxGetAppName();
	// remove any words in parenthesis
	int nFind = sAppName.Find('(');

	if (nFind != -1)
		sAppName = sAppName.Left(nFind - 1);

	di.cbSize = sizeof(DOCINFO);
	di.lpszDocName = (sAppName += " - Message List");
	di.lpszOutput = NULL;
	di.fwType = 0;
	nRes = pDC->StartDoc(&di);

	int nNumCollationCopies,nColCopy;

	// printing WITH collation ----------------------------------
	if (bCollate)
	{
		nNumCollationCopies = nNumCopies;
		nNumCopies = 1;
	}
	// printing WITHOUT collation------------------------------
	else
		nNumCollationCopies = 1;
	
	//Calculate relative width of columns
	LV_COLUMN lvColumn;
	char strColumnBuffer[MAX_HEADING_SIZE]; 
	int nListWidth = 0,nColCount=0;
				
	lvColumn.mask = LVCF_TEXT;
	lvColumn.pszText = (char*)&strColumnBuffer;
	lvColumn.cchTextMax = MAX_HEADING_SIZE;

	while( GetColumn(nNumCols && pColumns ? pColumns[nColCount] : nColCount , &lvColumn ) && (nNumCols==0 || nColCount < nNumCols) )
	{
		if (!pColWidths)
			nListWidth += GetColumnWidth(  nNumCols ? pColumns[nColCount] : nColCount);
		else
			nListWidth += pColWidths[nColCount];
		
		nColCount++;
	}
				
	ASSERT(nListWidth>0);
	double dRelWidth =  double(sizePrint.cx) / nListWidth;

	for (nColCopy = 0; nColCopy < nNumCollationCopies && !dialogCancel.Cancelled(); nColCopy++)
	{
		nStartItem =  bSelection ? 	GetFirstSel() : 0;
		nStartLine = 0;
		nEndLine = nNumLinesPage;
	
		for (nPage = 0; nPage < nNumPages && !dialogCancel.Cancelled(); nPage++)
		{
			// update cancel dialog box
			sMessage.Format("Printing page %d", nPage + 1);
			dialogCancel.SetFirstTextLine(sMessage);

			for (nCopy = 0; nCopy < nNumCopies && !dialogCancel.Cancelled(); nCopy++)
			{
				// update cancel dialog box
				sMessage.Format("Copy %d", nCopy + 1);
				dialogCancel.SetSecondTextLine(sMessage);

				nIndexItem = nStartItem;
				nLine = nPrintedLines = nStartLine;

				nRes = pDC->StartPage();
				pDC->SelectObject(&font);
				ptPrint.y = PRINTING_MARGIN + HEADER_SIZE;

				CString strHeading;
				GetPrintHeadingText(strHeading);

				// Print list headings
				for (int nPos = PRINTING_MARGIN,nSubItem = 0; GetColumn( nNumCols && pColumns ? pColumns[nSubItem] : nSubItem , &lvColumn ) && (nNumCols==0 || nSubItem < nNumCols) ;  nSubItem++) // ignore description
				{
					int nColWidth = 0;
					
					if (!pColWidths)
						nColWidth = GetColumnWidth(  nNumCols ? pColumns[nSubItem] : nSubItem);
					else
						nColWidth = pColWidths[nSubItem];

					nColWidth = int(  dRelWidth * nColWidth );

					rText.SetRect(nPos, ptPrint.y, nColWidth + nPos, ptPrint.y + nLineHeight);
					pDC->ExtTextOut(nPos, ptPrint.y, ETO_CLIPPED, rText, lvColumn.pszText  , NULL);

					nPos += nColWidth;
				}
				ptPrint.y += 2 * nLineHeight;

				//Now Print the List
				while (nLine < nEndLine && nPrintedLines < nLinesToPrint &&	!dialogCancel.Cancelled())
				{
					// do the print 
					for (int nPos = PRINTING_MARGIN,nSubItem = 0; GetColumn( nNumCols && pColumns ? pColumns[nSubItem] : nSubItem , &lvColumn ) && (nNumCols==0 || nSubItem < nNumCols); nSubItem++) // ignore description
					{
						// Calculate the Column relative position and size
						int nColWidth = 0;
						
						if (!pColWidths)
							nColWidth = GetColumnWidth(  nNumCols ? pColumns[nSubItem] : nSubItem);
						else
							nColWidth = pColWidths[nSubItem];

						nColWidth = int(  dRelWidth * nColWidth );

						//Create the rect and Print to DC
						CString sItem = GetItemText(nIndexItem, nNumCols && pColumns ? pColumns[nSubItem] : nSubItem);
						rText.SetRect(nPos, ptPrint.y, nColWidth + nPos, ptPrint.y + nLineHeight);
						pDC->ExtTextOut(nPos, ptPrint.y, ETO_CLIPPED, rText, sItem, NULL);
			
						//increment position
						nPos += nColWidth;
					}

#ifdef _DEBUG
					CString sItem = GetItemText(nIndexItem, 0);
#endif
					nLine++;nPrintedLines++;
					bSelection ? nIndexItem = GetNextSel(nIndexItem): nIndexItem++;
					ptPrint.y += nLineHeight;
				}

				BdeTools::PrintHeader(pDC, strHeading , nPage + 1 );
				BdeTools::PrintFooter(pDC, nPage+1, nNumPages);

				pDC->EndPage();
			}

			nStartLine = nEndLine;
			nStartItem = nIndexItem;
			nEndLine += nNumLinesPage;
		}
	}

	// abort print job if user clicked cancel
	if (!dialogCancel.Cancelled())
		pDC->EndDoc();
	else
		pDC->AbortDoc();

	// restore device context
	pDC->SelectObject(pOldFont);

	AfxGetMainWnd()->EnableWindow(TRUE);
	SetFocus();

	// this is very important
	font.DeleteObject();

	if(bDCDelete)
		pDC->DeleteDC();
}
*/


BOOL CEnListCtrl::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	
	return CListCtrl::PreCreateWindow(cs);
}

int C