cted, bDropHighlighted, bListFocused);

		// draw item images if required
		int nImageWidth = 0;

		// make sure there is enough space
		lvc.mask = LVCF_WIDTH | LVCF_FMT;
		int nCol = 0;
		BOOL bRes = GetColumn(nCol, &lvc);
		
		// must paint the background of column 0 before the icons
		if (bRes && (pStateList || pImageList))
			pDC->ExtTextOut(0, rItem.top, ETO_CLIPPED | ETO_OPAQUE, CRect(0, rItem.top, lvc.cx, rItem.bottom), "", NULL);

		// state
		if (pStateList && bRes)
		{
			int nState = (GetItemState(nItem, LVIS_STATEIMAGEMASK) & LVIS_STATEIMAGEMASK);
			nState = nState >> 12;

			if (lvc.cx > sizeState.