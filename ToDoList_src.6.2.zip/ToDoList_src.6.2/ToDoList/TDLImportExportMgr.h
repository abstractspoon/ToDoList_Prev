LPDRAWITEMSTRUCT)lp))
			return 0L;
		break;
		
	case WM_MEASUREITEM:
		if (OnMeasureItem(wp, (LPMEASUREITEMSTRUCT)lp))
			return 0L;
		break;
	}
	
	return CSubclassWnd::Default();
}

BOOL CMenuIconMgr::OnDrawItem(int /*nIDCtl*/, LPDRAWITEMSTRUCT lpdis)
{
    if (lpdis == NULL || lpdis->CtlType != ODT_MENU)
        return FALSE; // not for a menu
	
    HICON hIcon = LoadItemImage(lpdis->itemID);
	
    if (hIcon)
    {
        ICONINFO iconinfo;
        GetIconInfo(hIcon, &iconinfo);
		
        BITMAP bitmap;
        GetObject(iconinfo.hbmColor, sizeof(bitmap), &bitmap);
		
        ::DrawIconEx(lpdis->hDC, lpdis->rcItem.left, lpdis->rcItem.top, hIcon, 
					bitmap.bmWidth, bitmap.bmHeight, 0, NULL, DI_IMAGE | DI_MASK);
	
		// cleanup
		::DeleteObject(iconinfo.hbmColor);
		::DeleteObject(iconinfo.hbmMask);

		return TRUE;
    }
	
	return FALSE;
}

void CMenuIconMgr::OnInitMenuPopup(CMenu* pMenu)
{
	ASSERT (pMenu);

    MENUINFO mnfo;
    mnfo.cbSize = sizeof(mnfo);
    mnfo.fMask = MIM_STYLE;
    mnfo.dwStyle = MNS_CHECKORBMP | MNS_AUTODISMISS;
	::SetMenuInfo(pMenu->GetSafeHmenu(), &mnfo);
	
    MENUITEMINFO minfo;
    minfo.cbSize = sizeof(minfo);
	
    for (UINT pos=0; pos<pMenu->GetMenuItemCount(); pos++)
    {
        minfo.fMask = MIIM_FTYPE | MIIM_ID;
        pMenu->GetMenuItemInfo(pos, &minfo, TRUE);
		
        CString sItem;
        pMenu->GetMenuString(pos, sItem, MF_BYPOSITION);
		
        HICON hIcon = LoadItemImage(minfo.wID);
		
        if (hIcon && !(minfo.fType & MFT_OWNERDRAW))
        {
            minfo.fMask = MIIM_BITMAP | MIIM_DATA;
            minfo.hbmpItem = HBMMENU_CALLBACK;
			
			::SetMenuItemInfo(pMenu->GetSafeHmenu(), pos, TRUE,