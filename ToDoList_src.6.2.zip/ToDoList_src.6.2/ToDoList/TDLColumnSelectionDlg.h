VIR_BOUNDS))
	{
		if ((rItem.top % rItem.Height()) != 0)
			rItem.top -= rItem.Height();
	}
	
	dwTopLeft = MAKELONG(rItem.left, rItem.top - 10);
	EGetRegKey().Write("TopLeft", dwTopLeft);

	// sort state
	EGetRegKey().Write("SortColumn", (DWORD)GetSortColumn());
	EGetRegKey().Write("SortAscending", (DWORD)GetSortAscending());

	return TRUE;
}

BOOL CEnListCtrl::ERegRestoreState(CRegKey& regKey)
{
	int nNumCols, nCol, nWidth, nView = LVS_REPORT, nSortColumn = 0;
	BOOL bSortAscending = TRUE;
	CString sColKey;
	CPoint ptTopLeft;
	DWORD dwTopLeft;

	if (!ERegistry::ERegRestoreState(regKey))
		return FALSE;

	SetRedraw(FALSE);

	// restore column widths
	nNumCols = GetColumnCount();

	for (nCol = 0; nCol < nNumCols; nCol++)
	{
		nWidth = 0;
		sColKey.Format("ColumnWidth%d", nCol);
		EGetRegKey().Read(sColKey, (DWORD&)nWidth);

		if (nWidth > 0)
			SetColumnWidth(nCol, nWidth);
	}

	// restore view
	EGetRegKey().Read("View", (DWORD&)nView);
	SetView(nView);

	// sort state
	EGetRegKey().Read("SortColumn", (DWORD&)nSortColumn);
	EGetRegKey().Read("SortAscending", (DWORD&)bSortAscending);
	SetSortColumn(nSortColumn, FALSE);
	SetSortAscending(bSortAscending);
	Sort();

	// restore scrolled pos
	EGetRegKey().Read("TopLeft", dwTopLeft);
	ptTopLeft = CPoint(dwTopLeft);
	Scroll(CSize(0, max(0, -ptTopLeft.y)));

	SetRedraw(TRUE);
	Invalidate();

	return TRUE;
}

*/
void CEnListCtrl::DeleteAllColumnData()
{
	int nCol;
	CColumnData* pData;
	POSITION pos = m_mapColumnData.GetStartPosition();

	while (pos)
	{
		m_mapColumnData.GetNextAssoc(pos, nCol, pData);
		delete pData;
	}
}

CColumnData* CEnListCtrl::CreateColumnData(int