// maskedit.cpp : implementation file
//

#include "stdafx.h"
#include "maskedit.h"
#include "winclasses.h"
#include "misc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMaskEdit

CMaskEdit::CMaskEdit(LPCTSTR szMask, DWORD dwFlags) : m_sMask(szMask), m_dwFlags(dwFlags)
{
	if (dwFlags & ME_LOCALIZEDECIMAL)
	{
		if (m_sMask.Find('.') != -1)
			m_sMask += Misc::GetDecimalSeparator();
	}
}

CMaskEdit::~CMaskEdit()
{
}

BEGIN_MESSAGE_MAP(CMaskEdit, CEdit)
	//{{AFX_MSG_MAP(CMaskEdit)
	ON_WM_CHAR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMaskEdit message handlers

void CMaskEdit::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	switch (nChar)
	{
	case VK_BACK:
		break;
/*
	// Ctrl+Backspace does not work in standard edit controls
	case 0x7F:
		if (GetKeyState(VK_CONTROL) & 0x8000)
		{
			// delete word to left of selection start
			int nSelStart, nSelEnd;
			GetSel(nSelStart, nSelEnd);

			if (nSelStart > 0)
			{
				int nWordStart = SendMessage(EM_FINDWORDBREAK, WB_MOVEWORDLEFT, nSelStart);

				if (nWordStart >= 0 && nWordStart < nSelStart)
				{
					SetSel(nWordStart, nSelStart);
					ReplaceSel("", TRUE);
					return;
				}
			}
		}
		break;
*/

	// something wierd going on with edit control accelerators
	case 3:   // c
	case 22:  // v
	case 24:  // x
		if (CWinClasses::IsEditControl(*this))
		{
			ASSERT (GetKeyState(VK_CONTROL) & 0x8000);
			break;
		}
		// else drop thru
		
	case 'c':
	case 'C':
	case 'v':
	case 'V':
	case 'x':
	case 'X':
		if (GetKeyState(VK_CONTROL) & 0x8000)
			break;
		// else drop thru
		
	default:
		if (!m_sMask.IsEmpty())
		{
			if ((m_dwFlags & ME_EXCLUDE) && m_sMask.Find((char)nChar) != -1)
				return;

			else if (!(m_dwFlags & ME_EXCLUDE) && m_sMask.Find((char)nChar) == -1)
				return;
		}
		break;
	}

	CEdit::OnChar(nChar, nRepCnt, nFlags);
}

void CMaskEdit::SetMask(LPCTSTR szMask, DWORD dwFlags) 
{ 
	m_sMask = szMask; 
	m_dwFlags = dwFlags; 

	if (dwFlags & ME_LOCALIZEDECIMAL)
	{
		if (m_sMask.Find('.') != -1)
			m_sMask += Misc::GetDecimalSeparator();
	}
}


                                                                                                                                                                                                         );
		nIndex		+= 3;
		m_nEDataLen	+= 4;
	}

	if(nBufLen > nIndex)
	{
		Raw.Clear();
		Raw.nSize = (BYTE) (nBufLen - nIndex);
		::CopyMemory(&Raw, m_pDBuffer + nIndex, nBufLen - nIndex);
		_EncodeToBuffer(Raw, m_pEBuffer + m_nEDataLen);
		m_nEDataLen += 4;
	}
}

void Base64Coder::Encode(LPCTSTR szMessage)
{
	if(szMessage != NULL)
		Base64Coder::Encode((const PBYTE)szMessage, strlen(szMessage));
}

void Base64Coder::Decode(const PBYTE pBuffer, DWORD dwBufLen)
{
	if(!Base64Coder::m_Init)
		_Init();

	// trim off padding
//	while (pBuffer[dwBufLen - 1] == '=')
//		dwBufLen--;

	SetEncodeBuffer(pBuffer, dwBufLen);

	AllocDecode(dwBufLen);

	TempBucket			Raw;

	DWORD		nIndex = 0;

	while((nIndex + 4) <= m_nEDataLen)
	{
		Raw.Clear();
		Raw.nData[0] = Base64Coder::m_DecodeTable[m_pEBuffer[nIndex]];
		Raw.nData[1] = Base64Coder::m_DecodeTable[m_pEBuffer[nIndex + 1]];
		Raw.nData[2] = Base64Coder::m_DecodeTable[m_pEBuffer[nIndex + 2]];
		Raw.nData[3] = Base64Coder::m_DecodeTable[m_pEBuffer[nIndex + 3]];

		if(Raw.nData[2] == 255)
			Raw.nData[2] = 0;
		if(Raw.nData[3] == 255)
			Raw.nData[3] = 0;
		
		Raw.nSize = 4;
		_DecodeToBuffer(Raw, m_pDBuffer + m_nDDataLen);
		nIndex += 4;
		m_nDDataLen += 3;
	}
	
   // If nIndex < m_nEDataLen, then we got a decode message without padding.
   // We may want to throw some kind of warning here, but we are still required
   // to handle the decoding as if it was properly padded.
	if(nIndex < m_nEDataLen)
	{
		Raw.Clear();#if !defined(AFX_MASKEDIT_H__03CD6C84_2D70_4E44_9E7E_5673B6F6F97E__INCLUDED_)
#define AFX_MASKEDIT_H__03CD6C84_2D70_4E44_9E7E_5673B6F6F97E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// maskedit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMaskEdit window

enum
{
	ME_EXCLUDE			= 0x01,
	ME_LOCALIZEDECIMAL	= 0x02,
};

class CMaskEdit : public CEdit
{
// Construction
public:
	CMaskEdit(LPCTSTR szMask = NULL, DWORD dwFlags = 0);

	void SetMask(LPCTSTR szMask, DWORD dwFlags = 0);

protected:
	CString m_sMask;
	DWORD m_dwFlags;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMaskEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMaskEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CMaskEdit)
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MASKEDIT_H__03CD6C84_2D70_4E44_9E7E_5673B6F6F97E__INCLUDED_)
                                                                                                                                                                                                                                        0x3F;
	Data.nData[2] |= nTemp;
}

void Base64Coder::_EncodeRaw(TempBucket &Data, const TempBucket &Decode)
{
	BYTE		nTemp;

	Data.nData[0] = Decode.nData[0];
	Data.nData[0] >>= 2;
	
	Data.nData[1] = Decode.nData[0];
	Data.nData[1] <<= 4;
	nTemp = Decode.nData[1];
	nTemp >>= 4;
	Data.nData[1] |= nTemp;
	Data.nData[1] &= 0x3F;

	Data.nData[2] = Decode.nData[1];
	Data.nData[2] <<= 2;

	nTemp = Decode.nData[2];
	nTemp >>= 6;

	Data.nData[2] |= nTemp;
	Data.nData[2] &= 0x3F;

	Data.nData[3] = Decode.nData[2];
	Data.nData[3] &= 0x3F;
}

BOOL Base64Coder::_IsBadMimeChar(BYTE nData)
{
	switch(nData)
	{
		case '\r': case '\n': case '\t': case ' ' :
		case '\b': case '\a': case '\f': case '\v':
			return TRUE;
		default:
			return FALSE;
	}
}

void Base64Coder::_Init()
{  // Initialize Decoding table.

	int	i;

	for(i = 0; i < 256; i++)
		Base64Coder::m_DecodeTable[i] = -2;

	for(i = 0; i < 64; i++)
	{
		Base64Coder::m_DecodeTable[Base64Digits[i]]			= (char)i;
		Base64Coder::m_DecodeTable[Base64Digits[i]|0x80]	= (char)i;
	}

	Base64Coder::m_DecodeTable['=']				= -1;
	Base64Coder::m_DecodeTable['='|0x80]		= -1;

	Base64Coder::m_Init = TRUE;
}

