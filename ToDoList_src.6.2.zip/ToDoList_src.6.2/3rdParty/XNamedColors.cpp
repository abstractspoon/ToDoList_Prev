epercentChange();
	}

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesTaskCalcPage::LoadPreferences(const CPreferences& prefs)
{
	// load settings
	m_bTreatSubCompletedAsDone = prefs.GetProfileInt("Preferences", "TreatSubCompletedAsDone", TRUE);
	m_bAveragePercentSubCompletion = prefs.GetProfileInt("Preferences", "AveragePercentSubCompletion", TRUE);
	m_bIncludeDoneInAverageCalc = prefs.GetProfileInt("Preferences", "IncludeDoneInAverageCalc", TRUE);
	m_bUseEarliestDueDate = prefs.GetProfileInt("Preferences", "UseEarliestDueDate", FALSE);
	m_bUsePercentDoneInTimeEst = prefs.GetProfileInt("Preferences", "UsePercentDoneInTimeEst", TRUE);
	m_bUseHighestPriority = prefs.GetProfileInt("Preferences", "UseHighestPriority", FALSE);
	m_bAutoCalcTimeEst = prefs.GetProfileInt("Preferences", "AutoCalcTimeEst", FALSE);
	m_bIncludeDoneInPriorityRiskCalc = prefs.GetProfileInt("Preferences", "IncludeDoneInPriorityCalc", FALSE);
	m_bAutoCalcPercentDone = prefs.GetProfileInt("Preferences", "AutoCalcPercentDone", FALSE);
	m_bAutoAdjustDependents = prefs.GetProfileInt("Preferences", "AutoAdjustDependents", FALSE);
	m_bDueTasksHaveHighestPriority = prefs.GetProfileInt("Preferences", "DueTasksHaveHighestPriority", FALSE);
	m_bDoneTasksHaveLowestPriority = prefs.GetProfileInt("Preferences", "DoneTasksHaveLowestPriority", TRUE);
	m_bNoDueDateDueToday = prefs.GetProfileInt("Preferences", "NoDueDateIsDueToday", FALSE);
	m_bWeightPercentCompletionByNumSubtasks = prefs.GetProfileInt("Preferences", "WeightPercentCompletionByNumSubtasks", TRUE);
	m_nCalcRemainingTime = prefs.GetProfileInt("Preferences", "CalcRemainingTime", 0);

	// fix up m_bAveragePercentSubCompletion because it's overridden by m_bAutoCalcPercentDone
	if (m_bAutoCalcPercentDone)
		m_bAveragePercentSubCompletion = FALSE;

//	m_b = prefs.GetProfileInt("Preferences", "", FALSE);
}

void CPreferencesTaskCalcPage::SavePreferences(CPreferences& prefs)
{
	// save settings
	prefs.WriteProfileInt("Preferences", "TreatSubCompletedAsDone", m_bTreatSubCompletedAsDone);
	prefs.WriteProfileInt("Preferences", "AveragePercentSubCompletion", m_bAveragePercentSubCompletion);
	prefs.WriteProfileInt("Preferences", "IncludeDoneInAverageCalc", m_bIncludeDoneInAverageCalc);
	prefs.WriteProfileInt("Preferences", "UseEarliestDueDate", m_bUseEarliestDueDate);
	prefs.WriteProfileInt("Preferences", "UsePercentDoneInTimeEst", m_bUsePercentDoneInTimeEst);
	prefs.WriteProfileInt("Preferences", "UseHighestPriority", m_bUseHighestPriority);
	prefs.WriteProfileInt("Preferences", "AutoCalcTimeEst", m_bAutoCalcTimeEst);
	prefs.WriteProfileInt("Preferences", "IncludeDoneInPriorityCalc", m_bIncludeDoneInPriorityRiskCalc);
	prefs.WriteProfileInt("Preferences", "WeightPercentCompletionByNumSubtasks", m_bWeightPercentCompletionByNumSubtasks);
	prefs.WriteProfileInt("Preferences", "AutoCalcPercentDone", m_bAutoCalcPercentDone);
	prefs.WriteProfileInt("Preferences", "AutoAdjustDependents", m_bAutoAdjustDependents);
	prefs.WriteProfileInt("Preferences", "DueTasksHaveHighestPriority", m_bDueTasksHaveHighestPriority);
	prefs.WriteProfileInt("Preferences", "DoneTasksHaveLowestPriority", m_bDoneTasksHaveLowestPriority);
	prefs.WriteProfileInt("Preferences", "NoDueDateIsDueToday", m_bNoDueDateDueToday);
	prefs.WriteProfileInt("Preferences", "CalcRemainingTime", m_nCalcRemainingTime);

//	prefs.WriteProfileInt("Preferences", "", m_b);
}


                                                                                                                             en,				_T("LightGreen") },
	{ colorLightGrey,				_T("LightGrey") },
	{ colorLightPink,				_T("LightPink") },
	{ colorLightSalmon,				_T("LightSalmon") },
	{ colorLightSeaGreen,			_T("LightSeaGreen") },
	{ colorLightSkyBlue,			_T("LightSkyBlue") },
	{ colorLightSlateGray,			_T("LightSlateGray") },
	{ colorLightSteelBlue,			_T("LightSteelBlue") },
	{ colorLightYellow,				_T("LightYellow") },
	{ colorLime,					_T("Lime") },
	{ colorLimeGreen,				_T("LimeGreen") },
	{ colorLinen,					_T("Linen") },
#if !defined(AFX_PREFERENCESTASKCALCPAGE_H__84CBF881_D8CA_4D00_ADD6_1DCB7DE71C5B__INCLUDED_)
#define AFX_PREFERENCESTASKCALCPAGE_H__84CBF881_D8CA_4D00_ADD6_1DCB7DE71C5B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesTaskPage.h : header file
//

#include "..\shared\groupline.h"
#include "..\shared\dialoghelper.h"
#include "..\shared\preferencesbase.h"

enum
{
	PTCP_REMAININGTTIMEISDUEDATE,
	PTCP_REMAININGTTIMEISSPENT,
	PTCP_REMAININGTTIMEISPERCENTAGE,
};

/////////////////////////////////////////////////////////////////////////////
// CPreferencesTaskCalcPage dialog

class CPreferencesTaskCalcPage : public CPreferencesPageBase, public CDialogHelper
{
	DECLARE_DYNCREATE(CPreferencesTaskCalcPage)

// Construction
public:
	CPreferencesTaskCalcPage();
	~CPreferencesTaskCalcPage();

	BOOL GetAveragePercentSubCompletion() const { return m_bAveragePercentSubCompletion; }
	BOOL GetIncludeDoneInAverageCalc() const { return m_bIncludeDoneInAverageCalc; }
	BOOL GetUseEarliestDueDate() const { return m_bUseEarliestDueDate; }
	BOOL GetUsePercentDoneInTimeEst() const { return m_bUsePercentDoneInTimeEst; }
	BOOL GetTreatSubCompletedAsDone() const { return m_bTreatSubCompletedAsDone; }
	BOOL GetUseHighestPriority() const { return m_bUseHighestPriority; }
	BOOL GetUseHighestRisk() const { return m_bUseHighestPriority; } // Note: this uses same flag as priority
	BOOL GetAutoCalcTimeEstimates() const { return m_bAutoCalcTimeEst; }
	BOOL GetIncludeDoneInPriorityRiskCalc() const { return m_bIncludeDoneInPriorityRiskCalc; }
	BOOL GetWeightPercentCompletionByNumSubtasks() const { return m_bWeightPercentCompletionByNumSubtasks; }
	BOOL GetAutoCalcPercentDone() const { return m_bAutoCalcPercentDone; }
	BOOL GetAutoAdjustDependents() const { return m_bAutoAdjustDependents; }
	BOOL GetDueTasksHaveHighestPriority() const { return m_bDueTasksHaveHighestPriority; }
	BOOL GetDoneTasksHaveLowestPriority() const { return m_bDoneTasksHaveLowestPriority; }
	BOOL GetDoneTasksHaveLowestRisk() const { return m_bDoneTasksHaveLowestPriority; } // Note: this uses same flag as priority
	BOOL GetNoDueDateIsDueToday() const { return m_bNoDueDateDueToday; }
	int GetTimeRemainingCalculation() const { return m_nCalcRemainingTime; }

//	BOOL Get() const { return m_b; }

protected:
// Dialog Data
	//{{AFX_DATA(CPreferencesTaskCalcPage)
	enum { IDD = IDD_PREFTASKCALC_PAGE };
	BOOL	m_bTreatSubCompletedAsDone;
	BOOL	m_bUseHighestPriority;
	BOOL	m_bAutoCalcTimeEst;
	BOOL	m_bIncludeDoneInPriorityRiskCalc;
	BOOL	m_bAutoCalcPercentDone;
	BOOL	m_bAutoAdjustDependents;
	BOOL	m_bWeightPercentCompletionByNumSubtasks;
	BOOL	m_bDueTasksHaveHighestPriority;
	BOOL	m_bDoneTasksHaveLowestPriority;
	BOOL	m_bNoDueDateDueToday;
	int		m_nCalcRemainingTime;
	//}}AFX_DATA
	BOOL	m_bUseEarliestDueDate;
	BOOL	m_bUsePercentDoneInTimeEst;
	BOOL	m_bAveragePercentSubCompletion;
	BOOL	m_bIncludeDoneInAverageCalc;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesTaskCalcPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesTaskCalcPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnUsehighestpriority();
	afx_msg void OnAutocalcpercentdone();
	//}}AFX_MSG
	afx_msg void OnAveragepercentChange();
	DECLARE_MESSAGE_MAP()

   virtual void LoadPreferences(const CPreferences& prefs);
   virtual void SavePreferences(CPreferences& prefs);

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESTASKCALCPAGE_H__84CBF881_D8CA_4D00_ADD6_1DCB7DE71C5B__INCLUDED_)
                                                                                                                                                                                                                                      // PreferencesTaskDefPage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesTaskDefPage.h"
#include "tdcenum.h"

#include "..\shared\enstring.h"
#include "..\shared\misc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesTaskDefPage property page

IMPLEMENT_DYNCREATE(CPreferencesTaskDefPage, CPreferencesPageBase)

CPreferencesTaskDefPage::CPreferencesTaskDefPage() : 
	CPreferencesPageBase(CPreferencesTaskDefPage::IDD),
	m_cbAllocByList(TRUE),
	m_cbAllocToList(TRUE),
	m_cbCategoryList(TRUE),
	m_cbStatusList(TRUE)
{
	//{{AFX_DATA_INIT(CPreferencesTaskDefPage)
	m_bUpdateInheritAttributes = FALSE;
	//}}AFX_DATA_INIT
	m_nSelAttribUse = -1;

	// attrib use
	m_aAttribPrefs.Add(ATTRIBPREF(IDS_TDLBC_PRIORITY, PTPA_PRIORITY, -1)); 
	m_aAttribPrefs.Add(ATTRIBPREF(IDS_TDLBC_RISK, PTPA_RISK, -1)); 
	m_aAttribPrefs.Add(ATTRIBPREF(IDS_TDLBC_TIMEEST, PTPA_TIMEEST, -1)); 
	m_aAttribPrefs.Add(ATTRIBPREF(IDS_TDLBC_ALLOCTO, PTPA_ALLOCTO, -1)); 
	m_aAttribPrefs.Add(ATTRIBPREF(IDS_TDLBC_ALLOCBY, PTPA_ALLOCBY, -1)); 
	m_aAttribPrefs.Add(ATTRIBPREF(IDS_TDLBC_STATUS, PTPA_STATUS, -1)); 
	m_aAttribPrefs.Add(ATTRIBPREF(IDS_TDLBC_CATEGORY, PTPA_CATEGORY, -1)); 
	m_aAttribPrefs.Add(ATTRIBPREF(IDS_PTDP_COLOR, PTPA_COLOR, -1)); 
	m_aAttribPrefs.Add(ATTRIBPREF(IDS_PTDP_DUEDATE, PTPA_DUEDATE, -1)); 
	m_aAttribPrefs.Add(ATTRIBPREF(IDS_PTDP_VERSION, PTPA_VERSION, -1)); 
	m_aAttribPrefs.Add(ATTRIBPREF(IDS_TDLBC_STARTDATE, PTPA_STARTDATE, -1)); 
	m_aAttribPrefs.Add(ATTRIBPREF(IDS_TDLBC_FLAG, PTPA_FLAG, -1)); 

	m_eCost.SetMask(".0123456789", ME_LOCALIZEDECIMAL);
}

CPreferencesTaskDefPage::~CPreferencesTaskDefPage()
{
}

void CPreferencesTaskDefPage::DoDataExchange(CDataExchange* pDX)
{
	CPreferencesPageBase::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesTaskDefPage)
	DDX_Control(pDX, IDC_DEFAULTRISK, m_cbDefRisk);
	DDX_Control(pDX, IDC_DEFAULTPRIORITY, m_cbDefPriority);
	DDX_Control(pDX, IDC_ALLOCBYLIST, m_cbAllocByList);
	DDX_Control(pDX, IDC_ALLOCTOLIST, m