Misc::GetModuleFileName(), sDrive, sFolder;

		FileMisc::SplitPath(sDllPath, &sDrive, &sFolder);
		FileMisc::MakePath(sDllPath, sDrive, sFolder, "*", ".dll");

		m_sEnginePath = sDllPath;
	}

	m_ncBorder.Initialize(m_reText);
	m_bMadeChanges = FALSE;

	// reload dictionary list
	int nDicCount = prefs.GetProfileInt("SpellChecker", "DictionaryCount", 0);

	for (int nDic = 0; nDic < nDicCount; nDic++)
	{
		CString sKey;
		sKey.Format("Dictionary%d", nDic);

		CString sPath = prefs.GetProfileString("SpellChecker", sKey);

		if (GetFileAttributes(sPath) != 0xffffffff)
		{
			if (m_cbDictionaries.FindStringExact(-1, sPath) == CB_ERR)
				m_cbDictionaries.AddString(sPath);
		}
	}

	if (m_sSelDictionary.IsEmpty())
		m_sSelDictionary = prefs.GetProfileString("SpellChecker", "ActiveDictionary");

	// check spell check engine is initialized
	BOOL bCancel = FALSE;

	if (!IsSpellCheckDll(m_sEnginePath))
	{
		CString sMsg = GetItemText(DLG_SCD_SETUPMSG, "Before you can spell check for the first time you need \nto specify the location of the Spell Checker.");
		bCancel = (IDCANCEL == AfxMessageBox(sMsg, MB_OKCANCEL));

		while (!bCancel && !IsSpellCheckDll(m_sEnginePath))
		{
			// notify user and browse for dll
			CString sFilter = GetItemText(DLG_SCD_ENGINEFILTER, "SpellChecker Engines|*.dll||");
			CEnFileDialog dialog(TRUE, "dll", m_sEnginePath, OFN_PATHMUSTEXIST, sFilter);

			dialog.m_ofn.lpstrTitle = GetItemText(DLG_SCD_ENGINETITLE, "Locate Spell Check Engine");

			if (dialog.DoModal() == IDOK)
				m_sEnginePath = dialog.GetPathName();
			else
				bCancel = TRUE;
		}
	}

	if (bCancel)
	{
		EndDialog(IDCANCEL);
		return FALSE;
	}

	// make the rich edit appear disabled if not using text
	if (m_pSpellCheck != &m_reSpellCheck)
		m_reText.SetBackgroundColor(FALSE, GetSysColor(COLOR_3DFACE));

	if (IsInitialized() || InitDictionary(m_sSelDictionary))
	{
		if (!StartChecking() && m_bEndOnNoErrors)
		{
			EndDialog(IDNOERRORS);
			return FALSE;
		}
	}

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}

CString CSpellCheckDlg::GetItemText(UINT nIDItem, LPCTSTR szDefault)
{
	CString sText;
	s_mapText.Lookup(nIDItem, sText);
	
	if (sText.IsEmpty() && szDefault)
		return szDefault;

	return sText;
}

void CSpellCheckDlg::SetItemText(UINT nIDItem, UINT nIDText)
{
	CString sText;
	sText.LoadString(nIDText);
	s_mapText[nIDItem] = sText;
}

BOOL CSpellCheckDlg::StartChecking(CHECKFROM nFrom)
{
	CString sWord; 

	BOOL bMisspelt = FindNextMisspeltWord(sWord, nFrom);

	// if starting from the beginning and no misspelt words are found
	// then e return FALSE to indicate no further checking required
	if (nFrom == CH_START && !bMisspelt)
		return FALSE;

	else if (bMisspelt)
	{
		ProcessMisspeltWord(sWord);
		return TRUE;
	}

	// else reached the end so start again
	ProcessMisspeltWord("");

	return StartChecking(CH_START);
}

void CSpellCheckDlg::ProcessMisspeltWord(LPCTSTR szWord)
{
	if (!szWord || !*szWord) // no misspelling
	{
		m_lbSuggestions.ResetContent();
		GetDlgItem(IDC_SCD_REPLACE)->EnableWindow(FALSE);

		m_sMisspeltWord.Empty();
		UpdateData(FALSE);

		return;
	}

	// else
	m_sMisspeltWord.Format("'%s'", szWord);
	UpdateData(FALSE);

	// set new selection
	HighlightWord(TRUE);

	// add suggestions
	m_lbSuggestions.ResetContent();

	if (m_pSpellChecker)
	{
		char** pSuggestions = NULL;
		int nNumSuggestions = 0;

		m_pSpellChecker->CheckSpelling(szWord, pSuggestions, nNumSuggestions);

		for (int nSugg = 0; nSugg < nNumSuggestions; nSugg++)
			m_lbSuggestions.AddString(pSuggestions[nSugg]);

		m_pSpellChecker->FreeSuggestions(pSuggestions);
	}

	if (m_lbSuggestions.GetCount())
		m_lbSuggestions.GetText(0, m_sSuggestion);
	else
		m_sSuggestion.Empty();

	m_lbSuggestions.SelectString(-1, m_sSuggestion);
	GetDlgItem(IDC_SCD_REPLACE)->EnableWindow(m_lbSuggestions.GetCount());
}

void CSpellCheckDlg::HighlightWord(BOOL bHighlight)
{
	if (bHighlight)
		m_pSpellCheck->SelectCurrentWord();
	else
		m_pSpellCheck->ClearSelection();
}

BOOL CSpellCheckDlg::IsWordMisspelt(LPCTSTR szWord)
{
	if (m_pSpellChecker)
		return (m_pSpellChecker->CheckSpelling(szWord) == 0);

	return FALSE;
}

void CSpellCheckDlg::OnSelchangeSuggestions() 
{
	UpdateData();
	
	GetDlgItem(IDC_SCD_REPLACE)->EnableWindow(!m_sSuggestion.IsE