// ServerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ServerDlg.h"
#include "regkey.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CServerDlg dialog

CMap<UINT, UINT, CString, CString&> CServerDlg::s_mapText;

const CString INTERNETSETTINGS("Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings");

CServerDlg::CServerDlg(LPCTSTR szServer, LPCTSTR szUsername, LPCTSTR szPassword, AL_TYPE nAnonymousLogin)
	: m_sServer(szServer), 
	  m_sUsername(szUsername), 
	  m_sPassword(szPassword), 
	  m_nAnonLogin(nAnonymousLogin)
{
	BOOL bShowAnonLogin = (m_nAnonLogin != ANONLOGIN_HIDE);
	int LOGINOFFSET = 0;
	
    AddRCControl("LTEXT", "", "Server:", 0, 0,7,10,24,8, IDC_SD_SERVERLABEL);
    AddRCControl("COMBOBOX", "", "",CBS_DROPDOWN | WS_VSCROLL | WS_TABSTOP | CBS_AUTOHSCROLL, 0,49,7,134,100, IDC_SD_SERVER);

	if (bShowAnonLogin)
	{
		AddRCControl("CONTROL", "Button", "Anonymous Login", BS_AUTOCHECKBOX | WS_TABSTOP, 0, 49,29,134,10, IDC_SD_ANONLOGIN);
		LOGINOFFSET = 20;
	}

	AddRCControl("LTEXT", "", "Username:",0, 0, 7,29 + LOGINOFFSET,35,8, IDC_SD_USERNAMELABEL);
	AddRCControl("COMBOBOX", "", "",CBS_DROPDOWN | WS_VSCROLL | WS_TABSTOP, 0,49,27 + LOGINOFFSET,134,100, IDC_SD_USERNAME);
	AddRCControl("LTEXT", "", "Password:",0, 0, 7,48 + LOGINOFFSET,34,8, IDC_SD_PASSWORDLABEL);
	AddRCControl("EDITTEXT", "", "",ES_PASSWORD | ES_AUTOHSCROLL | WS_TABSTOP, 0,49,45 + LOGINOFFSET,134,14, IDC_SD_PASSWORD);

	AddRCControl("LTEXT", "", "Proxy:",0, 0, 7,67 + LOGINOFFSET,34,8, IDC_SD_PROXYLABEL);
	AddRCControl("EDITTEXT", "", "",ES_AUTOHSCROLL | WS_TABSTOP, 0,49,65 + LOGINOFFSET,80,14, IDC_SD_PROXY);
	AddRCControl("LTEXT", "", "Port:",0, 0, 133,67 + LOGINOFFSET,20,8, IDC_SD_PROXYPORTLABEL);
	AddRCControl("EDITTEXT", "", "",ES_NUMBER | ES_AUTOHSCROLL | WS_TABSTOP, 0,153,65 + LOGINOFFSET,30,14, IDC_SD_PROXYPORT);

	AddRCControl("CONTROL","Static", "",SS_ETCHEDHORZ, 0,7,85 + LOGINOFFSET,176,1, (UINT)IDC_STATIC);
	AddRCControl("DEFPUSHBUTTON", "", "OK", WS_TABSTOP, 0, 77,94 + LOGINOFFSET,50,14,IDOK);
	AddRCControl("PUSHBUTTON", "", "Cancel", WS_TABSTOP, 0,133,94 + LOGINOFFSET,50,14,IDCANCEL);

	if (m_sServer.IsEmpty())
		m_sServer = AfxGetApp()->GetProfileString("RemoteSettings", "LastServer");

	if (m_sUsername.IsEmpty())
		m_sUsername = AfxGetApp()->GetProfileString("RemoteSettings", "LastUsername");

	if (m_nAnonLogin == ANONLOGIN_AUTO)
		m_nAnonLogin = AfxGetApp()->GetProfileInt("RemoteSettings", "LastAnonLogin", ANONLOGIN_NO) ? ANONLOGIN_YES : ANONLOGIN_NO;

	m_sProxy = AfxGetApp()->GetProfileString("RemoteSettings", "Proxy");
	m_nProxyPort = AfxGetApp()->GetProfileInt("RemoteSettings", "ProxyPort", 80);
	
	// if the proxy settings are blank, try to get them from the registry
	if (m_sProxy.IsEmpty())
	{
		CRegKey reg;
		
		if (reg.Open(HKEY_CURRENT_USER, INTERNETSETTINGS) == ERROR_SUCCESS)
		{
			// is proxy enabled?
			DWORD dwProxyEnabled = FALSE;

			if (reg.Read("ProxyEnabled", dwProxyEnabled) == ERROR_SUCCESS && dwProxyEnabled)
			{
				CString sProxy;

				if (reg.Read("ProxyServer", sProxy) == ERROR_SUCCESS && !sProxy.IsEmpty())
				{
					int nColon = sProxy.Find(':', 0);

					if (nColon != -1)
					{
						m_sProxy = sProxy.Left(nColon);
						m_nProxyPort = atoi(sProxy.Mid(nColon + 1));
					}
					else
					{
						m_sProxy = sProxy;
						m_nProxyPort = 80;
					}
				}
			}
		}
	}
}

void CServerDlg::DoDataExchange(CDataExchange* pDX)
{
	CRuntimeDlg::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CServerDlg)
	DDX_CBString(pDX, IDC_SD_SERVER, m_sServer);
	DDX_CBString(pDX, IDC_SD_USERNAME, m_sUsername);
	DDX_Text(pDX, IDC_SD_PASSWORD, m_sPassword);
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_SD_PROXY, m_sProxy);
	DDX_Text(pDX, IDC_SD_PROXYPORT, m_nProxyPort);
	DDX_Control(pDX, IDC_SD_SERVER, m_cbServers);
	DDX_Control(pDX, IDC_SD_USERNAME, m_cbUsernames);

	if (m_nAnonLogin >= ANONLOGIN_NO)
		DDX_Check(pDX, IDC_SD_ANONLOGIN, (int&)m_nAnonLogin);

	if (pDX->m_bSaveAndValidate)
	{
		m_sServer.TrimLeft();
		m_sServer.TrimRight();
		m_sUsername.TrimLeft();
		m_sUsername.TrimRight();
		m_sPassword.TrimLeft();
		m_sPassword.TrimRight();
	}
}

BEGIN_MESSAGE_MAP(CServerDlg, CRuntimeDlg)
	//{{AFX_MSG_MAP(CServerDlg)
	ON_CBN_EDITCHANGE(IDC_SD_SERVER, OnChangeServer)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_SD_ANONLOGIN, OnAnonLogin)
	ON_EN_CHANGE(IDC_SD_PROXY, OnChangeProxy)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServerDlg message handlers

void CServerDlg::OnChangeServer() 
{
	UpdateData();
	
	GetDlgItem(IDOK)->EnableWindow(!m_sServer.IsEmpty());
}

void CServerDlg::OnChangeProxy() 
{
	UpdateData();
	
	GetDlgItem(IDC_SD_PROXYPORTLABEL)->EnableWindow(!m_sProxy.IsEmpty());
	GetDlgItem(IDC_SD_PROXYPORT)->EnableWindow(!m_sProxy.IsEmpty());
}

BOOL CServerDlg::OnInitDialog() 
{
	CRuntimeDlg::OnInitDialog();

	// popuplate comboboxes from registry
	int nServer = AfxGetApp()->GetProfileInt("RemoteSettings", "ServerCount", 0);

	while (nServer--)
	{
		CString sServer, sItem;

		sItem.Format("Server%d", nServer);
		sServer = AfxGetApp()->GetProfileString("RemoteSettings", sItem);

		if (!sServer.IsEmpty() && m_cbServers.FindString(-1, sServer) == CB_ERR)
			m_cbServers.InsertString(0, sServer);
	}

	// add m_sServer as appropriate and select
	if (!m_sServer.IsEmpty() && m_cbServers.FindString(-1, m_sServer) == CB_ERR)
		m_cbServers.InsertString(0, m_sServer);

	m_cbServers.SelectString(-1, m_sServer);
	
	int nName = AfxGetApp()->GetProfileInt("RemoteSettings", "UsernameCount", 0);

	while (nName--)
	{
		CString sName, sItem;

		sItem.Format("Username%d", nName);
		sName = AfxGetApp()->GetProfileString("RemoteSettings", sItem);

		if (!sName.IsEmpty() && m_cbUsernames.FindString(-1, sName) == CB_ERR)
			m_cbUsernames.InsertString(0, sName);
	}

	// add m_sUsername as appropriate and select
	if (!m_sUsername.IsEmpty() && m_cbUsernames.FindString(-1, m_sUsername) == CB_ERR)
		m_cbUsernames.InsertString(0, m_sUsername);

	m_cbUsernames.SelectString(-1, m_sUsername);

	OnChangeProxy();
	OnChangeServer();
	OnAnonLogin();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CServerDlg::OnOK() 
{
	CRuntimeDlg::OnOK();

	// save server list to registry and last selected item
	int nServer = m_cbServers.GetCount();

	AfxGetApp()->WriteProfileInt("RemoteSettings", "ServerCount", nServer);

	while (nServer--)
	{
		CString sServer, sItem;

		sItem.Format("Server%d", nServer);
		m_cbServers.GetLBText(nServer, sServer);

		AfxGetApp()->WriteProfileString("RemoteSettings", sItem, sServer);
	}

	AfxGetApp()->WriteProfileString("RemoteSettings", "LastServer", m_sServer);
	
	// save username list to registry and last selected item
	int nName = m_cbUsernames.GetCount();

	AfxGetApp()->WriteProfileInt("RemoteSettings", "UsernameCount", nName);

	while (nName--)
	{
		CString sName, sItem;

		sItem.Format("Username%d", nName);
		m_cbUsernames.GetLBText(nName, sName);

		if (!sName.IsEmpty())
			AfxGetApp()->WriteProfileString("RemoteSettings", sItem, sName);
	}

	AfxGetApp()->WriteProfileString("RemoteSettings", "LastUsername", m_sUsername);
	AfxGetApp()->WriteProfileInt("RemoteSettings", "LastAnonLogin", m_nAnonLogin);
}

void CServerDlg::OnAnonLogin()
{
	UpdateData();

	if (m_nAnonLogin != ANONLOGIN_HIDE)
	{
		GetDlgItem(IDC_SD_USERNAME)->EnableWindow(m_nAnonLogin == ANONLOGIN_NO);
		GetDlgItem(IDC_SD_PASSWORD)->EnableWindow(m_nAnonLogin == ANONLOGIN_NO);
	}
}

CString CServerDlg::GetItemText(UINT nIDItem, LPCTSTR szDefault)
{
	CString sText;
	s_mapText.Lookup(nIDItem, sText);
	
	if (sText.IsEmpty() && szDefault)
		return szDefault;

	return sText;
}

void CServerDlg::SetItemText(UINT nIDItem, UINT nIDText)
{
	CString sText;
	sText.LoadString(nIDText);
	s_mapText[nIDItem] = sText;
}


                                                                                                                                                                                                                                                                                                                                                                                                                                                                 sg->wParam == VK_DOWN)
				{
					//select next task
					if (m_nSelectedTaskID != -1)
					{
						CBigCalendarTask* plbTasks = GetTaskListboxFromDate(m_dateSelected);
						if (plbTasks != NULL)
						{
							m_nSelectedTaskID++;
							if (m_nSelectedTaskID >= plbTasks->GetCount())
							{
								m_nSelectedTaskID = -1;
							}
							plbTasks->SetCurSel(m_nSelectedTaskID);

							SendSelectDateMessageToParent(TRUE);
						}
					}

					if (m_nSelectedTaskID == -1)
					{
						LeaveCell();

						//move to cell below
						if (nRow == nNumWeeks-1)
						{
							CCalendarUtils::AddDay(dtNew, 7);
							if (!CCalendarUtils::IsDateValid(dtNew))
							{
								ASSERT(FALSE);
								return FALSE;
							}

							m_nVscrollPos++;
						}
						else
						{
							nRow++;
						}
					}
				}
				else if (pMsg->wParam == VK_LEFT)
				{
					LeaveCell();

					//move to previous cell
					if (nCol > 0)
					{
						nCol--;
					}
					else
					{
						nCol = nNumColumns-1;
						if (nRow == 0)
						{
							CCalendarUtils::SubtractDay(dtNew, 7);
							if (!CCalendarUtils::IsDateValid(dtNew))
							{
								ASSERT(FALSE);
								return FALSE;
							}

							m_nVscrollPos--;
						}
						else
						{
							nRow--;
						}
					}
				}
				else //(pMsg->wParam == VK_RIGHT)
				{
					LeaveCell();

					//move to next cell
					if (nCol < nNumColumns-1)
					{
						nCol++;
					}
					else
					{
						nCol = 0;
						if (nRow == nNumWeeks-1)
						{
							CCalendarUtils::AddDay(dtNew, 7);
							if (!CCalendarUtils::IsDateValid(dtNew))
							{
								ASSERT(FALSE);
								return FALSE;
							}

							m_nVscrollPos++;
						}
						else
						{
							nRow++;
						}
					}
				}

				if (nOldScrollPos != m_nVscrollPos)	//scroll pos changed - update scrollpos and goto new date
				{
					SetScrollPos(SB_VERT, m_nVscrollPos, TRUE);
					Goto(dtNew);
				}

				if (!CCalendarUtils::IsDateValid(m_dayCells[nRow][nCol].date))
				{
					ASSERT(FALSE);
					return FALSE;
				}

				m_dateSelected = m_dayCells[nRow][nCol].date;
				Invalidate(TRUE);

				if (m_nSelectedTaskID == -1)	//no need if we still have a task selected
				{
					FireNotifySelectDate();
				}

				return TRUE;
			}
			case VK_NEXT:
			{
				LeaveCell();

				CCalendarUtils::AddMonth(m_dateSelected);
				SelectDate(m_dateSelected);

				FireNotifySelectDate();

				break;
			}
			case VK_PRIOR:
			{
				LeaveCell();

				CCalendarUtils::SubtractMonth(m_dateSelected);
				SelectDate(m_dateSelected);

				FireNotifySelectDate();

				break;
			}
			case VK_RETURN:
			{
				if (m_nSelectedTaskID != -1)
				{
					CBigCalendarTask* plbTasks = GetTaskListboxFromDate(m_dateSelected);
					if (plbTasks != NULL)
					{
						SelectTask(plbTasks->GetDlgCtrlID(), m_nSelectedTaskID);
					}
				}
				break;
			}
			default:
			{
				break;
			}
		}
	}

	return CWnd::PreTranslateMessage(pMsg);
}

BOOL CBigCalendarCtrl::GetGridCellFromPoint(CPoint _point,
											int& _nRow,
											int& _nCol) const
{
	if (_point.y > CALENDAR_HEADER_HEIGHT) 
	{
		int nNumColumns = m_pFrameWnd->GetNumDaysToDisplay();
		int nNumWeeks = m_pFrameWnd->GetNumWeeksToDisplay();

		CRect rc;
		GetClientRect(&rc);
		int nHeight = (rc.Height()-CALENDAR_HEADER_HEIGHT)/nNumWeeks;
		int nWidth = rc.Width()/nNumColumns;
		if(nHeight && nWidth)
		{
			_nRow = (_point.y-CALENDAR_HEADER_HEIGHT)/nH// ShortcutManager.cpp: implementation of the CShortcutManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ShortcutManager.h"
#include "wclassdefines.h"
#include "runtimedlg.h"
#include "winclasses.h"
#include "preferences.h"
#include "Misc.h"

#include <afxtempl.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

enum
{
	VK_0 = 0x30,
	VK_9 = 0x39,
	VK_A = 0x41,
	VK_Z = 0x5A,
};

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CShortcutManager::CShortcutManager(BOOL bAutoSendCmds)
	: m_bAutoSendCmds(bAutoSendCmds), m_wInvalidComb(0), m_wFallbackModifiers(0)
{

}

CShortcutManager::~CShortcutManager()
{

}

BOOL CShortcutManager::Initialize(CWnd* pOwner, WORD wInvalidComb, WORD wFallbackModifiers)
{
	if (wInvalidComb && !IsHooked())
	{
		if (pOwner && HookWindow(*pOwner))
		{
			m_wInvalidComb = wInvalidComb;
			m_wFallbackModifiers = wFallbackModifiers;
			LoadSettings();

			return TRUE;
		}
	}

	return FALSE;
}

BOOL CShortcutManager::Release()
{
	if (!IsHooked())
		return TRUE;

	return HookWindow(NULL);
}

void CShortcutManager::SetShortcut(UINT nCmdID, WORD wVirtKeyCode, WORD wModifiers)
{
	UINT nOtherCmdID = 0;
	DWORD dwShortcut = MAKELONG(wVirtKeyCode, wModifiers);

	// if the shortcut == 0 then remove the existing shortcut associated with nCmdID
	if (!dwShortcut)
	{
		m_mapID2Shortcut.Lookup(nCmdID, dwShortcut);

		m_mapShortcut2ID.RemoveKey(dwShortcut);

		// mark these commands explicitly as having no shortcut so that
		// the user's intent is clear. 
		m_mapID2Shortcut[nCmdID] = NO_SHORTCUT;

		return;
	}
	// check for existing cmds using this shortcut to remove
	else if (m_mapShortcut2ID.Lookup(dwShortcut, nOtherCmdID))
	{
		m_mapShortcut2ID.RemoveKey(dwShortcut);

		// mark these commands explicitly as having no shortcut so that
		// they subsequently will not be overwritten 
		m_mapID2Shortcut[nOtherCmdID] = NO_SHORTCUT;
	}

	// then simple add
	AddShortcut(nCmdID, wVirtKeyCode, wModifiers);
}

void CShortcutManager::SetShortcut(UINT nCmdID, DWORD dwShortcut)
{
	SetShortcut(nCmdID, LOWORD(dwShortcut), HIWORD(dwShortcut));
}

BOOL CShortcutManager::AddShortcut(UINT nCmdID, DWORD dwShortcut)
{
	return AddShortcut(nCmdID, LOWORD(dwShortcut), HIWORD(dwShortcut));
}

BOOL CShortcutManager::AddShortcut(UINT nCmdID, WORD wVirtKeyCode, WORD wModifiers)
{
	// test for invalid modifiers
	if (ValidateModifiers(wModifiers, wVirtKeyCode) != wModifiers)
		return FALSE;

	// check for existing cmds using this shortcut
	DWORD dwShortcut = MAKELONG(wVirtKeyCode, wModifiers);

	if (!nCmdID || !dwShortcut)
		return FALSE;

	UINT nOtherCmdID = 0;

	if (m_mapShortcut2ID.Lookup(dwShortcut, nOtherCmdID) && nOtherCmdID)
		return FALSE;

	// check for existing shortcut on this cmd that we'll need to clean up
	DWORD dwOtherShortcut = 0;

	if (m_mapID2Shortcut.Lookup(nCmdID, dwOtherShortcut))
		m_mapShortcut2ID.RemoveKey(dwOtherShortcut);

	m_mapShortcut2ID[dwShortcut] = nCmdID;
	m_mapID2Shortcut[nCmdID] = dwShortcut;

	return TRUE;
}

WORD CShortcutManager::ValidateModifiers(WORD wModifiers, WORD wVirtKeyCode) const
{
	if (!m_wInvalidComb) // optimization
		return wModifiers;

	// check for our special modifiers first
	if ((m_wInvalidComb & HKCOMB_EXFKEYS) && (wVirtKeyCode >= VK_F1 && wVirtKeyCode <= VK_F24))
		return wModifiers;

	// test for invalid combinations
	BOOL bCtrl = (wModifiers & HOTKEYF_CONTROL);
	BOOL bShift = (wModifiers & HOTKEYF_SHIFT);
	BOOL bAlt = (wModifiers & HOTKEYF_ALT);
	BOOL bExtended = (wModifiers & HOTKEYF_EXT);

	BOOL bFail = ((m_wInvalidComb & HKCOMB_NONE) && !bCtrl && !bShift && !bAlt);

	bFail |= ((m_wInvalidComb & HKCOMB_S) && !bCtrl && bShift && !bAlt);
	bFail |= ((m_wInvalidComb & HKCOMB_C) && bCtrl && !bShift && !bAlt);
	bFail |= ((m_wInvalidComb & HKCOMB_A) && !bCtrl && !bShift && bAlt);
	bFail |= ((m_wInvalidComb & HKCOMB_SC) && bCtrl && bShift && !bAlt);
	bFail |= ((m_wInvalidComb & HKCOMB_SA) && !bCtrl && bShift && bAlt);
	bFail |= ((m_wInvalidComb & HKCOMB_CA) && bCtrl && !bShift && bAlt);
	bFail |= ((m_wInvalidComb & HKCOMB_SCA) && bCtrl && bShift && bAlt);

	if (bFail)
		return (WORD)(m_wFallbackModifiers | (bExtended ? HOTKEYF_EXT : 0x0));

	// else ok
	return wModifiers;
}

DWORD CShortcutManager::GetShortcut(WORD wVirtKeyCode, BOOL bExtended) const
{
	BOOL bCtrl = Misc::KeyIsPressed(VK_CONTROL);
	BOOL bShift = Misc::KeyIsPressed(VK_SHIFT);
	BOOL bAlt = Misc::KeyIsPressed(VK_MENU);

	WORD wModifiers = (WORD)((bCtrl ? HOTKEYF_CONTROL : 0) |
						(bShift ? HOTKEYF_SHIFT : 0) |
						(bAlt ? HOTKEYF_ALT : 0) |
						(bExtended ? HOTKEYF_EXT : 0));

	return MAKELONG(wVirtKeyCode, wModifiers);
}


UINT CShortcutManager::ProcessMessage(const MSG* pMsg, DWORD* pShortcut) const
{
	// only process accelerators if we are enabled and visible
	if (!IsWindowEnabled() || !IsWindowVisible())
		return FALSE;

	// we only process keypresses
	if (pMsg->message != WM_KEYDOWN && pMsg->message != WM_SYSKEYDOWN)
		return FALSE;

	// also check that it's one of our children with the focus
	// not another popup window
	CWnd* pWnd = CWnd::FromHandle(pMsg->hwnd);
	
	CWnd* pMainWnd = GetCWnd();
	CWnd* pTopParent = pWnd->GetParentOwner();
	
	if (pTopParent != pMainWnd)
		return FALSE;
			
	switch (pMsg->wParam)
	{
	case VK_CONTROL:
	case VK_SHIFT:
	case VK_MENU:
	case VK_NUMLOCK:
	case VK_SCROLL:
	case VK_CAPITAL:
		return FALSE;
		
		// don't handle return/cancel keys
	case VK_RETURN:
	case VK_CANCEL:
		return FALSE;

	case VK_MBUTTON:
		break;
		
		// shortcut keys
	default: 
		{
			// don't process messages destined for hotkey controls!
			if (CWinClasses::IsClass(pMsg->hwnd, WC_HOTKEY))
				return FALSE;

			// don't process AltGr if destined for edit control
			BOOL bEdit = CWinClasses::IsEditControl(pMsg->hwnd);

			if (bEdit && Misc::KeyIsPressed(VK_RMENU))
				return FALSE;
			
			// get DWORD shortcut
			BOOL bExtKey = (pMsg->lParam & 0x01000000);
			DWORD dwShortcut = GetShortcut((WORD)pMsg->wParam, bExtKey);
			
			// look it up
			UINT nCmdID = 0;
			
			if (!m_mapShortcut2ID.Lookup(dwShortcut, nCmdID) || !nCmdID)
				return FALSE;
			
			// check if HKCOMB_EDITCTRLS is set and a edit has the focus
			// and the shortcut clashes
			if (bEdit && (m_wInvalidComb & HKCOMB_EDITCTRLS))
			{
				// 1. check does not clash with edit shortcuts
				if (IsEditShortcut(dwShortcut))
					return FALSE;
				
				//WORD wVirtKeyCode = LOWORD(dwShortcut);
				WORD wModifiers = HIWORD(dwShortcut);
				
				// 2. can be a function key
				if (pMsg->wParam >= VK_F1 && pMsg->wParam <= VK_F24)
				{
					// ok
				}
				// 3. else must have <ctrl> or <alt>
				else if (!(wModifiers & (HOTKEYF_ALT | HOTKEYF_CONTROL)))
					return FALSE;
			}
			
			// return command ID
			if (m_bAutoSendCmds)
				SendMessage(WM_COMMAND, nCmdID);

			if (pShortcut)
				*pShortcut = dwShortcut;
			
			return nCmdID;
		}
	}
	
	return FALSE;
}

BOOL CShortcutManager::IsEditShortcut(DWORD dwShortcut)
{
	switch (dwShortcut)
	{
	case MAKELONG('C', HOTKEYF_CONTROL): // copy
	case MAKELONG('V', HOTKEYF_CONTROL): // paste
	case MAKELONG('X', HOTKEYF_CONTROL): // cut
//	case MAKELONG('Z', HOTKEYF_CONTROL): // undo
	case MAKELONG(VK_LEFT, HOTKEYF_CONTROL | HOTKEYF_EXT): // left one word
	case MAKELONG(VK_RIGHT, HOTKEYF_CONTROL | HOTKEYF_EXT): // right one word
	case MAKELONG(VK_DELETE, 0):
		return TRUE;
	}

	// all else
	return FALSE;
}

LRESULT CShortcutManager::WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case WM_INITMENUPOPUP:
		{
			// default processing so all text changes 
			// are complete before we have a go
			LRESULT lr = Default();

			PrepareMenuItems(CMenu::FromHandle((HMENU)wp));

			return lr;
		}
		break;

	case WM_DESTROY:
		{
			// must call rest of chain first 
			LRESULT lr =  CSubclassWnd::WindowProc(hRealWnd, msg, wp, lp);
			HookWindow(NULL);

			SaveSettings();
			return lr;
		}
		break;
	}

	return CSubclassWnd::WindowProc(hRealWnd, msg, wp, lp);
}

void CShortcutManager::PrepareMenuItems(CMenu* pMenu) const
{
	if (!pMenu || !pMenu->GetSafeHmenu())
		return;

	// we iterate all the menu items
	// if we find a match we get the menu text and add the shortcut
	// first removing any existing one
	int nItem = pMenu->GetMenuItemCount();

	while (nItem--)
	{
		UINT nCmdID = pMenu->GetMenuItemID(nItem);
		DWORD dwShortcut = GetShortcut(nCmdID);

		if (!nCmdID || nCmdID == (UINT)-1)
			continue;
		
		// note: we must handle items without shortcuts as well
		// as ones with

		// get the menu text
		MENUITEMINFO minfo;
		minfo.cbSize = sizeof(minfo);
        minfo.fMask = MIIM_FTYPE | MIIM_STRING;
        minfo.fType = MFT_STRING;
		minfo.dwTypeData = NULL;
		minfo.cch = 0;

        ::GetMenuItemInfo(pMenu->GetSafeHmenu(), nItem, TRUE, &minfo);
		CString sMenuText;

		if (!minfo.cch)
			continue; // ??

		minfo.cch++;
		minfo.dwTypeData = sMenuText.GetBuffer(minfo.cch);
		::GetMenuItemInfo(pMenu->GetSafeHmenu(), nItem, TRUE, &minfo);
		sMenuText.ReleaseBuffer();

		// look for '\t' indicating existing hint
		int nTab = sMenuText.Find('\t');
		
		// remove it
		if (nTab >= 0)
			sMenuText = sMenuText.Left(nTab);
		// else if it didn't have one and it has no shortcut then continue
		else if (!dwShortcut)
			continue;
		
		// add new hint
		CString sShortcut = GetShortcutText(dwShortcut);

		if (!sShortcut.IsEmpty())
		{
			sMenuText += '\t';
			sMenuText += sShortcut;
		}

		// update menu item text
		minfo.dwTypeData = (LPSTR)(LPCTSTR)sMenuText;
		
        ::SetMenuItemInfo(pMenu->GetSafeHmenu(), nItem, TRUE, &minfo);
	}
}

int CShortcutManager::BuildMapping(UINT nMenuID, CStringArray& aMapping, char cDelim)
{
	CMenu menu;

	if (!menu.LoadMenu(nMenuID) || !menu.GetMenuItemCount())
		return 0;

	return BuildMapping(&menu, NULL, aMapping, cDelim);
}

int CShortcutManager::BuildMapping(CMenu* pMenu, LPCTSTR szParentName, 
								   CStringArray& aMapping, char cDelim)
{
	int nItems = pMenu->GetMenuItemCount();

	for (int nItem = 0; nItem < nItems; nItem++)
	{
		CString sMenuText, sItemText;

		pMenu->GetMenuString(nItem, sMenuText, MF_BYPOSITION);

		if (szParentName && *szParentName)
			sItemText.Format("%s > %s", szParentName, sMenuText);
		else
			sItemText = sMenuText;

		UINT nCmdID = pMenu->GetMenuItemID(nItem);

		if (nCmdID == (UINT)-1) // sub menu
		{
			CMenu* pSubMenu = pMenu->GetSubMenu(nItem);

			BuildMapping(pSubMenu, sItemText, aMapping, cDelim);
		}
		else
		{
			DWORD dwShortcut = GetShortcut(nCmdID);

			if (dwShortcut)
			{
				CString sShortcut = GetShortcutText(dwShortcut), sItem;
				sItem.Format("%s%c%s", sShortcut, cDelim, sItemText);

				// remove single '&'
				// rather painful way to do it to avoid replacing '&&'
				sItem.Replace("&&", "~~");
				sItem.Remove('&');
				sItem.Replace("~~", "&&");

				aMapping.Add(sItem);
			}
		}
	}
	
	// add a space between sections unless already added
	if (aMapping.GetSize() && !aMapping[aMapping.GetSize() - 1].IsEmpty())
		aMapping.Add("");

	return aMapping.GetSize();
}

UINT CShortcutManager::GetCommandID(DWORD dwShortcut)
{
	UINT nCmdID = 0;

	m_mapShortcut2ID.Lookup(dwShortcut, nCmdID);

	return nCmdID;
}

DWORD CShortcutManager::GetShortcut(UINT nCmdID) const
{
	DWORD dwShortcut = 0;

	m_mapID2Shortcut.Lookup(nCmdID, dwShortcut);
	
	return (dwShortcut == NO_SHORTCUT) ? 0 : dwShortcut;
}

void CShortcutManager::DeleteShortcut(UINT nCmdID)
{
	DWORD dwShortcut = 0;

	if (m_mapID2Shortcut.Lookup(nCmdID, dwShortcut))
	{
		m_mapID2Shortcut.RemoveKey(nCmdID);

		// remove reverse mapping too
		m_mapShortcut2ID.RemoveKey(dwShortcut);
	}
}

CString CShortcutManager::GetShortcutTextByCmd(UINT nCmdID)
{
	return GetShortcutText(GetShortcut(nCmdID));
}

CString CShortcutManager::GetShortcutText(DWORD dwShortcut)
{
	if (!dwShortcut || dwShortcut == NO_SHORTCUT)
		return "";

	CString sText;

	WORD wVirtKeyCode = LOWORD(dwShortcut);
	WORD wModifiers = HIWORD(dwShortcut);

	if (wModifiers & HOTKEYF_CONTROL)
	{
		sText += GetKeyName(VK_CONTROL);
		sText += "+";
	}

	if (wModifiers & HOTKEYF_SHIFT)
	{
		sText += GetKeyName(VK_SHIFT);
		sText += "+";
	}

	if (wModifiers & HOTKEYF_ALT)
	{
		sText += GetKeyName(VK_MENU);
		sText += "+";
	}

	CString sKey = GetKeyName(wVirtKeyCode, (wModifiers & HOTKEYF_EXT));

	if (!sKey.IsEmpty())
		sText += sKey;
	else
		sText.Empty();

	return sText;
}

CString CShortcutManager::GetKeyName(WORD wVirtKeyCode, BOOL bExtended)
{
	const int KEYNAMELEN = 64;
	static char szKeyName[64];

	WORD wScanCode = (WORD)MapVirtualKey(wVirtKeyCode, 0);

	// build lParam to send to GetKeyNameText
	LPARAM lParam = (wScanCode * 0x00010000);

	if (bExtended)
		lParam += 0x01000000;

	GetKeyNameText(lParam, szKeyName, KEYNAMELEN);

	return CString(szKeyName);
}

void CShortcutManager::LoadSettings()
{
	CPreferences prefs;

	// load shortcuts overriding any defaults
	int nItem = prefs.GetProfileInt("KeyboardShortcuts", "NumItems", 0);

	while (nItem--)
	{
		CString sKey;
		sKey.Format("KeyboardShortcuts\\Item%02d", nItem);

		UINT nCmdID = (UINT)prefs.GetProfileInt(sKey, "CmdID", 0);
		DWORD dwShortcut = (DWORD)prefs.GetProfileInt(sKey, "Shortcut", 0);

		if (nCmdID && dwShortcut)
			SetShortcut(nCmdID, dwShortcut);
	}
}

void CShortcutManager::SaveSettings()
{
	CPreferences prefs;

	prefs.WriteProfileInt("KeyboardShortcuts", "NumItems", m_mapID2Shortcut.GetCount());

	POSITION pos = m_mapID2Shortcut.GetStartPosition();
	int nItem = 0;

	while (pos)
	{
		UINT nCmdID = 0;
		DWORD dwShortcut = 0;

		m_mapID2Shortcut.GetNextAssoc(pos, nCmdID, dwShortcut);

		if (nCmdID && dwShortcut)
		{
			CString sKey;
			sKey.Format("KeyboardShortcuts\\Item%02d", nItem);

			prefs.WriteProfileInt(sKey, "CmdID", nCmdID);
			prefs.WriteProfileInt(sKey, "Shortcut", dwShortcut);

			nItem++;
		}
	}
}
                                                                                                                                                                                                                                                                                                ulateTasks)
					{
						//remove existing items from all listboxes
						pWndTask->ResetContent();

						//re-add values to all listboxes
						int iNumTasks = m_dayCells[i][u].arrTasks.GetSize();
						for (int iTask = 0; iTask < iNumTasks; iTask++)
						{
							CString strOut = m_dayCells[i][u].arrTasks.GetAt(iTask);
							DWORD dwTaskID = m_dayCells[i][u].arrTaskIDs[iTask];
							BOOL bIsStartTask = m_dayCells[i][u].arrIsStartTask[iTask];
							BOOL bIsCompleteTask = m_dayCells[i][u].arrIsCompleteTask[iTask];
							pWndTask->AddItem(strOut, dwTaskID, bIsStartTask, bIsCompleteTask);
						}

						//does this cell contain any task that should be selected?
						if (m_dayCells[i][u].date == m_dateSelected)
						{
							//re-select task now that it has been redrawn
							pWndTask->SetCurSel(m_nSelectedTaskID);
						}
					}

					int nMaxHeight = rcCell.Height()-12;
					int nRequiredHeight = pWndTask->GetTotalItemHeight();
					if (nRequiredHeight > nMaxHeight)
					{
						nRequiredHeight = nMaxHeight;
					}

					//resize/move the tasks listbox
					pWndTask->SetWindowPos(NULL, rcCell.left+3, rcCell.top+14,
										   rcCell.Width()-5, nRequiredHeight, 0);
				}
			}
		}
	}
}

//redraws all cells, populating each one with the new date
void CBigCalendarCtrl::RepopulateAllCells(const COleDateTime& _dateFirstCell)
{
	COleDateTime dateCurrent = _dateFirstCell;
	int iFirstCellDayOfWeek = dateCurrent.GetDayOfWeek();

	if (m_pFrameWnd->IsWeekendsHidden())// SpellCheckDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SpellCheckDlg.h"
#include "ispellcheck.h"
#include "enfiledialog.h"
#include "stringres.h"
#include "filemisc.h"
#include "preferences.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSpellCheckDlg dialog

CMap<UINT, UINT, CString, CString&> CSpellCheckDlg::s_mapText;


CSpellCheckDlg::CSpellCheckDlg(LPCTSTR szDictionaryPath, ISpellCheck* pSpellCheck, LPCTSTR szText, CWnd* /*pParent*/) : 
	m_pSpellChecker(NULL), 
	m_reSpellCheck(m_reText),
    m_sSelDictionary(szDictionaryPath), 
	m_stURL("http://wiki.services.openoffice.org/wiki/Dictionaries"),
	m_bMadeChanges(FALSE),
	m_ptTopLeft(-1, -1)
{
	InitDialog(pSpellCheck, szText);
}

void CSpellCheckDlg::InitDialog(ISpellCheck* pSpellCheck, LPCTSTR szText)
{
	AfxEnableControlContainer();
	AfxInitRichEdit();

	AddRCControl("LTEXT", "", _T("Ac&tive Dictionary:"), 0,0, 7,9,65,8, IDC_SCD_DICTLABEL);
	AddRCControl("COMBOBOX", "", "", CBS_DROPDOWNLIST | WS_TABSTOP, 0, 66, 8, 182,100, IDC_SCD_DICTIONARIES);
	AddRCControl("PUSHBUTTON", "", _T("Bro&wse"),WS_TABSTOP, 0,256,7,50,14,IDC_SCD_BROWSE);
	AddRCControl("LTEXT", "", _T("Download More Dictionaries"), WS_TABSTOP,0, 66,21,90,8,IDC_SCD_URL);
	AddRCControl("LTEXT", "", _T("C&hecking Text:"), 0,0, 7,30,49,8, IDC_SCD_CHECKINGLABEL);
	AddRCControl("CONTROL", "RICHEDIT", "",ES_MULTILINE | ES_AUTOVSCROLL | ES_NOHIDESEL |/*WS_BORDER | */ ES_READONLY | WS_VSCROLL | WS_TABSTOP | WS_DISABLED,0, 7,40,242,68,IDC_SCD_TEXT);
	AddRCControl("PUSHBUTTON", "", _T("R&estart"),WS_TABSTOP, 0,256,40,50,14,IDC_SCD_RESTART);
	AddRCControl("LTEXT", "", _T("Replace:"),0, 0,7,112,30,8, IDC_SCD_REPLACELABEL);
	AddRCControl("LTEXT", "", "Static",0, 0,44,112,205,8,IDC_SCD_MISSPELTWORD);
	AddRCControl("LTEXT", "", _T("&With:"),0, 0,7,124,18,8, IDC_SCD_WITHLABEL);
	AddRCControl("LISTBOX", "", "", LBS_SORT | LBS_NOINTEGRALHEIGHT | WS_VSCROLL | WS_TABSTOP | LBS_NOTIFY, 0,41,124,208,51, IDC_SCD_SUGGESTIONS);
	AddRCControl("PUSHBUTTON", "", _T("&Replace"),WS_TABSTOP, 0,256,124,50,14,IDC_SCD_REPLACE);
	AddRCControl("PUSHBUTTON", "", _T("&Next Word"),WS_TABSTOP, 0,256,144,50,14,IDC_SCD_NEXT);
	AddRCControl("CONTROL", "static", "",SS_ETCHEDHORZ,0,7,182,299,1, (UINT)IDC_STATIC);

	if (!pSpellCheck)
	{
		AddRCControl("DEFPUSHBUTTON", "", BTN_OK, WS_TABSTOP, 0, 199,190,50,14,IDOK);
		AddRCControl("PUSHBUTTON", "", BTN_CANCEL, WS_TABSTOP, 0,256,190,50,14,IDCANCEL);

		SetText(szText);
	}
	else
	{
		AddRCControl("PUSHBUTTON", "", BTN_CLOSE, WS_TABSTOP, 0,256,190,50,14,IDCANCEL);

		SetSpellCheck(pSpellCheck);
	}
}

CSpellCheckDlg::~CSpellCheckDlg()
{
	ReleaseSpellCheckerInterface(m_pSpellChecker);
}

void CSpellCheckDlg::DoDataExchange(CDataExchange* pDX)
{
	CRuntimeDlg::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSpellCheckDlg)
	DDX_Control(pDX, IDC_SCD_SUGGESTIONS, m_lbSuggestions);
	DDX_Text(pDX, IDC_SCD_MISSPELTWORD, m_sMisspeltWord);
	DDX_LBString(pDX, IDC_SCD_SUGGESTIONS, m_sSuggestion);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_SCD_URL, m_stURL);
	DDX_Control(pDX, IDC_SCD_DICTIONARIES, m_cbDictionaries);

	DDX_Text(pDX, IDC_SCD_TEXT, m_sText);
	DDX_Control(pDX, IDC_SCD_TEXT, m_reText);

	if (pDX->m_bSaveAndValidate)
	{
		int nCurSel = m_cbDictionaries.GetCurSel();

		if (nCurSel != CB_ERR)
			m_cbDictionaries.GetLBText(nCurSel, m_sSelDictionary);
		else
			m_sSelDictionary.Empty();
	}
	else
	{
		// make sure its in the list and move to top
		int nDic = m_cbDictionaries.FindStringExact(-1, m_sSelDictionary);

		if (nDic != CB_ERR)
			m_cbDictionaries.DeleteString(nDic);

		if (!m_sSelDictionary.IsEmpty())
		{
			m_cbDictionaries.InsertString(0, m_sSelDictionary);
			m_cbDictionaries.SetCurSel(0);
		}
	}
}

BEGIN_MESSAGE_MAP(CSpellCheckDlg, CRuntimeDlg)
	//{{AFX_MSG_MAP(CSpellCheckDlg)
	ON_BN_CLICKED(IDC_SCD_REPLACE, OnReplace)
	ON_BN_CLICKED(IDC_SCD_NEXT, OnContinue)
	ON_LBN_SELCHANGE(IDC_SCD_SUGGESTIONS, OnSelchangeSuggestions)
	ON_BN_CLICKED(IDC_SCD_RESTART, OnRestart)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_SCD_BROWSE, OnBrowse)
	ON_CBN_SELCHANGE(IDC_SCD_DICTIONARIES, OnChangeDictionary)
	ON_LBN_DBLCLK(IDC_SCD_SUGGESTIONS, OnDblClkSuggestions)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSpellCheckDlg message handlers

int CSpellCheckDlg::DoModal(BOOL bEndOnNoErrors) 
{ 
	m_bEndOnNoErrors = bEndOnNoErrors;

	// turn off centering if we saved the last position
	DWORD dwFlags = RTD_DEFSTYLE;

	if (m_ptTopLeft.x != -1 || m_ptTopLeft.y != -1)
		dwFlags &= ~DS_CENTER;

	return CRuntimeDlg::DoModal(GetItemText(SCD_TITLE, "Spell Checking"), dwFlags); 
}

BOOL CSpellCheckDlg::InitDictionary(LPCTSTR szDicPath)
{
	CString sAffixPath(szDicPath);
	sAffixPath.MakeLower();
	sAffixPath.Replace(".dic", ".aff");

	ISpellChecker* pTemp = CreateSpellCheckerInterface(m_sEnginePath, sAffixPath, szDicPath);

	if (pTemp) // alls well
	{
		ReleaseSpellCheckerInterface(m_pSpellChecker);
		m_pSpellChecker = pTemp;
		pTemp = NULL;

		m_sSelDictionary = szDicPath;
		UpdateData(FALSE);

		// cle