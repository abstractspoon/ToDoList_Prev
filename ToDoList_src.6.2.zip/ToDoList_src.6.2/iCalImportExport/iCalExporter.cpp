// iCalExporter.cpp: implementation of the CiCalExporter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "iCalImportExport.h"
#include "iCalExporter.h"

#include "..\Shared\DateHelper.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CiCalExporter::CiCalExporter()
{
	
}

CiCalExporter::~CiCalExporter()
{
	
}

bool CiCalExporter::Export(const ITaskList* pSrcTaskFile, const char* szDestFilePath, BOOL /*bSilent*/)
{
	CStdioFile fileOut;
	
	if (fileOut.Open(szDestFilePath, CFile::modeCreate | CFile::modeWrite))
	{
		// header
		WriteString(fileOut, "BEGIN:VCALENDAR");
		WriteString(fileOut, "PRODID:iCalExporter (c) AbstractSpoon 2009");
		WriteString(fileOut, "VERSION:2.0.0");
		
		// export first task
		ExportTask(pSrcTaskFile, pSrcTaskFile->GetFirstTask(), "", fileOut);
		
		// footer
		WriteString(fileOut, "END:VCALENDAR");
		
		return true;
	}
	
	return false;
}

bool CiCalExporter::Export(const IMultiTaskList* pSrcTaskFile, const char* szDestFilePath, BOOL /*bSilent*/)
{
	CStdioFile fileOut;
	
	if (fileOut.Open(szDestFilePath, CFile::modeCreate | CFile::modeWrite))
	{
		// header
		WriteString(fileOut, "BEGIN:VCALENDAR");
		WriteString(fileOut, "PRODID:iCalExporter (c) AbstractSpoon 2009");
		WriteString(fileOut, "VERSION:2.0.0");
		
		for (int nTaskList = 0; nTaskList < pSrcTaskFile->GetTaskListCount(); nTaskList++)
		{
			const ITaskList* pTasks = pSrcTaskFile->GetTaskList(nTaskList);

			if (pTasks)
			{
				// export first task
				ExportTask(pTasks, pTasks->GetFirstTask(), "", fileOut);
			}
		}

		// footer
		WriteString(fileOut, "END:VCALENDAR");
		
		return true;
	}
	
	return false;
}

void CiCalExporter::ExportTask(const ITaskList* pSrcTaskFile, HTASKITEM hTask, const CString& sParentUID, CStdioFile& fileOut)
{
	if (!hTask)
		return;
	
	// attributes
	time_t tStartDate = pSrcTaskFile->GetTaskStartDate(hTask);
	time_t tDueDate = pSrcTaskFile->GetTaskDueDate(hTask);
	
	// if task only has a start date then make the due date the same as the start and vice versa
	if (tDueDate == 0 && tStartDate)
		tDueDate = tStartDate;
	
	else if (tStartDate == 0 && tDueDate)
		tStartDate = tDueDate;
	
	// construct a unique ID
	CString sUID, sFile = fileOut.GetFilePath();
    
	sFile.Replace("\\", "");
    sFile.Replace(":", "");
	sUID.Format("%ld@%s.com", pSrcTaskFile->GetTaskID(hTask), sFile);
		
	// tasks must have a start date or a due date or both
	if (tStartDate || tDueDate)
	{
		// header
		WriteString(fileOut, "BEGIN:VEVENT");
		
		COleDateTime dtStart(tStartDate);
		WriteString(fileOut, FormatDateTime("DTSTART", dtStart, TRUE));
		
		// neither Google Calendar not Outlook pay any attention to the 'DUE' tag so we won't either.
		// instead we use 'DTEND' to mark the duration of the task. There is also no way to mark a
		// task as complete so we ignore our completion status
		
		COleDateTime dtDue(tDueDate);
		WriteString(fileOut, FormatDateTime("DTEND", dtDue, FALSE));
		
		WriteString(fileOut, "SUMMARY:%s", pSrcTaskFile->GetTaskTitle(hTask));
		WriteString(fileOut, "DESCRIPTION:%s", pSrcTaskFile->GetTaskComments(hTask));
		WriteString(fileOut, "STATUS:%s", pSrcTaskFile->GetTaskStatus(hTask));
		WriteString(fileOut, "CATEGORIES:%s", pSrcTaskFile->GetTaskCategory(hTask));
		WriteString(fileOut, "URL:%s", pSrcTaskFile->GetTaskFileReferencePath(hTask));
		WriteString(fileOut, "ORGANIZER:%s", pSrcTaskFile->GetTaskAllocatedBy(hTask));
		WriteString(fileOut, "ATTENDEE:%s", pSrcTaskFile->GetTaskAllocatedTo(hTask));
		WriteString(fileOut, "UID:%s", sUID);

		// parent child relationship
		WriteString(fileOut, "RELATED-TO;RELTYPE=PARENT:%s", sParentUID);
		
		// footer
		WriteString(fileOut, "END:VEVENT");
	}
	
	// copy across first child
	ExportTask(pSrcTaskFile, pSrcTaskFile->GetFirstTask(hTask), sUID, fileOut);
	
	// copy across first sibling
	ExportTask(pSrcTaskFile, pSrcTaskFile->GetNextTask(hTask), sParentUID, fileOut);
}

CString CiCalExporter::FormatDateTime(LPCTSTR szType, const COleDateTime& date, BOOL bStartOfDay)
{
	CString sDateTime;

	if (CDateHelper::DateHasTime(date))
	{
		sDateTime.Format("%s;VALUE=DATE-TIME:%04d%02d%02dT%02d%02d%02d", szType, 
						date.GetYear(), date.GetMonth(), date.GetDay(),
						date.GetHour(), date.GetMinute(), date.GetSecond());
	}
	else // no time component
	{
		if (bStartOfDay)
		{
			sDateTime.Format("%s;VALUE=DATE:%04d%02d%02dT000000", szType, 
						date.GetYear(), date.GetMonth(), date.GetDay());
		}
		else // end of day
		{
			sDateTime.Format("%s;VALUE=DATE:%04d%02d%02dT240000", szType, 
						date.GetYear(), date.GetMonth(), date.GetDay());
		}
	}

	return sDateTime;
}

void __cdecl CiCalExporter::WriteString(CStdioFile& fileOut, LPCTSTR lpszFormat, ...)
{
	ASSERT(AfxIsValidString(lpszFormat));
	CString sLine;
	
	va_list argList;
	va_start(argList, lpszFormat);
	sLine.FormatV(lpszFormat, argList);
	va_end(argList);
	
	sLine.TrimRight();
	
	// write line out in pieces no longer than 75 bytes
	while (sLine.GetLength() > 75)
	{
		CString sTemp = sLine.Left(75);
		sLine = sLine.Mid(75);
		
		fileOut.WriteString(sTemp);
		fileOut.WriteString("\n ");
	}
	
	// write out whatever's left
	fileOut.WriteString(sLine);
	fileOut.WriteString("\n");
}
