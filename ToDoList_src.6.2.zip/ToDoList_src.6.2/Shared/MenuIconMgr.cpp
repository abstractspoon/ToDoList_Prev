
BaseClass=CDialog
HeaderFile=TDLPrefMigrationDlg.h
ImplementationFile=TDLPrefMigrationDlg.cpp

[CLS:CTDLPrintDialog]
Type=0
BaseClass=CDialog
HeaderFile=TDLPrintDialog.h
ImplementationFile=TDLPrintDialog.cpp

[CLS:CTDLPriorityComboBox]
Type=0
BaseClass=CColorComboBox
HeaderFile=TDLPriorityComboBox.h
ImplementationFile=TDLPriorityComboBox.cpp

[CLS:CTDLReuseRecurringTaskDlg]
Type=0
BaseClass=CDialog
HeaderFile=TDLReuseRecurringTaskDlg.h
ImplementationFile=TDLReuseRecurringTaskDlg.cpp

[CLS:CTDLRiskComboBox]
Type=0
BaseClass=CComboBox
HeaderFile=TDLRiskComboBox.h
ImplementationFile=TDLRiskComboBox.cpp

[CLS:CTDLSendTasksDlg]
Type=0
BaseClass=CDialog
HeaderFile=TDLSendTasksDlg.h
ImplementationFile=TDLSendTasksDlg.cpp

[CLS:CTDLSetReminderDlg]
Type=0
BaseClass=CDialog
HeaderFile=TDLSetReminderDlg.h
ImplementationFile=TDLSetReminderDlg.cpp

[CLS:CTDLShowReminderDlg]
Type=0
BaseClass=CDialog
HeaderFile=TDLShowReminderDlg.h
ImplementationFile=TDLShowReminderDlg.cpp

[CLS:CTDLTaskIconDlg]
Type=0
BaseClass=CDialog
HeaderFile=TDLTaskIconDlg.h
ImplementationFile=TDLTaskIconDlg.cpp

[CLS:CTDLTransformDialog]
Type=0
BaseClass=CDialog
HeaderFile=TDLTransformDialog.h
ImplementationFile=TDLTransformDialog.cpp

[CLS:CToDoCommentsCtrl]
Type=0
BaseClass=CUrlRichEditCtrl
HeaderFile=todocommentsctrl.h
ImplementationFile=todocommentsctrl.cpp

[CLS:CToDoCtrl]
Type=0
BaseClass=CRuntimeDlg
HeaderFile=ToDoCtrl.h
ImplementationFile=ToDoCtrl.cpp

[CLS:CToDoCtrlReminders]
Type=0
BaseClass=CWnd
HeaderFile=ToDoCtrlReminders.h
ImplementationFile=ToDoCtrlReminders.cpp

[CLS:CToDoListApp]
Type=0
BaseClass=CWinApp
HeaderFile=ToDoList.h
ImplementationFile=ToDoList.cpp

[CLS:CToDoListWnd]
Type=0
BaseClass=CFrameWnd
HeaderFile=ToDoListWnd.h
ImplementationFile=ToDoListWnd.cpp

[CLS:CToolsUserInputDlg]
Type=0
BaseClass=CRuntimeDlg
HeaderFile=ToolsUserInputDlg.h
ImplementationFile=ToolsUserInputDlg.cpp

[CLS:CWelcomeWizard]
Type=0
HeaderFile=WelcomeWizard.h
ImplementationFile=WelcomeWizard.cpp

[CLS:CWelcomePage1]
Type=0
HeaderFile=WelcomeWizard.h
ImplementationFile=WelcomeWizard.cpp

[CLS:CWelcomePage2]
Type=0
HeaderFile=WelcomeWizard.h
ImplementationFile=WelcomeWizard.cpp

[CLS:CWelcomePage3]
Type=0
HeaderFile=WelcomeWizard.h
ImplementationFile=WelcomeWizard.cpp

[DLG:IDD_KEYBOARDSHORTCUTDISPLAYDIALOG]
Type=1
Class=CKeyboardShortcutDisplayDlg
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDC_SHORTCUTS,SysListView32,1350680581
Control3=IDC_COPYSHORTCUTS,button,1342242816

[DLG:IDD_OFFSETDATES_DIALOG]
Type=1
Class=COffsetDatesDlg
ControlCount=13
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_OFFSETSTARTDATE,button,1342242819
Control4=IDC_STATIC,static,1342308352
Control5=IDC_OFFSETDUEDATE,button,1342242819
Control6=IDC_OFFSETDONEDATE,button,1342242819
Control7=IDC_STATIC,static,1342308352
Control8=IDC_STATIC,static,1342308352
Control9=IDC_DIRECTION,combobox,1344340227
Control10=IDC_BY,edit,1350639744
Control11=IDC_BYUNITS,combobox,1344339971
Control12=IDC_STATIC,static,1342177296
Control13=IDC_OFFSETSUBTASKS,button,1342242819

[DLG:IDD_PREFERENCES]
Type=1
Class=CPreferencesDlg
ControlCount=8
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_HELP2,button,1342242816
Control4=IDC_PAGES,SysTreeView32,1350635568
Control5=IDC_HOSTFRAME,static,1207959559
Control6=IDC_STATIC,static,1342177296
Control7=IDC_STATIC,static,1342312960
Control8=IDC_APPLY,button,1342242816

[DLG:IDD_PREFEXPORT_PAGE]
Type=1
Class=CPreferencesExportPage
ControlCount=19
Control1=IDC_PREVIEWEXPORT,button,1342251011
Control2=IDC_EXPORTVISIBLEONLY,button,1342242819
Control3=IDC_EXPORTPARENTTITLECOMMENTSONLY,button,1342252035
Control4=IDC_EXPORTSPACEFORNOTES,button,1342242819
Control5=IDC_NUMLINESPACE,edit,1350639744
Control6=IDC_STATIC,static,1342308352
Control7=IDC_HTMLFONTLIST,combobox,1344340227
Control8=IDC_STATIC,static,1342308352
Control9=IDC_HTMLFONTSIZE,combobox,1344339971
Control10=IDC_STATIC,static,1342308352
Control11=IDC_CHARSET,edit,1350631552
Control12=IDC_TABTEXTINDENT,button,1342308361
Control13=IDC_SPACETEXTINDENT,button,1342177289
Control14=IDC_TABWIDTHS,edit,1350639744
Control15=IDC_STATIC,static,1342177297
Control16=IDC_STATIC,button,1342177287
Control17=IDC_STATIC,button,1342177287
Control18=IDC_TEXTINDENTTRAIL,static,1342308352
Control19=IDC_NUMLINESPACETRAIL,static,1342308352

[DLG:IDD_PREFFILE2_PAGE]
Type=1
Class=CPreferencesFile2Page
ControlCount=22
Control1=IDC_BACKUPGROUP,static,1342308352
Control2=IDC_BACKUPONSAVE,button,1342242819
Control3=IDC_BACKUPLOCATIONLABEL,static,1342308352
Control4=IDC_BACKUPLOCATION,edit,1350631552
Control5=IDC_BACKUPCOUNTLABEL,static,1342308352
Control6=IDC_NUMBACKUPSTOKEEP,combobox,1344339971
Control7=IDC_BACKUPCOUNTTRAIL,static,1342308352
Control8=IDC_SAVEGROUP,static,1342308352
Control9=IDC_AUTOSAVE,button,1342242819
Control10=IDC_AUTOSAVEFREQUENCY,combobox,1344339971
Control11=IDC_AUTOSAVEONSWITCHTASKLIST,button,1342242819
Control12=IDC_AUTOSAVEONSWITCHAPP,button,1342242819
Control13=IDC_AUTOEXPORT,button,1342242819
Control14=IDC_HTMLEXPORT,button,1342308361
Control15=IDC_OTHEREXPORT,button,1342177289
Control16=IDC_USESTYLESHEETFORSAVE,button,1342373891
Control17=IDC_SAVEEXPORTSTYLESHEET,edit,1350631552
Control18=IDC_OTHEREXPORTERS,combobox,1344339971
Control19=IDC_EXPORTFILTERED,button,1342242819
Control20=IDC_EXPORTTOFOLDER,button,1342242819
Control21=IDC_EXPORTFOLDER,edit,1350631552
Control22=IDC_STATIC,static,1342177297

[DLG:IDD_PREFFILE_PAGE]
Type=1
Class=CPreferencesFilePage
ControlCount=23
Control1=IDC_LOADGROUP,static,1342308352
Control2=IDC_NOTIFYREADONLY,button,1342243843
Control3=IDC_NOTIFYDUEONLOAD,button,1342243843
Control4=IDC_NOTIFYDUEBYONLOAD,combobox,1344339971
Control5=IDC_AUTOARCHIVE,button,1342242819
Control6=IDC_REFRESHFINDTASKS,button,1342242819
Control7=IDC_EXPANDTASKS,button,1342242819
Control8=IDC_ARCHIVEGROUP,static,1342308352
Control9=IDC_REMOVEARCHIVEDITEMS,button,1342373891
Control10=IDC_DONTREMOVEFLAGGED,button,1342242819
Control11=IDC_REMOVEONLYONABSCOMPLETION,button,1342252035
Control12=IDC_WARNADDDELARCHIVE,button,1342252035
Control13=IDC_SWITCHGROUP,static,1342308352
Control14=IDC_NOTIFYDUEONSWITCH,button,1342243843
Control15=IDC_NOTIFYDUEBYONSWITCH,combobox,1344339971
Control16=IDC_DUEGROUP,static,1342308352
Control17=IDC_DISPLAYDUETASKSINHT