 | DT_NOPREFIX);
		
		// draw a horizontal dividing line
		pDC->DrawText(sText, rLabel, DT_TOP | DT_LEFT | DT_END_ELLIPSIS | DT_NOPREFIX | DT_CALCRECT);
		pDC->FillSolidRect(rLabel.right + 6, rLabel.top + rLabel.Height() / 2, rItem.right - rLabel.right, 1, GetSysColor(COLOR_3DSHADOW));
		
		pDC->RestoreDC(nSave);
	}
}

COLORREF CTDLFindResultsListCtrl::GetItemTextColor(int nItem, int nSubItem, BOOL bSelected, BOOL bDropHighlighted, BOOL bWndFocus) const
{
   if (!bSelected && !bDropHighlighted)
   {
      FTDRESULT* pRes = (FTDRESULT*)GetItemData(nItem);

      if (pRes && pRes->bDone && nSubItem == 0 && m_crDone != (COLORREF)-1)
         return m_crDone;
   }

   // else
   return CEnListCtrl::GetItemTextColor(nItem, nSubItem, bSelected, bDropHighlighted, bWndFocus);
}

CFont* CTDLFindResultsListCtrl::GetItemFont(int nItem, int nSubItem)
{
	FTDRESULT* pRes = GetResult(nItem);

	if (pRes && pRes->bDone && nSubItem == 0 && m_fontStrike.GetSafeHandle())
		return &m_fontStrike;

	// else
	return CEnListCtrl::GetItemFont(nItem, nSubItem);
}

void CTDLFindResultsListCtrl::RefreshUserPreferences()
{
	CPreferences prefs;
	
	// update user completed tasks colour
	if (prefs.GetProfileInt("Preferences", "SpecifyDoneColor", FALSE))
		m_crDone = (COLORREF)prefs.GetProfileInt("Preferences\\Colors", "TaskDone", -1);
	else
		m_crDone = (COLORREF)-1;

	// update strike thru font
	if (prefs.GetProfileInt("Preferences", "StrikethroughDone", FALSE))
	{
		if (!m_fontStrike.GetSafeHandle())
			GraphicsMisc::CreateFont(m_fontStrike, (HFONT)SendMessage(WM_GETFONT), MFS_STRIKETHRU);
	}
	else
		m_fontStrike.DeleteObject();

	if (IsWindowVisible())
		Invalidate();
}

int CTDLFindResultsListCtrl::AddResult(const SEARCHRESULT& result, LPCTSTR szTask, LPCTSTR /*szPath*/, const CFilteredToDoCtrl* pTDC)
{
	int nPos = GetItemCount();
		
	// add result
	int nIndex = InsertItem(nPos, szTask);
	SetItemText(nIndex, 1, Misc::FormatArray(result.aMatched));
	UpdateWindow();
		
	// map identifying data
	FTDRESULT* pRes = new FTDRESULT(result.dwID, pTDC, result.HasFlag(RF_DONE));
	SetItemData(nIndex, (DWORD)pRes);

	return nIndex;
}

BOOL CTDLFindResultsListCtrl::AddHeaderRow(LPCTSTR szText, BOOL bSpaceAbove)
{
	int nPos = GetItemCount();

	// add space above?
	if (bSpaceAbove)
	{
		int nIndex = InsertItem(nPos, "");
		SetItemData(nIndex, 0);
		nPos++;
	}
	
	// add result
	int nIndex = InsertItem(nPos, szText);
	SetItemData(nIndex, 0);

	// bold font for rendering
	if (m_fontBold.GetSafeHandle() == NULL)
		GraphicsMisc::CreateFont(m_fontBold, (HFONT)SendMessage(WM_GETFONT), MFS_BOLD);

	return (nIndex != -1);
}

                                              