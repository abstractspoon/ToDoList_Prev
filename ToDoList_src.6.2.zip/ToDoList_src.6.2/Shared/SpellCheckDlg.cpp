);
		}
		break;

	case ANDOR:
		{
			ASSERT (ctrl.IsKindOf(RUNTIME_CLASS(CComboBox)));
			CComboBox* pCombo = (CComboBox*)&ctrl;

			if (sp.bAnd)
				pCombo->SelectString(-1, CEnString(IDS_FP_AND));
			else
				pCombo->SelectString(-1, CEnString(IDS_FP_OR));
		}
		break;

	case VALUE:
		switch (sp.GetAttribType())
		{
		case FT_DATE:
			ASSERT (&ctrl == &m_dtDate);

			// if the rule does not yet have a date then set it now to
			// the current date because that's whats the date ctrl will default to
			if (sp.dValue <= 0)
			{
				sp.dValue = COleDateTime::GetCurrentTime();
				SetItemText(nRow, nCol, COleDateTime(sp.dValue).Format(VAR_DATEVALUEONLY));
			}
			else
				m_dtDate.SetTime(sp.dValue);
			break;

		case FT_TIME:
			ASSERT (&ctrl == &m_eTime);
			m_eTime.SetTime(sp.dValue, sp.dwFlags);
			break;
		}
		break;

	}
}

void CTDLFindTaskExpressionListCtrl::ValidateListData() const
{
#ifdef _DEBUG
	for (int nRule = 0; nRule < GetRuleCount(); nRule++)
	{
		const SEARCHPARAM& rule = m_aSearchParams[nRule];

		// check matching attribute text 
		CString sRuleAttrib = GetAttribName(rule.attrib);
		CString sListAttrib = GetItemText(nRule, ATTRIB);
		ASSERT (sRuleAttrib == sListAttrib);

		// check matching operator text 
		CString sRuleOp = GetOpName(rule.op);
		CString sListOp = GetItemText(nRule, OPERATOR);
		ASSERT (sListOp.IsEmpty() || sRuleOp == sListOp);

		// check valid operator
		ASSERT(rule.HasValidOperator());
	}
#endif
}

void CTDLFindTaskExpressionListCtrl::HideControl(CWnd& ctrl)
{
	if (ctrl.IsWindowVisible())
	{
		ctrl.ShowWindow(SW_HIDE);
		ctrl.EnableWindow(FALSE);
	}
}

void CTDLFindTaskExpressionListCtrl::OnAttribEditCancel()
{
	HideControl(m_cbAttributes);
}

void CTDLFindTaskExpressionListCtrl::OnAttribEditOK()
{
	HideControl(m_cbAttributes);

	// update attribute type
	int nSel = m_cbAttributes.GetCurSel();

	if (nSel != CB_ERR)
	{
		CString sSel;
		m_cbAttributes.GetLBText(nSel, sSel);

		int nRow = GetCurSel();
		SetItemText(nRow, ATTRIB, sSel);

		// keep data store synched
		TDC_ATTRIBUTE attrib = (TDC_ATTRIBUTE)m_cbAttributes.GetItemData(nSel);
		m_aSearchParams[nRow].SetAttribute(attrib);

		// clear the operator cell text if the operator was no longer valid
		if (m_aSearchParams[nRow].op == FO_NONE)
			SetItemText(nRow, OPERATOR, "");

		ValidateListData();
	}
}

BOOL CTDLFindTaskExpressionListCtrl::OnSelItemChanged(NMHDR* /*pNMHDR*/, LRESULT* pResult) 
{
//	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
//	int nRow = pNMListView->iItem;

	// always make sure we hide the datetime ctrl and the time edit
	HideControl(m_dtDate);
	HideControl(m_eTime);

	*pResult = 0;
	
	return FALSE; // continue routing
}

void CTDLFindTaskExpressionListCtrl::OnValueEditOK(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;
	
	int nRow = pDispInfo->item.iItem;
	int nCol = pDispInfo->item.iSubItem;

	ASSERT (nCol == VALUE);

	SEARCHPARAM& sp = m_aSearchParams[nRow];
	
	switch (sp.GetAttribType())
	{
	case FT_STRING:
		sp.sValue = pDispInfo->item.pszText;
		break;
		
	case FT_INTEGER:
		sp.nValue = atoi(pDispInfo->item.pszText);
		break;
		
	case FT_DOUBLE:
		sp.dValue = atof(pDispInfo->item.pszText);
		break;
		
	case FT_DATE:
	case FT_BOOL:
		// not handled here
		break;
	}
		
	*pResult = 0;
}

void CTDLFindTaskExpressionListCtrl::OnOperatorEditCancel()
{
	HideControl(m_cbOperators);
}

void CTDLFindTaskExpressionListCtrl::OnOperatorEditOK()
{
	HideControl(m_cbOperators);

	// update operator type
	int nSel = m_cbOperators.GetCurSel();

	if (nSel != CB_ERR)
	{
		CString sSel;
		m_cbOperators.GetLBText(nSel, sSel);

		int nRow = GetCurSel();
		SetItemText(nRow, OPERATOR, sSel);

		// keep data store synched
		FIND_OPERATOR nOp = (FIND_OPERATOR)m_cbOperators.GetItemData(nSel);
		SEARCHPARAM& rule = m_aSearchParams[nRow];

		rule.SetOperator(nOp);

		// if the op is set/notset then clear the field
		if (nOp == FO_SET || nOp == FO_NOT_SET)
		{
			rule.dValue = 0.0;
			rule.nValue = 0;
			rule.sValue.Empty();

			SetItemText(nRow, VALUE, "");
		}

		ValidateListData();
	}
}

void CTDLFindTaskExpressionListCtrl::OnAndOrEditCancel()
{
	HideControl(m_cbAndOr);
}

void CTDLFindTaskExpressionListCtrl::OnAndOrEditOK()
{
	HideControl(m_cbAndOr);

	// update operator type
	int nSel = m_cbAndOr.GetCurSel();

	if (nSel != CB_ERR)
	{
		CString sSel;
		m_cbAndOr.GetLBText(nSel, sSel);

		int nRow = GetCurSel();
		SetItemText(nRow, ANDOR, sSel);

		// keep data store synched
		m_aSearchParams[nRow].bAnd = m_cbAndOr.GetItemData(nSel);

		ValidateListData();
	}
}

void CTDLFindTaskExpressionListCtrl::BuildListCtrl()
{
	DeleteAllItems();

	for (int nParam = 0; nParam < GetRuleCount(); nParam++)
	{
		SEARCHPARAM& sp = m_aSearchParams[nParam];

		// attrib
		CString sAttrib = GetAttribName(sp.attrib);
		int nItem = InsertItem(nParam, sAttrib);

		// operator
		CString sOp = GetOpName(sp.op);
		SetItemText(nItem, OPERATOR, sOp);

		// and/or (but not for last row)
		if (nParam < GetRuleCount() - 1)
		{
			CEnString sAndOr(sp.bAnd ? IDS_FP_AND : IDS_FP_OR);
			SetItemText(nItem, ANDOR, sAndOr);
		}

		// value
		CString sValue;

		try
		{
			switch (sp.GetAttribType())
			{
			case FT_STRING:
			case FT_INTEGER:
			case FT_DOUBLE:
				sValue = sp.ValueAsString();
				break;
				
			case FT_DATE:
				if (sp.op == FO_SET || sp.op == FO_NOT_SET)
				{
					// handled by operator
				}
				else
					sValue = COleDateTime(sp.dValue).Format(VAR_DATEVALUEONLY);
				break;
				
			case FT_TIME:
				sValue = CTimeHelper().FormatTime(sp.dValue, sp.dwFlags, 2);
				break;
				
			case FT_BOOL:
				// handled by operator
				break;
			}

			SetItemText(nItem, VALUE, sValue);
		}
		catch (...)
		{
			// bad value but we continue
		}
	}

	ValidateListData();
	SetCurSel(0);
}

CString CTDLFindTaskExpressionListCtrl::GetAttribName(TDC_ATTRIBUTE attrib)
{
	int nAttrib = ATTRIB_COUNT;

	while (nAttrib--)
	{
		if (ATTRIBUTES[nAttrib].attrib == attrib)
		{
			if (ATTRIBUTES[nAttrib].nAttribResID)
				return CEnString(ATTRIBUTES[nAttrib].nAttribResID);
			else
				return "";
		}
	}

	ASSERT (0); // not found
	return "";
}

CString CTDLFindTaskExpressionListCtrl::GetOpName(FIND_OPERATOR op)
{
	int nOp = OP_COUNT;

	while (nOp--)
	{
		if (OPERATORS[nOp].op == op)
		{
			if (OPERATORS[nOp].nOpResID)
				return CEnString(OPERATORS[nOp].nOpResID);
			else
				return "";
		}
	}

	ASSERT (0); // not found
	return "";
}

void CTDLFindTaskExpressionListCtrl::OnDateChange(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMDATETIMECHANGE pDTHDR = (LPNMDATETIMECHANGE)pNMHDR;
	COleDateTime dt(pDTHDR->st);

	// update the rule 
	int nRow = GetCurSel();

	m_aSearchParams[nRow].dValue = dt.m_dt;
	SetItemText(nRow, VALUE, dt.Format(VAR_DATEVALUEONLY));
	
	*pResult = 0;
}

void CTDLFindTaskExpressionListCtrl::OnDateCloseUp(NMHDR* /*pNMHDR*/, LRESULT* pResult)
{
//	LPNMDATETIMECHANGE pDTHDR = (LPNMDATETIMECHANGE)pNMHDR;

	HideControl(m_dtDate);
	
	*pResult = 0;
}


void CTDLFindTaskExpressionListCtrl::OnKillFocus(CWnd* pNewWnd) 
{
	CInputListCtrl::OnKillFocus(pNewWnd);
	
	if (pNewWnd != &m_dtDate)
		HideControl(m_dtDate);

	if (pNewWnd != &m_eTime)
		HideControl(m_eTime);
}

void CTDLFindTaskExpressionListCtrl::OnTimeChange()
{
	// update the rule 
	int nRow = GetCurSel();
	SEARCHPARAM& rule = m_aSearchParams[nRow];

	rule.dValue = m_eTime.GetTime();
	rule.dwFlags = m_eTime.GetUnits();

	SetItemText(nRow, VALUE, CTimeHelper().FormatTime(rule.dValue, rule.dwFlags, 3));
}

LRESULT CTDLFindTaskExpressionListCtrl::OnTimeUnitsChange(WPARAM /*wp*/, LPARAM /*lp*/)
{
	// update the rule 
	int nRow = GetCurSel();
	SEARCHPARAM& rule = m_aSearchParams[nRow];

	rule.dwFlags = m_eTime.GetUnits();
	SetItemText(nRow, VALUE, CTimeHelper().FormatTime(rule.dValue, rule.dwFlags, 3));

	return 0L;
}

void CTDLFindTaskExpressionListCtrl::OnSize(UINT nType, int cx, int cy) 
{
	CInputListCtrl::OnSize(nType, cx, cy);
	
	// resize columns by proportion
	SetColumnWidth(ATTRIB, (int)(cx * COL_PROPORTIONS[ATTRIB]));
	SetColumnWidth(OPERATOR, (int)(cx * COL_PROPORTIONS[OPERATOR]));
	SetColumnWidth(VALUE, (int)(cx * COL_PROPORTIONS[VALUE]));
	SetColumnWidth(ANDOR, (int)(cx * COL_PROPORTIONS[ANDOR]));
	
}

void CTDLFindTaskExpressionListCtrl::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	int nItem, nCol;
	GetCurSel(nItem, nCol);
	
	if (GetRuleCount() > 0 || nCol == ATTRIB)
	{
		// if the user typed an alphanumeric char then begin editing automatically
		// numeric keys only work for value column
		if (isalpha(nChar) || (nCol == VALUE && isdigit(nChar)))
		{
			EditCell(nItem, nCol);

			// forward key down on to edit control
			CWnd* pEdit = GetEditControl(nItem, nCol);

			if (pEdit)
			{
				pEdit->PostMessage(WM_CHAR, nChar, MAKELPARAM(nRepCnt, nFlags));
				return; // eat it
			}
		}
	}
	
	CInputListCtrl::OnKeyDown(nChar, nRepCnt, nFlags);
}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                 g.DoModal() == IDOK)
				m_sEnginePath = dialog.GetPathName();
			else
				bCancel = TRUE;
		}
	}

	if (bCancel)
	{
		EndDialog(IDCANCEL);
		return FALSE;
	}

	// make the rich edit appear disabled if not using text
	if (m_pSpellCheck != &m_reSpellCheck)
		m_reText.SetBackgroundColor(FALSE, GetSysColor(COLOR_3DFACE));

	if (IsInitialized() || InitDictionary(m_sSelDictionary))
	{
		if (!StartChecking() && m_bEndOnNoErrors)
		{
			EndDialog(IDNOERRORS);
			return FALSE;
		}
	}

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}

CString CSpellCheckDlg::GetItemText(UINT nIDItem, LPCTSTR szDefault)
{
	CString sText;
	s_mapText.Lookup(nIDItem, sText);
	
	if (sText.IsEmpty() && szDefault)
		return szDefault;

	return sText;
}

void CSpellCheckDlg::SetItemText(UINT nIDItem, UINT nIDText)
{
	CString sText;
	sText.LoadString(nIDText);
	s_mapText[nIDItem] = sText;
}

BOOL CSpellCheckDlg::StartChecking(CHECKFROM nFrom)
{
	CString sWord; 

	BOOL bMisspelt = FindNextMisspeltWord(sWord, nFrom);

	// if starting from the beginning and no misspelt words are found
	// then e return FALSE to indicate no further checking required
	if (nFrom == CH_START && !bMisspelt)
		return FALSE;

	else if (bMisspelt)
	{
		ProcessMisspeltWord(sWord);
		return TRUE;
	}

	// else reached the end so start again
	ProcessMisspeltWord("");

	return StartChecking(CH_START);
}

void CSpellCheckDlg::ProcessMisspeltWord(LPCTSTR szWord)
{
	if (!szWord || !*szWord) // no misspelling
	{
		m_lbSuggestions.ResetContent();
		GetDlgItem(IDC_SCD_REPLACE)->EnableWindow(FALSE);

		m_sMisspeltWord.Empty();
		UpdateData(FALSE);

		return;
	}

	// else
	m_sMisspeltWord.Format("'%s'", szWord);
	UpdateData(FALSE);

	// set new selection
	HighlightWord(TRUE);

	// add suggestions
	m_lbSuggestions.ResetContent();

	if (m_pSpellChecker)
	{
		char** pSuggestions = NULL;
		int nNumSuggestions = 0;

		m_pSpellChecker->CheckSpelling(szWord, pSuggestions, nNumSuggestions);

		for (int nSugg = 0; nSugg < nNumSuggestions; nSugg++)
			m_lbSuggestions.AddString(pSuggestions[nSugg]);

		m_pSpellChecker->FreeSuggestions(pSuggestions);
	}

	if (m_lbSuggestions.GetCount())
		m_lbSuggestions.GetText(0, m_sSuggestion);
	else
		m_sSuggestion.Empty();

	m_lbSuggestions.SelectString(-1, m_sSuggestion);
	GetDlgItem(IDC_SCD_REPLACE)->EnableWindow(m_lbSuggestions.GetCount());
}

void CSpellCheckDlg::Highl#if !defined(AFX_FINDTASKEXPRESSIONLISTCTRL_H__42272309_6C54_4901_A56D_D6FDA87F1E48__INCLUDED_)
#define AFX_FINDTASKEXPRESSIONLISTCTRL_H__42272309_6C54_4901_A56D_D6FDA87F1E48__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FindTaskExpressionListCtrl.h : header file
//

#include "tdcenum.h"
#include "tdcstruct.h"
#include "..\shared\InputListCtrl.h"
#include "..\shared\timeedit.h"

#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////
// CTDLFindTaskExpressionListCtrl window

class CTDLFindTaskExpressionListCtrl : public CInputListCtrl
{
// Construction
public:
	CTDLFindTaskExpressionListCtrl();

	void SetSearchParams(const SEARCHPARAM& param);
	void SetSearchParams(const CSearchParamArray& params);
	int GetSearchParams(CSearchParamArray& params) const;

	void ClearSearch();

	BOOL AddRule();
	BOOL DeleteSelectedRule();
	BOOL CanDeleteSelectedRule() const { return CanDeleteSelectedCell(); }
	BOOL HasRules() const { return m_aSearchParams.GetSize(); }

	void MoveSelectedRuleUp();
	BOOL CanMoveSelectedRuleUp() const;
	void MoveSelectedRuleDown();
	BOOL CanMoveSelectedRuleDown() const;

	void EndEdit();

// Attributes
protected:
	CComboBox	m_cbOperators;
	CComboBox	m_cbAttributes;
	CComboBox	m_cbAndOr;
	CDateTimeCtrl m_dtDate;
	CTimeEdit	m_eTime;

	CSearchParamArray m_aSearchParams;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTDLFindTaskExpressionListCtrl)
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTDLFindTaskExpressionListCtrl();

	// Generated message map f