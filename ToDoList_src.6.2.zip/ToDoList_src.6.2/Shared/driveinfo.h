// TaskListCsvImporter.h: interface for the CTaskListCsvImporter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TASKLISTCSVIMPORTER_H__ADF211CB_FBD2_42A2_AD51_DFF58E566753__INCLUDED_)
#define AFX_TASKLISTCSVIMPORTER_H__ADF211CB_FBD2_42A2_AD51_DFF58E566753__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "tdcenum.h"
#include "TDLCsvImportExportDlg.h"

#include "..\shared\Itasklist.h"
#include "..\shared\IImportExport.h"

class CTaskListCsvImporter : public IImportTasklist  
{
public:
	CTaskListCsvImporter();
	virtual ~CTaskListCsvImporter();

	const char* GetMenuText() { return "Spreadsheet"; }
	const char* GetFileFilter() { return "Spreadsheet Files (*.csv)|*.csv||"; }
	const char* GetFileExtension() { return "csv"; }

	bool Import(const char* szSrcFilePath, ITaskList* pDestTaskFile);
    void Release() { delete this; }

protected:
	LPCTSTR DELIM;
	CString INDENT;
	int ROOTDEPTH;

	CTDCCsvColumnMapping m_aColumnMapping;

p