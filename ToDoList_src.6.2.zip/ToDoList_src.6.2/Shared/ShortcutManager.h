w = InsertItem(nRow, GetAttribName(sp.attrib));
	SetItemText(nNew, OPERATOR, GetOpName(sp.op));

	CString sValue;

	switch (sp.GetAttribType(sp.attrib))
	{
	case FT_STRING:
	case FT_INTEGER:
	case FT_DOUBLE:
		sValue = sp.ValueAsString();
		break;
		
	case FT_DATE:
		sValue = COleDateTime(sp.dValue).Format(VAR_DATEVALUEONLY);
		break;
		
	case FT_TIME:
		sValue = CTimeHelper().FormatTime(sp.dValue, sp.dwFlags, 2);
		break;
		
	case FT_BOOL:
		// handled by operator
		break;
	}
	SetItemText(nNew, VALUE, sValue);
	
	// omit and/or for last rule
	if (nRow < GetRuleCount() - 1)
	{
		CEnString sAndOr(sp.bAnd ? IDS_FP_AND : IDS_FP_OR);
		SetItemText(nNew, ANDOR, sAndOr);
	}

	return nNew;
}

BOOL CTDLFindTaskExpressionListCtrl::CanMoveSelectedRuleUp() const
{
	int nRow = GetCurSel();

	return (nRow > 0 && nRow < GetRuleCount());
}

void CTDLFindTaskExpressionListCtrl::MoveSelectedRuleDown()
{
	if (CanMoveSelectedRuleDown())
	{
		int nRow, nCol;
		GetCurSel(nRow, nCol);

		// save off rule
		SEARCHPARAM sp = m_aSearchParams[nRow];

		// delete rule
		m_aSearchParams.RemoveAt(nRow);
		DeleteItem(nRow);

		// reinsert rule
		nRow = InsertRule(nRow + 1, sp);
	
		// sanity check
		ValidateListData();

		// restore selection
		SetCurSel(nRow, nCol);
		EnsureVisible(nRow, FALSE);
	}
}

BOOL CTDLFindTaskExpressionListCtrl::CanMoveSelectedRuleDown() const
{
	return (GetCurSel() < GetRuleCount() - 1);
}

void CTDLFindTaskExpressionListCtrl::ShowControl(CWnd& ctrl, int nRow, int nCol)
{
	PrepareControl(ctrl, nRow, nCol);

	CRect rCell;
	GetCellEditRect(nRow, nCol, rCell);

	if (ctrl.IsKindOf(RUNTIME_CLASS(CComboBox)))
		rCell.bottom += 200;
//	else
//		rCell.bottom++;

	ctrl.MoveWindow(rCell);
	ctrl.EnableWindow(TRUE);
	ctrl.ShowWindow(SW_SHOW);
	ctrl.SetFocus();

	if (ctrl.IsKindOf(RUNTIME_CLASS(CComboBox)))
	{
		CComboBox* pCombo = (CComboBox*)&ctrl;
		pCombo->ShowDropDown(TRUE);
	}
	else //if (ctrl.IsKindOf(RUNTIME_CLASS(CDateTimeCtrl)))
	{
		//CDateTimeCtrl* pDateTime = (CDateTimeCtrl*)&ctrl;
	}
}

void CTDLFindTaskExpressionListCtrl::PrepareControl(CWnd& ctrl, int nRow, int nCol)
{
	if (!GetRuleCount())
		return;

	SEARCHPARAM& sp = m_aSearchParams[nRow];

	switch (nCol)
	{
	case ATTRIB:
		{
			ASSERT (ctrl.IsKindOf(RUNTIME_CLASS(CComboBox)));
			CComboBox* pCombo = (CComboBox*)&ctrl;
	
			if (sp.GetAttribType() != FT_NONE)
				pCombo->SelectString(-1, GetAttribName(sp.attrib));
			else
				pCombo->SetCurSel(-1);
		}
		break;

	case OPERATOR:
		{
			ASSERT (ctrl.IsKindOf(RUNTIME_CLASS(CComboBox)));
			CComboBox* pCombo = (CComboBox*)&ctrl;

			pCombo->ResetContent();
			
			FIND_ATTRIBTYPE nType = sp.GetAttribType();

			switch (nType)
			{
			