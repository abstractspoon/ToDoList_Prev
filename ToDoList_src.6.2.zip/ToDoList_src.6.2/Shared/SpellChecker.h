#if !defined(AFX_TDLIMPORTDIALOG_H__F3B10AEE_B46C_4183_AC05_FB72D7C5AFA4__INCLUDED_)
#define AFX_TDLIMPORTDIALOG_H__F3B10AEE_B46C_4183_AC05_FB72D7C5AFA4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TDLImportDialog.h : header file
//

#include "..\shared\fileedit.h"
#include "..\shared\importexportmgr.h"

/////////////////////////////////////////////////////////////////////////////
// CTDLImportDialog dialog

enum TDLID_IMPORTTO
{
	TDIT_NEWTASKLIST,
	TDIT_TOPTASKLIST,
	TDIT_SELECTEDTASK,
};

class CTDLImportDialog : public CDialog
{
// Construction
public:
	CTDLImportDialog(const CImportExportMgr& mgr, CWnd* pParent = NULL);   // standard constructor

	BOOL ImportTasklist() const;
	int GetImporterIndex() const; // returns -1 if 'ToDoList'
	TDLID_IMPORTTO GetImportTo() const;
	BOOL GetImportFromClipboard() const;
	CString GetImportFilePath() const;
	CString GetImportClipboardText() const