// TDLContentMgr.cpp: implementation of the CTDLContentMgr class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "todolist.h"
#include "TDLContentMgr.h"
#include "ToDoCommentsCtrl.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////

class CDefaultContent : public IContent
{
	const char* GetTypeID() const { static LPCTSTR sID = "PLAIN_TEXT"; return sID; }
	const char* GetTypeDescription() const { static LPCTSTR sDesc = "Simple Text"; return sDesc; }

	IContentControl* CreateCtrl(unsigned short nCtrlID, unsigned long nStyle, 
						long nLeft, long nTop, long nWidth, long nHeight, HWND hwndParent)
	{
		CToDoCommentsCtrl* pComments = new CToDoCommentsCtrl;

		nStyle |= ES_MULTILINE | ES_WANTRETURN | WS_VSCROLL;
		CRect rect(nLeft, nTop, nLeft + nWidth, nTop + nHeight);

		if (pComments->Create(nStyle, rect, CWnd::FromHandle(hwndParent), nCtrlID))
			return pComments;

		// else
		delete pComments;
		return NULL;
	}

	void Release() { delete this; }

	int ConvertToHtml(const unsigned char* /*pContent*/, int /*nLength*/, const char* /*szCharset*/,
						char*& /*szHtml*/) { return 0; } // not supported

//	void SetIniLocation(bool /*bRegistry*/, const char* /*szIniPathName*/) {}


};

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTDLContentMgr::CTDLContentMgr() 
{

}

CTDLContentMgr::~CTDLContentMgr()
{

}

BOOL CTDLContentMgr::Initialize()
{
	BOOL bWasInitialized = m_bInitialized;

	if (CContentMgr::Initialize())
	{
		if (!bWasInitialized)
			m_aContent.InsertAt(0, new CDefaultContent);
		
		return TRUE;
	}

	return FALSE;
}
                                                                                                                            ENT)GetProcAddress(hDll, "CreateContentInterface");
		FreeLibrary(hDll);

		return (pCreate != NULL);
	}

	return FALSE;
}

class IContent  
{
public:
	virtual const char* GetTypeID() const = 0;
	virtual const char* GetTypeDescription() const = 0;

	virtual IContentControl* CreateCtrl(unsigned short nCtrlID, unsigned long nStyle, 
						long nLeft, long nTop, long nWidth, long nHeight, HWND hwndParent) = 0;

	virtual void Release() = 0;
	
	// returns the length of the html or zero if not supported
	virtual int ConvertToHtml(const unsigned char* pContent, int nLength,
							  const char* szCharSet, char*& pHtml) = 0;
};

class ISpellCheck;
struct UITHEME;

class IContentControl  
{
public:
	// custom/binary data format
	virtual int GetContent(unsigned char* pContent) const = 0;
	virtual bool SetContent(unsigned char* pContent, int nLength, BOOL bResetSelection) = 0;
	virtual const char* GetTypeID() const = 0;

	// text content if supported. return false if not supported
	virtual int GetTextContent(char* szContent, int nLength = -1) const = 0;
	virtual bool SetTextContent(const char* szContent, BOOL bResetSelection) = 0;

	virtual void SetReadOnly(bool bReadOnly) = 0;
	virtual HWND GetHwnd() const = 0;

	virtual void Release() = 0;
	virtual bool ProcessMessage(MSG* pMsg) = 0;

	virtual ISpellCheck* GetSpellCheckInterface() = 0;
	
	virtual bool Undo() = 0;
	virtual bool Redo() = 0;
	
	virtual void SetUITheme(const UITHEME* pTheme) = 0;

	virtual void SavePreferences(IPreferences* pPrefs, LPCTSTR szKey) const = 0;
	virtual void LoadPreferences(const IPreferences* pPrefs, LPCTSTR szKey) = 0;
};

#endif // AFX_ICONTENTCONTROL_H__7741547B_BA15_4851_A41B_2B4EC1DC12D5__INCLUDED_
