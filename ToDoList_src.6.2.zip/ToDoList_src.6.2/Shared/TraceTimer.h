// TraceTimer.h: interface for the CTraceTimer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRACETIMER_H__F7453F0F_769F_4646_BFA8_6B955A3DC387__INCLUDED_)
#define AFX_TRACETIMER_H__F7453F0F_769F_4646_BFA8_6B955A3DC387__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTraceTimer  
{
public:
	CTraceTimer();
	virtual ~CTraceTimer();

};

#endif // !defined(AFX_TRACETIMER_H__F7453F0F_769F_4646_BFA8_6B955A3DC387__INCLUDED_)
