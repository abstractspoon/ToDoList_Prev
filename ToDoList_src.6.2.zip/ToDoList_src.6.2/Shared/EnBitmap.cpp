 not already in use
	int nExist = FindMappedAttribute(sSel, nRow);
	
	if (nExist != -1)
	{
		// clear it
		SetItemText(nExist, EXPORT_COLUMNNAME, "");
		m_aMapping[nExist].sColumnName.Empty();
	}
	
	SetItemText(nRow, EXPORT_COLUMNNAME, sSel);
	m_aMapping[nRow].sColumnName = sSel;

	*pResult = 0;
}

                                                                                                                                                                                                    ef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

const int HIMETRIC_INCH	= 2540;

enum 
{
	FT_BMP,
	FT_ICO,
	FT_JPG,
	FT_GIF,
	FT_PNG,

	FT_UNKNOWN
};

///////////////////////////////////////////////////////////////////////

C32BitImageProcessor::C32BitImageProcessor(BOOL bEnableWeighting) : m_bWeightingEnabled(bEnableWeighting)
{
}

C32BitImageProcessor::~C32BitImageProcessor()
{
}

CSize C32BitImageProcessor::CalcDestSize(CSize sizeSrc) 
{ 
	return sizeSrc; // default
}

BOOL C32BitImageProcessor::ProcessPixels(RGBX* pSrcPixels, CSize /*sizeSrc*/, RGBX* pDestPixels, 
										CSize sizeDest, COLORREF /*crMask*/)
{ 
	CopyMemory(pDestPixels, pSrcPixels, sizeDest.cx * 4 * sizeDest.cy); // default
	return TRUE;
}
 
// C32BitImageProcessor::CalcWeightedColor(...) is inlined in EnBitmap.h

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEnBitmap::CEnBitmap(COLORREF crBkgnd) : m_crBkgnd(crBkgnd)
{

}

CEnBitmap::~CEnBitmap()
{

}

BOOL CEnBitmap::LoadImage(UINT uIDRes, LPCTSTR szResourceType, HMODULE hInst, COLORREF crBack)
{
	ASSERT(m_hObject == NULL);      // only attach once, detach on destroy

	if (m_hObject != NULL)
		return FALSE;

	return Attach(LoadImageResource(uIDRes, szResourceType, hInst, crBack == -1 ? m_crBkgnd : crBack));
}

BOOL CEnBitmap::LoadImage(LPCTSTR szImagePath, COLORREF crBack)
{
	ASSERT(m_hObject == NULL);      // only attach once, detach on destroy

	if (m_hObject != NULL)
		return FALSE;

	return Attach(LoadImageFile(szImagePath, crBack == -1 ? m_crBkgnd : crBack));
}

HBITMAP CEnBitmap::LoadImageFile(LPCTSTR szImagePath, COLORREF crBack)
{
	int nType = GetFileType(szImagePath);

	switch (nType)
	{
		case FT_BMP:
			// the reason for this is that i suspect it is more efficient to load
			// bmps this way since it avoids creating device contexts etc that the 
			// IPicture methods requires. that method however is still valuable
			// since it handles other image types and transparency
			return (HBITMAP)::LoadImage(NULL, szImagePath, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_LOADMAP3DCOLORS);

		case FT_UNKNOWN:
			break;

		default: // all the rest
		{
			USES_CONVERSION;
			IPicture* pPicture = NULL;
			
			HBITMAP hbm = NULL;
			HRESULT hr = OleLoadPicturePath(T2OLE(szImagePath), NULL, 0, crBack, IID_IPicture, (LPVOID*)&pPicture);
					
			if (SUCCEEDED(hr) && pPicture)
			{
				hbm = ExtractBitmap(pPicture, crBack);
				pPicture->Release();
			}

			return hbm;
		}
	}

	return NULL;
}

HBITMAP CEnBitmap::LoadImageResource(UINT uIDRes, LPCTSTR szResourceType, HMODULE hInst, COLORREF crBack)
{
	BYTE* pBuff = NULL;
	int nSize = 0;
	HBITMAP hbm = NULL;

	// first call is to get buffer size
	if (GetResource(MAKEINTRESOURCE(uIDRes), szResourceType, hInst, 0, nSize))
	{
		if (nSize > 0)
		{
			pBuff = new BYTE[nSize];
			
			// this loads it
			if (GetResource(MAKEINTRESOURCE(uIDRes), szResourceType, hInst, pBuff, nSize))
			{
				IPicture* pPicture = LoadFromBuffer(pBuff, nSize);

				if (pPicture)
				{
					hbm = ExtractBitmap(pPicture, crBack);
					pPicture->Release();
				}
			}
			
			delete [] pBuff;
		}
	}

	return hbm;
}

IPicture* CEnBitmap::LoadFromBuffer(BYTE* pBuff, int nSize)
{
	HGLOBAL hGlobal = GlobalAlloc(GMEM_MOVEABLE, nSize);
	void* pData = GlobalLock(hGlobal);
	memcpy(#if !defined(AFX_TDLCSVCOLUMNSETUPLISTCTRL_H__E379E120_FF91_417F_ADBB_0DD6A98089AA__INCLUDED_)
#define AFX_TDLCSVCOLUMNSETUPLISTCTRL_H__E379E120_FF91_417F_ADBB_0DD6A98089AA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TDLCsvColumnSetupListCtrl.h : header file
//

#include "tdcenum.h"

#include "..\shared\InputListCtrl.h"

/////////////////////////////////////////////////////////////////////////////
// CTDLCsvAttributeSetupListCtrl window

struct CSVCOLUMNMAPPING
{
	CSVCOLUMNMAPPING() : nTDCAttrib(TDCA_NONE) {}
	CSVCOLUMNMAPPING(const CString& sName, TDC_ATTRIBUTE tdcAttrib) 
	{ 
		sColumnName = sName; 
		nTDCAttrib = tdcAttrib;
	}

	TDC_ATTRIBUTE nTDCAttrib;
	CString sColumnName;
};

typedef CArray<CSVCOLUMNMAPPING, CSVCOLUMNMAPPING&> CTDCCsvColumnMapping;

class CTDLCsvAttributeSetupListCtrl : public CInputListCtrl
{
// Construction
public:
	CTDLCsvAttributeSetupListCtrl(BOOL bImporting);

	void SetColumnMapping(const CTDCCsvColumnMapping& aMapping);
	int GetColumnMapping(CTDCCsvColumnMapping& aMapping) const;

// attributes
protected:
	CComboBox m_cbAttributes;
	CTDCCsvColumnMapping m_aMapping;
	BOOL m_bImporting;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTDLCsvAttributeSetupListCtrl)
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTDLCsvAttributeSetupListCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CTDLCsvAttributeSetupListCtrl)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	afx_msg void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	afx_msg void OnAttribEditCancel();
	afx_msg void OnAttribEditOK();
	afx_msg void OnNameEditOK(NMHDR* pNMHDR, LRESULT* pResult);

	DECLARE_MESSAGE_MAP()

protected:
	void BuildListCtrl();
	
	virtual void EditCell(int nItem, int nCol);
	virtual BOOL IsEditing() const;
	virtual BOOL CanDeleteSelectedCell() const;
	virtual BOOL DeleteSelectedCell();
	virtual BOOL CanEditSelectedCell() const;

	void PrepareEdit(int nRow, int nCol);

	int FindMappedAttribute(TDC_ATTRIBUTE nAttrib, int nIgnoreRow = -1) const;
	int FindMappedAttribute(const CString& sName, int nIgnoreRow = -1) const;

	static CString GetAttributeName(TDC_ATTRIBUTE nAttrib);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TDLCSVCOLUMNSETUPLISTCTRL_H__E379E120_FF91_417F_ADBB_0DD6A98089AA__INCLUDED_)
                                                                                                                                                                                                                                                                                                                                                                                     

	// else
	return FT_UNKNOWN;
}

BOOL CEnBitmap::ProcessImage(C32BitImageProcessor* pProcessor, COLORREF crMask)
{
	C32BIPArray aProcessors;

	aProcessors.Add(pProcessor);

	return ProcessImage(aProcessors, crMask);
}

BOOL CEnBitmap::ProcessImage(C32BIPArray& aProcessors, COLORREF crMask)
{
	ASSERT (GetSafeHandle());

	if (!GetSafeHandle())
		return FALSE;

	if (!aProcessors.GetSize())
		return TRUE;

	int nProcessor, nCount = aProcessors.GetSize();

	// retrieve src and final dest sizes
	BITMAP BM;

	if (!GetBitmap(&BM))
		return FALSE;

	CSize sizeSrc(BM.bmWidth, BM.bmHeight);
	CSize sizeDest(sizeSrc), sizeMax(sizeSrc);

	for (nProcessor = 0; nProcessor < nCount; nProcessor++)
	{
		sizeDest = aProcessors[nProcessor]->CalcDestSize(sizeDest);
		sizeMax = CSize(max(sizeMax.cx, sizeDest.cx), max(sizeMax.cy, sizeDest.cy));
	}

	// prepare src and dest bits
	RGBX* pSrcPixels = GetDIBits32();

	if (!pSrcPixels)
		return FALSE;

	RGBX* pDestPixels = new RGBX[sizeMax.// TDLCsvImportExportDlg.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "TDLCsvImportExportDlg.h"
#include "tdcstatic.h"

#include "..\shared\misc.h"
#include "..\shared\filemisc.h"
#include "..\shared\preferences.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTDLCsvImportExportDlg dialog

CTDLCsvImportExportDlg::CTDLCsvImportExportDlg(const CString& sFilePath, CWnd* pParent /*=NULL*/)
	: CDialog(IDD_CSVIMPORTEXPORT_DIALOG, pParent), 
	m_sFilePath(sFilePath), m_lcColumnSetup(TRUE), m_bImporting(TRUE), m_eFilePath(FES_NOBROWSE)
{
	m_bAlwaysExportTaskIDs = TRUE;
	m_sDelim = Misc::GetListSeparator();

	LoadMasterColumnMapping();

	// user mapping
	CTDCCsvColumnMapping aMapping;
	BuildImportColumnMapping(aMapping);
	m_lcColumnSetup.SetColumnMapping(aMapping);
}

CTDLCsvImportExportDlg::CTDLCsvImportExportDlg(const CString& sFilePath, const CTDCAttributeArray& aExportAttributes, CWnd* pParent /*=NULL*/)
	: CDialog(IDD_CSVIMPORTEXPORT_DIALOG, pParent), 
	m_sFilePath(sFilePath), m_lcColumnSetup(FALSE), m_bImporting(FALSE), m_eFilePath(FES_NOBROWSE)
{
	m_bAlwaysExportTaskIDs = TRUE;
	m_sDelim = Misc::GetListSeparator();
	m_aExportAttributes.Copy(aExportAttributes);

	LoadMasterColumnMapping();

	// user mapping
	CTDCCsvColumnMapping aMapping;
	BuildExportColumnMapping(aMapping);
	m_lcColumnSetup.SetColumnMapping(aMapping);
}


void CTDLCsvImportExportDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTDLCsvImportExportDlg)
	DDX_Text(pDX, IDC_CSVDELIMITER, m_sDelim);
	DDX_Text(pDX, IDC_CSVFILEPATH, m_sFilePath); 
	DDX_Control(pDX, IDC_CSVFILEPATH, m_eFilePath);
	DDX_Control(pDX, IDC_COLUMNSETUP, m_lcColumnSetup);
	DDX_Check(pDX, IDC_EXPORTTASKIDS, m_bAlwaysExportTaskIDs);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTDLCsvImportExportDlg, CDialog)
	//{{AFX_MSG_MAP(CTDLCsvImportExportDlg)
	ON_EN_CHANGE(IDC_CSVDELIMITER, OnChangeCsvdelimiter)
	ON_BN_CLICKED(IDC_EXPORTTASKIDS, OnExportTaskids)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTDLCsvImportExportDlg message handlers

BOOL CTDLCsvImportExportDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	SetWindowText(CEnString(m_bImporting ? IDS_CSV_IMPORTDLG : IDS_CSV_EXPORTDLG));

	GetDlgItem(IDC_EXPORTTASKIDS)->EnableWindow(!m_bImporting);
	GetDlgItem(IDC_EXPORTTASKIDS)->ShowWindow(m_bImporting ? SW_HIDE : SW_SHOW);

	if (!m_bImporting)
		OnExportTaskids();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

int CTDLCsvImportExportDlg::GetColumnMapping(CTDCCsvColumnMapping& aMapping) const 
{ 
	return m_lcColumnSetup.GetColumnMapping(aMapping);
}

void CTDLCsvImportExportDlg::OnChangeCsvdelimiter() 
{
	CString sOldDelim = m_sDelim;
	UpdateData();

	if (m_bImporting && m_sDelim != sOldDelim)
	{
		CTDCCsvColumnMapping aMapping;
		
		if (BuildImportColumnMapping(aMapping))
			m_lcColumnSetup.SetColumnMapping(aMapping);
	}
}

void CTDLCsvImportExportDlg::BuildDefaultMasterColumnMapping()
{
	m_aMasterColumnMapping.RemoveAll();

	for (int nCol = 0; nCol < ATTRIB_COUNT; nCol++)
	{
		TDC_ATTRIBUTE attrib = ATTRIBUTES[nCol].attrib;
		CEnString sName(ATTRIBUTES[nCol].nAttribResID);

		m_aMasterColumnMapping.Add(CSVCOLUMNMAPPING(sName, attrib));
	}
}

int CTDLCsvImportExportDlg::BuildImportColumnMapping(CTDCCsvColumnMapping& aImportMapping) const
{
	ASSERT (m_bImporting);
	ASSERT(!m_sFilePath.IsEmpty());

	// read first few lines from file
	CStringArray aLines;
	
	if (!FileMisc::LoadFileLines(m_sFilePath, aLines, 5))
		return FALSE;
	
	CStringArray aColumnHeaders;
	
	if (!Misc::Split(aLines[0], aColumnHeaders, TRUE, m_sDelim))
		return FALSE;
	
	// build column mapping from file attributes
	for (int nCol = 0; nCol < aColumnHeaders.GetSize(); nCol++)
	{
		CString sName = aColumnHeaders[nCol];
		ASSERT (!sName.IsEmpty());
		
		// try to map text column names to column IDs
		aImportMapping.Add(CSVCOLUMNMAPPING(sName, GetMasterColumnAttribute(sName)));
	}

	return aImportMapping.GetSize();
}

int CTDLCsvImportExportDlg::BuildExportColumnMapping(CTDCCsvColumnMapping& aExportMapping) const
{
	ASSERT (!m_bImporting);

	// build column mapping from passed in attributes
	for (int nAttrib = 0; nAttrib < m_aExportAttributes.GetSize(); nAttrib++)
	{
		TDC_ATTRIBUTE attrib = m_aExportAttributes[nAttrib];
		ASSERT(attrib != TDCA_NONE);

		// try to map text column names to column IDs
		aExportMapping.Add(CSVCOLUMNMAPPING(GetMasterColumnName(attrib), attrib));
	}

	return aExportMapping.GetSize();
}

void CTDLCsvImportExportDlg::OnOK()
{
	CDialog::OnOK();
	
	// save attribute mapping
	UpdateMasterColumnMappingFromList();
	SaveMaster