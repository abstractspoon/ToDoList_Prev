// TaskListCsvImporter.cpp: implementation of the CTaskListCsvImporter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TaskListCsvImporter.h"
#include "tdlschemadef.h"
#include "resource.h"
#include "recurringtaskedit.h"
#include "TDLCsvImportExportDlg.h"

#include <locale.h>

#include "..\shared\timehelper.h"
#include "..\shared\enstring.h"
#include "..\shared\misc.h"
#include "..\shared\filemisc.h"
#include "..\shared\Preferences.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const LPCTSTR SPACE = " ";
const LPCTSTR ENDL = "\n";
const LPCTSTR ONEDBLQUOTE = "\"";
const LPCTSTR TWODBLQUOTE = "\"\"";

// private structure for sorting
struct CSVSORT
{
	void Set(DWORD id, DWORD parentID, int originalLineIndex)
	{
		dwID = id;
		dwParentID = parentID;
		nOriginalLineIndex = originalLineIndex;
	}

	DWORD dwID;
	DWORD dwParentID;
	int nOriginalLineIndex;
};

////////////////////////////////////////////////////////

CTaskListCsvImporter::CTaskListCsvImporter()
{

}

CTaskListCsvImporter::~CTaskListCsvImporter()
{

}

void CTaskListCsvImporter::InitConsts()
{
	CPreferences prefs;

	DELIM = Misc::GetListSeparator();

	if (prefs.GetProfileInt("Preferences", "UseSpaceIndents", TRUE))
		INDENT = CString(' ', prefs.GetProfileInt("Preferences", "TextIndent", 2));
	else
		INDENT = "  "; // don't use tabs - excel strips them off
}

/*
void CTaskListCsvImporter::PreProcessFileLines(CStringArray& aLines) const
{
	// if we have parent ID then we need to sort the lines so that
	// the parent task occurs before its subtasks
	int nParentIDIndex = AttributeIndex(TDCA_PARENTID);

	if (nParentIDIndex == -1)
		return;

	int nIDIndex = AttributeIndex(TDCA_ID);

	// build an array that contains enough information to sort
	CArray<CSVSORT, CSVSORT&> aSortArray;
	int nLine, nNumLines = aLines.GetSize();

	aSortArray.SetSize(nNumLines);
	
	for (nLine = 0; nLine < nNumLines; nLine++)
	{
		CStringArray aColumns;
		Misc::Split(aLines[nLine], aColumn