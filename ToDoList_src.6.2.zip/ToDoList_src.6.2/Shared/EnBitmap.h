(nNameCol != -1)
		m_aMasterColumnMapping[nNameCol].nTDCAttrib = attrib;
}

void CTDLCsvImportExportDlg::SetMasterColumnName(TDC_ATTRIBUTE attrib, LPCTSTR szColumn)
{
	// prevent setting the master mapping to an empty name
	if (szColumn && *szColumn)
	{
		// check if the column name is already in use
		int nNameCol = FindMasterColumn(szColumn);
		int nAttribCol = FindMasterColumn(attrib);

		// and clear if it is
		if (nNameCol != -1 && nNameCol != nAttribCol)
			m_aMasterColumnMapping[nNameCol].sColumnName.Empty();

		// and set new name
		if (nAttribCol != -1)
			m_aMasterColumnMapping[nAttribCol].sColumnName = szColumn;
	}
}

int CTDLCsvImportExportDlg::FindMasterColumn(TDC_ATTRIBUTE attrib) const
{
	int nColumns = m_aMasterColumnMapping.GetSize();

	for (int nCol = 0; nCol < nColumns; nCol++)
	{
		if (m_aMasterColumnMapping[nCol].nTDCAttrib == attrib)
			return nCol;
	}

	// else
	return -1;
}

int CTDLCsvImportExportDlg::FindMasterColumn(LPCTSTR szColumn) const
{
	int nColumns = m_aMasterColumnMapping.GetSize();

	for (int nCol = 0; nCol < nColumns; nCol++)
	{
		if (m_aMasterColumnMapping[nCol].sColumnName.CompareNoCase(szColumn) == 0)
			return nCol;
	}

	// else
	return -1;
}

void CTDLCsvImportExportDlg::OnExportTaskids() 
{
	ASSERT(!m_bImporting);

	UpdateData();

	CTDCCsvColumnMapping aMapping;
	m_lcColumnSetup.GetColumnMapping(aMapping);

	if (!m_bAlwaysExportTaskIDs)
	{
		// Find if these attributes were originally present
		BOOL bWantTaskID = FALSE, bWantParentID = FALSE;

		for (int nAttrib = 0; nAttrib < m_aExportAttributes.GetSize(); nAttrib++)
		{
			if (!bWantTaskID)
				bWantTaskID = (m_aExportAttributes[nAttrib] == TDCA_ID);

			if (!bWantParentID)
				bWantParentID = (m_aExportAttributes[nAttrib] == TDCA_PARENTID);
		}

		// if attribute was not present in original attributes then remove
		int nCol = aMapping.GetSize();

		while (nCol--)
		{
			TDC_ATTRIBUTE attrib = aMapping[nCol].nTDCAttrib;

			if (attrib == TDCA_ID && !bWantTaskID)
				aMapping.RemoveAt(nCol);

			else if (attrib == TDCA_PARENTID && !bWantParentID)
				aMapping.RemoveAt(nCol);
		}
	}
	else // always include
	{
		// find out what's already present
		int nTaskID = -1, nParentTaskID = -1;

		for (int nCol = 0; nCol < aMapping.GetSize() && (nTaskID == -1 || nParentTaskID == -1); nCol++)
		{
			TDC_ATTRIBUTE attrib = aMapping[nCol].nTDCAttrib;

			if (attrib == TDCA_ID)
				nTaskID = nCol;

			else if (attrib == TDCA_PARENTID)
				nParentTaskID = nCol;
		}

		// Add TaskID and/or ParentTaskID if not present
		if (nTaskID == -1)
			aMapping.Add(CSVCOLUMNMAPPING(GetMasterColumnName(TDCA_ID), TDCA_ID)); 

		if (nParentTaskID == -1)
			aMapping.Add(CSVCOLUMNMAPPING(GetMasterColumnName(TDCA_PARENTID), TDCA_PARENTID));
	}
	
	m_lcColumnSetup.SetColumnMapping(aMapping);
}
                                                                                                                                                             Fraction = dY - nY;
	double dY1MinusFraction = 1 - dYFraction;

	int nXP1 = min(nX + 1, size.cx - 1);
	int nYP1 = min(nY + 1, size.cy - 1);
	
	RGBX* pRGB = &pPixels[nY * size.cx + nX]; // x, y
	RGBX* pRGBXP = &pPixels[nY * size.cx + nXP1]; // x + 1, y
	RGBX* pRGBYP = &pPixels[nYP1 * size.cx + nX]; // x, y + 1
	RGBX* pRGBXYP = &pPixels[nYP1 * size.cx + nXP1]; // x + 1, y + 1
	
	int nRed = (int)(dX1MinusFraction * dY1MinusFraction * pRGB->btRed +
					dXFraction * dY1MinusFraction * pRGBXP->btRed +
					dX1MinusFraction * dYFraction * pRGBYP->btRed +
					dXFraction * dYFraction * pRGBXYP->btRed);
	
	int nGreen = (int)(dX1MinusFraction * dY1MinusFraction * pRGB->btGreen +
					dXFraction * dY1MinusFraction * pRGBXP->btGreen +
					dX1MinusFraction * dYFraction * pRGBYP->btGreen +
					dXFraction * dYFraction * pRGBXYP->btGreen);
	
	int nBlue = (int)(dX1MinusFraction * dY1MinusFraction * pRGB->btBlue +
					dXFraction * dY1MinusFraction * pRGBXP->btBlue +
					dX1MinusFraction * dYFraction#if !defined(AFX_TDLCSVIMPORTEXPORTDLG_H__3230FA12_9619_426A_9D8A_FC4D76A56596__INCLUDED_)
#define AFX_TDLCSVIMPORTEXPORTDLG_H__3230FA12_9619_426A_9D8A_FC4D76A56596__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TDLCsvImportExportDlg.h : header file
//

#include "TDLCsvAttributeSetu