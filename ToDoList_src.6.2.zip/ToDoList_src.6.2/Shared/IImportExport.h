// FilterBar.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "TDLFilterBar.h"
#include "tdcmsg.h"
#include "filteredtodoctrl.h"

#include "..\shared\deferwndmove.h"
#include "..\shared\dlgunits.h"
#include "..\shared\enstring.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

const int FILTERCTRLXSPACING = 6; // dlu
const int FILTERCTRLYSPACING = 2; // dlu

struct FILTERCTRL
{
	UINT nIDLabel;
	UINT nIDCtrl;
	int nLenLabelDLU;
	int nLenCtrlDLU;
	TDC_COLUMN nType;
};

static FILTERCTRL FILTERCTRLS[] = 
{
	{ IDC_FILTERLABEL, IDC_FILTERCOMBO, 22, 150, (TDC_COLUMN)-1 },
	{ IDC_TITLEFILTERLABEL, IDC_TITLEFILTERTEXT, 45, 75, (TDC_COLUMN)-1 },
	{ IDC_PRIORITYFILTERLABEL, IDC_PRIORITYFILTERCOMBO, 45, 75, TDCC_PRIORITY },
	{ IDC_RISKFILTERLABEL, IDC_RISKFILTERCOMBO, 45, 75, TDCC_RISK },
	{ IDC_ALLOCTOFILTERLABEL, IDC_ALLOCTOFILTERCOMBO, 45, 75, TDCC_ALLOCTO },
	{ IDC_ALLOCBYFILTERLABEL, IDC_ALLOCBYFILTERCOMBO, 45, 75, TDCC_ALLOCBY },
	{ IDC_STATUSFILTERLABEL, IDC_STATUSFILTERCOMBO, 45, 75, TDCC_STATUS },
	{ IDC_CATEGORYFILTERLABEL, IDC_CATEGORYFILTERCOMBO, 45, 75, TDCC_CATEGORY },
	{ IDC_VERSIONFILTERLABEL, IDC_VERSIONFILTERCOMBO, 45, 75, TDCC_VERSION },
	{ IDC_OPTIONFILTERLABEL, IDC_OPTIONFILTERCOMBO, 45, 75, (TDC_COLUMN)-1 }
};

const int NUMFILTERCTRLS = sizeof(FILTERCTRLS) / sizeof(FILTERCTRL);

#define WM_WANTCOMBOPROMPT (WM_APP+1)

/////////////////////////////////////////////////////////////////////////////
// CFilterBar dialog

CTDLFilterBar::CTDLFilterBar(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_FILTER_BAR, pParent), 
	  m_cbCategoryFilter(TRUE, IDS_NOCATEGORY, IDS_TDC_ANY),
	  m_cbAllocToFilter(TRUE, IDS_NOALLOCTO, IDS_TDC_ANYONE),
	  m_cbAllocByFilter(TRUE, IDS_NOONE, IDS_TDC_ANYONE),
	  m_cbStatusFilter(TRUE, IDS_NOSTATUS, IDS_TDC_ANY),
	  m_cbVersionFilter(TRUE, IDS_NOVERSION, IDS_TDC_ANY),
	  m_bShowDivider(TRUE),
	  m_nView(FTCV_UNSET),
	  m_bCustomFilter(FALSE)
{
	//{{AFX_DATA_INIT(CFilterBar)
	//}}AFX_DATA_INIT

	m_aVisibility.SetSize(TDCC_LAST);

	// add update button to title text
	m_eTitleFilter.AddButton(1, 0xC4, 
							CEnString(IDS_TDC_UPDATEFILTER_TIP),
							CALC_BTNWIDTH, "Wingdings");
}


void CTDLFilterBar::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFilterBar)
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_VERSIONFILTERCOMBO, m_cbVersionFilter);
	DDX_Control(pDX, IDC_OPTIONFILTERCOMBO, m_cbOptions);
	DDX_Control(pDX, IDC_FILTERCOMBO, m_cbTaskFilter);
	DDX_Control(pDX, IDC_ALLOCTOFILTERCOMBO, m_cbAllocToFilter);
	DDX_Control(pDX, IDC_ALLOCBYFILTERCOMBO, m_cbAllocByFilter);
	DDX_Control(pDX, IDC_CATEGORYFILTERCOMBO, m_cbCategoryFilter);
	DDX_Control(pDX, IDC_STATUSFILTERCOMBO, m_cbStatusFilter);
	DDX_Control(pDX, IDC_PRIORITYFILTERCOMBO, m_cbPriorityFilter);
	DDX_Control(pDX, IDC_RISKFILTERCOMBO, m_cbRiskFilter);
	DDX_Control(pDX, IDC_TITLEFILTERTEXT, m_eTitleFilter);
	DDX_Text(pDX, IDC_TITLEFILTERTEXT, m_filter.sTitle);
	
	// special handling
	if (pDX->m_bSaveAndValidate)
	{
		// filter
		m_filter.nFilter = m_cbTaskFilter.GetSelectedFilter();

		// priority
		int nIndex;
		DDX_CBIndex(pDX, IDC_PRIORITYFILTERCOMBO, nIndex);

		if (nIndex == 0) // any
			m_filter.nPriority = FT_ANYPRIORITY;

		else if (nIndex == 1) // none
			m_filter.nPriority = FT_NOPRIORITY;
		else
			m_filter.nPriority = nIndex - 2;

		// risk
		DDX_CBIndex(pDX, IDC_RISKFILTERCOMBO, nIndex);

		if (nIndex == 0) // any
			m_filter.nRisk = FT_ANYRISK;

		else if (nIndex == 1) // none
			m_filter.nRisk = FT_NORISK;
		else
			m_filter.nRisk = nIndex - 2;

		// cats
		m_cbCategoryFilter.GetChecked(m_filter.aCategories);

		// allocto
		m_cbAllocToFilter.GetChecked(m_filter.aAllocTo);

		// status
		m_cbStatusFilter.GetChecked(m_filter.aStatus);

		// allocby
		m_cbAllocByFilter.GetChecked(m_filter.aAllocBy);

		// version
		m_cbVersionFilter.GetChecked(m_filter.aVersions);

		// flags
		m_filter.dwFlags = m_cbOptions.GetOptio