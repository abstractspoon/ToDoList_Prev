ile2Page.cpp

[CLS:CPreferencesFilePage]
Type=0
BaseClass=CPreferencesPageBase
HeaderFile=PreferencesFilePage.h
ImplementationFile=PreferencesFilePage.cpp

[CLS:CPreferencesGenPage]
Type=0
BaseClass=CPreferencesPageBase
HeaderFile=PreferencesGenPage.h
ImplementationFile=PreferencesGenPage.cpp

[CLS:CPreferencesMultiUserPage]
Type=0
BaseClass=CPreferencesPageBase
HeaderFile=PreferencesMultiUserPage.h
ImplementationFile=PreferencesMultiUserPage.cpp

[CLS:CPreferencesShortcutsPage]
Type=0
BaseClass=CPreferencesPageBase
HeaderFile=PreferencesShortcutsPage.h
ImplementationFile=PreferencesShortcutsPage.cpp

[CLS:CPreferencesTaskCalcPage]
Type=0
BaseClass=CPreferencesPageBase
HeaderFile=PreferencesTaskCalcPage.h
ImplementationFile=PreferencesTaskCalcPage.cpp

[CLS:CPreferencesTaskDefPage]
Type=0
BaseClass=CPreferencesPageBase
HeaderFile=PreferencesTaskDefPage.h
ImplementationFile=PreferencesTaskDefPage.cpp

[CLS:CPreferencesTaskPage]
Type=0
BaseClass=CPreferencesPageBase
HeaderFile=PreferencesTaskPage.h
ImplementationFile=PreferencesTaskPage.cpp

[CLS:CPre