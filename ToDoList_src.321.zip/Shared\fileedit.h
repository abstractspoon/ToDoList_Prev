#if !defined(AFX_FILEEDIT_H__7A50F411_3AAE_4BC2_989A_53D44291B643__INCLUDED_)
#define AFX_FILEEDIT_H__7A50F411_3AAE_4BC2_989A_53D44291B643__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// fileedit.h : header file
//

#include "sysimagelist.h"

/////////////////////////////////////////////////////////////////////////////
// CFileEdit window

enum
{
	FES_NOBROWSE = 0x0001,
	FES_FOLDERS = 0x0002,
	FES_COMBOBORDERBROWSEBTN = 0x0004, // draws the browse button border like that of a combo box else like a std button
};

class CFileEdit : public CEdit
{
// Construction
public:
	CFileEdit(int nStyle = 0);

// Attributes
protected:
	BOOL m_bFirstShow;
	BOOL m_bBrowseButtonDown;
	int m_nStyle;
	CToolTipCtrl m_tooltip;
	BOOL m_bTipNeeded;
	CSysImageList m_ilSys;

	const UINT ICON_WIDTH;
	const UINT BUTTON_WIDTH;


// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileEdit)
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL
	virtual int OnToolHitTest(CPoint pt, TOOLINFO* pTI) const;

// Implementation
public:
	virtual ~CFileEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFileEdit)
	afx_msg void OnPaint();
	afx_msg void OnNcPaint();
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
	afx_msg void OnLButtonUp(UINT nHitTest, CPoint point);
	afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg UINT OnNcHitTest(CPoint point);
	afx_msg void OnMouseMove(UINT nHitTest, CPoint point);
	afx_msg BOOL OnChange();
	afx_msg void OnEnable(BOOL bEnable);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG
	afx_msg LRESULT OnSetText(WPARAM /*wp*/, LPARAM /*lp*/);
	afx_msg void OnNeedTooltip(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnShowTooltip(NMHDR* pNMHDR, LRESULT* pResult);
	DECLARE_MESSAGE_MAP()

protected:
	CRect GetBrowseButtonRect(); // screen coords
	CRect GetIconRect(); // client coords
	inline BOOL HasStyle(int nStyle) { return (m_nStyle & nStyle); }
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILEEDIT_H__7A50F411_3AAE_4BC2_989A_53D44291B643__INCLUDED_)
