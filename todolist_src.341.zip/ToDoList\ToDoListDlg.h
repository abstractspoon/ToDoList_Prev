// ToDoListDlg.h : header file
//

#if !defined(AFX_TODOLISTDLG_H__13051D32_D372_4205_BA71_05FAC2159F1C__INCLUDED_)
#define AFX_TODOLISTDLG_H__13051D32_D372_4205_BA71_05FAC2159F1C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "todoctrl.h"

#include "..\shared\trayicon.h"
#include "..\shared\toolbarhelper.h"
#include "..\shared\filemisc.h"
#include "..\shared\enstatic.h"
#include "..\shared\ShortcutManager.h"
#include "..\shared\driveinfo.h"

#include <afxadv.h> // for CRecentFileList

/////////////////////////////////////////////////////////////////////////////
// CToDoListDlg dialog

const UINT WM_TDL_SHOWWINDOW = ::RegisterWindowMessage("WM_TDL_SHOWWINDOW");

// WM_COPYDATA 
enum 
{
	OPENTASKLIST, // data is char[MAX_PATH]
};

class CPreferencesDlg;

class CToDoListDlg : public CDialog
{
// Construction
public:
	CToDoListDlg(BOOL bVisible = -1, LPCTSTR szTDListPath = NULL, CWnd* pParent = NULL); // standard constructor

protected:
// Dialog Data
	//{{AFX_DATA(CToDoListDlg)
	enum { IDD = IDD_TODOLIST_DIALOG };
	CEnStatic	m_stFilePath;
	CString	m_sCmdLineFilePath;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CToDoListDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL
	virtual void OnOK() {}
	virtual void OnCancel() {}
	virtual BOOL PreTranslateMessage(MSG* pMsg);

// Implementation
protected:
	HICON m_hIcon;
	CImageList m_ilTabCtrl;
	CString m_sStatus;
	CToolBar m_toolbar;
	CToolbarHelper m_tbHelper;
	CTrayIcon m_ti;
	BOOL m_bVisible;
	CRecentFileList m_mruList;
	CTabCtrl m_tabCtrl;
	int m_nLastSelItem; // just for flicker-free todoctrl switching
	BOOL m_bSimpleMode;
	BOOL m_bInNewTask;
	BOOL m_bSaving;
	BOOL m_bInTimer;
	CShortcutManager m_mgrShortcuts;

	struct TDCITEM
	{
		TDCITEM() 
		{ 
			pTDC = NULL; 
			bModified = FALSE; 
			bLastStatusReadOnly = -1; 
			tLastMod = 0; 
			bLastCheckoutSuccess = -1;
		}

		TDCITEM(CToDoCtrl* pCtrl) 
		{ 
			pTDC = pCtrl; 
			
			bModified = FALSE; 
			bLastStatusReadOnly = -1;
			tLastMod = 0;
			bLastCheckoutSuccess = -1;

			CString sFilePath = pCtrl->GetFilePath();

			if (!sFilePath.IsEmpty())
			{
				bLastStatusReadOnly = CDriveInfo::IsReadonlyPath(sFilePath);
				tLastMod = GetLastModified(sFilePath);
			}
		}

		CToDoCtrl* pTDC;
		BOOL bModified;
		BOOL bLastStatusReadOnly;
		time_t tLastMod;
		BOOL bLastCheckoutSuccess;

		inline CString GetFilePath() const { return pTDC->GetFilePath(); }
	};

	CArray<TDCITEM, TDCITEM&> m_aToDoCtrls;

	// Generated message map functions
	//{{AFX_MSG(CToDoListDlg)
	afx_msg void OnViewNext();
	afx_msg void OnUpdateViewNext(CCmdUI* pCmdUI);
	afx_msg void OnViewPrev();
	afx_msg void OnUpdateViewPrev(CCmdUI* pCmdUI);
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnUpdateImport(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDelete(CCmdUI* pCmdUI);
	afx_msg void OnUpdateNewtask(CCmdUI* pCmdUI);
	afx_msg void OnToolsCheckout();
	afx_msg void OnUpdateToolsCheckout(CCmdUI* pCmdUI);
	afx_msg void OnToolsCheckin();
	afx_msg void OnUpdateToolsCheckin(CCmdUI* pCmdUI);
	afx_msg void OnExport();
	afx_msg void OnUpdateExport(CCmdUI* pCmdUI);
	//}}AFX_MSG
	virtual BOOL OnInitDialog();
	afx_msg void OnDeleteTask();
	afx_msg void OnDeleteAllTasks();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnSave();
	afx_msg void OnLoad();
	afx_msg void OnDestroy();
	afx_msg void OnNew();
	afx_msg void OnUpdateDeletetask(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEdittask(CCmdUI* pCmdUI);
	afx_msg void OnUpdateTaskcolor(CCmdUI* pCmdUI);
	afx_msg void OnUpdateTaskdone(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDeletealltasks(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSave(CCmdUI* pCmdUI);
	afx_msg void OnUpdateNew(CCmdUI* pCmdUI);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnNewtaskAttop();
	afx_msg void OnNewtaskAtbottom();
	afx_msg void OnNewtaskAfterselectedtask();
	afx_msg void OnNewtaskBeforeselectedtask();
	afx_msg void OnUpdateSort(CCmdUI* pCmdUI);
	afx_msg void OnNewsubtaskAtbottom();
	afx_msg void OnNewsubtaskAttop();
	afx_msg void OnEditTaskcolor();
	afx_msg void OnEditTaskdone();
	afx_msg void OnEditTasktext();
	afx_msg void OnMovetaskdown();
	afx_msg void OnUpdateMovetaskdown(CCmdUI* pCmdUI);
	afx_msg void OnMovetaskup();
	afx_msg void OnUpdateMovetaskup(CCmdUI* pCmdUI);
	afx_msg void OnClose();
	afx_msg void OnTrayiconClose();
	afx_msg void OnWindowPosChanging(WINDOWPOS FAR* lpwndpos);
	afx_msg void OnUpdateNewsubtaskAtBottom(CCmdUI* pCmdUI);
	afx_msg void OnSaveas();
	afx_msg void OnUpdateSaveas(CCmdUI* pCmdUI);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg UINT OnGetDlgCode();
	afx_msg void OnTrayiconShow();
	afx_msg BOOL OnQueryEndSession();
	afx_msg void OnUpdateRecentFileMenu(CCmdUI* pCmdUI);
	afx_msg void OnAbout();
	afx_msg void OnPreferences();
	afx_msg BOOL OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct);
	afx_msg void OnEditCopy();
	afx_msg void OnEditPaste();
	afx_msg void OnEditCopyastext();
	afx_msg void OnEditCopyashtml();
	afx_msg void OnUpdateEditPaste(CCmdUI* pCmdUI);
	afx_msg void OnUpdateNewtaskAttop(CCmdUI* pCmdUI);
	afx_msg void OnUpdateNewtaskAtbottom(CCmdUI* pCmdUI);
	afx_msg void OnUpdateNewtaskAfterselectedtask(CCmdUI* pCmdUI);
	afx_msg void OnUpdateNewtaskBeforeselectedtask(CCmdUI* pCmdUI);
	afx_msg void OnUpdateNewsubtaskAttop(CCmdUI* pCmdUI);
	afx_msg void OnSimplemode();
	afx_msg void OnUpdateSimplemode(CCmdUI* pCmdUI);
	afx_msg void OnReload();
	afx_msg void OnUpdateReload(CCmdUI* pCmdUI);
	afx_msg void OnArchiveCompletedtasks();
	afx_msg void OnUpdateArchiveCompletedtasks(CCmdUI* pCmdUI);
	afx_msg void OnExportTohtml();
	afx_msg void OnUpdateExportTohtml(CCmdUI* pCmdUI);
	afx_msg void OnExportToplaintext();
	afx_msg void OnUpdateExportToplaintext(CCmdUI* pCmdUI);
	afx_msg void OnPrint();
	afx_msg void OnUpdatePrint(CCmdUI* pCmdUI);
	afx_msg void OnMovetaskright();
	afx_msg void OnUpdateMovetaskright(CCmdUI* pCmdUI);
	afx_msg void OnMovetaskleft();
	afx_msg void OnUpdateMovetaskleft(CCmdUI* pCmdUI);
	afx_msg void OnSelchangeTabcontrol(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangingTabcontrol(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCloseTasklist();
	afx_msg void OnSaveall();
	afx_msg void OnUpdateSaveall(CCmdUI* pCmdUI);
	afx_msg void OnCloseall();
	afx_msg void OnUpdateCloseall(CCmdUI* pCmdUI);
	afx_msg void OnExit();
	afx_msg void OnUpdateMovetask(CCmdUI* pCmdUI);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnImportTasklist();
	afx_msg void OnSortBy(UINT nCmdID);
	afx_msg void OnUpdateSortBy(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditTasktext(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
	afx_msg void OnTrayiconCreatetask();
	afx_msg void OnSetPriority(UINT nCmdUI);
	afx_msg void OnUpdateSetPriority(CCmdUI* pCmdUI);
	afx_msg void OnEditSetfileref();
	afx_msg void OnUpdateEditSetfileref(CCmdUI* pCmdUI);
	afx_msg void OnEditOpenfileref();
	afx_msg void OnUpdateEditOpenfileref(CCmdUI* pCmdUI);
	afx_msg void OnUpdateUserTool1(CCmdUI* pCmdUI);
	afx_msg void OnUserTool(UINT nCmdID);
	afx_msg void OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu);
	afx_msg void OnTrayIconClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTrayIconDblClk(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTrayIconRClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg LRESULT OnToDoCtrlNotifySort(WPARAM wp, LPARAM lp);
	afx_msg LRESULT OnToDoCtrlNotifyMod(WPARAM wp, LPARAM lp);
	afx_msg LRESULT OnToDoCtrlNotifyMinWidthChange(WPARAM wp, LPARAM lp);
	afx_msg LRESULT OnToDoListShowWindow(WPARAM wp, LPARAM lp);
	afx_msg BOOL OnOpenRecentFile(UINT nID);
	DECLARE_MESSAGE_MAP()

	// OnTimer helpers
	void OnTimerReadOnlyStatus();
	void OnTimerTimestampChange();
	void OnTimerAutoSave();
	void OnTimerCheckoutStatus();

	virtual void LoadSettings();
	virtual void SaveSettings();
	CRect OffsetCtrl(UINT uCtrlID, int cx = 0, int cy = 0);
	BOOL Export2Html(LPCTSTR szFilePath, BOOL bPreview, TDC_FILTER nFilter = TDCF_ALL);
	BOOL Export2Text(LPCTSTR szFilePath, BOOL bPreview, TDC_FILTER nFilter = TDCF_ALL);
	BOOL OpenTaskList(LPCTSTR szFilePath);
	BOOL OpenTaskList(CToDoCtrl* pCtrl, LPCTSTR szFilePath = NULL, LPCTSTR szArchivePath = NULL, TDC_ARCHIVE nRemove = TDC_REMOVEALL);
	void ReloadTaskList(TDCITEM& tdci);
	CString GetArchivePath(LPCTSTR szFilePath);
	BOOL DoSaveAs(int nType);
	void ResizeDlg(int cx = 0, int cy = 0, BOOL bMaximized = FALSE);
	BOOL NewTask(LPCTSTR szTitle, TDC_INSERTWHERE nInsertWhere);
	TDC_SORTBY GetSortBy(UINT nSortID);
	UINT GetSortID(TDC_SORTBY nSortBy);
	void ShowMenuBar(BOOL bShow);
	BOOL IsToolbarShowing() { return (m_toolbar.GetStyle() & WS_VISIBLE); }
	void CheckMinWidth();
	void MinimizeToTray(BOOL bAutoSave);
	void Show(BOOL bAllowToggle);

	CToDoCtrl& GetToDoCtrl();
	TDCITEM& GetTDCItem();
	TDCITEM& GetTDCItem(int nIndex);
	CToDoCtrl& GetToDoCtrl(int nIndex);
	CToDoCtrl* NewToDoCtrl();
	BOOL CreateToDoCtrl(CToDoCtrl* pCtrl);
	int AddToDoCtrl(CToDoCtrl* pCtrl);
	BOOL CloseToDoCtrl(int nIndex, BOOL bClosing);
	inline int GetTDCCount() { return m_aToDoCtrls.GetSize(); }
	BOOL SelectToDoCtrl(LPCTSTR szFilePath);
	void SelectToDoCtrl(int nIndex);
	void SetTimer(UINT nTimerID, BOOL bOn, UINT nPeriod = 1000);
	inline int GetSelToDoCtrl() const { return m_tabCtrl.GetCurSel(); }
	BOOL IsReadOnly(const CToDoCtrl* pCtrl) const;
	BOOL SaveTaskList(TDCITEM& tdci, LPCTSTR szFilePath = NULL); // returns FALSE only if the user was prompted to save and cancelled

	BOOL ItemSupportsSourceControl(const CToDoCtrl* pCtrl, const CPreferencesDlg* pPref = NULL) const;

	CString UpdateTabItemText(int nIndex = -1);
	void UpdateCaption();
	void UpdateStatusbar();
	void UpdateDefaultSortItem();
	void UpdateTabSwitchTooltip();

	void UpdateToDoCtrlPreferences(const CPreferencesDlg& pref);
	void UpdateToDoCtrlPreferences();

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TODOLISTDLG_H__13051D32_D372_4205_BA71_05FAC2159F1C__INCLUDED_)
