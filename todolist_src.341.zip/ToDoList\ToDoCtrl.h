#if !defined(AFX_TODOCTRL_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_)
#define AFX_TODOCTRL_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ToDoCtrl.h : header file
//

#include "TaskListDropTarget.h"

#include "..\shared\runtimedlg.h"
#include "..\shared\dialoghelper.h"
#include "..\shared\orderedtreectrl.h"
#include "..\shared\fileedit.h"
#include "..\shared\sysimagelist.h"

/////////////////////////////////////////////////////////////////////////////
// CToDoCtrl dialog

// notification messages
const UINT WM_TDCN_MODIFY = ::RegisterWindowMessage("WM_TDCN_MODIFY"); // lParam == <TDC_ATTRIBUTE>
const UINT WM_TDCN_SORT = ::RegisterWindowMessage("WM_TDCN_SORT"); 
const UINT WM_TDCN_MINWIDTHCHANGE = ::RegisterWindowMessage("WM_TDCN_MINWIDTHCHANGE"); 

enum TDC_ATTRIBUTE
{
	TDCA_NONE,
	TDCA_TASKNAME,
	TDCA_DONEDATE,
	TDCA_DUEDATE,
	TDCA_STARTDATE,
	TDCA_PRIORITY,
	TDCA_COLOR,
	TDCA_PERSON,
	TDCA_PERCENT,
	TDCA_TIMEEST,
	TDCA_FILEREF,
	TDCA_COMMENTS,
	TDCA_PROJNAME,
};

enum TDC_SORTBY
{
	TDC_SORTBYNONE,
	TDC_SORTBYNAME,
	TDC_SORTBYDONEDATE,
	TDC_SORTBYDUEDATE,
	TDC_SORTBYSTARTDATE,
	TDC_SORTBYPRIORITY,
	TDC_SORTBYCOLOR,
	TDC_SORTBYPERSON,
	TDC_SORTBYPERCENT,
	TDC_SORTBYTIMEEST,
	TDC_SORTBYID,
	TDC_SORTBYDONE,
};

enum TDC_INSERTWHERE
{
	TDC_INSERTATTOP,
	TDC_INSERTATBOTTOM,
	TDC_INSERTATTOPOFSELTASKPARENT,
	TDC_INSERTATBOTTOMOFSELTASKPARENT,
	TDC_INSERTAFTERSELTASK,
	TDC_INSERTBEFORESELTASK,
	TDC_INSERTATTOPOFSELTASK, // subtask
	TDC_INSERTATBOTTOMOFSELTASK, // subtask
};

enum TDC_FILTER
{
	TDCF_NONE,			// not very useful except to assist coding
	TDCF_ALL,
	TDCF_DUE,
	TDCF_DONE,
	TDCF_NOTDONE,
	TDCF_FULLYDONE,		// used for archiving == all subitems and siblings done
	TDCF_NOTFULLYDONE,	// used for archiving == !(all subitems and siblings done)
};

enum TDC_ARCHIVE
{
	TDC_REMOVENONE,
	TDC_REMOVEALL,
	TDC_REMOVEIFSIBLINGSANDSUBTASKSCOMPLETE,
};

enum TDC_STYLE
{
	TDCS_SHOWINFOTIPS					= 0x00000001,
	TDCS_COLORTEXTBYPRIORITY			= 0x00000002,
	TDCS_SIMPLEMODE						= 0x00000004,
	TDCS_SHOWCOMMENTSINLIST				= 0x00000008,
	TDCS_COLORPRIORITY					= 0x00000010,
	TDCS_TREATSUBCOMPLETEDASDONE		= 0x00000020,
	TDCS_HIDEPERCENTFORDONETASKS		= 0x00000040,
	TDCS_CONFIRMDELETE					= 0x00000080,
	TDCS_AVERAGEPERCENTSUBCOMPLETION	= 0x00000100,
	TDCS_INCLUDEDONEINAVERAGECALC		= 0x00000200,
	TDCS_FIXEDCOMMENTHEIGHT				= 0x00000400,
	TDCS_SHOWBUTTONSINTREE				= 0x00000800,
	TDCS_USEEARLIESTDUEDATE				= 0x00001000,
	TDCS_USEPERCENTDONEINTIMEEST		= 0x00002000,
	TDCS_SHOWCTRLSASCOLUMNS				= 0x00004000,
	TDCS_SHOWCOMMENTSALWAYS				= 0x00008000,
	TDCS_AUTOREPOSCTRLS					= 0x00010000,
	TDCS_HIDEZEROTIMEEST				= 0x00020000,
	TDCS_HIDESTARTDUEFORDONETASKS		= 0x00040000,
	TDCS_SHOWPERCENTASPROGRESSBAR		= 0x00080000,
	TDCS_READONLY						= 0x00100000,
	TDCS_ENABLESOURCECONTROL			= 0x00200000, 
	TDCS_CHECKOUTONLOAD					= 0x00400000, 
	TDCS_QUERYAPPLYCHANGESTOSUBTASKS	= 0x00800000, 
};

enum TDC_COLUMN
{
	TDCC_PRIORITY,
	TDCC_PERCENT,
	TDCC_TIMEEST,
	TDCC_STARTDATE,
	TDCC_DUEDATE,
	TDCC_DONEDATE,
	TDCC_PERSON,
	TDCC_FILEREF,
	TDCC_POSITION,
	TDCC_ID,
	TDCC_DONE,
}; 
 
// predeclarations
class CXmlItem;
class CXmlFile;
struct CTRLITEM;
struct TDCCOLUMN;

class CToDoCtrl : public CRuntimeDlg, protected CDialogHelper
{
// Construction
public:
	CToDoCtrl();
	virtual ~CToDoCtrl();

	BOOL Create(const RECT& rect, CWnd* pParentWnd, UINT nID, BOOL bVisible = TRUE);

	BOOL Save(LPCTSTR szFilePath = NULL, BOOL bCheckforLaterChanges = TRUE);
	BOOL Load(LPCTSTR szFilePath, LPCTSTR szArchivePath = NULL, TDC_ARCHIVE nRemove = TDC_REMOVEALL);
	BOOL Import(LPCTSTR szFilePath);

	int ArchiveDoneTasks(LPCTSTR szFilePath, TDC_ARCHIVE nFlags); // returns the number of tasks removed

	BOOL CheckIn();
	BOOL CheckOut();
	BOOL CheckOut(CString& sCheckedOutTo);
	BOOL IsCheckedOut() const { return m_bCheckedOut; }

	BOOL IsModified() const { return m_bModified; }
	void SetModified(BOOL bMod = TRUE);

	inline CString GetProjectName() const { return m_sProjectName; }
	inline CString GetFilePath() const { return m_sLastSavePath; }

	BOOL DeleteAllTasks();
	void NewList();

	void SetReadonly(BOOL bReadOnly) { SetStyle(TDCS_READONLY, bReadOnly); }
	BOOL IsReadOnly() const { return HasStyle(TDCS_READONLY); }

	void SetStyle(TDC_STYLE nStyle, BOOL bOn = TRUE); // one style at a time only 
	BOOL HasStyle(DWORD dwStyle) const; // can be multiple styles

	void ShowColumn(TDC_COLUMN nColumn, BOOL bShow);
	BOOL IsColumnShowing(TDC_COLUMN nColumn) const;

	BOOL SetPriorityColors(const CDWordArray& aColors); // must have either 2 or 11 elements
	void SetPriorityColors(COLORREF crLow, COLORREF crHigh);
	void SetGridlineColor(COLORREF color);
	void SetTaskCompletedColor(COLORREF color);

	HTREEITEM NewTask(LPCTSTR szText, TDC_INSERTWHERE nWhere = TDC_INSERTATTOPOFSELTASKPARENT, 
						BOOL bSelect = TRUE, BOOL bEditText = TRUE);

	BOOL DeleteSelectedTask();
	BOOL EditSelectedTask();

	COleDateTime GetSelectedTaskDoneDate() const;
	COleDateTime GetSelectedTaskDueDate() const;
	COleDateTime GetSelectedTaskStartDate() const;
	BOOL SetSelectedTaskStartDate(COleDateTime& date);
	BOOL SetSelectedTaskDoneDate(COleDateTime& date);
	BOOL SetSelectedTaskDueDate(COleDateTime& date);
	BOOL SetSelectedTaskDone(BOOL bDone = TRUE);
	BOOL IsSelectedTaskDone() const;
	BOOL IsSelectedTaskDue() const;

	COLORREF GetSelectedTaskColor() const; // -1 on no item selected
	CString GetSelectedTaskComments() const;
	int GetSelectedTaskPercentDone() const;
	double GetSelectedTaskEstimate() const;
	CString GetSelectedTaskPerson() const;
	CString GetSelectedTaskFileRef() const;
	int GetSelectedTaskPriority() const;

	BOOL SetSelectedTaskColor(COLORREF color);
	BOOL SetSelectedTaskComments(LPCTSTR szComments);
	BOOL SetSelectedTaskPercentDone(int nPercent);
	BOOL SetSelectedTaskEstimate(double dHours);
	BOOL SetSelectedTaskPerson(LPCTSTR szPerson);
	BOOL SetSelectedTaskFileRef(LPCTSTR szFilePath);
	BOOL SetSelectedTaskPriority(int nPriority); // 0-10 (10 is highest)

	BOOL GetSelectedTaskParentColor(COLORREF& color) const;
	BOOL GetSelectedTaskParentEstimate(double& dHours) const;
	BOOL GetSelectedTaskParentPerson(CString& sPerson) const;
	BOOL GetSelectedTaskParentPriority(int& nPriority) const; 

	void Sort(TDC_SORTBY nBy); // calling twice with the same param will toggle ascending attrib
	TDC_SORTBY GetSortBy() { return m_nSortBy; }

	// move functions
	BOOL MoveSelectedTaskDown();
	BOOL MoveSelectedTaskUp();
	BOOL CanMoveSelectedTaskDown() const;
	BOOL CanMoveSelectedTaskUp() const;
	BOOL MoveSelectedTaskLeft();
	BOOL MoveSelectedTaskRight();
	BOOL CanMoveSelectedTaskLeft() const;
	BOOL CanMoveSelectedTaskRight() const;

	// export functions
	void Export2Html(CString& sOutput, BOOL bVisibleColsOnly, BOOL bIncludeProjectName = TRUE, LPCTSTR szFontName = NULL, int nFontSize = 10, TDC_FILTER nFilter = TDCF_ALL) const;
	void Export2Text(CString& sOutput, BOOL bVisibleColsOnly, BOOL bIncludeProjectName = TRUE, int nIndentWidth = 2, TDC_FILTER nFilter = TDCF_ALL) const;
	BOOL CopySelectedItemAsHtml(CString& sOutput, BOOL bVisibleColsOnly, LPCTSTR szFontName = NULL) const;
	BOOL CopySelectedItemAsText(CString& sOutput, BOOL bVisibleColsOnly, int nIndent = 2) const;
	BOOL CopySelectedItemToClipboardAsHtml(BOOL bVisibleColsOnly, LPCTSTR szFontName = NULL) const;
	BOOL CopySelectedItemToClipboardAsText(BOOL bVisibleColsOnly, int nIndent = 2) const;

	// copy/paste functions
	BOOL CopySelectedItem();
	void ClearCopiedItem();
	BOOL PasteOnSelectedItem();
	BOOL CanPaste() const;

	unsigned short GetFileVersion() const { return m_nFileVersion; }
	unsigned short GetFileFormat() const { return m_nFileVersion; }
	
	// tree related
	BOOL SetImageList(CImageList* pImageList); // must be small
	inline HTREEITEM GetSelectedItem() const { return (m_tcToDo.GetSafeHwnd() ? m_tcToDo.GetSelectedItem() : NULL); }
	UINT GetTaskCount() const { return m_tcToDo.GetCount(); }
	BOOL ItemHasChildren(HTREEITEM hti) const { return m_tcToDo.ItemHasChildren(hti); }
	BOOL ItemHasParent(HTREEITEM hti) const { return (NULL != m_tcToDo.GetParentItem(hti)); }
	BOOL TreeHasFocus() { return m_tcToDo.HasFocus(FALSE); }
	BOOL SetTreeFont(LPCTSTR szFaceName, int nPoint = 8);

	// misc
	int GetMinWidth();

protected:
	struct TODOITEM
	{
		TODOITEM(LPCTSTR szTitle, LPCTSTR szComments = NULL) 
		{ 
			sTitle = szTitle; 
			sComments = szComments; 
			color = 0; 
			dateStart.m_dt = dateDone.m_dt = dateDue.m_dt = 0;
			nPriority = 5;
			nPercentDone = 0;
			dTimeEstimate = 0;

			SetModified();
		}

		TODOITEM() 
		{ 
			color = 0; 
			dateStart.m_dt = dateDone.m_dt = dateDue.m_dt = 0;
			nPriority = 5;
			nPercentDone = 0;
			dTimeEstimate = 0;

			SetModified();
		}

		TODOITEM(const TODOITEM& tdi) 
		{ 
			sTitle = tdi.sTitle; 
			sComments = tdi.sComments; 
			color = tdi.color; 
			dateStart = tdi.dateStart;
			dateDone = tdi.dateDone;
			dateDue = tdi.dateDue;
			nPriority = tdi.nPriority;
			nPercentDone = tdi.nPercentDone;
			sFileRefPath = tdi.sFileRefPath;
			dTimeEstimate = tdi.dTimeEstimate;

			SetModified();
		}

		inline BOOL HasStart() const { return (dateStart.m_dt > 0) ? TRUE : FALSE;; }
		inline BOOL HasDue() const { return (dateDue.m_dt > 0) ? TRUE : FALSE;; }
		inline BOOL IsDone() const { return (dateDone.m_dt > 0) ? TRUE : FALSE; }

		BOOL IsDue() const
		{ 
			if (IsDone() || !HasDue())
				return FALSE;
			
			COleDateTime today = COleDateTime::GetCurrentTime();
			today = COleDateTime(today.GetYear(), today.GetMonth(), today.GetDay(), 23, 59, 59); // end of today

			return (dateDue <= today); 
		}

		void SetModified() { tLastMod = COleDateTime::GetCurrentTime(); }

		CString sTitle;
		CString sComments;
		COLORREF color;
		COleDateTime dateStart, dateDue, dateDone;
		int nPriority;
		CString sPerson;
		int nPercentDone;
		CString sFileRefPath;
		double dTimeEstimate;
		COleDateTime tLastMod;
	};

	typedef CMap<DWORD, DWORD, TODOITEM, TODOITEM&> CTDIMap;
	typedef CMap<DWORD, DWORD, HTREEITEM, HTREEITEM&> CHTIMap;

	CTDIMap m_mapTDItems;
	COrderedTreeCtrl m_tcToDo;
	CString	m_sComments;
	CDateTimeCtrl m_dateStart, m_dateDue, m_dateDone;
	BOOL m_bModified;
	DWORD m_dwNextUniqueID;
	CComboBox m_cbPriority;
	int m_nPriority;
	TDC_SORTBY m_nSortBy;
	BOOL m_bSortAscending;
	unsigned short m_nFileVersion;
	unsigned short m_nFileFormat;
	CString m_sProjectName;
	CSpinButtonCtrl m_spinPercent;
	int m_nPercentDone;
	CString m_sPerson;
	DWORD m_dwStyle;
	BOOL m_bArchive;
	CFileEdit m_eFile;
	CString m_sFileRefPath;
	CDWordArray m_aPriorityColors;
	double m_dTimeEstimate;
	CString m_sXmlHeader;
	BOOL m_bModSinceLastSort;
	DWORD m_dwVisibleColumns;
	CSysImageList m_ilFileRef;
	CTaskListDropTarget m_dtTree, m_dtFileRef;
	CComboBox m_cbPerson;
	CFont m_fontTree, m_fontDone;
	CString m_sLastSavePath;
	CString m_sFontName;
	int m_nFontSize; // in points
	COLORREF m_crGridlines, m_crTaskDone;
	BOOL m_bCheckedOut; // intentionally not a style
	CString m_sMachineName; // for source control
	HCURSOR m_hHandCursor;
	CImageList m_ilDone;

	static CToDoCtrl* s_pCopySrc;
	static DWORD s_dwCopySrc; // itemID
	
	// sort helper structure
	struct SORTSTRUCT
	{
		CToDoCtrl* pTDCtrl;
		CTDIMap* pMapTDItems;
		CHTIMap* pMapHTItems;
		TDC_SORTBY nSortBy;
		BOOL bAscending;
	};

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CToDoCtrl)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	virtual void PreSubclassWindow();

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CToDoCtrl)
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnDestroy();
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG
	afx_msg void OnTreeEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTreeBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTreeSelChanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTaskDatechange(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTreeCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTreeClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTreeDblClk(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg LRESULT OnTreeEndDrag(WPARAM wParam, LPARAM lParam);
	afx_msg void OnTreeGetInfoTip(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnChangePriority();
	afx_msg void OnChangeComments();
	afx_msg void OnChangePercent();
	afx_msg void OnChangeTimeEstimate();
	afx_msg void OnEditChangePerson();
	afx_msg void OnSelChangePerson();
	afx_msg void OnKillFocusPerson();
	afx_msg void OnChangeProjectName();
	afx_msg void OnChangeFileRefPath();
	afx_msg void OnKillFocusPercent();
	afx_msg LRESULT OnGutterDrawItem(WPARAM wParam, LPARAM lParam); // for drawing priority
	afx_msg LRESULT OnGutterRecalcColWidth(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterNotifyHeaderClick(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterWidthChange(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterGetCursor(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterNotifyColumnClick(WPARAM wParam, LPARAM lParam);
	afx_msg void OnGotoFile();
	afx_msg LRESULT OnDropFileRef(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()

protected:
	void UpdateControls();
	void UpdateControl(const CTRLITEM* pCtrlItem);
	void UpdateTask(TDC_ATTRIBUTE nAttrib);
	BOOL IsParentTaskDone(HTREEITEM hti) const; // this is recursive
	int AreChildTasksDone(HTREEITEM hti) const; // 1=yes, 0=no, -1=no children
	BOOL IsTaskDue(HTREEITEM hti) const;
	BOOL GetTask(DWORD dwUniqueID, TODOITEM& tdi) const;
	void UpdateTask(DWORD dwUniqueID, TODOITEM& tdi);
	void InvalidateSelectedItem();
	BOOL DeleteTask(HTREEITEM hti);
	HTREEITEM GetTopLevelTask(HTREEITEM htiSubtask) const;
	void SetModified(BOOL bMod, TDC_ATTRIBUTE nAttrib);
	int GetSelectedTaskPercent(BOOL bCheckIfDone) const;
	HTREEITEM InsertItem(LPCTSTR szText, HTREEITEM htiParent, HTREEITEM htiAfter, BOOL bSelect, BOOL bEdit);
	void RebuildCopiedItem(HTREEITEM hti);
	void CopyTexttoclipboard(const CString& sText) const;
	CString FormatInfoTip(const HTREEITEM hti, const TODOITEM& tdi) const;
	int GetItemPos(HTREEITEM hti, HTREEITEM htiSearch) const; // returns 0 if not found
	int ArchiveDoneTasks(LPCTSTR szFilePath, TDC_ARCHIVE nRemove, BOOL bFlickerFree); // returns the number of tasks removed
	BOOL IsTaskFullyDone(const HTREEITEM hti, const TODOITEM& tdi, BOOL bCheckSiblings) const;
	COLORREF CalcPriorityColor(int nPriority) const;
	int CalcPercentDone(const HTREEITEM hti, const TODOITEM& tdi) const;
	double CalcTimeEstimate(const HTREEITEM hti, const TODOITEM& tdi) const;
	COLORREF GetTaskColor(const HTREEITEM hti) const;
	double GetTaskEstimate(const HTREEITEM hti) const;
	CString GetTaskPerson(const HTREEITEM hti) const;
	int GetTaskPriority(const HTREEITEM hti) const;
	void BuildHTIMap(CHTIMap& mapHTI);
	void UpdateHTIMapEntry(CHTIMap& mapHTI, HTREEITEM hti);
	double GetEarliestDueDate(HTREEITEM hti, const TODOITEM& tdi) const;
	void Resize(int cx = 0, int cy = 0);
	DWORD GetSelectedTaskID() const;
	void InitHandCursor();
	void ApplyLastChangeToSubtasks(const HTREEITEM hti, const TODOITEM& tdi, TDC_ATTRIBUTE nAttrib);

	HTREEITEM CopyTree(const CToDoCtrl* pSrc, const CDragDropTreeCtrl::HTREECOPY& htcSrc, HTREEITEM hDest);
	int AddChildren(HTREEITEM hti, CXmlItem* pXI, TDC_FILTER nFilter, BOOL bVisibleColsOnly) const;
	BOOL AddItem(HTREEITEM hti, CXmlItem* pXI, TDC_FILTER nFilter, BOOL bVisibleColsOnly, int nPos = 0) const;
	HTREEITEM AddItem(const CXmlItem* pXI, HTREEITEM htiParent);
	void Merge(const CXmlItem* pXISrc, CXmlItem* pXIDest);

	BOOL Load(CXmlFile* pFile, LPCTSTR szArchivePath = NULL, TDC_ARCHIVE nRemove = TDC_REMOVEALL);
	BOOL CheckOut(CXmlFile* pFile, CString& sCheckedOutTo);
	BOOL IsCheckedOut(const CXmlFile* pFile) const;

	enum 
	{
		CHECKPARENT = 0x1,
		CHECKCHILDREN = 0x2,
		CHECKALL = 0x3,
	};
	BOOL IsTaskDone(HTREEITEM hti, DWORD dwExtraCheck = 0) const;

	TDCCOLUMN* GetColumn(UINT nColID); 
	TDCCOLUMN* GetColumn(TDC_SORTBY nSortBy);

	void SaveExpandedState(); // keyed by last filepath
	HTREEITEM LoadExpandedState(BOOL bResetSel = TRUE); // returns the previously selected item if any
	int SaveExpandedState(LPCTSTR szRegKey, HTREEITEM hti = NULL, int nStart = 0); // keyed by filepath
	void LoadExpandedState(LPCTSTR szRegKey); // keyed by filepath

	// for sorting
	void Sort(HTREEITEM hti, TDC_SORTBY nBy, BOOL bAscending = TRUE);
	static int CALLBACK CompareFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort); 
	static int CompareDates(const COleDateTime& date1, const COleDateTime& date2, BOOL bAscending);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TODOCTRL_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_)
