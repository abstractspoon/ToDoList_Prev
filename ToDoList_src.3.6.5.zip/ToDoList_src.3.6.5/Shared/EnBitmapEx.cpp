// EnBitmap.cpp: implementation of the CEnBitmapEx class (c) daniel godson 2002.
//
// credits: Peter Hendrix's CPicture implementation for the original IPicture code 
//          Yves Maurer's GDIRotate implementation for the idea of working directly on 32 bit representations of bitmaps 
//          Karl Lager's 'A Fast Algorithm for Rotating Bitmaps' 
// 
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "EnBitmapex.h"
#include "imageprocessors.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEnBitmapEx::CEnBitmapEx(COLORREF crBkgnd) : CEnBitmap(crBkgnd)
{

}

CEnBitmapEx::~CEnBitmapEx()
{

}

BOOL CEnBitmapEx::RotateImage(int nDegrees, BOOL bEnableWeighting)
{
	return ProcessImage(&CImageRotator(nDegrees, bEnableWeighting));
}

BOOL CEnBitmapEx::ShearImage(int nHorz, int nVert, BOOL bEnableWeighting)
{
	return ProcessImage(&CImageShearer(nHorz, nVert, bEnableWeighting));
}

BOOL CEnBitmapEx::GrayImage(COLORREF crMask)
{
	return ProcessImage(&CImageGrayer(), crMask);
}

BOOL CEnBitmapEx::BlurImage(int nAmount)
{
	return ProcessImage(&CImageBlurrer(nAmount));
}

BOOL CEnBitmapEx::SharpenImage(int nAmount)
{
	return ProcessImage(&CImageSharpener(nAmount));
}

BOOL CEnBitmapEx::ResizeImage(double dFactor)
{
	return ProcessImage(&CImageResizer(dFactor));
}

BOOL CEnBitmapEx::LightenImage(double dAmount, COLORREF crMask)
{
	return ProcessImage(&CImageLightener(dAmount), crMask);
}

BOOL CEnBitmapEx::FlipImage(BOOL bHorz, BOOL bVert)
{
	return ProcessImage(&CImageFlipper(bHorz, bVert));
}

BOOL CEnBitmapEx::NegateImage()
{
	return ProcessImage(&CImageNegator());
}

BOOL CEnBitmapEx::ReplaceColor(COLORREF crFrom, COLORREF crTo)
{
	return ProcessImage(&CColorReplacer(crFrom, crTo));
}

BOOL CEnBitmapEx::ColorizeImage(COLORREF color)
{
	return ProcessImage(&CImageColorizer(color));
}

BOOL CEnBitmapEx::ContrastImage(int nAmount)
{
	return ProcessImage(&CImageContraster(nAmount));
}

BOOL CEnBitmapEx::TintImage(COLORREF color, int nAmount, COLORREF crMask)
{
	return ProcessImage(&CImageTinter(color, nAmount), crMask);
}

BOOL CEnBitmapEx::RemapSysColors()
{
	return ProcessImage(&CImageSysColorMapper());
}
