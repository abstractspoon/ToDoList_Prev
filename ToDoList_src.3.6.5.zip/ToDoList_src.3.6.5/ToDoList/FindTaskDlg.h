#if !defined(AFX_FINDTASKDLG_H__BDCCE0F4_B91B_47AD_AE27_1DEB4BA7EA1C__INCLUDED_)
#define AFX_FINDTASKDLG_H__BDCCE0F4_B91B_47AD_AE27_1DEB4BA7EA1C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FindTaskDlg.h : header file
//

#include "..\shared\dialoghelper.h"
#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////
// CFindTaskDlg dialog

const UINT WM_FTD_FIND = ::RegisterWindowMessage("WM_FTD_FIND");
const UINT WM_FTD_SELECTRESULT = ::RegisterWindowMessage("WM_FTD_SELECTRESULT");

struct FTDRESULT
{
	DWORD dwItemData;
	int nTaskList;
};

class CFindTaskDlg : public CDialog, public CDialogHelper
{
// Construction
public:
	static BOOL Show(CWnd* pParent);
	static void AddResult(LPCTSTR szTask, LPCTSTR szPath, LPCTSTR szTaskList, DWORD dwItemData, int nTaskList);

	static BOOL GetSearchAllTasklists();
	static CString GetSearchText();
	static BOOL GetSearchTitle();
	static BOOL GetSearchComments();
	static BOOL GetSearchPerson();
	static BOOL GetIncludeDone();
	static BOOL GetMatchCase();
	static BOOL GetMatchWholeWord();

protected:
	CFindTaskDlg(CWnd* pParent = NULL);   // standard constructor
	int DoModal() { return -1; } // not for public use

	static CFindTaskDlg& FindDlg(CWnd* pParent = NULL);

// Dialog Data
	//{{AFX_DATA(CFindTaskDlg)
	enum { IDD = IDD_FIND_DIALOG };
	CListCtrl	m_lcResults;
	CComboBox	m_cbLookFor;
	CString	m_sLookFor;
	int		m_bAllTasklists;
	BOOL	m_bSearchTitle;
	BOOL	m_bSearchComments;
	CString	m_sResultsLabel;
	BOOL	m_bIncludeDone;
	BOOL	m_bMatchCase;
	BOOL	m_bMatchWholeWord;
	BOOL	m_bSearchPerson;
	//}}AFX_DATA
	CMap<int, int, FTDRESULT, FTDRESULT&> m_mapResults;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFindTaskDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	virtual void OnCancel() { ShowWindow(SW_HIDE); }

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFindTaskDlg)
	afx_msg void OnFind();
	afx_msg void OnClose();
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeTasklistoptions();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnItemActivated(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void SaveSettings();
	void ResizeDlg(int cx = 0, int cy = 0);
	int FindSearchInCombo(LPCTSTR szLookFor);

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FINDTASKDLG_H__BDCCE0F4_B91B_47AD_AE27_1DEB4BA7EA1C__INCLUDED_)
