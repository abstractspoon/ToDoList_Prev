// PreferencesFilePage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesFilePage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesFilePage property page

IMPLEMENT_DYNCREATE(CPreferencesFilePage, CPropertyPage)

CPreferencesFilePage::CPreferencesFilePage() : 
		CPropertyPage(CPreferencesFilePage::IDD),
		m_eExportFolderPath(FES_FOLDERS | FES_COMBOSTYLEBTN)
{
//	m_psp.dwFlags &= ~PSP_HASHELP;

	//{{AFX_DATA_INIT(CPreferencesFilePage)
	m_bExportToFolder = FALSE;
	m_nNotifyDueBy = -1;
	//}}AFX_DATA_INIT
	m_bNotifyDue = AfxGetApp()->GetProfileInt("Preferences", "NotifyDue", FALSE);
	m_bAutoArchive = AfxGetApp()->GetProfileInt("Preferences", "AutoArchive", FALSE);
	m_bNotifyReadOnly = AfxGetApp()->GetProfileInt("Preferences", "NotifyReadOnly", TRUE);
	m_bRemoveArchivedTasks = AfxGetApp()->GetProfileInt("Preferences", "RemoveArchivedTasks", TRUE);
	m_bRemoveOnlyOnAbsoluteCompletion = AfxGetApp()->GetProfileInt("Preferences", "RemoveOnlyOnAbsoluteCompletion", TRUE);
	m_sHtmlFont = AfxGetApp()->GetProfileString("Preferences", "HTMLFont", "Verdana");
	m_bPreviewSaveAs = AfxGetApp()->GetProfileInt("Preferences", "PreviewSaveAs", TRUE);
	m_nHtmlFontSize = AfxGetApp()->GetProfileInt("Preferences", "HtmlFontSize", 3);
	m_nTextIndent = AfxGetApp()->GetProfileInt("Preferences", "TextIndent", 2);
	m_nAutoSaveFrequency = AfxGetApp()->GetProfileInt("Preferences", "AutoSaveFrequency", 0);
	m_bAutoSave = (m_nAutoSaveFrequency > 0);
	m_bExportVisibleOnly = AfxGetApp()->GetProfileInt("Preferences", "ExportVisibleOnly", FALSE);
	m_bAutoHtmlExport = AfxGetApp()->GetProfileInt("Preferences", "AutoHtmlExport", FALSE);
	m_sExportFolderPath = AfxGetApp()->GetProfileString("Preferences", "ExportFolderPath", "");
	m_nNotifyDueBy = AfxGetApp()->GetProfileInt("Preferences", "NotifyDueBy", 0);

	m_sExportFolderPath.TrimLeft();
	m_sExportFolderPath.TrimRight();

	m_bExportToFolder = !m_sExportFolderPath.IsEmpty();
}

CPreferencesFilePage::~CPreferencesFilePage()
{
}

void CPreferencesFilePage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesFilePage)
	DDX_Control(pDX, IDC_HTMLFONTSIZE, m_cbFontSize);
	DDX_Control(pDX, IDC_EXPORTFOLDER, m_eExportFolderPath);
	DDX_Check(pDX, IDC_EXPORTTOFOLDER, m_bExportToFolder);
	DDX_Text(pDX, IDC_EXPORTFOLDER, m_sExportFolderPath);
	DDX_CBIndex(pDX, IDC_NOTIFYDUEBY, m_nNotifyDueBy);
	//}}AFX_DATA_MAP
	DDX_Check(pDX, IDC_TASKNOTIFICATIONS, m_bNotifyDue);
	DDX_Check(pDX, IDC_NOTIFYREADONLY, m_bNotifyReadOnly);
	DDX_Check(pDX, IDC_AUTOARCHIVE, m_bAutoArchive);
	DDX_Control(pDX, IDC_AUTOSAVEFREQUENCY, m_cbAutoSave);
	DDX_Check(pDX, IDC_AUTOHTMLEXPORT, m_bAutoHtmlExport);
	DDX_Control(pDX, IDC_TABWIDTHS, m_cbIndent);
	DDX_Control(pDX, IDC_FONTLIST, m_cbFonts);
	DDX_Check(pDX, IDC_PREVIEWSAVEAS, m_bPreviewSaveAs);
	DDX_Check(pDX, IDC_REMOVEARCHIVEDITEMS, m_bRemoveArchivedTasks);
	DDX_Check(pDX, IDC_REMOVEONLYONABSCOMPLETION, m_bRemoveOnlyOnAbsoluteCompletion);
	DDX_Check(pDX, IDC_EXPORTVISIBLEONLY, m_bExportVisibleOnly);
	DDX_Check(pDX, IDC_AUTOSAVE, m_bAutoSave);

	// custom
	if (pDX->m_bSaveAndValidate)
	{
		m_sHtmlFont = m_cbFonts.GetSelectedFont();

		CString sSize;
		m_cbFontSize.GetLBText(m_cbFontSize.GetCurSel(), sSize);
		m_nHtmlFontSize = atoi(sSize);

		CString sIndent;
		m_cbIndent.GetLBText(m_cbIndent.GetCurSel(), sIndent);
		m_nTextIndent = atoi(sIndent);

		if (m_bAutoSave)
		{
			CString sFreq;
			m_cbAutoSave.GetLBText(m_cbAutoSave.GetCurSel(), sFreq);
			m_nAutoSaveFrequency = atoi(sFreq);
		}
		else
			m_nAutoSaveFrequency = 0;
	}
	else
	{
		m_cbFonts.SetSelectedFont(m_sHtmlFont);

		CString sSize;
		sSize.Format("%d", m_nHtmlFontSize);

		if (CB_ERR == m_cbFontSize.SelectString(-1, sSize))
		{
			m_nHtmlFontSize = 3;
			m_cbFontSize.SelectString(-1, "3");
		}

		m_cbFontSize.GetLBText(m_cbFontSize.GetCurSel(), sSize);
		m_nHtmlFontSize = atoi(sSize);

		CString sIndent;
		sIndent.Format("%d", m_nTextIndent);

		if (CB_ERR == m_cbIndent.SelectString(-1, sIndent))
		{
			m_nTextIndent = 2;
			m_cbIndent.SelectString(-1, "2");
		}

		if (m_bAutoSave)
		{
			CString sFreq;
			sFreq.Format("%d", m_nAutoSaveFrequency);

			if (CB_ERR == m_cbAutoSave.SelectString(-1, sFreq))
			{
				m_nAutoSaveFrequency = 5;
				m_cbAutoSave.SelectString(-1, "5");
			}
		}
		else
			m_cbAutoSave.SetCurSel(2);
	}
}


BEGIN_MESSAGE_MAP(CPreferencesFilePage, CPropertyPage)
	//{{AFX_MSG_MAP(CPreferencesFilePage)
	ON_BN_CLICKED(IDC_EXPORTTOFOLDER, OnExporttofolder)
	ON_BN_CLICKED(IDC_AUTOHTMLEXPORT, OnAutohtmlexport)
	ON_BN_CLICKED(IDC_TASKNOTIFICATIONS, OnTasknotifications)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_REMOVEARCHIVEDITEMS, OnRemovearchiveditems)
	ON_BN_CLICKED(IDC_AUTOSAVE, OnAutosave)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesFilePage message handlers

void CPreferencesFilePage::OnRemovearchiveditems() 
{
	UpdateData();

	GetDlgItem(IDC_REMOVEONLYONABSCOMPLETION)->EnableWindow(m_bRemoveArchivedTasks);
}

void CPreferencesFilePage::OnOK() 
{
	CPropertyPage::OnOK();
	
	// save settings
	AfxGetApp()->WriteProfileInt("Preferences", "NotifyDue", m_bNotifyDue);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoArchive", m_bAutoArchive);
	AfxGetApp()->WriteProfileInt("Preferences", "NotifyReadOnly", m_bNotifyReadOnly);
	AfxGetApp()->WriteProfileString("Preferences", "HTMLFont", m_sHtmlFont);
	AfxGetApp()->WriteProfileInt("Preferences", "HtmlFontSize", m_nHtmlFontSize);
	AfxGetApp()->WriteProfileInt("Preferences", "PreviewSaveAs", m_bPreviewSaveAs);
	AfxGetApp()->WriteProfileInt("Preferences", "TextIndent", m_nTextIndent);
	AfxGetApp()->WriteProfileInt("Preferences", "RemoveArchivedTasks", m_bRemoveArchivedTasks);
	AfxGetApp()->WriteProfileInt("Preferences", "RemoveOnlyOnAbsoluteCompletion", m_bRemoveOnlyOnAbsoluteCompletion);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoHtmlExport", m_bAutoHtmlExport);
	AfxGetApp()->WriteProfileInt("Preferences", "ExportVisibleOnly", m_bExportVisibleOnly);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoSaveFrequency", m_nAutoSaveFrequency);
	AfxGetApp()->WriteProfileString("Preferences", "ExportFolderPath", m_bExportToFolder ? m_sExportFolderPath : "");
	AfxGetApp()->WriteProfileInt("Preferences", "NotifyDueBy", m_nNotifyDueBy);
//	AfxGetApp()->WriteProfileInt("Preferences", "", m_b);
}

void CPreferencesFilePage::OnAutosave() 
{
	UpdateData();

	GetDlgItem(IDC_AUTOSAVEFREQUENCY)->EnableWindow(m_bAutoSave);

	if (m_bAutoSave && !m_nAutoSaveFrequency)
	{
		m_nAutoSaveFrequency = 5;
		m_cbAutoSave.SetCurSel(2);
	}
}

BOOL CPreferencesFilePage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	GetDlgItem(IDC_REMOVEONLYONABSCOMPLETION)->EnableWindow(m_bRemoveArchivedTasks);
	GetDlgItem(IDC_AUTOSAVEFREQUENCY)->EnableWindow(m_bAutoSave);
	GetDlgItem(IDC_EXPORTTOFOLDER)->EnableWindow(m_bAutoHtmlExport);
	GetDlgItem(IDC_EXPORTFOLDER)->EnableWindow(m_bAutoHtmlExport && m_bExportToFolder);
	GetDlgItem(IDC_NOTIFYDUEBY)->EnableWindow(m_bNotifyDue);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreferencesFilePage::OnExporttofolder() 
{
	UpdateData();

	GetDlgItem(IDC_EXPORTFOLDER)->EnableWindow(m_bAutoHtmlExport && m_bExportToFolder);
}

void CPreferencesFilePage::OnAutohtmlexport() 
{
	UpdateData();	

	GetDlgItem(IDC_EXPORTTOFOLDER)->EnableWindow(m_bAutoHtmlExport);
	GetDlgItem(IDC_EXPORTFOLDER)->EnableWindow(m_bAutoHtmlExport && m_bExportToFolder);
}

CString CPreferencesFilePage::GetAutoExportFolderPath() const 
{ 
	if (m_bAutoHtmlExport && m_bExportToFolder)
		return m_sExportFolderPath;
	else
		return "";
}

void CPreferencesFilePage::OnTasknotifications() 
{
	UpdateData();
	
	GetDlgItem(IDC_NOTIFYDUEBY)->EnableWindow(m_bNotifyDue);
}
