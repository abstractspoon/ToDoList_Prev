#if !defined(AFX_PREFERENCESDLG_H__C3FCC72A_6C69_49A6_930D_D5C94EC31298__INCLUDED_)
#define AFX_PREFERENCESDLG_H__C3FCC72A_6C69_49A6_930D_D5C94EC31298__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesDlg.h : header file
//

#include "preferencesgenpage.h"
#include "preferencestaskpage.h"
#include "preferencestoolpage.h"
#include "preferencesuipage.h"
#include "preferencesshortcutspage.h"
#include "preferencesfilepage.h"

/////////////////////////////////////////////////////////////////////////////
// CPreferencesDlg dialog

class CPreferencesDlg : public CPropertySheet
{
// Construction
public:
	CPreferencesDlg(CShortcutManager* pMgr = NULL, UINT nMenuID = 0, CWnd* pParent = NULL);   // standard constructor
	virtual ~CPreferencesDlg();

	BOOL GetAlwaysOnTop() const { return m_pageGen.GetAlwaysOnTop(); }
	BOOL GetUseSysTray() const { return m_pageGen.GetUseSysTray(); }
	BOOL GetAutoSaveOnSysTray() const { return m_pageGen.GetAutoSaveOnSysTray(); }
	BOOL GetConfirmDelete() const { return m_pageGen.GetConfirmDelete(); }
	BOOL GetConfirmSaveOnExit() const { return m_pageGen.GetConfirmSaveOnExit(); }
	int GetReadonlyReloadOption() const { return m_pageGen.GetReadonlyReloadOption(); }
	int GetTimestampReloadOption() const { return m_pageGen.GetTimestampReloadOption(); }
	BOOL GetShowOnStartup() const { return m_pageGen.GetShowOnStartup(); }
	int GetSysTrayOption() const { return m_pageGen.GetSysTrayOption(); }
	BOOL GetToggleTrayVisibility() const { return m_pageGen.GetToggleTrayVisibility(); }
	BOOL GetEnableSourceControl() const { return m_pageGen.GetEnableSourceControl(); }
	BOOL GetSourceControlLanOnly() const { return m_pageGen.GetSourceControlLanOnly(); }
	BOOL GetAutoCheckOut() const { return m_pageGen.GetAutoCheckOut(); }
	BOOL GetCheckoutOnCheckin() const { return m_pageGen.GetCheckoutOnCheckin(); }
	BOOL GetMultiInstance() const { return m_pageGen.GetMultiInstance(); }
	BOOL GetCheckinOnClose() const { return m_pageGen.GetCheckinOnClose(); }

	BOOL GetNotifyDue() const { return m_pageFile.GetNotifyDue(); }
	int GetNotifyDueBy() const { return m_pageFile.GetNotifyDueBy(); }
	BOOL GetAutoArchive() const { return m_pageFile.GetAutoArchive(); }
	BOOL GetNotifyReadOnly() const { return m_pageFile.GetNotifyReadOnly(); }
	CString GetHtmlFont() const { return m_pageFile.GetHtmlFont(); }
	int GetHtmlFontSize() const { return m_pageFile.GetHtmlFontSize(); }
	BOOL GetPreviewExport() const { return m_pageFile.GetPreviewExport(); }
	int GetTextIndent() const { return m_pageFile.GetTextIndent(); }
	BOOL GetRemoveArchivedTasks() const { return m_pageFile.GetRemoveArchivedTasks(); }
	BOOL GetRemoveOnlyOnAbsoluteCompletion() const { return m_pageFile.GetRemoveOnlyOnAbsoluteCompletion(); }
	BOOL GetAutoHtmlExport() const { return m_pageFile.GetAutoHtmlExport(); }
	BOOL GetExportVisibleOnly() const { return m_pageFile.GetExportVisibleOnly(); }
	int GetAutoSaveFrequency() const { return m_pageFile.GetAutoSaveFrequency(); }
	CString GetAutoExportFolderPath() const { return m_pageFile.GetAutoExportFolderPath(); }

	int GetDefaultPriority() const { return m_pageTask.GetDefaultPriority(); }
	CString GetDefaultPerson() const { return m_pageTask.GetDefaultPerson(); }
	int GetDefaultTimeEst() const { return m_pageTask.GetDefaultTimeEst(); }
	COLORREF GetDefaultColor() const { return m_pageTask.GetDefaultColor(); }
	COleDateTime GetDefaultStartDate() const { return m_pageTask.GetDefaultStartDate(); }
	BOOL GetUseParentColorAttrib() const { return m_pageTask.GetUseParentColorAttrib(); }
	BOOL GetUseParentPersonAttrib() const { return m_pageTask.GetUseParentPersonAttrib(); }
	BOOL GetUseParentPriorityAttrib() const { return m_pageTask.GetUseParentPriorityAttrib(); }
	BOOL GetUseParentTimeEstAttrib() const { return m_pageTask.GetUseParentTimeEstAttrib(); }
	BOOL GetAutoReSort() const { return m_pageTask.GetAutoReSort(); }
	BOOL GetAveragePercentSubCompletion() const { return m_pageTask.GetAveragePercentSubCompletion(); }
	BOOL GetIncludeDoneInAverageCalc() const { return m_pageTask.GetIncludeDoneInAverageCalc(); }
	BOOL GetUseEarliestDueDate() const { return m_pageTask.GetUseEarliestDueDate(); }
	BOOL GetUsePercentDoneInTimeEst() const { return m_pageTask.GetUsePercentDoneInTimeEst(); }
	BOOL GetTreatSubCompletedAsDone() const { return m_pageTask.GetTreatSubCompletedAsDone(); }
	BOOL GetHidePercentForDoneTasks() const { return m_pageTask.GetHidePercentForDoneTasks(); }
	BOOL GetHideZeroTimeEst() const { return m_pageTask.GetHideZeroTimeEst(); }
	BOOL GetHideStartDueForDoneTasks() const { return m_pageTask.GetHideStartDueForDoneTasks(); }
	BOOL GetShowPercentAsProgressbar() const { return m_pageTask.GetShowPercentAsProgressbar(); }
	BOOL GetQueryApplyChangestoSubtasks() const { return m_pageTask.GetQueryApplyChangestoSubtasks(); }
	BOOL GetSortVisibleOnly() const { return m_pageTask.GetSortVisibleOnly(); }

	BOOL GetColorTextByPriority() const { return m_pageUI.GetColorTextByPriority(); }
	BOOL GetShowButtonsInTree() const { return m_pageUI.GetShowButtonsInTree(); }
	BOOL GetShowInfoTips() const { return m_pageUI.GetShowInfoTips(); }
	BOOL GetShowComments() const { return m_pageUI.GetShowComments(); }
	BOOL GetShowColumn(PTP_COLUMN nColumn) const { return m_pageUI.GetShowColumn(nColumn); }
	BOOL GetColorPriority() const { return m_pageUI.GetColorPriority(); }
	int GetPriorityColors(CDWordArray& aColors) const { return m_pageUI.GetPriorityColors(aColors); }
	BOOL GetTreeFont(CString& sFaceName, int& nPointSize) const { return m_pageUI.GetTreeFont(sFaceName, nPointSize); }
	BOOL GetShowCtrlsAsColumns() const { return m_pageUI.GetShowCtrlsAsColumns(); }
	BOOL GetShowCommentsAlways() const { return m_pageUI.GetShowCommentsAlways(); }
	BOOL GetAutoReposCtrls() const { return m_pageUI.GetAutoReposCtrls(); }
	COLORREF GetGridlineColor() const { return m_pageUI.GetGridlineColor(); }
	COLORREF GetTaskDoneColor() const { return m_pageUI.GetTaskDoneColor(); }
	BOOL GetShowPathInHeader() const { return m_pageUI.GetShowPathInHeader(); }
	BOOL GetStrikethroughDone() const { return m_pageUI.GetStrikethroughDone(); }
	BOOL GetFullRowSelection() const { return m_pageUI.GetFullRowSelection(); }
	BOOL GetTreeCheckboxes() const { return m_pageUI.GetTreeCheckboxes(); }
	CString GetToolbarImagePath() const { return m_pageUI.GetToolbarImagePath(); }
	BOOL GetEnableHeaderSorting() const { return m_pageUI.GetEnableHeaderSorting(); }
	CString GetCheckboxImagePath() const { return m_pageUI.GetCheckboxImagePath(); }
	COLORREF GetCheckboxMaskColor() const { return m_pageUI.GetCheckboxMaskColor(); }
	BOOL GetSharedCommentsHeight() const { return m_pageUI.GetSharedCommentsHeight(); }

	int GetUserTools(CUserToolArray& aTools) const { return m_pageTool.GetUserTools(aTools); }

//	BOOL Get() const { return m_b; }

protected:
	CPreferencesGenPage m_pageGen;
	CPreferencesFilePage m_pageFile;
	CPreferencesUIPage m_pageUI;
	CPreferencesTaskPage m_pageTask;
	CPreferencesToolPage m_pageTool;
	CPreferencesShortcutsPage m_pageShortcuts;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnHelp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESDLG_H__C3FCC72A_6C69_49A6_930D_D5C94EC31298__INCLUDED_)
