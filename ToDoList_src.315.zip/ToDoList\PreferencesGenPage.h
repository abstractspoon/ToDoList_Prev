#if !defined(AFX_PREFERENCESGENPAGE_H__7A8CC153_F3FB_4FBA_8EB9_B8ADF0A59982__INCLUDED_)
#define AFX_PREFERENCESGENPAGE_H__7A8CC153_F3FB_4FBA_8EB9_B8ADF0A59982__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesGenPage.h : header file
//

#include "..\shared\fontcombobox.h"

/////////////////////////////////////////////////////////////////////////////
// CPreferencesGenPage dialog

class CPreferencesGenPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPreferencesGenPage)

// Construction
public:
	CPreferencesGenPage();
	~CPreferencesGenPage();

	CString GetHtmlFont() { return m_sHtmlFont; }
	BOOL GetPreviewSaveAs() { return m_bPreviewSaveAs; }
	int GetTextIndent() { return m_nTextIndent; }
	BOOL GetAlwaysOnTop() { return m_bAlwaysOnTop; }
	BOOL GetUseSysTray() { return m_bUseSysTray; }
	BOOL GetAutoSave() { return m_bUseSysTray && m_bAutoSave; }
	BOOL GetConfirmDelete() { return m_bConfirmDelete; }
	BOOL GetNotifyDue() { return m_bNotifyDue; }
	BOOL GetAutoArchive() { return m_bAutoArchive; }
	BOOL GetConfirmSaveOnExit() { return m_bConfirmSaveOnExit; }
	BOOL GetRemoveArchivedTasks() { return m_bRemoveArchivedTasks; }
	BOOL GetRemoveOnlyOnAbsoluteCompletion() { return m_bRemoveOnlyOnAbsoluteCompletion; }
	BOOL GetNotifyReadOnly() { return m_bNotifyReadOnly; }
	BOOL GetPromptReloadOnWritable() { return m_bPromptReloadOnWritable; }
	BOOL GetAutoHtmlExport() { return m_bAutoHtmlExport; }
	BOOL GetPromptReloadOnTimestamp() { return m_bPromptReloadOnTimestamp; }
	BOOL GetShowMenuBar() { return m_bShowMenuBar; }
	BOOL GetExportVisibleOnly() { return m_bExportVisibleOnly; }
	BOOL GetShowOnStartup() { return m_bAutoSave && m_bShowOnStartup; }
//	BOOL Get() { return m_b; }

// Dialog Data
	//{{AFX_DATA(CPreferencesGenPage)
	enum { IDD = IDD_PREFGEN_PAGE };
	CComboBox	m_cbIndent;
	CFontComboBox	m_cbFonts;
	BOOL	m_bPreviewSaveAs;
	BOOL	m_bAlwaysOnTop;
	BOOL	m_bUseSysTray;
	BOOL	m_bAutoSave;
	BOOL	m_bConfirmDelete;
	BOOL	m_bNotifyDue;
	BOOL	m_bAutoArchive;
	BOOL	m_bConfirmSaveOnExit;
	BOOL	m_bRemoveArchivedTasks;
	BOOL	m_bRemoveOnlyOnAbsoluteCompletion;
	BOOL	m_bNotifyReadOnly;
	BOOL	m_bPromptReloadOnWritable;
	BOOL	m_bAutoHtmlExport;
	BOOL	m_bPromptReloadOnTimestamp;
	BOOL	m_bShowMenuBar;
	BOOL	m_bExportVisibleOnly;
	BOOL	m_bShowOnStartup;
	//}}AFX_DATA
	CString m_sHtmlFont;
	int m_nTextIndent;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesGenPage)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesGenPage)
	afx_msg void OnUseSystray();
	virtual BOOL OnInitDialog();
	afx_msg void OnRemovearchiveditems();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESGENPAGE_H__7A8CC153_F3FB_4FBA_8EB9_B8ADF0A59982__INCLUDED_)
