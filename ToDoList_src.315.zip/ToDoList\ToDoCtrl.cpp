// ToDoCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "ToDoCtrl.h"
#include "ExportToDoList.h"

#include "..\shared\xmlfile.h"
#include "..\shared\holdredraw.h"
#include "..\shared\deferWndMove.h"
#include "..\shared\dlgunits.h"

#include <Windowsx.h>
#include <float.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CToDoCtrl dialog

// control ids
enum 
{
	IDC_FIRST			= 100,

	IDC_TREE,			// 101
	IDC_PROJECTLABEL,	// 102
	IDC_PROJECTNAME,	// 103
	IDC_PERSONLABEL,	// 104
	IDC_PERSON,			// 105
	IDC_PRIORITYLABEL,	// 106
	IDC_PRIORITY,		// 107
	IDC_STARTLABEL,		// 108
	IDC_STARTDATE,		// 109
	IDC_DUELABEL,		// 110
	IDC_DUEDATE,		// 111
	IDC_PERCENTLABEL,	// 112
	IDC_PERCENT,		// 113
	IDC_PERCENTSPIN,	// 114
	IDC_DONELABEL,		// 115
	IDC_DONEDATE,		// 116
	IDC_FILEPATHLABEL,	// 117
	IDC_FILEPATH,		// 118
	IDC_GOTOFILE,		// 119
	IDC_TIMEESTLABEL,	// 122
	IDC_TIMEEST,		// 123
	IDC_COMMENTSLABEL,	// 120
	IDC_COMMENTS,		// 121

	IDC_LAST
};

struct TDCCOLUMN
{
	TDC_COLUMN nCol;
	LPCTSTR szName;
	TDC_SORTBY nSortBy;
	UINT nAlignment;
	int nPos;
	BOOL bClickable;
};

static TDCCOLUMN COLUMNS[] = 
{
	{ TDCC_ID, "ID", TDC_SORTBYID, DT_LEFT, 0, TRUE },
	{ TDCC_PRIORITY, "!", TDC_SORTBYPRIORITY, DT_CENTER, 0, TRUE },
	{ TDCC_PERCENT, "%", TDC_SORTBYPERCENT, DT_CENTER, 0, TRUE },
	{ TDCC_TIMEEST, "Est.", TDC_SORTBYTIMEEST, DT_RIGHT, 0, TRUE },
	{ TDCC_STARTDATE, "Start", TDC_SORTBYSTART, DT_LEFT, 0, TRUE },
	{ TDCC_DUEDATE, "Due", TDC_SORTBYDUE, DT_LEFT, 0, TRUE },
	{ TDCC_DONEDATE, "Completed", TDC_SORTBYDONE, DT_LEFT, 0, TRUE },
	{ TDCC_PERSON, "Who", TDC_SORTBYPERSON, DT_LEFT, 0, TRUE },
	{ TDCC_FILEREF, "Ref", (TDC_SORTBY)-1, DT_CENTER, 0, FALSE },

	// special client column
	{ (TDC_COLUMN)0xffff, "Task Description", TDC_SORTBYNAME, DT_LEFT, NCG_CLIENTCOLUMN, TRUE },
};

int NUM_COLUMNS = sizeof(COLUMNS) / sizeof(TDCCOLUMN);

struct CTRLITEM
{
	UINT nCtrlID;
	UINT nLabelID;
	TDC_COLUMN nCol;
};

static CTRLITEM CTRLITEMS[] = 
{
	{ IDC_PRIORITY,		IDC_PRIORITYLABEL,	TDCC_PRIORITY },
	{ IDC_PERCENT,		IDC_PERCENTLABEL,	TDCC_PERCENT },
	{ IDC_TIMEEST,		IDC_TIMEESTLABEL,	TDCC_TIMEEST },
	{ IDC_STARTDATE,	IDC_STARTLABEL,		TDCC_STARTDATE },
	{ IDC_DUEDATE,		IDC_DUELABEL,		TDCC_DUEDATE },
	{ IDC_DONEDATE,		IDC_DONELABEL,		TDCC_DONEDATE },
	{ IDC_PERSON,		IDC_PERSONLABEL,	TDCC_PERSON },
	{ IDC_FILEPATH,		IDC_FILEPATHLABEL,	TDCC_FILEREF },
};

const int NUM_CTRLITEMS = sizeof(CTRLITEMS) / sizeof(CTRLITEM);
const int CTRLHEIGHT = 13; // dlu
const int CTRLVSPACING = 5; // dlu
const int CTRLHSPACING = 4; // dlu
const int CTRLSTARTOFFSET = 45; // dlu
const int CTRLENDOFFSET = 110; // dlu

const int COLPADDING = 3;

//////////////////////////////////////////////////////////////////////////////

const unsigned short FILEFORMAT = 5; // increment this when format changes
const unsigned short MINCOMMENTHEIGHT = 50;
const COLORREF BLACK = RGB(0, 0, 0);
const COLORREF WHITE = RGB(235, 235, 235);

CToDoCtrl* CToDoCtrl::s_pCopySrc = NULL;
DWORD CToDoCtrl::s_dwCopySrc = 0;

CToDoCtrl::CToDoCtrl() : m_bModified(FALSE), 
						 m_dwNextUniqueID(1), 
						 m_nPriority(-1), 
						 m_nSortBy(TDC_SORTBYNAME),
						 m_bSortAscending(-1),
						 m_nFileVersion(0),
						 m_dwStyle(TDCS_SHOWINFOTIPS),
						 m_bArchive(FALSE),
						 m_dTimeEstimate(0),
						 m_eFile(FES_COMBOBORDERBROWSEBTN),
						 m_nFileFormat(FILEFORMAT),
						 m_bModSinceLastSort(FALSE),
						 m_dwVisibleColumns(0),
						 m_nFontSize(-1)
{
	SetBordersDLU(0);

	AddRCControl("CONTROL", "SysTreeView32", "", TVS_EDITLABELS | WS_TABSTOP | TVS_SHOWSELALWAYS | TVS_HASLINES /*| TVS_LINESATROOT | TVS_HASBUTTONS*/ | TVS_INFOTIP/* | TVS_FULLROWSELECT*/, 0, 0,16,190,108, IDC_TREE);
	AddRCControl("LTEXT", "", "&Allocated to", SS_CENTERIMAGE, 0, 1,131,38,8, IDC_PERSONLABEL);
	AddRCControl("COMBOBOX", "", "", CBS_DROPDOWN | WS_TABSTOP, 0, 45,128,65,100, IDC_PERSON);
	AddRCControl("LTEXT", "", "P&riority", SS_CENTERIMAGE, 0, 119,131,22,8, IDC_PRIORITYLABEL);
	AddRCControl("COMBOBOX", "combobox", "", CBS_DROPDOWNLIST | WS_VSCROLL | WS_TABSTOP, 0, 159,128,65,300, IDC_PRIORITY);
	AddRCControl("LTEXT", "", "&Time Est (hr)", SS_CENTERIMAGE, 0, 1,148,40,8, IDC_TIMEESTLABEL);
	AddRCControl("EDITTEXT", "", "", WS_TABSTOP, 0, 45,146,65,13, IDC_TIMEEST);
	AddRCControl("LTEXT", "", "% Co&mplete", SS_CENTERIMAGE, 0, 119,148,37,8, IDC_PERCENTLABEL);
	AddRCControl("EDITTEXT", "", "", WS_TABSTOP, 0, 159,146,65,13, IDC_PERCENT);
	AddRCControl("CONTROL", "msctls_updown32", "", UDS_SETBUDDYINT | UDS_ALIGNRIGHT | UDS_AUTOBUDDY | UDS_ARROWKEYS, 0, 97,180,13,14, IDC_PERCENTSPIN);
	AddRCControl("LTEXT", "", "&Start Date", SS_CENTERIMAGE, 0, 1,166,33,8, IDC_STARTLABEL);
	AddRCControl("CONTROL", "SysDateTimePick32", "", DTS_RIGHTALIGN | DTS_SHOWNONE | WS_TABSTOP, 0, 45,164,65,13, IDC_STARTDATE);
	AddRCControl("LTEXT", "", "&Due Date", SS_CENTERIMAGE, 0, 119,166,32,8, IDC_DUELABEL);
	AddRCControl("CONTROL", "SysDateTimePick32", "", DTS_RIGHTALIGN | DTS_SHOWNONE | WS_TABSTOP, 0, 159,164,65,13, IDC_DUEDATE);
	AddRCControl("LTEXT", "", "&Completed", SS_CENTERIMAGE, 0, 1,184,34,8, IDC_DONELABEL);
	AddRCControl("CONTROL", "SysDateTimePick32", "", DTS_RIGHTALIGN | DTS_SHOWNONE | WS_TABSTOP, 0, 45,182,65,13, IDC_DONEDATE);
	AddRCControl("LTEXT", "", "&File Ref.", SS_CENTERIMAGE, 0, 119,184,37,8, IDC_FILEPATHLABEL);
	AddRCControl("EDITTEXT", "", "", ES_AUTOHSCROLL | ES_LEFT | WS_TABSTOP, 0, 159,182,65,13, IDC_FILEPATH);
	AddRCControl("PUSHBUTTON", "", "&Go", WS_TABSTOP, 0, 224,182,23,13, IDC_GOTOFILE);
	AddRCControl("LTEXT", "", "C&omments", 0, 0, 1,201,34,8, IDC_COMMENTSLABEL);
	AddRCControl("EDITTEXT", "", "", ES_MULTILINE | ES_WANTRETURN | WS_VSCROLL | WS_TABSTOP, 0, 0,211,171,27, IDC_COMMENTS);
	AddRCControl("LTEXT", "", "&Project", 0, 0, 1,3,28,8, IDC_PROJECTLABEL);
	AddRCControl("EDITTEXT", "", "", ES_AUTOHSCROLL | WS_TABSTOP, 0, 29,1,142,13, IDC_PROJECTNAME);

	SetPriorityColors(WHITE, BLACK);
}

CToDoCtrl::~CToDoCtrl()
{
	if (s_pCopySrc == this)
	{
		s_pCopySrc = NULL;
		s_dwCopySrc = 0;
	}
}

void CToDoCtrl::DoDataExchange(CDataExchange* pDX)
{
	CRuntimeDlg::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_TREE, m_tcToDo);
	DDX_Text(pDX, IDC_PROJECTNAME, m_sProjectName);
	DDX_CBString(pDX, IDC_PERSON, m_sPerson);
	DDX_Control(pDX, IDC_PERSON, m_cbPerson);
	DDX_Text(pDX, IDC_COMMENTS, m_sComments);
	DDX_Text(pDX, IDC_TIMEEST, m_dTimeEstimate);
	DDX_Control(pDX, IDC_DUEDATE, m_dateDue);
	DDX_Control(pDX, IDC_DONEDATE, m_dateDone);
	DDX_Control(pDX, IDC_STARTDATE, m_dateStart);
	DDX_Control(pDX, IDC_PRIORITY, m_cbPriority);
	DDX_Control(pDX, IDC_PERCENTSPIN, m_spinPercent);
	DDX_Control(pDX, IDC_FILEPATH, m_eFile);
	DDX_Text(pDX, IDC_FILEPATH, m_sFileRefPath);

	// custom
	if (pDX->m_bSaveAndValidate)
	{
		CString sPercent;
		GetDlgItem(IDC_PERCENT)->GetWindowText(sPercent);

		m_nPercentDone = max(0, atoi(sPercent));
		m_nPercentDone = min(100, m_nPercentDone);
		m_nPriority = m_cbPriority.GetCurSel();
	}
	else
	{
		m_spinPercent.SetPos(m_nPercentDone);
		m_cbPriority.SetCurSel(m_nPriority);
	}
}

BEGIN_MESSAGE_MAP(CToDoCtrl, CRuntimeDlg)
	//{{AFX_MSG_MAP(CToDoCtrl)
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_DESTROY()
	ON_WM_CONTEXTMENU()
	ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
	ON_NOTIFY(NM_CLICK, IDC_TREE, OnTreeClick)
	ON_NOTIFY(NM_DBLCLK, IDC_TREE, OnTreeDblClk)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_TREE, OnTreeCustomDraw)
	ON_NOTIFY(TVN_ENDLABELEDIT, IDC_TREE, OnTreeEndlabeledit)
	ON_NOTIFY(TVN_BEGINLABELEDIT, IDC_TREE, OnTreeBeginlabeledit)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE, OnTreeSelChanged)
	ON_NOTIFY(TVN_GETINFOTIP, IDC_TREE, OnTreeGetInfoTip)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_DONEDATE, OnTaskDatechange)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_DUEDATE, OnTaskDatechange)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_STARTDATE, OnTaskDatechange)
	ON_REGISTERED_MESSAGE(WM_DDTC_ENDDRAG, OnTreeEndDrag)
	ON_CBN_SELCHANGE(IDC_PRIORITY, OnChangePriority)
	ON_EN_CHANGE(IDC_TIMEEST, OnChangeTimeEstimate)
	ON_EN_CHANGE(IDC_COMMENTS, OnChangeComments)
	ON_EN_CHANGE(IDC_PROJECTNAME, OnChangeProjectName)
	ON_REGISTERED_MESSAGE(WM_NCG_DRAWITEM, OnGutterDrawItem)
	ON_REGISTERED_MESSAGE(WM_NCG_RECALCCOLWIDTH, OnGutterRecalcColWidth)
	ON_REGISTERED_MESSAGE(WM_NCG_NOTIFYHEADERCLICK, OnGutterNotifyHeaderClick)
	ON_REGISTERED_MESSAGE(WM_NCG_WIDTHCHANGE, OnGutterWidthChange)
	ON_CBN_EDITCHANGE(IDC_PERSON, OnEditChangePerson)
	ON_CBN_SELENDOK(IDC_PERSON, OnSelChangePerson)
	ON_CBN_KILLFOCUS(IDC_PERSON, OnKillFocusPerson)
	ON_EN_CHANGE(IDC_PERCENT, OnChangePercent)
	ON_EN_KILLFOCUS(IDC_PERCENT, OnKillFocusPercent)
	ON_BN_CLICKED(IDC_GOTOFILE, OnGotoFile)
	ON_EN_CHANGE(IDC_FILEPATH, OnChangeFileRefPath)
	ON_REGISTERED_MESSAGE(WM_TLDT_DROPFILE, OnDropFileRef)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CToDoCtrl message handlers

BOOL CToDoCtrl::Create(const RECT& rect, CWnd* pParentWnd, UINT nID, BOOL bVisible)
{
	DWORD dwStyle = WS_CHILD | (bVisible ? WS_VISIBLE : 0);

	return CRuntimeDlg::Create(NULL, dwStyle, 0, rect, pParentWnd, nID);
}

BOOL CToDoCtrl::OnInitDialog() 
{
	CRuntimeDlg::OnInitDialog();

	// init priority combo
	m_cbPriority.AddString("0 (Lowest)");
	m_cbPriority.AddString("1 (Low)");
	m_cbPriority.AddString("2 (Low)");
	m_cbPriority.AddString("3 (Low)");
	m_cbPriority.AddString("4 (Medium)");
	m_cbPriority.AddString("5 (Medium)");
	m_cbPriority.AddString("6 (Medium)");
	m_cbPriority.AddString("7 (Medium)");
	m_cbPriority.AddString("8 (High)");
	m_cbPriority.AddString("9 (High)");
	m_cbPriority.AddString("10 (Highest)");

	m_spinPercent.SetRange(0, 100);
	m_spinPercent.SetBuddy(GetDlgItem(IDC_PERCENT));

	UDACCEL uda = { 0, 5 };
	m_spinPercent.SetAccel(1, &uda);

	// extra gutter columns
	for (int nCol = 0; nCol < NUM_COLUMNS; nCol++)
	{
		TDCCOLUMN& tdcc = COLUMNS[nCol];

		if (tdcc.nPos != NCG_CLIENTCOLUMN)
			tdcc.nPos = m_tcToDo.AddGutterColumn(tdcc.szName, 0, tdcc.nAlignment);
		else
			m_tcToDo.SetGutterColumnHeaderTitle(tdcc.nPos, tdcc.szName);

		m_tcToDo.EnableGutterColumnHeaderClicking(tdcc.nPos, tdcc.bClickable);
	}

	// init dates
	m_dateStart.SendMessage(DTM_SETSYSTEMTIME, GDT_NONE, 0);
	m_dateDue.SendMessage(DTM_SETSYSTEMTIME, GDT_NONE, 0);
	m_dateDone.SendMessage(DTM_SETSYSTEMTIME, GDT_NONE, 0);

	m_dtTree.Register(&m_tcToDo, this);
	m_dtFileRef.Register(&m_eFile, this); 

	if (m_fontTree.GetSafeHandle())
		m_tcToDo.SetFont(&m_fontTree);

	// enabled states
	UpdateControls();
	m_tcToDo.SetFocus();

	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CToDoCtrl::SetTreeFont(LPCTSTR szFaceName, int nPoint)
{
	nPoint = min(24, max(6, nPoint));

	if (m_sFontName.CompareNoCase(szFaceName ? szFaceName : "") == 0)
	{
		if (m_sFontName.IsEmpty()) // both empty
			return TRUE; // no change

		else if (m_nFontSize == nPoint)
			return TRUE; // no change
	}

	m_fontDone.DeleteObject();
	m_fontTree.DeleteObject();

	CFont* pFont = CFont::FromHandle((HFONT)GetStockObject(ANSI_VAR_FONT));
						
	LOGFONT lf;
	pFont->GetLogFont(&lf);

	// this is essential for double-byte support
	lf.lfCharSet |= DEFAULT_CHARSET;

	if (szFaceName && lstrlen(szFaceName))
	{
		lstrcpy(lf.lfFaceName, szFaceName);

		HDC hDC = ::GetDC(NULL);
		lf.lfHeight = -MulDiv(abs(nPoint), GetDeviceCaps(hDC, LOGPIXELSY), 72);
		::ReleaseDC(NULL, hDC);

		lf.lfWidth = 0;

		m_fontTree.CreateFontIndirect(&lf); // check for failure later
	}
	
	lf.lfStrikeOut = TRUE;
		
	m_fontDone.CreateFontIndirect(&lf);

	if (m_fontTree.GetSafeHandle())
	{
		m_sFontName = szFaceName;
		m_nFontSize = nPoint;
		
		if (m_tcToDo.GetSafeHwnd())
			m_tcToDo.SetFont(&m_fontTree);
	}
	else
	{
		m_sFontName.Empty();
		m_nFontSize = -1;
		
		if (m_tcToDo.GetSafeHwnd())
			m_tcToDo.SendMessage(WM_SETFONT, NULL, TRUE);
	}
	
	return TRUE;
}

TDCCOLUMN* CToDoCtrl::GetColumn(int nPos)
{
	int nCol = NUM_COLUMNS;

	while (nCol--)
	{
		if (COLUMNS[nCol].nPos == nPos)
			return &COLUMNS[nCol];
	}

	// else
	return NULL;
}

TDCCOLUMN* CToDoCtrl::GetColumn(TDC_SORTBY nSortBy)
{
	int nCol = NUM_COLUMNS;

	while (nCol--)
	{
		if (COLUMNS[nCol].nSortBy == nSortBy)
			return &COLUMNS[nCol];
	}

	// else
	return NULL;
}

void CToDoCtrl::OnSize(UINT nType, int cx, int cy) 
{
	CRuntimeDlg::OnSize(nType, cx, cy);
	
	Resize(cx, cy);
}

void CToDoCtrl::Resize(int cx, int cy)
{
	if (m_tcToDo.GetSafeHwnd())
	{
		if (!cx && !cy)
		{
			CRect rClient;
			GetClientRect(rClient);

			cx = rClient.right;
			cy = rClient.bottom;

			// check again 
			if (!cx && !cy)
				return;
		}

		// written to use DeferWindowPos()
		CDeferWndMove dwm(25);
		
		CRect rTree = OffsetCtrl(IDC_TREE); // just a get
		CRect rComments = OffsetCtrl(IDC_COMMENTS); // not a move just a 'get'
		
		// adjust comments height to be 20% of height or MINCOMMENTHEIGHT whichever is greater
		int nCommentHeight = MINCOMMENTHEIGHT;
		
		if (!HasStyle(TDCS_FIXEDCOMMENTHEIGHT)) 
			nCommentHeight = max((cy * 20) / 100, MINCOMMENTHEIGHT);
		
		// and determine 'general' Y offset
		int nXOffset = cx - rComments.right;
		int nYOffset = cy - rComments.top - nCommentHeight;
		
		rComments.top = cy - nCommentHeight;
		rComments.right = cx;
		rComments.bottom = cy;
		
		dwm.MoveWindow(GetDlgItem(IDC_COMMENTS), rComments);
		rComments = dwm.OffsetCtrl(this, IDC_COMMENTSLABEL, 0, nYOffset);
		
		// the edit controls are handled dynamically to reflect the
		// corresponding column visibility
		
		// first count up the visible controls
		// so we can allocate the correct amount of space
		BOOL bAllVisible = !HasStyle(TDCS_SHOWCTRLSASCOLUMNS);
		int nVisibleCtrls = 0;
		
		if (bAllVisible)
			nVisibleCtrls = NUM_CTRLITEMS;
		else
		{
			for (int nCtrl = 0; nCtrl < NUM_CTRLITEMS; nCtrl++)
			{
				if (IsColumnShowing(CTRLITEMS[nCtrl].nCol))
					nVisibleCtrls++;
			}
		}
		
		// for converting dlus to pixels
		CDlgUnits dlu(*this);
		
		int nCols = max(2, (cx - dlu.ToPixelsX(1)) / dlu.ToPixelsX(CTRLENDOFFSET + CTRLHSPACING));
		int nRows = (nVisibleCtrls / nCols) + ((nVisibleCtrls % nCols) ? 1 : 0);
		
		CRect rItem(0, rComments.top - nRows * dlu.ToPixelsY(CTRLHEIGHT + CTRLVSPACING), 0, 0);
		rItem.bottom = rItem.top + dlu.ToPixelsY(CTRLHEIGHT);
		
		// resize tree now that we can calculate where its bottom is
		if (HasStyle(TDCS_SIMPLEMODE))
		{
			if (HasStyle(TDCS_SHOWCOMMENTSALWAYS))
				rTree.bottom = rComments.top - dlu.ToPixelsY(CTRLVSPACING);
			else
				rTree.bottom = cy;
		}
		else
			rTree.bottom = (rItem.top - dlu.ToPixelsY(CTRLVSPACING));

		rTree.right = cx;
		
		dwm.MoveWindow(GetDlgItem(IDC_TREE), rTree);
		dwm.ResizeCtrl(this, IDC_PROJECTNAME, nXOffset, 0);
		
		// now iterate the visible controls settings their positions dynamically
		int nRow = 0, nCol = 0;
		
		for (int nCtrl = 0; nCtrl < NUM_CTRLITEMS; nCtrl++)
		{
			if (!bAllVisible && !IsColumnShowing(CTRLITEMS[nCtrl].nCol))
				continue;
			
			if (nCol >= nCols)
			{
				nCol = 0;
				rItem.OffsetRect(0, dlu.ToPixelsY(CTRLHEIGHT + CTRLVSPACING));
			}
			
			rItem.left = dlu.ToPixelsX(1 + nCol * (CTRLENDOFFSET + CTRLHSPACING));
			rItem.right = rItem.left + dlu.ToPixelsX(CTRLENDOFFSET);
			
			// move label
			CRect rLabel(rItem);
			rLabel.right = rLabel.left + dlu.ToPixelsX(CTRLSTARTOFFSET);
			
			dwm.MoveWindow(GetDlgItem(CTRLITEMS[nCtrl].nLabelID), rLabel);
			
			// move control
			CRect rCtrl(rItem);
			rCtrl.left += dlu.ToPixelsX(CTRLSTARTOFFSET);
			
			// some special cases
			switch (CTRLITEMS[nCtrl].nCtrlID)
			{
			case IDC_PERCENT:
				{
					CRect rSpin = dwm.OffsetCtrl(this, IDC_PERCENTSPIN);
					rSpin.OffsetRect(rCtrl.right - rSpin.right, rCtrl.bottom - rSpin.bottom);
					dwm.MoveWindow(&m_spinPercent, rSpin);
				}
				break;
				
			case IDC_FILEPATH:
				{
					CWnd* pGotoBtn = GetDlgItem(IDC_GOTOFILE);

					CRect rGotoBtn = OffsetCtrl(IDC_GOTOFILE); // just a get
					rGotoBtn.OffsetRect(cx - rGotoBtn.right - 1, rCtrl.top - rGotoBtn.top);
					dwm.MoveWindow(pGotoBtn, rGotoBtn);

					pGotoBtn->Invalidate();
					
					rCtrl.right = max(rCtrl.right, rGotoBtn.left - 2);
				}
				break;
			}
			
			dwm.MoveWindow(GetDlgItem(CTRLITEMS[nCtrl].nCtrlID), rCtrl);
			
			nCol++;
		}
	}
}

int CToDoCtrl::GetMinWidth()
{
	if (m_tcToDo.GetSafeHwnd())
		return m_tcToDo.GetGutterWidth() + 20;

	return 0;
}

// wrapper for CTreeCtrl
CImageList* CToDoCtrl::SetImageList(CImageList* pImageList, int nImageListType)
{
	return m_tcToDo.SetImageList(pImageList, nImageListType);
}

void CToDoCtrl::SetProjectName(LPCTSTR szName) 
{ 
	m_sProjectName = szName; 

	if (GetSafeHwnd())
		UpdateData(FALSE);
}

void CToDoCtrl::OnTreeSelChanged(NMHDR* pNMHDR, LRESULT* pResult)
{
	UpdateControls(); // load newly selected item

	*pResult = 0;
}

void CToDoCtrl::UpdateControls()
{
	HTREEITEM hti = GetSelectedItem();

	if (hti)
	{
		m_sComments = GetSelectedTaskComments();
		m_nPriority = (int)GetSelectedTaskPriority();
		m_sPerson = GetSelectedTaskPerson();
		m_sFileRefPath = GetSelectedTaskFileRef();
		m_dTimeEstimate = GetSelectedTaskEstimate();

		// date controls need special handling
		COleDateTime date = GetSelectedTaskDoneDate();

		if (date.m_dt)
			m_dateDone.SetTime(date);
		else
			m_dateDone.SendMessage(DTM_SETSYSTEMTIME, GDT_NONE, 0);

		date = GetSelectedTaskDueDate();

		if (date.m_dt)
			m_dateDue.SetTime(date);
		else
			m_dateDue.SendMessage(DTM_SETSYSTEMTIME, GDT_NONE, 0);

		date = GetSelectedTaskStartDate();

		if (date.m_dt)
			m_dateStart.SetTime(date);
		else
			m_dateStart.SendMessage(DTM_SETSYSTEMTIME, GDT_NONE, 0);

		m_nPercentDone = IsSelectedTaskDone() ? 100 : GetSelectedTaskPercent(FALSE);

		UpdateData(FALSE);
	}

	BOOL bSimpleMode = HasStyle(TDCS_SIMPLEMODE);
	BOOL bEnable = (hti && !bSimpleMode);
	BOOL bEditPercent = !(HasStyle(TDCS_AVERAGEPERCENTSUBCOMPLETION) && m_tcToDo.ItemHasChildren(hti));
	BOOL bEditTime = !m_tcToDo.ItemHasChildren(hti);

	// now enable/disable appropriate controls
	if (HasStyle(TDCS_SHOWCTRLSASCOLUMNS))
	{
		for (int nCtrl = 0; nCtrl < NUM_CTRLITEMS; nCtrl++)
		{
			CWnd* pCtrl = GetDlgItem(CTRLITEMS[nCtrl].nCtrlID);
			CWnd* pLabel = GetDlgItem(CTRLITEMS[nCtrl].nLabelID);
			
			BOOL bColShowing = IsColumnShowing(CTRLITEMS[nCtrl].nCol);
			int nShowCtrl = (bColShowing && !bSimpleMode) ? SW_SHOW : SW_HIDE;
			BOOL bEnableCtrl = (bColShowing && bEnable);
			
			// some additions and modifications
			switch (CTRLITEMS[nCtrl].nCtrlID)
			{
			case IDC_PERCENT:
				bEnableCtrl &= bEditPercent;
				m_spinPercent.ShowWindow(nShowCtrl);
				m_spinPercent.EnableWindow(bEnable);
				break;
				
			case IDC_FILEPATH:
				GetDlgItem(IDC_GOTOFILE)->ShowWindow(nShowCtrl);
				GetDlgItem(IDC_GOTOFILE)->EnableWindow(bEnable && !m_sFileRefPath.IsEmpty());
				break;

			case IDC_TIMEEST:
				bEnableCtrl &= bEditTime;
				break;
			}

			pCtrl->ShowWindow(nShowCtrl);
			pCtrl->EnableWindow(bEnableCtrl);
			pLabel->ShowWindow(nShowCtrl);
			pLabel->EnableWindow(bEnableCtrl);
		}

		// also
		BOOL bCommentsAlways = HasStyle(TDCS_SHOWCOMMENTSALWAYS);

		EnableControls(IDC_COMMENTSLABEL, IDC_COMMENTS, (bCommentsAlways || !bSimpleMode) && hti);
		ShowControls(IDC_COMMENTSLABEL, IDC_COMMENTS, (bCommentsAlways || !bSimpleMode));
	}
	else
	{
		EnableControls(IDC_PERSONLABEL, IDC_COMMENTSLABEL - 1, bEnable);
		ShowControls(IDC_PERSONLABEL, IDC_COMMENTSLABEL - 1, !bSimpleMode);

		// exceptions
		BOOL bCommentsAlways = HasStyle(TDCS_SHOWCOMMENTSALWAYS);

		EnableControls(IDC_COMMENTSLABEL, IDC_COMMENTS, (bCommentsAlways || !bSimpleMode) && hti);
		ShowControls(IDC_COMMENTSLABEL, IDC_COMMENTS, (bCommentsAlways || !bSimpleMode));

		EnableControls(IDC_GOTOFILE, IDC_GOTOFILE, bEnable && !m_sFileRefPath.IsEmpty());
		EnableControls(IDC_PERCENTLABEL, IDC_PERCENTSPIN, bEnable && bEditPercent);
		EnableControls(IDC_TIMEESTLABEL, IDC_TIMEEST, bEnable && bEditTime);
	}
}

void CToDoCtrl::UpdateTask(TDC_ATTRIBUTE nAttrib)
{
	if (!m_tcToDo.GetSafeHwnd())
		return;

	HTREEITEM hti = GetSelectedItem();

	if (!hti)
		return;

	// else
	UpdateData();

	switch (nAttrib)
	{
//	case TDCA_TASKNAME:
//		break;

	case TDCA_DONEDATE:
		{
			CTime time;
			COleDateTime date;

			if (m_dateDone.GetTime(time) == GDT_VALID)
				m_dateDone.GetTime(date);

			SetSelectedTaskDoneDate(date);

			// check if we need to modify percent done also
			if (!IsSelectedTaskDone())
			{
				int nPercentDone = GetSelectedTaskPercent(FALSE);

				if (nPercentDone == 100)
					nPercentDone = 0;

				SetSelectedTaskPercentDone(nPercentDone);
				m_nPercentDone = nPercentDone;

				UpdateData(FALSE);
			}
			else if (m_nPercentDone != 100) // make the percent field look right
			{
				m_nPercentDone = 100;
				UpdateData(FALSE);
			}
		}
		break;

	case TDCA_DUEDATE:
		{
			CTime time;
			COleDateTime date;

			if (m_dateDue.GetTime(time) == GDT_VALID)
				m_dateDue.GetTime(date);

			SetSelectedTaskDueDate(date);
		}
		break;

	case TDCA_STARTDATE:
		{
			CTime time;
			COleDateTime date;

			if (m_dateStart.GetTime(time) == GDT_VALID)
				m_dateStart.GetTime(date);

			SetSelectedTaskStartDate(date);
		}
		break;

	case TDCA_PRIORITY:
		SetSelectedTaskPriority(m_nPriority);
		break;

//	case TDCA_COLOR:
//		break;

	case TDCA_PERSON:
		SetSelectedTaskPerson(m_sPerson);
		break;

	case TDCA_PERCENT:
		{
			// note: we need to take account of 'done' state too because
			// we maintain the task percent at its pre-done state even
			// if the UI says its '100%'
			BOOL bWasDone = IsSelectedTaskDone();
			int nPrevPercent = GetSelectedTaskPercent(FALSE);
			SetSelectedTaskPercentDone(m_nPercentDone);

			// check if we need to update 'done' state
			BOOL bDoneChange = (bWasDone && m_nPercentDone < 100) || (!bWasDone && m_nPercentDone == 100);

			if (bDoneChange)
			{
				SetSelectedTaskDone(m_nPercentDone == 100);
				nAttrib = TDCA_DONEDATE;
			}
		}
		break;

	case TDCA_TIMEEST:
		SetSelectedTaskEstimate(m_dTimeEstimate);
		break;

	case TDCA_FILEREF:
		SetSelectedTaskFileRef(m_sFileRefPath);

		GetDlgItem(IDC_GOTOFILE)->EnableWindow(!m_sFileRefPath.IsEmpty());
		break;

	case TDCA_COMMENTS:
		SetSelectedTaskComments(m_sComments);
		break;

	default:
		return;
	}
}

void CToDoCtrl::OnChangePriority()
{
	UpdateTask(TDCA_PRIORITY);
}

void CToDoCtrl::OnTaskDatechange(NMHDR* pNMHDR, LRESULT* pResult)
{
	switch (pNMHDR->idFrom)
	{
	case IDC_DONEDATE:
		UpdateTask(TDCA_DONEDATE); 
		break;

	case IDC_STARTDATE:
		UpdateTask(TDCA_STARTDATE); 
		break;

	case IDC_DUEDATE:
		UpdateTask(TDCA_DUEDATE); 
		break;
	}

	*pResult = 0;
}

BOOL CToDoCtrl::OnEraseBkgnd(CDC* pDC) 
{
	int nDC = pDC->SaveDC();

	// clip out all the child controls to reduce flicker
	if (!(GetStyle() & WS_CLIPCHILDREN))
	{
		if (m_tcToDo.GetSafeHwnd())
			ExcludeControls(pDC, IDC_FIRST + 1, IDC_LAST - 1);
	}

	BOOL bRes = CRuntimeDlg::OnEraseBkgnd(pDC);

	pDC->RestoreDC(nDC);

	return bRes;
}

void CToDoCtrl::NewList()
{
	BOOL bConfirmDelete = HasStyle(TDCS_CONFIRMDELETE);

	if (bConfirmDelete)
		SetStyle(TDCS_CONFIRMDELETE, FALSE);

	DeleteAllTasks();

	if (bConfirmDelete)
		SetStyle(TDCS_CONFIRMDELETE, TRUE);

	m_sProjectName.Empty();
	m_nFileVersion = 0;
	m_bModified = FALSE;

	UpdateData(FALSE);
}

BOOL CToDoCtrl::SetSelectedTaskColor(COLORREF color)
{
	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(htiSel);

		if (GetTask(dwID, tdi))
		{
			if (tdi.color != color)
			{
				tdi.color = color;
				UpdateTask(dwID, tdi);
				InvalidateSelectedItem();

				SetModified(TRUE, TDCA_COLOR);
			}
			return TRUE;
		}
	}

	return FALSE;
}

BOOL CToDoCtrl::SetSelectedTaskComments(LPCTSTR szComments)
{
	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(htiSel);

		if (GetTask(dwID, tdi))
		{
			if (tdi.sComments != szComments)
			{
				tdi.sComments = szComments;
				UpdateTask(dwID, tdi);

				InvalidateSelectedItem();

				if (m_sComments != szComments) // without this check the caret gets mucked up
				{
					m_sComments = szComments;
					UpdateData(FALSE);
				}

				SetModified(TRUE, TDCA_COMMENTS);
			}
			return TRUE;
		}
	}

	return FALSE;
}

CString CToDoCtrl::GetSelectedTaskComments() const
{
	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(htiSel);

		if (GetTask(dwID, tdi))
			return tdi.sComments;
	}

	return "";
}

int CToDoCtrl::GetSelectedTaskPriority() const
{
	return GetTaskPriority(GetSelectedItem());
}

double CToDoCtrl::GetSelectedTaskEstimate() const
{
	return GetTaskEstimate(GetSelectedItem());
}

double CToDoCtrl::GetTaskEstimate(const HTREEITEM hti) const
{
	if (hti)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(hti);

		if (GetTask(dwID, tdi))
			return tdi.dTimeEstimate;
	}

	return 0;
}

CString CToDoCtrl::GetTaskPerson(const HTREEITEM hti) const
{
	if (hti)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(hti);

		if (GetTask(dwID, tdi))
			return tdi.sPerson;
	}

	return "";
}

COLORREF CToDoCtrl::GetTaskColor(const HTREEITEM hti) const
{
	if (hti)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(hti);

		if (GetTask(dwID, tdi))
			return tdi.color;
	}

	return 0;
}

int CToDoCtrl::GetTaskPriority(const HTREEITEM hti) const
{
	if (hti)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(hti);

		if (GetTask(dwID, tdi))
			return tdi.nPriority;
	}

	return 0;
}

BOOL CToDoCtrl::SetSelectedTaskPriority(int nPriority)
{
	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel && nPriority >= 0 && nPriority <= 10)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(htiSel);

		if (GetTask(dwID, tdi))
		{
			if (tdi.nPriority != nPriority)
			{
				tdi.nPriority = nPriority;
				UpdateTask(dwID, tdi);
				
				if (m_nPriority != nPriority)
				{
					m_nPriority = nPriority;
					UpdateData(FALSE);
				}

				SetModified(TRUE, TDCA_PRIORITY);
			}
			return TRUE;
		}
	}

	return FALSE;
}

COleDateTime CToDoCtrl::GetSelectedTaskDueDate() const
{
	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(htiSel);

		if (GetTask(dwID, tdi))
			return tdi.dateDue;
	}

	return COleDateTime();
}

COleDateTime CToDoCtrl::GetSelectedTaskStartDate() const
{
	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(htiSel);

		if (GetTask(dwID, tdi))
			return tdi.dateStart;
	}

	return COleDateTime();
}

COleDateTime CToDoCtrl::GetSelectedTaskDoneDate() const
{
	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(htiSel);

		if (GetTask(dwID, tdi))
			return tdi.dateDone;
	}

	return COleDateTime();
}

BOOL CToDoCtrl::SetSelectedTaskStartDate(COleDateTime& date)
{
	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(htiSel);

		if (GetTask(dwID, tdi))
		{
			if (tdi.dateStart != date)
			{
				tdi.dateStart = date;
				UpdateTask(dwID, tdi);

				SetModified(TRUE, TDCA_STARTDATE);
			}
			return TRUE;
		}
	}

	return FALSE;
}

BOOL CToDoCtrl::SetSelectedTaskDoneDate(COleDateTime& date)
{
	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(htiSel);

		if (GetTask(dwID, tdi))
		{
			if (tdi.dateDone != date)
			{
				tdi.dateDone = date;
				UpdateTask(dwID, tdi);

				m_tcToDo.SetItemImage(htiSel, date.m_dt ? 1 : 0, date.m_dt ? 1 : 0);

				SetModified(TRUE, TDCA_DONEDATE);
			}
			return TRUE;
		}
	}

	return FALSE;
}

BOOL CToDoCtrl::SetSelectedTaskDueDate(COleDateTime& date)
{
	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(htiSel);

		if (GetTask(dwID, tdi))
		{
			if (tdi.dateDue != date)
			{
				tdi.dateDue = date;
				UpdateTask(dwID, tdi);
				
				if (IsTaskDue(htiSel))
					m_tcToDo.RedrawGutter();
			}

			SetModified(TRUE, TDCA_DUEDATE);
			return TRUE;
		}
	}

	return FALSE;
}

BOOL CToDoCtrl::GetTask(DWORD dwUniqueID, TODOITEM& tdi) const
{
	return m_mapTDItems.Lookup(dwUniqueID, tdi);
}

void CToDoCtrl::UpdateTask(DWORD dwUniqueID, const TODOITEM& tdi)
{
	ASSERT (dwUniqueID);

	TODOITEM tdiTemp;
	ASSERT (m_mapTDItems.Lookup(dwUniqueID, tdiTemp));

	if (dwUniqueID)
		m_mapTDItems[dwUniqueID] = tdi;
}

BOOL CToDoCtrl::GetSelectedTaskParentColor(COLORREF& color) const
{
	HTREEITEM htiParent = m_tcToDo.GetParentItem(GetSelectedItem());

	if (htiParent)
	{
		color = GetTaskColor(htiParent);
		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::GetSelectedTaskParentEstimate(double& dHours) const
{
	HTREEITEM htiParent = m_tcToDo.GetParentItem(GetSelectedItem());

	if (htiParent)
	{
		dHours = GetTaskEstimate(htiParent);
		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::GetSelectedTaskParentPerson(CString& sPerson) const
{
	HTREEITEM htiParent = m_tcToDo.GetParentItem(GetSelectedItem());

	if (htiParent)
	{
		sPerson = GetTaskPerson(htiParent);
		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::GetSelectedTaskParentPriority(int& nPriority) const
{
	HTREEITEM htiParent = m_tcToDo.GetParentItem(GetSelectedItem());

	if (htiParent)
	{
		nPriority = GetTaskPriority(htiParent);
		return TRUE;
	}

	return FALSE;
}

COLORREF CToDoCtrl::GetSelectedTaskColor() const
{
	return GetTaskColor(GetSelectedItem());
}

BOOL CToDoCtrl::SetSelectedTaskDone(BOOL bDone)
{
	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(htiSel);
		
		if (!GetTask(dwID, tdi))
			return FALSE;

		tdi.dateDone = bDone ? COleDateTime::GetCurrentTime() : COleDateTime();

		if (!bDone)
		{
			// restore last known percentage unless is 100%
			if (tdi.nPercentDone == 100)
				tdi.nPercentDone = 0;

			m_nPercentDone = tdi.nPercentDone;
			UpdateData(FALSE);
		}
		else if (m_nPercentDone != 100) // make it look right
		{
			m_nPercentDone = 100;
			UpdateData(FALSE);
		}

		UpdateTask(dwID, tdi);
		UpdateControls();

		m_tcToDo.SetItemImage(htiSel, bDone ? 1 : 0, bDone ? 1 : 0);
		m_tcToDo.UpdateWindow();

		SetModified(TRUE, TDCA_DONEDATE);

		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::IsSelectedTaskDone() const
{
	return IsTaskDone(GetSelectedItem());
}

BOOL CToDoCtrl::IsSelectedTaskDue() const
{
	return IsTaskDue(GetSelectedItem());
}

BOOL CToDoCtrl::IsTaskDone(HTREEITEM hti, DWORD dwExtraCheck) const
{
	if (!hti)
		return FALSE;

	TODOITEM tdi;
	
	if (!GetTask(m_tcToDo.GetItemData(hti), tdi))
		return FALSE;

	if (tdi.IsDone())
		return TRUE;

	if (dwExtraCheck & CHECKPARENT)
	{
		HTREEITEM htiParent = m_tcToDo.GetParentItem(hti);

		if (htiParent && IsTaskDone(htiParent, CHECKPARENT))
			return TRUE;
	}

	// else check children for 'good-as-done'
	if ((dwExtraCheck & CHECKCHILDREN) && HasStyle(TDCS_GRAYOUTSUBCOMPLETEDTASKS))
	{
		if (AreChildTasksDone(hti) == 1)
			return TRUE;
	}

	// else return as is
	return (tdi.IsDone());
}

BOOL CToDoCtrl::IsParentTaskDone(HTREEITEM hti) const
{
	if (!hti)
		return FALSE;

	HTREEITEM htiParent = m_tcToDo.GetParentItem(hti);

	if (!htiParent)
		return FALSE;

	TODOITEM tdiParent;
	
	if (!GetTask(m_tcToDo.GetItemData(htiParent), tdiParent))
		return FALSE;

	if (tdiParent.IsDone())
		return TRUE;

	// else check parent's parent
	return IsParentTaskDone(htiParent);
}


int CToDoCtrl::AreChildTasksDone(HTREEITEM hti) const
{
 	if (!m_tcToDo.ItemHasChildren(hti))
		return -1;

	// else check children and their children recursively
	TODOITEM tdi;
	HTREEITEM htiChild = m_tcToDo.GetChildItem(hti);

	while (htiChild)
	{
		int bDone = IsTaskDone(htiChild, CHECKCHILDREN);

		if (!bDone)
			return FALSE;

		// next
		htiChild = m_tcToDo.GetNextItem(htiChild, TVGN_NEXT);
	}

	return TRUE;
}

BOOL CToDoCtrl::IsTaskDue(HTREEITEM hti) const
{
	if (!hti)
		return FALSE;

	TODOITEM tdi;
	
	if (!GetTask(m_tcToDo.GetItemData(hti), tdi))
		return FALSE;

	return tdi.IsDue();
}
	
BOOL CToDoCtrl::SetSelectedTaskPercentDone(int nPercent)
{
	if (nPercent < 0 || nPercent > 100)
		return FALSE;

	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(htiSel);

		if (GetTask(dwID, tdi))
		{
			if (tdi.nPercentDone != nPercent)
			{
				tdi.nPercentDone = nPercent;
				UpdateTask(dwID, tdi);
				
				if (m_nPercentDone != nPercent)
				{
					m_nPercentDone = nPercent;
					UpdateData(FALSE);
				}

				SetModified(TRUE, TDCA_PERCENT);
			}
			return TRUE;
		}
	}

	return FALSE;
}

BOOL CToDoCtrl::SetSelectedTaskEstimate(double dHours)
{
	if (dHours < 0)
		return FALSE;

	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(htiSel);

		if (GetTask(dwID, tdi))
		{
			if (tdi.dTimeEstimate != dHours)
			{
				tdi.dTimeEstimate = dHours;
				UpdateTask(dwID, tdi);
				
				if (m_dTimeEstimate != dHours)
				{
					m_dTimeEstimate = dHours;
					UpdateData(FALSE);
				}

				SetModified(TRUE, TDCA_TIMEEST);
			}	
			
			return TRUE;
		}
	}

	return FALSE;
}

int CToDoCtrl::GetSelectedTaskPercentDone() const
{
	return GetSelectedTaskPercent(TRUE);
}

int CToDoCtrl::GetSelectedTaskPercent(BOOL bCheckIfDone) const
{
	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
	{
		TODOITEM tdi;

		if (GetTask(m_tcToDo.GetItemData(htiSel), tdi))
		{
			if (bCheckIfDone)
				return tdi.IsDone() ? 100 : tdi.nPercentDone;
			else
				return tdi.nPercentDone;
		}
	}

	return 0;
}

BOOL CToDoCtrl::SetSelectedTaskPerson(LPCTSTR szPerson)
{
	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(htiSel);

		if (GetTask(dwID, tdi))
		{
			if (tdi.sPerson.CompareNoCase(szPerson))
			{
				tdi.sPerson = szPerson;
				UpdateTask(dwID, tdi);
				
				if (m_sPerson != szPerson)
				{
					m_sPerson = szPerson;
					UpdateData(FALSE);
				}

				SetModified(TRUE, TDCA_PERSON);
			}
			return TRUE;
		}
	}

	return FALSE;
}

CString CToDoCtrl::GetSelectedTaskPerson() const
{
	return GetTaskPerson(GetSelectedItem());
}

BOOL CToDoCtrl::SetSelectedTaskFileRef(LPCTSTR szFilePath)
{
	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(htiSel);

		if (GetTask(dwID, tdi))
		{
			if (tdi.sFileRefPath.CompareNoCase(szFilePath))
			{
				tdi.sFileRefPath = szFilePath;
				UpdateTask(dwID, tdi);
				
				if (m_sFileRefPath != szFilePath)
				{
					m_sFileRefPath = szFilePath;
					UpdateData(FALSE);
				}

				SetModified(TRUE, TDCA_FILEREF);
			}
			return TRUE;
		}
	}

	return FALSE;
}

CString CToDoCtrl::GetSelectedTaskFileRef() const
{
	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
	{
		TODOITEM tdi;

		if (GetTask(m_tcToDo.GetItemData(htiSel), tdi))
			return tdi.sFileRefPath;
	}

	return "";
}

HTREEITEM CToDoCtrl::GetTopLevelTask(HTREEITEM htiSubtask) const
{
	if (!htiSubtask)
		return NULL;

	HTREEITEM htiParent = m_tcToDo.GetParentItem(htiSubtask);

	while (htiParent)
	{
		htiSubtask = htiParent;
		htiParent = m_tcToDo.GetParentItem(htiSubtask);
	}

	return htiSubtask;
}

HTREEITEM CToDoCtrl::NewTask(LPCTSTR szText, TDC_INSERTWHERE nWhere, BOOL bSelect, BOOL bEditText)
{
	if (!szText || !lstrlen(szText))
		return NULL;

	HTREEITEM htiSel = GetSelectedItem(), htiParent = NULL, htiAfter = NULL;

	// handle no selected item
	if (!htiSel)
	{
		switch (nWhere)
		{
		case TDC_INSERTATTOP:
		case TDC_INSERTATTOPOFSELTASKPARENT:
		case TDC_INSERTATTOPOFSELTASK:
		case TDC_INSERTBEFORESELTASK:
			htiParent = TVI_ROOT;
			htiAfter = TVI_FIRST;
			break;

		case TDC_INSERTATBOTTOM:
		case TDC_INSERTATBOTTOMOFSELTASKPARENT:
		case TDC_INSERTATBOTTOMOFSELTASK:
		case TDC_INSERTAFTERSELTASK:
			htiParent = TVI_ROOT;
			htiAfter = TVI_LAST; 
			break;
		}
	}

	// detrmine the actual pos to insert
	switch (nWhere)
	{
	case TDC_INSERTATTOP:
		htiParent = TVI_ROOT;
		htiAfter = TVI_FIRST;
		break;

	case TDC_INSERTATBOTTOM:
		htiParent = TVI_ROOT;
		htiAfter = TVI_LAST; 
		break;

	case TDC_INSERTATTOPOFSELTASKPARENT:
		htiParent = m_tcToDo.GetParentItem(htiSel);
		htiAfter = TVI_FIRST;
		break;

	case TDC_INSERTATBOTTOMOFSELTASKPARENT:
		htiParent = m_tcToDo.GetParentItem(htiSel);
		htiAfter = TVI_LAST;
		break;

	case TDC_INSERTAFTERSELTASK:
		htiParent = m_tcToDo.GetParentItem(htiSel);
		htiAfter = htiSel;

		if (!htiAfter)
			htiAfter = TVI_LAST;
		break;

	case TDC_INSERTBEFORESELTASK:
		htiParent = m_tcToDo.GetParentItem(htiSel);
		htiAfter = htiSel;

		if (!(htiAfter = m_tcToDo.GetNextItem(htiAfter, TVGN_PREVIOUS)))
			htiAfter = TVI_FIRST;
		break;

	case TDC_INSERTATTOPOFSELTASK: // subtask
		htiParent = htiSel;
		htiAfter = TVI_FIRST;
		break;

	case TDC_INSERTATBOTTOMOFSELTASK: // subtask
		htiParent = htiSel;
		htiAfter = TVI_LAST; 
		break;
	}

	return InsertItem(szText, htiParent, htiAfter, bSelect, bEditText);
}

HTREEITEM CToDoCtrl::InsertItem(LPCTSTR szText, HTREEITEM htiParent, HTREEITEM htiAfter, BOOL bSelect, BOOL bEdit)
{
	if (!szText || !lstrlen(szText))
		return NULL;

	// must create the new task item first
	TODOITEM tdiNew(szText);

	// and map it
	m_mapTDItems.SetAt(m_dwNextUniqueID, TODOITEM(szText));

	// bold state
	BOOL bBold = (!htiParent || htiParent == TVI_ROOT);

	HTREEITEM htiNew = m_tcToDo.InsertItem(TVIF_TEXT | TVIF_PARAM | TVIF_STATE,
											szText, 
											-1, // image not used
											-1, // sel image not used
											bBold ? TVIS_BOLD : 0, // state
											TVIS_BOLD, // state mask
											m_dwNextUniqueID, // lParam
											htiParent, 
											htiAfter);
	
	if (htiNew)
	{
		m_dwNextUniqueID++;
		SetModified(TRUE, TDCA_NONE);
		UpdateControls();
		
		if (bSelect)
		{
			m_tcToDo.SelectItem(htiNew);
			
			if (bEdit)
				m_tcToDo.EditLabel(htiNew);
			else
				m_tcToDo.SetFocus();
		}
	}
	else // cleanup
		m_mapTDItems.RemoveKey(m_dwNextUniqueID);
	
	return htiNew;
}

BOOL CToDoCtrl::DeleteSelectedTask()
{
	HTREEITEM htiSel = GetSelectedItem();

	if (!htiSel)
		return FALSE;

	// if need confirmation then make sure the user knows that child items will get removed too
	if (HasStyle(TDCS_CONFIRMDELETE))
	{
		CString sMessage("Are you sure you want to delete the selected task?");

		if (m_tcToDo.ItemHasChildren(htiSel))
			sMessage += "\n\n(ATTENTION: This task has subtasks which will also be deleted)";

		if (MessageBox(sMessage, "Confirm Delete", MB_YESNO | MB_DEFBUTTON2) != IDYES)
			return FALSE;
	}

	// do it
	CHoldRedraw hr(this);

	if (DeleteTask(htiSel))
	{
		SetModified(TRUE, TDCA_NONE);
		UpdateControls();

		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::DeleteTask(HTREEITEM hti)
{
	// do children first to ensure entire branch is deleted
	HTREEITEM htiChild = m_tcToDo.GetChildItem(hti);

	while (htiChild)
	{
		DeleteTask(htiChild);
		htiChild = m_tcToDo.GetNextItem(htiChild, TVGN_NEXT);
	}

	// then this item
	DWORD dwID = m_tcToDo.GetItemData(hti);
	
	if (m_tcToDo.DeleteItem(hti))
	{
		// delete mapping
		m_mapTDItems.RemoveKey(dwID);
		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::EditSelectedTask()
{
	HTREEITEM htiSel = GetSelectedItem();

	if (htiSel)
		return (NULL != m_tcToDo.EditLabel(htiSel));

	return FALSE;
}

void CToDoCtrl::OnTreeEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;

	if (pTVDispInfo->item.pszText) // not cancelled
	{
		TODOITEM tdi;
		DWORD dwID = m_tcToDo.GetItemData(pTVDispInfo->item.hItem);

		if (GetTask(dwID, tdi))
		{
			if (tdi.sTitle != pTVDispInfo->item.pszText)
			{
				tdi.sTitle = pTVDispInfo->item.pszText;
				UpdateTask(dwID, tdi);

				SetModified(TRUE, TDCA_TASKNAME);
			}
		}
	}

	*pResult = (pTVDispInfo->item.pszText != NULL); // accept text
}

void CToDoCtrl::OnTreeBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;
	
	*pResult = 0;
}

BOOL CToDoCtrl::DeleteAllTasks()
{
	if (!HasStyle(TDCS_CONFIRMDELETE) || MessageBox("Are you sure you want to delete all the tasks in this task list?",
								"Confirm Delete", MB_YESNO | MB_DEFBUTTON2) == IDYES)
	{
		CHoldRedraw hr(this);

		if (GetCount())
		{
			m_tcToDo.DeleteAllItems();
			m_mapTDItems.RemoveAll();

			SetModified(TRUE, TDCA_NONE);
			UpdateControls();

			return TRUE;
		}
	}

	return FALSE;
}

void CToDoCtrl::SetStyle(DWORD dwStyle, BOOL bOn)
{
	ASSERT (GetSafeHwnd());

	bOn = bOn ? TRUE : FALSE; // normalize

	if (bOn != HasStyle(dwStyle))
	{
		if (bOn)
			m_dwStyle |= dwStyle;
		else
			m_dwStyle &= ~dwStyle;

		switch (dwStyle)
		{
		case TDCS_SHOWINFOTIPS:
			m_tcToDo.ModifyStyle(bOn ? 0 : TVS_INFOTIP, bOn ? TVS_INFOTIP : 0);
			break;

		case TDCS_SHOWBUTTONSINTREE:
			m_tcToDo.ModifyStyle(bOn ? 0 : TVS_LINESATROOT | TVS_HASBUTTONS, bOn ? TVS_LINESATROOT | TVS_HASBUTTONS : 0);
			break;

		case TDCS_COLORTEXTBYPRIORITY:
		case TDCS_SHOWCOMMENTSINLIST:
		case TDCS_GRAYOUTSUBCOMPLETEDTASKS:
			Invalidate(FALSE);
			break;

		case TDCS_COLORPRIORITY:
		case TDCS_HIDEPERCENTSUBCOMPLETEDTASKS:
		case TDCS_INCLUDEDONEINAVERAGECALC:
			m_tcToDo.RedrawGutter();
			break;

		case TDCS_AVERAGEPERCENTSUBCOMPLETION:
			UpdateControls();
			m_tcToDo.RedrawGutter();
			break;

		case TDCS_SIMPLEMODE:
			// ensure focus is ok
			if (bOn)
				m_tcToDo.SetFocus();

			UpdateControls();
			Resize();
			break;

		case TDCS_SHOWCTRLSASCOLUMNS:
		case TDCS_SHOWCOMMENTSALWAYS:
			UpdateControls();
			Resize();
			break;

		case TDCS_FIXEDCOMMENTHEIGHT:
			Resize();
			break;
		}
	}
}

void CToDoCtrl::ShowColumn(TDC_COLUMN nColumn, BOOL bShow)
{
	// special case
	if (nColumn == TDCC_POSITION)
		m_tcToDo.ShowGutterPosColumn(bShow);
	else
	{
		DWORD dwPrevColumns = m_dwVisibleColumns;
		DWORD dwColumn = (2 << (int)nColumn);

		if (bShow)
			m_dwVisibleColumns |= dwColumn;
		else
			m_dwVisibleColumns &= ~dwColumn;

		if (m_dwVisibleColumns != dwPrevColumns)
		{
			m_tcToDo.RecalcGutter();

			// hide/show controls which may have been affected
			UpdateControls();

			// and resize to allow for control realignment
			Resize();
		}
	}
}

BOOL CToDoCtrl::IsColumnShowing(TDC_COLUMN nColumn) const
{
	DWORD dwColumn = (2 << (int)nColumn);

	return ((m_dwVisibleColumns & dwColumn) == dwColumn);
}

BOOL CToDoCtrl::Save(LPCTSTR szFilePath, BOOL bCheckforLaterChanges)
{
	ASSERT (GetSafeHwnd());

	if (!GetSafeHwnd())
		return FALSE;

	UpdateData();

	// check for later changes (multi-user usage)
	if (bCheckforLaterChanges && m_nFileVersion > 0) // else its newly created
	{
		if (GetFileAttributes(szFilePath) != 0xffffffff) // file exists (sanity check)
		{
			// i was going to use filetimes but these are too unreliable
			// instead we open the xml file and look at its internal version
			CXmlFile temp("TODOLIST");

			if (temp.Load(szFilePath))
			{
				if (temp.GetItemValueI("FILEVERSION") > m_nFileVersion)
				{
					CString sMessage;
					sMessage.Format("The tasklist '%s' has been modified \nsince you opened it or last saved your changes.\n\nIf you continue you will overwrite those changes.\n\nAre you sure you want to proceed?", szFilePath);

					if (AfxMessageBox(sMessage,	MB_ICONWARNING | MB_YESNO) == IDNO)
						return FALSE;
				}
			}
		}
	}

	CXmlFile file("TODOLIST");

	AddChildren(NULL, file.Root(), TDCF_ALL);

	// file header info
	if (IsModified())
		m_nFileVersion++;

	file.SetHeader(m_sXmlHeader);
	file.AddItem("FILEFORMAT", FILEFORMAT);
	file.AddItem("FILEVERSION", m_nFileVersion);
	file.AddItem("LASTMODIFIED", COleDateTime::GetCurrentTime().Format(VAR_DATEVALUEONLY));
	file.AddItem("PROJECTNAME", m_sProjectName);

	// save sort status
	file.AddItem("LASTSORTBY", m_nSortBy);
	file.AddItem("LASTSORTDIR", m_bSortAscending);

	// and next unique ID
	file.AddItem("NEXTUNIQUEID", (int)m_dwNextUniqueID);

	if (m_bArchive)
		file.AddItem("ARCHIVE", 1);
	
	if (file.Save(szFilePath, TRUE))
	{
		m_sLastSavePath = szFilePath;
		m_bModified = FALSE;

		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::AddItem(HTREEITEM hti, CXmlItem* pXI, TDC_FILTER nFilter, int nPos) const
{
	// attributes
	TODOITEM tdi;
	DWORD dwID = m_tcToDo.GetItemData(hti);

	if (GetTask(dwID, tdi))
	{
		// special optimization check for TDC_FULLYDONE and TDC_NOTFULLYDONE
		if (nFilter == TDCF_FULLYDONE || nFilter == TDCF_NOTFULLYDONE)
		{
			BOOL bDone = IsTaskFullyDone(hti, tdi, TRUE);

			if (nFilter == TDCF_FULLYDONE && !bDone)
				return FALSE;

			else if (nFilter == TDCF_NOTFULLYDONE && bDone)
				return FALSE;

			// else carryon
		}

		CXmlItem* pXIItem = pXI->AddItem("TASK");

		// unique ID
		if (nFilter != TDCF_VISIBLE || IsColumnShowing(TDCC_ID))
			pXIItem->AddItem("ID", (int)dwID);
	
		// attributes
		pXIItem->AddItem("TITLE", tdi.sTitle);
		
		if (!tdi.sComments.IsEmpty())
		{
			CXmlItem* pXIComments = pXIItem->AddItem("COMMENTS", tdi.sComments);

			if (pXIComments)
				pXIComments->SetNotAttribute(); // attributes have a total max length of 1024
		}
		
		if (!tdi.sPerson.IsEmpty() && (nFilter != TDCF_VISIBLE || IsColumnShowing(TDCC_PERSON)))
			pXIItem->AddItem("PERSON", tdi.sPerson);
		
		if (!tdi.sFileRefPath.IsEmpty() && (nFilter != TDCF_VISIBLE || IsColumnShowing(TDCC_FILEREF)))
			pXIItem->AddItem("FILEREFPATH", tdi.sFileRefPath);
		
		if (tdi.color)
		{
			pXIItem->AddItem("COLOR", (int)tdi.color);
			
			// this is to help display the date in a web page
			CString sWebColor;
			sWebColor.Format("#%02X%02X%02X", GetRValue(tdi.color), GetGValue(tdi.color), GetBValue(tdi.color));
			pXIItem->AddItem("WEBCOLOR", sWebColor);
		}
		
		if (nFilter != TDCF_VISIBLE || IsColumnShowing(TDCC_PRIORITY))
			pXIItem->AddItem("PRIORITY", (int)tdi.nPriority);
		
		if (tdi.nPercentDone && (nFilter != TDCF_VISIBLE || IsColumnShowing(TDCC_PERCENT)))
			pXIItem->AddItem("PERCENTDONE", (int)tdi.nPercentDone);
		
		if (tdi.dTimeEstimate > 0 && (nFilter != TDCF_VISIBLE || IsColumnShowing(TDCC_TIMEEST)))
			pXIItem->AddItem("TIMEESTIMATE", tdi.dTimeEstimate);
		
		if (tdi.IsDone() && (nFilter != TDCF_VISIBLE || IsColumnShowing(TDCC_DONEDATE)))
		{
			pXIItem->AddItem("DONEDATE", tdi.dateDone);
			
			// this is to help display the date in a web page
			pXIItem->AddItem("DONEDATESTRING", COleDateTime(tdi.dateDone).Format(VAR_DATEVALUEONLY));
		}
		
		if (tdi.HasDue() && (nFilter != TDCF_VISIBLE || IsColumnShowing(TDCC_DUEDATE)))
		{
			pXIItem->AddItem("DUEDATE", tdi.dateDue);
			
			// this is to help display the date in a web page
			pXIItem->AddItem("DUEDATESTRING", COleDateTime(tdi.dateDue).Format(VAR_DATEVALUEONLY));
		}
		
		if (tdi.HasStart() && (nFilter != TDCF_VISIBLE || IsColumnShowing(TDCC_STARTDATE)))
		{
			pXIItem->AddItem("STARTDATE", tdi.dateStart);
			
			// this is to help display the date in a web page
			pXIItem->AddItem("STARTDATESTRING", COleDateTime(tdi.dateStart).Format(VAR_DATEVALUEONLY));
		}

		// items position
		if (nFilter != TDCF_VISIBLE || IsColumnShowing(TDCC_POSITION))
			pXIItem->AddItem("POS", nPos);

		// children
		int nChildren = AddChildren(hti, pXIItem, nFilter);

		// we return TRUE if we match the filter or we have any matching children
		BOOL bMatch = nChildren;

		switch (nFilter)
		{
		case TDCF_ALL:
		case TDCF_VISIBLE:
		case TDCF_FULLYDONE: // we did a check at the start
		case TDCF_NOTFULLYDONE: // we did a check at the start
			bMatch = TRUE; // always
			break;
			
		case TDCF_DUE:
			bMatch |= tdi.IsDue();
			break;
			
		case TDCF_DONE:
			bMatch |= tdi.IsDone();
			break;
			
		case TDCF_NOTDONE:
			bMatch |= !tdi.IsDone();
			break;

		default:
			bMatch = FALSE;
		}
		
		// if we don't match, we remove the item
		if (!bMatch)
			pXI->DeleteItem(pXIItem);

		return bMatch;
	}

	return FALSE;
}

int CToDoCtrl::AddChildren(HTREEITEM hti, CXmlItem* pXI, TDC_FILTER nFilter) const
{
	// if hti == NULL it means the root
	HTREEITEM htiChild = hti ? m_tcToDo.GetChildItem(hti) : m_tcToDo.GetNextItem(NULL, TVGN_CHILD);
	int nChildren = 0;
	int nPos = 1; // positions are 1-based

	while (htiChild)
	{
		if (AddItem(htiChild, pXI, nFilter, nPos))
			nChildren++;

		// next
		nPos++;
		htiChild = m_tcToDo.GetNextItem(htiChild, TVGN_NEXT);
	}

	return nChildren;
}

BOOL CToDoCtrl::Load(LPCTSTR szFilePath, LPCTSTR szArchivePath, TDC_ARCHIVE nRemove)
{
	ASSERT (GetSafeHwnd());

	if (!GetSafeHwnd())
		return FALSE;

	SaveExpandedState();

	CXmlFile file("TODOLIST");
	
	if (file.Load(szFilePath))
	{
		m_sLastSavePath = szFilePath;

		// file header info
		m_sXmlHeader = file.GetHeader();
		m_nFileFormat = file.GetItemValueI("FILEFORMAT");
		m_nFileVersion = file.GetItemValueI("FILEVERSION");
		m_sProjectName = file.GetItemValue("PROJECTNAME");
		m_bArchive = file.GetItemValueI("ARCHIVE");

		// load last sort status
		if (file.GetItem("LASTSORTBY"))
		{
			m_nSortBy = (TDC_SORTBY)file.GetItemValueI("LASTSORTBY");
			m_bSortAscending = file.GetItemValueI("LASTSORTDIR");
		}

		// enxt unique ID
		m_dwNextUniqueID = file.GetItemValueI("NEXTUNIQUEID");

		// backwards compatibility
		if (!m_dwNextUniqueID)
			m_dwNextUniqueID = 1;

		CHoldRedraw hr2(&m_tcToDo);
		CHoldRedraw hr1(this);
		m_tcToDo.DeleteAllItems();

		HTREEITEM htiFirst = AddItem(file.Root(), NULL);

		if (szArchivePath && lstrlen(szArchivePath) && ArchiveDoneTasks(szArchivePath, nRemove, FALSE))
			m_bModified = TRUE;
		else
			m_bModified = FALSE;

		m_bModSinceLastSort = TRUE; // to preserve the last sort direction

		// restore last expanded state
		LoadExpandedState();

		m_tcToDo.SelectItem(htiFirst);
		m_tcToDo.SetFocus();

		// init column header
		TDCCOLUMN* pTDCC = GetColumn(m_nSortBy);

		if (pTDCC)
			m_tcToDo.PressGutterColumnHeader(pTDCC->nPos);
		else
			m_tcToDo.PressGutterColumnHeader(-1);

		UpdateData(FALSE);

		return TRUE;
	}

	return FALSE;
}

int CToDoCtrl::ArchiveDoneTasks(LPCTSTR szFilePath, TDC_ARCHIVE nRemove, BOOL bFlickerFree)
{
	// can't archive archives
	if (m_bArchive)
		return 0;

	if (!GetCount() || !szFilePath || !lstrlen(szFilePath))
		return 0;

	// 1. first see if there's anything to archive
	CXmlItem xiDone;

	int nNumAdded = AddChildren(NULL, &xiDone, TDCF_DONE);

	if (!nNumAdded)
		return 0;

	SaveExpandedState();

	// 2. load existing archive if present
	CXmlFile file("TODOLIST");

	if (file.Load(szFilePath))
	{
		VERIFY(file.GetItemValue("ARCHIVE"));

		CXmlItem* pXI = file.GetItem("FILEVERSION");

		if (pXI)
			pXI->SetValue(pXI->GetValueI() + 1);
		else
			file.AddItem("FILEVERSION", 1);
	}
	else // or initialize first time
	{
		file.AddItem("ARCHIVE", 1);
		file.AddItem("FILEFORMAT", FILEFORMAT);
		file.AddItem("FILEVERSION", 1);
		file.AddItem("LASTMODIFIED", COleDateTime::GetCurrentTime().Format(VAR_DATEVALUEONLY));
		file.AddItem("PROJECTNAME", m_sProjectName);
	}

	// 3. merge in new done items
	Merge(&xiDone, file.Root());

	// 4. save archive
	file.Save(szFilePath, TRUE);

	// 5. remove archived tasks from current list
	if (nRemove != TDC_REMOVENONE)
	{
		file.Reset();

		if (bFlickerFree)
			m_tcToDo.SetRedraw(FALSE);

		// filter
		TDC_FILTER nFilter = TDCF_ALL;

		switch (nRemove)
		{
		case TDC_REMOVEALL:
			nFilter = TDCF_NOTDONE;
			break;

		case TDC_REMOVEIFSIBLINGSANDSUBTASKSCOMPLETE:
			nFilter = TDCF_NOTFULLYDONE;
			break;

		default:
			ASSERT (0);
		}

		if (AddChildren(NULL, file.Root(), nFilter))
		{
			m_tcToDo.DeleteAllItems();
			AddItem(file.Root(), NULL);
		}
		else
			m_tcToDo.DeleteAllItems();

		// we only need to this if we've rebuilt the tree
		LoadExpandedState();

		if (bFlickerFree)
			m_tcToDo.SetRedraw(TRUE);
	}

	return (nRemove == TDC_REMOVEALL) ? nNumAdded : 0;
}

int CToDoCtrl::ArchiveDoneTasks(LPCTSTR szFilePath, TDC_ARCHIVE nRemove)
{
	// this is only called externally so we need to specify flicker free
	int nRes = ArchiveDoneTasks(szFilePath, nRemove, TRUE);

	if (nRes)
		SetModified(TRUE, TDCA_NONE);

	return nRes;
}

BOOL CToDoCtrl::Import(LPCTSTR szFilePath)
{
	CXmlFile fileSrc("TODOLIST"), fileDest("TODOLIST");

	if (!fileSrc.Load(szFilePath))
		return FALSE;

	SaveExpandedState();

	AddChildren(NULL, fileDest.Root(), TDCF_ALL);

	Merge(fileSrc.Root(), fileDest.Root());
	
	CHoldRedraw hr2(&m_tcToDo);
	CHoldRedraw hr1(this);
	m_tcToDo.DeleteAllItems();
	
	HTREEITEM htiFirst = AddItem(fileDest.Root(), NULL);

	LoadExpandedState();
	
	m_tcToDo.SelectItem(htiFirst);
	m_tcToDo.SetFocus();
	
	m_bModified = TRUE;
	UpdateData(FALSE);
	
	return TRUE;
}

void CToDoCtrl::Merge(const CXmlItem* pXISrc, CXmlItem* pXIDest)
{
	// if both these items are root items (have no parents) then we just
	// merge their children else if the task name does not match then we don't merge
	if (pXISrc->GetParent())
	{
		ASSERT (lstrcmp(pXISrc->GetName(), "TASK") == 0);
		ASSERT (pXISrc->NameMatches(pXIDest));
		ASSERT (pXIDest->GetParent());
		ASSERT (pXISrc->ItemValueMatches(pXIDest, "TITLE"));

		if (!pXISrc->ItemValueMatches(pXIDest, "TITLE"))
			return;
	}

	// merge children
	// essentially we simply add whatever tasks exist in pXISrc which do not exist in pXIDest
	// and merge duplicates
	const CXmlItem* pXISrcChild = pXISrc->GetItem("TASK");

	while (pXISrcChild)
	{
		// cycle pXIDest children looking for a match
		CXmlItem* pXIDestChild = pXIDest->GetItem("TASK");

		while (pXIDestChild)
		{
			if (pXISrcChild->ItemValueMatches(pXIDestChild, "TITLE")) // names match so merge
			{
				Merge(pXISrcChild, pXIDestChild);
				break; // done
			}
			// next task
			pXIDestChild = pXIDestChild->GetSibling();
		}
			
		// if no match found then simply copy src to dest
		if (!pXIDestChild)
			pXIDest->AddItem(*pXISrcChild);

		pXISrcChild = pXISrcChild->GetSibling();
	}
}

HTREEITEM CToDoCtrl::AddItem(const CXmlItem* pXI, HTREEITEM htiParent)
{
	HTREEITEM hti = TVI_ROOT; // default for root item

	if (htiParent)
	{
		// add new task to map
		TODOITEM tdi;

		tdi.sTitle = pXI->GetItemValue("TITLE");
		tdi.sComments = pXI->GetItemValue("COMMENTS");
		tdi.sPerson = pXI->GetItemValue("PERSON");
		tdi.color = pXI->GetItemValueI("COLOR");
		tdi.nPercentDone = pXI->GetItemValueI("PERCENTDONE");
		tdi.dTimeEstimate = pXI->GetItemValueF("TIMEESTIMATE");
		tdi.sFileRefPath = pXI->GetItemValue("FILEREFPATH");

		// if file fmt == 0 then massage the priority field
		tdi.nPriority = pXI->GetItemValueI("PRIORITY");

		if (m_nFileFormat == 0)
			tdi.nPriority = (tdi.nPriority == 1 ? 5 : (tdi.nPriority == 2 ? 10 : 0));

		tdi.dateDue = pXI->GetItemValueF("DUEDATE");
		tdi.dateStart = pXI->GetItemValueF("STARTDATE");
		tdi.dateDone = pXI->GetItemValueF("DONEDATE");

//		if (tdi.dateDone > 0)
//			tdi.nPercentDone = 100;

		// add items to map
		DWORD dwUniqueID = pXI->GetItemValueI("ID");

		// backward compatibility
		if (!dwUniqueID)
			dwUniqueID = m_dwNextUniqueID++;

		m_mapTDItems[dwUniqueID] = tdi;

		// add this item to tree
		int nImage = (tdi.dateDone > 0) ? 1 : 0;
		hti = m_tcToDo.InsertItem(tdi.sTitle, nImage, nImage, htiParent);

		m_tcToDo.SetItemData(hti, dwUniqueID);
		m_tcToDo.SetItemState(hti, (htiParent == TVI_ROOT) ? TVIS_BOLD : 0, TVIS_BOLD);

		// add unique 'persons' to person combobox
		if (!tdi.sPerson.IsEmpty() && m_cbPerson.FindString(-1, tdi.sPerson) == CB_ERR)
			m_cbPerson.AddString(tdi.sPerson);
	}

	// then children
	const CXmlItem* pXIChild = pXI->GetItem("TASK");
	HTREEITEM htiFirstItem = (hti == TVI_ROOT) ? NULL : hti;

	while (pXIChild)
	{
		HTREEITEM htiChild = AddItem(pXIChild, hti);

		if (!htiFirstItem)
			htiFirstItem = htiChild;

		pXIChild = pXIChild->GetSibling(); // next
	}

	return htiFirstItem;
}

void CToDoCtrl::OnTreeCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMCUSTOMDRAW* pNMCD = (NMCUSTOMDRAW*)pNMHDR;

	if (pNMCD->dwDrawStage == CDDS_PREPAINT)
		*pResult |= CDRF_NOTIFYITEMDRAW | CDRF_NOTIFYPOSTPAINT;	
		
	else if (pNMCD->dwDrawStage == CDDS_ITEMPREPAINT)
	{
		NMTVCUSTOMDRAW* pTVCD = (NMTVCUSTOMDRAW*)pNMCD;
		TODOITEM tdi;
		
		// set fonts and colors
		if (GetTask((DWORD)pTVCD->nmcd.lItemlParam, tdi))
		{
			HTREEITEM hti = (HTREEITEM)pTVCD->nmcd.dwItemSpec;
			BOOL bSelected = (pNMCD->uItemState & CDIS_SELECTED);

			BOOL bDone = IsTaskDone(hti);
			BOOL bGoodAsDone = IsTaskDone(hti, CHECKPARENT | CHECKCHILDREN);
			
			if (!bSelected)
			{
				COLORREF crOrg = pTVCD->clrText;

				if (bDone || bGoodAsDone)
					pTVCD->clrText = RGB(196, 196, 196); // parent and/or item is done

				else if (tdi.IsDue())
				{
					if (HasStyle(TDCS_COLORTEXTBYPRIORITY))
						pTVCD->clrText = CalcPriorityColor(10);
					else
						pTVCD->clrText = 255;
				}
				else if (HasStyle(TDCS_COLORTEXTBYPRIORITY))
					pTVCD->clrText = CalcPriorityColor(tdi.nPriority); 

				else if (tdi.color)
					pTVCD->clrText = tdi.color; 

				if (pTVCD->clrText != crOrg)
					*pResult |= CDRF_NEWFONT;
			}

			if (bDone)
			{
				CDC* pDC = CDC::FromHandle(pNMCD->hdc);
				pDC->SelectObject(m_fontDone);

				*pResult |= CDRF_NEWFONT;
			}
		}
	}
	else if (pNMCD->dwDrawStage == CDDS_ITEMPOSTPAINT)
	{
		NMTVCUSTOMDRAW* pTVCD = (NMTVCUSTOMDRAW*)pNMCD;
		TODOITEM tdi;

		// set fonts and colors for columns
		if (GetTask((DWORD)pTVCD->nmcd.lItemlParam, tdi))
		{
			tdi.sComments.Replace("\r\n", " ");

			if (!tdi.sComments.IsEmpty())
			{
				CDC* pDC = CDC::FromHandle(pNMCD->hdc);
				int nDC = pDC->SaveDC();

				HTREEITEM hti = (HTREEITEM)pTVCD->nmcd.dwItemSpec;

				BOOL bDone = IsTaskDone(hti);
				BOOL bGoodAsDone = IsTaskDone(hti, CHECKPARENT | CHECKCHILDREN);
				
				pDC->SetTextColor(bGoodAsDone ? RGB(196, 196, 196) : RGB(98, 98, 98));

				if (bDone)
					pDC->SelectObject(m_fontDone);

				CString sTemp("[see comments]");

				if (HasStyle(TDCS_SHOWCOMMENTSINLIST))
					sTemp.Format("[%s]", tdi.sComments);

				CRect rClient, rText;
				m_tcToDo.GetItemRect((HTREEITEM)pTVCD->nmcd.dwItemSpec, rText, TRUE);

				rText.top++;
				rText.left = rText.right + 4;
				rText.right = pTVCD->nmcd.rc.right;
				
				pDC->SetBkMode(TRANSPARENT);
				pDC->ExtTextOut(rText.left, rText.top, ETO_CLIPPED, &rText, sTemp, NULL);

				pDC->RestoreDC(nDC);
			}			
		}
	}
}

void CToDoCtrl::OnTreeClick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// see if the click was on the 'done' checkbox
	CPoint point(::GetMessagePos());
	m_tcToDo.ScreenToClient(&point);

	UINT nFlags = 0;
	HTREEITEM htiHit = m_tcToDo.HitTest(point, &nFlags);

	if (htiHit && (nFlags & TVHT_ONITEMICON))
	{
		SetSelectedTaskDone(!IsSelectedTaskDone());
		UpdateControls();

		SetModified(TRUE, TDCA_DONEDATE);
	}
	else if (!htiHit)
		m_tcToDo.SelectItem(NULL);

	*pResult = 0;
}

void CToDoCtrl::OnTreeDblClk(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CPoint point(::GetMessagePos());
	m_tcToDo.ScreenToClient(&point);

	UINT nFlags = 0;
	HTREEITEM htiHit = m_tcToDo.HitTest(point, &nFlags);

	if (htiHit && (nFlags & TVHT_ONITEMLABEL) && !m_tcToDo.ItemHasChildren(htiHit))
	{
		// we have to post this for reasons i haven't been able to figure.
		// if we send it, the edit finishes immediately
		// (later) i now think that this may be related to the lbuttonup which follows this
		m_tcToDo.PostMessage(TVM_EDITLABEL, 0, (LPARAM)htiHit);
	}

	*pResult = 0;
}

void CToDoCtrl::PreSubclassWindow() 
{
	if (!m_fontDone.GetSafeHandle()) // create first time
	{
		CFont* pFont = GetFont();

		if (!pFont)
			pFont = CFont::FromHandle((HFONT)GetStockObject(ANSI_VAR_FONT));
					
		LOGFONT lf;
		pFont->GetLogFont(&lf);
					
		lf.lfStrikeOut = TRUE;
					
		m_fontDone.CreateFontIndirect(&lf);
	}
	
	CRuntimeDlg::PreSubclassWindow();
}

void CToDoCtrl::OnDestroy() 
{
	// save expanded state
	SaveExpandedState();

	// reset copied item if its us
	if (s_pCopySrc == this)
	{
		s_pCopySrc = NULL;
		s_dwCopySrc = 0;
	}

	CRuntimeDlg::OnDestroy();
	
	m_fontDone.DeleteObject();	
}

LRESULT CToDoCtrl::OnTreeEndDrag(WPARAM wParam, LPARAM lParam)
{
	HTREEITEM hti = (HTREEITEM)wParam;
	BOOL bCopy = lParam;

	// if it was a copy then we need to create copies of all the TODOITEMs
	// and update the item data values to be unique
	if (bCopy)
		RebuildCopiedItem(hti);

	// check the bold state is correct
	HTREEITEM htiParent = m_tcToDo.GetParentItem(hti);
	m_tcToDo.SetItemState(hti, (!htiParent || htiParent == TVI_ROOT) ? TVIS_BOLD : 0, TVIS_BOLD);
	SetModified(TRUE, TDCA_NONE);

	return 0;
}

void CToDoCtrl::RebuildCopiedItem(HTREEITEM hti)
{
	TODOITEM tdiOrg;

	ASSERT (GetTask(m_tcToDo.GetItemData(hti), tdiOrg));

	if (GetTask(m_tcToDo.GetItemData(hti), tdiOrg))
	{
		m_mapTDItems.SetAt(m_dwNextUniqueID, tdiOrg);

		m_tcToDo.SetItemData(hti, m_dwNextUniqueID);
		m_dwNextUniqueID++;

		// children
		HTREEITEM htiChild = m_tcToDo.GetChildItem(hti);

		while (htiChild)
		{
			RebuildCopiedItem(htiChild);
			htiChild = m_tcToDo.GetNextItem(htiChild, TVGN_NEXT);
		}
	}
}

void CToDoCtrl::SetModified(BOOL bMod)
{
	m_bModified = bMod;
	m_bModSinceLastSort = TRUE; // always
}

// internal version
void CToDoCtrl::SetModified(BOOL bMod, TDC_ATTRIBUTE nAttrib)
{
	SetModified(bMod);

	if (bMod)
	{
		// redraw the gutter if the associated column is visible
		BOOL bRedraw = FALSE, bRecalc = FALSE;

		switch (nAttrib)
		{
		case TDCA_DONEDATE:
			bRedraw = IsColumnShowing(TDCC_DONEDATE);
			Invalidate(); // text color can be affected
			break;

		case TDCA_DUEDATE:
			bRedraw = IsColumnShowing(TDCC_DUEDATE);
			Invalidate(); // text color can be affected 
			break;

		case TDCA_STARTDATE:
			bRedraw = IsColumnShowing(TDCC_STARTDATE);
			break;

		case TDCA_PRIORITY:
			bRedraw = IsColumnShowing(TDCC_PRIORITY);
			Invalidate(); // text color can be affected 
			break;

		case TDCA_PERSON:
			bRedraw = IsColumnShowing(TDCC_PERSON);
			break;

		case TDCA_PERCENT:
			bRedraw = IsColumnShowing(TDCC_PERCENT);
			Invalidate(); // text color can be affected 
			break;

		case TDCA_TIMEEST:
			bRecalc = IsColumnShowing(TDCC_TIMEEST);
			break;

		case TDCA_FILEREF:
			bRedraw = IsColumnShowing(TDCC_FILEREF);
			break;
		}

		if (bRecalc)
			m_tcToDo.RecalcGutter();

		else if (bRedraw)
			m_tcToDo.RedrawGutter();

		UpdateWindow();
		GetParent()->SendMessage(WM_TDCN_MODIFY, GetDlgCtrlID(), (LPARAM)nAttrib);
	}
}

void CToDoCtrl::OnChangeComments()
{
	UpdateTask(TDCA_COMMENTS);
}

void CToDoCtrl::OnChangeFileRefPath()
{
	UpdateTask(TDCA_FILEREF);
}

void CToDoCtrl::OnChangeProjectName()
{
	UpdateData();
	SetModified(TRUE, TDCA_PROJNAME);
}

void CToDoCtrl::InvalidateSelectedItem()
{
	CRect rItem;
	
	if (m_tcToDo.GetItemRect(GetSelectedItem(), rItem, FALSE))
		m_tcToDo.InvalidateRect(rItem, FALSE);
}

void CToDoCtrl::Sort(TDC_SORTBY nBy)
{
	TRACE ("CToDoCtrl::Sort().begin\n");

	CHoldRedraw hr(&m_tcToDo);

	if (m_bSortAscending == -1 || nBy != m_nSortBy)
		m_bSortAscending = TRUE;

	// if there's been a mod since last sorting then its reasonable to assume
	// that the user is not toggling direction but wants to simply resort
	// in the same direction.
	else if (!m_bModSinceLastSort)
		m_bSortAscending = !m_bSortAscending;

	// update the column header
	TDCCOLUMN* pTDCC = GetColumn(nBy);

	if (pTDCC)
		m_tcToDo.PressGutterColumnHeader(pTDCC->nPos);
	else
		m_tcToDo.PressGutterColumnHeader(-1);

	DWORD dwTick = GetTickCount();
	Sort(NULL, nBy, m_bSortAscending);
	TRACE ("CToDoCtrl::Sort(%d ms)\n", GetTickCount() - dwTick);

	SetModified(TRUE, TDCA_NONE);

	m_nSortBy = nBy;
	m_bModSinceLastSort = FALSE;

	TRACE ("CToDoCtrl::Sort().end\n");
}

void CToDoCtrl::Sort(HTREEITEM hti, TDC_SORTBY nBy, BOOL bAscending)
{
	CHTIMap mapHTI;
	BuildHTIMap(mapHTI);

	SORTSTRUCT ss = { this, &m_mapTDItems, &mapHTI, nBy, bAscending };
	TVSORTCB tvs = { hti, CompareFunc, (LPARAM)&ss };

	// sort this items children first
	m_tcToDo.SortChildrenCB(&tvs);

	// then its childrens children
	HTREEITEM htiChild = hti ? m_tcToDo.GetChildItem(hti) : m_tcToDo.GetNextItem(NULL, TVGN_CHILD);

	while (htiChild)
	{
		Sort(htiChild, nBy, bAscending);
		
		htiChild = m_tcToDo.GetNextItem(htiChild, TVGN_NEXT);
	}
}

int CALLBACK CToDoCtrl::CompareFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	SORTSTRUCT* pSS = (SORTSTRUCT*)lParamSort;

	// sort by id can be optimized since the IDs are the lParams
	if (pSS->nSortBy == TDC_SORTBYID)
		return pSS->bAscending ? lParam1 - lParam2 : lParam2 - lParam1;

	// else all the rest require the task lookup
	TODOITEM tdi1, tdi2;
	
	VERIFY(pSS->pMapTDItems->Lookup(lParam1, tdi1));
	VERIFY(pSS->pMapTDItems->Lookup(lParam2, tdi2));

	switch (pSS->nSortBy)
	{
	case TDC_SORTBYNAME:
		return pSS->bAscending ? tdi1.sTitle.CompareNoCase(tdi2.sTitle) : tdi2.sTitle.CompareNoCase(tdi1.sTitle);

	case TDC_SORTBYDONE:
		{
			COleDateTime date1 = tdi1.dateDone; // default
			COleDateTime date2 = tdi2.dateDone; // default

			// see if tasks are as good as done
			if (pSS->pTDCtrl->HasStyle(TDCS_GRAYOUTSUBCOMPLETEDTASKS))
			{
				if (date1 <= 0) // not done
				{
					HTREEITEM hti1 = NULL;
					VERIFY(pSS->pMapHTItems->Lookup(lParam1, hti1) && hti1);

					if (hti1 && pSS->pTDCtrl->AreChildTasksDone(hti1))
						date1 = 1.0; // will sort lowest
				}

				if (date2 <= 0) // not done
				{
					HTREEITEM hti2 = NULL;
					VERIFY(pSS->pMapHTItems->Lookup(lParam2, hti2) && hti2);

					if (hti2 && pSS->pTDCtrl->AreChildTasksDone(hti2))
						date2 = 1.0; // will sort lowest
				}
			}
			return CompareDates(date1, date2, pSS->bAscending);
		}

	case TDC_SORTBYDUE:
		{
			// done or as good as done tasks are handled in GetEarliestDueDate
			HTREEITEM hti1 = NULL, hti2 = NULL;

			VERIFY(pSS->pMapHTItems->Lookup(lParam1, hti1) && hti1);
			VERIFY(pSS->pMapHTItems->Lookup(lParam2, hti2) && hti2);

			double date1 = pSS->pTDCtrl->GetEarliestDueDate(hti1, tdi1);
			double date2 = pSS->pTDCtrl->GetEarliestDueDate(hti2, tdi2);

			return CompareDates(date1, date2, pSS->bAscending);
		}

	case TDC_SORTBYSTART:
		return CompareDates(tdi1.dateStart, tdi2.dateStart, pSS->bAscending);

	case TDC_SORTBYPRIORITY:
		{
			// done items have even less than zero priority!
			// and due items have greater than the highest priority
			int nPriority1 = tdi1.nPriority; // default
			int nPriority2 = tdi2.nPriority; // default

			if (tdi1.IsDone())
				nPriority1 = -1;

			else if (pSS->pTDCtrl->HasStyle(TDCS_GRAYOUTSUBCOMPLETEDTASKS))
			{
				HTREEITEM hti1 = NULL;
				VERIFY(pSS->pMapHTItems->Lookup(lParam1, hti1) && hti1);
				
				if (hti1 && pSS->pTDCtrl->IsTaskDone(hti1, CHECKPARENT | CHECKCHILDREN))
					nPriority1 = -1; // as good as done
			}

			else if (tdi1.IsDue())
				nPriority1 = 11;

			if (tdi2.IsDone())
				nPriority2 = -1;

			else if (pSS->pTDCtrl->HasStyle(TDCS_GRAYOUTSUBCOMPLETEDTASKS))
			{
				HTREEITEM hti2 = NULL;
				VERIFY(pSS->pMapHTItems->Lookup(lParam2, hti2) && hti2);
				
				if (hti2 && pSS->pTDCtrl->IsTaskDone(hti2, CHECKPARENT | CHECKCHILDREN))
					nPriority2 = -1; // as good as done
			}

			else if (tdi1.IsDue())
				nPriority2 = 11;

			return pSS->bAscending ? nPriority1 - nPriority2 : nPriority2 - nPriority1;
		}

	case TDC_SORTBYCOLOR:
		return pSS->bAscending ? tdi1.color - tdi2.color :  tdi2.color - tdi1.color;

	case TDC_SORTBYPERSON:
		return pSS->bAscending ? tdi1.sPerson.CompareNoCase(tdi2.sPerson) : tdi2.sPerson.CompareNoCase(tdi1.sPerson);

	case TDC_SORTBYPERCENT:
		{
			// this is a bit messy because percentage may be calculated from subtasks
			HTREEITEM hti1 = NULL, hti2 = NULL;

			VERIFY(pSS->pMapHTItems->Lookup(lParam1, hti1) && hti1);
			VERIFY(pSS->pMapHTItems->Lookup(lParam2, hti2) && hti2);

			int nPercent1 = pSS->pTDCtrl->CalcPercentDone(hti1, tdi1);
			int nPercent2 = pSS->pTDCtrl->CalcPercentDone(hti2, tdi2);

			return pSS->bAscending ? nPercent1 - nPercent2 : nPercent2 - nPercent1;
		}

	case TDC_SORTBYTIMEEST:
		{
			// this is a bit messy because estimate may be calculated from subtasks
			HTREEITEM hti1 = NULL, hti2 = NULL;

			VERIFY(pSS->pMapHTItems->Lookup(lParam1, hti1) && hti1);
			VERIFY(pSS->pMapHTItems->Lookup(lParam2, hti2) && hti2);

			double dTimeEst1 = pSS->pTDCtrl->CalcTimeEstimate(hti1, tdi1);
			double dTimeEst2 = pSS->pTDCtrl->CalcTimeEstimate(hti2, tdi2);

			if (pSS->bAscending)
			{
				if (dTimeEst1 > dTimeEst2)
					return 1;
				else if (dTimeEst1 < dTimeEst2)
					return -1;
				else
					return 0;
			}
			else
			{
				if (dTimeEst2 > dTimeEst1)
					return 1;
				else if (dTimeEst2 < dTimeEst1)
					return -1;
				else
					return 0;
			}
		}
		break;
	}

	return 0;
}

int CToDoCtrl::CompareDates(const COleDateTime& date1, const COleDateTime& date2, BOOL bAscending)
{
	if (date1 > 0 && date2 > 0)
	{
		if (bAscending)
			return (date1 < date2) ? -1 : (date1 > date2) ? 1 : 0;
		else
			return (date1 < date2) ? 1 : (date1 > date2) ? -1 : 0;
	}
	else if (date1 > 0)
		return bAscending ? 1 : -1;
	
	else if (date2 > 0)
		return bAscending ? -1 : 1;
	
	// else 
	return 0;
}

BOOL CToDoCtrl::PreTranslateMessage(MSG* pMsg) 
{
	switch (pMsg->message)
	{
	case WM_KEYDOWN:
		if (pMsg->hwnd == (HWND)m_tcToDo)
		{
			switch(pMsg->wParam)
			{
			case VK_DELETE:
				return DeleteSelectedTask();
				
			case VK_F2:
				return EditSelectedTask();

			case ' ':
				return SetSelectedTaskDone(!IsSelectedTaskDone());

			case VK_DOWN:
				if (GetKeyState(VK_CONTROL) & 0x8000) // ctrl key if down
					return MoveSelectedTaskDown();
				break;

			case VK_UP:
				if (GetKeyState(VK_CONTROL) & 0x8000) // ctrl key if down
					return MoveSelectedTaskUp();
				break;

			case VK_LEFT:
				if (GetKeyState(VK_CONTROL) & 0x8000) // ctrl key if down
					return MoveSelectedTaskLeft();
				break;

			case VK_RIGHT:
				if (GetKeyState(VK_CONTROL) & 0x8000) // ctrl key if down
					return MoveSelectedTaskRight();
				break;
			}
		}
		else if (pMsg->hwnd == (HWND)m_tcToDo.SendMessage(TVM_GETEDITCONTROL))
		{
			switch (pMsg->wParam)
			{
			case VK_ESCAPE:
				m_tcToDo.SendMessage(TVM_ENDEDITLABELNOW, TRUE);
				return TRUE;
				
			case VK_RETURN:
				m_tcToDo.SendMessage(TVM_ENDEDITLABELNOW, FALSE);
				return TRUE;
			}
		}
		break;
	}
	
	return CRuntimeDlg::PreTranslateMessage(pMsg);
}

BOOL CToDoCtrl::MoveSelectedTaskDown()
{
	if (CanMoveSelectedTaskDown())
	{
		m_tcToDo.SelectItem(m_tcToDo.MoveItemDown(GetSelectedItem()));
		SetModified(TRUE, TDCA_NONE);

		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::MoveSelectedTaskUp()
{
	if (CanMoveSelectedTaskUp())
	{
		m_tcToDo.SelectItem(m_tcToDo.MoveItemUp(GetSelectedItem()));
		SetModified(TRUE, TDCA_NONE);

		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::CanMoveSelectedTaskDown() const
{
	return m_tcToDo.CanMoveItemDown(GetSelectedItem());
}

BOOL CToDoCtrl::CanMoveSelectedTaskUp() const
{
	return m_tcToDo.CanMoveItemUp(GetSelectedItem());
}

BOOL CToDoCtrl::MoveSelectedTaskLeft()
{
	if (CanMoveSelectedTaskLeft())
	{
		m_tcToDo.SelectItem(m_tcToDo.MoveItemLeft(GetSelectedItem()));
		SetModified(TRUE, TDCA_NONE);

		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::MoveSelectedTaskRight()
{
	if (CanMoveSelectedTaskRight())
	{
		m_tcToDo.SelectItem(m_tcToDo.MoveItemRight(GetSelectedItem()));
		SetModified(TRUE, TDCA_NONE);

		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::CanMoveSelectedTaskLeft() const
{
	return m_tcToDo.CanMoveItemLeft(GetSelectedItem());
}

BOOL CToDoCtrl::CanMoveSelectedTaskRight() const
{
	return m_tcToDo.CanMoveItemRight(GetSelectedItem());
}

LRESULT CToDoCtrl::OnGutterDrawItem(WPARAM wParam, LPARAM lParam)
{
	NCGDRAWITEM* pNCGDI = (NCGDRAWITEM*)lParam;

	// convert index to TDC_COLUMN
	TDCCOLUMN* pTDCC = GetColumn(pNCGDI->nColPos);

	if (!pTDCC) // not one of ours
		return FALSE;

	// is it visible
	if (!CRect().IntersectRect(pNCGDI->rItem, pNCGDI->rWindow))
		return TRUE;

	if (!IsColumnShowing(pTDCC->nCol))
		return TRUE;

	TODOITEM tdi;
	HTREEITEM hti = (HTREEITEM)pNCGDI->dwItem;
	DWORD dwUniqueID = m_tcToDo.GetItemData(hti);
	
	if (GetTask(dwUniqueID, tdi))
	{
		CRect rItem(pNCGDI->rItem);
		
		BOOL bFocused = m_tcToDo.HasFocus();
		BOOL bSelected = pNCGDI->bSelected;
		COLORREF crTextColor = GetSysColor((bSelected && bFocused) ? COLOR_HIGHLIGHTTEXT : COLOR_WINDOWTEXT);
		
		// bkcolor
		if (bSelected)
		{
			if (bFocused)
				pNCGDI->pDC->FillSolidRect(rItem, GetSysColor(COLOR_HIGHLIGHT));
			else
				pNCGDI->pDC->FillSolidRect(rItem, GetSysColor(COLOR_3DFACE));
		}
		
		// vertical divider
		if (!bSelected)
			pNCGDI->pDC->FillSolidRect(rItem.right - 1, rItem.top, 1, rItem.Height(), RGB(224, 224, 224));
		
		switch (pTDCC->nCol)
		{
		case TDCC_PRIORITY:
			{
				// priority color
				rItem.DeflateRect(2, 2);
				rItem.right -= 1;
				rItem.bottom--;
				
				if (!IsTaskDone(hti, CHECKPARENT | CHECKCHILDREN))
				{
					COLORREF color = CalcPriorityColor(tdi.IsDue() ? 10 : tdi.nPriority);
					pNCGDI->pDC->FillSolidRect(rItem, color);
				}
			}
			break;

		case TDCC_ID:
			{
				rItem.left += COLPADDING;

				pNCGDI->pDC->SetTextColor(crTextColor);
				pNCGDI->pDC->SetBkMode(TRANSPARENT);

				CString sID;
				sID.Format("%u", dwUniqueID);
				pNCGDI->pDC->DrawText(sID, rItem, DT_SINGLELINE | DT_VCENTER | DT_LEFT);
			}
			break;

		case TDCC_PERSON:
			if (!tdi.sPerson.IsEmpty())
			{
				rItem.left += COLPADDING;

				pNCGDI->pDC->SetTextColor(crTextColor);
				pNCGDI->pDC->SetBkMode(TRANSPARENT);
				pNCGDI->pDC->DrawText(tdi.sPerson, rItem, DT_SINGLELINE | DT_VCENTER | DT_LEFT | DT_END_ELLIPSIS);
			}
			break;

		case TDCC_PERCENT:
			{
				// draw percent
				if (!HasStyle(TDCS_HIDEPERCENTSUBCOMPLETEDTASKS) || AreChildTasksDone(hti) != TRUE)
				{
					int nPercent = 100;
					
					if (!tdi.IsDone()) // not explicitly done
						nPercent = CalcPercentDone(hti, tdi);
					
					CString sPercent;
					sPercent.Format("%d%%", nPercent);

					rItem.right -= COLPADDING;
					
					pNCGDI->pDC->SetTextColor(crTextColor);
					pNCGDI->pDC->SetBkMode(TRANSPARENT);
					pNCGDI->pDC->DrawText(sPercent, rItem, DT_SINGLELINE | DT_VCENTER | DT_RIGHT);
				}
			}
			break;

		case TDCC_TIMEEST:
			{
				// draw time
				double dTime = CalcTimeEstimate(hti, tdi);
				
				if (dTime > 0)
				{
					CString sTime;
					sTime.Format("%.02f", dTime);

					rItem.right -= COLPADDING;

					pNCGDI->pDC->SetTextColor(crTextColor);
					pNCGDI->pDC->SetBkMode(TRANSPARENT);
					pNCGDI->pDC->DrawText(sTime, rItem, DT_SINGLELINE | DT_VCENTER | DT_RIGHT);
				}
			}
			break;

		case TDCC_STARTDATE:
			if (tdi.HasStart())
			{
				rItem.right -= COLPADDING;

				pNCGDI->pDC->SetTextColor(crTextColor);
				pNCGDI->pDC->SetBkMode(TRANSPARENT);
				pNCGDI->pDC->DrawText(tdi.dateStart.Format(VAR_DATEVALUEONLY), rItem, DT_SINGLELINE | DT_VCENTER | DT_RIGHT);
			}
			break;

		case TDCC_DUEDATE:
			{
				COleDateTime date = GetEarliestDueDate(hti, tdi);

				if (date.m_dt > 1.0) // 1.0 is used by completed items for sorting
				{
					rItem.right -= COLPADDING;

					pNCGDI->pDC->SetTextColor(crTextColor);
					pNCGDI->pDC->SetBkMode(TRANSPARENT);
					pNCGDI->pDC->DrawText(date.Format(VAR_DATEVALUEONLY), rItem, DT_SINGLELINE | DT_VCENTER | DT_RIGHT);
				}
			}
			break;

		case TDCC_DONEDATE:
			if (tdi.IsDone())
			{
				rItem.right -= COLPADDING;

				pNCGDI->pDC->SetTextColor(crTextColor);
				pNCGDI->pDC->SetBkMode(TRANSPARENT);
				pNCGDI->pDC->DrawText(tdi.dateDone.Format(VAR_DATEVALUEONLY), rItem, DT_SINGLELINE | DT_VCENTER | DT_RIGHT);
			}
			break;

		case TDCC_FILEREF:
			if (!tdi.sFileRefPath.IsEmpty())
			{
				int nImage = m_ilFileRef.GetFileImageIndex(tdi.sFileRefPath);

				if (nImage >= 0)
				{
					rItem.DeflateRect((rItem.Width() - 16) / 2, (rItem.Height() - 16) / 2);
					m_ilFileRef.GetImageList()->Draw(pNCGDI->pDC, nImage, rItem.TopLeft(), ILD_TRANSPARENT);
				}
			}
			break;
		}

		return TRUE; // we handled it
	}

	return FALSE;
}

BOOL CToDoCtrl::SetPriorityColors(const CDWordArray& aColors)
{
	if (aColors.GetSize() != 11 && aColors.GetSize() != 2)
		return FALSE;

	m_aPriorityColors.Copy(aColors);

	if (GetSafeHwnd())
		CRedrawAll(this);

	return TRUE;
}

void CToDoCtrl::SetPriorityColors(COLORREF crLow, COLORREF crHigh)
{
	m_aPriorityColors.RemoveAll();
	m_aPriorityColors.Add(crLow);
	m_aPriorityColors.Add(crHigh);

	if (GetSafeHwnd())
		CRedrawAll(this);
}

COLORREF CToDoCtrl::CalcPriorityColor(int nPriority) const
{
	if (nPriority < 0 || nPriority > 10)
		return GetSysColor(COLOR_WINDOW);

	COLORREF crLow = 0, crHigh = 0;

	if (HasStyle(TDCS_COLORPRIORITY))
	{
		if (m_aPriorityColors.GetSize() == 11)
			return (COLORREF)m_aPriorityColors[nPriority];

		// else
		ASSERT (m_aPriorityColors.GetSize() == 2);

		crLow = m_aPriorityColors[0];
		crHigh = m_aPriorityColors[1];
	}
	else
	{
		crLow = WHITE;
		crHigh = BLACK;
	}

	if (nPriority == 0)
		return crLow;
	
	else if (nPriority == 10)
		return crHigh;

	BYTE redLow = GetRValue(crLow);
	BYTE greenLow = GetGValue(crLow);
	BYTE blueLow = GetBValue(crLow);

	BYTE redHigh = GetRValue(crHigh);
	BYTE greenHigh = GetGValue(crHigh);
	BYTE blueHigh = GetBValue(crHigh);

	double dRed = (redLow * (10 - nPriority) / 10) + (redHigh * nPriority / 10);
	double dGreen = (greenLow * (10 - nPriority) / 10) + (greenHigh * nPriority / 10);
	double dBlue = (blueLow * (10 - nPriority) / 10) + (blueHigh * nPriority / 10);

	double dColor = dRed + (dGreen * 256) + (dBlue * 256 * 256);

	return min(RGB(255, 255, 255), (COLORREF)(int)dColor);
}

void CToDoCtrl::Export2Html(CString& sOutput, BOOL bIncludeProjectName, LPCTSTR szFontName, TDC_FILTER nFilter) const
{
	sOutput.Empty();

	if (!GetCount())
		return;

	CXmlItem xi;
	CExportToDoListToHtml e2html(bIncludeProjectName ? m_sProjectName : "", 
								m_dwStyle, m_aPriorityColors, szFontName);

	AddChildren(NULL, &xi, nFilter);

	e2html.Export(&xi, 0, 1, sOutput);
}

void CToDoCtrl::Export2Text(CString& sOutput, BOOL bIncludeProjectName, int nIndentWidth, TDC_FILTER nFilter) const
{
	sOutput.Empty();

	if (!GetCount())
		return;

	CXmlItem xi;
	CExportToDoListToText e2text(bIncludeProjectName ? m_sProjectName : "", 
								m_dwStyle, nIndentWidth);

	AddChildren(NULL, &xi, nFilter);

	e2text.Export(&xi, 0, 1, sOutput);
}

void CToDoCtrl::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	if (pWnd == &m_tcToDo)
	{
		CPoint ptTree(point);
		m_tcToDo.ScreenToClient(&ptTree);

		if (ptTree.x < 0)
			ptTree.x = 0; // because point may be in the gutter

		HTREEITEM htiHit = m_tcToDo.HitTest(ptTree);
		m_tcToDo.SelectItem(htiHit);

		// forward to our parent for handling
		GetParent()->SendMessage(WM_CONTEXTMENU, (WPARAM)GetSafeHwnd(), MAKELPARAM(point.x, point.y));
	}
}

void CToDoCtrl::OnEditChangePerson()
{
	UpdateTask(TDCA_PERSON);
}

void CToDoCtrl::OnSelChangePerson()
{
	// special case
	int nSel = m_cbPerson.GetCurSel();

	if (nSel != CB_ERR)
		m_cbPerson.GetLBText(nSel, m_sPerson);

	SetSelectedTaskPerson(m_sPerson);

	if (IsColumnShowing(TDCC_PERSON))
		m_tcToDo.RedrawGutter();
}

void CToDoCtrl::OnKillFocusPerson()
{
	UpdateData();

	// add unique person to list
	if (m_cbPerson.FindString(-1, m_sPerson) == CB_ERR)
		m_cbPerson.AddString(m_sPerson);
}

void CToDoCtrl::OnChangeTimeEstimate()
{
	UpdateTask(TDCA_TIMEEST); 
}

void CToDoCtrl::OnChangePercent()
{
	UpdateTask(TDCA_PERCENT);
}

void CToDoCtrl::OnKillFocusPercent()
{
	UpdateTask(TDCA_PERCENT);
}

void CToDoCtrl::OnTreeGetInfoTip(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMTVGETINFOTIP* pTVGIT = (NMTVGETINFOTIP*)pNMHDR;
	TODOITEM tdi;

	if (GetTask((DWORD)pTVGIT->lParam, tdi))
	{
		strncpy(pTVGIT->pszText, FormatInfoTip(tdi), pTVGIT->cchTextMax);
	}

	*pResult = 0;
}

CString CToDoCtrl::FormatInfoTip(const TODOITEM& tdi) const
{
	// format text multilined
	CString sTip;
	
	sTip.Format("Task:\t\t %s",	tdi.sTitle);
	
	if (!tdi.sComments.IsEmpty())
		sTip += "\nComments:\t " + tdi.sComments;
	
	if (!tdi.sPerson.IsEmpty())
		sTip += "\nAssigned to:\t " + tdi.sPerson;
	
	if (tdi.IsDone())
	{
		sTip += "\nCompleted:\t " + tdi.dateDone.Format(VAR_DATEVALUEONLY);
	}
	else
	{
		CString sTemp;

		if (IsColumnShowing(TDCC_PRIORITY) && tdi.nPriority)
		{
			sTemp.Format("\nPriority:\t\t %d", tdi.nPriority);
			sTip += sTemp;
		}
		
		if (tdi.HasStart())
			sTip += "\nStart Date:\t " + tdi.dateStart.Format(VAR_DATEVALUEONLY);

		if (tdi.HasDue())
			sTip += "\nDue Date:\t " + tdi.dateDue.Format(VAR_DATEVALUEONLY);

		if (IsColumnShowing(TDCC_PERCENT))
		{
			sTemp.Format("\n%% Complete:\t %d", tdi.nPercentDone);
			sTip += sTemp;
		}
	}

	return sTip;
}

int CToDoCtrl::GetItemPos(HTREEITEM hti, HTREEITEM htiSearch) const
{
	// traverse the entire tree util we find the item
	if (!htiSearch)
		htiSearch = TVI_ROOT;

	int nPos = 1; // always 1-based
	HTREEITEM htiChild = m_tcToDo.GetChildItem(htiSearch);

	while (htiChild)
	{
		if (htiChild == hti)
			return nPos;

		// try items children
		int nChildPos = GetItemPos(hti, htiChild);

		if (nChildPos)
			return nChildPos;

		nPos++;
		htiChild = m_tcToDo.GetNextItem(htiChild, TVGN_NEXT);
	}

	return 0; // not found
}

BOOL CToDoCtrl::CopySelectedItemAsHtml(CString& sOutput, LPCTSTR szFontName) const
{
	HTREEITEM hti = GetSelectedItem();

	if (!hti)
		return FALSE;

	CXmlItem xi;
	int nPos = GetItemPos(hti, NULL);
	AddItem(hti, &xi, TDCF_VISIBLE, nPos);

	CExportToDoListToHtml e2html(NULL, m_dwStyle, m_aPriorityColors, szFontName);
	e2html.Export(&xi, 0, 1, sOutput);

	return TRUE;
}

BOOL CToDoCtrl::CopySelectedItemAsText(CString& sOutput, int nIndent) const
{
	HTREEITEM hti = GetSelectedItem();

	if (!hti)
		return FALSE;

	CXmlItem xi;
	int nPos = GetItemPos(hti, NULL);
	AddItem(hti, &xi, TDCF_VISIBLE, nPos);

	CExportToDoListToText e2text(NULL, m_dwStyle, nIndent);
	e2text.Export(&xi, 0, 1, sOutput);

	return TRUE;
}

BOOL CToDoCtrl::CopySelectedItemToClipboardAsHtml(LPCTSTR szFontName) const
{
	CString sOutput;

	BOOL bRes = CopySelectedItemAsHtml(sOutput, szFontName);

	if (bRes)
		CopyTexttoclipboard(sOutput);

	return bRes;
}

BOOL CToDoCtrl::CopySelectedItemToClipboardAsText(int nIndent) const
{
	CString sOutput;

	BOOL bRes = CopySelectedItemAsText(sOutput, nIndent);

	if (bRes)
		CopyTexttoclipboard(sOutput);

	return bRes;
}

BOOL CToDoCtrl::CopySelectedItem()
{
	HTREEITEM hti = m_tcToDo.GetSelectedItem();

	if (hti)
	{
		s_pCopySrc = this;
		s_dwCopySrc = m_tcToDo.GetItemData(hti); // itemID

		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::CanPaste() const
{
	// if no selection then must will paste at the root
	if (s_pCopySrc && s_dwCopySrc)
	{
		TODOITEM tdi;

		return s_pCopySrc->GetTask(s_dwCopySrc, tdi);
	}

	return FALSE;
}

void CToDoCtrl::ClearCopiedItem()
{
	s_pCopySrc = NULL;
	s_dwCopySrc = 0; // itemID
}

BOOL CToDoCtrl::PasteOnSelectedItem()
{
	if (!CanPaste())
		return FALSE;

	HTREEITEM htiDest = m_tcToDo.GetSelectedItem();

	if (!htiDest)
		htiDest = TVI_ROOT;

	CHTIMap mapHTI;

	s_pCopySrc->BuildHTIMap(mapHTI);

	HTREEITEM htiSrc = NULL;

	if (!mapHTI.Lookup(s_dwCopySrc, htiSrc) && htiSrc) // does item still exist?
	{
		s_pCopySrc = NULL;
		s_dwCopySrc = 0; // itemID
		return FALSE;
	}
	
	CDragDropTreeCtrl::HTREECOPY htcSrc;

	s_pCopySrc->m_tcToDo.BuildCopy(htiSrc, htcSrc);
	HTREEITEM htiNew = NULL;

	{
		CHoldRedraw hr(this);
		CHoldRedraw hr2(&m_tcToDo);

		htiNew = CopyTree(s_pCopySrc, htcSrc, htiDest);
	}

	if (htiNew && htiNew != htiDest)
	{
//		m_tcToDo.PostMessage(TVM_EXPAND, (WPARAM)TVE_EXPAND, (LPARAM)htiDest);
		m_tcToDo.SelectItem(htiNew);

		SetModified(TRUE, TDCA_NONE);
		UpdateControls();

		return TRUE;
	}

	return FALSE;
}

HTREEITEM CToDoCtrl::CopyTree(const CToDoCtrl* pSrc, const CDragDropTreeCtrl::HTREECOPY& htcSrc, HTREEITEM htiDest)
{
	ASSERT (pSrc && pSrc->GetSafeHwnd());

	if (!(pSrc && pSrc->GetSafeHwnd()))
		return htiDest;

	// make sure we (can) create the new task first
	TODOITEM tdiNew;

	if (!pSrc->GetTask(htcSrc.dwItemData, tdiNew)) // copy the src
		return htiDest;

	HTREEITEM htiSrc = htcSrc.hti;

	// create the mapping too
	DWORD dwItemData = m_dwNextUniqueID;
	m_mapTDItems.SetAt(m_dwNextUniqueID, tdiNew);
	m_dwNextUniqueID++;

	// Get the attributes of item to be copied.
	int nImage, nSelectedImage;
	pSrc->m_tcToDo.GetItemImage(htiSrc, nImage, nSelectedImage);

	CString sText = pSrc->m_tcToDo.GetItemText(htiSrc);
	UINT uState = pSrc->m_tcToDo.GetItemState(htiSrc, TVIS_BOLD);
	UINT uMask = TVIF_IMAGE | TVIF_PARAM | TVIF_SELECTEDIMAGE | TVIF_STATE | TVIF_TEXT;

	// Create an exact copy of the item at the destination.
	HTREEITEM htiNew = m_tcToDo.InsertItem(uMask, sText, nImage, nSelectedImage, uState, 
											TVIS_BOLD, dwItemData, htiDest, TVI_LAST);

	// copy children too
	if (htcSrc.childItems.GetSize())
	{
		for (int nChild = 0; nChild < htcSrc.childItems.GetSize(); nChild++)
			CopyTree(pSrc, htcSrc.childItems[nChild], htiNew);
	}

	// restore the expanded state
	if (pSrc->m_tcToDo.IsItemExpanded(htiSrc))
		m_tcToDo.Expand(htiNew, TVE_EXPAND);
	else
		m_tcToDo.Expand(htiNew, TVE_COLLAPSE);

	return htiNew;
}

void CToDoCtrl::CopyTexttoclipboard(const CString& sText) const 
{
	if (sText.IsEmpty())
		return;
	
	if (!::OpenClipboard(GetSafeHwnd())) 
		return; 

    ::EmptyClipboard(); 
 
    // Allocate a global memory object for the text. 
	HGLOBAL hglbCopy = GlobalAlloc(GMEM_MOVEABLE, (sText.GetLength() + 1) * sizeof(TCHAR)); 

	if (!hglbCopy) 
	{ 
		CloseClipboard(); 
		return; 
	} 
	
	// Lock the handle and copy the text to the buffer. 
	LPTSTR lptstrCopy = (LPTSTR)GlobalLock(hglbCopy); 

	memcpy(lptstrCopy, (LPVOID)(LPCTSTR)sText, sText.GetLength() * sizeof(TCHAR)); 

	lptstrCopy[sText.GetLength()] = (TCHAR) 0;    // null character 
	GlobalUnlock(hglbCopy); 
	
	// Place the handle on the clipboard. 
	::SetClipboardData(CF_TEXT, hglbCopy); 

	::CloseClipboard();
}

LRESULT CToDoCtrl::OnGutterNotifyHeaderClick(WPARAM wParam, LPARAM lParam)
{
	NCGHDRCLICK* pNGHC = (NCGHDRCLICK*)lParam;

	if (pNGHC->nMsgID != WM_NCLBUTTONUP)
		return 0;

	TDC_SORTBY nSortBy = (TDC_SORTBY)-1;

	// special case: column is client area
	if (pNGHC->nColPos == NCG_CLIENTCOLUMN)
		nSortBy = TDC_SORTBYNAME;
	else
	{
		// convert index to TDC_COLUMN
		TDCCOLUMN* pTDCC = GetColumn(pNGHC->nColPos);

		if (!pTDCC) // not one of ours so preserve existing sort selection
		{
			TDCCOLUMN* pSortCol = GetColumn(m_nSortBy);

			if (pSortCol)
				m_tcToDo.PressGutterColumnHeader(pSortCol->nPos);

			return TRUE; // we handled it
		}
		
		if (!IsColumnShowing(pTDCC->nCol))
			return TRUE; // we handled it

		switch (pTDCC->nCol)
		{
		case TDCC_PRIORITY:
			nSortBy = TDC_SORTBYPRIORITY;
			break;
			
		case TDCC_ID:
			nSortBy = TDC_SORTBYID;
			break;
			
		case TDCC_PERSON:
			nSortBy = TDC_SORTBYPERSON;
			break;
			
		case TDCC_TIMEEST:
			nSortBy = TDC_SORTBYTIMEEST;
			break;

		case TDCC_PERCENT:
			nSortBy = TDC_SORTBYPERCENT;
			break;

		case TDCC_STARTDATE:
			nSortBy = TDC_SORTBYSTART;
			break;

		case TDCC_DUEDATE:
			nSortBy = TDC_SORTBYDUE;
			break;

		case TDCC_DONEDATE:
			nSortBy = TDC_SORTBYDONE;
			break;

		default:
			break;
		}
	}

	if (nSortBy != (TDC_SORTBY)-1)
	{
		Sort(nSortBy);
		pNGHC->bPressed = TRUE;

		// notify parent
		GetParent()->SendMessage(WM_TDCN_SORT);

		return TRUE; // we handled it
	}

	return 0;
}

LRESULT CToDoCtrl::OnGutterRecalcColWidth(WPARAM wParam, LPARAM lParam)
{
	NCGRECALCCOLUMN* pNCRC = (NCGRECALCCOLUMN*)lParam;

	// convert colpos to TDC_COLUMN
	TDCCOLUMN* pTDCC = GetColumn(pNCRC->nColPos);

	if (!pTDCC)
		return FALSE;
	
	if (!IsColumnShowing(pTDCC->nCol))
	{
		pNCRC->nWidth = 0;
		return TRUE;
	}

	switch (pTDCC->nCol)
	{
	case TDCC_ID:
		{
			static int nMinIDWidth = 0;
			
			if (nMinIDWidth == 0) // first time only (this is the width of the header)
			{
				CClientDC dc(this);
				dc.SelectStockObject(ANSI_VAR_FONT);

				nMinIDWidth = dc.GetTextExtent("ID ").cx + 2 * COLPADDING;
			}

			CString sMaxID;
			sMaxID.Format("%u", m_dwNextUniqueID - 1);

			pNCRC->nWidth = max(nMinIDWidth, pNCRC->pDC->GetTextExtent(sMaxID).cx + 2 * COLPADDING);
		}
		break; 

	case TDCC_PRIORITY:
		pNCRC->nWidth = 10;
		break; 
		
	case TDCC_FILEREF:
		pNCRC->nWidth = 16 + 2 * COLPADDING; // small icon plus padding
		break; 
		
	case TDCC_PERSON:
		pNCRC->nWidth = pNCRC->pDC->GetTextExtent("A.N.Other").cx + 2 * COLPADDING;;
		break;
		
	case TDCC_TIMEEST:
		{
			// else calc the greatest cumulative time estimate of the top level items
			HTREEITEM hti = m_tcToDo.GetNextItem(NULL, TVGN_CHILD);
			double dMaxTime = 0;
			
			while (hti)
			{
				TODOITEM tdi;
				
				if (GetTask(m_tcToDo.GetItemData(hti), tdi))
					dMaxTime = max(dMaxTime, CalcTimeEstimate(hti, tdi));
				
				hti = m_tcToDo.GetNextItem(hti, TVGN_NEXT);
			}
			
			CString sTime;
			sTime.Format("%.02f", dMaxTime);

			pNCRC->nWidth = pNCRC->pDC->GetTextExtent(sTime).cx + 2 * COLPADDING;
		}
		break;

	case TDCC_PERCENT:
		pNCRC->nWidth = pNCRC->pDC->GetTextExtent("100%").cx + 2 * COLPADDING;
		break;

	case TDCC_STARTDATE:
	case TDCC_DUEDATE:
	case TDCC_DONEDATE:
		{
			static int nMinDateWidth = 0;
			
			if (nMinDateWidth == 0) // first time only (this is the width of the header)
			{
				CClientDC dc(this);
				dc.SelectStockObject(ANSI_VAR_FONT);

				nMinDateWidth = dc.GetTextExtent("Completed ").cx + 2 * COLPADDING;
			}

			COleDateTime date(2002, 12, 31, 0, 0, 0);
			pNCRC->nWidth = max(nMinDateWidth, pNCRC->pDC->GetTextExtent(date.Format(VAR_DATEVALUEONLY)).cx + 2 * COLPADDING);
		}
		break;

	default:
		ASSERT (0);
		break;
	}

	return TRUE;
}

void CToDoCtrl::OnGotoFile()
{
	ShellExecute(*this, NULL, m_sFileRefPath, NULL, NULL, SW_SHOWNORMAL); 
}

int CToDoCtrl::CalcPercentDone(const HTREEITEM hti, const TODOITEM& tdi) const
{
	int nPercent = tdi.IsDone() ? 100 : tdi.nPercentDone; // default

	if (HasStyle(TDCS_AVERAGEPERCENTSUBCOMPLETION) && m_tcToDo.ItemHasChildren(hti))
	{
		int nNumChildren = 0;
		nPercent = 0;
		BOOL bIncludeDone = HasStyle(TDCS_INCLUDEDONEINAVERAGECALC);

		HTREEITEM htiChild = m_tcToDo.GetChildItem(hti);

		while (htiChild)
		{
			TODOITEM tdiChild;
			VERIFY(GetTask(m_tcToDo.GetItemData(htiChild), tdiChild));

			if (!tdiChild.IsDone() || bIncludeDone)
			{
				nPercent += CalcPercentDone(htiChild, tdiChild);
				nNumChildren++;
			}

			htiChild = m_tcToDo.GetNextItem(htiChild, TVGN_NEXT);
		}

		// average
		if (nNumChildren)
			nPercent /= nNumChildren;
		else
			ASSERT(!nPercent);
	}

	return nPercent;
}

double CToDoCtrl::CalcTimeEstimate(const HTREEITEM hti, const TODOITEM& tdi) const
{
	double dTime = 0;
	
	if (!m_tcToDo.ItemHasChildren(hti))
	{
		dTime = tdi.dTimeEstimate;

		if (HasStyle(TDCS_USEPERCENTDONEINTIMEEST))
			dTime *= ((100 - tdi.nPercentDone) / 100.0); // estimating time left
	}

	// children
	HTREEITEM htiChild = m_tcToDo.GetChildItem(hti);

	while (htiChild)
	{
		TODOITEM tdiChild;
		VERIFY(GetTask(m_tcToDo.GetItemData(htiChild), tdiChild));
		
		if (!tdiChild.IsDone())
			dTime += CalcTimeEstimate(htiChild, tdiChild);
		
		htiChild = m_tcToDo.GetNextItem(htiChild, TVGN_NEXT);
	}

	return dTime;
}

void CToDoCtrl::BuildHTIMap(CHTIMap& mapHTI)
{
	mapHTI.RemoveAll();

	// traverse toplevel items
	HTREEITEM hti = m_tcToDo.GetNextItem(NULL, TVGN_CHILD);
	
	while (hti)
	{
		UpdateHTIMapEntry(mapHTI, hti);
		hti = m_tcToDo.GetNextItem(hti, TVGN_NEXT);
	}
}

void CToDoCtrl::UpdateHTIMapEntry(CHTIMap& mapHTI, HTREEITEM hti)
{
	// update our own mapping
	mapHTI[m_tcToDo.GetItemData(hti)] = hti;

	// then our children
	HTREEITEM htiChild = m_tcToDo.GetChildItem(hti);

	while (htiChild)
	{
		UpdateHTIMapEntry(mapHTI, htiChild);
		htiChild = m_tcToDo.GetNextItem(htiChild, TVGN_NEXT);
	}
}

BOOL CToDoCtrl::IsTaskFullyDone(const HTREEITEM hti, const TODOITEM& tdi, BOOL bCheckSiblings) const
{
	if (bCheckSiblings)
	{
		HTREEITEM htiParent = m_tcToDo.GetParentItem(hti);
		HTREEITEM htiSibling = htiParent ? m_tcToDo.GetChildItem(htiParent) : 
											m_tcToDo.GetNextItem(NULL, TVGN_CHILD);

		while (htiSibling)
		{
			if (htiSibling != hti) // else we would recurse
			{
				TODOITEM tdiSibling;
				
				if (GetTask(m_tcToDo.GetItemData(htiSibling), tdiSibling))
				{
					// exit on first failure
					if (!IsTaskFullyDone(htiSibling, tdiSibling, FALSE)) // FALSE: we're doing the siblings
						return FALSE;
				}
			}

			htiSibling = m_tcToDo.GetNextItem(htiSibling, TVGN_NEXT);
		}
	}

	// check children
	if (m_tcToDo.ItemHasChildren(hti))
	{
		HTREEITEM htiChild = m_tcToDo.GetChildItem(hti);

		while (htiChild)
		{
			TODOITEM tdiChild;
			
			if (GetTask(m_tcToDo.GetItemData(htiChild), tdiChild))
			{
				// exit on first failure
				if (!IsTaskFullyDone(htiChild, tdiChild, FALSE)) // FALSE: we're doing the siblings
					return FALSE;
			}

			htiChild = m_tcToDo.GetNextItem(htiChild, TVGN_NEXT);
		}
	}
	else 
		return tdi.IsDone(); // no children => relies on our state only

	// if we got here there were no sibling or child failures
	return TRUE;
}

void CToDoCtrl::OnSetFocus(CWnd* pOldWnd) 
{
	CRuntimeDlg::OnSetFocus(pOldWnd);
	
	// ensure the selected tree item is visible
	m_tcToDo.EnsureVisible(m_tcToDo.GetSelectedItem());
}

LRESULT CToDoCtrl::OnDropFileRef(WPARAM wParam, LPARAM lParam)
{
	HTREEITEM hti = (HTREEITEM)wParam;

	if (hti)
	{
		m_tcToDo.SelectItem(hti);
		SetSelectedTaskFileRef((LPCTSTR)lParam);
	}
	else // its the file ref edit field
	{
		m_eFile.SetWindowText((LPCTSTR)lParam);
		GetDlgItem(IDC_GOTOFILE)->EnableWindow(TRUE);
	}

	return 0;
}

void CToDoCtrl::SaveExpandedState()
{
	ASSERT (GetSafeHwnd());
	CString sKey;

	m_sLastSavePath.Replace('\\', '_');
	sKey.Format("ExpandedState\\%s", m_sLastSavePath);

	int nCount = SaveExpandedState(sKey);

	// save expanded count
	AfxGetApp()->WriteProfileInt(sKey, "Count", nCount);
}

void CToDoCtrl::LoadExpandedState()
{
	ASSERT (GetSafeHwnd());
	
	CString sKey, sFilePath(m_sLastSavePath);
	sFilePath.Replace('\\', '_');
	sKey.Format("ExpandedState\\%s", sFilePath);
	
	LoadExpandedState(sKey);
}

int CToDoCtrl::SaveExpandedState(LPCTSTR szRegKey, HTREEITEM hti, int nStart)
{
	// create a new key using the filepath and simply save the ID 
	// of every expanded item
	HTREEITEM htiChild = hti ? m_tcToDo.GetChildItem(hti) : m_tcToDo.GetNextItem(NULL, TVGN_CHILD);
	int nCount = nStart;

	while (htiChild)
	{
		if (m_tcToDo.IsItemExpanded(htiChild))
		{
			CString sItem;
			sItem.Format("Item%d", nCount);

			AfxGetApp()->WriteProfileInt(szRegKey, sItem, (int)m_tcToDo.GetItemData(htiChild));
			nCount++;

			// now its children
			nCount += SaveExpandedState(szRegKey, htiChild, nCount);
		}

		htiChild = m_tcToDo.GetNextItem(htiChild, TVGN_NEXT);
	}	
	
	return (nCount - nStart);
}

void CToDoCtrl::LoadExpandedState(LPCTSTR szRegKey)
{
	int nCount = AfxGetApp()->GetProfileInt(szRegKey, "Count", 0);
	CString sItem;

	CHTIMap map;
	BuildHTIMap(map);

	while (nCount--)
	{
		sItem.Format("Item%d", nCount);

		DWORD dwID = (DWORD)AfxGetApp()->GetProfileInt(szRegKey, sItem, 0);
		HTREEITEM hti = NULL;

		if (dwID && map.Lookup(dwID, hti) && hti)
			m_tcToDo.Expand(hti, TVE_EXPAND);
	}
}

double CToDoCtrl::GetEarliestDueDate(HTREEITEM hti, const TODOITEM& tdi) const
{
	ASSERT (hti);

	// handle done or 'good-as-done' tasks
	if (tdi.IsDone())
		return 1.0;
	
	else if (HasStyle(TDCS_GRAYOUTSUBCOMPLETEDTASKS) && hti && AreChildTasksDone(hti) == 1)
		return 1.0;

	else if (!m_tcToDo.ItemHasChildren(hti) || !HasStyle(TDCS_USEEARLIESTDUEDATE))
		return tdi.dateDue;

	// check children
	double dEarliest = tdi.HasDue() ? tdi.dateDue : DBL_MAX;

	HTREEITEM htiChild = m_tcToDo.GetChildItem(hti);

	while (htiChild)
	{
		TODOITEM tdiChild;

		if (!GetTask(m_tcToDo.GetItemData(htiChild), tdiChild))
			return 0;

		double dChildDue = GetEarliestDueDate(htiChild, tdiChild);

		if (dChildDue > 0 && dChildDue < dEarliest)
			dEarliest = dChildDue;

		htiChild = m_tcToDo.GetNextItem(htiChild, TVGN_NEXT);
	}

	return (dEarliest == DBL_MAX) ? 0 : dEarliest;

}

LRESULT CToDoCtrl::OnGutterWidthChange(WPARAM wParam, LPARAM lParam)
{
	// let parent know if min width has changed
	int nPrevWidth = LOWORD(lParam);
	int nNewWidth = HIWORD(lParam);

	if (nNewWidth < nPrevWidth || (!nPrevWidth && nNewWidth))
		GetParent()->SendMessage(WM_TDCN_MINWIDTHCHANGE);

	return 0;
}
