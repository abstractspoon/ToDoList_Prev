// ToolbarHelper.h: interface for the CToolbarHelper class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TOOLBARHELPER_H__86A32540_80BF_421C_97E3_6E760BF427A8__INCLUDED_)
#define AFX_TOOLBARHELPER_H__86A32540_80BF_421C_97E3_6E760BF427A8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Subclass.h"
#include <afxtempl.h>

class CToolbarHelper : protected CSubclassWnd  
{
public:
	CToolbarHelper();
	virtual ~CToolbarHelper();

	BOOL Initialize(CToolBar* pToolbar, CWnd* pToolbarParent);
	BOOL SetDropButton(UINT nBtnCmdID, UINT nMenuID, int nSubMenu, UINT nDefCmdID = 0, char cHotkey = 0);
	BOOL SetDefaultMenuID(UINT nBtnCmdID, UINT nDefCmdID = 0);

	void EnableMultilineText(BOOL bEnable = TRUE, int nWidth = 200);
	BOOL PreTranslateMessage(MSG* pMsg); // called by parent

	static void PrepareMenuItems(CMenu* pMenu, CWnd* pWnd);

protected:
	CToolBar* m_pToolbar;

	struct DropMenu
	{
		UINT nMenuID;
		int nSubMenu;
		UINT nDefCmdID;
		char cHotKey;
	};

	CMap<UINT, UINT, DropMenu, DropMenu&> m_mapDropMenus;
	BOOL m_bMultiline;
	int m_nMultilineWidth;

protected:
	LRESULT WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp);
	CString GetTip(UINT nID, LPPOINT pPoint = NULL) const;
	BOOL DisplayDropMenu(UINT nCmdID, BOOL bPressBtn = FALSE);
	BOOL IsCmdEnabled(UINT nCmdID) const;

};

#endif // !defined(AFX_TOOLBARHELPER_H__86A32540_80BF_421C_97E3_6E760BF427A8__INCLUDED_)
