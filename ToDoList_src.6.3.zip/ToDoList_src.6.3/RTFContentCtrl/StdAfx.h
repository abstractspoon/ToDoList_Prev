Urls with m_aUrls to see if anything has changed
	BOOL bReformat = !sText.IsEmpty() && (bForceReformat || !UrlsMatch(aUrls));
	
	// then overwrite (always)	
	m_aUrls.Copy(aUrls);
	
	if (bReformat)
	{
		BOOL bVisible = IsWindowVisible();
		CRePauseUndo rep(*this);
		
		if (bVisible)
			SetRedraw(FALSE);
		
		// save current selection
		CHARRANGE crSel;
		GetSel(crSel);
		
		// and first line
		int nFirstLine = GetFirstVisibleLine();
		
		// retrieve default character attribs
		CHARFORMAT cf;
		cf.cbSize = sizeof(cf);
		cf.dwMask = CFM_LINK;
		
		// format urls
		int nUrls = aUrls.GetSize();
		CHARRANGE cr = { 0, 0 };
		
		for (int nUrl = 0; nUrl < nUrls; nUrl++)
		{
			// clear formatting from the end of the previous
			// url to the start of this url
			cr.cpMax = aUrls[nUrl].cr.cpMin;
			cf.dwEffects = 0;
			
			SetSel(cr);
			SetSelectionCharFormat(cf);
			
			// update for next url
			cr.cpMin = aUrls[nUrl].cr.cpMax;
			
			// then format url
			cf.dwEffects = CFM_LINK;
			
			SetSel(aUrls[nUrl].cr);
			SetSelectionCharFormat(cf);
		}	
		
		// clear formatting for whatever's left
		cr.cpMax = -1;
		cf.dwEffects = 0;
		
		SetSel(cr);
		SetSelectionCharFormat(cf);
		
		// restore selection
		SetSel(crSel);
		
		// and first line
		SetFirstVisibleLine(nFirstLine);
		
		if (bVisible)
		{
			SetRedraw(TRUE);
			Invalidate(FALSE);
		}
	}
}

BOOL CUrlRichEditCtrl::UrlsMatch(const CUrlArray& aUrls)
{
	int nUrls = aUrls.GetSize();

	if (nUrls !=  m_aUrls.GetSize())
		retur