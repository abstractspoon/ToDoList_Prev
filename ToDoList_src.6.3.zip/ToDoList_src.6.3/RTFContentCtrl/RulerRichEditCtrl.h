// urlricheditctrl.cpp : implementation file
//

#include "stdafx.h"
#include "urlricheditctrl.h"
#include "autoflag.h"
#include "richedithelper.h"
#include "winclasses.h"
#include "wclassdefines.h"
#include "filemisc.h"

#include "afxole.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static LPSTR URLDELIMS[] = 
{ 
	" ", 
	"\n",
	"\t",
	", ",
	". ",
//	";",
//	"[",
//	"]",
//	"(",
//	")"
	"<",
	"{",
	"}",
};

const LPCTSTR FILEPREFIX = "file://";
const CString ENDPUNCTUATION(".,;:(){}[]<>&*~?\\\"'");

enum 
{ 
	TIMER_REPARSE = 1, 
};

const UINT PAUSE = 1000; // 1 second
CString CUrlRichEditCtrl::s_sGotoErrMsg;
CString CUrlRichEditCtrl::s_sCtrlClickMsg;

/////////////////////////////////////////////////////////////////////////////
// CUrlRichEditCtrl

CUrlRichEditCtrl::CUrlRichEditCtrl() : m_nContextUrl(-1), m_nFileProtocol(-1)
{
	EnableToolTips();

	AddProtocol("www.", FALSE);
	AddProtocol("http://", FALSE);
	AddProtocol("https://", FALSE);
	AddProtocol("ftp://", FALSE);
	AddProtocol("outlook:", FALSE);
	AddProtocol("mailto:", FALSE);
	AddProtocol("Notes://", FALSE);
	AddProtocol("evernote://", FALSE);
	AddProtocol("onenote:///", FALSE);

	m_nFileProtocol = AddProtocol(FILEPREFIX, FALSE);

	if (s_sCtrlClickMsg.IsEmpty())
		s_sCtrlClickMsg = "Ctrl+Click to follow link";
}

CUrlRichEditCtrl::~CUrlRichEditCtrl()
{
}

BEGIN_MESSAGE_MAP(CUrlRichEditCtrl, CRichEditBaseCtrl)
//{{AFX_MSG_MAP(CUrlRichEditCtrl)
	ON_CONTROL_REFLECT_EX(EN_CHANGE, OnChangeText)
	ON_WM_CHAR()
	ON_WM_RBUTTONUP()
	ON_WM_KEYUP()
	ON_WM_RBUTTONDOWN()
	ON_WM_SHOWWINDOW()
	ON_WM_CREATE()
	ON_WM_CONTEXTMENU()
	ON_WM_SYSKEYDOWN()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_SETTEXT, OnSetText)
	ON_MESSAGE(WM_SETFONT, OnSetFont)
	ON_MESSAGE(WM_DROPFILES, OnDropFiles)
	ON_NOTIFY_REFLECT_EX(EN_LINK, OnNotifyLink)
	ON_NOTIFY_RANGE(TTN_NEEDTEXT, 0, 0xffff, OnNeedTooltip)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUrlRichEditCtrl message handlers

int CUrlRichEditCtrl::AddProtocol(LPCTSTR szProtocol, BOOL bWantNotify)
{
	int nExist = MatchProtocol(szProtocol);
	
	if (nExist == -1)
	{
		PROTOCOL prot(szProtocol, bWantNotify);
		return m_aProtocols.Add(prot);
	}
	
	return nExist;
}

int CUrlRichEditCtrl::MatchProtocol(LPCTSTR szText) const
{
   int nProt = m_aProtocols.GetSize();

   while (nProt--)
   {
      const PROTOCOL& prot = m_aProtocols[nProt];

      if (_strnicmp(szText, prot.sProtocol, prot.sProtocol.GetLength()) == 0)
         return nProt;
   }

   return -1;
}

BOOL CUrlRichEditCtrl::OnChangeText() 
{
	// kill any existing timer
	KillTimer(TIMER_REPARSE);

	// and start a new one
	SetTimer(TIMER_REPARSE, PAUSE, NULL);
	
	return FALSE;
}

LRESULT CUrlRichEditCtrl::OnDropFiles(WPARAM wp, LPARAM /*lp*/) 
{
	CHARRANGE crSelOrg;
	GetSel(crSelOrg); // save this off
	BOOL bEnable = !(GetStyle() & ES_READONLY) && IsWindowEnabled();
	
	if (!bEnable)
		return 0;
	
	long nChar = -1;
	GetSel(nChar, nChar);
	
	CString sText, sFile;
	TCHAR szFileName[_MAX_PATH];
	UINT nFileCount = ::DragQueryFile((HDROP)wp, 0xFFFFFFFF, NULL, 0);
	
	ASSERT(nFileCount != 0);
	
	for (UINT i=0; i < nFileCount; i++)
	{
		::DragQueryFile((HDROP)wp, i, szFileName, _MAX_PATH);
		::GetLongPathName(szFileName, szFileName, _MAX_PATH);
		
		sFile = CreateFileLink(szFileName) + " ";
		sText += sFile;
	}
	::DragFinish((HDROP)wp);
	
	// set selection to that which we saved during the drag
	SetSel(m_crDropSel);
	
	if (!sText.IsEmpty())
		PathReplaceSel(sText, FALSE);
	
	return FALSE;
}

int CUrlRichEditCtrl::CharFromPoint(const CPoint& point)
{
/*	int nFirstLine = GetFirstVisibleLine();
	int nLineCount = GetLineCount();
	
	for (int nLine = nFirstLine; nLine < nLineCount; nLine++)
	{
		int nFirstChar = LineIndex(nLine);
		CPoint ptChar = GetCharPos(nFirstChar);
		int nLineHeight = GetLineHeight();
		
		if (point.y >= ptChar.y && point.y < ptChar.y + nLineHeight)
		{
			int nLineLength = LineLength(nFirstChar);
			
			for (int nChar = nFirstChar; nChar < (nFirstChar + nLineLength); nChar++)
			{
				ptChar = GetCharPos(nChar);
				
				if (point.x < ptChar.x)
					return nChar;
			}
		}
	}
	
	return GetTextLength();
*/
	POINTL ptl = { point.x, point.y };

	return SendMessage(EM_CHARFROMPOS, 0, (LPARAM)&ptl);
}

void CUrlRichEditCtrl::PreSubclassWindow() 
{
	SetEventMask(GetEventMask() | ENM_CHANGE | ENM_DROPFILES | ENM_DRAGDROPDONE );
	DragAcceptFiles();
	
	// enable multilevel undo
	SendMessage(EM_SETTEXTMODE, TM_MULTILEVELUNDO);

	m_ncBorder.Initialize(GetSafeHwnd());

	CRichEditBaseCtrl::PreSubclassWindow();
}

LRESULT CUrlRichEditCtrl::OnSetText(WPARAM /*wp*/, LPARAM lp)
{
	// eat duplicate messages
	CString sText;
	GetWindowText(sText);
	
	BOOL bChange = (sText != (LPCTSTR)lp);
	LRESULT lr = 0;
	
	if (bChange)
	{
		CRichEditHelper::ClearUndo(GetSafeHwnd());
		
		lr = Default();
		ParseAndFormatText(TRUE);
	}
	
	return lr;
}

LRESULT CUrlRichEditCtrl::OnSetFont(WPARAM /*wp*/, LPARAM /*lp*/)
{
	LRESULT lr = Default();
	
	ParseAndFormatText(TRUE);
	
	return lr;
}

BOOL CUrlRichEditCtrl::IsDelim(LPCTSTR szText)
{
	if (!szText || !*szText)
		return TRUE; // end of string
	
	int nDelims = sizeof(URLDELIMS) / sizeof(LPCTSTR);
	char ch = *szText;
				
	for (int nDelim = 0; nDelim < nDelims; nDelim++)
	{
		LPCTSTR szDelim = URLDELIMS[nDelim];
		
		if (ch == szDelim[0])
		{
			// test char after ch if 2 char delim
			if (szDelim[1] == 0 || *(szText + 1) == szDelim[1])
				return 