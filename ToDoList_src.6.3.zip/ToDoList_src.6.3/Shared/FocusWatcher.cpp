))
		{
			m_nTreeFontSize = 9;
			m_cbTreeFontSize.SetCurSel(0);
		}

		// comments
		sFontSize.Format("%d", m_nCommentsFontSize);

		if (CB_ERR == m_cbCommentsFontSize.SelectString(-1, sFontSize))
		{
			m_nCommentsFontSize = 9;
			m_cbCommentsFontSize.SetCurSel(0);
		}
	}
}


BEGIN_MESSAGE_MAP(CPreferencesUITasklistColorsPage, CPreferencesPageBase)
	//{{AFX_MSG_MAP(CPreferencesUITasklistColorsPage)
	ON_BN_CLICKED(IDC_SETALTLINECOLOR, OnAltlinecolor)
	ON_BN_CLICKED(IDC_ALTERNATELINECOLOR, OnSpecifyAlternatelinecolor)
	ON_BN_CLICKED(IDC_COLORTEXTBYCATEGORY, OnChangeTextColorOption)
	ON_BN_CLICKED(IDC_SETCATEGORYCOLOR, OnSetcategorycolor)
	ON_CBN_EDITCHANGE(IDC_CATEGORYCOLORS, OnEditCategorycolors)
	ON_CBN_SELCHANGE(IDC_CATEGORYCOLORS, OnSelchangeCategorycolors)
	ON_BN_CLICKED(IDC_COMMENTSUSETREEFONT, OnCommentsusetreefont)
	ON_BN_CLICKED(IDC_SPECIFYCOMMENTSFONT, OnSpecifycommentsfont)
	ON_BN_CLICKED(IDC_DUETASKCOLOR, OnDuetaskcolor)
	ON_BN_CLICKED(IDC_SETDUETASKCOLOR, OnSetduetaskcolor)
	ON_BN_CLICKED(IDC_COLORTASKSBYCOLOR, OnChangeTextColorOption)
	ON_BN_CLICKED(IDC_COLORTEXTBYPRIORITY, OnChangeTextColorOption)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_DUETODAYTASKCOLOR, OnDuetodaytaskcolor)
	ON_BN_CLICKED(