// RecurrenceEdit.h: interface for the CRecurringTaskEdit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RECURRENCEEDIT_H__4EE655E3_F4B1_44EA_8AAA_39DD459AD8A8__INCLUDED_)
#define AFX_RECURRENCEEDIT_H__4EE655E3_F4B1_44EA_8AAA_39DD459AD8A8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\shared\enedit.h"
#include "..\shared\propertypagehost.h"
#include "..\shared\monthcombobox.h"
#include "..\Shared\checklistboxex.h"

#include "ToDoCtrlData.h"

const int REBTN_OPTIONS = 1;

class CTDLRecurringTaskEdit : public CEnEdit  
{
public:
	CTDLRecurringTaskEdit();
	virtual ~CTDLRecurringTaskEdit();

//	CString GetRegularity() const;
	void GetRecurrenceOptions(TDIRECURRENCE& tr) const;
	void SetRecurrenceOptions(const TDIRECURRENCE& tr);

	void SetDefaultDate(const COleDateTime& date) { m_dtDefault = date; }

	BOOL ModifyStyle(DWORD dwRemove, DWORD dwAdd, UINT nFlags = 0);
	void DoEdit();
