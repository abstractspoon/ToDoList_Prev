t = prefs.GetProfileInt("Preferences", "HideZeroTimeEst", TRUE);
	m_bShowPercentAsProgressbar = prefs.GetProfileInt("Preferences", "ShowPercentAsProgressbar", FALSE);
	m_bRoundTimeFractions = prefs.GetProfileInt("Preferences", "RoundTimeFractions", FALSE);
	m_bShowNonFilesAsText = prefs.GetProfileInt("Preferences", "ShowNonFilesAsText", FALSE);
	m_bUseHMSTimeFormat = prefs.GetProfileInt("Preferences", "UseHMSTimeFormat", FALSE);
	m_bAutoFocusTasklist = prefs.GetProfileInt("Preferences", "AutoFocusTasklist", FALSE);
	m_bShowSubtaskCompletion = prefs.GetProfileInt("Preferences", "ShowSubtaskCompletion", FALSE);
	m_bShowColumnsOnRight = prefs.GetProfileInt("Preferences", "ShowColumnsOnRight", FALSE);
	m_bHideDueTimeField = prefs.GetProfileInt("Preferences", "HideDueTimeField", FALSE);
	m_bHideStartTimeField = prefs.GetProfileInt("Preferences", "HideStartTimeField", FALSE);
	m_bHideDoneTimeField = prefs.GetProfileInt("Preferences", "HideDoneTimeField", FALSE);
	m_bLimitColumnWidths = prefs.GetProfileInt("Preferences", "LimitColumnWidths", FALSE);
	m_nMaxColumnWidth = prefs.GetProfileInt("Preferences", "MaxColumnWidth", 60);
//	m_b = prefs.GetProfileInt("Preferences", "", FALSE);
}

void CPreferencesUITasklistPage::SavePreferences(CPreferences& prefs)
{
	// save settings
	// column visibility
	CTDCColumnArray aCols;
	int nCol = m_lbColumnVisibility.GetVisibleColumns(aCols);

	prefs.WriteProfileInt("Preferences\\ColumnVisibility", "Count", nCol);

	while (nCol--)
	{
		CString sKey;
		sKey.Format("Col%d", nCol);

		prefs.WriteProfileInt("Preferences\\ColumnVisibility", sKey, aCols[nCol]);
	}

	// save settings
	prefs.WriteProfileInt("Preferences", "ShowInfoTips", m_bShowInfoTips);
	prefs.WriteProfileInt("Preferences", "ShowComments", m_bShowComments);
	prefs.WriteProfileInt("Preferences", "DisplayFirstCommentLine", m_bDisplayFirstCommentLine);
	prefs.WriteProfileInt("Preferences", "ShowPercentColumn", m_bShowPercentColumn);
	prefs.WriteProfileInt("Preferences", "ShowPriorityColumn", m_bShowPriorityColumn);
	prefs.WriteProfileInt("Preferences", "StrikethroughDone", m_bStrikethroughDone);
	prefs.WriteProfileInt("Preferences", "ShowPathInHeader", m_bShowPathInHeader);
	prefs.WriteProfileInt("Preferences", "FullRowSelection", m_bFullRowSelection);
	prefs.WriteProfileInt("Preferences", "TreeCheckboxes", m_bTreeCheckboxes);
	prefs.WriteProfileInt("Preferences", "TreeTaskIcons", m_bTreeTaskIcons);
	prefs.WriteProfileInt("Preferences", "DisplayDatesInISO", m_bUseISOForDates);
	prefs.WriteProfileInt("Preferences", "ShowWeekdayInDates", m_bShowWeekdayInDates);
	prefs.WriteProfileInt("Preferences", "ShowParentsAsFolders", m_bShowParentsAsFolders);
	prefs.WriteProfileInt("Preferences", "MaxInfoTipCommentsLength", max(m_nMaxInfoTipCommentsLength, 0));
	prefs.WriteProfileInt("Preferences", "LimitInfoTipCommentsLength", m_bLimitInfoTipCommentsLength);
	prefs.WriteProfileInt("Preferences", "HidePercentForDoneTasks", m_bHidePercentForDoneTasks);
	prefs.WriteProfileInt("Preferences", "HideStartDueForDoneTasks", m_bHideStartDueForDoneTasks);
	prefs.WriteProfileInt("Preferences", "HideZeroTimeEst", m_bHideZeroTimeCost);
	prefs.WriteProfileInt("Preferences", "ShowPercentAsProgressbar", m_bShowPercentAsProgressbar);
	prefs.WriteProfileInt("Preferences", "RoundTimeFractions", m_bRoundTimeFractions);
	prefs.WriteProfileInt("Preferences", "ShowNonFilesAsText", m_bShowNonFilesAsText);
	prefs.WriteProfileInt("Preferences", "UseHMSTimeFormat", m_bUseHMSTimeFormat);
	prefs.WriteProfileInt("Preferences", "AutoFocusTasklist", m_bAutoFocusTasklist);
	prefs.WriteProfileInt("Preferences", "ShowSubtaskCompletion", m_bShowSubtaskCompletion);
	prefs.WriteProfileInt("Preferences", "ShowColumnsOnRight", m_bShowColumnsOnRight);
	prefs.WriteProfileInt("Preferences", "HideDueTimeField", m_bHideDueTimeField);
	prefs.WriteProfileInt("Preferences", "HideStartTimeField", m_bHideStartTimeField);
	prefs.WriteProfileInt("Preferences", "HideDoneTimeField", m_bHideDoneTimeField)