 // EXCEPTION: OCX Property Pages should return FALSE
}

int CPreferencesUITasklistPage::GetMaxInfoTipCommentsLength() const
{
	if (m_bShowInfoTips)
		return m_bLimitInfoTipCommentsLength ? max(0, m_nMaxInfoTipCommentsLength) : -1;

	return -1;
}

int CPreferencesUITasklistPage::GetMaxColumnWidth() const
{
	return m_bLimitColumnWidths ? max(0, m_nMaxColumnWidth) : -1;
}

void CPreferencesUITasklistPage::OnShowcomments() 
{
	UpdateData();

	GetDlgItem(IDC_DISPLAYFIRSTCOMMENTLINE)->EnableWindow(m_bShowComments);
}

void CPreferencesUITasklistPage::OnShowinfotips() 
{
	UpdateData();

	GetDlgItem(IDC_LIMITINFOTIPCOMMENTS)->EnableWindow(m_bShowInfoTips);
	GetDlgItem(IDC_INFOTIPCOMMENTSMAX)->EnableWindow(m_bShowInfoTips && m_bLimitInfoTipCommentsLength);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesUITasklistPage::OnLimitinfotipcomments() 
{
	UpdateData();

	GetDlgItem(IDC_INFOTIPCOMMENTSMAX)->EnableWindow(m_bShowInfoTips && m_bLimitInfoTipCommentsLength);

	CPreferencesPageBase::OnControlChange();
}

int CPreferencesUITasklistPage::GetVisibleColumns(CTDCColumnArray& aColumns) const
{
	return m_lbColumnVisibility.GetVisibleColumns(aColumns);
}

void CPreferencesUITasklistPage::SetVisibleColumns(const CTDCColumnArray& aColumns) 
{
	m_lbColumnVisibility.SetVisibleColumns(aColumns);
	SaveColumns();
}

void CPreferencesUITasklistPage::SaveColumns() const
{
	CPreferences prefs;
	CTDCColumnArray aCols;

	int nCol = m_lbColumnVisibility.GetVisibleColumns(aCols);
	prefs.WriteProfileInt("Preferences\\ColumnVisibility", "Count", nCol);

	while (nCol--)
	{
		CString sKey;
		sKey.Format("Col%d", nCol);

		prefs.WriteProfileInt("Preferences\\ColumnVisibility", sKey, aCols[nCol]);
	}
}

void CPreferencesUITasklistPage::LoadPreferences(const CPreferences& prefs)
{
	// column visibility
	CTDCColumnArray aCols;
	int nCol = prefs.GetProfileInt("Preferences\\ColumnVisibility", "Count", -1);

	if (nCol == -1) // backward compat required
	{
		for (int nCol = 0; ; nCol++)
		{
			CString sKey;
			sKey.Format("Col%d", nCol);
			
			BOOL bVisible = prefs.GetProfileInt("Preferences\\ColumnVisibility", sKey, -1);
			
			if (bVisible == -1)
				break; // all done
			
			if (bVisible)
			{
				TDC_COLUMN col = m_lbColumnVisibility.MapOldColumnIndex(nCol