 "LimitColumnWidths", m_bLimitColumnWidths);
	prefs.WriteProfileInt("Preferences", "MaxColumnWidth", m_nMaxColumnWidth);
//	prefs.WriteProfileInt("Preferences", "", m_b);
}



void CPreferencesUITasklistPage::OnLimitcolwidths() 
{
	UpdateData();

	GetDlgItem(IDC_COLWIDTHS)->EnableWindow(m_bLimitColumnWidths);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesUITasklistPage::OnTreecheckboxes() 
{
	// if the user is turning this preference on then make sure that
	// the completion column is hidden else the checkbox won't turn up
	UpdateData();

	if (m_bTreeCheckboxes)
		m_lbColumnVisibility.SetColumnVisible(TDCC_DONE, FALSE);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesUITasklistPage::OnShowparentsasfolders() 
{
	UpdateData();

	if (m_bShowParentsAsFolders)
		m_lbColumnVisibility.SetColumnVisible(TDCC_ICON);

	CPreferencesPageBase::OnControlChange();
}

void CPreferenc