
	m_cbCommentsFmt.GetSelectedFormat(m_cfDefault);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesUIPage::LoadPreferences(const CPreferences& prefs)
{
	// load settings
	m_bShowCtrlsAsColumns = prefs.GetProfileInt("Preferences", "ShowCtrlsAsColumns", FALSE);
	m_bShowEditMenuAsColumns = prefs.GetProfileInt("Preferences", "ShowEditMenuAsColumns", FALSE);
	m_bShowCommentsAlways = prefs.GetProfileInt("Preferences", "ShowCommentsAlways", FALSE);
	m_bAutoReposCtrls = prefs.GetProfileInt("Preferences", "AutoReposCtrls", TRUE);
	m_bSpecifyToolbarImage = prefs.GetProfileInt("Preferences", "SpecifyToolbarImage", FALSE);
	m_bSharedCommentsHeight = prefs.GetProfileInt("Preferences", "SharedCommentsHeight", TRUE);
	m_bAutoHideTabbar = prefs.GetProfileInt("Preferences", "AutoHideTabbar", TRUE);
	m_bStackTabbarItems = prefs.GetProfileInt("Preferences", "StackTabbarItems", FALSE);
	m_bRightAlignLabels = prefs.GetProfileInt("Preferences", "RightAlignLabels", TRUE);
	m_bFocusTreeOnEnter = prefs.GetProfileInt("Preferences", "FocusTreeOnEnter", FALSE);
	m_nNewTaskPos = prefs.GetProfileInt("Preferences", "NewTaskPos", PUIP_BELOW);
	m_nNewSubtaskPos = prefs.GetProfileInt("Preferences", "NewSubtaskPos", PUIP_BOTTOM);
	m_bKeepTabsOrdered = prefs.GetProfileInt("Preferences", "KeepTabsOrdered", FALSE);
	m_bShowTasklistCloseButton = prefs.GetProfileInt("Preferences", "ShowTasklistCloseButton", TRUE);
	m_bSortDoneTasksAtBottom = prefs.GetProfileInt("Preferences", "SortDoneTasksAtBottom", TRUE);
	m_bRTLComments = prefs.GetProfileInt("Preferences", "RTLComments", FALSE);
	m_nCommentsPos = prefs.GetProfileInt("Preferences", "VertComments", PUIP_RIGHTCOMMENTS);
	m_bMultiSelFilters = prefs.GetProfileInt("Preferences", "MultiSelFilters", TRUE);
	m_bRestoreTasklistFilters = prefs.GetProfileInt("Preferences", "RestoreTasklistFilters", TRUE);
	m_bAutoRefilter = prefs.GetProfileInt("Preferences", "AutoRefilter", TRUE);
	m_bEnableLightboxMgr = prefs.GetProfileInt("Preferences", "EnableLightboxMgr", COSVersion() <= OSV_XP);
	m_bUseUITheme = CThemed::IsThemeActive() && prefs.GetProfileInt("Preferences", "UseUITheme", TRUE);
//	m_b = prefs.GetProfileInt("Preferences", "", FALSE);

	// set default theme to blue
	if (CThemed::IsThemeActive())
	{
		CString sDefault = FileMisc::GetModuleFolder() + "Resources\\ThemeBlue.xml";
		m_sUIThemeFile = prefs.GetProfileString("Preferences", "UIThemeFile", sDefault);
	}
	else
		m_sUIThemeFile.Empty();

	// comments format
	if (m_cbCommentsFmt.IsInitialized())
	{
		m_cfDefault = prefs.GetProfileString("Preferences", "DefaultCommentsFormatID");
		m_nDefaultCommentsFormat = m_cbCommentsFmt.SetSelectedFormat(m_cfDefault);

		// fallback
		if (m_nDefaultCommentsFormat == CB_ERR)
			m_nDefaultCommentsFormat = prefs.GetProfileInt("Preferences", "DefaultCommentsFormat", -1);

		if (m_nDefaultCommentsFormat == CB_ERR || m_nDefaultCommentsFormat >= m_cbCommentsFmt.GetCount())
		{
			ASSERT (m_cbCommentsFmt.GetCount());

			m_nDefaultCommentsFormat = 0;
		}

		m_cbCommentsFmt.SetCurSel(m_nDefaultCommentsFormat);
		m_cbCommentsFmt.GetSelectedFormat(m_cfDefault);
	}
}

void CPreferencesUIPage::SavePreferences(CPreferences& prefs)
{
	// save settings
	prefs.WriteProfileInt("Preferences", "ShowCtrlsAsColumns", m_bShowCtrlsAsColumns);
	prefs.WriteProfileInt("Preferences", "ShowEditMenuAsColumns", m_bShowEditMenuAsColumns);
	prefs.WriteProfileInt("Preferences", "ShowCommentsAlways", m_bShowCommentsAlways);
	prefs.WriteProfileInt("Preferences", "AutoReposCtrls", m_bAutoReposCtrls);
	prefs.WriteProfileInt("Preferences", "SpecifyToolbarImage", m_bSpecifyToolbarImage);
	prefs.WriteProfileInt("Preferences", "SharedCommentsHeight", m_bSharedCommentsHeight);
	prefs.WriteProfileInt("Preferences", "AutoHideTabbar", m_bAutoHideTabbar);
	prefs.WriteProfileInt("Preferences", "StackTabbarItems", m_bStackTabbarItems);
	prefs.WriteProfileInt("Preferences", "RightAlignLabels", m_bRightAlignLabels);
	prefs.WriteProfileInt("Preferences", "FocusTreeOnEnter", m_bFocusTreeOnEnter);
	prefs.WriteProfileInt("Preferences", "NewTaskPos", m_nNewTaskPos);
	prefs.WriteProfileInt("Preferences", "NewSubtaskPos", m_nNewSubtaskPos);
	prefs.WriteProfileInt("Preferences", "KeepTabsOrdered", m_bKeepTabsOrdered);
	prefs.WriteProfileInt("Preferences", "ShowTasklistCloseButton", m_bShowTasklistCloseButton);
	prefs.WriteProfileInt("Preferences", "SortDoneTasksAtBottom", m_bSortDoneTasksAtBottom);
	prefs.WriteProfileInt("Preferences", "RTLComments", m_bRTLComments);
	prefs.WriteProfileInt("Preferences", "VertComments", m_nCommentsPos);
	prefs.WriteProfileInt("Preferences", "MultiSelFilters", m_bMultiSelFilters);
	prefs.WriteProfileInt("Preferences", "RestoreTasklistFilters", m_bRestoreTasklistFilters);
	prefs.WriteProfileInt("Preferences", "AutoRefilter", m_bAutoRefilter);
	prefs.WriteProfileString("Preferences", "UIThemeFile", m_sUIThemeFile);
	prefs.WriteProfileInt("Preferences", "UseUITheme", m_bUseUITheme);
	prefs.WriteProfileInt("Preferences", "EnableLightboxMgr", m_bEnableLightboxMgr);
//	prefs.WriteProfileInt("Preferences", "", m_b);

	// comments format
	if (m_pContentMgr)
	{
		prefs.WriteProfileInt("Preferences", "DefaultCommentsFormat", m_nDefaultCommentsFormat);
		prefs.WriteProfileString("Preferences", "DefaultCommentsFormatID", m_cfDefault);
	}
}

void CPreferencesUIPage::OnUseuitheme() 
{
	UpdateData();
	GetDlgItem(IDC_UITHEMEFILE)->EnableWindow(m_bUseUITheme);

	CPreferencesPageBase::OnControlChange();
}

CString CPreferencesUIPage::GetUITheme() const 
{ 
	if (m_bUseUITheme)
		return FileMisc::GetFullPath(m_sUIThemeFile, TRUE);
	
	// else
	return "";
}
                                                                                                                                                                                                                                                                                                                                                                                                                   rn 3;
	case 2: /* wed */ return 4;
	case 3: /* thu */ return 5;
	case 4: /* fri */ return 6;
	case 5: /* sat */ return 7;
	case 6: /* sun */ return 1;
	}

	ASSERT (0);
	return 1;
}

int CDateHelper::LastDayOfWeek()
{
	switch (FirstDayOfWeek())
	{
	case 2: /* mon */ return 1; // sun
	case 3: /* tue */ return 2; // mon
	case 4: /* wed */ return 3; // tue
	case 5: /* thu */ return 4; // wed
	case 6: /* fri */ return 5; // thu
	case 7: /* sat */ return 6; // fri
	case 1: /* sun */ return 7; // sat
	}

	ASSERT (0);
	return 1;
}

int CDateHelper::NextDayOfWeek(int nDOW)
{
	switch (nDOW)
	{
	case 2: /* mon */ return 3; // tue
	case 3: /* tue */ return 4; // wed
	case 4: /* wed */ return 5; // thu
	case 5: /* thu */ return 6; // fri
	case 6: /* fri */ return 7; // sat
	case 7: /* sat */ return 1; // sun
	case 1: /* sun */ return 2; // mon
	}

	ASSERT (0);
	return 1;
}

CString CDateHelper::FormatDate(const COleDateTime& date, DWORD dwFlags)
{
	SYSTEMTIME st;

	if (!date.GetAsSystemTime(st))
		return "";

	CString sFormat;

	if (dwFlags & DHFD_ISO)
	{
		sFormat = "yyyy-MM-dd";

		if (dwFlags & DHFD_DOW)
			sFormat = "ddd " + sFormat;
	}
	else
		sFormat = Misc::GetShortDateFormat(dwFlags & DHFD_DOW);

	CString sDate;
	::GetDateFormat(0, 0, &st, sFormat, sDate.GetBuffer(50), 49);
	sDate.ReleaseBuffer();

	// want time?
	if (dwFlags & DHFD_TIME)
	{
		if (dwFlags & DHFD_ISO)
		{
			sDate += 'T'; // ISO delimiter
			sDate += CTimeHelper::FormatISOTime(st.wHour, st.wMinute, st.wSecond, !(dwFlags & DHFD_NOSEC));
		}
		else 
		{
			sDate += ' ';
			sDate += CTimeHelper::Format24HourTime(st.wHour, st.wMinute, st.wSecond, !(dwFlags & DHFD_NOSEC));
		}
	}
	
	return sDate;
}

CString CDateHelper::FormatCurrentDate(DWORD dwFlags)
{
	return FormatDate(COleDateTime::GetCurrentTime(), dwFlags);
}

CString CDateHelper::GetWeekday(int nWeekday, BOOL bShort)
{
	LCTYPE lct = bShort ? LOCALE_SABBREVDAYNAME1 : LOCALE_SDAYNAME1;
	CString sWeekday;

#if !defined(AFX_PREFERENCESUIPAGE_H__5AE787F2_44B0_4A48_8D75_24C6C16B45DF__INCLUDED_)
#define AFX_PREFERENCESUIPAGE_H__5AE787F2_44B0_4A48_8D75_24C6C16B45DF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesUIPage.h : header file
//

#include "..\shared\contentMgr.h"
#include "..\shared\fileedit.h"
#include "..\shared\groupline.h"
#include "..\shared\preferencesbase.h"
#include "..\shared\contenttypecombobox.h"

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUIPage dialog

enum 
{ 
	PUIP_TOP,
	PUIP_BOTTOM,
	PUIP_ABOVE,
	PUIP_BELOW,
};

enum
{
	PUIP_BOTTOMCOMMENTS,
	PUIP_RIGHTCOMMENTS,
//	PUIP_BOTTOMRIGHTCOMMENTS,
};

class CPreferencesUIPage : public CPreferencesPageBase
{
	DECLARE_DYNCREATE(CPreferencesUIPage)

// Construction
public:
	CPreferencesUIPage(const CContentMgr* pMgr = NULL);
	~CPreferencesUIPage();

	BOOL GetShowCtrlsAsColumns() const { return m_bShowCtrlsAsColumns; }
	BOOL GetShowEditMenuAsColumns() const { return m_bShowEditMenuAsColumns; }
	BOOL GetShowCommentsAlways() const { return m_bShowCommentsAlways; }
	BOOL GetAutoReposCtrls() const { return m_bAutoReposCtrls; }
	BOOL GetSharedCommentsHeight() const { return m_bSharedCommentsHeight; }
	BOOL GetAutoHideTabbar() const { return m_bAutoHideTabbar; }
	BOOL GetStackTabbarItems() const { return m_bStackTabbarItems; }
	BOOL GetRightAlignLabels() const { return m_bRightAlignLabels; }
	BOOL GetFocusTreeOnEnter() const { return m_bFocusTreeOnEnter; }
	int GetNewTaskPos() const { return m_nNewTaskPos; }
	int GetNewSubtaskPos() const { return m_nNewSubtaskPos; }
	BOOL GetKeepTabsOrdered() const { return m_bKeepTabsOrdered; }
	BOOL GetShowTasklistCloseButton() const { return m_bShowTasklistCloseButton; }
	BOOL GetSortDoneTasksAtBottom() const { return m_bSortDoneTasksAtBottom; }
	BOOL GetRTLComments() const { return m_bRTLComments; }
	int GetCommentsPos() const { return m_nCommentsPos; }
	CONTENTFORMAT GetDefaultCommentsFormat() const { return m_cfDefault; }
	BOOL GetMultiSelFilters() const { return m_bMultiSelFilters; }
	BOOL GetRestoreTasklistFilters() const { return m_bRestoreTasklistFilters; }
	BOOL GetReFilterOnModify() const { return m_bAutoRefilter; }
	CString GetUITheme() const;
	BOOL GetEnableLightboxMgr() const { return m_bEnableLightboxMgr; }
//	BOOL Get() const { return ; }

protected:
// Dialog Data
	//{{AFX_DATA(CPreferencesUIPage)
	enum { IDD = IDD_PREFUI_PAGE };
	CFileEdit	m_eUITheme;
	BOOL	m_bShowCtrlsAsColumns;
	BOOL	m_bShowCommentsAlways;
	BOOL	m_bAutoReposCtrls;
	BOOL	m_bSpecifyToolbarImage;
	BOOL	m_bSharedCommentsHeight;
	BOOL	m_bAutoHideTabbar;
	BOOL	m_bStackTabbarItems;
	BOOL	m_bRightAlignLabels;
	BOOL	m_bFocusTreeOnEnter;
	int		m_nNewTaskPos;
	int		m_nNewSubtaskPos;
	BOOL	m_bKeepTabsOrdered;
	BOOL	m_bShowTasklistCloseButton;
	BOOL	m_bRTLComments;
	BOOL	m_bShowEditMenuAsColumns;
	BOOL	m_bMultiSelFilters;
	BOOL	m_bRestoreTasklistFilters;
	BOOL	m_bAutoRefilter;
	CString	m_sUIThemeFile;
	BOOL	m_bUseUITheme;
	BOOL	m_bEnableLightboxMgr;
	//}}AFX_DATA
	int		m_nCommentsPos;
	CContentTypeComboBox	m_cbCommentsFmt;
	BOOL	m_bSortDoneTasksAtBottom;
	const CContentMgr* m_pContentMgr;
	CGroupLineManager m_mgrGroupLines;
	CONTENTFORMAT m_cfDefault;
	int m_nDefaultCommentsFormat;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesUIPage)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesUIPage)
	afx_msg void OnUseuitheme();
	//}}AFX_MSG
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeCommentsformat();
	DECLARE_MESSAGE_MAP()

   virtual void LoadPreferences(const CPreferences& prefs);
   virtual void SavePreferences(CPreferences& prefs);

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESUIPAGE_H__5AE787F2_44B0_4A48_8D75_24C6C16B45DF__INCLUDED_)
                                                                                                                                                                                                                                                                                                                                                                                                                                 :GetMonths(BOOL bShort, CStringArray& aMonths)
{
	aMonths.RemoveAll();

	for (int nMonth = 1; nMonth <= 12; nMonth++)
		aMonths.Add(GetMonth(nMonth, bShort));
}

double CDateHelper::GetTimeOnly(const COleDateTime& date)
{
	return (date.m_dt - GetDateOnly(date));
}

BOOL CDateHelper::DateHasTime(const COleDateTime& date)
{
	return (GetTimeOnly(date) > 0);
}

double CDateHelper::GetDateOnly(const COleDateTime& date)
{
	return floor(date.m_dt);
}

void CDateHelper::SplitDate(const COleDateTime& date, double& dDateOnly, double& dTimeOnly)
{
	dDateOnly = GetDateOnly(date);
	dTimeOnly = GetTimeOnly(date);
}

double CDateHelper::MakeDate(const COleDateTime& dtTimeOnly, const COleDateTime& dtDateOnly)
{
	double dDateOnly = GetDateOnly(dtDateOnly);
	double dTimeOnly = GetTimeOnly(dtTimeOnly);
	
	return dDateOnly + dTimeOnly;
}
