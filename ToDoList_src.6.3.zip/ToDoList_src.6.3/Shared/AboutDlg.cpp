#if !defined(AFX_WCDEFINES_H__E2EFA8F0_B9CD_41AB_98FD_812C963B7ACC__INCLUDED_)
#define AFX_WCDEFINES_H__E2EFA8F0_B9CD_41AB_98FD_812C963B7ACC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//////////////////////////

#define WC_BUTTONA              "Button"	// ansi
#define WC_BUTTONW              L"Button"	// wide

#ifdef UNICODE
#define WC_BUTTON               WC_BUTTONW
#else
#define WC_BUTTON               WC_BUTTONA
#endif

//////////////////////////

#define WC_STATICA              "Static"	// ansi
#define WC_STATICW              L"Static"	// wide

#ifdef UNICODE
#define WC_STATIC               WC_STATICW
#else
#define WC_STATIC               WC_STATICA
#endif

//////////////////////////

#define WC_EDITA              "Edit"	// ansi
#define WC_EDITW              L"Edit"	// wide

#ifdef UNICODE
#define WC_EDIT               WC_EDITW
#else
#define WC_EDIT               WC_EDITA
#endif

//////////////////////////

#define WC_COMBOBOXA              "ComboBox"	// ansi
#define WC_COMBOBOXW              L"ComboBox"	// wide

#ifdef UNICODE
#define WC_COMBOBOX               WC_COMBOBOXW
#else
#define WC_COMBOBOX               WC_COMBOBOXA
#endif

//////////////////////////

#define WC_COMBOLBOXA              "ComboLBox"	// ansi
#define WC_COMBOLBOXW              L"ComboLBox"	// wide

#ifdef UNICODE
#define WC_COMBOLBOX               WC_COMBOLBOXW
#else
#define WC_COMBOLBOX               WC_COMBOLBOXA
#endif

//////////////////////////

#define WC_LISTBOXA              "ListBox"	// ansi
#define WC_LISTBOXW              L"ListBox"	// wide

#ifdef UNICODE
#define WC_LISTBOX               WC_LISTBOXW
#else
#define WC_LISTBOX               WC_LISTBOXA
#endif

//////////////////////////

#define WC_CHECKLISTBOXA         "CheckListBox"	// ansi
#define WC_CHECKLISTBOXW         L"CheckListBox"	// wide

#ifdef UNICODE
#define WC_CHECKLISTBOX          WC_CHECKLISTBOXW
#else
#define WC_CHECKLISTBOX          WC_CHECKLISTBOXA
#endif

//////////////////////////

#ifndef WC_SCROLLBARA

#define WC_SCROLLBARA              "Scrollbar"	// ansi
#define WC_SCROLLBARW              L"Scrollbar"	// wide

#ifdef UNICODE
#define WC_SCROLLBAR               WC_SCROLLBARW
#else
#define WC_SCROLLBAR               WC_SCROLLBARA
#endif

#endif

//////////////////////////

#define WC_TOOLBARA              "toolbarwindow32"	// ansi
#define WC_TOOLBARW              L"toolbarwindow32"	// wide

#ifdef UNICODE
#define WC_TOOLBAR               WC_TOOLBARW
#else
#define WC_TOOLBAR               WC_TOOLBARA
#endif

//////////////////////////

#define WC_SPINA              "msctls_updown32"	// ansi
#define WC_SPINW              L"msctls_updown32"	// wide

#ifdef UNICODE
#define WC_SPIN               WC_SPINW
#else
#define WC_SPIN               WC_SPINA
#endif

//////////////////////////

#define WC_PROGRESSA              "msctls_progress32"	// ansi
#define WC_PROGRESSW              L"msctls_progress32"	// wide

#ifdef UNICODE
#define WC_PROGRESS               WC_PROGRESSW
#else
#define WC_PROGRESS               WC_PROGRESSA
#endif

//////////////////////////

#define WC_SLIDERA              "msctls_trackbar32"	// ansi
#define WC_SLIDERW              L"msctls_trackbar32"	// wide

#ifdef UNICODE
#define WC_SLIDER               WC_SLIDERW
#else
#define WC_SLIDER               WC_SLIDERA
#endif

//////////////////////////

#define WC_HOTKEYA              "msctls_hotkey32"	// ansi
#define WC_HOTKEYW              L"msctls_hotkey32"	// wide

#ifdef UNICODE
#define WC_HOTKEY               WC_HOTKEYW
#else
#define WC_HOTKEY               WC_HOTKEYA
#endif

//////////////////////////

#define WC_SHELLDLLDEFVIEWA              "SHELLDLL_DefView"	// ansi
#define WC_SHELLDLLDEFVIEWW   