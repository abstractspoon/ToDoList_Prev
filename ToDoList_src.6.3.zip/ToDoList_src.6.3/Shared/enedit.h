ry.Flush();
		
		else if (m_cbStatus.IsChild(pFocus))
			m_cbStatus.Flush();
		
		else if (m_cbAllocBy.IsChild(pFocus))
			m_cbAllocBy.Flush();
		
		else if (m_cbAllocTo.IsChild(pFocus))
			m_cbAllocTo.Flush();
	}

	m_data.ResetCachedCalculations();
	m_treeDragDrop.CancelDrag();

	HandleUnsavedComments();

	if (bEndTimeTracking)
		EndTimeTracking();
}

BOOL CToDoCtrl::CheckIn()
{
	ASSERT (HasStyle(TDCS_ENABLESOURCECONTROL) && !HasStyle(TDCS_USES3RDPARTYSOURCECONTROL));

	if (!HasStyle(TDCS_ENABLESOURCECONTROL) || HasStyle(TDCS_USES3RDPARTYSOURCECONTROL))
		return FALSE;
	
	if (m_sLastSavePath.IsEmpty())
		return TRUE;
	
	CTaskFile file(m_sPassword);
	
	// backup the file
	CTempFileBackup backup(m_sLastSavePath);

	// load the file in its encrypted state because we're not interested 
	// in changing that bit of it
	if (file.Open(m_sLastSavePath, XF_READWRITE, FALSE) && file.LoadEx())
	{
		m_bSourceControlled = file.IsSourceControlled();

		if (m_bSourceControlled)
		{
			CString sCheckedOutTo = file.GetCheckOutTo();
			
			if (sCheckedOutTo.IsEmpty() || sCheckedOutTo == m_sMachineName) // its us
			{
				file.SetCheckedOutTo(""); // retain the item
				
				// and rewrite the file but keeping the same timestamp
				FILETIME ftMod;
				::GetFileTime((HANDLE)file.GetFileHandle(), NULL, NULL, &ftMod);
				
				m_bCheckedOut = !file.SaveEx(); // ie if successfully saved then m_bCheckedOut == 0
				
				::SetFileTime((HANDLE)file.GetFileHandle(), NULL, NULL, &ftMod);
				
				return !m_bCheckedOut;
			}
		}
	}
	
	// else someone else or invalid file
	return FALSE;
}

BOOL CToDoCtrl::CheckOut()
{
	CString sTemp;
	return CheckOut(sTemp);
}

BOOL CToDoCtrl::RemoveFromSourceControl()
{
	// can't be checked out to someone
	if (IsCheckedOut())
		return FALSE;

	m_bSourceControlled = FALSE;

	if (!m_sLastSavePath.IsEmpty())
		return (Save() == TDCO_SUCCESS);

	// else
	return TRUE;
}

BOOL CToDoCtrl::CheckOut(CString& sCheckedOutTo)
{
	ASSERT (HasStyle(TDCS_ENABLESOURCECONTROL) && !HasStyle(TDCS_USES3RDPARTYSOURCECONTROL));

	if (!HasStyle(TDCS_ENABLESOURCECONTROL) || HasStyle(TDCS_USES3RDPARTYSOURCECONTROL))
		return FALSE;
	
	if (m_sLastSavePath.IsEmpty())
		return TRUE;
	
	CTaskFile file(m_sPassword);
	CWaitCursor cursor;
	
	// backup the file
	CTempFileBackup backup(m_sLastSavePath);

	if (file.Open(m_sLastSavePath, XF_READWRITE, FALSE) && file.LoadEx())
	{
		m_bCheckedOut = file.CheckOut(sCheckedOutTo);
		m_bSourceControlled = file.IsSourceControlled();

		if (m_bCheckedOut)
		{
		    file.Decrypt();

			// restore unsorted order
			if (file.GetFileFormat() <= FILEFORMAT_SORTBYID)
	 			file.SortTasksByPos();
			
			LoadTasks(file); // reload file
			return TRUE;
		}
	}
	
	return FALSE;
}

int CToDoCtrl::FindTasks(const SEARCHPARAMS& params, CResultArray& aResults) const
{
	return m_find.FindTasks(params, aResults);
}

DWORD CToDoCtrl::FindFirstTask(const SEARCHPARAMS& params, SEARCHRESULT& result) const
{
	return m_find.FindFirstTask(params, result);
}

BOOL CToDoCtrl::SelectTask(CString sPart, TDC_SELECTTASK nSelect)
{
	SEARCHRESULT result;

	// build a search query
	SEARCHPARAMS params;
	params.rules.Add(SEARCHPARAM(TDCA_TASKNAMEORCOMMENTS, FO_INCLUDES, sPart));

	switch (nSelect)
	{
	case TDC_SELECTFIRST:
		m_find.FindFirstTask(params, result);
		break;

	case TDC_SELECTNEXT:
	case TDC_SELECTNEXTINCLCURRENT:
	case TDC_SELECTPREV:
		{
			HTREEITEM hti = GetSelectedItem(); // our start point

			if (!hti)
				return FALSE;

			// we want to start searching from the next item
			switch (nSelect)
			{
				case TDC_SELECTNEXT:
					hti = m_tree.TCH().GetNextItem(hti);
					break;

 				case TDC_SELECTNEXTINCLCURRENT:
 					// nothing to do
 					break;

				case TDC_SELECTPREV:
					hti = m_tree.TCH().GetPrevItem(hti);
					break;
			}

			if (!hti)
				return FALSE; // at the end/start

			BOOL bNext = (nSelect != TDC_SELECTPREV);
			m_find.FindNextTask(GetTaskID(hti), params, result, bNext);
		}
		break;

	case TDC_SELE