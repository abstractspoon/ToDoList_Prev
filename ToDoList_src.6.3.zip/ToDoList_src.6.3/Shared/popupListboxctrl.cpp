dex(HTASKITEM hTask, int nIndex);
	int  GetTaskIconIndex(HTASKITEM hTask) const;

	BOOL SetTaskCategories(HTASKITEM hTask, const CStringArray& aCategories);
	int  GetTaskCategories(HTASKITEM hTask, CStringArray& aCategories) const;

	BOOL SetTaskDependencies(HTASKITEM hTask, const CStringArray& aDepends);
	int  GetTaskDependencies(HTASKITEM hTask, CStringArray& aDepends) const;

	BOOL SetTaskAllocatedTo(HTASKITEM hTask, const CStringArray& aAllocTo);
	int  GetTaskAllocatedTo(HTASKITEM hTask, CStringArray& aAllocTo) const;

	BOOL SetTaskCustomComments(HTASKITEM hTask, const CString& sContent, const CString& sType);
	BOOL GetTaskCustomComments(HTASKITEM hTask, CString& sContent, CString& sType) const;
	BOOL SetTaskHtmlComments(HTASKITEM hTask, const CString& sContent, BOOL bForTransform);
	
	BOOL DeleteTaskAttributes(HTASKITEM hTask);// deletes all but child tasks
	BOOL DeleteTask(HTASKITEM hTask);
	HTASKITEM FindTask(DWORD dwTaskID) const;

	BOOL CheckIn();
	BOOL CheckOut();
	BOOL CheckOut(CString& sCheckedOutTo);

	BOOL SetReportAttributes(LPCTSTR szTitle, const COleDateTime& date = 0.0);
	BOOL HideAttribute(HTASKITEM hTask, const char* szAttrib, BOOL bHide = TRUE);

	bool SetTaskPriority(HTASKITEM hTask, int nPriority);
	bool SetTaskRisk(HTASKITEM hTask, int nRisk);

	//////////////////////////////////////////////////////////////
	// ITaskList7 implementation 
	unsigned char GetTaskDependencyCount(HTASKITEM hTask) const;
	bool AddTaskDependency(HTASKITEM hTask, const char* szDepends);
	const char* GetTaskDependency(HTASKITEM hTask, int nIndex) const;

	unsigned char GetTaskAllocatedToCount(HTASKITEM hTask) const;
	bool AddTaskAllocatedTo(HTASKITEM hTask, const char* szAllocTo);
	const char* GetTaskAllocatedTo(HTASKITEM hTask, int nIndex) const;

	//////////////////////////////////////////////////////////////
	// ITaskList6 implementation 
	bool SetTaskRecurrence(HTASKITEM hTask, int nRegularity, DWORD dwSpecific1, 
									DWORD dwSpecific2, BOOL bRecalcFromDue, int nReuse);
	bool GetTaskRecurrence(HTASKITEM hTask, int& nRegularity, DWORD& dwSpecific1, 
									DWORD& dwSpecific2, BOOL& bRecalcFromDue, int& nReuse) const;

	bool SetTaskVersion(HTASKITEM hTask, const char* szVersion);
	const char* GetTaskVersion(HTASKITEM hTask) const;

	//////////////////////////////////////////////////////////////
	// ITaskList5 implementation 
	bool AddTaskCategory(HTASKITEM hTask, const char* szCategory);

	//////////////////////////////////////////////////////////////
	// ITaskList4 implementation 
	const char* GetAttribute(const char* szAttrib) const;

	const char* GetHtmlCharSet() const;
	const char* GetReportTitle() const;
	const char* GetReportDate() const;
	double GetTaskCost(HTASKITEM hTask, BOOL bCalc) const;
	unsigned char GetTaskCategoryCount(HTASKITEM hTask) const;
	const char* GetTaskCategory(HTASKITEM hTask, int nIndex) const;
	const char* GetTaskDependency(HTASKITEM hTask) const;

	bool SetTaskCost(HTASKITEM hTask, double dCost);
	bool SetTaskDependency(HTASKITEM hTask, const char* szDepends);

	//////////////////////////////////////////////////////////////
	// ITaskList3 implementation 
	time_t GetTaskDueDate(HTASKITEM hTask, BOOL bEarliest) const;
	const char* GetTaskDueDateString(HTASKITEM hTask, BOOL bEarliest) const;
	unsigned long GetTaskTextColor(HTASKITEM hTask) const;
	int GetTaskRisk(HTASKITEM hTask, BOOL bHighest) const;
	const char* GetTaskExternalID(HTASKITEM hTask) const;

	bool SetTaskRisk(HTASKITEM hTask, unsigned char nRisk);
	bool SetTaskExternalID(HTASKITEM hTask, const char* szID);

	//////////////////////////////////////////////////////////////
	// ITaskList2 implementation 
	
	const char* GetTaskCreatedBy(HTASKITEM hTask) const;
	time_t GetTaskCreationDate(HTASKITEM hTask) const;
	const char* GetTaskCreationDateString(HTASKITEM hTask) const;

	bool SetTaskCreatedBy(HTASKITEM hTask, const char* szCreatedBy);
	bool SetTaskCreationDate(HTASKITEM hTask, time_t tCreationDate);

	//////////////////////////////////////////////////////////////
	// ITaskList implementation 

	bool IsArchive() const;
	bool IsCheckedOut() const;
	bool IsSourceControlled() const;
	
	const char* GetProjectName() const;
	const char* GetCheckOutTo() const;
	
	unsigned long GetFileFormat() const;
	unsigned long GetFileVersion() const;
	
	time_t GetLastModified() const;

	bool SetProjectName(const char* szName);
	bool SetFileVersion(unsigned long nVersion);

	//////////////////////////////////////////////////////////////

	HTASKITEM NewTask(const char* szTitle, HTASKITEM hParent = NULL);

	HTASKITEM GetFirstTask(HTASKITEM hParent = NULL) const;
	HTASKITEM GetNextTask(HTASKITEM hTask) const;

	const char* GetTaskTitle(HTASKITEM hTask) const;
	const char* GetTaskComments(HTASKITEM hTask) const;
	const char* GetTaskAllocatedTo(HTASKITEM hTask) const;
	const char* GetTaskAllocatedBy(HTASKITEM hTask) const;
	const char* GetTaskCategory(HTASKITEM hTask) const;
	const char* GetTaskStatus(HTASKITEM hTask) const;
	const char* GetTaskFileReferencePath(HTASKITEM hTask) const;
	const char* GetTaskWebColor(HTASKITEM hTask) const;
	const char* GetTaskPriorityWebColor(HTASKITEM hTask) const;

	unsigned long GetTaskID(HTASKITEM hTask) const;
	unsigned long GetTaskColor(HTASKITEM hTask) const;
	unsigned long GetTaskPriorityColor(HTASKITEM hTask) const;

	int GetTaskPriority(HTASKITEM hTask, BOOL bHighest) const;
	unsigned char GetTaskPercentDone(HTASKITEM hTask, BOOL bCalc) const;

	double GetTaskTimeEstimate(HTASKITEM hTask, char& cUnits, BOOL bCalc) const;
	double GetTaskTimeSpent(HTASKITEM hTask, char& cUnits, BOOL bCalc) const;

	time_t GetTaskLastModified(HTASKITEM hTask) const;
	time_t GetTaskDoneDate(HTASKITEM hTask) const;
	time_t GetTaskDueDate(HTASKITEM hTask) const;
	time_t GetTaskStartDate(HTASKITEM hTask) const;

	const char* GetTaskDoneDateString(HTASKITEM hTask) const;
	const char* GetTaskDueDateString(HTASKITEM hTask) const;
	const char* GetTaskStartDateString(HTASKITEM hTask) const;
	
	bool IsTaskDone(HTASKITEM hTask) const;
	bool IsTaskDue(HTASKITEM hTask) const;

	unsigned long GetTaskPosition(HTASKITEM hTask) const;

	bool IsTaskFlagged(HTASKITEM hTask) const;

	bool TaskHasAttribute(HTASKITEM hTask, const char* szAttrib) const;
	const char* GetTaskAttribute(HTASKITEM hTask, const char* szAttrib) const;
	HTASKITEM GetTaskParent(HTASKITEM hTask) const;

	/////////////////////////////////////////////////////

	bool SetTaskTitle(HTASKITEM hTask, const char* szTitle);
	bool SetTaskComments(HTASKITEM hTask, const char* szComments);
	bool SetTaskAllocatedTo(HTASKITEM hTask, const char* szAllocTo);
	bool SetTaskAllocatedBy(HTASKITEM hTask, const char* szAllocBy);
	bool SetTaskCategory(HTASKITEM hTask, const char* szCategory);
	bool SetTaskStatus(HTASKITEM hTask, const char* szStatus);
	bool SetTaskFileReferencePath(HTASKITEM hTask, const char* szFileRefpath);

	bool SetTaskColor(HTASKITEM hTask, unsigned long nColor);
	bool SetTaskWebColor(HTASKITEM hTask, unsigned long nColor);

	bool SetTaskPriority(HTASKITEM hTask, unsigned char nPriority);
	bool SetTaskPercentDone(HTASKITEM hTask, unsigned char nPercent);

	bool SetTaskTimeEstimate(HTASKITEM hTask, double dTimeEst, char cUnits);
	bool SetTaskTimeSpent(HTASKITEM hTask, double dTimeSpent, char cUnits);

	bool SetTaskLastModified(HTASKITEM hTask, time_t tLastMod);
	bool SetTaskDoneDate(HTASKITEM hTask, time_t tDoneDate);
	bool SetTaskDueDate(HTASKITEM hTask, time_t tDueDate);
	bool SetTaskStartDate(HTASKITEM hTask, time_t tStartDate);

	bool SetTaskPosition(HTASKITEM hTask, unsigne