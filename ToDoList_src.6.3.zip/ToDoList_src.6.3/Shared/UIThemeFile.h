// UIThemeFile.h: interface for the CUIThemeFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UITHEMEFILE_H__A652A09A_AB3F_4B65_A3D9_B4B975A36195__INCLUDED_)
#define AFX_UITHEMEFILE_H__A652A09A_AB3F_4B65_A3D9_B4B975A36195__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\SHARED\uitheme.h"

class CXmlFile;

class CUIThemeFile : public UITHEME  
{
public:
	CUIThemeFile();
	virtual ~CUIThemeFile();

	BOOL LoadThemeFile(LPCTSTR szThemeFile);
	void Reset();

protected:
	static COLORREF GetColor(const CXmlFile& xiFile, LPCTSTR szName, int nColorID = -1);
	static UI_STYLE GetStyle(const CXmlFile& xiFile);

};

#endif // !defined(AFX_UITHEMEFILE_H__A652A09A_AB3F_4B65_A3D9_B4B975A36195__INCLUDED_)
