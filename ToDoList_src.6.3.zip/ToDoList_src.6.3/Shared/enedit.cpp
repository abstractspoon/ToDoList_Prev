
      
      if (pTDI->aDependencies.GetSize() && filter.WantAttribute(TDCA_DEPENDENCY))
         file.SetTaskDependencies(hTask, pTDI->aDependencies);
      
      if (filter.WantAttribute(TDCA_PRIORITY))
      {
         file.SetTaskPriority(hTask, nPriority);
         
         if (nHighestPriority > nPriority)
            file.SetTaskHighestPriority(hTask, nHighestPriority);
      }
      
      if (filter.WantAttribute(TDCA_RISK))
      {
         file.SetTaskRisk(hTask, pTDI->nRisk);
         
         int nHighestRisk = m_data.GetHighestRisk(pTDI, pTDS);
         
         if (nHighestRisk > pTDI->nRisk)
            file.SetTaskHighestRisk(hTask, nHighestRisk);
      }
      
      // percent done
      if (filter.WantAttribute(TDCA_PERCENT))
      {
         // don't allow incomplete tasks to be 100%
         int nPercent = pTDI->IsDone() ? 100 : min(99, pTDI->nPercentDone); 
         file.SetTaskPercentDone(hTask, (unsigned char)nPercent);
         
         // calculated percent
         nPercent = m_data.CalcPercentDone(pTDI, pTDS);
         
         if (nPercent > 0)
            file.SetTaskCalcCompletion(hTask, nPercent);
      }
      
      // cost
      if (filter.WantAttribute(TDCA_COST))
      {
         //if (pTDI->dCost > 0)
            file.SetTaskCost(hTask, pTDI->dCost);
         
         double dCost = m_data.CalcCost(pTDI, pTDS);
         
         //if (dCost > 0)
            file.SetTaskCalcCost(hTask, dCost);
      }
      
      // time estimate
      if (filter.WantAttribute(TDCA_TIMEEST))
      {
         if (pTDI->dTimeEstimate > 0 || pTDI->nTimeEstUnits != TDITU_HOURS)
            file.SetTaskTimeEstimate(hTask, pTDI->dTimeEstimate, m_data.MapTimeUnits(pTDI->nTimeEstUnits)[0]);
         
         double dTime = m_data.CalcTimeEstimate(pTDI, pTDS, TDITU_HOURS);
         
         if (dTime > 0)
            file.SetTaskCalcTimeEstimate(hTask, dTime);
      }
      
      // time spent
      if (filter.WantAttribute(TDCA_TIMESPENT))
      {
         if (pTDI->dTimeSpent > 0|| pTDI->nTimeSpentUnits != TDITU_HOURS)
            file.SetTaskTimeSpent(hTask, pTDI->dTimeSpent, m_data.MapTimeUnits(pTDI->nTimeSpentUnits)[0]);
         
         double dTime = m_data.CalcTimeSpent(pTDI, pTDS, TDITU_HOURS);
         
         if (dTime > 0)
            file.SetTaskCalcTimeSpent(hTask, dTime);
      }
      
      // done date
      if (bDone)
      {
         file.SetTaskDoneDate(hTask, pTDI->dateDone);
         
         // hide it if column not visible
         if (!filter.WantAttribute(TDCA_DONEDATE))
         {
            file.HideAttribute(hTask, TDL_TASKDONEDATE);
            file.HideAttribute(hTask, TDL_TASKDONEDATESTRING);
         }
      }
      
      // add due date if we're filtering by due date
      if (pTDI->HasDue() && (filter.dateDueBy > 0 || filter.WantAttribute(TDCA_DUEDATE)))
         file.SetTaskDueDate(hTask, pTDI->dateDue);
      
      if (HasStyle(TDCS_USEEARLIESTDUEDATE) && filter.WantAttribute(TDCA_DUEDATE))
      {
         double dDate = m_data.GetEarliestDueDate(pTDI, pTDS, TRUE);
         
         if (dDate > 0)
            file.SetTaskEarliestDueDate(hTask, dDate);
      }
      
      // start date
      if (pTDI->HasStart() && filter.WantAttribute(TDCA_STARTDATE))
         file.SetTaskStartDate(hTask, pTDI->dateStart);
      
      // creation date
      if (filter.WantAttribute(TDCA_CREATIONDATE))
         file.SetTaskCreationDate(hTask, pTDI->dateCreated);
      
      // modify date
      if (pTDI->HasLastMod() && filter.WantAttribute(TDCA_LASTMOD))
         file.SetTaskLastModified(hTask, pTDI->tLastMod);
      
      // custom comments
      if (filter.WantAttribute(TDCA_COMMENTS))
      {
         // Even if it's a text format we still need to write out the comments format
         // unless there were no comments or the comment type is the same as the default
         if (CONTENTFORMAT(pTDI->sCommentsTypeID).FormatIsText())
         {
            if (!pTDI->sComments.IsEmpty() || pTDI->sCommentsTypeID != m_cfDefault)
               file.SetTaskCustomComments(hTask, "", pTDI->sCommentsTypeID);
         }
         // else we save the custom comments either if there are any comments or if the
         // comments type is different from the default
         else if (!pTDI->sCustomComments.IsEmpty() || pTDI->sCommentsTypeID != m_cfDefault)
            file.SetTaskCustomComments(hTask, pTDI->sCustomComments, pTDI->sCommentsTypeID);
      }
   }
   else if (bDone)
   {
      file.SetTaskDoneDate(hTask, pTDI->dateDone);
      file.HideAttribute(hTask, TDL_TASKDONEDATE);
      file.HideAttribute(hTask, TDL_TASKDONEDATESTRING);
   }
   
   // task color
   if (pTDI->color)
      file.SetTaskColor(hTask, pTDI->color);
   
   // actual text color
   COLORREF colorText = HasStyle(TDCS_COLORTEXTBYNONE) ? GetSysColor(COLOR_WINDOWTEXT) : pTDI->color;
   
   if (bDone)
   {
      if (m_crDone != NOCOLOR)
         colorText = m_crDone;
   }
   else if (pTDI->IsDue())
   {
      if (m_crDue != NOCOLOR)
         colorText = m_crDue;
   }
   else if (HasStyle(TDCS_COLORTEXTBYCATEGORY))
      GetCategoryColor(pTDI->GetFirstCategory(), colorText);
   
   else if (HasStyle(TDCS_COLORTEXTBYPRIORITY))
      colorText = GetPriorityColor(nHighestPriority);
   
   if (colorText)
      file.SetTaskTextColor(hTask, colorText);
   
   // priority color
   file.SetTaskPriorityColor(hTask, GetPriorityColor(nHighestPriority));

   return TRUE;
}

int CToDoCtrl::AddTreeChildrenToTaskFile(HTREEITEM hti, CTaskFile& file, HTASKITEM hTask, const TDCGETTASKS& filter) const
{
	if (filter.dwFlags & TDCGTF_NOTSUBTASKS)
		return 0;

	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	int nChildren = 0;
	int nPos = 1; // positions are 1-based
	
	while (htiChild)
	{
		if (AddTreeItemToTaskFile(htiChild, file, hTask, filter, nPos))
			nChildren++;
		
		// next
		nPos++;
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
	
	return nChildren;
}

BOOL CToDoCtrl::AddTreeItemToTaskFile(HTREEITEM hti, CTaskFile& file, HTASKITEM hParentTask, 
						const TDCGETTASKS& filter, int nPos) const
{
	// attributes
	DWORD dwTaskID = GetTaskID(hti);
	TODOITEM* pTDI = GetTask(dwTaskID);
	
	if (pTDI)
	{
		BOOL bDone = pTDI->IsDone();
		BOOL bGoodAsDone = bDone ? TRUE : m_data.IsTaskDone(GetTaskID(hti), TDCCHECKALL);
		BOOL bTitleCommentsOnly = m_tree.ItemHasChildren(hti) &&
								(filter.dwFlags & TDCGTF_PARENTTITLECOMMENTSONLY);
		BOOL bWantSelected = filter.dwFlags & TDCGTF_SELECTED;
		
		CString sTitle = pTDI->sTitle;
		
		HTASKITEM hTask = file.NewTask(sTitle, hParentTask, dwTaskID);
		ASSERT(hTask);
		
		if (!hTask)
			return FALSE;

		const TODOSTRUCTURE* pTDS = m_data.LocateTask(dwTaskID);
		ASSERT (pTDS);
		
	    SetTaskAttributes(pTDI, pTDS, file, hTask, filter, nPos, bTitleCommentsOnly);

		// we return TRUE if we match the filter _or_ we have any matching children
		BOOL bMatch = AddTreeChildrenToTaskFile(hti, file, hTask, filter);

		if (!bMatch) //  no children matched
		{
			switch (filter.nFilter)
			{
			case TDCGT_ALL:
				bMatch = TRUE; // always
				break;
				
			case TDCGT_DUE:
			case TDCGT_DUETOMORROW:
			case TDCGT_DUETHISWEEK:
			case TDCGT_DUENEXTWEEK:
			case TDCGT_DUETHISMONTH:
			case TDCGT_DUENEXTMONTH:
				bMatch |= (!bGoodAsDone && pTDI->IsDue(filter.dateDueBy));
				break;
				
			case TDCGT_DONE:
				bMatch |= (bGoodAsDone || bDone);
				break;
				
			case TDCGT_NOTDONE:
				bMatch |= !bGoodAsDone; // 'good as' includes 'done'

				// check 'flagged' flag
				if (!bMatch && (filter.dwFlags & TDCGTF_KEEPFLAGGED) && pTDI->bFlagged) 
					bMatch = TRUE;
				break;
				
			default:
				bMatch = FALSE;
			}

			// then check 'allocated to' if set
			if (bMatch && !filter.sAllocTo.IsEmpty())
				bMatch = (Misc::Find(pTDI->aAllocTo, filter.sAllocTo) != -1);

			// check selected
			if (bMatch && bWantSelected)
				bMatch = Selection().IsItemSelected(hti, TRUE);
		}
		
		// if we don't match, we remove the item unless we're flagged
		if (!bMatch)
			file.DeleteTask(hTask);
		
		return bMatch;
	}
	
	return FALSE;
}

void CToDoCtrl::OnGotoFileRef()
{
	if (!m_sFileRefPath.IsEmpty())
		GotoFile(m_sFileRefPath, TRUE);
}

void CToDoCtrl::SetFocusToTasks()
{
	if (GetFocus() != &m_tree)
		m_tree.SetFocus();

	// ensure the selected tree item is visible
	if (GetSelectedCount())
		m_tree.TCH().EnsureVisibleEx(m_tree.GetSelectedItem(), FALSE);
	else
		SelectItem(m_tree.GetChildItem(NULL));

	m_tree.RedrawGutter();
}

void CToDoCtrl::SetFocusToComments()
{
	// fail if comments are not visible
	if (!::IsWindowVisible(m_ctrlComments))
		return;

	::SetFocus(m_ctrlComments);
}

LRESULT CToDoCtrl::OnDropFileRef(WPARAM wParam, LPARAM lParam)
{
	if (IsReadOnly())
		return 0;
	
	HTREEITEM hti = (HTREEITEM)wParam;
	
	if (hti)
	{
		SelectItem(hti);
		SetSelectedTaskFileRef((LPCTSTR)lParam);
	}
	else // its the file ref edit field
	{
		m_eFileRef.SetWindowText((LPCTSTR)lParam);
	}
	
	return 0;
}

void CToDoCtrl::SaveSortState(CPreferences& prefs)
{
	// ignore this if we have no tasks
	if (GetTaskCount() == 0)
		return;
	
	// create a new key using the filepath
	ASSERT (GetSafeHwnd());
	
	CString sKey = GetPreferencesKey("SortState");
	
	if (!sKey.IsEmpty())
	{
		prefs.WriteProfileInt(sKey, "Multi", m_bMultiSort);
		prefs.WriteProfileInt(sKey, "Column", m_sort.nBy1);
		prefs.WriteProfileInt(sKey, "Column2", m_sort.nBy2);
		prefs.WriteProfileInt(sKey, "Column3", m_sort.nBy3);
		prefs.WriteProfileInt(sKey, "Ascending", m_sort.bAscending1);
		prefs.WriteProfileInt(sKey, "Ascending2", m_sort.bAscending2);
		prefs.WriteProfileInt(sKey, "Ascending3", m_sort.bAscending3);
	}
}

CString CToDoCtrl::GetPreferencesKey(LPCTSTR szSubKey, LPCTSTR szFilePath) const
{
	CString sFilePath(szFilePath), sKey;
	
	if (sFilePath.IsEmpty())
		sFilePath = m_sLastSavePath;
	
	if (sFilePath.IsEmpty())
		sFilePath = "Default";
	else
		sFilePath = CPreferences::KeyFromFile(sFilePath);
	
	if (szSubKey && *szSubKey)
		sKey.Format("FileStates\\%s\\%s", sFilePath, szSubKey);
	else
		sKey.Format("FileStates\\%s", sFilePath);
	
	return sKey;
}

void CToDoCtrl::LoadSortState(const CPreferences& prefs, LPCTSTR szFilePath)
{
	CString sKey = GetPreferencesKey("SortState", szFilePath);
	
	if (!sKey.IsEmpty())
	{
		TDC_SORTBY nDefSort = TDC_UNSORTED;

		m_bMultiSort = prefs.GetProfileInt(sKey, "Multi", FALSE);
		m_sort.nBy1 = (TDC_SORTBY)prefs.GetProfileInt(sKey, "Column", nDefSort);
		m_sort.nBy2 = (TDC_SORTBY)prefs.GetProfileInt(sKey, "Column2", TDC_UNSORTED);
		m_sort.nBy3 = (TDC_SORTBY)prefs.GetProfileInt(sKey, "Column3", TDC_UNSORTED);
		m_sort.bAscending1 = prefs.GetProfileInt(sKey, "Ascending", TRUE);
		m_sort.bAscending2 = prefs.GetProfileInt(sKey, "Ascending2", TRUE);
		m_sort.bAscending3 = prefs.GetProfileInt(sKey, "Ascending3", TRUE);

		// backward compatibility
		m_sort.nBy1 = max(m_sort.nBy1, TDC_UNSORTED);
	}
}

void CToDoCtrl::SaveSplitPos(CPreferences& prefs)
{
	ASSERT (GetSafeHwnd());
	
	CString sKey = GetPreferencesKey(); // no subkey
	
	if (!sKey.IsEmpty())
		prefs.WriteProfileInt(sKey, "SplitPos", m_nCommentsSize);

	if (HasStyle(TDCS_SHAREDCOMMENTSHEIGHT))
		prefs.WriteProfileInt("FileStates", "SharedSplitPos", s_nCommentsSize);
}

void CToDoCtrl::LoadSplitPos(const CPreferences& prefs)
{
	s_nCommentsSize = prefs.GetProfileInt("FileStates", "SharedSplitPos", DEFCOMMENTSIZE);

	CString sKey = GetPreferencesKey(); // no subkey
	
	if (!sKey.IsEmpty())
		m_nCommentsSize = prefs.GetProfileInt(sKey, "SplitPos", DEFCOMMENTSIZE);
	else
		m_nCommentsSize = s_nCommentsSize;
}

void CToDoCtrl::SaveExpandedState(CPreferences& prefs)
{
	ASSERT (GetSafeHwnd());
	
	// ignore this if we have no tasks
	if (GetTaskCount() == 0)
		return;
	
	// create a new key using the filepath and simply save the ID 
	// of every expanded item
	CString sKey = GetPreferencesKey("ExpandedState");
	
	if (!sKey.IsEmpty())
	{
		int nCount = SaveTreeExpandedState(prefs, sKey);
		
		// save expanded count
		prefs.WriteProfileInt(sKey, "Count", nCount);
		
		// and selected item
		prefs.WriteProfileInt(sKey, "SelItem", GetSelectedTaskID());
	}
}

HTREEITEM CToDoCtrl::LoadExpandedState(const CPreferences& prefs, BOOL bResetSel)
{
	ASSERT (GetSafeHwnd());
	
	CString sKey = GetPreferencesKey("ExpandedState");
	
	if (!sKey.IsEmpty())
		LoadTreeExpandedState(prefs, sKey);

	// restore prev selected item
	UINT uID = prefs.GetProfileInt(sKey, "SelItem", 0);
	HTREEITEM hti = NULL;
	
	if (uID)
	{
		// find the corresponding tree item
		CHTIMap htiMap;
		CTreeCtrlHelper(m_tree).BuildHTIMap(htiMap);
		
		if (htiMap.Lookup(uID, hti) && hti)
		{
			if (bResetSel)
				SelectItem(hti);
		}
	}
	
	return hti;
}

void CToDoCtrl::LoadTreeExpandedState(const CPreferences& prefs, LPCTSTR szRegKey)
{
	ASSERT (szRegKey && *szRegKey);

	int nCount = prefs.GetProfileInt(szRegKey, "Count", 0);

	if (!nCount)
		return;

	HOLD_REDRAW(*this, m_tree);

	CString sItem;
	CHTIMap map;
	CTreeCtrlHelper(m_tree).BuildHTIMap(map);
	
	while (nCount--)
	{
		sItem.Format("Item%d", nCount);
		
		DWORD dwTaskID = (DWORD)prefs.GetProfileInt(szRegKey, sItem, 0);
		HTREEITEM hti = NULL;
		
		if (dwTaskID && map.Lookup(dwTaskID, hti) && hti)
			m_tree.Expand(hti, TVE_EXPAND);
	}
}

int CToDoCtrl::SaveTreeExpandedState(CPreferences& prefs, LPCTSTR szRegKey, HTREEITEM hti, int nStart)
{
	CTreeCtrlHelper tch(m_tree);
	
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	int nCount = nStart;
	
	while (htiChild)
	{
		if (tch.IsItemExpanded(htiChild) > 0)
		{
			CString sItem;
			sItem.Format("Item%d", nCount);
			
			prefs.WriteProfileInt(szRegKey, sItem, (int)GetTaskID(htiChild));
			nCount++;
			
			// now its children
			nCount += SaveTreeExpandedState(prefs, szRegKey, htiChild, nCount);
		}
		
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}	
	
	return (nCount - nStart);
}


LRESULT CToDoCtrl::OnGutterWidthChange(WPARAM /*wParam*/, LPARAM lParam)
{
	// let parent know if min width has changed
	int nPrevWidth = LOWORD(lParam);
	int nNewWidth = HIWORD(lParam);
	
	if (nNewWidth < nPrevWidth || (!nPrevWidth && nNewWidth))
		GetParent()->SendMessage(WM_TDCN_MINWIDTHCHANGE);
	
	return 0;
}

LRESULT CToDoCtrl::OnGutterGetCursor(WPARAM /*wParam*/, LPARAM lParam)
{
	NCGGETCURSOR* pNCGGC = (NCGGETCURSOR*)lParam;
	HTREEITEM hti = (HTREEITEM)pNCGGC->dwItem;

	switch (pNCGGC->nColID)
	{
	case TDCC_FILEREF:
		// we handle the file ref column if the ctrl key is down
		if (Misc::ModKeysArePressed(MKS_CTRL) && hti)
		{
			DWORD dwUniqueID = GetTaskID(hti);
			TODOITEM* pTDI = GetTask(dwUniqueID);
			
			if (pTDI && !pTDI->sFileRefPath.IsEmpty())
				return (LRESULT)GraphicsMisc::HandCursor();
		}
		break;
		
	case TDCC_DEPENDENCY:
		// we handle the depends column if the ctrl key is down
		if (Misc::ModKeysArePressed(MKS_CTRL) && hti)
		{
			DWORD dwUniqueID = GetTaskID(hti);
			TODOITEM* pTDI = GetTask(dwUniqueID);
			
			if (pTDI && pTDI->aDependencies.GetSize() == 1)
				return (LRESULT)GraphicsMisc::HandCursor();
		}
		break;
		
	case TDCC_TRACKTIME:
		// check tasklist is editable, task is trackable and 
		// neither the ctrl not shift keys are pressed (ie => multiple selection)
		if (Misc::ModKeysArePressed(0) && !IsReadOnly() && m_data.IsTaskTimeTrackable(GetTaskID(hti)))
		{
			return (LRESULT)GraphicsMisc::HandCursor();
		}
		break;

	case TDCC_FLAG:
		if (hti)
			return (LRESULT)GraphicsMisc::HandCursor();
		break;
	}
	
	return 0L;
}

void CToDoCtrl::EndLabelEdit(BOOL bCancel)
{
	m_eLabel.EndEdit(bCancel);
//	m_tree.TCH().EndLabelEdit(bCancel);
}

void CToDoCtrl::Flush(BOOL bEndTimeTracking) // called to end current editing actions
{
	CWnd* pFocus = GetFocus();

	if (pFocus)
	{
		if (pFocus == &m_eLabel)
			EndLabelEdit(FALSE);

		else if (m_cbCategory.IsC