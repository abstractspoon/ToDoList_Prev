or.EnableWindow(m_bSpecifyDoneColor);
	m_btAltLineColor.EnableWindow(m_bAlternateLineColor);
	m_btDueColor.EnableWindow(m_bSpecifyDueColor);
	m_btDueTodayColor.EnableWindow(m_bSpecifyDueTodayColor);
	m_btCatColor.EnableWindow(m_nTextColorOption == COLOROPT_CATEGORY && !m_sSelCategory.IsEmpty());
	m_btFlaggedColor.EnableWindow(m_bSpecifyFlaggedColor);
	
	m_btGridlineColor.SetColor(m_crGridlines);
	m_btLowColor.SetColor(m_crLow);
	m_btHighColor.SetColor(m_crHigh);
	m_btSetColor.SetColor(m_aPriorityColors[0]);
	m_btDoneColor.SetColor(m_crDone);
	m_btAltLineColor.SetColor(m_crAltLine);
	m_btDueColor.SetColor(m_crDue);
	m_btDueTodayColor.SetColor(m_crDueToday);
	m_btFlaggedColor.SetColor(m_crFlagged);

	// category colors
	if (!m_sSelCategory.IsEmpty())
	{
		int nColor = m_aCategoryColors.GetSize();

		while (nColor--)
		{
			const CATCOLOR& cc = m_aCategoryColors[nColor];
			
			if (!cc.sCategory.IsEmpty())
				m_cbCategories.AddString(cc.sCategory);
		}

	