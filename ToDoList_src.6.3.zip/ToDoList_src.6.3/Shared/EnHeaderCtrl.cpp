(Selection().GetCount())
	{
		POSITION pos = Selection().GetFirstItemPos();
		
		while (pos)
		{
			HTREEITEM hti = Selection().GetNextItem(pos);
			m_tree.TCH().ExpandItem(hti, bExpand);
		}
	}
	else
		m_tree.TCH().ExpandItem(NULL, bExpand);
}

BOOL CToDoCtrl::CanExpandSelectedTask(BOOL bExpand) const
{
	if (Selection().GetCount() == 0)
		return FALSE;
	
	if (bExpand)
		return !Selection().IsSelectionExpanded(TRUE);

	// else test for collapsibility
	return (Selection().IsSelectionExpanded(FALSE) > 0);
}

LRESULT CToDoCtrl::OnTDCHasClipboard(WPARAM /*wParam*/, LPARAM lParam)
{
	if (!lParam || s_clipboard.hwndToDoCtrl == *this)
		return !IsClipboardEmpty();

	return 0;
}

LRESULT CToDoCtrl::OnTDCGetClipboard(WPARAM /*wParam*/, LPARAM lParam)
{
	if (!lParam || s_clipboard.hwndToDoCtrl == *this)
		return (LRESULT)&s_clipboard.tasks;

	// else
	return NULL;
}

LRESULT CToDoCtrl::OnTDCDoTaskLink(WPARAM wParam, LPARAM lParam)
{
	ShowTaskLink(wParam, (LPCTSTR)lParam);

	return 0;
}

BOOL CToDoCtrl::AdjustTaskDates(DWORD dwTaskID, DWORD dwDependencyID)
{
	TODOITEM* pTDI = GetTask(dwTaskID);
	TODOITEM* pTDIDepends = GetTask(dwDependencyID);
	
	if (!pTDI || !pTDIDepends)
		return FALSE;
	
	// don't bother fixing tasks that are already completed
	if (!pTDI->IsDone())
	{
		COleDateTime dtNewStart;
		
		// make the start dates match the preceding task's end date 
		// or it's due date if it's not yet finished
		if (pTDIDepends->IsDone())
			dtNewStart = pTDIDepends->dateDone.m_dt + 1;
		
// 		else if (pTDIDepends->HasDue())
// 			dtNewStart = pTDIDepends->dateDue.m_dt + 1;

		if (dtNewStart > pTDI->dateStart)
		{
			// bump the due date too if present
			if (pTDI->HasDue() && pTDI->HasStart())
			{
				double dLength = max(0, pTDI->dateDue - pTDI->dateStart);
				pTDI->dateDue.m_dt = dtNewStart.m_dt + dLength;
			}
			
			// always set the start date
			pTDI->dateStart = dtNewStart;

			return TRUE;
		}
	}

	// no change
	return FALSE;
}

void CToDoCtrl::FixupTaskDependentsDates(DWORD dwTaskID)
{
	ASSERT (HasStyle(TDCS_AUTOADJUSTDEPENDENTS));
	CDWordArray aDependents;

	// check for circular dependency before continuing
	if (m_data.TaskHasCircularDependencies(dwTaskID))
		return;
	
	if (m_data.GetTaskDependents(dwTaskID, aDependents))
	{
		for (int nLink = 0; nLink < aDependents.GetSize(); nLink++)
		{
			DWORD dwIDDependent = aDependents[nLink];
			
			if (AdjustTaskDates(dwIDDependent, dwTaskID))
			{
				// then process this task's dependents
				FixupTaskDependentsDates(dwIDDependent);
			}
		}
	}
}

BOOL CToDoCtrl::ShowTaskLink(DWORD dwTaskID, LPCTSTR szLink)
{
	CString sFile;

	ParseTaskLink(szLink, dwTaskID, sFile);

	// if there's a file attached then pass to parent because
	// we can't handle it.
	if (!sFile.IsEmpty())
		return GetParent()->SendMessage(WM_TDCM_TASKLINK, dwTaskID, (LPARAM)(LPCTSTR)sFile);

	else if (dwTaskID)
	{
		if (SelectTask(dwTaskID))
		{
			SetFocusToTasks();
			return TRUE;
		}
		else
			MessageBoxEx(this, CEnString(IDS_TDC_TASKIDNOTFOUND, dwTaskID), IDS_TDC_TASKIDNOTFOUND_TITLE);
	}
	else
		MessageBoxEx(this, IDS_TDC_ZEROINVALIDTASKID, IDS_TDC_ZEROINVALIDTASKID_TITLE);

	return FALSE;
}

void CToDoCtrl::ParseTaskLink(LPCTSTR szLink, DWORD& dwTaskID, CString& sFile)
{
	CString sLink(szLink);

	// strip off protocol (if not done)
	int nProtocol = sLink.Find(TDL_PROTOCOL);

	if (nProtocol != -1)
		sLink = sLink.Mid(nProtocol + strlen(TDL_PROTOCOL));

	// cleanup
	sLink.Replace("%20", " ");
	sLink.Replace("/", "\\");

	// parse the url
	TODOITEM::ParseTaskLink(sLink, dwTaskID, sFile);
}

BOOL CToDoCtr