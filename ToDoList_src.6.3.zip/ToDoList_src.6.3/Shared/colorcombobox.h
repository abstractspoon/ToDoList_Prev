/* ==========================================================================
	File :			FontComboBox.cpp

	Class :			CFontComboBox

	Author :		Johan Rosengren, Abstrakt Mekanik AB
					Iain Clarke

	Date :			2005-05-06

	Purpose :		CFontComboBox is derived from "CComboBox" and is an 
					autosizing no-frills combobox for display of the fonts 
					installed in the system.. 

	Description :	Simpel derived class with members to fill the box, to 
					autosize the dropdown and select an entry by name.

	Usage :			Create as any combobox, and call "FillCombo" to fill 
					the control with the names of the fonts installed in 
					the system. Call "SelectFontName" to select a font by 
					name.

   ========================================================================*/

#include "stdafx.h"
#include "FontComboBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Enumeration callback function for 
// installed fonts
BOOL CALLBACK EnumFontProc( LPLOGFONT lplf, LPTEXTMETRIC /*lptm*/, DWORD /*dwType*/, LPARAM lpData )	
{	
	CFontComboBox *caller = reinterpret_cast< CFontComboBox* > ( lpData );		
	caller->AddString( lplf->lfFaceName );

	CClientDC dc( caller );
	dc.SelectStockObject( ANSI_VAR_FONT );

	// Add a "0" for the margin.
	CSize sz = dc.GetTextExtent( CString( lplf->lfFaceName ) + CString( "0" ) );

	caller->SetMaxWidth( max( caller->