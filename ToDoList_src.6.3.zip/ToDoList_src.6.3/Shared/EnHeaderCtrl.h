ompleteDependencies(hti, sIncomplete))
			return TRUE;
	}

	return FALSE;
}

int CToDoCtrl::GetSelectionRecurringTaskCount() const
{
	int nRecurring = 0;

	const CTreeSelectionHelper& selection = Selection();
	POSITION pos = selection.GetFirstItemPos();

	// traverse the selected items looking for the first one
	// who has an incomplete dependent.
	while (pos)
	{
		HTREEITEM hti = selection.GetNextItem(pos);
		DWORD dwTaskID = GetTaskID(hti);
		COleDateTime dtNext;
		
		if (m_data.GetTaskNextOccurrence(dwTaskID, dtNext))
			nRecurring++;
	}

	return nRecurring;
}

BOOL CToDoCtrl::SelectionHasDates(TDC_DATE nDate, BOOL bAll) const
{
	const CTreeSelectionHelper& selection = Selection();
	POSITION pos = selection.GetFirstItemPos();

	// traverse the selected items looking for the first one
	// who has a due date or the first that doesn't
	while (pos)
	{
		HTREEITEM hti = selection.GetNextItem(pos);
		double dDate = m_data.GetTaskDate(GetTaskID(hti), nDate);

		if (!bAll && dDate > 0)
			return TRUE;
		
		else if (bAll && dDate == 0)
			return FALSE;
	}

	return bAll; // there were no dissenting tasks
}

int CToDoCtrl::SelectionHasCircularDependencies(CDWordArray& aTaskIDs) const
{
	const CTreeSelectionHelper& selection = Selection();
	POSITION pos = selection.GetFirstItemPos();
	aTaskIDs.RemoveAll();

	// traverse the selected items looking for the first one
	// who has an incomplete dependent.
	while (pos)
	{
		HTREEITEM hti = selection.GetNextItem(pos);
		DWORD dwTaskID = GetTaskID(hti);

		if (m_data.TaskHasCircularDependencies(dwTaskID))
		{
			aTaskIDs.Add(dwTask