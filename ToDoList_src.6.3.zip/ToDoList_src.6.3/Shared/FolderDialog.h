TSFONTSIZELABEL)->EnableWindow(m_bSpecifyCommentsFont && !bCommentsUseTreeFont);
	GetDlgItem(IDC_COMMENTSFONTLIST)->EnableWindow(m_bSpecifyCommentsFont && !bCommentsUseTreeFont);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesUITasklistColorsPage::OnSpecifycommentsfont() 
{
	UpdateData();
	
	BOOL bCommentsUseTreeFont = (m_bCommentsUseTreeFont && m_bSpecifyTreeFont);
	GetDlgItem(IDC_COMMENTSFONTSIZE)->EnableWindow(m_bSpecifyCommentsFont && !bCommentsUseTreeFont);
	GetDlgItem(IDC_COMMENTSFONTSIZELABEL)->EnableWindow(m_bSpecifyCommentsFont && !bCommentsUseTreeFont);
	GetDlgItem(IDC_COMMENTSFONTLIST)->EnableWindow(m_bSpecifyCommentsFont && !bCommentsUseTreeFont);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesUITasklistColorsPage::OnDuetaskcolor() 
{
	UpdateData();	
	
	m_btDueColor.EnableWindow(m_bSpecifyDueColor);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesUITasklistColorsPage::OnDuetodaytaskcolor() 
{
	UpdateData();	
	
	m_btDueTodayColor.EnableWindow(m_bSpecifyDueTodayColor);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesUITasklistColorsPage::OnSetduetaskcolor() 
{
	m_crDue = m_btDueColor.GetColor();

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesUITasklistColorsPage::OnSetduetodaytaskcolor() 
{
	m_crDueToday = m_btDueTodayColor.GetColor();

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesUITasklistColorsPage::DeleteCategory(LPCTSTR szCategory)
{
	int nCat = FindCategoryColor(szCategory);
	
	if (nCat != -1)
	{
		m_aCategoryColors.RemoveAt(nCat);

		// do we need to update the combo
		if (m_cbCategories.GetSafeHwnd())
			m_cbCategories.DeleteString(szCategory);

		CPreferencesPageBase::OnControlChange();
	}
}

void CPreferencesUITasklistColorsPage::AddCategory(LPCTSTR szCategory)
{
	if (szCategory && *szCategory && FindCategoryColor(szCategory) == -1)
	{
		CATCOLOR cc;
		cc.sCategory = szCategory;
		cc.color = 0;
		
		m_aCategoryColors.Add(cc);

		// do we need to update the combo
		if (m_cbCategories.GetSafeHwnd())
			m_cbCategories.AddString(szCategory);

		CPreferencesPageBase::OnControlChange();
	}
}

void CPreferencesUITasklistColorsPage::LoadPreferences(const CPreferences& prefs)
{
	m_crLow = prefs.GetProfileInt("Preferences\\Colors", "Low", PRIORITYLOWCOLOR);
	m_crHigh = prefs.GetProfileInt("Preferences\\Colors", "High", PRIORITYHIGHCOLOR);

	m_aPriorityColors.Add(prefs.GetProfileInt("Preferences\\Colors", "P0", RGB(30, 225, 0)));
	m_aPriorityColors.Add(prefs.GetProfileInt("Preferences\\Colors", "P1", RGB(30, 225, 0)));
	m_aPriorityColors.Add(prefs.GetProfileInt("Preferences\\Colors", "P2", RGB(30, 225, 0)));
	m_aPriorityColors.Add(prefs.GetProfileInt("Preferences\\Colors", "P3", RGB(30, 225, 0)));
	m_aPriorityColors.Add(prefs.GetProfileInt("Preferences\\Colors", "P4", RGB(0, 0, 255)));
	m_aPriorityColors.Add(prefs.GetProfileInt("Preferences\\Colors", "P5", RGB(0, 0, 255)));
	m_aPriorityColors.Add(prefs.GetProfileInt("Preferences\\Colors", "P6", RGB(0, 0, 255)));
	m_aPriorityColors.Add(prefs.GetProfileInt("Preferences\\Colors", "P7", RGB(0, 0, 255)));
	m_aPriorityColo