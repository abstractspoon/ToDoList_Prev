// UIThemeFile.cpp: implementation of the CUIThemeFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "UIThemeFile.h"
#include "xmlfile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CUIThemeFile::CUIThemeFile()
{
	Reset();
}

CUIThemeFile::~CUIThemeFile()
{

}

BOOL CUIThemeFile::LoadThemeFile(LPCTSTR szThemeFile)
{
	CXmlFile xiFile;

	if (!xiFile.Load(szThemeFile, _T("TODOLIST")))
		return FALSE;

	if (!xiFile.GetItem(_T("UITHEME")))
		return FALSE;

	// else
	nStyle = GetStyle(xiFile);

	crAppBackDark = GetColor(xiFile, _T("APPBACKDARK"));
	crAppBackLight = GetColor(xiFile, _T("APPBACKLIGHT"));
	crAppLinesDark = GetColor(xiFile, _T("APPLINESDARK"), COLOR_3DSHADOW);
	crAppLinesLight = GetColor(xiFile, _T("APPLINESLIGHT"), COLOR_3DHIGHLIGHT);
	crAppText = GetColor(xiFile, _T("APPTEXT"), COLOR_WINDOWTEXT);
	crMenuBack = GetColor(xiFile, _T("MENUBACK"), COLOR_3DFACE);
	crToolbarDark = GetColor(xiFile, _T("TOOLBARDARK"));
	crToolbarLight = GetColor(xiFile, _T("TOOLBARLIGHT"));
	crStatusBarDark = GetColor(xiFile, _T("STATUSBARDARK"));
	crStatusBarLight = GetColor(xiFile, _T("STATUSBARLIGHT"));
	crStatusBarText = GetColor(xiFile, _T("STATUSBARTEXT"), COLOR_WINDOWTEXT);

	return TRUE;
}

void CUIThemeFile::Reset()
{
	nStyle = UIS_GRADIENT;

	crAppBackDark = GetSysColor(COLOR_3DFACE);
	crAppBackLight = GetSysColor(COLOR_3DFACE);
	crAppLinesDark = GetSysColor(COLOR_3DSHADOW);
	crAppLinesLight = GetSysColor(COLOR_3DHIGHLIGHT);
	crAppText = GetSysColor(COLOR_WINDOWTEXT);
	crMenuBack = GetSysColor(COLOR_3DFACE);
	crToolbarDark = GetSysColor(COLOR_3DFACE);
	crToolbarLight = GetSysColor(COLOR_3DFACE);
	crStatusBarDark = GetSysColor(COLOR_3DFACE);
	crStatusBarLight = GetSysColor(COLOR_3DFACE);
	crStatusBarText = GetSysColor(COLOR_WINDOWTEXT);
}

COLORREF CUIThemeFile::GetColor(const CXmlFile& xiFile, LPCTSTR szName, int nColorID)
{
	const CXmlItem* pXIName = xiFile.FindItem(_T("NAME"), szName);

	if (!pXIName)
	{
		if (nColorID != -1)
			return GetSysColor(nColorID);
		else
			return UIT_NOCOLOR;
	}

	const CXmlItem* pXIColor = pXIName->GetParent();
	ASSERT(pXIColor);

	BYTE bRed = (BYTE)pXIColor->GetItemValueI(_T("R"));
	BYTE bGreen = (BYTE)pXIColor->GetItemValueI(_T("G"));
	BYTE bBlue = (BYTE)pXIColor->GetItemValueI(_T("B"));

	return RGB(bRed, bGreen, bBlue);
}

UI_STYLE CUIThemeFile::GetStyle(const CXmlFile& xiFile)
{
	const CXmlItem* pXITheme = xiFile.GetItem(_T("UITHEME"));
	ASSERT (pXITheme);

	if (!pXITheme)
		return UIS_GRADIENT;

	CString sStyle = pXITheme->GetItemValue(_T("STYLE"));

	if (sStyle == _T("GLASS"))
		return UIS_GLASS;

	else if (sStyle == _T("GLASSWITHGRADIENT"))
		return UIS_GLASSWITHGRADIENT;

	// else
	return UIS_GRADIENT;
}
