// PreferencesUITasklistColorsPage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesUITasklistColorsPage.h"

#include "..\shared\colordef.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUITasklistColorsPage property page

// default priority colors
const COLORREF PRIORITYLOWCOLOR = RGB(30, 225, 0);
const COLORREF PRIORITYHIGHCOLOR = RGB(255, 0, 0);
const COLORREF CBMASKCOLOR = RGB(255, 0, 0);
const COLORREF ALTERNATELINECOLOR = RGB(230, 230, 255);
const COLORREF GRIDLINECOLOR = RGB(192, 192, 192);
const COLORREF TASKDONECOLOR = RGB(128, 128, 128);
const COLORREF TASKDUECOLOR = RGB(255, 0, 0);
const COLORREF FILTEREDCOLOR = RGB(200, 200, 200);
const COLORREF FLAGGEDCOLOR = (COLORREF)-1;

IMPLEMENT_DYNCREATE(CPreferencesUITasklistColorsPage, CPreferencesPageBase)

CPreferencesUITasklistColorsPage::CPreferencesUITasklistColorsPage() : 
	CPreferencesPageBase(CPreferencesUITasklistColorsPage::IDD),
	m_nTextColorOption(COLOROPT_DEFAULT), m_cbCategories(TRUE)

{
	//{{AFX_DATA_INIT(CPreferencesUITasklistColorsPage)
	//}}AFX_DATA_INIT
	// priority colors
	m_nSelPriorityColor = 0; 
}

CPreferencesUITasklistColorsPage::~CPreferencesUITasklistColors