///

#define WC_STATUSBARA              "msctls_statusbar32"	// ansi
#define WC_STATUSBARW              L"msctls_statusbar32"	// wide

#ifdef UNICODE
#define WC_STATUSBAR               WC_STATUSBARW
#else
#define WC_STATUSBAR               WC_STATUSBARA
#endif

//////////////////////////

#define WC_ANIMATEA              "SysAnimate32"	// ansi
#define WC_ANIMATEW              L"SysAnimate32"	// wide

#ifdef UNICODE
#define WC_ANIMATE               WC_ANIMATEW
#else
#define WC_ANIMATE               WC_ANIMATEA
#endif

//////////////////////////

#define WC_RICHEDITA              "Richedit"	// ansi
#define WC_RICHEDITW              L"Richedit"	// wide

#ifdef UNICODE
#define WC_RICHEDIT               WC_RICHEDITW
#else
#define WC_RICHEDIT               WC_RICHEDITA
#endif

//////////////////////////

#define WC_RICHEDIT20A              "RichEdit20A"	// ansi
#define WC_RICHEDIT20W              L"RichEdit20W"	// wide

#ifdef UNICODE
#define WC_RICHEDIT20               WC_RICHEDIT20W
#else
#define WC_RICHEDIT20               WC_RICHEDIT20A
#endif

//////////////////////////

#define WC_RICHEDIT50A              "RichEdit50W"	// ansi
#define WC_RICHEDIT50W              L"RichEdit50W"	// wide

#ifdef UNICODE
#define WC_RICHEDIT50               WC_RICHEDIT50W
#else
#define WC_RICHEDIT50               WC_RICHEDIT50A
#endif

//////////////////////////

#define WC_DATETIMEPICKA              "SysDateTimePick32"	// ansi
#define WC_DATETIMEPICKW              L"SysDateTimePick32"	// wide

#ifdef UNICODE
#define WC_DATETIMEPICK               WC_DATETIMEPICKW
#else
#define WC_DATETIMEPICK               WC_DATETIMEPICKA
#endif

//////////////////////////

#define WC_MONTHCALA              "SysMonthCal32"	// ansi
#define WC_MONTHCALW              L