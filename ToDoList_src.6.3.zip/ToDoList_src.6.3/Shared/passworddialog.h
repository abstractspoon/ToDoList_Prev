etReadOnly, TRUE);
// 
// 	return DefWindowProc(EM_SETREADONLY, TRUE, 0);
// }
// 
// void CTDLRecurringTaskEdit::OnStyleChanging(int nStyleType, LPSTYLESTRUCT lpStyleStruct)
// {
// 	CEnEdit::OnStyleChanging(nStyleType, lpStyleStruct);
// 
// 	if (nStyleType == GWL_STYLE && !m_bInOnSetReadOnly)
// 	{
// 		// check for change in readonly style
// 		if ((lpStyleStruct->styleOld & ES_READONLY) != (lpStyleStruct->styleNew & ES_READONLY))
// 		{
// 			m_bReadOnly = (lpStyleStruct->styleNew & ES_READONLY);
// 			lpStyleStruct->styleNew |= ES_READONLY; // make sure we stay readonly
// 
// 			EnableButton(REBTN_OPTIONS, !m_bReadOnly);
// 			Invalidate();
// 		}
// 	}
// }

CString CTDLRecurringTaskEdit::GetRegularity(const TDIRECURRENCE& tr, BOOL bIncOnce)
{
	if (tr.sRegularity.IsEmpty())
		return GetRegularity(tr.nRegularity, bIncOnce);
	
	// else
	return tr.sRegularity;
}

CString CTDLRecurringTaskEdit::GetRegularity(TDI_REGULARITY nRegularity, BOOL bIncOnce)
{
	CString sRegularity;

	switch (nRegularity)
	{
	case TDIR_ONCE:    
		if (bIncOnce)
			sRegularity.LoadString(IDS_ONCEONLY); 
		break;

	case TDIR_DAILY:   sRegularity.LoadString(IDS_DAILY);    break;
	case TDIR_WEEKLY:  sRegularity.LoadString(IDS_WEEKLY);   break;
	case TDIR_MONTHLY: sRegularity.LoadString(IDS_MONTHLY);  break;
	case TDIR_YEARLY:  sRegularity.LoadString(IDS_YEARLY);   break;
	}

	return sRegularity;
}

BOOL CTDLRecurringTaskEdit::IsDefaultString(const CString& sRegularity)
{
	int nReg = (int)TDIR_YEARLY + 1;

	while (nReg--)
	{
		if (sRegularity.CompareNoCase(GetRegularity((TDI_REGULARITY)nReg, TRUE)) == 0)
			return TRUE;
	}

	// else
	return FALSE;
}

int CTDLRecurringTaskEdit::CalcMaxRegularityWidth(CDC* pDC, BOOL bIncOnce)
{
	int nReg = (int)TDIR_YEARLY + 1;
	int nMax = 0;

	while (nReg--)
	{
		CString sRegularity = GetRegularity((TDI_REGULARITY)nReg, bIncOnce);
		int nItem = pDC->GetTextExtent(sRegularity).cx;
		nMax = max(nItem, nMax);
	}

	return nMax;
}

/*
int CTDLRecurringTaskEdit::CalcRegularityWidth(CDC* pDC, TDI_REGULARITY nRegularity, const CString& sRegularity, BOOL bIncOnce)
{
	int nMax = 0;

	if (sRegularity.IsEmpty())
		nMax = CalcMaxRegularityWidth(pDC, bIncOnce);
	else 