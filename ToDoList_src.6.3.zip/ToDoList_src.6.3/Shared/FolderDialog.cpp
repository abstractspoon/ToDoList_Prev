
			}
			else // RGB Gradient
			{
				BYTE redLow = GetRValue(m_crLow);
				BYTE greenLow = GetGValue(m_crLow);
				BYTE blueLow = GetBValue(m_crLow);

				BYTE redHigh = GetRValue(m_crHigh);
				BYTE greenHigh = GetGValue(m_crHigh);
				BYTE blueHigh = GetBValue(m_crHigh);

				for (int nPriority = 1; nPriority <= 10; nPriority++) // m_aPriorityColors[0] added at top
				{
					double dRed = (redLow * (10 - nPriority) / 10) + (redHigh * nPriority / 10);
					double dGreen = (greenLow * (10 - nPriority) / 10) + (greenHigh * nPriority / 10);
					double dBlue = (blueLow * (10 - nPriority) / 10) + (blueHigh * nPriority / 10);

					double dColor = dRed + (dGreen * 256) + (dBlue * 256 * 256);

					aColors.Add((DWORD)min(RGB(255, 255, 255), (COLORREF)(int)dColor));
				}
			}
		}
	}
	else
	{
		// grayscale
		aColors.Add(RGB(240, 240, 240));	// 0
		aColors.Add(RGB(216, 216, 216));	// 1
		aColors.Add(RGB(192, 192, 192));	// 2
		aColors.Add(RGB(168, 168, 168));	// 3
		aColors.Add(RGB(144, 144, 144));	// 4
		aColors.Add(RGB(120, 120, 120));	// 5
		aColors.Add(RGB(96, 96, 96));		// 6
		aColors.Add(RGB(72, 72, 72));		// 7
		aColors.Add(RGB(48, 48, 48));		// 8
		aColors.Add(RGB(24, 24, 24));		// 9
		aColors.Add(0);						// 10
	}
	
	return aColors.GetSize(); 
}

void CPreferencesUITasklistColorsPage::GetDueTaskColors(COLORREF& crDue, COLORREF& crDueToday) const 
{ 
	crDue = m_bSpecifyDueColor ? m_crDue : -1; 
	crDueToday = m_bSpecifyDueTodayColor ? m_crDueToday : -1; 
}

int CPreferencesUITasklistColorsPage::GetCategoryColors(CCatColorArray& aColors) const
{
	aColors.Copy(m_aCategoryColors);

	return aColors.GetSize();
}

void CPreferencesUITasklistColorsPage::OnSelchangePrioritycolors() 
{
	UpdateData();

	ASSERT (m_nSelPriorityColor >= 0);
	
	if (m_nSelPriorityColor >= 0)
	{
		m_btSetColor.SetColor(m_aPriorityColors[m_nSelPriorityColor]);
		m_btSetColor.EnableWindow(TRUE);
	}
	else
		m_btSetColor.EnableWindow(FALSE);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesUITasklistColorsPage::OnSpecifytreefont() 
{
	UpdateData();

	GetDlgItem(IDC_TREEFONTLIST)->EnableWindow(m_bSpecifyTreeFont);
	GetDlgItem(IDC_TREEFONTSIZE)->EnableWindow(m_bSpecifyTreeFont);
	GetDlgItem(IDC_TREEFONTSIZELABEL)->EnableWindow(m_bSpecifyTreeFont);
	GetDlgItem(IDC_COMMENTSUSETREEFONT)->EnableWindow(m_bSpecifyTreeFont);

	GetDlgItem(IDC_SPECIFYCOMMENTSFONT)->EnableWindow(!m_bCommentsUseTreeFont || !m_bSpecifyTreeFont);
	GetDlgItem(IDC_COMMENTSFONTSIZE)->EnableWindow(m_bSpecifyCommentsFont && !m_bCommentsUseTreeFont);
	GetDlgItem(IDC_COMMENTSFONTSIZELABEL)->EnableWindow(m_bSpecifyCommentsFont && !m_bCommentsUseTreeFont);
	GetDlgItem(IDC_COMMENTSFONTLIST)->EnableWindow(m_bSpecifyCommentsFont && !m_bCommentsUseTreeFont);

//	if (m_bSpecifyTreeFont)
//		m_cbTreeFonts.SetSelectedFont(m_sTreeFont);

	CPreferencesPageBase::OnControlChange();
}

BOOL CPreferencesUITasklistColorsPage::GetTreeFont(CString& sFaceName, int& nPointSize) const
{
	if (m_bSpecifyTreeFont)
	{
		sFaceName = m_sTreeFont;
		nPointSize = m_nTreeFontSize;
	}

	return m_bSpecifyTreeFont;
}

BOOL CPreferencesUITasklistColorsPage::GetCommentsFont(CString& sFaceName, int& nPointSize) const
{
	if ((m_bSpecifyTreeFont && m_bCommentsUseTreeFont) || !m_bSpecifyCommentsFont)
		return FALSE;

	sFaceName = m_sCommentsFont;
	nPointSize = m_nCommentsFontSize;

	return m_bSpecifyCommentsFont;
}

void CPreferencesUITasklistColorsPage::OnSetgridlinecolor() 
{
	m_crGridlines = m_btGridlineColor.GetColor();

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesUITasklistColorsPage::OnSpecifygridlinecolor() 
{
	UpdateData();	

	m_btGridlineColor.EnableWindow(m_bSpecifyGridColor);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesUITasklistColorsPage::OnSetdonecolor() 
{
	m_crDone = m_btDoneColor.GetColor();

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesUITasklistColorsPage::OnSetflaggedcolor() 
{
	m_crFlagged = m_btFlaggedColor.GetColor();

	CPreferencesPageBase::O