#if !defined(AFX_PREFERENCESUITASKLISTCOLORSPAGE_H__9612D6FB_2A00_46DA_99A4_1AC6270F060D__INCLUDED_)
#define AFX_PREFERENCESUITASKLISTCOLORSPAGE_H__9612D6FB_2A00_46DA_99A4_1AC6270F060D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesUITasklistPageColors.h : header file
//

#include "..\shared\fileedit.h"
#include "..\shared\colorbutton.h"
#include "..\3rdparty\fontcombobox.h"
#include "..\shared\autocombobox.h"
#include "..\shared\preferencesbase.h"
#include "..\shared\groupline.h"

#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUITasklistColorsPage dialog

enum { COLOROPT_CATEGORY, COLOROPT_PRIORITY, COLOROPT_DEFAULT, COLOROPT_NONE };

struct CATCOLOR
{
	CString sCategory;
	COLORREF color;
};

const UINT WM_PUITCP_CATEGORYCHANGE = ::RegisterWindowMessage("WM_PUITCP_CATEGORYCHANGE");

typedef CArray<CATCOLOR, CATCOLOR&> CCatColorArray;

class CPreferencesUITasklistColorsPage : public CPreferencesPageBase
{
	DECLARE_DYNCREATE(CPreferencesUITasklistColorsPage)

// Construction
public:
	CPreferencesUITasklistColorsPage();
	~CPreferencesUITasklistColorsPage();

	BOOL GetColorPriority() const { return m_bColorPriority; }
	int GetTextColorOption() const { return m_nTextColorOption; }
	BOOL GetHidePriorityNumber() const { return m_bHidePriorityNumber; }
	int GetPriorityColors(CDWordArray& aColors) const;
	int GetCategoryColors(CCatColorArray& aColors) const;
	BOOL GetTreeFont(CString& sFaceName, int& nPointSize) const;
	BOOL GetCommentsFont(CString& sFaceName, int& nPointSize) const;
	COLORREF GetGridlineColor() const { return m_bSpecifyGridColor ? m_crGridlines : -1; }
	COLORREF GetDoneTaskColor() const { return m_bSpecifyDoneColor ? m_crDone : -1; }
	COLORREF GetAlternateLineColor() const { return m_bAlternateLineColor ? m_crAltLine : -1; }
	void GetDueTaskColors(COLORREF& crDue, COLORREF& crDueToday) const;
	BOOL GetColorTaskBackground() const { return m_bColorTaskBackground; }
	BOOL GetCommentsUseTreeFont() const { return m_bSpecifyTreeFont && m_bCommentsUseTreeFont; }
	COLORREF GetFlaggedTaskColor() const { return m_bSpecifyFlaggedColor ? m_crFlagged : -1; }

	void DeleteCategory(LPCTSTR szCategory);
	void AddCategory(LPCTSTR szCategory);

protected:
// Dialog Data
	//{{AFX_DATA(CPreferencesUITasklistColorsPage)
	enum { IDD = IDD_PREFUITASKLISTCOLORS_PAGE };
	CAutoComboBox	m_cbCategories;
	BOOL	m_bColorTaskBackground;
	BOOL	m_bCommentsUseTreeFont;
	BOOL	m_bHLSColorGradient;
	BOOL	m_bHidePriorityNumber;
	BOOL	m_bAlternateLineColor;
	int		m_nTextColorOption;
	CString	m_sSelCategory;
	BOOL	m_bSpecifyDueColor;
	//}}AFX_DATA
	BOOL	m_bSpecifyDueTodayColor;
	BOOL	m_bSpecifyGridColor;
	BOOL	m_bSpecifyDoneColor;
	BOOL	m_bSpecifyFlaggedColor;
	CColorBu