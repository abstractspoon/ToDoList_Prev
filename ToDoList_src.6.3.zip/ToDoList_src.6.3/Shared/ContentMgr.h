ToolCount", 0);

			if (!nTools)
				bContinue = (AfxMessageBox(IDS_INIHASNOTOOLS, MB_YESNO) == IDYES);
			else
			{
				int nCurCount = m_lcTools.GetItemCount();

				for (int nTool = 0; nTool < nTools; nTool++)
				{
					CString sKey;
					sKey.Format("Tools\\Tool%d", nTool + 1);
					
					CString sName = ini.GetString(sKey, "Name");
					CString sPath = ini.GetString(sKey, "Path");
					CString sIconPath = ini.GetString(sKey, "IconPath");
					BOOL bRunMinimized = ini.GetBool(sKey, "RunMinimized", FALSE);
					CString sCmdline = ini.GetString(sKey, "Cmdline");

					// replace safe quotes with real quotes
					sCmdline.Replace(SAFEQUOTE, REALQUOTE);

					// add tool to list
					int nImage = m_ilSys.GetFileImageIndex(sPath);
					
					if (!sIconPath.IsEmpty()) 
						nImage = m_ilSys.GetFileImageIndex(sIconPath);
						
					int nIndex = m_lcTools.InsertItem(nCurCount + nTool, sName, nImage);

					m_lcTools.SetItemText(nIndex, 1, sPath);
					m_lcTools.SetItemText(nIndex, 2, sCmdline);
					m_lcTools.SetItemText(nIndex, 3, sIconPath);
					m_lcTools.SetItemData(nIndex, bRunMinimized);
				}

				bContinue = FALSE;

				CPreferencesPageBase::OnControlChange();
			}
		}
		else
			bContinue = FALSE; // cancelled
	}
}

void CPreferencesToolPage::LoadPreferences(const CPreferences& prefs)
{
	// load tools
	int nToolCount = prefs.GetProfileInt("Tools", "ToolCount", 0);

	for (int nTool = 1; nTool <= nToolCount; nTool++)
	{
		CString sKey;
		sKey.Format("Tools\\Tool%d", nTool);

		USERTOOL ut;
		ut.sToolName = prefs.GetProfileStri