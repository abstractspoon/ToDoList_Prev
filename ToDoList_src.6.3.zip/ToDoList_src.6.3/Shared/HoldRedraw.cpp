// TaskListCsvExporter.h: interface for the CTaskListCsvExporter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TASKLISTCSVEXPORTER_H__ADF211CB_FBD2_42A2_AD51_DFF58E566753__INCLUDED_)
#define AFX_TASKLISTCSVEXPORTER_H__ADF211CB_FBD2_42A2_AD51_DFF58E566753__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\SHARED\Itasklist.h"
#include "..\SHARED\IImportExport.h"

class CTaskListCsvExporter : public IExportTasklist  
{
public:
	CTaskListCsvExporter();
	virtual ~CTaskListCsvExporter();

	const char* GetMenuText() { return "Spreadsheet"; }
	const char* GetFileFilter() { return "Spreadsheet Files (*.csv)|*.csv||"; }
	const char* GetFileExtension() { return "csv"; }

	bool Export(const ITaskList* pSrcTaskFile, const char* szDestFilePath, BOOL bSilent);
    void Release() { delete this; }

protected:
	BOOL ROUNDTIMEFRACTIONS;
	LPCTSTR DELIM;
	CString INDENT;
	CStringArray m_aAttribs;

protected:
	CString& ExportTask(const ITaskList6* pTasks, HTASKITEM hTask, int nDepth, 
						int nPos, const CString& sParentPos, CString& sOutput) const;
	CString ColumnHeadings() const;

	enum ATTRIBTYPE { AT_TEXT, AT_COST, AT_TIME };

	void AppendAttribute(const ITaskList6* pTasks, HTASKITEM hTask, 
						LPCTSTR szAttribName, LPCTSTR szAltAttribName, 
                        CString& sOutput, ATTRIBTYPE at = AT_TEXT, LPCTSTR szPrefix = NULL) const;

	void AppendAttribute(LPCTSTR szAttrib, CString& sOutput, ATTRIBTYPE at = AT_TEXT, BOOL bForceQuoted = FALSE) const;
	void AppendComments(const ITaskList6* pTasks, HTASKITEM hTask, CString& sOutput) const;

	int BuildAttribList(const ITa