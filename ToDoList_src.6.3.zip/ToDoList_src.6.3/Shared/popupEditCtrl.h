// TaskFile.h: interface for the CTaskFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TASKFILE_H__BA5D71E7_2770_45FD_A693_A2344B589DF4__INCLUDED_)
#define AFX_TASKFILE_H__BA5D71E7_2770_45FD_A693_A2344B589DF4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\SHARED\ITaskList.h"

#include <afxtempl.h>

#ifdef NO_TL_ENCRYPTDECRYPT
#	include "..\SHARED\xmlfile.h"
#	define XMLBASE CXmlFile
#else
#	include "..\SHARED\xmlfileex.h"
#	define XMLBASE CXmlFileEx
#endif

struct TDIRECURRENCE; // predeclaration

class CTaskFile : public ITASKLISTBASE, public XMLBASE
{
public:
	CTaskFile(LPCTSTR szPassword = NULL);
	virtual ~CTaskFile();

	BOOL Load(LPCTSTR szFilePath, IXmlParse* pCallback = NULL, BOOL bDecrypt = TRUE);

	virtual BOOL LoadEx(IXmlParse* pCallback = NULL);
	virtual BOOL SaveEx();
	virtual BOOL LoadHeader(LPCTSTR szFilePath);

#ifndef NO_TL_ENCRYPTDECRYPT
	virtual BOOL Decrypt(LPCTSTR szPassword = NULL); 
#endif

	BOOL Copy(const CTaskFile& tasks);
	BOOL Copy(const ITaskList* pTasks);
	void Reset();

	int GetTaskCount() const { return m_mapHandles.GetCount(); }

#ifndef NO_TL_MERGE
	int Merge(const CTaskFile& tasks, BOOL bByID, BOOL bMoveExist);
	int Merge(LPCTSTR szTaskFilePath, BOOL bByID, BOOL bMoveExist);
#endif

	HTASKITEM NewTask(const char* szTitle, HTASKITEM hParent, DWORD dwID);

	DWORD GetNextUniqueID() const; 
	BOOL SetNextUniqueID(DWORD dwNextID); 

	BOOL SetArchive(BOOL bArchive = TRUE);
	BOOL SetCheckedOutTo(const CString& sCheckedOutTo);
	BOOL SetFileFormat(unsigned long lFormat);
	BOOL SetLastModified(const CString& sLastMod);
//	void SortTasksByID();
	void SortTasksByPos();
	BOOL SetCharSet(LPCTSTR szCharSet);
	BOOL SetFileName(LPCTSTR szFilename);
	
	BOOL SetCategoryNames(const CStringArray& aCategories);
	BOOL SetStatusNames(const CStringArray& aStatuses);
	BOOL SetAllocToNames(const CStringArray& aAllocTo);
	BOOL SetAllocByNames(const CStringArray& aAllocBy);
	BOOL SetVersionNames(const CStringArray& aVersions);
	int GetCategoryNames(CStringArray& aCategories) const;
	int GetStatusNames(CStringArray& aStatuses) const;
	int GetAllocToNames(CStringArray& aAllocTo) const;
	int GetAllocByNames(CStringArray& aAllocBy) const;
	int GetVersionNames(CStringArray& aVersions) const;

	BOOL SetEarliestDueDate(const COleDateTime& date);
	BOOL GetEarliestDueDate(COleDateTime& date) const;

// 	BOOL SetCommentsType(LPCTSTR szID); 
	CString GetCommentsTyp