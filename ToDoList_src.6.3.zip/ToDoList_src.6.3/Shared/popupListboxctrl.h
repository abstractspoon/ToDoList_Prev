em*&> m_mapHandles;
	DWORD m_dwNextUniqueID;
	BOOL m_bISODates;

protected:
	void BuildHandleMap();
	void AddTaskToMap(CXmlItem* pXITask, BOOL bRecurse);
	void RemoveTaskFromMap(CXmlItem* pXITask);
	CXmlItem* TaskFromHandle(HTASKITEM hTask) const;
	
	double GetTaskTime(HTASKITEM hTask, LPCTSTR szTimeItem) const;
	char GetTaskTimeUnits(HTASKITEM hTask, LPCTSTR szUnitsItem) const;
	time_t GetTaskDate(HTASKITEM hTask, LPCTSTR szDateItem, BOOL bIncTime) const;
	COleDateTime GetTaskDateOle(HTASKITEM hTask, LPCTSTR szDateItem, BOOL bIncTime) const;
	unsigned char GetTaskUChar(HTASKITEM hTask, LPCTSTR szUCharItem) const;
	unsigned long GetTaskULong(HTASKITEM hTask, LPCTSTR szULongItem) const;
	int GetTaskInt(HTASKITEM hTask, LPCTSTR szIntItem) const;
	const char* GetTaskCChar(HTASKITEM hTask, LPCTSTR szCCharItem) const;
	double GetTaskDouble(HTASKITEM hTask, LPCTSTR szDoubleItem) const;

	bool SetTaskDate(HTASKITEM hTask, LPCTSTR szDateItem, time_t tVal, BOOL bIncTime);
	bool SetTaskDate(HTASKITEM hTask, LPCTSTR szDateItem, const COleDateTime& tVal, BOOL bIncTime, LPCTSTR szDateStringItem = NULL);
	bool SetTaskUChar(HTASKITEM hTask, LPCTSTR szUCharItem, unsigned char cVal);
	bool SetTaskULong(HTASKITEM hTask, LPCTSTR szULongItem, unsigned long lVal);
	bool SetTaskInt(HTASKITEM hTask, LPCTSTR szIntItem, int iVal);
	bool SetTaskCChar(HTASKITEM hTask, LPCTSTR szCCharItem, const char* szVal, XI_TYPE nType = XIT_ATTRIB);
	bool SetTaskDouble(HTASKITEM hTask, LPCTSTR szDoubleItem, double dVal);
	bool SetTaskTime(HTASKITEM hTask, LPCTSTR szTimeItem, double dTime,
					 LPCTSTR szUnitsItem, char cUnits);

	// for handling arrays at *task* level
	bool AddTaskArrayItem(HTASKITEM hTask, const char* szNumItemTag, 
						  const char* szItemTag, const char* szItem);
	const char* GetTaskArrayItem(HTASKITEM hTask, const char* szNumItemTag, 
				  				 const char* szItemTag, int nIndex) const;
	BOOL SetTaskArray(HTASKITEM hTask, const char* szNumItemTag, 
				  	 const char* szItemTag, const CStringArray& aItems);
	int GetTaskArray(HTASKITEM hTask, const char* szNumItemTag, 
				  	 const char* szItemTag, CStringArray& aItems) const;
	bool DeleteTaskArray(HTASKITEM hTask, const char* szNumItemTag, 
						 const char* szItemTag);

	// for handling arrays at *tasklist* level
	BOOL SetArray(const char* szItemTag, const CStringArray& aItems);
	int GetArray(const char* szItemTag, CStringArray& aItems) const;

	virtual CXmlItem* NewItem(LPCTSTR szName = NULL);
	BOOL CopyTask(HTASKITEM hSrcTask, const ITaskList* pSrcTasks, HTASKITEM hDestParent);

	static CString GetWebColor(COLORREF color);
};

#endif // !defined(AFX_TASKFILE_H__BA5D71E7_2770_45