kIDs, DWORD& dwFocusedTaskID, BOOL bRemoveChildDupes) const
{
	if (!GetSelectedCount())
		return 0;
	
	CHTIList selection;
	
	Selection().CopySelection(selection);

	if (bRemoveChildDupes)
		Selection().RemoveChildDuplicates(selection, m_tree);
	
	TDCGETTASKS filter(TDCGT_ALL, 0);
	POSITION pos = selection.GetHeadPosition();
	
	while (pos)
		aTaskIDs.Add(GetTaskID(selection.GetNext(pos)));

	// focused item
	HTREEITEM htiFocus = m_tree.GetSelectedItem();
	dwFocusedTaskID = GetTaskID(htiFocus);

	ASSERT (GetSelectedCount() > 1 || dwFocusedTaskID == aTaskIDs[0]); // sanity check
	
	return (aTaskIDs.GetSize());
}

BOOL CToDoCtrl::InsertTasks(const CTaskFile& tasks, TDC_INSERTWHERE nWhere)
{
	if (IsReadOnly())
		return FALSE;
	
	HTREEITEM htiParent = NULL, htiAfter = NULL;

	if (!GetInsertLocation(nWhere, htiParent, htiAfter))
		return FALSE;

	// else
	IMPLEMENT_UNDO(TDCUAT_ADD);
	HOLD_REDRAW(*this, m_tree);

	return AddTasksToTree(tasks, htiParent, htiAfter, TDCR_YES);
}

BOOL CToDoCtrl::SetTaskAttributes(const TODOITEM* pTDI, const TODOSTRUCTURE* pTDS,