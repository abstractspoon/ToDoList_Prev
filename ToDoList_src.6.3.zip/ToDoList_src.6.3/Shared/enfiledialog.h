fault.dateCreated.m_dt = 0.0;
}

LRESULT CToDoCtrl::OnEEBtnClick(WPARAM wParam, LPARAM lParam)
{
	switch (wParam)
	{
	case IDC_TIMESPENT:
		if (lParam == ID_TIMEEDITBTN && GetSelectedCount() == 1)
		{
			HandleUnsavedComments();
			TimeTrackTask(GetSelectedItem());
		}
		break;

	case IDC_DEPENDS:
		{
			CStringArray aDepends;
			GetSelectedTaskDependencies(aDepends);

			if (aDepends.GetSize())
				ShowTaskLink(0, aDepends[0]);
		}
		break;
	}
	
	return 0L;
}

void CToDoCtrl::OnTimer(UINT nIDEvent) 
{
	switch (nIDEvent)
	{
	case TIMER_TRACK:
		IncrementTrackedTime();
		break;

	case TIMER_MIDNIGHT:
		{
			// check if we've just passed midnight, in which case some tasks
			// may have just become due
			static time_t tPrev = time(NULL); // once only
			time_t tNow = time(NULL);

			if (tNow / DAY_IN_SECS > tPrev / DAY_IN_SECS)
			{
				m_data.ResetCachedCalculations();
				Invalidate();
			}

			tPrev = tNow;
		}
		break;
	}

	
	CRuntimeDlg::OnTimer(nIDEvent);
}

void CToDoCtrl::IncrementTrackedTime()
{
	// if we are editing the title of the task being tracked then leave immediately
	// and wait until the editing has ended
	if (IsT