 nDefColor = aDefCats.GetSize();

	while (nDefColor--)
	{
		const CString& sDefCat = aDefCats[nDefColor];

		if (sDefCat.IsEmpty())
			continue;

		// make sure this category is not already specified
		if (FindCategoryColor(sDefCat) != -1)
			continue; // skip

		CATCOLOR cc;
		cc.color = 0;
		cc.sCategory = sDefCat;

		m_sSelCategory = sDefCat;
		m_aCategoryColors.Add(cc);
	}
	
	// prefs
	m_bColorPriority = prefs.GetProfileInt("Preferences", "ColorPriority", TRUE);
	m_bGradientPriorityColors = !prefs.GetProfileInt("Preferences", "IndividualPriorityColors", FALSE);
	m_sTreeFont = prefs.GetProfileString("Preferences", "TreeFont", "Arial");
	m_nTreeFontSize = prefs.GetProfileInt("Preferences", "FontSize", 8);
	m_bSpecifyTreeFont = prefs.GetProfileInt("Preferences", "SpecifyTreeFont", FALSE);
	m_sCommentsFont = prefs.GetProfileString("Preferences", "CommentsFont", "Arial");
	m_nCommentsFontSize = prefs.GetProfileInt("Preferences", "CommentsFontSize", 8);
	m_bSpecifyCommentsFont = prefs.GetProfileInt("Preferences", "SpecifyCommentsFont", TRUE);
	m_bSpecifyGridColor = prefs.GetProfileInt("Preferences", "SpecifyGridColor", TRUE);
	m_crGridlines = prefs.GetProfileInt("Preferences\\Colors", "Gridlines", GRIDLINECOLOR);
	m_bSpecifyDoneColor = prefs.GetProfileInt("Preferences", "SpecifyDoneColor", TRUE);
	m_bSpecifyDueColor = prefs.GetProfileInt("Preferences", "SpecifyDueColor", TRUE);
	m_bSpecifyDueTodayColor = prefs.GetProfileInt("Preferences", "SpecifyDueTodayColor", TRUE);
	m_crDone = prefs.GetProfileInt("Preferences\\Colors", "TaskDone", TASKDONECOLOR);
	m_crDue = prefs.GetProfileInt("Preferences\\Colors", "TaskDue", TASKDUECOLOR);
	m_crDueToday = prefs.GetProfileInt("Preferences\\Colors", "TaskDueToday", TASKDUECOLOR);
	m_bColorTaskBackground = prefs.GetProfileInt("Preferences", "ColorTaskBackground", FALSE);
	m_bCommentsUseTreeFont = prefs.GetProfileInt("Preferences", "CommentsUseTreeFont", FALSE);
	m_bHLSColorGradient = prefs.GetProfileInt("Preferences", "HLSColorGradient", TRUE);
	m_bHidePriorityNumber = prefs.GetProfileInt("Preferences", "HidePriorityNumber", FALSE);
	m_bAlternateLineColor = prefs.GetProfileInt("Preferences", "AlternateLineColor", TRUE);
	m_crAltLine = prefs.GetProfileInt("Preferences\\Colors", "AlternateLines", ALTERNATELINECOLOR);
	m_bSpecifyFlaggedColor = prefs.GetProfileInt("Preferences", "FlaggedColor", FALSE);
	m_crFlagged = prefs.GetProfileInt("Preferences\\Colors", "Flagged", FLAGGEDCOLOR);

	// bkwds compatibility
	if (prefs.GetProfileInt("Preferences", "ColorByPriority", FALSE))
		m_nTextColorOption = COLOROPT_PRIORITY;

	m_nTextColorOption = prefs.GetProfileInt("Preferences", "TextColorOption", m_nTextColorOption);
}

void CPreferencesUITasklistColorsPage::SavePreferences(CPreferences& prefs)
{
	// save settings
	// priority colors
	prefs.WriteProfileInt("Preferences\\Colors", "Low", m_crLow);
	prefs.WriteProfileInt("Preferences\\Colors", "High", m_crHigh);

	int nColor = 11;

	while (nColor--)
	{
		CString sKey;
		sKey.Format("P%d", nColor);
		prefs.WriteProfileInt("Preferences\\Colors", sKey, m_aPriorityColors[nColor]);
	}

	// category colors
	int nNumColor = m_aCategoryColors.GetSize();
	prefs.WriteProfileInt("Preferences\\CatColors", "Count", nNumColor);

	for (nColor = 0; nColor < nNumColor; nColor++)
	{
		CString sKey;
		sKey.Format("Preferences\\CatColors\\P%d", nColor);

		const CATCOLOR& cc = m_aCategoryColors[nColor];
		prefs.WriteProfileInt(sKey, "Color", cc.color);
		prefs.WriteProfileString(sKey, "Category", cc.sCategory);
	}

	// save settings
	prefs.WriteProfileInt("Preferences", "TextColorOption", m_nTextColorOption);
	prefs.WriteProfileInt("Preferences", "ColorPriority", m_bColorPriority);
	prefs.WriteProfileInt("Preferences", "IndividualPriorityColors", !m_bGradientPriorityColors);
	prefs.WriteProfileString("Preferences", "TreeFont", m_sTreeFont);
	prefs.WriteProfileInt("Preferences", "FontSize", m_nTreeFontSize);
	prefs.WriteProfileInt("Preferences", "SpecifyTreeFont", m_bSpecifyTreeFont);
	prefs.WriteProfileString("Preferences", "CommentsFont", m_sCommentsFont);
	prefs.WriteProfileInt("Preferences", "CommentsFontSize", m_nCommentsFontSize);
	prefs.WriteProfileInt("Preferences", "SpecifyCommentsFont", m_bSpecifyCommentsFont);
	prefs.WriteProfileInt("Preferences", "SpecifyGridColor", m_bSpecifyGridColor);
	prefs.WriteProfileInt("Preferences\\Colors", "Gridlines", m_crGridlines);
	prefs.WriteProfileInt("Preferences", "SpecifyDoneColor", m_bSpecifyDoneColor);
	prefs.WriteProfileInt("Preferences\\Colors", "TaskDone", m_crDone);
	prefs.WriteProfileInt("Preferences", "SpecifyDueColor", m_bSpecifyDueColor);
	prefs.WriteProfileInt("Preferences\\Colors", "TaskDue", m_crDue);
	prefs.WriteProfileInt("Preferences", "SpecifyDueTodayColor", m_bSpecifyDueTodayColor);
	prefs.WriteProfileInt("Preferences\\Colors", "TaskDueToday", m_crDueToday);
	prefs.WriteProfileInt("Preferences", "ColorTaskBackground", m_bColorTaskBackground);
	prefs.WriteProfileInt("Preferences", "CommentsUseTreeFont", m_bCommentsUseTreeFont);
	prefs.WriteProfileInt("Preferences", "HLSColorGradient", m_bHLSColorGradient);
	prefs.WriteProfileInt("Preferences", "HidePriorityNumber", m_bHidePriorityNumber);
	prefs.WriteProfileInt("Preferences\\Colors", "AlternateLines", m_crAltLine);
	prefs.WriteProfileInt("Preferences", "AlternateLineColor", m_bAlternateLineColor);
	prefs.WriteProfileInt("Preferences", "FlaggedColor", m_bSpecifyFlaggedColor);
	prefs.WriteProfileInt("Preferences\\Colors", "Flagged", m_crFlagged);
}
     ze) && 
			(!szFaceName || sFontName.CompareNoCase(szFaceName) == 0));
}

BOOL GraphicsMisc::SameFontNameSize(HFONT hFont1, HFONT hFont2)
{
	CString sName1;
	int nSize1 = GetFontNameSize(hFont1, sName1);

	return SameFont(hFont2, sName1, nSize1);
}

HCURSOR GraphicsMisc::HandCursor()
{
#ifndef IDC_HAND
#	define IDC_HAND  MAKEINTRESOURCE(32649) // from winuser.h
#endif
	static HCURSOR cursor = NULL;
	
	if (!cursor)
	{
		cursor = ::LoadCursor(NULL, IDC_HAND);
		
		// fallback hack for win9x
		if (!cursor)
		{
			CString sWinHlp32;
			
			GetWindowsDirectory(sWinHlp32.GetBuffer(MAX_PATH), MAX_PATH);
			sWinHlp32.ReleaseBuffer();
			sWinHlp32 += _T("\\winhlp32.exe");
			
			HMODULE hMod = LoadLibrary(sWinHlp32);
			
			if (hMod)
				cursor = ::LoadCursor(hMod, MAKEINTRESOURCE(106));
		}
	}

	return cursor;
}

CFont& GraphicsMisc::WingDings()
{
	static CFont font;
				
	if (!font.GetSafeHandle())
		font.Attach(CreateFont(_T("Wingdings"), -1, MFS_SYMBOL));

	return font;
}

CFont& GraphicsMisc::Marlett()
{
	static CFont font;
				
	if (!font.GetSafeHandle())
		font.Attach(CreateFont(_T("Marlett"), -1, MFS_SYMBOL));

	return font;
}

int AFX_CDECL GraphicsMisc::GetTextWidth(CDC* pDC, LPCTSTR lpszFormat, ...)
{
	static TCHAR BUFFER[2048];

	ASSERT(AfxIsValidString(lpszFormat));

	va_list argList;
	va_start(argList, lpszFormat);
//fabio_2005
#if _MSC_VER >= 1400
	_vstprintf_s(BUFFER, lpszFormat, argList);
#else
	_vstprintf(BUFFER, lpszFormat, argList);
#endif
	va_end(argList);

	return pDC->GetTextExtent(BUFFER).cx;
}

float GraphicsMisc::GetAverageCharWidth(CDC* pDC)
{
	ASSERT(pDC);
	
	int nExtent = pDC->GetTextExtent("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz").cx;
	
	return (nExtent / 52.0f);
}

COLORREF GraphicsMisc::Lighter(COLORREF color, double dAmount)
{
	int red = GetRValue(color);
	int green = GetGValue(color);
	int blue = GetBValue(color);
	
	red += (int)((255 - red) * dAmount);
	green += (int)((255 - green) * dAmount);
	blue += (int)((255 - blue) * dAmount);

	red = min(255, red);
	green = min(255, green);
	blue = min(255, blue);
	
	return RGB(red, green, blue);
}

COLORREF GraphicsMisc::Darker(COLORREF color, double dAmount)
{
	int red = GetRValue(color);
	int green = GetGValue(color);
	int blue = GetBValue(color);
	
	red -= (int)((255 - red) * dAmount);
	green -= (int)((255 - green) * dAmount);
	blue -= (int)((255 - blue) * dAmount);

	red = max(0, red);
	green = max(0, green);
	blu// PreferencesUITasklistPage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesUITasklistPage.h"

#include "..\shared\colordef.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUITasklistPage property page

CPreferencesUITasklistPage::CPreferencesUITasklistPage() : 
	CPreferencesPageBase(CPreferencesUITasklistPage::IDD)
{
	//{{AFX_DATA_INIT(CPreferencesUITasklistPage)
	m_bHideDoneTimeField = FALSE;
	//}}AFX_DATA_INIT

}

CPreferencesUITasklistPage::~CPreferencesUITasklistPage()
{
}

void CPreferencesUITasklistPage::DoDataExchange(CDataExchange* pDX)
{ 
	CPreferencesPageBase::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesUITasklistPage)
	DDX_Check(pDX, IDC_USEISODATEFORMAT, m_bUseISOForDates);
	DDX_Check(pDX, IDC_SHOWWEEKDAYINDATES, m_bShowWeekdayInDates);
	DDX_Check(pDX, IDC_SHOWPARENTSASFOLDERS, m_bShowParentsAsFolders);
	DDX_Check(pDX, IDC_DISPLAYFIRSTCOMMENTLINE, m_bDisplayFirstCommentLine);
	DDX_C