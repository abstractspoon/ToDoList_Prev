/ look at every dll from wherever we are now
	CFileFind ff;
    CString sSearchPath = FileMisc::GetModuleFileName(), sFolder, sDrive;

	FileMisc::SplitPath(sSearchPath, &sDrive, &sFolder);
	FileMisc::MakePath(sSearchPath, sDrive, sFolder, "*", ".dll");

	BOOL bContinue = ff.FindFile(sSearchPath);
	
	while (bContinue)
	{
		bContinue = ff.FindNextFile();
		
		if (!ff.IsDots() && !ff.IsDirectory())
		{
			CString sDllPath = ff.GetFilePath();

			if (IsUIExtemsionDll(sDllPath))
			{
				IUIExtension* m_pExtension = CreateUIExtensionInterface(sDllPath);

				if (m_pExtension)
					m_aUIExtensions.Add(new CUIExtension(m_pExtension));

			}
		}
	}

	m_bInitialized = TRUE;
}

int CUIExtensionMgr::GetNumUIExtensions() const
{
	if (!m_bInitialized) 
		return 0;

	return m_aUIExtensions.GetSize();
}

CString CUIExtensionMgr::GetUIExtensionMenuText(int nExtension) const
{
	CString sText;

	if (m_bInitialized) 
	{
		if (nExtension >= 0 && nExtension < m_aUIExtensions.GetSize())
			sText = m_aUIExtensions[nExtension]->GetMenuText();
	}

	return Clean(sText);
}

HICON CUIExtensionMgr::GetUIExtensionIcon(int nExtension) const
{
	if (m_bInitialized) 
	{
		if (nExtension >= 0 && nExtension < m_aUIExtensions.GetSize())
			return m_aUIExtensions[nExtension]->GetIcon();
	}

	return NULL;
}

CString& CUIExtensionMgr::Clean(CString& sText)
{
	sText.TrimLeft();
	sText.TrimRight();

	return sText;
}

IUIExtensionWindow* CUIExtensionMgr::GetExtensionWindow(int nExtension, DWORD dwItemData, 
														HWND hParent, BOOL bAutoCreate)
{
	IUIExtensionWindow* pWindow = NULL;

	if (m_bInitialized) 
	{
		if (nExtension >= 0 && nExtension < m_aUIExtensions.GetSize())
			pWindow = m_aUIExtensions[nExtension]->GetWindow(dwItemData, hParent, bAutoCreate);
	}

	return pWindow;
}

BOOL CUIExtensionMgr::HasAnyExtensionWindows(DWORD dwItemData, BOOL bVisibleOnly) const
{
	int nExtension = GetNumUIExtensions();

	while (nExtension--)
	{
		if (m_aUIExtensions[nExtens