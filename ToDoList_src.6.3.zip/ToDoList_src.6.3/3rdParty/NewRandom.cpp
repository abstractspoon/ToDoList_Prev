// ImportExportMgr.h: interface for the CUIExtensionMgr class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UIEXTENSIONMGR_H__C258D849_69ED_46A7_A2F0_351C5C9FB3B3__INCLUDED_)
#define AFX_UIEXTENSIONMGR_H__C258D849_69ED_46A7_A2F0_351C5C9FB3B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "iuiextension.h"
#include "itasklist.h"
#include <afxtempl.h>

class IUIExtension;
class IUIExtensionWindow;

struct UIEXTENSIONWINDOW
{
	UIEXTENSIONWINDOW(IUIExtensionWindow* p = NULL) : pWindow(p)
	{
		bVisible = p ? p->IsShowing() : FALSE;
	}
	
	IUIExtensionWindow* pWindow;
	BOOL bVisible;
};

enum UI_SHOW
{
	UIS_SHOW,
	UIS_HIDE,
	UIS_RESTORE,
};

typedef CMap<DWORD, DWORD, UIEXTENSIONWINDOW*, UIEXTENSIONWINDOW*&> CUIExtensionWndMap;

class CUIExtension
{
public:
	CUIExtension(IUIExtension* pExt = NULL);
	virtual ~CUIExtension();

	CString GetMenuText();
	HICON GetIcon();

	IUIExtensionWindow* GetWindow(DWORD dwItemData, HWND hParent, BOOL bAutoCreate = TRUE);

	BOOL HasWindow(DWORD dwItemData, BOOL bVisibleOnly = FALSE) const;
	void RemoveWindow(DWORD dwItemData);
	BOOL ShowWindow(DWORD dwItemData, UI_SHOW nShow = UIS_RESTORE);
	void UpdateWindow(DWORD dwItemData, const ITaskList* pTasks, DWORD dwFlags = UIU_ALL);
	
protected:
	IUIExtension* m_pExtension;
	CUIExtensionWndMap* m_pMapWindows;

protected:
	void Release();
	UIEXTENSIONWINDOW* FindWindow(DWORD dwItemData) const;
	CUIExtensionWndMap* WindowMap();
};

class CUIExtensionMgr  
{
public:
	CUIExtensionMgr();
	virtual ~CUIExtensionMgr();
	
	virtual void Initialize();
	
	int GetNumUIExtensions() const;
	CString GetUIExtensionMenuText(int nExtension) const;
	HICON GetUIExtensionIcon(int nExtension) const;

	IUIExtensionWindow* GetExtensionWindow(int nExtension, DWORD dwItemData, HWND hParent, BOOL bAutoCreate = TRUE);

	BOOL HasAnyExtensionWindows(DWORD dwItemData, BOOL bVisibleOnly = FALSE) const;
	void ShowAllExtensionsWindows(DWORD dwItemData, UI_SHOW nShow = UIS_RESTORE);
	void RemoveAllExtensionsWindows(DWORD dwItemData);
	void UpdateAllExtensionsWindow(DWORD dwItemData, const ITaskList* pTasks, DWORD dwFlags = UIU_ALL);
	
protected:
	BOOL m_bInitialized;
	CArray<CUIExtension*, CUIExtension*> m_aUIExtensions;
	
protected:
	static CString& Clean(CString& sText);

};

#endif // !defined(AFX_UIEXTENSIONMGR_H__C258D849_69ED_46A7_A2F0_351C5C9FB3B3__INCLUDED_)
                                             nx], &st, sizeof(SYSTEMTIME));
	inx += sizeof(SYSTEMTIME);

	GetCursorPos(&pt);
	memcpy(&m_pPseudoRandom[inx], &pt, sizeof(POINT));
	inx += sizeof(POINT);

	ww = (WORD)(rand());
	memcpy(&m_pPseudoRandom[inx], &ww, 2); inx += 2;
	ww = (WORD)(rand());
	memcpy(&m_pPseudoRandom[inx], &ww, 2); inx += 2;
	ww = (WORD)(rand());
	memcpy(&m_pPseudoRandom[inx], &ww, 2); inx += 2;

	GetCaretPos(&pt);
	memcpy(&m_pPseudoRandom[inx], &pt, sizeof(POINT));
	inx += sizeof(POINT);

	GlobalMemoryStatus(&ms);
	memcpy(&m_pPseudoRandom[inx], &ms, sizeof(MEMORYSTATUS));
	inx += sizeof(MEMORYSTATUS);

	dw = (DWORD)GetActiveWindow();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = (DWORD)GetCapture();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = (DWORD)GetClipboardOwner();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

#ifndef _WIN32_WCE
	// No support under Windows CE
	dw = (DWORD)GetClipboardViewer();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); 
#else
	// Leave the stack data - random :)
#endif
	inx += 4;

	dw = GetCurrentProcessId();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = (DWORD)GetCurrentProcess();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = (DWORD)GetActiveWindow();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = GetCurrentThreadId();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = (DWORD)GetCurrentThread();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = (DWORD)GetDesktopWindow();
	memcpy(&m_pPseud// UIExtensionUIHelper.cpp: implementation of the CUIExtensionUIHelper class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "UIExtensionUIHelper.h"
#include "UIExtensionmgr.h"
#include "sysimagelist.h"
#include "MenuIconMgr.h"
#include "toolbarhelper.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CUIExtensionUIHelper::CUIExtensionUIHelper(const CUIExtensionMgr& mgrUIExt, UINT nStart, int nSize) : 
	m_mgrUIExt(mgrUIExt), m_nStartID(nStart), m_nSize(nSize)
{

}

CUIExtensionUIHelper::~CUIExtensionUIHelper()
{

}

void CUIExtensionUIHelper::UpdateMenu(CCmdUI* pCmdUI, CMenuIconMgr& mgrIcon, BOOL bEnabled) const
{
	if (pCmdUI->m_pMenu)
	{
		ASSERT (m_nStartID == pCmdUI->m_nID);

		// delete existing tool entries and their icons first
		int nExt;
		for (nExt = 0; nExt < m_nSize; nExt++)
		{
			pCmdUI->m_pMenu->DeleteMenu(m_nStartID + nExt, MF_BYCOMMAND);
			mgrIcon.DeleteImage(m_nStartID + nExt);
		}
		
		// if we have any tools to add we do it here
		int nNumExt = m_mgrUIExt.GetNumUIExtensions();

		if (nNumExt)
		{
			int nPos = 0;
			UINT nFlags = MF_BYPOSITION | MF_STRING | (bEnabled ? 0 : MF_GRAYED);
			
			for (nExt = 0; nExt < m_nSize && nExt < nNumExt; nExt++)
			{
				CString sMenuItem, sText = m_mgrUIExt.GetUIExtensionMenuText(nExt);
								
				if (nPos < 9)
					sMenuItem.Format("&%d %s", nPos + 1, sText);
				else
					sMenuItem = sText;

				pCmdUI->m_pMenu->InsertMenu(pCmdUI->m_nIndex++, nFlags, 
											m_nStartID + nExt, sMenuItem);

				// icon
				HICON hIcon = m_mgrUIExt.GetUIExtensionIcon(nExt);
				mgrIcon.AddImage(m_nStartID + nExt, hIcon);
				
				nPos++;
			}
			
			// update end menu count
			pCmdUI->m_nIndex--; // point to last menu added
			pCmdUI->m_nIndexMax = pCmdUI->m_pMenu->GetMenuItemCount();
			
			pCmdUI->m_bEnableChanged = TRUE;    // all the added items are enabled
		}
		else // if nothing to add just re-add placeholder
		{
			pCmdUI->m_pMenu->InsertMenu(pCmdUI->m_nIndex, MF_BYPOSITION | MF_STRING | MF_GRAYED, 
				m_nStartID, "3rd Party Extensions");
		}
	}
}

void CUIExtensionUIHelper::RemoveExtensionsFromToolbar(CToolBar& toolbar, UINT nCmdAfter)
{
	int nRemoved = 0;
	
	TBBUTTON tbb;
	CImageList* pIL = toolbar.GetToolBarCtrl().GetImageList();
	
	for (UINT nExtID = m_nStartID; nExtID <= m_nStartID + m_nSize; nExtID++)
	{
		int nBtn = toolbar.CommandToIndex(nExtID);
		
		if (nBtn != -1)
		{
			VERIFY(toolbar.GetToolBarCtrl().GetButton(nBtn, &tbb));
			
			if (toolbar.GetToolBarCtrl().DeleteButton(nBtn))
			{
				// delete the image too
				pIL->Remove(tbb.iBitmap);
				nRemoved++;
			}
		}
	}
	
	// remove separator
	if (nRemoved)
	{
		int nSep = toolbar.CommandToIndex(nCmdAfter) + 1;
		toolbar.GetToolBarCtrl().DeleteButton(nSep);
	}
}

void CUIExtensionUIHelper::AppendExtensionsToToolbar(CToolBar& toolbar, UINT nCmdAfter)
{
	// remove tools first
	RemoveExtensionsFromToolbar(toolbar, nCmdAfter);
	
	// then re-add
	int nNumExt = m_mgrUIExt.GetNumUIExtensions();

	if (nNumExt)
	{
		// start adding after the pref button
		int nStartPos = toolbar.CommandToIndex(nCmdAfter) + 1;
		int nAdded = 0;
		
		for (int nExt = 0; nExt < m_mgrUIExt.GetNumUIExtensions(); nExt++)
		{
			HICON hIcon = m_mgrUIExt.GetUIExtensionIcon(nExt);
				
			if (hIcon)
			{
				CImageList* pIL = toolbar.GetToolBarCtrl().GetImageList();
				int nImage = pIL->Add(hIcon);
				
				TBBUTTON tbb = { nImage, nExt + m_nStartID, 0, 