// ImportExportMgr.cpp: implementation of the CUIExtensionMgr class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "UIExtensionMgr.h"
#include "ITaskList.h"
#include "IUIExtension.h"
#include "filemisc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CUIExtension::CUIExtension(IUIExtension* pExt) : m_pExtension(pExt), m_pMapWindows(NULL) 
{

}

CUIExtension::~CUIExtension()
{
	// cleanup
	Release();
}

CString CUIExtension::GetMenuText()
{
	if (m_pExtension)
		return m_pExtension->GetMenuText();
	
	return "";
}

HICON CUIExtension::GetIcon()
{
	if (m_pExtension)
		return m_pExtension->GetIcon();
	
	return NULL;
}

void CUIExtension::Release() 
{ 
	if (m_pExtension) 
	{
		if (m_pMapWindows)
		{
			POSITION pos = m_pMapWindows->GetStartPosition();
			
			while (pos)
			{
				UIEXTENSIONWINDOW* pUIWnd = NULL;
				DWORD dwDummy;
				
				m_pMapWindows->GetNextAssoc(pos, dwDummy, pUIWnd);
				
				if (pUIWnd)
				{
					if (pUIWnd->pWindow)
						pUIWnd->pWindow->Release();

					delete pUIWnd;
				}
			}
			
			m_pMapWindows->RemoveAll();
			delete m_pMapWindows;
			m_pMapWindows = NULL;
		}
		m_pExtension->Release(); 
	}
	
	m_pExtension = NULL;
}

IUIExtensionWindow* CUIExtension::GetWindow(DWORD dwItemData, HWND hParent, BOOL bAutoCreate)
{
	UIEXTENSIONWINDOW* pUIWnd = FindWindow(dwItemData);
	
	if (!pUIWnd && bAutoCreate)
	{
		SIZE size = { 300, 200 };
		IUIExtensionWindow* pWindow = m_pExtension->CreateExtensionWindow(hParent, FALSE, &size);

		pUIWnd = new UIEXTENSIONWINDOW(pWindow);
		WindowMap()->SetAt(dwItemData, pUIWnd);
	}
	
	return pUIWnd ? pUIWnd->pWindow : NULL;
}

BOOL CUIExtension::HasWindow(DWORD dwItemData, BOOL bVisibleOnly) const
{
	UIEXTENSIONWINDOW* pUIWnd = FindWindow(dwItemData);

	if (bVisibleOnly)
		return (pUIWnd && pUIWnd->pWindow->IsShowing());

	// else
	return (pUIWnd != NULL);
}

void CUIExtension::RemoveWindow(DWORD dwItemData)
{
	UIEXTENSIONWINDOW* pUIWnd = FindWindow(dwItemData);
	
	if (pUIWnd)
	{
		pUIWnd->pWindow->Release();
		delete pUIWnd;
		WindowMap()->RemoveKey(dwItemData);
	}
}

BOOL CUIExtension::ShowWindow(DWORD dwItemData, UI_SHOW nShow)
{
	UIEXTENSIONWINDOW* pUIWnd = FindWindow(dwItemData);
	
	if (pUIWnd)
	{
		switch (nShow)
		{
		case UIS_HIDE:
			// save current state
			pUIWnd->bVisible = pUIWnd->pWindow->IsShowing();
			return pUIWnd->pWindow->Show(FALSE);

		case UIS_SHOW:
			return pUIWnd->pWindow->Show(TRUE);

		case UIS_RESTORE:
			return pU