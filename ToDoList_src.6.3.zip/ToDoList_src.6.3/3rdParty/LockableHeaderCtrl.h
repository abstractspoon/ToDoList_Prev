HTREEITEM& htiAnchor, HTREEITEM& htiTreeSel) const;
	void RestoreAnchorSel(HTREEITEM htiAnchor, HTREEITEM htiTreeSel);

	BOOL FixupTreeSelection(); // returns TRUE if the tree selection changed
 
   void OrderSelection();
   static void OrderSelection(CHTIList& selection, const CTreeCtrl& tree);

protected:
	CTreeCtrl& m_tree;
	CHTIList m_lstSelection;
	int m_nCurSelection;
	HTREEITEM m_htiAnchor;
	CTreeCtrlHelper m_tch;

	class CIDArray : public CArray<DWORD, DWORD&>
	{
	public:
		CIDArray() {}
		CIDArray(const CIDArray& arr) { Copy(arr); }

		const CIDArray& CIDArray::operator=(const CIDArray& arr)
		{
			Copy(arr);
			return *this;
		}
	};
	CArray<CIDArray, CIDArray&> m_aHistory;

protected:
	void InvalidateItem(HTREEITEM hti);
	static BOOL HasSelectedParent(HTREEITEM hti, const CHTIList& selection, const CTreeCtrl& tree);
	int GetItemPos(