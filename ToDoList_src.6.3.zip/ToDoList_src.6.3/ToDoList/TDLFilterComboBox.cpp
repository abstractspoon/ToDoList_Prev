// TDLFilterComboBox.cpp : implementation file
//

#include "stdafx.h"
#include "TDLFilterComboBox.h"
#include "tdcstatic.h"

#include "..\shared\enstring.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTDLFilterComboBox

CTDLFilterComboBox::CTDLFilterComboBox()
{
}

CTDLFilterComboBox::~CTDLFilterComboBox()
{
}


BEGIN_MESSAGE_MAP(CTDLFilterComboBox, CTabbedComboBox)
	//{{AFX_MSG_MAP(CTDLFilterComboBox)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTDLFilterComboBox message handlers

void CTDLFilterComboBox::PreSubclassWindow() 
{
	CTabbedComboBox::PreSubclassWindow();

	FillCombo();
}

int CTDLFilterComboBox::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CTabbedComboBox::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	FillCombo();
	
	return 0;
}

void CTDLFilterComboBox::FillCombo()
{
	ASSERT(GetSafeHwnd());

	if (GetCount())
		return; // already called

	for (int nItem = 0; nItem < NUM_TASKFILTER; nItem++)
	{
		CString sFilter((LPCTSTR)TASK_FILTERS[nItem][0]);
		UINT nFilter = TASK_FILTERS[nItem][1];

		CString sText;
		sText.Format(_T("%c)\t%s"), 'A' + nItem, sFilter); 
		int nIndex = AddString(sText);
		ASSERT (nIndex != CB_ERR);

		if (nIndex != CB_ERR)
			SetItemData(nIndex, nFilter);
	}
}

void CTDLFilterComboBox::RemoveCustomFilter()
{
	int nFind = GetCount();

	// find an existing entry
	while (nFind--)
	{
		if (GetItemData(nFind) == (DWORD)FT_CUSTOM)
			break;
	}

	if (nFind != -1)
	{
		// save selection so we can restore it
		int nSel = GetCurSel();

		DeleteString(nFind);

		if (nFind < nSel)
			nSel--;

		SetCurSel(nSel);
	}
}

void CTDLFilterComboBox::SetCustomFilter(LPCTSTR szFilter)
{
	int nFind = GetCount();
	
	// find an existing entry
	while (nFind--)
	{
		if (GetItemData(nFind) == (DWORD)FT_CUSTOM)
			break;
	}
	
	CString sCustom((LPCTSTR)IDS_CUSTOMFILTER), sFilter((LPCTSTR)IDS_CUSTOMFILTER);
	
	if (szFilter && *szFilter)
		sFilter.Format(_T("%s (%s)"), sCustom, szFilter);
	
	// delete existing entry if the text has changed
	if (nFind != -1)
	{
		CString sPrevFilter;
		GetLBText(nFind, sPrevFilter);
		
		if (sFilter != sPrevFilter)
			DeleteString(nFind);
		else
			return; // nothing to do
	}
	
	nFind = AddString(sFilter);
	SetItemData(nFind, (DWORD)FT_CUSTOM);
	SetCurSel(nFind);
}

FILTER_TYPE CTDLFilterComboBox::GetSelectedFilter() const
{
	int nSel = GetCurSel();
	ASSERT (nSel != CB_ERR);

	if (nSel == CB_ERR)
		return (FILTER_TYPE)-1;

	// else
	return (FILTER_TYPE)GetItemData(nSel);
}

BOOL CTDLFilterComboBox::SetSelectedFilter(FILTER_TYPE nFilter)
{
	for (int nItem = 0; nItem < GetCount(); nItem++)
	{
		FILTER_TYPE nItemFilter = (FILTER_TYPE)GetItemData(nItem);

		if (nItemFilter == nFilter)
		{
			SetCurSel(nItem);
			return TRUE;
		}
	}

	return FALSE;
}
