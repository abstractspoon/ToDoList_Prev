// TaskListTxtExporter.cpp: implementation of the CTaskListTxtExporter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "todolist.h"
#include "TaskListTxtExporter.h"
#include "tdlschemadef.h"
#include "recurringtaskedit.h"

#include "..\shared\Preferences.h"

#include "..\3rdparty\stdiofileex.h"

#include <locale.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

static LPCTSTR ENDL = _T("\n");

CTaskListTxtExporter::CTaskListTxtExporter()
{
}

CTaskListTxtExporter::~CTaskListTxtExporter()
{
	
}

bool CTaskListTxtExporter::ExportOutput(LPCTSTR szDestFilePath, const CString& sOutput)
{
	CStdioFileEx fileOut;
	
	if (fileOut.Open(szDestFilePath, CFile::modeCreate | CFile::modeWrite))
	{
		fileOut.WriteString(sOutput);
		return true;
	}
	
	// else
	return false;
}

void CTaskListTxtExporter::InitConsts()
{
	CPreferences prefs;
	
	if (prefs.GetProfileInt(_T("Preferences"), _T("UseSpaceIndents"), TRUE))
		INDENT = CString(' ', prefs.GetProfileInt(_T("Preferences"), _T("TextIndent"), 2));
	else
		INDENT = '\t';
	
	if (prefs.GetProfileInt(_T("Preferences"), _T("ExportSpaceForNotes"), FALSE))
	{
		TEXTNOTES.Empty();
		int nLine = prefs.GetProfileInt(_T("Preferences"), _T("LineSpaces"), 8);
		
		if (nLine > 0)
		{
			while (nLine--)
				TEXTNOTES += "\n";
		}
	}
	
	ROUNDTIMEFRACTIONS = prefs.GetProfileInt(_T("Preferences"), _T("RoundTimeFractions"), FALSE);
}

bool CTaskListTxtExporter::Export(const IMultiTaskList* pSrcTaskFile, LPCTSTR szDestFilePath, BOOL /*bSilent*/)
{
	InitConsts();
	
	CString sOutput;
	
	for (int nTaskList = 0; nTaskList < pSrcTaskFile->GetTaskListCount(); nTaskList++)
	{
		const ITaskList8* pTasks8 = GetITLInterface<ITaskList8>(pSrcTaskFile->GetTaskList(nTaskList), IID_TASKLIST8);
		ExportTask(pTasks8, NULL, 0, 0, _T(""), sOutput);
	}
	
	return ExportOutput(szDestFilePath, sOutput);
}

bool CTaskListTxtExporter::Export(const ITaskList* pSrcTaskFile, LPCTSTR szDestFilePath, BOOL /*bSilent*/)
{
	InitConsts();
	
	const ITaskList8* pTasks8 = GetITLInterface<ITaskList8>(pSrcTaskFile, IID_TASKLIST8);
	
	CString sOutput;
	ExportTask(pTasks8, NULL, 0, 0, _T(""), sOutput);
	
	return ExportOutput(szDestFilePath, sOutput);
}

CString& CTaskListTxtExporter::ExportTask(const ITaskList8* pTasks, HTASKITEM hTask, int nDepth, int nPos, const CString& sParentPos, CString& sOutput) const
{
	// handle locale specific decimal separator
	setlocale(LC_NUMERIC, "");
	
	// if depth == 0 then we're at the root so just add sub-tasks
	// else insert pItem first
	CString sPos; 
	
	if (nDepth > 0)
	{
		// first create string to hold TABs
		CString sTabs;
		
		for (int nTab = 0; nTab < nDepth; nTab++)
			sTabs += INDENT;
		
		// if there is a POS child item then this replaces nPos
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKPOS))
		{
			nPos = pTasks->GetTaskPosition(hTask);
		
			if (!sParentPos.IsEmpty())
				sPos.Format(_T("%s%d."), sParentPos, nPos);
			else
				sPos.Format(_T("%d."), nPos);
		}
		
		CString sID, sItem, sPriority, sStartDate, sDueDate, sDoneDate;
		CString sAllocTo, sAllocBy, sCategory, sStatus, sCost;
		CString sComments, sPercent, sTimeEst, sTimeSpent, sFileRef;
		CString sLastMod, sRisk, sExtID, sCreateDate, sCreateBy, sVersion;
		CString sRecurrence, sDepends;
		TCHAR cTemp;
		
		// IDs
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKID))
		{
			DWORD dwID = pTasks->GetTaskID(hTask);
			
			if (dwID)
			{
				if (nDepth > 1)
					sID.Format(_T("(ID: %d, PID: %d) "), dwID, pTasks->GetTaskParentID(hTask));
				else
					sID.Format(_T("(ID: %d) "), dwID);
			}
		}
		
		// title
		CString sTitle(pTasks->GetTaskTitle(hTask));
		
		// priority, start/due/done dates
		int nPercent = pTasks->GetTaskPercentDone(hTask, TRUE);
		BOOL bDone = pTasks->IsTaskDone(hTask) || (nPercent == 100);
		int nTimePlaces = ROUNDTIMEFRACTIONS ? 0 : 2;
		
		if (bDone)
			FormatAttribute(pTasks, hTask, TDL_TASKDONEDATESTRING, _T(" (completed: %s)"), sDoneDate);
		
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKHIGHESTPRIORITY) ||
			pTasks->TaskHasAttribute(hTask, TDL_TASKPRIORITY))
		{
			int nPriority = pTasks->GetTaskPriority(hTask, TRUE);
			
			if (nPriority >= 0)
				sPriority.Format(_T("[%d] "), nPriority);
			else
				sPriority = _T("[ ]");
		}
		
		FormatAttribute(pTasks, hTask, TDL_TASKSTARTDATESTRING, _T(" (start: %s)"), sStartDate);
		FormatAttribute(pTasks, hTask, TDL_TASKDUEDATESTRING, _T(" (due: %s)"), sDueDate);
		FormatAttribute(pTasks, hTask, TDL_TASKPERCENTDONE, _T(" (%s%%) "), sPercent);
		
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKTIMEESTIMATE) ||
			pTasks->TaskHasAttribute(hTask, TDL_TASKCALCTIMEESTIMATE))
			sTimeEst.Format(_T(" (time est: %.*f hrs)"), nTimePlaces, pTasks->GetTaskTimeEstimate(hTask, cTemp, TRUE));
		
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKTIMESPENT) ||
			pTasks->TaskHasAttribute(hTask, TDL_TASKCALCTIMESPENT))
			sTimeEst.Format(_T(" (time spent: %.*f hrs)"), nTimePlaces, pTasks->GetTaskTimeSpent(hTask, cTemp, TRUE));
		
		FormatAttribute(pTasks, hTask, TDL_TASKCREATIONDATESTRING, _T(" (created: %s)"), sCreateDate);
		FormatAttribute(pTasks, hTask, TDL_TASKCREATEDBY, _T(" (created by: %s)"), sCreateBy);
		FormatAttributeList(pTasks, hTask, TDL_TASKNUMALLOCTO, TDL_TASKALLOCTO, _T(" (allocated to: %s)"), sAllocTo);
		FormatAttribute(pTasks, hTask, TDL_TASKALLOCBY, _T(" (allocated by: %s)"), sAllocBy);
		FormatAttributeList(pTasks, hTask, TDL_TASKNUMCATEGORY, TDL_TASKCATEGORY, _T(" (category: %s)"), sCategory);
		FormatAttribute(pTasks, hTask, TDL_TASKSTATUS, _T(" (status: %s)"), sStatus);
		FormatAttribute(pTasks, hTask, TDL_TASKRISK, _T(" (risk: %s)"), sRisk);
		FormatAttribute(pTasks, hTask, TDL_TASKEXTERNALID, _T(" (ext.ID: %s)"), sExtID);
		FormatAttribute(pTasks, hTask, TDL_TASKLASTMODSTRING, _T(" (last mod: %s)"), sLastMod);
		FormatAttribute(pTasks, hTask, TDL_TASKCOST, _T(" (cost: %s)"), sCost);
		FormatAttribute(pTasks, hTask, TDL_TASKVERSION, _T(" (version: %s)"), sVersion);
		FormatAttribute(pTasks, hTask, TDL_TASKRECURRENCE, _T(" (occurs: %s)"), sRecurrence);
		FormatAttribute(pTasks, hTask, TDL_TASKDEPENDENCY, _T(" (depends on: %s)"), sDepends);
		
		// fileref
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKFILEREFPATH))
			sFileRef.Format(_T("%s%s(link: %s)"), ENDL, sTabs, pTasks->GetTaskFileReferencePath(hTask));
		
		// comments
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKCOMMENTS))
			sComments.Format(_T("%s%s%s"), ENDL, sTabs, pTasks->GetTaskComments(hTask));
		
		sItem.Format(_T("%s %s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s"), 
			sPos, sID, sPriority, sPercent, sTitle, sRisk, 
			sAllocTo, sAllocBy, sDepends, sVersion, sRecurrence, sCategory, sStatus, 
			sDoneDate, sCreateDate, sCreateBy, sStartDate, sDueDate, 
			sTimeEst, sTimeSpent, sCost,
			sExtID, sLastMod, sFileRef, sComments, ENDL);
		
		// notes section
		if (!bDone)
			sItem += TEXTNOTES;
		
		// indent to match depth
		sOutput += sTabs;
		sOutput += sItem;
		sOutput += ENDL;
	}
	else
	{
		// title and date
		const ITaskList4* pITL4 = static_cast<const ITaskList4*>(pTasks);
		
		CString sTitle = pITL4->GetReportTitle();
		CString sDate = pITL4->GetReportDate();
		
		// note: do not append a trailing ENDL as this will be added 
		// by the following code
		if (!sTitle.IsEmpty())
		{
			sOutput += sTitle;
			
			if (!sDate.IsEmpty())
			{
				sOutput += ENDL;
				sOutput += sDate;
			}
		}
		else if (!sDate.IsEmpty())
			sOutput += sDate;
	}
	
	// begin new ordered list for sub-tasks
	hTask = pTasks->GetFirstTask(hTask);
	
	if (hTask) // at least one sub-task
	{
		int nChildPos = 1;
		
		while (hTask)
		{
			CString sTask;
			sOutput += ENDL;
			sOutput += ExportTask(pTasks, hTask, nDepth + 1, nChildPos++, sPos, sTask);
			
			hTask = pTasks->GetNextTask(hTask);
		}
	}
	
	// restore decimal separator to '.'
	setlocale(LC_NUMERIC, "English");
	
	return sOutput;
}

BOOL CTaskListTxtExporter::FormatAttribute(const ITaskList8* pTasks, HTASKITEM hTask, 
										   LPCTSTR szAttribName, LPCTSTR szFormat, CString& sAttribText)
{
	if (pTasks->TaskHasAttribute(hTask, szAttribName))
	{
		sAttribText.Format(szFormat, pTasks->GetTaskAttribute(hTask, szAttribName));
		return TRUE;
	}
	
	return FALSE;
}


BOOL CTaskListTxtExporter::FormatAttributeList(const ITaskList8* pTasks, HTASKITEM hTask, 
											   LPCTSTR szNumAttribName, LPCTSTR szAttribName, 
											   LPCTSTR szFormat, CString& sAttribText)
{
	int nItemCount = _ttoi(pTasks->GetTaskAttribute(hTask, szNumAttribName));
	
	if (nItemCount <= 1)
		return FormatAttribute(pTasks, hTask, szAttribName, szFormat, sAttribText);
	
	// else more than one (use plus sign as delimiter)
	CString sAttribs = pTasks->GetTaskAttribute(hTask, szAttribName);
	
	for (int nItem = 1; nItem < nItemCount; nItem++)
	{
		CString sAttribName;
		sAttribName.Format(_T("%s%d"), szAttribName, nItem);
		
		sAttribs += '+';
		sAttribs += pTasks->GetTaskAttribute(hTask, sAttribName);
	}
	
	sAttribText.Format(szFormat, sAttribs);
	return TRUE;
}
