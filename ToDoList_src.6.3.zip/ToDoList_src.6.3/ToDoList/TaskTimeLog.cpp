// TaskTimeLog.cpp: implementation of the CTaskTimeLog class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TaskTimeLog.h"

#include "..\shared\Filemisc.h"
#include "..\shared\misc.h"
#include "..\shared\datehelper.h"

#include "..\3rdParty\stdiofileex.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

LPCTSTR COLUMNHEADINGS[] = { _T("Task ID"), _T("Title"), _T("Time Spent (Hrs)"), _T("User ID"), _T("End Date/Time"), _T("Start Date/Time") };
const UINT NUM_COLUMNHEADINGS = sizeof(COLUMNHEADINGS) / sizeof(LPCTSTR);

LPCTSTR LOGFORMAT[] = { _T("%ld"), _T("%s"), _T("%.3f"), _T("%s"), _T("%s"), _T("%s") };
const UINT NUM_LOGFORMATS = sizeof(LOGFORMAT) / sizeof(LPCTSTR);

CTaskTimeLog::CTaskTimeLog(LPCTSTR szRefPath, SFE_SAVEAS nSaveAs) : m_sRefPath(szRefPath), m_nSaveAs(nSaveAs)
{
}

CTaskTimeLog::~CTaskTimeLog()
{

}

BOOL CTaskTimeLog::LogTime(DWORD dwTaskID, LPCTSTR szTaskTitle, double dTime, BOOL bLogSeparately)
{
	return LogTime(dwTaskID, szTaskTitle, dTime, COleDateTime::GetCurrentTime(), bLogSeparately);
}

BOOL CTaskTimeLog::LogTime(DWORD dwTaskID, LPCTSTR szTaskTitle, double dTime, COleDateTime dtWhen, BOOL bLogSeparately)
{
	CString sLogPath = GetLogPath(dwTaskID, bLogSeparately);

	// if the file doesn't exist then we insert the column headings as the first line
	// and we use the passed in format for the log file
	if (!FileMisc::FileExists(sLogPath))
		FileMisc::AppendLineToFile(sLogPath, BuildColumnHeader(), m_nSaveAs);

	// then log the time spent
	CString sLog, sLogFormat(BuildRowFormat());

	COleDateTime dtEnd = dtWhen;
	COleDateTime dtStart = dtEnd - COleDateTime(dTime / 24); // dTime is in hours

	sLog.Format(sLogFormat, 
				dwTaskID, 
				szTaskTitle,
				dTime, 
				Misc::GetUserName(),
				CDateHelper::FormatDate(dtEnd, DHFD_ISO | DHFD_TIME), 
				CDateHelper::FormatDate(dtStart, DHFD_ISO | DHFD_TIME));

	return FileMisc::AppendLineToFile(sLogPath, sLog, SFE_ASIS);
}

CString CTaskTimeLog::GetLogPath(DWORD dwTaskID, BOOL bLogSeparately)
{
	CString sLogPath, sDrive, sFolder, sFileName;

	// use ref filename as the basis for the log filename
	FileMisc::SplitPath(m_sRefPath, &sDrive, &sFolder, &sFileName);
	
	if (bLogSeparately)
		sLogPath.Format(_T("%s%s%s\\%ld_Log.csv"), sDrive, sFolder, sFileName, dwTaskID);
	else
		sLogPath.Format(_T("%s%s%s_Log.csv"), sDrive, sFolder, sFileName);

	return sLogPath;
}

double CTaskTimeLog::CalcAccumulatedTime(DWORD dwTaskID, BOOL bLogSeparately)
{
	double dTotalTime = 0;
	CStdioFileEx file;
	CString sLogPath = GetLogPath(dwTaskID, bLogSeparately);

	if (file.Open(sLogPath, CFile::modeRead | CFile::typeText))
	{
		CString sLine;
		double dLogTime;
		DWORD dwLogID;

		while (file.ReadString(sLine))
		{
			// decode it
			//fabio_2005
#if _MSC_VER >= 1400
			if (sscanf_s(_T("%ld,%.3f"), sLine, &dwLogID, &dLogTime) == 2)
#else
			if (_stscanf(_T("%ld,%.3f"), sLine, &dwLogID, &dLogTime) == 2)
#endif

			{
				if (dwLogID == dwTaskID)
					dTotalTime += dLogTime;
			}
		}
	}

	return dTotalTime;
}

CString CTaskTimeLog::BuildColumnHeader()
{
	ASSERT(NUM_COLUMNHEADINGS == NUM_LOGFORMATS);

	CString sColumnHeader, sDelim = Misc::GetListSeparator();

	for (int nCol = 0; nCol < NUM_COLUMNHEADINGS; nCol++)
	{
		sColumnHeader += COLUMNHEADINGS[nCol];
		
		if (nCol < NUM_COLUMNHEADINGS - 1)
			sColumnHeader += sDelim + ' ';
	}

	return sColumnHeader;
}

CString CTaskTimeLog::BuildRowFormat()
{
	ASSERT(NUM_COLUMNHEADINGS == NUM_LOGFORMATS);

	CString sRowFormat, sDelim = Misc::GetListSeparator();

	for (int nRow = 0; nRow < NUM_LOGFORMATS; nRow++)
	{
		sRowFormat += LOGFORMAT[nRow];
		
		if (nRow < NUM_LOGFORMATS - 1)
			sRowFormat += sDelim + ' ';
	}

	return sRowFormat;
}
