// TDImportExportMgr.cpp: implementation of the CTDLImportExportMgr class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "todolist.h"
#include "TDLImportExportMgr.h"
#include "tasklisthtmlexporter.h"
#include "tasklisttxtexporter.h"
#include "tasklistcsvexporter.h"
#include "tasklistcsvimporter.h"
#include "tasklisttdlexporter.h"
#include "tasklisttdlimporter.h"
#include "tdlschemadef.h"

#include "..\shared\filemisc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

///////////////////////////////////////////////////////////////////////

#define ExportTaskListTo(FUNCTION)									\
																	\
	TCHAR szTempFile[MAX_PATH], szTempPath[MAX_PATH];				\
																	\
	if (!::GetTempPath(MAX_PATH, szTempPath) ||						\
		!::GetTempFileName(szTempPath, _T("tdl"), 0, szTempFile))	\
		return _T("");												\
																	\
	CString sFile;													\
																	\
	if (FUNCTION(pSrcTasks, szTempFile, bSilent))					\
		FileMisc::LoadFile(szTempFile, sFile);						\
																	\
	::DeleteFile(szTempFile);									

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTDLImportExportMgr::CTDLImportExportMgr()
{

}

CTDLImportExportMgr::~CTDLImportExportMgr()
{

}

void CTDLImportExportMgr::Initialize()
{
	// add html and text exporters first
	if (!m_bInitialized)
	{
		m_aExporters.InsertAt(EXPTOHTML, new CTaskListHtmlExporter);
		m_aExporters.InsertAt(EXPTOTXT, new CTaskListTxtExporter);
		m_aExporters.InsertAt(EXPTOCSV, new CTaskListCsvExporter);
		m_aExporters.InsertAt(EXPTOTDL, new CTaskListTdlExporter);

		m_aImporters.InsertAt(IMPFROMCSV, new CTaskListCsvImporter);
		m_aImporters.InsertAt(IMPFROMTDL, new CTaskListTdlImporter);
	}

	CImportExportMgr::Initialize();
}

BOOL CTDLImportExportMgr::ExportTaskListToHtml(const ITaskList* pSrcTasks, LPCTSTR szDestFile, BOOL bSilent) const
{
	return ExportTaskList(pSrcTasks, szDestFile, EXPTOHTML, bSilent);
}

CString CTDLImportExportMgr::ExportTaskListToHtml(const ITaskList* pSrcTasks, BOOL bSilent) const
{
	ExportTaskListTo(ExportTaskListToHtml)
	return sFile;
}

BOOL CTDLImportExportMgr::ExportTaskListsToHtml(const IMultiTaskList* pSrcTasks, LPCTSTR szDestFile, BOOL bSilent) const
{
	return ExportTaskLists(pSrcTasks, szDestFile, EXPTOHTML, bSilent);
}

CString CTDLImportExportMgr::ExportTaskListsToHtml(const IMultiTaskList* pSrcTasks, BOOL bSilent) const
{
	ExportTaskListTo(ExportTaskListsToHtml)
	return sFile;
}

BOOL CTDLImportExportMgr::ExportTaskListToText(const ITaskList* pSrcTasks, LPCTSTR szDestFile, BOOL bSilent) const
{
	return ExportTaskList(pSrcTasks, szDestFile, EXPTOTXT, bSilent);
}

CString CTDLImportExportMgr::ExportTaskListToText(const ITaskList* pSrcTasks, BOOL bSilent) const
{
	ExportTaskListTo(ExportTaskListToText)
	return sFile;
}

BOOL CTDLImportExportMgr::ExportTaskListsToText(const IMultiTaskList* pSrcTasks, LPCTSTR szDestFile, BOOL bSilent) const
{
	return ExportTaskLists(pSrcTasks, szDestFile, EXPTOTXT, bSilent);
}

CString CTDLImportExportMgr::ExportTaskListsToText(const IMultiTaskList* pSrcTasks, BOOL bSilent) const
{
	ExportTaskListTo(ExportTaskListsToText)
	return sFile;
}

BOOL CTDLImportExportMgr::ExportTaskListToCsv(const ITaskList* pSrcTasks, LPCTSTR szDestFile, BOOL bSilent) const
{
	return ExportTaskList(pSrcTasks, szDestFile, EXPTOCSV, bSilent);
}

CString CTDLImportExportMgr::ExportTaskListToCsv(const ITaskList* pSrcTasks, BOOL bSilent) const
{
	ExportTaskListTo(ExportTaskListToCsv)
	return sFile;
}

BOOL CTDLImportExportMgr::ExportTaskListsToCsv(const IMultiTaskList* pSrcTasks, LPCTSTR szDestFile, BOOL bSilent) const
{
	return ExportTaskLists(pSrcTasks, szDestFile, EXPTOCSV, bSilent);
}

CString CTDLImportExportMgr::ExportTaskListsToCsv(const IMultiTaskList* pSrcTasks, BOOL bSilent) const
{
	ExportTaskListTo(ExportTaskListsToCsv)
	return sFile;
}

BOOL CTDLImportExportMgr::ImportTaskListFromCsv(LPCTSTR szSrcFile, ITaskList* pDestTasks, BOOL bSilent) const
{
	return ImportTaskList(szSrcFile, pDestTasks, IMPFROMCSV, bSilent);
}

BOOL CTDLImportExportMgr::ExportTaskListToTdl(const ITaskList* pSrcTasks, LPCTSTR szDestFile, BOOL bSilent) const
{
	return ExportTaskList(pSrcTasks, szDestFile, EXPTOTDL, bSilent);
}

CString CTDLImportExportMgr::ExportTaskListToTdl(const ITaskList* pSrcTasks, BOOL bSilent) const
{
	ExportTaskListTo(ExportTaskListToTdl)
	return sFile;
}

BOOL CTDLImportExportMgr::ExportTaskListsToTdl(const IMultiTaskList* pSrcTasks, LPCTSTR szDestFile, BOOL bSilent) const
{
	return ExportTaskLists(pSrcTasks, szDestFile, EXPTOTDL, bSilent);
}

CString CTDLImportExportMgr::ExportTaskListsToTdl(const IMultiTaskList* pSrcTasks, BOOL bSilent) const
{
	ExportTaskListTo(ExportTaskListsToTdl)
	return sFile;
}

BOOL CTDLImportExportMgr::ImportTaskListFromTdl(LPCTSTR szSrcFile, ITaskList* pDestTasks, BOOL bSilent) const
{
	return ImportTaskList(szSrcFile, pDestTasks, IMPFROMTDL, bSilent);
}

BOOL CTDLImportExportMgr::ImportTaskList(LPCTSTR szSrcFile, ITaskList* pDestTasks, int nByImporter, BOOL bSilent) const
{
	// call base class and then fixup default attributes
	if (CImportExportMgr::ImportTaskList(szSrcFile, pDestTasks, nByImporter, bSilent))
	{
		SetTaskAttributesToDefaults(pDestTasks, pDestTasks->GetFirstTask());
		return TRUE;
	}

	return FALSE;
}

void CTDLImportExportMgr::SetTaskAttributesToDefaults(ITaskList* pTasks, HTASKITEM hTask) const
{
	if (!hTask)
		return;

	ASSERT(pTasks);
	ITaskList8* pTasks8 = GetITLInterface<ITaskList8>(pTasks, IID_TASKLIST8);

	if (!pTasks8->TaskHasAttribute(hTask, TDL_TASKCOLOR))
		pTasks8->SetTaskColor(hTask, m_tdiDefault.color);

	if (!pTasks8->TaskHasAttribute(hTask, TDL_TASKSTARTDATE) && m_tdiDefault.dateStart.m_dt > 0)
	{
		SYSTEMTIME st;
		m_tdiDefault.dateStart.GetAsSystemTime(st);

		pTasks8->SetTaskStartDate(hTask, CTime(st).GetTime());
	}
	
	if (!pTasks8->TaskHasAttribute(hTask, TDL_TASKALLOCBY))
		pTasks8->SetTaskAllocatedBy(hTask, m_tdiDefault.sAllocBy);
	
	if (!pTasks8->TaskHasAttribute(hTask, TDL_TASKSTATUS))
		pTasks8->SetTaskStatus(hTask, m_tdiDefault.sStatus);
	
	if (!pTasks8->TaskHasAttribute(hTask, TDL_TASKTIMEESTIMATE))
		pTasks8->SetTaskTimeEstimate(hTask, m_tdiDefault.dTimeEstimate, (TCHAR)m_tdiDefault.nTimeEstUnits);
	
	if (!pTasks8->TaskHasAttribute(hTask, TDL_TASKTIMESPENT))
		pTasks8->SetTaskTimeSpent(hTask, m_tdiDefault.dTimeSpent, (TCHAR)m_tdiDefault.nTimeSpentUnits);
	
	if (!pTasks8->TaskHasAttribute(hTask, TDL_TASKCREATEDBY))
		pTasks8->SetTaskCreatedBy(hTask, m_tdiDefault.sCreatedBy);
	
	if (!pTasks8->TaskHasAttribute(hTask, TDL_TASKCOST))
		pTasks8->SetTaskCost(hTask, m_tdiDefault.dCost);
	
	if (!pTasks8->TaskHasAttribute(hTask, TDL_TASKCATEGORY))
	{
		int nCat = m_tdiDefault.aCategories.GetSize();

		while (nCat--)
			pTasks8->AddTaskCategory(hTask, m_tdiDefault.aCategories[nCat]);
	}
	
	if (!pTasks8->TaskHasAttribute(hTask, TDL_TASKALLOCTO))
	{
		int nAlloc = m_tdiDefault.aAllocTo.GetSize();

		while (nAlloc--)
			pTasks8->AddTaskAllocatedTo(hTask, m_tdiDefault.aAllocTo[nAlloc]);
	}
	
	if (!pTasks8->TaskHasAttribute(hTask, TDL_TASKCOMMENTSTYPE))
		pTasks8->SetTaskAttribute(hTask, TDL_TASKCOMMENTSTYPE, m_tdiDefault.sCommentsTypeID);
	
	if (!pTasks8->TaskHasAttribute(hTask, TDL_TASKPRIORITY))
		pTasks8->SetTaskPriority(hTask, m_tdiDefault.nPriority);
	
	if (!pTasks8->TaskHasAttribute(hTask, TDL_TASKRISK))
		pTasks8->SetTaskRisk(hTask, m_tdiDefault.nRisk);

	// first child
	SetTaskAttributesToDefaults(pTasks8, pTasks8->GetFirstTask(hTask));

	// next sibling
	SetTaskAttributesToDefaults(pTasks8, pTasks8->GetNextTask(hTask));
}

