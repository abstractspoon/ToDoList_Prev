#if !defined(AFX_TDLTASKICONDLG_H__73512EBA_90D6_40EA_A2C3_F2089A567486__INCLUDED_)
#define AFX_TDLTASKICONDLG_H__73512EBA_90D6_40EA_A2C3_F2089A567486__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TDLTaskIconDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTDLTaskIconDlg dialog

class CTDLTaskIconDlg : public CDialog
{
// Construction
public:
	CTDLTaskIconDlg(const CImageList& ilIcons, int nSelIndex = -1, CWnd* pParent = NULL);   // standard constructor
	int GetIconIndex() const { return m_nIconIndex; }

protected:
// Dialog Data
	//{{AFX_DATA(CTDLTaskIconDlg)
	enum { IDD = IDD_TASKICON_DIALOG };
	CListCtrl	m_lcIcons;
	//}}AFX_DATA
	const CImageList& m_ilIcons;
	int m_nIconIndex;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTDLTaskIconDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTDLTaskIconDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDblclkIconlist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemchangedIconlist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEndlabeleditIconlist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TDLTASKICONDLG_H__73512EBA_90D6_40EA_A2C3_F2089A567486__INCLUDED_)
