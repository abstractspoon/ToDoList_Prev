// TaskFileHtmlExporter.h: interface for the CTaskListHtmlExporter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TASKFILEHTMLEXPORTER_H__E4FD92AB_2BF2_40E3_9C8E_5018A72AEA89__INCLUDED_)
#define AFX_TASKFILEHTMLEXPORTER_H__E4FD92AB_2BF2_40E3_9C8E_5018A72AEA89__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\SHARED\Itasklist.h"
#include "..\SHARED\IImportExport.h"

class CTaskListHtmlExporter : public IExportTasklist  
{
public:
	CTaskListHtmlExporter();
	virtual ~CTaskListHtmlExporter();

	LPCTSTR GetMenuText() { return _T("Web Page"); }
	LPCTSTR GetFileFilter() { return _T("Web Pages (*.html)|*.html||"); }
	LPCTSTR GetFileExtension() { return _T("html"); }

	bool Export(const ITaskList* pSrcTaskFile, LPCTSTR szDestFilePath, BOOL bSilent);
   	bool Export(const IMultiTaskList* pSrcTaskFile, LPCTSTR szDestFilePath, BOOL bSilent);
	void Release() { delete this; }

protected:
	CString DEFAULTFONT, HTMLNOTES;
	BOOL STRIKETHRUDONE, ROUNDTIMEFRACTIONS;

protected:
	CString& ExportTask(const ITaskList8* pTasks, HTASKITEM hTask, int nDepth, int nPos, const CString& sParentPos, CString& sOutput) const;
	void InitConsts();

	CString FormatCharSet(const ITaskList8* pTasks) const;
	
	static BOOL FormatAttribute(const ITaskList8* pTasks, HTASKITEM hTask, LPCTSTR szAttribName, 
								LPCTSTR szFormat, CString& sAttribText);
	static BOOL FormatAttributeList(const ITaskList8* pTasks, HTASKITEM hTask, 
										   LPCTSTR szNumAttribName, LPCTSTR szAttribName, 
                                          LPCTSTR szFormat, CString& sAttribText);
};

#endif // !defined(AFX_TASKFILEHTMLEXPORTER_H__E4FD92AB_2BF2_40E3_9C8E_5018A72AEA89__INCLUDED_)
