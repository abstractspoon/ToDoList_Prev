// TaskListCsvExporter.h: interface for the CTaskListTdlExporter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TASKLISTTDLEXPORTER_H__ADF211CB_FBD2_42A2_AD51_DFF58E566753__INCLUDED_)
#define AFX_TASKLISTTDLEXPORTER_H__ADF211CB_FBD2_42A2_AD51_DFF58E566753__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "tdcenum.h"
//#include "TDLImportExportDlg.h"

#include "..\shared\Itasklist.h"
#include "..\shared\IImportExport.h"

class CTaskListTdlExporter : public IExportTasklist  
{
public:
	CTaskListTdlExporter();
	virtual ~CTaskListTdlExporter();

	LPCTSTR GetMenuText() { return _T("TodoList"); }
	LPCTSTR GetFileFilter() { return _T("Tasklists (*.tdl)|*.tdl||"); }
	LPCTSTR GetFileExtension() { return _T("tdl"); }

	bool Export(const ITaskList* pSrcTaskFile, LPCTSTR szDestFilePath, BOOL bSilent);
	bool Export(const IMultiTaskList* pSrcTaskFile, LPCTSTR szDestFilePath, BOOL bSilent);
    void Release() { delete this; }

protected:

};

#endif // !defined(AFX_TASKLISTCSVEXPORTER_H__ADF211CB_FBD2_42A2_AD51_DFF58E566753__INCLUDED_)
