// TDLImportDialog.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "TDLImportDialog.h"

#include "../shared/enstring.h"
#include "../shared/misc.h"
#include "../shared/filemisc.h"
#include "../shared/preferences.h"
#include "../shared/dialoghelper.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTDLImportDialog dialog


CTDLImportDialog::CTDLImportDialog(const CImportExportMgr& mgr, CWnd* pParent /*=NULL*/)
	: CDialog(CTDLImportDialog::IDD, pParent),
	  m_mgrImportExport(mgr)
{
	//{{AFX_DATA_INIT(CTDLImportDialog)
	//}}AFX_DATA_INIT
	CPreferences prefs;

	m_bFromClipboard = prefs.GetProfileInt(_T("Importing"), _T("ImportOption"), FALSE);
	m_sFromFilePath = prefs.GetProfileString(_T("Importing"), _T("ImportFilePath"));
	m_nImportTo = prefs.GetProfileInt(_T("Importing"), _T("ImportToWhere"), TDIT_SELECTEDTASK);

	m_nFormatOption = prefs.GetProfileInt(_T("Importing"), _T("ImportFormat"), 0);
	m_nFormatOption = min(m_nFormatOption, mgr.GetNumImporters());
}


void CTDLImportDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTDLImportDialog)
	DDX_Control(pDX, IDC_FROMFILEPATH, m_eFilePath);
	DDX_Control(pDX, IDC_FORMATOPTIONS, m_cbFormat);
	DDX_Radio(pDX, IDC_FROMFILE, m_bFromClipboard);
	DDX_Text(pDX, IDC_FROMFILEPATH, m_sFromFilePath);
	DDX_Radio(pDX, IDC_TONEWTASKLIST, m_nImportTo);
	//}}AFX_DATA_MAP

	if (pDX->m_bSaveAndValidate)
	{
		int nIndex = m_cbFormat.GetCurSel();
		m_nFormatOption = m_cbFormat.GetItemData(nIndex);
	}
	else
		CDialogHelper::SelectItemByData(m_cbFormat, m_nFormatOption);
}


BEGIN_MESSAGE_MAP(CTDLImportDialog, CDialog)
	//{{AFX_MSG_MAP(CTDLImportDialog)
	ON_BN_CLICKED(IDC_FROMCLIPBOARD, OnChangeImportFrom)
	ON_CBN_SELCHANGE(IDC_FORMATOPTIONS, OnSelchangeFormatoptions)
	ON_BN_CLICKED(IDC_FROMFILE, OnChangeImportFrom)
	ON_EN_CHANGE(IDC_FROMCLIPBOARDTEXT, OnChangeClipboardtext)
	ON_EN_CHANGE(IDC_FROMFILEPATH, OnChangeFilepath)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTDLImportDialog message handlers

void CTDLImportDialog::OnChangeImportFrom() 
{
	UpdateData();

	BOOL bHasFilter = CurImporterHasFilter();
	
	GetDlgItem(IDC_FROMFILEPATH)->EnableWindow(!m_bFromClipboard && bHasFilter);
	GetDlgItem(IDC_FROMCLIPBOARDTEXT)->EnableWindow(m_bFromClipboard && bHasFilter);

	EnableOK();
}

BOOL CTDLImportDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// build the format comboxbox
	CString sFormat;
	
	for (int nImp = 0; nImp < m_mgrImportExport.GetNumImporters(); nImp++)
	{
		CString sImporter = m_mgrImportExport.GetImporterMenuText(nImp);
		CString sFileExt = m_mgrImportExport.GetImporterFileExtension(nImp);

		if (sFileExt.IsEmpty())
			sFormat = sImporter;
		else
			sFormat.Format(_T("%s (*.%s)"), sImporter, sFileExt);

		int nIndex = m_cbFormat.AddString(sFormat);
		m_cbFormat.SetItemData(nIndex, nImp);
	}

	CDialogHelper::SelectItemByData(m_cbFormat, m_nFormatOption);
	
	// init file edit
	BOOL bHasFilter = CurImporterHasFilter();

	m_eFilePath.SetFilter(GetCurImporterFilter());
	m_eFilePath.EnableWindow(bHasFilter);
	
	GetDlgItem(IDC_FROMFILEPATH)->EnableWindow(!m_bFromClipboard && bHasFilter);
	GetDlgItem(IDC_FROMCLIPBOARDTEXT)->EnableWindow(m_bFromClipboard && bHasFilter);
	GetDlgItem(IDC_FROMFILE)->EnableWindow(bHasFilter);
	GetDlgItem(IDC_FROMCLIPBOARD)->EnableWindow(bHasFilter);
	
	m_sClipboardText = Misc::GetClipboardText(*this);

	if (bHasFilter)
		GetDlgItem(IDC_FROMCLIPBOARDTEXT)->SetWindowText(m_sClipboardText);

	EnableOK();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CTDLImportDialog::CurImporterHasFilter() const
{
	return m_mgrImportExport.ImporterHasFileExtension(m_nFormatOption);
}

CString CTDLImportDialog::GetCurImporterFilter() const
{
	return m_mgrImportExport.GetImporterFileFilter(m_nFormatOption);
}

void CTDLImportDialog::OnOK()
{
	CDialog::OnOK();
	
	CPreferences prefs;
	
	prefs.WriteProfileInt(_T("Importing"), _T("ImportOption"), m_bFromClipboard);
	prefs.WriteProfileString(_T("Importing"), _T("ImportFilePath"), m_sFromFilePath);
	prefs.WriteProfileInt(_T("Importing"), _T("ImportToWhere"), m_nImportTo);
	prefs.WriteProfileInt(_T("Importing"), _T("ImportFormat"), m_nFormatOption);

	// retrieve clipboard text
	if (CurImporterHasFilter())
		GetDlgItem(IDC_FROMCLIPBOARDTEXT)->GetWindowText(m_sClipboardText);
}

int CTDLImportDialog::GetImporterIndex() const
{
	return m_nFormatOption;
}

TDLID_IMPORTTO CTDLImportDialog::GetImportTo() const
{
	return (TDLID_IMPORTTO)m_nImportTo;
}

BOOL CTDLImportDialog::GetImportFromClipboard() const
{
	return (m_bFromClipboard);
}

CString CTDLImportDialog::GetImportFilePath() const
{
	return (m_bFromClipboard || !CurImporterHasFilter()) ? _T("") : m_sFromFilePath;
}

CString CTDLImportDialog::GetImportClipboardText() const
{
	return (m_bFromClipboard && CurImporterHasFilter()) ? m_sClipboardText : _T("");
}

void CTDLImportDialog::OnSelchangeFormatoptions() 
{
	BOOL bHadFilter = m_mgrImportExport.ImporterHasFileExtension(m_nFormatOption);

	UpdateData(TRUE);
	
	// change the filter on the CFileEdit and clear the filepath
	// and clear/restore clipboard text depending
	BOOL bHasFilter = CurImporterHasFilter();

	m_eFilePath.SetFilter(GetCurImporterFilter());
	m_eFilePath.EnableWindow(bHasFilter);
	
	GetDlgItem(IDC_FROMFILE)->EnableWindow(bHasFilter);
	GetDlgItem(IDC_FROMCLIPBOARD)->EnableWindow(bHasFilter);
	GetDlgItem(IDC_FROMFILEPATH)->EnableWindow(!m_bFromClipboard && bHasFilter);
	GetDlgItem(IDC_FROMCLIPBOARDTEXT)->EnableWindow(m_bFromClipboard && bHasFilter);

	if (bHadFilter && !bHasFilter)
	{
		GetDlgItem(IDC_FROMCLIPBOARDTEXT)->GetWindowText(m_sClipboardText); // update
		GetDlgItem(IDC_FROMCLIPBOARDTEXT)->SetWindowText(_T("")); // clear field
	}
	else if (!bHadFilter && bHasFilter)
	{
		GetDlgItem(IDC_FROMCLIPBOARDTEXT)->SetWindowText(m_sClipboardText); // restore field
	}
	
	m_sFromFilePath.Empty();
	UpdateData(FALSE);

	EnableOK();
}

void CTDLImportDialog::EnableOK()
{
	if (!CurImporterHasFilter())
		GetDlgItem(IDOK)->EnableWindow(TRUE);

	else if (GetImportFromClipboard())
	{
		GetDlgItem(IDOK)->EnableWindow(!m_sClipboardText.IsEmpty());
	}
	else // import from file
	{
		m_sFromFilePath.TrimLeft();
		m_sFromFilePath.TrimRight();

		GetDlgItem(IDOK)->EnableWindow(FileMisc::FileExists(m_sFromFilePath));
	}
}

void CTDLImportDialog::OnChangeClipboardtext() 
{
	GetDlgItem(IDC_FROMCLIPBOARDTEXT)->GetWindowText(m_sClipboardText); // update
	EnableOK();
}

void CTDLImportDialog::OnChangeFilepath() 
{
	UpdateData();
	EnableOK();
}
