// TaskListCsvExporter.cpp: implementation of the CTaskListTdlExporter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TaskListtdlExporter.h"
#include "TaskFile.h"
#include "tdlschemadef.h"

#include "..\shared\filemisc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTaskListTdlExporter::CTaskListTdlExporter()
{

}

CTaskListTdlExporter::~CTaskListTdlExporter()
{

}

bool CTaskListTdlExporter::Export(const IMultiTaskList* pSrcTaskFile, LPCTSTR szDestFilePath, BOOL bSilent)
{
	if (pSrcTaskFile->GetTaskListCount() == 1)
		return Export(pSrcTaskFile->GetTaskList(0), szDestFilePath, bSilent);

	// create a single tasklist out of the many
	CTaskFile tasks;

	for (int nTaskList = 0; nTaskList < pSrcTaskFile->GetTaskListCount(); nTaskList++)
	{
		const ITaskList8* pTasks8 = GetITLInterface<ITaskList8>(pSrcTaskFile->GetTaskList(nTaskList), IID_TASKLIST8);
		
		if (pTasks8)
		{
			// do not export the destination file if it also appears in the list
			CString sFilePath = pTasks8->GetAttribute(TDL_FILENAME);

			if (FileMisc::IsSameFile(sFilePath, szDestFilePath))
				continue;

			// create a top-level task for each tasklist
			HTASKITEM hFileTask = tasks.NewTask(sFilePath, NULL);

			// copy tasklist into that top-level task
			tasks.CopyTaskFrom(pTasks8, pTasks8->GetFirstTask(), hFileTask);
		}
	}

	return (tasks.Save(szDestFilePath) != FALSE);
}

bool CTaskListTdlExporter::Export(const ITaskList* pSrcTaskFile, LPCTSTR szDestFilePath, BOOL /*bSilent*/)
{
	CTaskFile tasks(pSrcTaskFile);

	return (tasks.Save(szDestFilePath) != FALSE);
}

