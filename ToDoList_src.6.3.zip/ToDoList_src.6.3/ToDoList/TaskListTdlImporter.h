// TaskListCsvImporter.h: interface for the CTaskListTdlImporter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TASKLISTTDLIMPORTER_H__ADF211CB_FBD2_42A2_AD51_DFF58E566753__INCLUDED_)
#define AFX_TASKLISTTDLIMPORTER_H__ADF211CB_FBD2_42A2_AD51_DFF58E566753__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "tdcenum.h"
//#include "TDLImportExportDlg.h"

#include "..\shared\Itasklist.h"
#include "..\shared\IImportExport.h"

class CTaskListTdlImporter : public IImportTasklist  
{
public:
	CTaskListTdlImporter();
	virtual ~CTaskListTdlImporter();

	LPCTSTR GetMenuText() { return _T("ToDoList"); }
	LPCTSTR GetFileFilter() { return _T("Tasklists (*.tdl)|*.tdl||"); }
	LPCTSTR GetFileExtension() { return _T("tdl"); }

	bool Import(LPCTSTR szSrcFilePath, ITaskList* pDestTaskFile, BOOL bSilent);
    void Release() { delete this; }

};

#endif // !defined(AFX_TASKLISTCSVImPORTER_H__ADF211CB_FBD2_42A2_AD51_DFF58E566753__INCLUDED_)
