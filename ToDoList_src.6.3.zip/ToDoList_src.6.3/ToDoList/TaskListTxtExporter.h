// TaskListTxtExporter.h: interface for the CTaskListTxtExporter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TASKLISTTXTEXPORTER_H__CF68988D_FBBD_431D_BB56_464E8737D993__INCLUDED_)
#define AFX_TASKLISTTXTEXPORTER_H__CF68988D_FBBD_431D_BB56_464E8737D993__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\SHARED\Itasklist.h"
#include "..\SHARED\IImportExport.h"

class CTaskListTxtExporter : public IExportTasklist  
{
public:
	CTaskListTxtExporter();
	virtual ~CTaskListTxtExporter();

	LPCTSTR GetMenuText() { return _T("Plain Text"); }
	LPCTSTR GetFileFilter() { return _T("Text Files (*.txt)|*.txt||"); }
	LPCTSTR GetFileExtension() { return _T("txt"); }

	bool Export(const ITaskList* pSrcTaskFile, LPCTSTR szDestFilePath, BOOL bSilent);
	bool Export(const IMultiTaskList* pSrcTaskFile, LPCTSTR szDestFilePath, BOOL bSilent);
    void Release() { delete this; }

protected:
	CString TEXTNOTES, INDENT;
	BOOL ROUNDTIMEFRACTIONS;

protected:
	bool ExportOutput(LPCTSTR szDestFilePath, const CString& sOutput);
	void InitConsts();
	CString& ExportTask(const ITaskList8* pTasks, HTASKITEM hTask, int nDepth, int nPos, const CString& sParentPos, CString& sOutput) const;

	static BOOL FormatAttributeList(const ITaskList8* pTasks, HTASKITEM hTask, 
										   LPCTSTR szNumAttribName, LPCTSTR szAttribName, 
                                          LPCTSTR szFormat, CString& sAttribText);
	static BOOL FormatAttribute(const ITaskList8* pTasks, HTASKITEM hTask, LPCTSTR szAttribName, 
								LPCTSTR szFormat, CString& sAttribText);
};

#endif // !defined(AFX_TASKLISTTXTEXPORTER_H__CF68988D_FBBD_431D_BB56_464E8737D993__INCLUDED_)
