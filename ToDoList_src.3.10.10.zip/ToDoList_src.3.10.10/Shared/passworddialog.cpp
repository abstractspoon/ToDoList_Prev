// passworddialog.cpp : implementation file
//

#include "stdafx.h"
#include "passworddialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPasswordDialog dialog

enum
{
	IDC_PASSWORD = 101,
	IDC_CONFIRMATION,
};


CPasswordDialog::CPasswordDialog(BOOL bConfirm, LPCTSTR szExplanation, int nLines, CWnd* pParent /*=NULL*/)
	: CRuntimeDlg(), m_bConfirm(bConfirm)
{
	//{{AFX_DATA_INIT(CPasswordDialog)
	m_sPassword = _T("");
	m_sConfirmation = _T("");
	//}}AFX_DATA_INIT

	const UINT HIDE = bConfirm ? 0 : (WS_DISABLED | WS_NOTVISIBLE);
	const int YOFFSET = bConfirm ? 0 : 19;
	const int YEXPOFFSET = (NULL == szExplanation) ? 0 : (nLines * 8 + 8);

	if (szExplanation)
	    AddRCControl("LTEXT", "", szExplanation, 0, 0,7,9,172, (nLines * 8),IDC_STATIC);

    AddRCControl("LTEXT", "", "Enter Password:", 0, 0,7,9 + YEXPOFFSET,52,8,IDC_STATIC);
    AddRCControl("EDITTEXT", "", "", WS_TABSTOP | ES_PASSWORD | ES_AUTOHSCROLL, 0,70,7 + YEXPOFFSET,109,14, IDC_PASSWORD);
    AddRCControl("LTEXT", "", "Confirm Password:", HIDE, 0,7 + YEXPOFFSET,28,59,8,IDC_STATIC);
    AddRCControl("EDITTEXT", "", "", WS_TABSTOP | ES_PASSWORD | ES_AUTOHSCROLL | HIDE, 0,70,25 + YEXPOFFSET,109,14, IDC_CONFIRMATION);
    AddRCControl("CONTROL", "Static", "", SS_ETCHEDHORZ, 0, 7,45 - YOFFSET + YEXPOFFSET,172,1,IDC_STATIC);
    AddRCControl("DEFPUSHBUTTON", "", "OK", WS_DISABLED | WS_TABSTOP, 0, 71,55 - YOFFSET + YEXPOFFSET,50,14,IDOK);
    AddRCControl("PUSHBUTTON", "", "Cancel", WS_TABSTOP, 0,129,55 - YOFFSET + YEXPOFFSET,50,14,IDCANCEL);
}


void CPasswordDialog::DoDataExchange(CDataExchange* pDX)
{
	CRuntimeDlg::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPasswordDialog)
	DDX_Text(pDX, IDC_PASSWORD, m_sPassword);
	DDX_Text(pDX, IDC_CONFIRMATION, m_sConfirmation);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPasswordDialog, CRuntimeDlg)
	//{{AFX_MSG_MAP(CPasswordDialog)
	ON_EN_CHANGE(IDC_PASSWORD, OnChangePassword)
	ON_EN_CHANGE(IDC_CONFIRMATION, OnChangeConfirmation)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPasswordDialog message handlers

// static method
BOOL CPasswordDialog::RetrievePassword(BOOL bConfirm, CString& sPassword, LPCTSTR szExplanation, int nLines)
{
	BOOL bContinue = TRUE;

	while (bContinue)
	{
		CPasswordDialog dialog(bConfirm, szExplanation, nLines);

		if (IDOK == dialog.DoModal())
			bContinue = dialog.GetPassword().IsEmpty();
		else
			return FALSE;

		// check confirmation too
		if (!bContinue)
		{
			if (bConfirm)
			{
				if (dialog.GetConfirmation() != dialog.GetPassword())
				{
					::MessageBox(NULL, "Unfortunately the confirmation did not match the password."
										"\n\nPlease try again.", 
										"Password Confirmation Incorrect", MB_OK);
					bContinue = TRUE;
				}
				else
					sPassword = dialog.GetPassword();
			}
			else
				sPassword = dialog.GetPassword();
		}
	}

	return TRUE;
}

void CPasswordDialog::OnChangePassword() 
{
	UpdateData();

	GetDlgItem(IDOK)->EnableWindow(!m_sPassword.IsEmpty() && (!m_bConfirm || !m_sConfirmation.IsEmpty()));
}

void CPasswordDialog::OnChangeConfirmation() 
{
	UpdateData();

	if (m_bConfirm)
		GetDlgItem(IDOK)->EnableWindow(!m_sPassword.IsEmpty() && (!m_bConfirm || !m_sConfirmation.IsEmpty()));
}
