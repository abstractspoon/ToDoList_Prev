// KanbanStruct.h: interface for the CKanbanStruct class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_KanbanSTRUCT_H__C83C53D4_887E_4D5C_A8A7_85C8FDB19307__INCLUDED_)
#define AFX_KanbanSTRUCT_H__C83C53D4_887E_4D5C_A8A7_85C8FDB19307__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\shared\mapex.h"

#include "..\Interfaces\iuiextension.h"

#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////

class CKanbanValueMap : public CMapStringToString
{
public:
	BOOL HasValue(const CString& sValue) const;
	void AddValue(const CString& sValue);
	void GetNextValue(POSITION& pos, CString& sValue) const;
	int GetValues(CStringArray& aValues) const;
};
typedef CMapStringToContainer<CKanbanValueMap> CKanbanAttributeValueMap;

/////////////////////////////////////////////////////////////////////////////

struct KANBANITEM 
{ 
	KANBANITEM(DWORD dwID = 0);
	KANBANITEM(const KANBANITEM& ki);
	virtual ~KANBANITEM();
	
	KANBANITEM& operator=(const KANBANITEM& ki);
	BOOL operator==(const KANBANITEM& ki) const;

	DWORD dwTaskID;
	COLORREF color;
	BOOL bDone, bGoodAsDone;
	BOOL bParent;

	CString sTitle, sPath;
	CString sTimeEst, sTimeSpent;

	void SetAttributeValue(LPCTSTR szAttrib, LPCTSTR szValue);
	void SetAttributeValue(LPCTSTR szAttrib, int nValue);
	CString GetAttributeValue(LPCTSTR szAttrib) const;
	COLORREF GetTextColor(BOOL bSelected, BOOL bColorIsBkgnd) const;
	COLORREF GetFillColor(BOOL bColorIsBkgnd) const;
	COLORREF GetBorderColor(BOOL bColorIsBkgnd) const;
	BOOL HasColor() const;
	BOOL IsDone(BOOL bIncludeGoodAs) const;
	int GetPriority() const;
	
	static CString GetAttribID(IUI_ATTRIBUTEEDIT nAttrib);

protected:
	CMapStringToString mapAttribValues;
};
typedef CArray<const KANBANITEM*, const KANBANITEM*> CKanbanItemArray;

/////////////////////////////////////////////////////////////////////////////

class CKanbanItemArrayMap : public CMapStringToContainer<CKanbanItemArray>
{
public:
	virtual ~CKanbanItemArrayMap();

	void RemoveAll();
};

/////////////////////////////////////////////////////////////////////////////

class CKanbanItemMap : public CMap<DWORD, DWORD, KANBANITEM*, KANBANITEM*&>
{
public:
	virtual ~CKanbanItemMap();

	void RemoveAll();
	BOOL RemoveKey(DWORD dwKey);
	BOOL HasItem(DWORD dwTaskID) const;
	int BuildTempItemMaps(LPCTSTR szAttribID, CKanbanItemArrayMap& map) const;
	KANBANITEM* GetItem(DWORD dwTaskID) const;
	KANBANITEM* NewItem(DWORD dwTaskID, const CString& sTitle);

};

/////////////////////////////////////////////////////////////////////////////

struct KANBANCOLUMN
{
	KANBANCOLUMN();
	KANBANCOLUMN(const KANBANCOLUMN& kc);

	KANBANCOLUMN& operator=(const KANBANCOLUMN& kc);
	BOOL operator==(const KANBANCOLUMN& kc) const;
	BOOL AttributeMatches(const KANBANCOLUMN& kc) const;

	int GetAttributeValueIDs(CStringArray& aAttribValueIDs) const;

	CString sTitle;
	CString sAttribID;
	CStringArray aAttribValues;
//	int nMaxTaskCount;
	COLORREF crBackground;
	COLORREF crExcess;
};
typedef CArray<KANBANCOLUMN, KANBANCOLUMN&> CKanbanColumnArray;

/////////////////////////////////////////////////////////////////////////////

struct KANBANSORT
{
	KANBANSORT(const CKanbanItemMap& map);

	const CKanbanItemMap& data;
	IUI_ATTRIBUTEEDIT nBy;
	BOOL bAscending;
};

/////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_KanbanSTRUCT_H__C83C53D4_887E_4D5C_A8A7_85C8FDB19307__INCLUDED_)
