// tabctrlex.cpp : implementation file
//

#include "stdafx.h"
#include "tabctrlex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabCtrlEx

CTabCtrlEx::CTabCtrlEx(BOOL bPostDraw) : m_bPostDraw(bPostDraw)
{
}

CTabCtrlEx::~CTabCtrlEx()
{
}


BEGIN_MESSAGE_MAP(CTabCtrlEx, CTabCtrl)
	//{{AFX_MSG_MAP(CTabCtrlEx)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabCtrlEx message handlers

void CTabCtrlEx::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// always do default
	DefWindowProc(WM_PAINT, (WPARAM)(HDC)dc, 0);

	// then post draw if required
	if (m_bPostDraw)
	{
		CRect rClip;
		dc.GetClipBox(rClip);

		DRAWITEMSTRUCT dis;
		dis.CtlType = ODT_TAB;
		dis.CtlID = GetDlgCtrlID();
		dis.hwndItem = GetSafeHwnd();
		dis.hDC = dc;
		dis.itemAction = ODA_DRAWENTIRE;
		
		// paint the tabs first and then the borders
		int nTab = GetItemCount();
		int nSel = GetCurSel();
		
		while (nTab--)
		{
			if (nTab != nSel)
			{
				dis.itemID = nTab;
				dis.itemState = 0;
				
				VERIFY(GetItemRect(nTab, &dis.rcItem));

				dis.rcItem.bottom -= 2;
				dis.rcItem.top += 2;
				dis.rcItem.left += 2;
				dis.rcItem.right -= 2;

				if (CRect().IntersectRect(rClip, &dis.rcItem))
					GetParent()->SendMessage(WM_DRAWITEM, dis.CtlID, (LPARAM)&dis);
			}
		}
		
		// now selected tab
		if (nSel != -1)
		{
			dis.itemID = nSel;
			dis.itemState = ODS_SELECTED;
			
			VERIFY(GetItemRect(nSel, &dis.rcItem));
			dis.rcItem.bottom += 2;
			
			if (CRect().IntersectRect(rClip, &dis.rcItem))
				GetParent()->SendMessage(WM_DRAWITEM, dis.CtlID, (LPARAM)&dis);
		}
	}
}

void CTabCtrlEx::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	if (m_bPostDraw)
		return; // ignore because we probably sent it

	CTabCtrl::DrawItem(lpDrawItemStruct);
}
