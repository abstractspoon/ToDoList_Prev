// ExportDlg.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "ExportDlg.h"

#include "..\shared\filemisc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CExportDlg dialog

enum { ACTIVETASKLIST, ALLTASKLISTS };

const LPCTSTR HTMLFILTER = "Web Pages (*.html, *.htm)|*.html;*.htm||";
const LPCTSTR TEXTFILTER = "Text Files (*.txt)|*.txt||";

CExportDlg::CExportDlg(BOOL bSingleTaskList, LPCTSTR szFilePath, LPCTSTR szFolderPath, CWnd* pParent /*=NULL*/)
	: CDialog(CExportDlg::IDD, pParent), 
	  m_bSingleTaskList(bSingleTaskList), 
	  m_sFilePath(szFilePath),
	  m_sFolderPath(szFolderPath)
{
	//{{AFX_DATA_INIT(CExportDlg)
	m_bSelTaskOnly = FALSE;
	//}}AFX_DATA_INIT

	if (m_bSingleTaskList)
		m_nExportOption = ACTIVETASKLIST;
	else
		m_nExportOption = AfxGetApp()->GetProfileInt("Exporting", "ExportOption", ACTIVETASKLIST);

	m_nFormatOption = AfxGetApp()->GetProfileInt("Exporting", "FormatOption", ED_HTMLFMT);
	m_bIncludeDone = AfxGetApp()->GetProfileInt("Exporting", "IncludeDone", TRUE);
	m_bIncludeNotDone = AfxGetApp()->GetProfileInt("Exporting", "IncludeNotDone", TRUE);

	if (m_sFolderPath.IsEmpty())
		m_sFolderPath = AfxGetApp()->GetProfileString("Exporting", "LastFolder");

	if (m_bSingleTaskList || m_nExportOption == ACTIVETASKLIST)
		m_bExportOneFile = TRUE;
	else 
		m_bExportOneFile = AfxGetApp()->GetProfileInt("Exporting", "ExportOneFile", FALSE);

	if (m_bSingleTaskList || m_nExportOption == ACTIVETASKLIST || m_bExportOneFile)
	{
		m_sExportPath = m_sFilePath; // default

		if (m_sFilePath.IsEmpty() && !m_sFolderPath.IsEmpty())
		{
			char szFName[_MAX_FNAME];
			_splitpath(m_sFilePath, NULL, NULL, szFName, NULL);
			_makepath(m_sExportPath.GetBuffer(MAX_PATH), NULL, m_sFolderPath, szFName, NULL);
			m_sExportPath.ReleaseBuffer();
		}
				
		ReplaceExtension(m_sExportPath, m_nFormatOption);
	}
	else // multiple files
	{
		if (!m_sFolderPath.IsEmpty())
			m_sExportPath = m_sFolderPath;

		else if (!m_sFilePath.IsEmpty())
		{
			char szDrive[_MAX_DRIVE], szPath[MAX_PATH];
			_splitpath(m_sFilePath, szDrive, szPath, NULL, NULL);
			_makepath(m_sExportPath.GetBuffer(MAX_PATH), szDrive, szPath, NULL, NULL);
			m_sExportPath.ReleaseBuffer();
		}
	}
}


void CExportDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExportDlg)
	DDX_Control(pDX, IDC_EXPORTPATH, m_eExportPath);
	DDX_CBIndex(pDX, IDC_TASKLISTOPTIONS, m_nExportOption);
	DDX_CBIndex(pDX, IDC_FORMATOPTIONS, m_nFormatOption);
	DDX_Text(pDX, IDC_EXPORTPATH, m_sExportPath);
	DDX_Check(pDX, IDC_INCLUDEDONE, m_bIncludeDone);
	DDX_Check(pDX, IDC_INCLUDENOTDONE, m_bIncludeNotDone);
	DDX_Check(pDX, IDC_EXPORTONEFILE, m_bExportOneFile);
	DDX_Radio(pDX, IDC_ALLTASKS, m_bSelTaskOnly);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CExportDlg, CDialog)
	//{{AFX_MSG_MAP(CExportDlg)
	ON_CBN_SELCHANGE(IDC_TASKLISTOPTIONS, OnSelchangeTasklistoptions)
	ON_CBN_SELCHANGE(IDC_FORMATOPTIONS, OnSelchangeFormatoptions)
	ON_BN_CLICKED(IDC_EXPORTONEFILE, OnExportonefile)
	ON_BN_CLICKED(IDC_INCLUDEDONE, OnInclude)
	ON_EN_CHANGE(IDC_EXPORTPATH, OnChangeExportpath)
	ON_BN_CLICKED(IDC_INCLUDENOTDONE, OnInclude)
	ON_BN_CLICKED(IDC_ALLTASKS, OnChangeTaskOption)
	ON_BN_CLICKED(IDC_SELTASK, OnChangeTaskOption)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExportDlg message handlers

BOOL CExportDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	CDialogHelper::SetFont(this, (HFONT)GetStockObject(DEFAULT_GUI_FONT), FALSE);
	
	// set initial control states
	GetDlgItem(IDC_TASKLISTOPTIONS)->EnableWindow(!m_bSingleTaskList);
	GetDlgItem(IDC_EXPORTONEFILE)->EnableWindow(!m_bSingleTaskList && m_nExportOption == ALLTASKLISTS);
	GetDlgItem(IDC_INCLUDEDONE)->EnableWindow(!m_bSelTaskOnly);
	GetDlgItem(IDC_INCLUDENOTDONE)->EnableWindow(!m_bSelTaskOnly);

	m_eExportPath.SetFilter(m_nFormatOption == ED_HTMLFMT ? HTMLFILTER : TEXTFILTER);
	m_eExportPath.EnableStyle(FES_FOLDERS, (m_nExportOption == ALLTASKLISTS && !m_bExportOneFile));

	EnableOK();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CExportDlg::OnSelchangeTasklistoptions() 
{
	UpdateData();

	// can't do all tasklists and selected item
	if (m_bSelTaskOnly && m_nExportOption == ALLTASKLISTS)
		m_bSelTaskOnly = FALSE;
	
	// only process this notification if something's _really_ changed
	if (!(m_nExportOption == ALLTASKLISTS && m_bExportOneFile))
	{
		// check file extension is correct
		m_eExportPath.EnableStyle(FES_FOLDERS, (m_nExportOption == ALLTASKLISTS && !m_bExportOneFile));

		if (m_nExportOption == ALLTASKLISTS && !m_bExportOneFile)
		{
			m_sExportPath = m_sFolderPath;
		}
		else
		{
			m_sExportPath = m_sFilePath;
			ReplaceExtension(m_sExportPath, m_nFormatOption);
		}
	}

	GetDlgItem(IDC_EXPORTONEFILE)->EnableWindow(!m_bSingleTaskList && m_nExportOption == ALLTASKLISTS);

	UpdateData(FALSE);
}

void CExportDlg::OnSelchangeFormatoptions() 
{
	UpdateData();

	// check file extension is correct
	m_eExportPath.SetFilter(m_nFormatOption == ED_HTMLFMT ? HTMLFILTER : TEXTFILTER);

	if ((m_nExportOption == ACTIVETASKLIST || m_bExportOneFile) && !m_sExportPath.IsEmpty())
	{
		ReplaceExtension(m_sExportPath, m_nFormatOption);
		UpdateData(FALSE);
	}
}

void CExportDlg::ReplaceExtension(CString& sPathName, int nFormat)
{
	char szDrive[_MAX_DRIVE], szFolder[MAX_PATH], szFName[_MAX_FNAME];
	_splitpath(sPathName, szDrive, szFolder, szFName, NULL);

	switch (nFormat)
	{
	case ED_HTMLFMT:
		sPathName.Format("%s%s%s.html", szDrive, szFolder, szFName);
		break;

	case ED_TEXTFMT:
		sPathName.Format("%s%s%s.txt", szDrive, szFolder, szFName);
		break;

	default:
		ASSERT (0);
		break;
	}
}

void CExportDlg::OnOK()
{
	// make sure the output folder is valid
	BOOL bBadFolder = (m_nExportOption == ALLTASKLISTS && !m_bExportOneFile) ? 
						!CreateFolder(m_sExportPath) : !CreateFolderFromFilePath(m_sExportPath);

	if (bBadFolder)
	{
		CString sMessage;
		sMessage.Format("The output path '%s' could not be created.\n\nDo you want to specify another location?",
						m_sExportPath);
						
		UINT nRet = MessageBox(sMessage, "Unable to Create Path", MB_YESNO);

		switch (nRet)
		{
		case IDNO:
			EndDialog(IDCANCEL);
			return;

		case IDYES:
			m_sExportPath.Empty();
			m_eExportPath.SetFocus();
			UpdateData(FALSE);
			EnableOK();
			return;
		}
	}

	CDialog::OnOK();

	// make sure extension is right
	if (m_nExportOption == ACTIVETASKLIST || m_bExportOneFile)
		ReplaceExtension(m_sExportPath, m_nFormatOption);

	if (!m_bSingleTaskList)
	{
		AfxGetApp()->WriteProfileInt("Exporting", "ExportOption", m_nExportOption);
		AfxGetApp()->WriteProfileInt("Exporting", "ExportOneFile", m_bExportOneFile);

		if (m_nExportOption == ALLTASKLISTS)
			AfxGetApp()->WriteProfileString("Exporting", "LastFolder", m_sExportPath);
		else
			AfxGetApp()->WriteProfileString("Exporting", "LastFolder", m_sFolderPath);
	}

	AfxGetApp()->WriteProfileInt("Exporting", "FormatOption", m_nFormatOption);
	AfxGetApp()->WriteProfileInt("Exporting", "IncludeDone", m_bIncludeDone);
	AfxGetApp()->WriteProfileInt("Exporting", "IncludeNotDone", m_bIncludeNotDone);
}

BOOL CExportDlg::GetExportAllTasklists()
{
	return (!m_bSingleTaskList && m_nExportOption == ALLTASKLISTS);
}

void CExportDlg::OnExportonefile() 
{
	UpdateData();

	m_eExportPath.EnableStyle(FES_FOLDERS, (m_nExportOption == ALLTASKLISTS && !m_bExportOneFile));

	if (m_nExportOption == ALLTASKLISTS && !m_bExportOneFile)
		m_sExportPath = m_sFolderPath;
	else
		m_sExportPath = m_sFilePath;

	if (m_nExportOption == ACTIVETASKLIST || m_bExportOneFile)
		ReplaceExtension(m_sExportPath, m_nFormatOption);

	UpdateData(FALSE);
}

void CExportDlg::EnableOK()
{
	GetDlgItem(IDOK)->EnableWindow((m_bIncludeDone || m_bIncludeNotDone) && 
									!m_sExportPath.IsEmpty());
}

void CExportDlg::OnInclude() 
{
	UpdateData();
	EnableOK();
}

void CExportDlg::OnChangeExportpath() 
{
	UpdateData();
	EnableOK();

	if (m_nExportOption == ACTIVETASKLIST || m_bExportOneFile)
		m_sFilePath = m_sExportPath;
	else
		m_sFolderPath = m_sExportPath;
}

void CExportDlg::OnChangeTaskOption() 
{
	UpdateData();

	if (m_bSelTaskOnly && m_nExportOption == ALLTASKLISTS)
	{
		m_nExportOption = ACTIVETASKLIST;
		UpdateData(FALSE);

		OnSelchangeTasklistoptions();
	}
	
	GetDlgItem(IDC_INCLUDEDONE)->EnableWindow(!m_bSelTaskOnly);
	GetDlgItem(IDC_INCLUDENOTDONE)->EnableWindow(!m_bSelTaskOnly);
}
