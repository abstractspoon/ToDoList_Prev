// DateHelper.h: interface for the CDateHelper class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATEHELPER_H__2A4E63F6_A106_4295_BCBA_06D03CD67AE7__INCLUDED_)
#define AFX_DATEHELPER_H__2A4E63F6_A106_4295_BCBA_06D03CD67AE7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

enum DH_DATE
{
	DHD_TODAY,
	DHD_TOMORROW,
	DHD_ENDTHISWEEK, // start of week + 7
	DHD_ENDNEXTWEEK, // DHD_ENDTHISWEEK + 7
	DHD_ENDTHISMONTH, // begining of next month - 1
	DHD_ENDNEXTMONTH, // get's trickier :)
	DHD_ENDTHISYEAR,
	DHD_ENDNEXTYEAR,

};

class CDateHelper  
{
public:
	static int CalcDaysFromTo(const COleDateTime& dateFrom, const COleDateTime& dateTo, BOOL bInclusive);
	static int CalcDaysFromTo(const COleDateTime& dateFrom, DH_DATE nTo, BOOL bInclusive);
	static int CalcDaysFromTo(DH_DATE nFrom, DH_DATE nTo, BOOL bInclusive);
	static double GetDate(DH_DATE nDate); // 12am

	static int CalcWeekdaysFromTo(const COleDateTime& dateFrom, const COleDateTime& dateTo, BOOL bInclusive);

	// DOW = 'day of week'
	static CString FormatDate(const COleDateTime& date, BOOL bISOFormat = FALSE, BOOL bWantDOW = FALSE);
	static CString FormatCurrentDate(BOOL bISOFormat = FALSE, BOOL bWantDOW = FALSE);

	static int FirstDayOfWeek();
	static CString GetShortWeekday(int nWeekday); // 1-7, sun-sat
};

#endif // !defined(AFX_DATEHELPER_H__2A4E63F6_A106_4295_BCBA_06D03CD67AE7__INCLUDED_)
