#include "stdafx.h"
#include "webmisc.h"
#include "misc.h"
#include "xmlcharmap.h"

#include <wininet.h>
#include <shlwapi.h>

#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "shlwapi.lib")

///////////////////////////////////////////////////////////////////////////////////////////////////

BOOL WebMisc::IsOnline()
{
    DWORD dwState = 0; 
    DWORD dwSize = sizeof(DWORD);
	
    return InternetQueryOption(NULL, INTERNET_OPTION_CONNECTED_STATE, &dwState, &dwSize) && 
		(dwState & INTERNET_STATE_CONNECTED);
}

BOOL WebMisc::DeleteCacheEntry(LPCTSTR szURI)
{
	BOOL bSuccess = FALSE;

#if _MSC_VER >= 1400
	bSuccess = DeleteUrlCacheEntry(szURI);
#elif _UNICODE
	LPSTR szAnsiPath = Misc::WideToMultiByte(szURI);
	bSuccess = DeleteUrlCacheEntry(szAnsiPath);
	delete [] szAnsiPath;
#else
	bSuccess = DeleteUrlCacheEntry(szURI);
#endif

	return bSuccess;
}

BOOL WebMisc::IsURL(LPCTSTR szURL)
{
	if (::PathIsURL(szURL))
		return TRUE;

	CString sURL(szURL);

	sURL.TrimLeft();
	sURL.MakeLower();

	return ((sURL.Find(_T("www.")) == 0) || (sURL.Find(_T("ftp.")) == 0));
}

int WebMisc::ExtractFirstHtmlLink(const CString& sHtml, CString& sLink, CString& sText)
{
	return ExtractNextHtmlLink(sHtml, 0, sLink, sText);
}

int WebMisc::ExtractNextHtmlLink(const CString& sHtml, int nFrom, CString& sLink, CString& sText)
{
	const CString LINK_START(_T("href=\"")), LINK_END(_T("\""));
	const CString TEXT_START(_T(">")), TEXT_END(_T("</a>"));

	int nStart = sHtml.Find(LINK_START, nFrom), nEnd = -1;

	if (nStart == -1)
		return -1;

	nStart += LINK_START.GetLength();
	nEnd = sHtml.Find(LINK_END, nStart);

	if (nEnd == -1)
		return -1;

	sLink = sHtml.Mid(nStart, (nEnd - nStart));

	// get text
	nStart = sHtml.Find(TEXT_START, nEnd + 1);

	if (nStart == -1)
		return -1;

	nStart += TEXT_START.GetLength();
	nEnd = sHtml.Find(TEXT_END, nStart);

	if (nEnd == -1)
		return -1;

	sText = sHtml.Mid(nStart, (nEnd - nStart));

	// cleanup
	Misc::Trim(sText, _T("\" "));

	// translate HTML represenations
	CXmlCharMap::ConvertFromRep(sText);

	return (nEnd + TEXT_END.GetLength());
}

int WebMisc::ExtractHtmlLinks(const CString& sHtml, CStringArray& aLinks, CStringArray& aLinkText)
{
	CString sLink, sText;
	int nFind = ExtractFirstHtmlLink(sHtml, sLink, sText);

	while (nFind != -1)
	{
		aLinks.Add(sLink);
		aLinkText.Add(sText);

		// next link
		nFind = ExtractNextHtmlLink(sHtml, nFind, sLink, sText);
	}
	ASSERT(aLinkText.GetSize() == aLinks.GetSize());

	return aLinks.GetSize();
}
