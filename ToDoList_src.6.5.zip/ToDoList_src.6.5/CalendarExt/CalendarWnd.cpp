// CalendarFrameWnd.cpp : implementation file
//

#include "stdafx.h"
#include "CalendarExt.h"
#include "CalendarExtResource.h"
#include "CalendarData.h"
#include "CalendarUtils.h"
#include "calendarprefsdlg.h"
#include "CalendarWnd.h"

#include "..\Shared\DialogHelper.h"
#include "..\Shared\DateHelper.h"
#include "..\Shared\TimeHelper.h"
#include "..\Shared\FileMisc.h"
#include "..\Shared\UITheme.h"
#include "..\Shared\themed.h"
#include "..\Shared\dlgunits.h"
#include "..\shared\VersionInfo.h"
#include "..\shared\IPreferences.h"
#include "..\shared\misc.h"

#include "..\todolist\tdcmsg.h"
#include "..\todolist\tdcenum.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define CALENDAR_INI_KEY_SHOWMINICAL		_T("ShowMiniCalendar")
#define CALENDAR_INI_KEY_SHOWSTATUSBAR		_T("ShowStatusBar")
#define CALENDAR_INI_KEY_SHOWWEEKENDS		_T("ShowWeekends")
#define CALENDAR_INI_KEY_NUMWEEKS			_T("NumWeeks")
#define CALENDAR_INI_KEY_WINDOWSIZE			_T("WindowSize")
#define CALENDAR_INI_KEY_COMPLETEDTASKS		_T("CompletedTasks")
#define CALENDAR_INI_KEY_DISPLAYFLAGS		_T("CompletedTasks")
#define CALENDAR_INI_KEY_CELLFONTSIZE		_T("CellFontSize")

const int MINICALWIDTH = 160;
const int BUTTONSWIDTH = 100;
const int BUTTONSHEIGHT = 75;
const int STATUSBARHEIGHT = 22;

/////////////////////////////////////////////////////////////////////////////
// CCalendarWnd

IMPLEMENT_DYNAMIC(CCalendarWnd, CWnd)

CCalendarWnd::CCalendarWnd()
:	m_hParentOfFrame(NULL),
	m_pCalendarData(NULL),
	m_bShowMiniCalendar(TRUE),
	m_bShowStatusBar(FALSE),
	m_bShowWeekends(TRUE),
	m_nNumVisibleWeeks(6),
	m_nCellFontSize(8),
	m_dwDisplayFlags(DISPLAY_DEFAULT),
	m_hIcon(NULL)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_CALENDAR);
	m_pCalendarData = new CCalendarData;
}

CCalendarWnd::~CCalendarWnd()
{
	delete m_pCalendarData;
}


BEGIN_MESSAGE_MAP(CCalendarWnd, CWnd)
	//{{AFX_MSG_MAP(CCalendarWnd)
	ON_WM_SETFOCUS()
	ON_WM_SIZE()
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_COMMAND(ID_VIEW_MINICALENDAR, OnViewMiniCalendar)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MINICALENDAR, OnUpdateViewMiniCalendar)
	ON_COMMAND(ID_VIEW_STATUSBAR, OnViewStatusBar)
	ON_UPDATE_COMMAND_UI(ID_VIEW_STATUSBAR, OnUpdateViewStatusBar)
	ON_COMMAND(ID_VIEW_WEEKENDS, OnViewWeekends)
	ON_UPDATE_COMMAND_UI(ID_VIEW_WEEKENDS, OnUpdateViewWeekends)
	ON_COMMAND(ID_VIEW_PREFS, OnViewPrefs)
	ON_UPDATE_COMMAND_UI(ID_VIEW_PREFS, OnUpdateViewPrefs)
	ON_COMMAND(ID_VIEW_NUMWEEKS_1, OnViewNumWeeks1)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NUMWEEKS_1, OnUpdateViewNumWeeks1)
	ON_COMMAND(ID_VIEW_NUMWEEKS_2, OnViewNumWeeks2)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NUMWEEKS_2, OnUpdateViewNumWeeks2)
	ON_COMMAND(ID_VIEW_NUMWEEKS_3, OnViewNumWeeks3)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NUMWEEKS_3, OnUpdateViewNumWeeks3)
	ON_COMMAND(ID_VIEW_NUMWEEKS_4, OnViewNumWeeks4)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NUMWEEKS_4, OnUpdateViewNumWeeks4)
	ON_COMMAND(ID_VIEW_NUMWEEKS_5, OnViewNumWeeks5)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NUMWEEKS_5, OnUpdateViewNumWeeks5)
	ON_COMMAND(ID_VIEW_NUMWEEKS_6, OnViewNumWeeks6)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NUMWEEKS_6, OnUpdateViewNumWeeks6)
	ON_COMMAND(ID_VIEW_NUMWEEKS_7, OnViewNumWeeks7)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NUMWEEKS_7, OnUpdateViewNumWeeks7)
	ON_COMMAND(ID_VIEW_NUMWEEKS_8, OnViewNumWeeks8)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NUMWEEKS_8, OnUpdateViewNumWeeks8)
	ON_COMMAND(ID_VIEW_NUMWEEKS_9, OnViewNumWeeks9)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NUMWEEKS_9, OnUpdateViewNumWeeks9)
	ON_COMMAND(ID_GOTOTODAY, OnGoToToday)
	ON_UPDATE_COMMAND_UI(ID_GOTOTODAY, OnUpdateGoToToday)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCalendarWnd message handlers

BOOL CCalendarWnd::Create(DWORD dwStyle, const RECT &rect, CWnd* pParentWnd, UINT nID)
{
	return CWnd::CreateEx(0, NULL, NULL, dwStyle, rect, pParentWnd, nID);
}

void CCalendarWnd::SavePreferences(IPreferences* pPrefs, LPCTSTR szKey) const 
{
	CString sKey(szKey);
	sKey += _T("\\Calendar");

	pPrefs->WriteProfileInt(sKey, CALENDAR_INI_KEY_SHOWMINICAL, m_bShowMiniCalendar);
	pPrefs->WriteProfileInt(sKey, CALENDAR_INI_KEY_SHOWSTATUSBAR, m_bShowStatusBar);
	pPrefs->WriteProfileInt(sKey, CALENDAR_INI_KEY_SHOWWEEKENDS, m_bShowWeekends);
	pPrefs->WriteProfileInt(sKey, CALENDAR_INI_KEY_NUMWEEKS, m_nNumVisibleWeeks);
	pPrefs->WriteProfileInt(sKey, CALENDAR_INI_KEY_DISPLAYFLAGS, m_dwDisplayFlags);
	pPrefs->WriteProfileInt(sKey, CALENDAR_INI_KEY_CELLFONTSIZE, m_nCellFontSize);
}

void CCalendarWnd::LoadPreferences(const IPreferences* pPrefs, LPCTSTR szKey) 
{
	CString sKey(szKey);
	sKey += _T("\\Calendar");

	m_bShowMiniCalendar = pPrefs->GetProfileInt(sKey, CALENDAR_INI_KEY_SHOWMINICAL, m_bShowMiniCalendar);
	m_bShowStatusBar = FALSE;//pPrefs->GetProfileInt(sKey, CALENDAR_INI_KEY_SHOWSTATUSBAR, m_bShowStatusBar);
	m_bShowWeekends = pPrefs->GetProfileInt(sKey, CALENDAR_INI_KEY_SHOWWEEKENDS, m_bShowWeekends);
	m_nNumVisibleWeeks = pPrefs->GetProfileInt(sKey, CALENDAR_INI_KEY_NUMWEEKS, m_nNumVisibleWeeks);
	m_nCellFontSize = pPrefs->GetProfileInt(sKey, CALENDAR_INI_KEY_CELLFONTSIZE, m_nCellFontSize);
	m_dwDisplayFlags = pPrefs->GetProfileInt(sKey, CALENDAR_INI_KEY_DISPLAYFLAGS, m_dwDisplayFlags);

	// make sure 'today' is visible
	m_BigCalendar.SelectDate(COleDateTime::GetCurrentTime());
}

void CCalendarWnd::SetUITheme(const UITHEME* pTheme)
{
	if (CThemed::IsThemeActive())
	{
		m_StatusBar.SetUIColors(pTheme->crStatusBarLight, pTheme->crStatusBarDark, 
								pTheme->crStatusBarText, pTheme->HasGradient(), pTheme->HasGlass());
	}
}

LPCTSTR CCalendarWnd::GetMenuText() const
{
	return _T("Calendar");
}

LPCTSTR CCalendarWnd::GetTypeID() const
{
	static CString sID;

	Misc::GuidToString(CAL_TYPEID, sID); 

	return sID;
}

bool CCalendarWnd::ProcessMessage(MSG* pMsg) 
{
	if (!IsWindowEnabled())
		return false;

	// process editing shortcuts
	// TODO

	return false;
}

BOOL CCalendarWnd::GetLabelEditRect(LPRECT pEdit) const
{
	if (m_BigCalendar.GetSelectedTaskEditRect(pEdit))
	{
		// convert to our coordinates
		m_BigCalendar.ClientToScreen(pEdit);
		ScreenToClient(pEdit);
		::InflateRect(pEdit, 2, 2);
		return TRUE;
	}

	// else
	return FALSE;
}

bool CCalendarWnd::WantUpdate(int nAttribute) const
{
	switch (nAttribute)
	{
	case TDCA_TASKNAME:
	case TDCA_DONEDATE:
	case TDCA_DUEDATE:
	case TDCA_STARTDATE:
	case TDCA_PERCENT:
	case TDCA_TIMEEST:
	case TDCA_TIMESPENT:
		return true;
	}

	// all else 
	return false;
}

void CCalendarWnd::UpdateTasks(const ITaskList* pTasks, DWORD dwFlags, int nEditAttribute)
{
	m_strTasklistName = pTasks->GetProjectName();
	UpdateTitleBarText();

	if (m_pCalendarData->TasklistUpdated(pTasks, dwFlags, nEditAttribute))
	{
		//notify bigcal that data has been updated
		m_BigCalendar.TasklistUpdated();

		//notify minical that data has been updated
		m_MiniCalendar.TasklistUpdated();
	}
	else
	{
		// TODO
	}
}

void CCalendarWnd::Release()
{
	if (GetSafeHwnd())
		DestroyWindow();
	
	delete this;
}

void CCalendarWnd::OnSetFocus(CWnd* pOldWnd)
{
	//set focus to big calendar (seems the focus gets lost after switching back to the Calendar window from another app)
	m_BigCalendar.SetFocus();
}

void CCalendarWnd::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);

	if (m_BigCalendar.GetSafeHwnd())
		ResizeControls(cx, cy);
}

int CCalendarWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	//set the title of the window
	UpdateTitleBarText();

	//set the pointer to the data object
	m_MiniCalendar.Initialize(this, m_pCalendarData);
	m_BigCalendar.Initialize(this, m_pCalendarData, m_hParentOfFrame);

	//create mini-calendar ctrl
	m_MiniCalendar.Create(NULL, NULL, WS_CHILD | WS_VISIBLE, CRect(0,0,0,0), this, 1);

	//create big-calendar ctrl
	m_BigCalendar.Create(WS_CHILD | WS_VISIBLE, CRect(0,0,0,0), this, 1);

	m_dlgBtns.Create(this);
	m_penBorder.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_3DSHADOW));

	//create statusbar ctrl
	VERIFY(InitStatusBar());

	return 0;
}

BOOL CCalendarWnd::OnEraseBkgnd(CDC* pDC)
{
	// clip out children
	CDialogHelper::ExcludeChild(this, pDC, &m_dlgBtns);
	CDialogHelper::ExcludeChild(this, pDC, &m_MiniCalendar);
	CDialogHelper::ExcludeChild(this, pDC, &m_BigCalendar);

	// fill what's left
	CRect rClient;
	GetClientRect(rClient);

	pDC->FillSolidRect(rClient, GetSysColor(COLOR_WINDOW));

	// draw frame in gray
	CPen* pOldPen = pDC->SelectObject(&m_penBorder);
	pDC->Rectangle(rClient);
	pDC->SelectObject(pOldPen);

	return TRUE;
}

void CCalendarWnd::OnViewMiniCalendar()
{
	m_bShowMiniCalendar = !m_bShowMiniCalendar;

	//show/hide the minicalendar as necessary
	if (m_bShowMiniCalendar)
	{
		m_MiniCalendar.ShowWindow(SW_SHOW);
	}
	else
	{
		m_MiniCalendar.ShowWindow(SW_HIDE);
	}

	//call ResizeControls which will resize both calendars
	CRect rcFrame;
	GetClientRect(rcFrame);
	ResizeControls(rcFrame.Width(), rcFrame.Height());
}
void CCalendarWnd::OnUpdateViewMiniCalendar(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(TRUE);

	if (m_bShowMiniCalendar)
	{
		pCmdUI->SetCheck(1);
	}
	else
	{
		pCmdUI->SetCheck(0);
	}
}

void CCalendarWnd::OnViewStatusBar()
{
	m_bShowStatusBar = !m_bShowStatusBar;

	//show/hide the status-bar as necessary
	if (m_bShowStatusBar)
	{
		m_StatusBar.ShowWindow(SW_SHOW);
	}
	else
	{
		m_StatusBar.ShowWindow(SW_HIDE);
	}

	//call ResizeControls which will resize both calendars
	CRect rcFrame;
	GetClientRect(rcFrame);
	ResizeControls(rcFrame.Width(), rcFrame.Height());
}

void CCalendarWnd::OnUpdateViewStatusBar(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(TRUE);

	if (m_bShowStatusBar)
	{
		pCmdUI->SetCheck(1);
	}
	else
	{
		pCmdUI->SetCheck(0);
	}
}

void CCalendarWnd::OnViewWeekends() 
{
	m_bShowWeekends = !m_bShowWeekends;

	//repopulate the calendars
	m_MiniCalendar.Repopulate();
	m_BigCalendar.Repopulate();

	//call ResizeControls which will resize both calendars
	CRect rcFrame;
	GetClientRect(rcFrame);
	ResizeControls(rcFrame.Width(), rcFrame.Height());
	Invalidate();
}

void CCalendarWnd::OnUpdateViewWeekends(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(TRUE);
	pCmdUI->SetCheck(m_bShowWeekends);
}

void CCalendarWnd::OnViewPrefs()
{
	//show dialog
	CCalendarPrefsDlg dlg(m_dwDisplayFlags, m_nCellFontSize);

	if (dlg.DoModal() == IDOK)
	{
		if (dlg.GetFlags() != m_dwDisplayFlags || dlg.GetCellFontSize() != m_nCellFontSize)
		{
			m_dwDisplayFlags = dlg.GetFlags();
			m_nCellFontSize = dlg.GetCellFontSize();

			//repopulate the calendars
			m_MiniCalendar.Repopulate();
			m_BigCalendar.Repopulate(m_nCellFontSize);
		}
	}

	//set focus to big calendar (seems the focus gets lost after the dialog is shown)
	m_BigCalendar.SetFocus();
}

void CCalendarWnd::OnUpdateViewPrefs(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(TRUE);
}

void CCalendarWnd::OnViewNumWeeks1()
{
	m_nNumVisibleWeeks = 1;

	//repopulate the calendars
	m_MiniCalendar.Repopulate();
	m_BigCalendar.Repopulate();
}

void CCalendarWnd::OnUpdateViewNumWeeks1(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(TRUE);
	pCmdUI->SetCheck(m_nNumVisibleWeeks == 1);
}

void CCalendarWnd::OnViewNumWeeks2()
{
	m_nNumVisibleWeeks = 2;

	//repopulate the calendars
	m_MiniCalendar.Repopulate();
	m_BigCalendar.Repopulate();
}

void CCalendarWnd::OnUpdateViewNumWeeks2(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(TRUE);
	pCmdUI->SetCheck(m_nNumVisibleWeeks == 2);
}

void CCalendarWnd::OnViewNumWeeks3()
{
	m_nNumVisibleWeeks = 3;

	//repopulate the calendars
	m_MiniCalendar.Repopulate();
	m_BigCalendar.Repopulate();
}

void CCalendarWnd::OnUpdateViewNumWeeks3(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(TRUE);
	pCmdUI->SetCheck(m_nNumVisibleWeeks == 3);
}

void CCalendarWnd::OnViewNumWeeks4()
{
	m_nNumVisibleWeeks = 4;

	//repopulate the calendars
	m_MiniCalendar.Repopulate();
	m_BigCalendar.Repopulate();
}

void CCalendarWnd::OnUpdateViewNumWeeks4(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(TRUE);
	pCmdUI->SetCheck(m_nNumVisibleWeeks == 4);
}

void CCalendarWnd::OnViewNumWeeks5()
{
	m_nNumVisibleWeeks = 5;

	//repopulate the calendars
	m_MiniCalendar.Repopulate();
	m_BigCalendar.Repopulate();
}

void CCalendarWnd::OnUpdateViewNumWeeks5(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(TRUE);
	pCmdUI->SetCheck(m_nNumVisibleWeeks == 5);
}

void CCalendarWnd::OnViewNumWeeks6()
{
	m_nNumVisibleWeeks = 6;

	//repopulate the calendars
	m_MiniCalendar.Repopulate();
	m_BigCalendar.Repopulate();
}
void CCalendarWnd::OnUpdateViewNumWeeks6(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(TRUE);
	pCmdUI->SetCheck(m_nNumVisibleWeeks == 6);
}

void CCalendarWnd::OnViewNumWeeks7()
{
	m_nNumVisibleWeeks = 7;

	//repopulate the calendars
	m_MiniCalendar.Repopulate();
	m_BigCalendar.Repopulate();
} 

void CCalendarWnd::OnUpdateViewNumWeeks7(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(TRUE);
	pCmdUI->SetCheck(m_nNumVisibleWeeks == 7);
}

void CCalendarWnd::OnViewNumWeeks8()
{
	m_nNumVisibleWeeks = 8;

	//repopulate the calendars
	m_MiniCalendar.Repopulate();
	m_BigCalendar.Repopulate();
} 

void CCalendarWnd::OnUpdateViewNumWeeks8(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(TRUE);
	pCmdUI->SetCheck(m_nNumVisibleWeeks == 8);
}

void CCalendarWnd::OnViewNumWeeks9()
{
	m_nNumVisibleWeeks = 9;

	//repopulate the calendars
	m_MiniCalendar.Repopulate();
	m_BigCalendar.Repopulate();
} 

void CCalendarWnd::OnUpdateViewNumWeeks9(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(TRUE);
	pCmdUI->SetCheck(m_nNumVisibleWeeks == 9);
}

void CCalendarWnd::OnGoToToday()
{
	m_MiniCalendar.SelectToday();
} 

void CCalendarWnd::OnUpdateGoToToday(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(TRUE);
}

void CCalendarWnd::ResizeControls(int cx, int cy)
{
	CRect rClient(0, 0, cx, cy);
	rClient.DeflateRect(1, 1);

	int nMiniCalWidth = (m_bShowMiniCalendar ? MINICALWIDTH : 0);
	int nBtnsWidth = BUTTONSWIDTH;

	// status bar
	CRect rItem(rClient);
	rItem.top = rItem.bottom - GetStatusBarHeight();
	m_StatusBar.MoveWindow(rItem);

	// buttons
	rItem.right = rItem.left + nBtnsWidth;
	rItem.bottom = rItem.top;
	rItem.top -= BUTTONSHEIGHT;

	m_dlgBtns.MoveWindow(rItem);

	// mini-cal
	rItem.right = rItem.left + nMiniCalWidth;
	rItem.bottom = rItem.top;
	rItem.top = rClient.top;

	m_MiniCalendar.MoveWindow(rItem);

	// big-cal
	rItem.top = rClient.top;
	rItem.bottom = rClient.bottom - GetStatusBarHeight();
	rItem.left = max(nBtnsWidth, nMiniCalWidth);
	rItem.right = rClient.right;

	m_BigCalendar.MoveWindow(rItem);

	Invalidate(TRUE);
}

BOOL CCalendarWnd::OnNotify(WPARAM wParam,
								 LPARAM lParam,
								 LRESULT* pResult) 
{
	NMHDR* pNotifyArea = (NMHDR*)lParam;
	if (pNotifyArea->code == CALENDAR_MSG_SELECTDATE)
	{
		if (pNotifyArea->hwndFrom == m_MiniCalendar.GetSafeHwnd())
		{
			//send SelectDate message to BigCalendar
			COleDateTime dt;
			m_MiniCalendar.GetSelectedDate(dt);
			m_BigCalendar.SelectDate(dt);

			//set focus to big calendar
			m_BigCalendar.SetFocus();
		}
		else if (pNotifyArea->hwndFrom == m_BigCalendar.GetSafeHwnd())
		{
			//send SelectDate message to MiniCalendar (even if hidden)
			COleDateTime dt;
			m_BigCalendar.GetSelectedDate(dt);
			m_MiniCalendar.SelectDate(dt);
		}
		else
		{
			//ASSERT(FALSE);	//who sent it then?
		}

		//selection changed (possibly) - update the status bar with the info of the newly selected item
		UpdateStatusBar();
	}
	else if (pNotifyArea->code == CALENDAR_MSG_SELECTTASK)
	{
		AfxGetMainWnd()->SendMessage(WM_TDCM_TASKLINK, m_BigCalendar.GetSelectedTask(), 0L);
	}
	else if (pNotifyArea->code == CALENDAR_MSG_MOUSEWHEEL_UP)
	{
		m_BigCalendar.OnMouseWheel(0, 1, CPoint(0,0));
	}
	else if (pNotifyArea->code == CALENDAR_MSG_MOUSEWHEEL_DOWN)
	{
		m_BigCalendar.OnMouseWheel(0, -1, CPoint(0,0));
	}
	else if (pNotifyArea->code == NM_CLICK)
	{
		if (pNotifyArea->hwndFrom == m_MiniCalendar.GetSafeHwnd())
		{
			//set focus to big calendar
			m_BigCalendar.SetFocus();
		}
		else if (pNotifyArea->hwndFrom == m_BigCalendar.GetSafeHwnd())
		{
			//not bothered
		}
		else if (pNotifyArea->hwndFrom == m_StatusBar.GetSafeHwnd())
		{
			//not bothered
		}
		else
		{
			//ASSERT(FALSE);	//who sent it then?
		}
	}
	return CWnd::OnNotify(wParam, lParam, pResult);
}

DWORD CCalendarWnd::GetDisplayFlags() const
{
	return m_dwDisplayFlags;
}

int CCalendarWnd::GetNumWeeksToDisplay() const
{
	int nReturn = 6;
	if ((m_nNumVisibleWeeks > 0) && (m_nNumVisibleWeeks < 10))
	{
		nReturn = m_nNumVisibleWeeks;
	}
	else
	{
		//ASSERT(FALSE);
	}
	return nReturn;
}

int CCalendarWnd::GetNumDaysToDisplay() const
{
	if (m_bShowWeekends)
	{
		return 7;
	}
	else
	{
		return 5;
	}
}

BOOL CCalendarWnd::IsWeekendsHidden() const
{
	return !m_bShowWeekends;
}

//if date is a weekend and weekends are hidden, returns TRUE
BOOL CCalendarWnd::IsDateHidden(const COleDateTime& _dt) const
{
	if (!m_bShowWeekends)
	{
		int nDayOfWeek = _dt.GetDayOfWeek();
		if ((nDayOfWeek == 1) || (nDayOfWeek == 7)) //7=sat 1=sun
		{
			return TRUE;
		}
	}
	return FALSE;
}

void CCalendarWnd::UpdateTitleBarText()
{
	CString strAppName;
	strAppName.LoadString(IDR_CALENDAR);

	CString strWindowText(strAppName);

	if (!m_strTasklistName.IsEmpty())
		strWindowText.Format(_T("%s - %s"), m_strTasklistName, strAppName);

	SetWindowText(strWindowText);
}

int CCalendarWnd::GetStatusBarHeight() const
{
	return (m_bShowStatusBar ? STATUSBARHEIGHT : 0);
}

BOOL CCalendarWnd::InitStatusBar()
{
	static SBACTPANEINFO SB_PANES[] = 
	{
	  { ID_SB_STARTDATE,	MAKEINTRESOURCE(ID_SB_STARTDATE_TIP), SBACTF_NORMAL | SBACTF_RESOURCETIP }, 
	  { ID_SB_DUEDATE,		MAKEINTRESOURCE(ID_SB_DUEDATE_TIP), SBACTF_NORMAL | SBACTF_RESOURCETIP }, 
	  { ID_SB_DONEDATE,		MAKEINTRESOURCE(ID_SB_DONEDATE_TIP), SBACTF_STRETCHY | SBACTF_RESOURCETIP }, 
	  { ID_SB_TIMEESTIMATE,	MAKEINTRESOURCE(ID_SB_TIMEESTIMATE_TIP), SBACTF_NORMAL | SBACTF_RESOURCETIP }, 
	  { ID_SB_TIMESPENT,	MAKEINTRESOURCE(ID_SB_TIMESPENT_TIP), SBACTF_NORMAL | SBACTF_RESOURCETIP }, 
	};

	static int SB_PANECOUNT = sizeof(SB_PANES) / sizeof(SBACTPANEINFO);

	if (!m_StatusBar.Create(this, WS_CHILD | WS_VISIBLE | CBRS_BOTTOM, IDC_STATUSBAR))
		return -1;

	if (!m_StatusBar.SetPanes(SB_PANES, SB_PANECOUNT))
		return -1;

	return TRUE;
}

void CCalendarWnd::UpdateStatusBar()
{
	if (m_StatusBar.GetSafeHwnd() && m_bShowStatusBar)
	{
		CString strPaneTextStartDate;
		CString strPaneTextDueDate;
		CString strPaneTextDoneDate;
		CString strPaneTextTimeEstimate;
		CString strPaneTextTimeSpent;

		DWORD dwSelectedTaskID = m_BigCalendar.GetSelectedTask();
		if (dwSelectedTaskID != 0)
		{
			COleDateTime date;

			//start date
			if (m_pCalendarData->GetTaskStartDate(dwSelectedTaskID, date))
			{
				CString strDate = CDateHelper().FormatDate(date);
				strPaneTextStartDate.Format(ID_SB_STARTDATE, strDate);
			}

			//due date
			if (m_pCalendarData->GetTaskDueDate(dwSelectedTaskID, date))
			{
				CString strDate = CDateHelper().FormatDate(date);
				strPaneTextDueDate.Format(ID_SB_DUEDATE, strDate);
			}

			//completed date
			if (m_pCalendarData->GetTaskDoneDate(dwSelectedTaskID, date))
			{
				CString strDate = CDateHelper().FormatDate(date);
				strPaneTextDoneDate.Format(ID_SB_DONEDATE, strDate);
			}

			//time estimate
			double dTimeEstimate = 0;
			TCHAR cUnit = 0;
			if (m_pCalendarData->GetTaskTimeEstimate(dwSelectedTaskID, dTimeEstimate, cUnit))
			{
				CString strTime = CTimeHelper().FormatTime(dTimeEstimate, cUnit, 2);
				strPaneTextTimeEstimate.Format(ID_SB_TIMEESTIMATE, strTime, cUnit);
			}

			//time spent
			double dTimeSpent = 0;
			cUnit = 0;
			if (m_pCalendarData->GetTaskTimeSpent(dwSelectedTaskID, dTimeSpent, cUnit))
			{
				CString strTime = CTimeHelper().FormatTime(dTimeSpent, cUnit, 2);
				strPaneTextTimeSpent.Format(ID_SB_TIMESPENT, strTime, cUnit);
			}
		}

		m_StatusBar.SetPaneText(m_StatusBar.CommandToIndex(ID_SB_STARTDATE), strPaneTextStartDate);
		m_StatusBar.SetPaneText(m_StatusBar.CommandToIndex(ID_SB_DUEDATE), strPaneTextDueDate);
		m_StatusBar.SetPaneText(m_StatusBar.CommandToIndex(ID_SB_DONEDATE), strPaneTextDoneDate);
		m_StatusBar.SetPaneText(m_StatusBar.CommandToIndex(ID_SB_TIMEESTIMATE), strPaneTextTimeEstimate);
		m_StatusBar.SetPaneText(m_StatusBar.CommandToIndex(ID_SB_TIMESPENT), strPaneTextTimeSpent);
	}
}
