// UIThemeFile.cpp: implementation of the CUIThemeFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "UIThemeFile.h"
#include "xmlfile.h"
#include "filemisc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CUIThemeFile::CUIThemeFile()
{
	Reset();
}

CUIThemeFile::~CUIThemeFile()
{

}

BOOL CUIThemeFile::LoadThemeFile(LPCTSTR szThemeFile)
{
	CXmlFile xiFile;

	if (!xiFile.Load(szThemeFile, _T("TODOLIST")))
		return FALSE;

	const CXmlItem* pXITheme = xiFile.GetItem(_T("UITHEME"));

	if (!pXITheme)
		return FALSE;

	// else
	nStyle = GetStyle(pXITheme);

	crAppBackDark = GetColor(pXITheme, _T("APPBACKDARK"));
	crAppBackLight = GetColor(pXITheme, _T("APPBACKLIGHT"));
	crAppLinesDark = GetColor(pXITheme, _T("APPLINESDARK"), COLOR_3DSHADOW);
	crAppLinesLight = GetColor(pXITheme, _T("APPLINESLIGHT"), COLOR_3DHIGHLIGHT);
	crAppText = GetColor(pXITheme, _T("APPTEXT"), COLOR_WINDOWTEXT);
	crMenuBack = GetColor(pXITheme, _T("MENUBACK"), COLOR_3DFACE);
	crToolbarDark = GetColor(pXITheme, _T("TOOLBARDARK"));
	crToolbarLight = GetColor(pXITheme, _T("TOOLBARLIGHT"));
	crStatusBarDark = GetColor(pXITheme, _T("STATUSBARDARK"));
	crStatusBarLight = GetColor(pXITheme, _T("STATUSBARLIGHT"));
	crStatusBarText = GetColor(pXITheme, _T("STATUSBARTEXT"), COLOR_WINDOWTEXT);

	// toolbars
	CString sFolder = FileMisc::GetFolderFromFilePath(szThemeFile);
	const CXmlItem* pTBImage = pXITheme->GetItem(_T("TOOLBARIMAGES"));

	while (pTBImage)
	{
		CString sKey = pTBImage->GetItemValue(_T("KEY"));
		CString sFile = pTBImage->GetItemValue(_T("FILE"));

		if (!sKey.IsEmpty() && !sFile.IsEmpty())
			m_mapToolbarImageFiles[sKey] = FileMisc::MakeFullPath(sFile, sFolder);

		pTBImage = pTBImage->GetSibling();
	}

	return TRUE;
}

void CUIThemeFile::Reset()
{
	nStyle = UIS_GRADIENT;

	crAppBackDark = GetSysColor(COLOR_3DFACE);
	crAppBackLight = GetSysColor(COLOR_3DFACE);
	crAppLinesDark = GetSysColor(COLOR_3DSHADOW);
	crAppLinesLight = GetSysColor(COLOR_3DHIGHLIGHT);
	crAppText = GetSysColor(COLOR_WINDOWTEXT);
	crMenuBack = GetSysColor(COLOR_3DFACE);
	crToolbarDark = GetSysColor(COLOR_3DFACE);
	crToolbarLight = GetSysColor(COLOR_3DFACE);
	crStatusBarDark = GetSysColor(COLOR_3DFACE);
	crStatusBarLight = GetSysColor(COLOR_3DFACE);
	crStatusBarText = GetSysColor(COLOR_WINDOWTEXT);

	szToolbarImageFile[0] = 0;
}

COLORREF CUIThemeFile::GetColor(const CXmlItem* pXITheme, LPCTSTR szName, int nColorID)
{
	const CXmlItem* pXIColor = pXITheme->GetItem(_T("COLOR"));

	while (pXIColor)
	{
		if (pXIColor->GetItemValue(_T("NAME")).CompareNoCase(szName) == 0)
		{
			BYTE bRed = (BYTE)pXIColor->GetItemValueI(_T("R"));
			BYTE bGreen = (BYTE)pXIColor->GetItemValueI(_T("G"));
			BYTE bBlue = (BYTE)pXIColor->GetItemValueI(_T("B"));

			return RGB(bRed, bGreen, bBlue);
		}

		pXIColor = pXIColor->GetSibling();
	}

	// not found
	if (nColorID != -1)
		return GetSysColor(nColorID);

	// else
	return UIT_NOCOLOR;
}

UI_STYLE CUIThemeFile::GetStyle(const CXmlItem* pXITheme)
{
	CString sStyle = pXITheme->GetItemValue(_T("STYLE"));

	if (sStyle == _T("GLASS"))
		return UIS_GLASS;

	else if (sStyle == _T("GLASSWITHGRADIENT"))
		return UIS_GLASSWITHGRADIENT;

	// else
	return UIS_GRADIENT;
}

CString CUIThemeFile::GetToolbarImageFile(LPCTSTR szKey) const
{
	CString sImageFile;
	m_mapToolbarImageFiles.Lookup(szKey, sImageFile);

	return sImageFile;
}
