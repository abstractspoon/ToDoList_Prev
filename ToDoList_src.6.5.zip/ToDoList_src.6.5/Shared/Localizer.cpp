// Localizer.cpp: implementation of the CLocalizer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Localizer.h"
#include "FileMisc.h"
#include "enstring.h"
#include "enmenu.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#define NEEDSINIT ((ITransText*)-1)

ITransText* CLocalizer::s_pTransText = NEEDSINIT; // we only initialize once even if it fails

BOOL CLocalizer::Initialize(LPCTSTR szDictFile, ITT_TRANSLATEOPTION nOption)
{
	if (s_pTransText == NEEDSINIT)
	{
		// Load TransText module
		CString sTTDll = FileMisc::GetAppFolder() + _T("\\TransText.dll");
		
		if (IsTransTextDll(sTTDll) && (nOption != ITTTO_TRANSLATEONLY || FileMisc::FileExists(szDictFile)))
		{
			s_pTransText = CreateTransTextInterface(sTTDll, szDictFile, nOption);
			ASSERT(s_pTransText);

			CEnString::SetLocalizer(s_pTransText);
			CEnMenu::SetLocalizer(s_pTransText);
		}
		else
			s_pTransText = NULL;
	}

	return (s_pTransText != NEEDSINIT);
}

BOOL CLocalizer::Initialize(ITransText* pTT)
{
	if (s_pTransText == NEEDSINIT && pTT && pTT != NEEDSINIT)
	{
		s_pTransText = pTT;

		CEnString::SetLocalizer(s_pTransText);
		CEnMenu::SetLocalizer(s_pTransText);

		return TRUE;
	}

	// else
	return FALSE;
}

void CLocalizer::Release()
{
	if (s_pTransText && (s_pTransText != NEEDSINIT))
		s_pTransText->Release();

	s_pTransText = NEEDSINIT;
}

void CLocalizer::SetTranslationOption(ITT_TRANSLATEOPTION nOption)
{
	if (s_pTransText && (s_pTransText != NEEDSINIT))
		s_pTransText->SetTranslationOption(nOption);
}

BOOL CLocalizer::TranslateText(CString& sText, HWND hWndRef)
{
	VERIFY (Initialize());

	if (s_pTransText)
	{
		LPTSTR szTranslated = NULL;
		
		if (s_pTransText->TranslateText(sText, hWndRef, szTranslated))
		{
			sText = szTranslated;
			delete [] szTranslated;

			return TRUE;
		}
	}

	return FALSE;
}

BOOL CLocalizer::TranslateMenu(HMENU hMenu, HWND hWndRef, BOOL bRecursive)
{
	VERIFY (Initialize());

	if (s_pTransText)
		return s_pTransText->TranslateMenu(hMenu, hWndRef, bRecursive);

	return FALSE;
}

void CLocalizer::UpdateMenu(HWND hWnd)
{
	VERIFY (Initialize());

	if (s_pTransText)
		s_pTransText->UpdateMenu(hWnd);
}

void CLocalizer::EnableTranslation(HWND hWnd, BOOL bEnable)
{
	VERIFY (Initialize());

	if (s_pTransText)
		s_pTransText->EnableTranslation(hWnd, bEnable);
}

void CLocalizer::EnableTranslation(const CWnd& hWnd, BOOL bEnable)
{
	VERIFY (Initialize());

	if (s_pTransText)
		s_pTransText->EnableTranslation(hWnd.GetSafeHwnd(), bEnable);
}

void CLocalizer::EnableTranslation(HMENU hMenu, BOOL bEnable)
{
	VERIFY (Initialize());

	if (s_pTransText)
		s_pTransText->EnableTranslation(hMenu, bEnable);
}

void CLocalizer::EnableTranslation(UINT nMenuID, BOOL bEnable)
{
	VERIFY (Initialize());

	if (s_pTransText)
		s_pTransText->EnableTranslation(nMenuID, bEnable);
}

void CLocalizer::EnableTranslation(UINT nMenuIDFirst, UINT nMenuIDLast, BOOL bEnable)
{
	VERIFY (Initialize());

	if (s_pTransText)
	{
		for (UINT nMenuID = nMenuIDFirst; nMenuID <= nMenuIDLast; nMenuID++)
			s_pTransText->EnableTranslation(nMenuID, bEnable);
	}
}


void CLocalizer::IgnoreString(const CString& sText)
{
	VERIFY (Initialize());

	if (s_pTransText)
		s_pTransText->IgnoreString(sText);
}
