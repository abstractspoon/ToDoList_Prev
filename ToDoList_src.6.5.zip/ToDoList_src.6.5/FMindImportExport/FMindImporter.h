// FMindImporter.h: interface for the CFMindImporter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FMINDIMPORTER_H__48AE3CCE_E042_432D_B5DB_D7E310CF99CE__INCLUDED_)
#define AFX_FMINDIMPORTER_H__48AE3CCE_E042_432D_B5DB_D7E310CF99CE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\SHARED\IImportExport.h"
#include "..\SHARED\ITasklist.h"
#include "..\SHARED\xmlfile.h"

class CFMindImporter : public IImportTasklist  
{
public:
	CFMindImporter();
	virtual ~CFMindImporter();
	// interface implementation
	void Release() { delete this; }
	
	// caller must copy only
	LPCTSTR GetMenuText() const { return _T("FreeMind"); }
	LPCTSTR GetFileFilter() const { return _T("FreeMind Files (*.mm)|*.mm||"); }
	LPCTSTR GetFileExtension() const { return _T("mm"); }
	
	bool Import(LPCTSTR szSrcFilePath, ITaskList* pDestTaskFile, BOOL bSilent, IPreferences* pPrefs, LPCTSTR szKey);

protected:
	bool ImportTask(const CXmlItem* pFMTask, ITaskList10* pDestTaskFile, HTASKITEM hParent) const;
	COLORREF GetFMColor(const CXmlItem* pFMTask, LPCTSTR szColorField) const;
	time_t GetFMDate(const CXmlItem* pFMTask, LPCTSTR szDateField) const;
	CString GetAttribValueS(const CXmlItem* pFMTask, LPCTSTR szAttribName) const;
	int GetAttribValueI(const CXmlItem* pFMTask, LPCTSTR szAttribName) const;
	bool GetAttribValueB(const CXmlItem* pFMTask, LPCTSTR szAttribName) const;
	double GetAttribValueD(const CXmlItem* pFMTask, LPCTSTR szAttribName) const;
	time_t GetAttribValueT(const CXmlItem* pFMTask, LPCTSTR szAttribName) const;
	CString GetTaskRichContent(const CXmlItem* pFMTask, LPCTSTR szRichType, LPCTSTR szFallback = NULL) const;
	int GetTaskArrayItems(const CXmlItem* pFMTask, LPCTSTR szAttribName, CStringArray& aItems) const;

};

#endif // !defined(AFX_FMINDIMPORTER_H__48AE3CCE_E042_432D_B5DB_D7E310CF99CE__INCLUDED_)
