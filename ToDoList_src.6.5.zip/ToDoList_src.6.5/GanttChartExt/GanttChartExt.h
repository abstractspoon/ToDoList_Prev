// GanttChartExt.h: interface for the CGanttChartExtApp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GANTTCHARTEXT_H__DEE73DE1_C6EC_4648_9151_0FC2C75A806D__INCLUDED_)
#define AFX_GANTTCHARTEXT_H__DEE73DE1_C6EC_4648_9151_0FC2C75A806D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\SHARED\IUIExtension.h"

// {83F6CBD3-5F3C-4567-9BA8-9544B899F949}
static const GUID GANTT_TYPEID = 
{ 0x83f6cbd3, 0x5f3c, 0x4567, { 0x9b, 0xa8, 0x95, 0x44, 0xb8, 0x99, 0xf9, 0x49 } };

class CGanttChartExtApp : public IUIExtension  
{
public:
	CGanttChartExtApp();
	virtual ~CGanttChartExtApp();

    void Release(); // releases the interface

	LPCTSTR GetMenuText() const { return _T("Gantt Chart"); }
	HICON GetIcon() const { return m_hIcon; }
	LPCTSTR GetTypeID() const;

	IUIExtensionWindow* CreateExtWindow(UINT nCtrlID, DWORD nStyle, 
										long nLeft, long nTop, long nWidth, long nHeight, 
										HWND hwndParent);

protected:
	HICON m_hIcon;
};

#endif // !defined(AFX_GANTTCHARTEXT_H__DEE73DE1_C6EC_4648_9151_0FC2C75A806D__INCLUDED_)
