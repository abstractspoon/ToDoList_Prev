// iCalExporter.cpp: implementation of the CiCalExporter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "iCalImportExport.h"
#include "iCalExporter.h"

#include "..\Shared\DateHelper.h"
#include "..\3rdParty\stdiofileex.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CiCalExporter::CiCalExporter()
{
	
}

CiCalExporter::~CiCalExporter()
{
	
}

void CiCalExporter::WriteHeader(CStdioFileEx& fileOut)
{
	WriteString(fileOut, _T("BEGIN:VCALENDAR"));
	WriteString(fileOut, _T("PRODID:iCalExporter (c) AbstractSpoon 2009-11"));
	WriteString(fileOut, _T("VERSION:2.0"));
}

bool CiCalExporter::Export(const ITaskList* pSrcTaskFile, LPCTSTR szDestFilePath, BOOL /*bSilent*/, IPreferences* /*pPrefs*/, LPCTSTR /*szKey*/)
{
	CStdioFileEx fileOut;
	
	if (fileOut.Open(szDestFilePath, CFile::modeCreate | CFile::modeWrite, SFE_MULTIBYTE))
	{
		// header
		WriteHeader(fileOut);
		
		// export first task
		ExportTask(pSrcTaskFile, pSrcTaskFile->GetFirstTask(), "", fileOut);
		
		// footer
		WriteString(fileOut, _T("END:VCALENDAR"));
		
		return true;
	}
	
	return false;
}

bool CiCalExporter::Export(const IMultiTaskList* pSrcTaskFile, LPCTSTR szDestFilePath, BOOL /*bSilent*/, IPreferences* /*pPrefs*/, LPCTSTR /*szKey*/)
{
	CStdioFileEx fileOut;
	
	if (fileOut.Open(szDestFilePath, CFile::modeCreate | CFile::modeWrite, SFE_MULTIBYTE))
	{
		// header
		WriteHeader(fileOut);
		
		for (int nTaskList = 0; nTaskList < pSrcTaskFile->GetTaskListCount(); nTaskList++)
		{
			const ITaskList* pTasks = pSrcTaskFile->GetTaskList(nTaskList);

			if (pTasks)
			{
				// export first task
				ExportTask(pTasks, pTasks->GetFirstTask(), "", fileOut);
			}
		}

		// footer
		WriteString(fileOut, _T("END:VCALENDAR"));
		
		return true;
	}
	
	return false;
}

void CiCalExporter::ExportTask(const ITaskList* pSrcTaskFile, HTASKITEM hTask, const CString& sParentUID, CStdioFile& fileOut)
{
	if (!hTask)
		return;
	
	// attributes
	time_t tStartDate = pSrcTaskFile->GetTaskStartDate(hTask);
	time_t tDueDate = pSrcTaskFile->GetTaskDueDate(hTask);
	
	// if task only has a start date then make the due date the same as the start and vice versa
	if (tDueDate == 0 && tStartDate)
		tDueDate = tStartDate;
	
	else if (tStartDate == 0 && tDueDate)
		tStartDate = tDueDate;
	
	// construct a unique ID
	CString sUID, sFile = fileOut.GetFilePath();
    
	sFile.Replace(_T("\\"), _T(""));
    sFile.Replace(_T(":"), _T(""));
	sUID.Format(_T("%ld@%s.com"), pSrcTaskFile->GetTaskID(hTask), sFile);
		
	// tasks must have a start date or a due date or both
	if (tStartDate || tDueDate)
	{
		// header
		WriteString(fileOut, _T("BEGIN:VEVENT"));
		
		COleDateTime dtStart(tStartDate);
		WriteString(fileOut, FormatDateTime(_T("DTSTART"), dtStart));
		
		// neither Google Calendar not Outlook pay any attention to the 'DUE' tag so we won't either.
		// instead we use 'DTEND' to mark the duration of the task. There is also no way to mark a
		// task as complete so we ignore our completion status
		
		COleDateTime dtDue(tDueDate);
		WriteString(fileOut, FormatDateTime(_T("DTEND"), dtDue, FALSE));
		
		WriteString(fileOut, _T("SUMMARY:%s"), pSrcTaskFile->GetTaskTitle(hTask));
		WriteString(fileOut, _T("DESCRIPTION:%s"), pSrcTaskFile->GetTaskComments(hTask));
		WriteString(fileOut, _T("STATUS:%s"), pSrcTaskFile->GetTaskStatus(hTask));
		WriteString(fileOut, _T("CATEGORIES:%s"), pSrcTaskFile->GetTaskCategory(hTask));
		WriteString(fileOut, _T("URL:%s"), pSrcTaskFile->GetTaskFileReferencePath(hTask));
		WriteString(fileOut, _T("ORGANIZER:%s"), pSrcTaskFile->GetTaskAllocatedBy(hTask));
		WriteString(fileOut, _T("ATTENDEE:%s"), pSrcTaskFile->GetTaskAllocatedTo(hTask));
		WriteString(fileOut, _T("UID:%s"), sUID);

		// parent child relationship
		WriteString(fileOut, _T("RELATED-TO;RELTYPE=PARENT:%s"), sParentUID);
		
		// footer
		WriteString(fileOut, _T("END:VEVENT"));
	}
	
	// copy across first child
	ExportTask(pSrcTaskFile, pSrcTaskFile->GetFirstTask(hTask), sUID, fileOut);
	
	// copy across first sibling
	ExportTask(pSrcTaskFile, pSrcTaskFile->GetNextTask(hTask), sParentUID, fileOut);
}

CString CiCalExporter::FormatDateTime(LPCTSTR szType, const COleDateTime& date, BOOL bStartOfDay)
{
	CString sDateTime;

	if (CDateHelper::DateHasTime(date))
	{
		sDateTime.Format(_T("%s;VALUE=DATE-TIME:%04d%02d%02dT%02d%02d%02d"), szType, 
						date.GetYear(), date.GetMonth(), date.GetDay(),
						date.GetHour(), date.GetMinute(), date.GetSecond());
	}
	else // no time component
	{
		COleDateTime dtDay(date);
		
		if (!bStartOfDay)
			dtDay.m_dt += 1.0;
		
		sDateTime.Format(_T("%s;VALUE=DATE-TIME:%04d%02d%02dT000000"), szType, 
						dtDay.GetYear(), dtDay.GetMonth(), dtDay.GetDay());	
	}
	
	return sDateTime;
}

void __cdecl CiCalExporter::WriteString(CStdioFile& fileOut, LPCTSTR lpszFormat, ...)
{
	ASSERT(AfxIsValidString(lpszFormat));
	CString sLine;
	
	va_list argList;
	va_start(argList, lpszFormat);
	sLine.FormatV(lpszFormat, argList);
	va_end(argList);
	
	sLine.TrimRight();
	
	// write line out in pieces no longer than 75 bytes
	while (sLine.GetLength() > 75)
	{
		CString sTemp = sLine.Left(75);
		sLine = sLine.Mid(75);
		
		fileOut.WriteString(sTemp);
		fileOut.WriteString(_T("\n "));
	}
	
	// write out whatever's left
	fileOut.WriteString(sLine);
	fileOut.WriteString(_T("\n"));
}
