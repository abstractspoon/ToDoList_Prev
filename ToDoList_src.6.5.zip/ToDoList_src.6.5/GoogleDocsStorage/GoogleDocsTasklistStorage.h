// GoogleDocsTasklistStorage.h: interface for the CGoogleDocsTasklistStorage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GOOGLEDOCSTASKLISTSTORAGE_H__2C0D3EAE_7FCE_4580_BFF1_9A4341D3FBCD__INCLUDED_)
#define AFX_GOOGLEDOCSTASKLISTSTORAGE_H__2C0D3EAE_7FCE_4580_BFF1_9A4341D3FBCD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\Shared\ITaskListStorage.h"

class CGoogleDocsTasklistStorage : public ITasklistStorage  
{
public:
	CGoogleDocsTasklistStorage();
	virtual ~CGoogleDocsTasklistStorage();

	// interface implementation
    void Release() { delete this; }

	// caller must copy result only
	LPCTSTR GetMenuText() const { return _T("GoogleDocs"); }
	LPCTSTR GetTypeID() const { return _T("2C0D3EAE_7FCE_4580_BFF1_9A4341D3FBCD"); }

	bool RetrieveTasklist(ITS_TASKLISTINFO* pFInfo, ITaskList* pDestTaskFile, IPreferences* pPrefs, LPCTSTR szKey, bool bSilent);
	bool StoreTasklist(ITS_TASKLISTINFO* pFInfo, ITaskList* pSrcTaskFile, IPreferences* pPrefs, LPCTSTR szKey, bool bSilent);
};

#endif // !defined(AFX_GOOGLEDOCSTASKLISTSTORAGE_H__2C0D3EAE_7FCE_4580_BFF1_9A4341D3FBCD__INCLUDED_)
