// GoogleDocsTasklistStorage.cpp: implementation of the CGoogleDocsTasklistStorage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GoogleDocsTasklistStorage.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGoogleDocsTasklistStorage::CGoogleDocsTasklistStorage()
{

}

CGoogleDocsTasklistStorage::~CGoogleDocsTasklistStorage()
{

}

bool CGoogleDocsTasklistStorage::RetrieveTasklist(ITS_TASKLISTINFO* pFInfo, ITaskList* pDestTaskFile, 
												IPreferences* pPrefs, LPCTSTR szKey, bool bSilent)
{
	AfxMessageBox(_T("GoogleDocs storage plugin coming soon!"));
	return false;
}

bool CGoogleDocsTasklistStorage::StoreTasklist(ITS_TASKLISTINFO* pFInfo, ITaskList* pSrcTaskFile, 
											 IPreferences* pPrefs, LPCTSTR szKey, bool bSilent)
{
	AfxMessageBox(_T("GoogleDocs storage plugin coming soon!"));
	return false;
}

