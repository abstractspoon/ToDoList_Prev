// SetRedraw.h: interface and implementation of the CSetRedraw class.
//
/////////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_HOLDREDRAW_H__7E73ADE2_3848_4ED1_9E8B_8881813B4262__INCLUDED_)
#define AFX_HOLDREDRAW_H__7E73ADE2_3848_4ED1_9E8B_8881813B4262__INCLUDED_


class CNcRedraw // note: there is no inheritance intentionally.
{
public:
	CNcRedraw(HWND hWnd, LPCTSTR szTrace = NULL) : m_hWnd(hWnd), m_sTrace(szTrace)
	{
	}

	virtual ~CNcRedraw()
	{
		if (m_hWnd && ::IsWindowVisible(m_hWnd))
		{
			TRACE("~CNcRedraw(%s)\n", m_sTrace);
			::SendMessage(m_hWnd, WM_NCPAINT, 0, 0);
		}
	}

protected:
	HWND m_hWnd;
	CString m_sTrace;
};

class CRedrawAll
{
public:
	CRedrawAll(HWND hWnd, BOOL bUpdateWindow = FALSE) : m_hWnd(hWnd), m_bUpdateWindow(bUpdateWindow)
	{
	}

	virtual ~CRedrawAll()
	{
		if (m_hWnd && ::IsWindowVisible(m_hWnd))
		{
			//TRACE("~CRedrawAll()\n");
			::SendMessage(m_hWnd, WM_NCPAINT, 0, 0);
			::InvalidateRect(m_hWnd, NULL, FALSE);

			if (m_bUpdateWindow)
				::UpdateWindow(m_hWnd);
		}
	}

protected:
	HWND m_hWnd;
	BOOL m_bUpdateWindow;
};

class CHoldRedraw : protected CRedrawAll
{
public:
	CHoldRedraw(HWND hWnd, BOOL bUpdateWindow = FALSE) : CRedrawAll(hWnd, bUpdateWindow)
	{
		if (m_hWnd)
			::SendMessage(m_hWnd, WM_SETREDRAW, FALSE, 0);
	}

	virtual ~CHoldRedraw()
	{
		if (m_hWnd)
			::SendMessage(m_hWnd, WM_SETREDRAW, TRUE, 0);
	}
};

#endif
