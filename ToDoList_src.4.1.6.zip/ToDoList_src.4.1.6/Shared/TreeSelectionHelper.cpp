// TreeSelectionHelper.cpp: implementation of the CTreeSelectionHelper class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TreeSelectionHelper.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

struct SORTITEM
{
	HTREEITEM hti;
	int nPos;
};

CTreeSelectionHelper::CTreeSelectionHelper(CTreeCtrl& tree) : 
	m_tree(tree), m_nCurSelection(0), m_htiAnchor(NULL)
{

}

CTreeSelectionHelper::~CTreeSelectionHelper()
{

}

BOOL CTreeSelectionHelper::SetItem(HTREEITEM hti, int nState, BOOL bRedraw)
{
	if (!hti)
		return FALSE;

	POSITION pos = m_lstSelection.Find(hti);

	switch (nState)
	{
	case 1: // add
		if (!pos)
		{
			m_lstSelection.AddTail(hti);

			if (bRedraw)
				InvalidateItem(hti);

			return TRUE;
		}
		break;

	case 0: // remove
		if (pos)
		{
			m_lstSelection.RemoveAt(pos);

			if (bRedraw)
				InvalidateItem(hti);

			return TRUE;
		}
		break;

	case -1: // toggle
		if (!pos)
			m_lstSelection.AddTail(hti);
		else
			m_lstSelection.RemoveAt(pos);

		if (bRedraw)
			InvalidateItem(hti);

		return TRUE;
	}

	return FALSE;
}

void CTreeSelectionHelper::InvalidateItem(HTREEITEM hti)
{
	CRect rItem;

	if (m_tree.GetItemRect(hti, rItem, FALSE))
		m_tree.InvalidateRect(rItem, FALSE);	
}

BOOL CTreeSelectionHelper::SetItems(HTREEITEM htiFrom, HTREEITEM htiTo, int nState, BOOL bRedraw)
{
	if (!htiFrom || !htiTo)
		return FALSE;

	int nDirection = FindItem(htiTo, htiFrom);

	// if (htiFrom != htiTo) and nDirection is zero then htiTo could not be found
	if (htiFrom != htiTo && !nDirection)
		return FALSE;

	// if htiTo is above htiFrom then switch items so we can use a single loop
	if (nDirection == -1)
	{
		HTREEITEM htiTemp = htiFrom;
		htiFrom = htiTo;
		htiTo = htiTemp;
	}

	BOOL bRes = FALSE;
	HTREEITEM htiNext = htiFrom;

	while (htiNext) 
	{
		bRes |= SetItem(htiNext, nState, bRedraw);

		if (htiNext != htiTo)
			htiNext = GetNextItem(htiNext, TRUE);
		else
			break;
	}

	return bRes;
}

BOOL CTreeSelectionHelper::AddItems(HTREEITEM htiFrom, HTREEITEM htiTo, BOOL bRedraw)
{
	return SetItems(htiFrom, htiTo, 1, bRedraw);
}

BOOL CTreeSelectionHelper::ToggleItems(HTREEITEM htiFrom, HTREEITEM htiTo, BOOL bRedraw)
{
	return SetItems(htiFrom, htiTo, -1, bRedraw);
}

BOOL CTreeSelectionHelper::RemoveAll(BOOL bRedraw) 
{ 
	if (GetCount())
	{
		// flush the history stack
		if (m_nCurSelection < m_aHistory.GetSize())
			m_aHistory.RemoveAt(m_nCurSelection + 1, m_aHistory.GetSize() - m_nCurSelection - 1);

		else // add the current selection to the history
			m_aHistory.Add(m_lstSelection);

		// update the current selection
		m_nCurSelection++;
		
		if (bRedraw)
			InvalidateAll(FALSE);

		m_lstSelection.RemoveAll(); 
		return TRUE;
	}

	return FALSE;
}

void CTreeSelectionHelper::InvalidateAll(BOOL bErase)
{
	POSITION pos = GetFirstItemPos();
	CRect rItem;

	while (pos)
	{
		HTREEITEM hti = GetNextItem(pos);

		m_tree.GetItemRect(hti, rItem, FALSE);
		m_tree.InvalidateRect(rItem, bErase);
	}
}

BOOL CTreeSelectionHelper::AnyItemsHaveChildren() const
{
	POSITION pos = GetFirstItemPos();

	while (pos)
	{
		if (m_tree.ItemHasChildren(GetNextItem(pos)))
			return TRUE;
	}

	return FALSE;
}

HTREEITEM CTreeSelectionHelper::GetNextPageItem(HTREEITEM hti) const
{
	// if we're the last visible item then its just the page count
	// figure out how many items to step
	HTREEITEM htiNext = m_tree.GetNextVisibleItem(hti);

	if (!htiNext || !IsFullyVisible(htiNext))
	{
		int nCount = m_tree.GetVisibleCount();

		// keep going until we get NULL and then return
		// the previous item
		while (hti && nCount--)
		{
			if (hti = GetNextItem(hti))
				htiNext = hti;
		}
	}
	else // we keep going until we're the last visible item
	{
		// keep going until we get NULL and then return
		// the previous item
		while (hti)
		{
			hti = m_tree.GetNextVisibleItem(hti);
			
			if (hti && IsFullyVisible(hti))
				htiNext = hti;
			else
				hti = NULL;
		}
	}

	return htiNext;
}

HTREEITEM CTreeSelectionHelper::GetPrevPageItem(HTREEITEM hti) const
{
	// if we're the first visible item then its just the page count
	// figure out how many items to step
	HTREEITEM htiPrev = m_tree.GetPrevVisibleItem(hti);

	if (!htiPrev || !IsFullyVisible(htiPrev))
	{
		int nCount = m_tree.GetVisibleCount();

		// keep going until we get NULL and then return
		// the previous item
		while (hti && nCount--)
		{
			if (hti = GetPrevItem(hti))
				htiPrev = hti;
		}
	}
	else // we keep going until we're the first visible item
	{
		// keep going until we get NULL and then return
		// the previous item
		while (hti)
		{
			hti = m_tree.GetPrevVisibleItem(hti);
			
			if (hti && IsFullyVisible(hti))
				htiPrev = hti;
			else
				hti = NULL;
		}
	}

	return htiPrev;
}

HTREEITEM CTreeSelectionHelper::GetNextItem(HTREEITEM hti, BOOL bAllowChildren) const
{
	HTREEITEM htiNext = NULL;
	
	// try our first child if we're expanded
	if (bAllowChildren && m_tree.ItemHasChildren(hti) && IsItemExpanded(hti))
		htiNext = m_tree.GetChildItem(hti);
	else
	{
		// try next sibling
		htiNext = m_tree.GetNextItem(hti, TVGN_NEXT);
		
		// finally look up the parent chain as far as we can
		if (!htiNext)
		{
			HTREEITEM htiParent = hti;

			while (htiParent && !htiNext)
			{
				htiParent = m_tree.GetParentItem(htiParent);

				if (htiParent)
					htiNext = m_tree.GetNextItem(htiParent, TVGN_NEXT);
			}
		}
	}

	return htiNext == TVI_ROOT ? NULL : htiNext;
}

HTREEITEM CTreeSelectionHelper::GetPrevItem(HTREEITEM hti, BOOL bAllowChildren) const
{
	// try our prior sibling
	HTREEITEM htiPrev = m_tree.GetNextItem(hti, TVGN_PREVIOUS);
	
	// if we have one then first try its last child
	if (htiPrev)
	{
		if (bAllowChildren && m_tree.ItemHasChildren(htiPrev) && IsItemExpanded(htiPrev))
		{
			HTREEITEM htiChild = m_tree.GetChildItem(htiPrev);
			
			while (htiChild)
			{
				htiPrev = htiChild;
				htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
			}
		}
		// else we settle for htiPrev as-is
	}
	else // get parent
		htiPrev = m_tree.GetParentItem(hti);

	return htiPrev == TVI_ROOT ? NULL : htiPrev;
}

BOOL CTreeSelectionHelper::ItemsAreAllSiblings() const
{
	if (GetCount() < 2)
		return TRUE;

	POSITION pos = GetFirstItemPos();

	if (pos)
	{
		HTREEITEM hti = GetNextItem(pos);
		HTREEITEM htiParent = m_tree.GetParentItem(hti);

		while (pos)
		{
			hti = GetNextItem(pos);

			if (m_tree.GetParentItem(hti) != htiParent)
				return FALSE;
		}
	}

	return TRUE;
}

void CTreeSelectionHelper::SortIfAllSiblings(BOOL bAscending)
{
	if (ItemsAreAllSiblings())
	{
		// build an array of the current selection
		CArray<SORTITEM, SORTITEM&> items;
		items.SetSize(GetCount());
		int nItem = 0;

		POSITION pos = GetFirstItemPos();

		while (pos)
		{
			HTREEITEM hti = GetNextItem(pos);
			SORTITEM si = { hti, GetItemPos(hti) };

			items.SetAt(nItem, si);
			nItem++;
		}

		// sort that array
		qsort(items.GetData(), items.GetSize(), sizeof(SORTITEM), SortProc);

		// rebuild the selection
		RemoveAll(FALSE);

		if (bAscending)
		{
			for (nItem = items.GetSize() - 1; nItem >= 0 ; nItem--)
			{
				const SORTITEM& si = items[nItem];
				AddItem(si.hti, FALSE);
			}
		}
		else
		{
			for (nItem = 0; nItem < items.GetSize(); nItem++)
			{
				const SORTITEM& si = items[nItem];
				AddItem(si.hti, FALSE);
			}
		}
	}
}

int CTreeSelectionHelper::SortProc(const void* item1, const void* item2)
{
	const SORTITEM* pItem1 = (const SORTITEM*)item1;
	const SORTITEM* pItem2 = (const SORTITEM*)item2;

	return pItem1->nPos < pItem2->nPos;
}

int CTreeSelectionHelper::GetItemPos(HTREEITEM hti)
{
	HTREEITEM htiParent = m_tree.GetParentItem(hti);
	HTREEITEM htiChild = m_tree.GetChildItem(htiParent);
	int nPos = 0;

	while (htiChild)
	{
		if (hti == htiChild)
			return nPos;

		nPos++;
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}

	// not found ??
	return -1;
}

void CTreeSelectionHelper::RemoveChildDuplicates(CHTIList& selection, const CTreeCtrl& tree)
{
	POSITION pos = selection.GetHeadPosition();

	while (pos)
	{
		POSITION posChild = pos;
		HTREEITEM hti = selection.GetNext(pos);

		if (HasSelectedParent(hti, selection, tree))
			selection.RemoveAt(posChild);
	}
}

BOOL CTreeSelectionHelper::HasSelectedParent(HTREEITEM hti) const
{
	return HasSelectedParent(hti, m_lstSelection, m_tree);
}

BOOL CTreeSelectionHelper::HasSelectedParent(HTREEITEM hti, const CHTIList& selection, const CTreeCtrl& tree)
{
	HTREEITEM htiParent = tree.GetParentItem(hti);
	
	while (htiParent)
	{
		if (selection.Find(htiParent))
			return TRUE;
		
		// else
		htiParent = tree.GetParentItem(htiParent);
	}
	
	return FALSE; // not found
}


int CTreeSelectionHelper::FindItem(HTREEITEM htiFind, HTREEITEM htiStart)
{
	// try same first
	if (htiFind == htiStart)
		return 0;

	// then try up
	HTREEITEM htiPrev = GetPrevItem(htiStart);

	while (htiPrev)
	{
		if (htiPrev == htiFind)
			return -1;

		htiPrev = GetPrevItem(htiPrev);
	}

	// else try down
	HTREEITEM htiNext = GetNextItem(htiStart);

	while (htiNext)
	{
		if (htiNext == htiFind)
			return 1;

		htiNext = GetNextItem(htiNext);
	}

	// else
	return 0;
}

BOOL CTreeSelectionHelper::ContainsAllItems() const
{
	// traverse all top level items and check for inclusion
	HTREEITEM hti = m_tree.GetChildItem(NULL);

	while (hti)
	{
		if (!HasItem(hti))
			return FALSE;

		hti = m_tree.GetNextItem(hti, TVGN_NEXT);
	}

	return TRUE;
}

BOOL CTreeSelectionHelper::IsFullyVisible(HTREEITEM hti) const
{
	CRect rClient, rItem, rIntersect;

	m_tree.GetClientRect(rClient);
	m_tree.GetItemRect(hti, rItem, FALSE);

	return (rIntersect.IntersectRect(rItem, rClient) && rIntersect == rItem);
}

BOOL CTreeSelectionHelper::HasNextSelection() const
{
	return (m_nCurSelection < m_aHistory.GetSize() - 1);
}

BOOL CTreeSelectionHelper::NextSelection(BOOL bRedraw)
{
	if (HasNextSelection())
	{
		int nSizeHistory = m_aHistory.GetSize();

		// invalidate current selection
		if (bRedraw)
			InvalidateAll(FALSE);

		// save current selection in history
		m_aHistory[m_nCurSelection] = m_lstSelection;

		// copy next selection
		m_nCurSelection++;
		m_lstSelection = m_aHistory[m_nCurSelection];

		// invalidate new selection
		if (bRedraw)
			InvalidateAll(FALSE);

		return TRUE;
	}

	return FALSE;
}

BOOL CTreeSelectionHelper::HasPrevSelection() const
{
	return m_nCurSelection && m_aHistory.GetSize();
}

BOOL CTreeSelectionHelper::PrevSelection(BOOL bRedraw)
{
	if (HasPrevSelection())
	{
		int nSizeHistory = m_aHistory.GetSize();

		// invalidate current selection
		if (bRedraw)
			InvalidateAll(FALSE);

		// save current selection in history
		if (m_nCurSelection < nSizeHistory)
			m_aHistory[m_nCurSelection] = m_lstSelection;
		else
			m_aHistory.Add(m_lstSelection);

		m_nCurSelection--;
		m_lstSelection = m_aHistory[m_nCurSelection];

		// invalidate new selection
		if (bRedraw)
			InvalidateAll(FALSE);

		return TRUE;
	}

	return FALSE;
}
