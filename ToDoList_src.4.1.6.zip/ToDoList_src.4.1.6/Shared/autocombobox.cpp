// autocombobox.cpp : implementation file
//

#include "stdafx.h"
#include "autocombobox.h"
#include "holdredraw.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

void AFXAPI DDX_AutoCBString(CDataExchange* pDX, int nIDC, CString& value)
{
	HWND hWndCtrl = pDX->PrepareCtrl(nIDC);

	if (pDX->m_bSaveAndValidate)
	{
		DDX_CBString(pDX, nIDC, value);
	}
	else
	{
		// try exact first
		int nIndex = (int)::SendMessage(hWndCtrl, CB_FINDSTRINGEXACT, (WPARAM)-1,
										(LPARAM)(LPCTSTR)value);

		// then partial
		if (nIndex == CB_ERR)
			nIndex = ::SendMessage(hWndCtrl, CB_SELECTSTRING, (WPARAM)-1, (LPARAM)(LPCTSTR)value);

		if (nIndex == CB_ERR)
		{
			// just set the edit text (will be ignored if DROPDOWNLIST)
			SetWindowText(hWndCtrl, value);
		}
		else
		{
			// select it
			SendMessage(hWndCtrl, CB_SETCURSEL, nIndex, 0L);
		}
	}
}


/////////////////////////////////////////////////////////////////////////////
// CAutoComboBox

CAutoComboBox::CAutoComboBox(BOOL bAllowDelete, BOOL bCaseSensitive) : 
	m_bAllowDelete(bAllowDelete), m_hwndListbox(NULL), m_bCaseSensitive(bCaseSensitive)
{
}

CAutoComboBox::~CAutoComboBox()
{
}


BEGIN_MESSAGE_MAP(CAutoComboBox, CComboBox)
	//{{AFX_MSG_MAP(CAutoComboBox)
	ON_CONTROL_REFLECT_EX(CBN_KILLFOCUS, OnKillfocus)
	ON_WM_SIZE()
	ON_CONTROL_REFLECT(CBN_DROPDOWN, OnDropdown)
	ON_CONTROL_REFLECT(CBN_CLOSEUP, OnCloseup)
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAutoComboBox message handlers

BOOL CAutoComboBox::OnKillfocus() 
{
	CString sText;
	GetWindowText(sText);

	int nItem = AddUniqueItem(sText);
 
    // select
    if (nItem != CB_ERR)
        SetCurSel(nItem);

	return FALSE; // continue routing
}

int CAutoComboBox::AddUniqueItem(const CString& sItem)
{
    if (!sItem.IsEmpty())
    {
		int nFind = FindStringExact(-1, sItem, m_bCaseSensitive);
		
		if (nFind != CB_ERR)
            DeleteString(nFind); // remove original
		
        return CComboBox::AddString(sItem); // re-add at end
	}
	
	return CB_ERR; // invalid item
}

int CAutoComboBox::FindStringExact(int nIndexStart, const CString& sItem, BOOL bCaseSensitive) const
{
	int nFind = CB_ERR; // default
	
	if (!sItem.IsEmpty())
	{
		// because more than one item might exist if were doing a case-sensitive
		// search we can't just stop if the first find doesn't exactly match
		// because there still may be further matches
		BOOL bContinue = TRUE;
		
		while (bContinue)
        {
			int nPrevFind = nFind;
			nFind = CComboBox::FindStringExact(nFind, sItem);
			
			// if no match then definitely done
			if (nFind <= nPrevFind)
			{
				nFind = -1;
				bContinue = FALSE;
			}
			else if (!bCaseSensitive)
				bContinue = FALSE;
			else
			{
				// else if (bCaseSensitive)
				ASSERT (nFind != CB_ERR);
				ASSERT (bCaseSensitive);
				
				// test for real exactness because FindStringExact is not case sensitive
				CString sFind;
				GetLBText(nFind, sFind);
				
				bContinue = !(sItem == sFind); // differ in case
			}
        }
	}
	
	return nFind;
}

int CAutoComboBox::InsertUniqueItem(int nIndex, const CString& sItem)
{
	int nFind = FindStringExact(-1, sItem, m_bCaseSensitive);

    if (!sItem.IsEmpty())
    {
    	if (nFind != CB_ERR)
            DeleteString(nFind); // remove original

        return CComboBox::InsertString(nFind, sItem); // re-insert
	}

	return CB_ERR; // invalid item
}

void CAutoComboBox::OnSize(UINT nType, int cx, int cy) 
{
	CWnd* pEdit = GetDlgItem(1001);

	// if the edit control does not have the focus then hide the selection
	if (pEdit && pEdit != GetFocus())
	{
		CHoldRedraw hr(*pEdit);
		CComboBox::OnSize(nType, cx, cy);
	
		pEdit->SendMessage(EM_SETSEL, -1, 0);
	}
	else
		CComboBox::OnSize(nType, cx, cy);
}

int CAutoComboBox::AddUniqueItems(const CStringArray& aItems)
{
    int nItem = aItems.GetSize(), nCount = 0;

    while (nItem--)
    {
        if (AddUniqueItem(aItems[nItem]) >= 0)
            nCount++;
    }

    return nCount;
}

int CAutoComboBox::AddUniqueItems(const CAutoComboBox& cbItems)
{
    CStringArray aItems;

    if (cbItems.GetItems(aItems))
        return AddUniqueItems(aItems);

    // else
    return 0;
}

int CAutoComboBox::GetItems(CStringArray& aItems) const
{
    int nItem = GetCount();

    aItems.RemoveAll();
    aItems.SetSize(nItem);

    while (nItem--)
    {
        CString sItem;
		GetLBText(nItem, sItem);

        aItems.SetAt(nItem, sItem); // maintain order
    }

    return aItems.GetSize();
}

int CAutoComboBox::CalcMaxTextWidth(CDC* pDC, int nMin)
{
	CString sText;
	int nMaxWidth = nMin;
	int nItem = GetCount();
	
	while (nItem--)
	{
		GetLBText(nItem, sText);
		
		int nWidth = pDC->GetTextExtent(sText).cx;
		nMaxWidth = max(nMaxWidth, nWidth);
	}

	// check window text too
	GetWindowText(sText);

	int nWidth = pDC->GetTextExtent(sText).cx;
	nMaxWidth = max(nMaxWidth, nWidth);
	
	return nMaxWidth;
}


void CAutoComboBox::OnDropdown() 
{
	if (m_bAllowDelete)
	{
		// subclass the edit control whilst dropped down
		HookWindow(::GetDlgItem(GetSafeHwnd(), 1001));
	}
}

void CAutoComboBox::OnCloseup() 
{
	if (IsHooked())	
		HookWindow(NULL);
}

LRESULT CAutoComboBox::WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case WM_KEYDOWN:
		if (wp == VK_DELETE && m_hwndListbox)
		{
			int nSelItem = ::SendMessage(m_hwndListbox, LB_GETCURSEL, 0, 0);

			if (nSelItem >= 0)
			{
				CString sCurItem;
				int nCurSel = GetCurSel();

				// save existing selection
				if (nCurSel != -1)
					GetWindowText(sCurItem);

				::SendMessage(m_hwndListbox, LB_DELETESTRING, nSelItem, 0);

				// restore combo selection
				if (!sCurItem.IsEmpty())
					SelectString(0, sCurItem);

				// notify parent that we've been fiddling
				CComboBox::GetParent()->SendMessage(WM_COMMAND, 
													MAKEWPARAM(CComboBox::GetDlgCtrlID(), CBN_EDITCHANGE), 
													(LPARAM)GetSafeHwnd());

				// eat message else it'll go to the edit window
				return 0L;
			}
		}
		break;
	}

	return CSubclassWnd::Default();
}

HBRUSH CAutoComboBox::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CComboBox::OnCtlColor(pDC, pWnd, nCtlColor);

	// save handle of listbox window
	if (m_bAllowDelete && !m_hwndListbox && nCtlColor == CTLCOLOR_LISTBOX)
		m_hwndListbox = pWnd->GetSafeHwnd();
	
	return hbr;
}
