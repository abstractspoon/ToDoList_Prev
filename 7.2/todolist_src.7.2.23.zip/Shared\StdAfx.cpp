// stdafx.cpp : source file that includes just the standard includes
//	ToDoList.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

#define COMPILE_MULTIMON_STUBS

#pragma warning(push)
#pragma warning(disable:4706)
#include <multimon.h>
#pragma warning(pop)
