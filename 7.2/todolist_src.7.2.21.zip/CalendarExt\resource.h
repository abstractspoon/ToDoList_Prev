//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CalendarExt.rc
//
#define IDB_TOOLBAR_STD                 245
#define IDI_HELP_BUTTON                 293
#define IDR_CALENDAR                    1000
#define IDC_STATUSBAR                   1001
#define IDS_SNAP_NEARESTHOUR            1004
#define IDD_CALENDAR_DIALOG             1006
#define IDS_SNAP_NEARESTDAY             1007
#define IDS_SNAP_NEARESTHALFDAY         1008
#define IDC_NUMWEEKS                    1015
#define IDC_CALENDAR_FRAME              1016
#define IDC_DIVIDER                     1017
#define IDC_GOTOTODAY                   1029
#define IDC_PREFERENCES                 1030
#define IDC_SELECTEDTASKDATES           1032
#define IDC_DRAGMODE                    1033
#define IDC_SNAPMODES                   1034
#define IDC_SHOWCALCSTARTDATES          1038
#define IDC_SHOWCALCDUEDATES            1039
#define IDC_DYNAMICTASKHEIGHT           1040
#define IDC_SHOWOVERDUEASDUETODAY       1041
#define IDC_HIDEPARENTTASKS             1042
#define IDC_SHOWMINICALENDAR            2001
#define IDC_SHOWTASKSCONTINUOUS         2002
#define IDC_SHOWSTARTDATES              2003
#define IDC_SHOWDUEDATES                2004
#define IDC_USECREATIONFORSTART         2005
#define IDC_USEDUEFORSTART              2006
#define IDC_USEDUEORTODAYFORSTART       2007
#define IDC_USESTARTFORDUE              2008
#define IDC_USESTARTORTODAYFORDUE       2009
#define IDC_SHOWDONEDATES               2010
#define IDR_TOOLBAR                     16006
#define IDC_TB_PLACEHOLDER              16024
#define IDD_PREFERENCES_DIALOG          17002
#define IDD_PREFERENCES_PAGE            17003
#define IDC_PPHOST                      17019
#define ID_CAL_GOTOTODAY                32774
#define ID_CAL_PREFS                    32775
#define IDS_SNAP_FREE                   32790
#define ID_GOTOTODAY                    32795

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        32793
#define _APS_NEXT_COMMAND_VALUE         32799
#define _APS_NEXT_CONTROL_VALUE         1043
#define _APS_NEXT_SYMED_VALUE           32893
#endif
#endif
