// FMindImportExport.h : main header file for the FMINDIMPORTEXPORT DLL
//

#if !defined(AFX_FMINDIMPORTEXPORT_H__656730B3_F1EA_4E8F_B4B9_3EA2EF865F7A__INCLUDED_)
#define AFX_FMINDIMPORTEXPORT_H__656730B3_F1EA_4E8F_B4B9_3EA2EF865F7A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CFMindImportExportApp
// See FMindImportExport.cpp for the implementation of this class
//

class CFMindImportExportApp : public CWinApp
{
public:
	CFMindImportExportApp();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FMINDIMPORTEXPORT_H__656730B3_F1EA_4E8F_B4B9_3EA2EF865F7A__INCLUDED_)
