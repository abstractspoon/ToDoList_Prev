//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FtpStorage.rc
//
#define IDS_TDLFILEFILTER               102
#define IDR_FTPSTORAGE                  13001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        13002
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         13000
#define _APS_NEXT_SYMED_VALUE           13000
#endif
#endif
