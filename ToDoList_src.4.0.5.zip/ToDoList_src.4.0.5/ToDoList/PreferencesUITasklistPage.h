#if !defined(AFX_PREFERENCESUITASKLISTPAGE_H__9612D6FB_2A00_46DA_99A4_1AC6270F060D__INCLUDED_)
#define AFX_PREFERENCESUITASKLISTPAGE_H__9612D6FB_2A00_46DA_99A4_1AC6270F060D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesUITasklistPage.h : header file
//

#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUITasklistPage dialog

enum PTP_COLUMN
{
	PTPC_PRIORITY,
	PTPC_PERCENT,
	PTPC_TIMEEST,
	PTPC_STARTDATE,
	PTPC_DUEDATE,
	PTPC_DONEDATE,
	PTPC_ALLOCTO,
	PTPC_FILEREF,
	PTPC_POSITION,
	PTPC_ID,
	PTPC_DONE,
	PTPC_ALLOCBY,
	PTPC_STATUS,
	PTPC_CATEGORY,
	PTPC_TIMESPENT,
	PTPC_TRACKTIME,
	// add new items _ONLY_ at end
};

class CPreferencesUITasklistPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPreferencesUITasklistPage)

// Construction
public:
	CPreferencesUITasklistPage();
	~CPreferencesUITasklistPage();

	BOOL GetShowInfoTips() const { return m_bShowInfoTips; }
	BOOL GetShowComments() const { return m_bShowComments; }
	BOOL GetShowColumn(PTP_COLUMN nColumn) const;
	BOOL GetShowButtonsInTree() const { return m_bShowButtonsInTree; }
	BOOL GetShowPathInHeader() const { return m_bShowPathInHeader; }
	BOOL GetStrikethroughDone() const { return m_bStrikethroughDone; }
	BOOL GetFullRowSelection() const { return m_bFullRowSelection; }
	BOOL GetTreeCheckboxes() const { return m_bTreeCheckboxes; }
	BOOL GetEnableHeaderSorting() const { return m_bEnableHeaderSorting; }
	BOOL GetDisplayDatesInISO() const { return m_bUseISOForDates; }
	BOOL GetShowWeekdayInDates() const { return m_bShowWeekdayInDates; }
	BOOL GetShowParentsAsFolders() const { return m_bShowParentsAsFolders; }
	BOOL GetDisplayFirstCommentLine() const { return m_bShowComments && m_bDisplayFirstCommentLine; }

protected:
// Dialog Data
	//{{AFX_DATA(CPreferencesUITasklistPage)
	enum { IDD = IDD_PREFUITASKLIST_PAGE };
	BOOL	m_bUseISOForDates;
	BOOL	m_bShowWeekdayInDates;
	BOOL	m_bShowParentsAsFolders;
	BOOL	m_bDisplayFirstCommentLine;
	//}}AFX_DATA
	BOOL	m_bEnableHeaderSorting;
	BOOL	m_bShowPathInHeader;
	BOOL	m_bStrikethroughDone;
	BOOL	m_bFullRowSelection;
	BOOL	m_bTreeCheckboxes;
	CCheckListBox	m_lbColumnVisibility;
	BOOL	m_bShowInfoTips;
	BOOL	m_bShowComments;
	BOOL	m_bShowPercentColumn;
	BOOL	m_bShowPriorityColumn;
	BOOL	m_bShowButtonsInTree;
	int		m_nSelColumnVisibility;

	struct COLUMNPREF
	{
		COLUMNPREF() {}
		COLUMNPREF(LPCTSTR name, PTP_COLUMN col, BOOL visible) { szName = name; nCol = col; bVisible = visible; }

		LPCTSTR szName;
		PTP_COLUMN nCol;
		BOOL bVisible;
	};
	CArray<COLUMNPREF, COLUMNPREF&> m_aColPrefs;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesUITasklistPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	virtual void OnOK();

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesUITasklistPage)
	afx_msg void OnShowcomments();
	//}}AFX_MSG
	virtual BOOL OnInitDialog();
	afx_msg void OnColVisibilityChange();
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESUITASKLISTPAGE_H__9612D6FB_2A00_46DA_99A4_1AC6270F060D__INCLUDED_)
