#if !defined(AFX_ORDEREDTREECTRL_H__7E73ADE2_3848_4ED1_9E8B_8881813B4262__INCLUDED_)
#define AFX_ORDEREDTREECTRL_H__7E73ADE2_3848_4ED1_9E8B_8881813B4262__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ToDoCtrl.h : header file
//

#include "..\shared\ncgutter.h"
#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////
// COrderedTreeCtrl window

#define OTC_GRIDCOLOR ::GetSysColor(COLOR_3DFACE)
#define OTC_POSCOLUMNID (NCG_CLIENTCOLUMNID - 1)

class COrderedTreeCtrl : public CTreeCtrl
{
// Construction
public:
	COrderedTreeCtrl();
	virtual ~COrderedTreeCtrl();

	int AddGutterColumn(UINT nColID, LPCTSTR szTitle = NULL, UINT nWidth = 0, UINT nTextAlign = DT_LEFT);
	void PressGutterColumnHeader(UINT nColID, BOOL bPress = TRUE);
	void SetGutterColumnHeaderTitle(UINT nColID, LPCTSTR szTitle, LPCTSTR szFont = NULL, BOOL bSymbolFont = TRUE);
	void EnableGutterColumnHeaderClicking(UINT nColID, BOOL bEnable = TRUE);
	void SetGutterColumnSort(UINT nColID, NCGSORT nSortDir);

	void ShowGutterPosColumn(BOOL bShow = TRUE);
	void SetGridlineColor(COLORREF color);
   COLORREF GetGridlineColor() { return m_crGridlines; }

	inline void RedrawGutter() { m_gutter.Redraw(); }
	inline void RedrawGutterItem(DWORD dwItem) { m_gutter.RedrawItem(dwItem); }
	inline void RecalcGutter(BOOL bForceRedraw = TRUE) { m_gutter.RecalcGutter(bForceRedraw); }
	inline BOOL RecalcGutterColumn(UINT nColID) { return m_gutter.RecalcGutterColumn(nColID); }
	inline int GetGutterWidth() { return m_gutter.GetGutterWidth(); }

	BOOL HasFocus(BOOL bIncEditing = TRUE);
	BOOL IsItemExpanded(HTREEITEM hItem) const;
	void ExpandAll(BOOL bExpand = TRUE, HTREEITEM hti = NULL);
	void ExpandItem(HTREEITEM hti, BOOL bExpand = TRUE);

	void SetItemIntegral(HTREEITEM hti, int iIntegral);

	inline COLORREF GetAlternateLineColor() { return m_crAltLines; }
	void SetAlternateLineColor(COLORREF color);
	BOOL ItemLineIsOdd(HTREEITEM hti);

protected:
	CNcGutter m_gutter;
	BOOL m_bShowingPosColumn;
	COLORREF m_crGridlines, m_crAltLines;
	CMap<HTREEITEM, HTREEITEM, int, int&> m_mapVisibleIndices;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COrderedTreeCtrl)
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

	// Generated message map functions
protected:
	//{{AFX_MSG(COrderedTreeCtrl)
	afx_msg void OnSettingChange(UINT uFlags, LPCTSTR lpszSection);
	//}}AFX_MSG
	afx_msg BOOL OnItemexpanded(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBeginDrag(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg LRESULT OnPostSubclass(WPARAM wParam, LPARAM lParam);
	afx_msg void OnStyleChanged(int nStyleType, LPSTYLESTRUCT lpSS);
	afx_msg BOOL OnClick(NMHDR* pNMHDR, LRESULT* pResult);

	// callbacks for gutter
	afx_msg LRESULT OnGutterGetFirstVisibleTopLevelItem(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterGetNextItem(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterGetFirstChildItem(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterDrawItem(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterPostDrawItem(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterPostNcDraw(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterRecalcColWidth(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterGetItemRect(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterIsItemSelected(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterGetSelectedCount(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterHitTest(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterNotifyItemClick(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterGetParentID(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterWantRecalc(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()

protected:
	// returns the top level item whose child is the first visible item (or itself)
	DWORD GetFirstVisibleTopLevelItem(int& nPos); // return 0 if no items
	HTREEITEM GetTopLevelParentItem(HTREEITEM hti);

	int BuildVisibleIndexMap();
	void AddVisibleItemToIndex(HTREEITEM hti);

	void NcDrawItem(CDC* pDC, DWORD dwItem, DWORD dwParentItem, UINT nColID, CRect& rItem, 
					int nLevel, int nPos, BOOL bSelected, const CRect& rWindow);
	void PostNcDrawItem(CDC* pDC, DWORD dwItem, const CRect& rItem, int nLevel);
	void PostNcDraw(CDC* pDC, const CRect& rWindow);

	int GetItemPos(HTREEITEM hti, HTREEITEM htiParent);
	int GetItemLevel(HTREEITEM hti);

	BOOL RecalcColumnWidth(CDC* pDC, UINT nColID, UINT& nWidth);
	UINT GetGutterWidth(HTREEITEM hti, int nLevel, int nPos, CDC* pDC);
	static UINT GetWidth(int nNumber, CDC* pDC); // includes a trailing '.'

	inline void EndLabelEdit(BOOL bCancel) { SendMessage(TVM_ENDEDITLABELNOW, bCancel, 0); }
	
	void InvalidateItem(HTREEITEM hti, BOOL bChildren = TRUE);
	void GetClientRect(LPRECT lpRect, HTREEITEM htiFrom);

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ORDEREDTREECTRL_H__7E73ADE2_3848_4ED1_9E8B_8881813B4262__INCLUDED_)
