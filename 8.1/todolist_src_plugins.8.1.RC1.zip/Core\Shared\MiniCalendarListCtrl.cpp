// MiniCalendarCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "MiniCalendarListCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMiniCalendarCtrl

CMiniCalendarListCtrl::CMiniCalendarListCtrl()
{
}

CMiniCalendarListCtrl::~CMiniCalendarListCtrl()
{
}


BEGIN_MESSAGE_MAP(CMiniCalendarListCtrl, CFPSMiniCalendarListCtrl)
	//{{AFX_MSG_MAP(CMiniCalendarCtrl)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CMiniCalendarCtrl message handlers
