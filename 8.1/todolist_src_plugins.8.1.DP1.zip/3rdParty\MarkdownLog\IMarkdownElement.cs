namespace MarkdownLog
{
    public interface IMarkdownElement
    {
         string ToMarkdown();
    }
}