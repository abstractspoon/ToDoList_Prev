//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TDLTest.rc
//
#define IDR_MAINFRAME_STD               128
#define IDI_TIME_TRACK                  286
#define IDI_DEPENDS_LINK                289
#define IDI_NULL                        290
#define IDI_ADD_LOGGED_TIME             308
#define IDS_ONCEONLY                    51018
#define IDS_DAILY                       51019
#define IDS_WEEKLY                      51020
#define IDS_MONTHLY                     51021
#define IDS_YEARLY                      51022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
