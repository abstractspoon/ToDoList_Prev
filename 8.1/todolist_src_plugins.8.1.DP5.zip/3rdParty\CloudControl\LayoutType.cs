﻿namespace Gma.CodeCloud.Controls
{
    public enum LayoutType
    {
        Typewriter,
        Spiral,
    }
}
