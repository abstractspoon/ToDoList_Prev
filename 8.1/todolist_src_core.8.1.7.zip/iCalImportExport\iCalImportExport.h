// iCalImportExport.h : main header file for the ICALIMPORTEXPORT DLL
//

#if !defined(AFX_ICALIMPORTEXPORT_H__B49ADE71_74DD_40A0_BDE8_9A5F69D3DDC6__INCLUDED_)
#define AFX_ICALIMPORTEXPORT_H__B49ADE71_74DD_40A0_BDE8_9A5F69D3DDC6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CICalImportExportApp
// See iCalImportExport.cpp for the implementation of this class
//

class CICalImportExportApp : public CWinApp
{
public:
	CICalImportExportApp();
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ICALIMPORTEXPORT_H__B49ADE71_74DD_40A0_BDE8_9A5F69D3DDC6__INCLUDED_)
