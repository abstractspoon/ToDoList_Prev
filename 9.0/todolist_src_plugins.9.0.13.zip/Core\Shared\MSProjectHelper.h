// MSProjectHelper.h: interface for the CMSProjectHelper class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MSPROJECTHELPER_H__DADF02F4_F1C9_4C6A_9FAA_EBD25E725132__INCLUDED_)
#define AFX_MSPROJECTHELPER_H__DADF02F4_F1C9_4C6A_9FAA_EBD25E725132__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMSProjectHelper  
{
public:
	CMSProjectHelper();
	virtual ~CMSProjectHelper();

};

#endif // !defined(AFX_MSPROJECTHELPER_H__DADF02F4_F1C9_4C6A_9FAA_EBD25E725132__INCLUDED_)
