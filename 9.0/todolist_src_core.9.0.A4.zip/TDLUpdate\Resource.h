//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TDLUpdate.rc
//
#define IDR_MANIFEST                    1
#define IDD_TDLUPDATE_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDD_WEBUPDATE_PROGRESS_PAGE     272
#define IDC_PROGRESS                    1427
#define IDS_WEBUPDATE_SUCCESS           58383
#define IDS_WEBUPDATE_FAILURE           58384
#define IDS_WEBUPDATEPROGRESS_UNZIP     58385
#define IDS_WEBUPDATEPROGRESS_DOWNLOAD  58386
#define IDS_WEBUPDATEPROGRESS_COPY      58387
#define IDS_WEBUPDATEPROGRESS_BACKUP    58388
#define IDS_WEBUPDATEPROGRESS_CLEANUP   58389
#define IDS_WEBUPDATEDONE               58390
#define IDS_WEBUPDATE_PROGRESSHEADER    58392
#define IDS_WEBUPDATE_PROGRESS          58393
#define IDS_WEBUPDATE_CANCEL            58394

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
