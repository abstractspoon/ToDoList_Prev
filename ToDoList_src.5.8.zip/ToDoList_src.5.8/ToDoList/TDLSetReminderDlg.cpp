// TDLReminderDlg.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "TDLSetReminderDlg.h"
#include "filteredtodoctrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTDLSetReminderDlg dialog


CTDLSetReminderDlg::CTDLSetReminderDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTDLSetReminderDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTDLSetReminderDlg)
	m_dLeadIn = 0.25;
	m_bFromDueDate = 0;
	m_sTaskTitle = _T("");
	//}}AFX_DATA_INIT
}


void CTDLSetReminderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTDLSetReminderDlg)
	DDX_Control(pDX, IDC_LEADIN, m_cbLeadIn);
	DDX_CBIndex(pDX, IDC_LEADIN, m_nLeadIn);
	DDX_CBIndex(pDX, IDC_FROMWHERE, m_bFromDueDate);
	DDX_Text(pDX, IDC_TASKTITLE, m_sTaskTitle);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTDLSetReminderDlg, CDialog)
	//{{AFX_MSG_MAP(CTDLSetReminderDlg)
	ON_CBN_SELCHANGE(IDC_LEADIN, OnSelchangeLeadin)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTDLSetReminderDlg message handlers

int CTDLSetReminderDlg::DoModal(const TDCREMINDER& rem)
{
	m_sTaskTitle = rem.pTDC->GetTaskTitle(rem.dwTaskID);
	m_dLeadIn = rem.dDaysLeadIn * 24;
	m_bFromDueDate = (rem.nFromWhen == TDCR_DUEDATE);

	return CDialog::DoModal();
}

BOOL CTDLSetReminderDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// set item data to be time in minutes
	m_cbLeadIn.SetItemData(0, 5);  // 5 minutes
	m_cbLeadIn.SetItemData(1, 10); // 10 minutes
	m_cbLeadIn.SetItemData(2, 15); // 15 minutes
	m_cbLeadIn.SetItemData(3, 20); // 20 minutes
	m_cbLeadIn.SetItemData(4, 30); // 30 minutes
	m_cbLeadIn.SetItemData(5, 45); // 45 minutes
	m_cbLeadIn.SetItemData(6, 60); // 1 hour
	m_cbLeadIn.SetItemData(7, 120); //  2 hours
	m_cbLeadIn.SetItemData(8, 180); //  3 hours
	m_cbLeadIn.SetItemData(9, 240); //  4 hours
	m_cbLeadIn.SetItemData(10, 300); //  5 hours
	m_cbLeadIn.SetItemData(11, 360); //  6 hours
	m_cbLeadIn.SetItemData(12, 720); //  12 hours
	m_cbLeadIn.SetItemData(13, 1440); //  1 day
	m_cbLeadIn.SetItemData(14, 2880); //  2 days
	m_cbLeadIn.SetItemData(15, 4320); //  3 days
	m_cbLeadIn.SetItemData(16, 5760); //  4 days
	m_cbLeadIn.SetItemData(17, 7200); //  5 days
	m_cbLeadIn.SetItemData(18, 8640); //  6 days
	m_cbLeadIn.SetItemData(19, 10080); //  1 week

	// work out the index to select
	for (int nTime = 0; nTime < m_cbLeadIn.GetCount(); nTime++)
	{
		double dHours = m_cbLeadIn.GetItemData(nTime) / 60.0;

		if (dHours >= m_dLeadIn)
		{
			m_cbLeadIn.SetCurSel(nTime);
			m_nLeadIn = nTime;
			break;
		}
	}


	return TRUE;
}

void CTDLSetReminderDlg::OnSelchangeLeadin() 
{
	UpdateData();

	m_dLeadIn = m_cbLeadIn.GetItemData(m_nLeadIn) / 60.0; // in hours
	
}
