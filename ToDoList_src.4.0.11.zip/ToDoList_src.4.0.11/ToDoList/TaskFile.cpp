// TaskFile.cpp: implementation of the CTaskFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TaskFile.h"
#include "tdlschemadef.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTaskFile::CTaskFile(LPCTSTR szRootItemName, LPCTSTR szPassword) :
	CXmlFileEx(szRootItemName, szPassword)
{

}

CTaskFile::~CTaskFile()
{

}

BOOL CTaskFile::LoadEx(LPCTSTR szRootItemName, IXmlParse* pCallback)
{
	BOOL bResult = CXmlFileEx::LoadEx(szRootItemName, pCallback);

	if (bResult)
	{
		// fix corrupted tasklist where the root item has an ID
		CXmlItem* pXI = GetItem(TDL_TASKID);

		while (pXI)
		{
			DeleteItem(pXI);
			pXI = GetItem(TDL_TASKID);
		}
	}

	return bResult;
}
