//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PlainTextImport.rc
//
#define IDS_IMPORTLABEL                 1
#define IDS_EXPORTLABEL                 2
#define IDS_IMPORTTITLE                 3
#define IDS_EXPORTTITLE                 4
#define IDS_IMPORTPROJECTLABEL          5
#define IDS_EXPORTPROJECTLABEL          6
#define IDD_OPTIONSDIALOG               1000
#define IDC_CBLABEL                     1000
#define IDC_PROJECTINCLUDED             1001
#define IDC_TABWIDTHS                   1029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1002
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
