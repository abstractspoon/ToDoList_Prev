// FMindImporter.h: interface for the CFMindImporter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FMINDIMPORTER_H__48AE3CCE_E042_432D_B5DB_D7E310CF99CE__INCLUDED_)
#define AFX_FMINDIMPORTER_H__48AE3CCE_E042_432D_B5DB_D7E310CF99CE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\SHARED\IImportExport.h"
#include "..\SHARED\ITasklist.h"
#include "..\SHARED\xmlfile.h"

class CFMindImporter : public IImportTasklist  
{
public:
	CFMindImporter();
	virtual ~CFMindImporter();
	// interface implementation
	void Release() { delete this; }
	
	// caller must copy only
	const char* GetMenuText() { return "FreeMind"; }
	const char* GetFileFilter() { return "FreeMind Files (*.mm)|*.mm||"; }
	const char* GetFileExtension() { return "mm"; }
	
	bool Import(const char* szSrcFilePath, ITaskList* pDestTaskFile);

protected:
	bool ImportTask(const CXmlItem* pXIMLOTask, ITaskList7* pDestTaskFile, HTASKITEM hParent) const;
	long GetColor(const CXmlItem* pXIMLOTask, LPCTSTR szColorField) const;
	long GetDate(const CXmlItem* pXIMLOTask, LPCTSTR szColorField) const;
	CString GetAttribValueS(const CXmlItem *TaskItem , const CString &AttribName) const;
	int GetAttribValueI(const CXmlItem *TaskItem , const char *AttribName) const;
	bool GetAttribValueB(const CXmlItem *TaskItem , const char *AttribName) const;
	double GetAttribValueD(const CXmlItem *TaskItem , const char *AttribName) const;

};

#endif // !defined(AFX_FMINDIMPORTER_H__48AE3CCE_E042_432D_B5DB_D7E310CF99CE__INCLUDED_)
