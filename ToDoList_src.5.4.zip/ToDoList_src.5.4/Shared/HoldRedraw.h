// SetRedraw.h: interface and implementation of the CSetRedraw class.
//
/////////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_HOLDREDRAW_H__7E73ADE2_3848_4ED1_9E8B_8881813B4262__INCLUDED_)
#define AFX_HOLDREDRAW_H__7E73ADE2_3848_4ED1_9E8B_8881813B4262__INCLUDED_

enum
{
	NCR_UPDATE = 0x01,
	NCR_PAINT = 0x02,
	NCR_NCPAINT = 0x04,
};

class CNcRedraw // note: there is no inheritance intentionally.
{
public:
	CNcRedraw(HWND hWnd, LPCTSTR szTrace = NULL) : m_hWnd(hWnd), m_sTrace(szTrace)
	{
	}

	virtual ~CNcRedraw()
	{
		if (m_hWnd && ::IsWindowVisible(m_hWnd))
		{
			//TRACE("~CNcRedraw(%s)\n", m_sTrace);
			::SendMessage(m_hWnd, WM_NCPAINT, 0, 0);
		}
	}

protected:
	HWND m_hWnd;
	CString m_sTrace;
};

class CRedrawAll
{
public:
	CRedrawAll(HWND hWnd, DWORD dwFlags = NCR_PAINT | NCR_NCPAINT) : m_hWnd(hWnd), m_dwFlags(dwFlags)
	{
	}

	virtual ~CRedrawAll()
	{
		if (m_hWnd && ::IsWindowVisible(m_hWnd))
		{
			//TRACE("~CRedrawAll()\n");

			if (m_dwFlags & NCR_NCPAINT)
				::SendMessage(m_hWnd, WM_NCPAINT, 0, 0);

			if (m_dwFlags & NCR_PAINT)
			{
				::InvalidateRect(m_hWnd, NULL, FALSE);

				if (m_dwFlags & NCR_UPDATE)
					::UpdateWindow(m_hWnd);
			}
		}
	}

protected:
	HWND m_hWnd;
	DWORD m_dwFlags;
};

class CHoldRedraw : protected CRedrawAll
{
public:
	CHoldRedraw(HWND hWnd, DWORD dwFlags = NCR_PAINT | NCR_NCPAINT) : CRedrawAll(hWnd, dwFlags)
	{
		if (m_hWnd)
		{
			//TRACE ("Disabling redraw on 0x%08x\n", m_hWnd);
			::SendMessage(m_hWnd, WM_SETREDRAW, FALSE, 0);
		}
	}

	virtual ~CHoldRedraw()
	{
		if (m_hWnd)
		{
			//TRACE ("Re-enabling redraw on 0x%08x\n", m_hWnd);
			::SendMessage(m_hWnd, WM_SETREDRAW, TRUE, 0);
		}
	}
};

#endif
