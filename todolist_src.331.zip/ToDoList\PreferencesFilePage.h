#if !defined(AFX_PREFERENCESFILEPAGE_H__0A884806_5921_4C13_B368_6D14A441ADAC__INCLUDED_)
#define AFX_PREFERENCESFILEPAGE_H__0A884806_5921_4C13_B368_6D14A441ADAC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesFilePage.h : header file
//

#include "..\shared\fontcombobox.h"
#include "..\shared\fileedit.h"

/////////////////////////////////////////////////////////////////////////////
// CPreferencesFilePage dialog

class CPreferencesFilePage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPreferencesFilePage)

// Construction
public:
	CPreferencesFilePage();
	~CPreferencesFilePage();

	int GetTextIndent() const { return m_nTextIndent; }
	BOOL GetAutoHtmlExport() const { return m_bAutoHtmlExport; }
	BOOL GetExportVisibleOnly() const { return m_bExportVisibleOnly; }
	int GetAutoSaveFrequency() const { return m_nAutoSaveFrequency; }
	CString GetHtmlFont() const { return m_sHtmlFont; }
	BOOL GetPreviewExport() const { return m_bPreviewSaveAs; }
	BOOL GetRemoveArchivedTasks() const { return m_bRemoveArchivedTasks; }
	BOOL GetRemoveOnlyOnAbsoluteCompletion() const { return m_bRemoveOnlyOnAbsoluteCompletion; }
	BOOL GetExportIncompleteOnly() const { return m_bExportIncompleteOnly; }
	CString GetAutoExportFolderPath() const;

protected:
// Dialog Data
	//{{AFX_DATA(CPreferencesFilePage)
	enum { IDD = IDD_PREFFILE_PAGE };
	CFileEdit	m_eExportFolderPath;
	BOOL	m_bExportIncompleteOnly;
	BOOL	m_bExportToFolder;
	CString	m_sExportFolderPath;
	//}}AFX_DATA
	CComboBox	m_cbAutoSave;
	CComboBox	m_cbIndent;
	CFontComboBox	m_cbFonts;
	BOOL	m_bPreviewSaveAs;
	BOOL	m_bRemoveArchivedTasks;
	BOOL	m_bRemoveOnlyOnAbsoluteCompletion;
	BOOL	m_bExportVisibleOnly;
	CString m_sHtmlFont;
	int m_nTextIndent;
	int m_nAutoSaveFrequency;
	BOOL	m_bAutoSave;
	BOOL	m_bAutoHtmlExport;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesFilePage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	virtual void OnOK();

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesFilePage)
	virtual BOOL OnInitDialog();
	afx_msg void OnExporttofolder();
	afx_msg void OnAutohtmlexport();
	//}}AFX_MSG
	afx_msg void OnRemovearchiveditems();
	afx_msg void OnAutosave();
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESFILEPAGE_H__0A884806_5921_4C13_B368_6D14A441ADAC__INCLUDED_)
