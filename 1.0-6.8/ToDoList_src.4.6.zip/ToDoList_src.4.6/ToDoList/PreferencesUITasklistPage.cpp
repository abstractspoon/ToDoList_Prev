// PreferencesUITasklistPage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesUITasklistPage.h"

#include "..\shared\colordef.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUITasklistPage property page

CPreferencesUITasklistPage::CPreferencesUITasklistPage() : 
	CPropertyPage(CPreferencesUITasklistPage::IDD)
{
	//{{AFX_DATA_INIT(CPreferencesUITasklistPage)
	m_bShowParentsAsFolders = FALSE;
	m_bDisplayFirstCommentLine = FALSE;
	m_nMaxInfoTipCommentsLength = 0;
	m_bLimitInfoTipCommentsLength = FALSE;
	m_bAutoFocusTasklist = FALSE;
	//}}AFX_DATA_INIT
	
	// column visibility
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_POS, PTPC_POSITION, TRUE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_ID, PTPC_ID, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_PRIORITY, PTPC_PRIORITY, TRUE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_PERCENT, PTPC_PERCENT, TRUE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_TIMEEST, PTPC_TIMEEST, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_TIMESPENT, PTPC_TIMESPENT, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_TRACKTIME, PTPC_TRACKTIME, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_CREATEDBY, PTPC_CREATEDBY, FALSE));
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_CREATEDATE, PTPC_CREATIONDATE, FALSE));
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_STARTDATE, PTPC_STARTDATE, FALSE));
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_DUEDATE, PTPC_DUEDATE, TRUE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_DONEDATE, PTPC_DONEDATE, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_ALLOCTO, PTPC_ALLOCTO, TRUE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_ALLOCBY, PTPC_ALLOCBY, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_STATUS, PTPC_STATUS, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_CATEGORY, PTPC_CATEGORY, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_FILEREF, PTPC_FILEREF, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_FLAG, PTPC_FLAG, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_DONE, PTPC_DONE, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_MODIFYDATE, PTPC_MODIFYDATE, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_RISK, PTPC_RISK, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF(IDS_PTUIP_EXTERNALID, PTPC_EXTERNALID, FALSE)); 

	int nIndex = m_aColPrefs.GetSize();
	
	while (nIndex--)
	{
		COLUMNPREF& col = m_aColPrefs[nIndex];

		CString sKey;
		sKey.Format("Col%d", col.nCol);
		
		col.bVisible = AfxGetApp()->GetProfileInt("Preferences\\ColumnVisibility", sKey, col.bVisible);
	}

	// prefs
	m_bShowInfoTips = AfxGetApp()->GetProfileInt("Preferences", "ShowInfoTips", TRUE);
	m_bShowComments = AfxGetApp()->GetProfileInt("Preferences", "ShowComments", TRUE);
	m_bDisplayFirstCommentLine = AfxGetApp()->GetProfileInt("Preferences", "DisplayFirstCommentLine", TRUE);
	m_bShowButtonsInTree = AfxGetApp()->GetProfileInt("Preferences", "ShowButtonsInTree", TRUE);
	m_bStrikethroughDone = AfxGetApp()->GetProfileInt("Preferences", "StrikethroughDone", TRUE);
	m_bShowPathInHeader = AfxGetApp()->GetProfileInt("Preferences", "ShowPathInHeader", TRUE);
	m_bFullRowSelection = AfxGetApp()->GetProfileInt("Preferences", "FullRowSelection", FALSE);
	m_bTreeCheckboxes = AfxGetApp()->GetProfileInt("Preferences", "TreeCheckboxes", FALSE);
	m_bUseISOForDates = AfxGetApp()->GetProfileInt("Preferences", "DisplayDatesInISO", FALSE);
	m_bShowWeekdayInDates = AfxGetApp()->GetProfileInt("Preferences", "ShowWeekdayInDates", FALSE);
	m_bShowParentsAsFolders = AfxGetApp()->GetProfileInt("Preferences", "ShowParentsAsFolders", FALSE);
	m_nMaxInfoTipCommentsLength = AfxGetApp()->GetProfileInt("Preferences", "MaxInfoTipCommentsLength", 100);
	m_bLimitInfoTipCommentsLength = AfxGetApp()->GetProfileInt("Preferences", "LimitInfoTipCommentsLength", FALSE);
	m_bHidePercentForDoneTasks = AfxGetApp()->GetProfileInt("Preferences", "HidePercentForDoneTasks", TRUE);
	m_bHideStartDueForDoneTasks = AfxGetApp()->GetProfileInt("Preferences", "HideStartDueForDoneTasks", TRUE);
	m_bHideZeroTimeEst = AfxGetApp()->GetProfileInt("Preferences", "HideZeroTimeEst", TRUE);
	m_bShowPercentAsProgressbar = AfxGetApp()->GetProfileInt("Preferences", "ShowPercentAsProgressbar", FALSE);
	m_bRoundTimeFractions = AfxGetApp()->GetProfileInt("Preferences", "RoundTimeFractions", FALSE);
	m_bShowNonFilesAsText = AfxGetApp()->GetProfileInt("Preferences", "ShowNonFilesAsText", FALSE);
	m_bUseHMSTimeFormat = AfxGetApp()->GetProfileInt("Preferences", "UseHMSTimeFormat", FALSE);
	m_bAutoFocusTasklist = AfxGetApp()->GetProfileInt("Preferences", "AutoFocusTasklist", FALSE);
}

CPreferencesUITasklistPage::~CPreferencesUITasklistPage()
{
}

void CPreferencesUITasklistPage::DoDataExchange(CDataExchange* pDX)
{ 
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesUITasklistPage)
	DDX_Check(pDX, IDC_USEISODATEFORMAT, m_bUseISOForDates);
	DDX_Check(pDX, IDC_SHOWWEEKDAYINDATES, m_bShowWeekdayInDates);
	DDX_Check(pDX, IDC_SHOWPARENTSASFOLDERS, m_bShowParentsAsFolders);
	DDX_Check(pDX, IDC_DISPLAYFIRSTCOMMENTLINE, m_bDisplayFirstCommentLine);
	DDX_Check(pDX, IDC_LIMITINFOTIPCOMMENTS, m_bLimitInfoTipCommentsLength);
	DDX_Check(pDX, IDC_AUTOFOCUSTASKLIST, m_bAutoFocusTasklist);
	//}}AFX_DATA_MAP
	DDX_Check(pDX, IDC_DISPLAYPATHINHEADER, m_bShowPathInHeader);
	DDX_Check(pDX, IDC_STRIKETHROUGHDONE, m_bStrikethroughDone);
	DDX_Check(pDX, IDC_FULLROWSELECTION, m_bFullRowSelection);
	DDX_Check(pDX, IDC_TREECHECKBOXES, m_bTreeCheckboxes);
	DDX_Control(pDX, IDC_COLUMNVISIBILITY, m_lbColumnVisibility);
	DDX_Check(pDX, IDC_SHOWINFOTIPS, m_bShowInfoTips);
	DDX_Check(pDX, IDC_SHOWCOMMENTS, m_bShowComments);
	DDX_Check(pDX, IDC_SHOWBUTTONSINTREE, m_bShowButtonsInTree);
	DDX_LBIndex(pDX, IDC_COLUMNVISIBILITY, m_nSelColumnVisibility);
	DDX_Text(pDX, IDC_INFOTIPCOMMENTSMAX, m_nMaxInfoTipCommentsLength);
	DDX_Check(pDX, IDC_HIDEUNDEFINEDTIMEST, m_bHideZeroTimeEst);
	DDX_Check(pDX, IDC_HIDESTARTDUEFORDONETASKS, m_bHideStartDueForDoneTasks);
	DDX_Check(pDX, IDC_ROUNDTIMEFRACTIONS, m_bRoundTimeFractions);
	DDX_Check(pDX, IDC_SHOWNONFILEREFSASTEXT, m_bShowNonFilesAsText);
	DDX_Check(pDX, IDC_USEHMSTIMEFORMAT, m_bUseHMSTimeFormat);
	DDX_Check(pDX, IDC_SHOWPERCENTPROGRESSBAR, m_bShowPercentAsProgressbar);
	DDX_Check(pDX, IDC_HIDEPERCENTFORDONETASKS, m_bHidePercentForDoneTasks);
}


BEGIN_MESSAGE_MAP(CPreferencesUITasklistPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPreferencesUITasklistPage)
	ON_BN_CLICKED(IDC_SHOWCOMMENTS, OnShowcomments)
	ON_BN_CLICKED(IDC_SHOWINFOTIPS, OnShowinfotips)
	ON_BN_CLICKED(IDC_LIMITINFOTIPCOMMENTS, OnLimitinfotipcomments)
	//}}AFX_MSG_MAP
	ON_CLBN_CHKCHANGE(IDC_COLUMNVISIBILITY, OnColVisibilityChange)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUITasklistPage message handlers

BOOL CPreferencesUITasklistPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	m_mgrGroupLines.AddGroupLine(IDC_COLUMNGROUP, *this);

	// column visibility
	int nIndex = (int)m_aColPrefs.GetSize();
	
	while (nIndex--)
	{
		int nPos = m_lbColumnVisibility.InsertString(0, m_aColPrefs[nIndex].sName);
		m_lbColumnVisibility.SetCheck(nPos, m_aColPrefs[nIndex].bVisible ? 1 : 0);

		// note: we can't use SetItemData because CCheckListBox uses it
	}

	GetDlgItem(IDC_DISPLAYFIRSTCOMMENTLINE)->EnableWindow(m_bShowComments);
	GetDlgItem(IDC_LIMITINFOTIPCOMMENTS)->EnableWindow(m_bShowInfoTips);
	GetDlgItem(IDC_INFOTIPCOMMENTSMAX)->EnableWindow(m_bShowInfoTips && m_bLimitInfoTipCommentsLength);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

int CPreferencesUITasklistPage::GetMaxInfoTipCommentsLength() const
{
	if (m_bShowInfoTips)
		return m_bLimitInfoTipCommentsLength ? max(0, m_nMaxInfoTipCommentsLength) : -1;

	return -1;
}

BOOL CPreferencesUITasklistPage::GetShowColumn(PTP_COLUMN nColumn) const
{ 
	int nIndex = (int)m_aColPrefs.GetSize();
	
	while (nIndex--)
	{
		if (m_aColPrefs[nIndex].nCol == nColumn)
			return m_aColPrefs[nIndex].bVisible; 
	}

	// else
	return FALSE;
}

void CPreferencesUITasklistPage::OnColVisibilityChange()
{
	UpdateData();

	ASSERT (m_nSelColumnVisibility >= 0);
	
	if (m_nSelColumnVisibility >= 0)
		m_aColPrefs[m_nSelColumnVisibility].bVisible = m_lbColumnVisibility.GetCheck(m_nSelColumnVisibility);
}


void CPreferencesUITasklistPage::OnOK() 
{
	CPropertyPage::OnOK();
	
	// save settings
	// column visibility
	int nIndex = m_aColPrefs.GetSize();

	while (nIndex--)
	{
		CString sKey;
		sKey.Format("Col%d", m_aColPrefs[nIndex].nCol);

		AfxGetApp()->WriteProfileInt("Preferences\\ColumnVisibility", sKey, m_aColPrefs[nIndex].bVisible);
	}

	// save settings
	AfxGetApp()->WriteProfileInt("Preferences", "ShowInfoTips", m_bShowInfoTips);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowComments", m_bShowComments);
	AfxGetApp()->WriteProfileInt("Preferences", "DisplayFirstCommentLine", m_bDisplayFirstCommentLine);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowPercentColumn", m_bShowPercentColumn);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowPriorityColumn", m_bShowPriorityColumn);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowButtonsInTree", m_bShowButtonsInTree);
	AfxGetApp()->WriteProfileInt("Preferences", "StrikethroughDone", m_bStrikethroughDone);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowPathInHeader", m_bShowPathInHeader);
	AfxGetApp()->WriteProfileInt("Preferences", "FullRowSelection", m_bFullRowSelection);
	AfxGetApp()->WriteProfileInt("Preferences", "TreeCheckboxes", m_bTreeCheckboxes);
	AfxGetApp()->WriteProfileInt("Preferences", "DisplayDatesInISO", m_bUseISOForDates);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowWeekdayInDates", m_bShowWeekdayInDates);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowParentsAsFolders", m_bShowParentsAsFolders);
	AfxGetApp()->WriteProfileInt("Preferences", "MaxInfoTipCommentsLength", max(m_nMaxInfoTipCommentsLength, 0));
	AfxGetApp()->WriteProfileInt("Preferences", "LimitInfoTipCommentsLength", m_bLimitInfoTipCommentsLength);
	AfxGetApp()->WriteProfileInt("Preferences", "HidePercentForDoneTasks", m_bHidePercentForDoneTasks);
	AfxGetApp()->WriteProfileInt("Preferences", "HideStartDueForDoneTasks", m_bHideStartDueForDoneTasks);
	AfxGetApp()->WriteProfileInt("Preferences", "HideZeroTimeEst", m_bHideZeroTimeEst);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowPercentAsProgressbar", m_bShowPercentAsProgressbar);
	AfxGetApp()->WriteProfileInt("Preferences", "RoundTimeFractions", m_bRoundTimeFractions);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowNonFilesAsText", m_bShowNonFilesAsText);
	AfxGetApp()->WriteProfileInt("Preferences", "UseHMSTimeFormat", m_bUseHMSTimeFormat);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoFocusTasklist", m_bAutoFocusTasklist);
}

void CPreferencesUITasklistPage::OnShowcomments() 
{
	UpdateData();

	GetDlgItem(IDC_DISPLAYFIRSTCOMMENTLINE)->EnableWindow(m_bShowComments);
}

void CPreferencesUITasklistPage::OnShowinfotips() 
{
	UpdateData();

	GetDlgItem(IDC_LIMITINFOTIPCOMMENTS)->EnableWindow(m_bShowInfoTips);
	GetDlgItem(IDC_INFOTIPCOMMENTSMAX)->EnableWindow(m_bShowInfoTips && m_bLimitInfoTipCommentsLength);
}

void CPreferencesUITasklistPage::OnLimitinfotipcomments() 
{
	UpdateData();

	GetDlgItem(IDC_INFOTIPCOMMENTSMAX)->EnableWindow(m_bShowInfoTips && m_bLimitInfoTipCommentsLength);
}

