// TDLPrintDialog.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "TDLPrintDialog.h"

#include "..\shared\enstring.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTDLPrintDialog dialog


CTDLPrintDialog::CTDLPrintDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CTDLPrintDialog::IDD, pParent),
		m_eStylesheet(FES_COMBOSTYLEBTN, CEnString(IDS_XSLFILEFILTER))

{
	//{{AFX_DATA_INIT(CTDLPrintDialog)
	//}}AFX_DATA_INIT
	m_bCompletedTasks = AfxGetApp()->GetProfileInt("Print", "CompletedTasks", TRUE);
	m_bIncompleteTasks = AfxGetApp()->GetProfileInt("Print", "IncompleteTasks", TRUE);
	m_bSelectedTasks = FALSE;
	
	// see what we had last time
	m_sStylesheet = AfxGetApp()->GetProfileString("Print", "Stylesheet");

	// check whether user has set stylesheet in prefs
	if (m_sStylesheet.IsEmpty() || AfxGetApp()->GetProfileInt("Print", "DefaultStylesheet", FALSE))
	{
		CString sDefStylesheet = AfxGetApp()->GetProfileString("Preferences", "PrintStylesheet");

		if (!sDefStylesheet.IsEmpty())
			m_sStylesheet = sDefStylesheet;
	}

	m_bUseStylesheet = (!m_sStylesheet.IsEmpty());
}


void CTDLPrintDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTDLPrintDialog)
	DDX_Control(pDX, IDC_PRINTSTYLESHEET, m_eStylesheet);
	DDX_Check(pDX, IDC_INCLUDEDONE, m_bCompletedTasks);
	DDX_Check(pDX, IDC_INCLUDENOTDONE, m_bIncompleteTasks);
	DDX_Radio(pDX, IDC_ALLTASKS, m_bSelectedTasks);
	DDX_Text(pDX, IDC_PRINTSTYLESHEET, m_sStylesheet);
	DDX_Check(pDX, IDC_USESTYLESHEET, m_bUseStylesheet);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTDLPrintDialog, CDialog)
	//{{AFX_MSG_MAP(CTDLPrintDialog)
	ON_BN_CLICKED(IDC_ALLTASKS, OnChangetasksOption)
	ON_BN_CLICKED(IDC_INCLUDEDONE, OnInclude)
	ON_BN_CLICKED(IDC_SELTASK, OnChangetasksOption)
	ON_BN_CLICKED(IDC_INCLUDENOTDONE, OnInclude)
	ON_BN_CLICKED(IDC_USESTYLESHEET, OnUsestylesheet)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTDLPrintDialog message handlers

void CTDLPrintDialog::OnOK() 
{
	CDialog::OnOK();
	
	// save settings
	AfxGetApp()->WriteProfileInt("Print", "CompletedTasks", m_bCompletedTasks);
	AfxGetApp()->WriteProfileInt("Print", "IncompleteTasks", m_bIncompleteTasks);
	AfxGetApp()->WriteProfileString("Print", "Stylesheet", m_sStylesheet);

	// we store whether this is the same as the default print stylesheet
	// so we can update as it does
	CString sDefStylesheet = AfxGetApp()->GetProfileString("Preferences", "PrintStylesheet");
	AfxGetApp()->WriteProfileInt("Print", "DefaultStylesheet", (m_sStylesheet.CompareNoCase(sDefStylesheet) == 0));
}

void CTDLPrintDialog::OnChangetasksOption() 
{
	UpdateData();

	GetDlgItem(IDC_INCLUDEDONE)->EnableWindow(!m_bSelectedTasks);
	GetDlgItem(IDC_INCLUDENOTDONE)->EnableWindow(!m_bSelectedTasks);
}

void CTDLPrintDialog::OnInclude() 
{
	UpdateData();
	EnableOK();
}

void CTDLPrintDialog::EnableOK()
{
	GetDlgItem(IDOK)->EnableWindow(m_bCompletedTasks || m_bIncompleteTasks);
}


BOOL CTDLPrintDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	GetDlgItem(IDC_INCLUDEDONE)->EnableWindow(!m_bSelectedTasks);
	GetDlgItem(IDC_INCLUDENOTDONE)->EnableWindow(!m_bSelectedTasks);
	GetDlgItem(IDC_PRINTSTYLESHEET)->EnableWindow(m_bUseStylesheet);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTDLPrintDialog::OnUsestylesheet() 
{
	UpdateData();

	GetDlgItem(IDC_PRINTSTYLESHEET)->EnableWindow(m_bUseStylesheet);
}
