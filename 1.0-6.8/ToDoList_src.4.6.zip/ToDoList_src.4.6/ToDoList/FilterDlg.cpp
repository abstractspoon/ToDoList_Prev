// FilterDlg.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "FilterDlg.h"
#include "tdstringres.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFilterDlg dialog


CFilterDlg::CFilterDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFilterDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFilterDlg)
	m_nFilterWhat = -1;
	m_nPriorityFilter = -1;
	//}}AFX_DATA_INIT
}


void CFilterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFilterDlg)
	DDX_Control(pDX, IDC_CATEGORYFILTERCOMBO, m_cbCategoryFilter);
	DDX_Control(pDX, IDC_PRIORITYFILTERCOMBO, m_cbPriorityFilter);
	DDX_Control(pDX, IDC_ALLOCTOFILTERCOMBO, m_cbAllocToFilter);
	DDX_Control(pDX, IDC_ALLOCBYFILTERCOMBO, m_cbAllocByFilter);
	DDX_Control(pDX, IDC_FILTERCOMBO, m_cbTaskFilter);
	DDX_CBIndex(pDX, IDC_FILTERCOMBO, m_nFilterWhat);
	DDX_CBIndex(pDX, IDC_PRIORITYFILTERCOMBO, m_nPriorityFilter);
	DDX_CBString(pDX, IDC_CATEGORYFILTERCOMBO, m_sCategoryFilter);
	DDX_CBString(pDX, IDC_ALLOCTOFILTERCOMBO, m_sAllocToFilter);
	DDX_CBString(pDX, IDC_ALLOCBYFILTERCOMBO, m_sAllocByFilter);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFilterDlg, CDialog)
	//{{AFX_MSG_MAP(CFilterDlg)
	ON_BN_CLICKED(IDC_CLEARFILTER, OnClearfilter)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFilterDlg message handlers

int CFilterDlg::DoModal(const FTDCFILTER& filter, const CStringArray& aAllocTo,
						const CStringArray& aAllocBy, const CStringArray& aCategory, 
						const CDWordArray& aPriorityColors)
{
	m_filter = filter;
	m_aAllocTo.Copy(aAllocTo);
	m_aAllocBy.Copy(aAllocBy);
	m_aCategory.Copy(aCategory);
	m_aPriorityColors.Copy(aPriorityColors);

	return CDialog::DoModal();
}

void CFilterDlg::GetFilter(FTDCFILTER& filter)
{
	filter.nFilter = (FILTER_TYPE)m_nFilterWhat;
	filter.sAllocTo = m_sAllocToFilter;
	filter.sAllocBy = m_sAllocByFilter;
	filter.sCategory = m_sCategoryFilter;
	filter.nPriority = m_nPriorityFilter - 1; // because we added a blank
}

BOOL CFilterDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// main filter
	m_nFilterWhat = (int)m_filter.nFilter;
	
	// alloc filters
	SetComboBoxItems(m_cbAllocToFilter, m_aAllocTo);
	m_sAllocToFilter = m_filter.sAllocTo;

	SetComboBoxItems(m_cbAllocByFilter, m_aAllocBy);
	m_sAllocByFilter = m_filter.sAllocBy;

	// category filter
	SetComboBoxItems(m_cbCategoryFilter, m_aCategory);
	m_sCategoryFilter = m_filter.sCategory;

	// priority
	BOOL bHasColors = m_aPriorityColors.GetSize();

	for (int nPriority = 0; nPriority < TDC_NUMPRIORITIES; nPriority++)
	{
		COLORREF color = bHasColors ? (COLORREF)m_aPriorityColors[nPriority] : -1;
		m_cbPriorityFilter.AddColor(color, TDC_PRIORITY[nPriority]);
	}

	// add a blank item
	m_cbPriorityFilter.InsertColor(0, (COLORREF)-1, "");

	// set selection
	m_nPriorityFilter = m_filter.nPriority + 1; // because added a blank item

	// update UI
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CFilterDlg::OnClearfilter() 
{
	m_nFilterWhat = (int)FT_ALL;
	m_sCategoryFilter.Empty();
	m_sAllocToFilter.Empty();
	m_sAllocByFilter.Empty();
	m_nPriorityFilter = 0;
	
	UpdateData(FALSE);
	
	// the allocto and category don't get set properly if they
	// are empty but were not previously so we do it manually
	m_cbAllocToFilter.SetCurSel(0);
	m_cbAllocByFilter.SetCurSel(0);
	m_cbCategoryFilter.SetCurSel(0);
}
