#if !defined(AFX_TDLPRINTDIALOG_H__1A62F94F_687F_421C_97D2_300BAC4A3E7C__INCLUDED_)
#define AFX_TDLPRINTDIALOG_H__1A62F94F_687F_421C_97D2_300BAC4A3E7C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TDLPrintDialog.h : header file
//

#include "..\shared\fileedit.h"

/////////////////////////////////////////////////////////////////////////////
// CTDLPrintDialog dialog

class CTDLPrintDialog : public CDialog
{
// Construction
public:
	CTDLPrintDialog(CWnd* pParent = NULL);   // standard constructor

	BOOL GetWantSelectedTasks() const { return m_bSelectedTasks; }
	BOOL GetWantCompletedTasks() const { return m_bSelectedTasks || m_bCompletedTasks; }
	BOOL GetWantInCompleteTasks() const { return m_bSelectedTasks || m_bIncompleteTasks; }
	CString GetStylesheet() const { return m_bUseStylesheet ? m_sStylesheet : ""; }

// Dialog Data
	//{{AFX_DATA(CTDLPrintDialog)
	enum { IDD = IDD_PRINT_DIALOG };
	CFileEdit	m_eStylesheet;
	BOOL	m_bCompletedTasks;
	BOOL	m_bIncompleteTasks;
	int		m_bSelectedTasks;
	CString	m_sStylesheet;
	BOOL	m_bUseStylesheet;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTDLPrintDialog)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTDLPrintDialog)
	afx_msg void OnChangetasksOption();
	afx_msg void OnInclude();
	virtual BOOL OnInitDialog();
	afx_msg void OnUsestylesheet();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void EnableOK();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TDLPRINTDIALOG_H__1A62F94F_687F_421C_97D2_300BAC4A3E7C__INCLUDED_)
