// TimeEdit.cpp: implementation of the CTimeEdit class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TimeEdit.h"
#include "stringres.h"

#include <math.h>
#include <locale.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const int BTNWIDTHDLU = (6 * 4); // 'M  >'
const int ID_BTN = 1;

struct TIMEUNIT
{
	int nUnits;
	LPCTSTR szLabel;
	LPCTSTR szAbbrLabel;
	UINT nMenuID;
};

enum
{
	ID_HOURS = 0x8000,
	ID_DAYS,
	ID_WEEKS,
	ID_MONTHS,
	ID_YEARS,
};

const TIMEUNIT TIMEUNITS[] = 
{
	{ TEU_HOURS,	TIME_HOURS,	TIME_HOUR_ABBREV,	ID_HOURS },
	{ TEU_DAYS,		TIME_DAYS,	TIME_DAY_ABBREV,	ID_DAYS },
	{ TEU_WEEKS,	TIME_WEEKS,	TIME_WEEK_ABBREV,	ID_WEEKS },
	{ TEU_MONTHS,	TIME_MONTHS,TIME_MONTH_ABBREV,	ID_MONTHS },
	{ TEU_YEARS,	TIME_YEARS,	TIME_YEAR_ABBREV,	ID_YEARS },
};

const int NUM_UNITS = sizeof(TIMEUNITS) / sizeof (TIMEUNIT);

const TIMEUNIT& GetTimeUnit(int nUnits)
{
	int nItem = NUM_UNITS;

	while (nItem--)
	{
		if (TIMEUNITS[nItem].nUnits == nUnits)
			return TIMEUNITS[nItem];
	}

	return TIMEUNITS[0]; // hours
}

const double MINS2HOURS = 60;
double CTimeEdit::HOURS2DAYS = 8; // user definable
double CTimeEdit::DAYS2WEEKS = 5; // user definable
const double WEEKS2MONTHS = 4.348;
const double MONTHS2YEARS = 12;

CTimeEdit::CTimeEdit(int nUnits, int nDecPlaces) : m_nUnits(nUnits), m_nDecPlaces(nDecPlaces)
{
	SetMask(".0123456789", ME_LOCALIZEDECIMAL);

	CString sLabel;
	sLabel.Format("%s  >", GetTimeUnit(nUnits).szAbbrLabel);

	AddButton(ID_BTN, sLabel, TIME_UNITS);
}

CTimeEdit::~CTimeEdit()
{

}

BEGIN_MESSAGE_MAP(CTimeEdit, CEnEdit)
	//{{AFX_MSG_MAP(CTimeEdit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CTimeEdit::PreSubclassWindow() 
{
	CEnEdit::PreSubclassWindow();

	SetButtonWidthDLU(1, BTNWIDTHDLU);
}

double CTimeEdit::GetTime() const
{
	CString sTime;
	GetWindowText(sTime);
	return atof(sTime);
}

void CTimeEdit::SetTime(double dTime)
{
	CString sTime;
	sTime.Format("%.*f", m_nDecPlaces, dTime);

	SetWindowText(sTime);
}

void CTimeEdit::SetTime(double dTime, int nUnits)
{
	if (dTime != GetTime())
	{
		SetTime(dTime);
		SetUnits(nUnits);
	}
}

void CTimeEdit::SetUnits(int nUnits)
{
	if (nUnits != m_nUnits)
	{
		m_nUnits = nUnits;

		CString sLabel;
		sLabel.Format("%s  >", GetTimeUnit(nUnits).szAbbrLabel);
		SetButtonCaption(1, sLabel);
	}
}

void CTimeEdit::SetDecimalPlaces(int nDecPlaces)
{
	if (m_nDecPlaces != nDecPlaces)
	{
		m_nDecPlaces = nDecPlaces;

		SetTime(GetTime());
	}
}

void CTimeEdit::OnBtnClick(UINT nID)
{
	if (nID != ID_BTN)
		return;

	CMenu menu;
	
	if (menu.CreatePopupMenu())
	{			
		for (int nUnit = 0; nUnit < NUM_UNITS; nUnit++)
		{
			const TIMEUNIT& tu = TIMEUNITS[nUnit];

			menu.AppendMenu(MF_STRING, tu.nMenuID, tu.szLabel);

			if (tu.nUnits == m_nUnits)
				menu.CheckMenuItem(nUnit, MF_CHECKED | MF_BYPOSITION);
		}
		CRect rButton = GetButtonRect(nID);
		
		TPMPARAMS tpmp;
		tpmp.cbSize = sizeof(TPMPARAMS);
		tpmp.rcExclude = rButton;
		
		UINT nID = ::TrackPopupMenuEx(menu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RETURNCMD, 
									rButton.right, rButton.top, *this, &tpmp);

		// handle result
		for (nUnit = 0; nUnit < NUM_UNITS; nUnit++)
		{
			const TIMEUNIT& tu = TIMEUNITS[nUnit];

			if (tu.nMenuID == nID)
			{
				if (m_nUnits != tu.nUnits)
				{
					int nPrevUnits = m_nUnits;
					SetUnits(tu.nUnits);
					GetParent()->SendMessage(WM_TEN_UNITSCHANGE, (WPARAM)GetDlgCtrlID(), nPrevUnits);
				}
				break;
			}
		}
	}
}

double CTimeEdit::GetTime(int nUnits) const
{
	return GetTime(GetTime(), m_nUnits, nUnits);
}

double CTimeEdit::GetTime(double dTime, int nFromUnits, int nToUnits)
{
	if (nFromUnits == nToUnits)
		return dTime;

	else if (Compare(nFromUnits, nToUnits) > 0)
	{
		while (Compare(nFromUnits, nToUnits) > 0)
		{
			switch (nFromUnits)
			{
			case TEU_DAYS:
				dTime *= HOURS2DAYS;
				nFromUnits = TEU_HOURS;
				break;
				
			case TEU_WEEKS:
				dTime *= DAYS2WEEKS;
				nFromUnits = TEU_DAYS;
				break;
				
			case TEU_MONTHS:
				dTime *= WEEKS2MONTHS;
				nFromUnits = TEU_WEEKS;
				break;
				
			case TEU_YEARS:
				dTime *= MONTHS2YEARS;
				nFromUnits = TEU_MONTHS;
				break;
			}
		}
	}
	else // nFromUnits < nToUnits
	{
		while (Compare(nFromUnits, nToUnits) < 0)
		{
			switch (nFromUnits)
			{
			case TEU_HOURS:
				dTime /= HOURS2DAYS;
				nFromUnits = TEU_DAYS;
				break;

			case TEU_DAYS:
				dTime /= DAYS2WEEKS;
				nFromUnits = TEU_WEEKS;
				break;
				
			case TEU_WEEKS:
				dTime /= WEEKS2MONTHS;
				nFromUnits = TEU_MONTHS;
				break;
				
			case TEU_MONTHS:
				dTime /= MONTHS2YEARS;
				nFromUnits = TEU_YEARS;
				break;
			}
		}
	}

	return dTime;
}

CString CTimeEdit::FormatTime(BOOL bUnits) const
{
	if (bUnits)
		return FormatTime(GetTime(), m_nUnits, m_nDecPlaces);
	else
		return FormatTime(GetTime(), m_nDecPlaces);
}

// static
CString CTimeEdit::FormatTime(double dTime, int nDecPlaces)
{
	// handle locale specific decimal separator
	setlocale(LC_NUMERIC, "");

	CString sTime;
	sTime.Format("%.*f", nDecPlaces, dTime);

	// restore decimal separator to '.'
	setlocale(LC_NUMERIC, "English");

	return sTime;
}

// static
CString CTimeEdit::FormatTime(double dTime, int nUnits, int nDecPlaces)
{
	// handle locale specific decimal separator
	setlocale(LC_NUMERIC, "");

	CString sTime;
	sTime.Format("%.*f %s", nDecPlaces, dTime, GetTimeUnit(nUnits).szAbbrLabel);

	// restore decimal separator to '.'
	setlocale(LC_NUMERIC, "English");

	return sTime;
}

CString CTimeEdit::FormatTimeHMS() const
{
	return FormatTimeHMS(GetTime(), GetUnits());
}

CString CTimeEdit::FormatTimeHMS(double dTime, int nUnitsFrom)
{
	// convert the time to minutes 
	double dMins = GetTime(dTime, nUnitsFrom, TEU_HOURS) * MINS2HOURS;

	double dHours = dMins / MINS2HOURS;
	double dDays = dHours / HOURS2DAYS;
	double dWeeks = dDays / DAYS2WEEKS;
	double dMonths = dWeeks / WEEKS2MONTHS;
	double dYears = dMonths / MONTHS2YEARS;

	CString sTime;

	if (dYears >= 1.0)
	{
		while (dMonths >= MONTHS2YEARS)
			dMonths -= MONTHS2YEARS;

		sTime.Format("%d%s%d%s", (int)dYears, GetTimeUnit(TEU_YEARS).szAbbrLabel, 
								 (int)dMonths, GetTimeUnit(TEU_MONTHS).szAbbrLabel);
	}
	else if (dMonths >= 1.0)
	{
		while (dWeeks >= WEEKS2MONTHS)
			dWeeks -= WEEKS2MONTHS;

		sTime.Format("%d%s%d%s", (int)dMonths, GetTimeUnit(TEU_MONTHS).szAbbrLabel, 
								 (int)dWeeks, GetTimeUnit(TEU_WEEKS).szAbbrLabel);
	}
	else if (dWeeks >= 1.0)
	{
		while (dDays >= DAYS2WEEKS)
			dDays -= DAYS2WEEKS;

		sTime.Format("%d%s%d%s", (int)dWeeks, GetTimeUnit(TEU_WEEKS).szAbbrLabel, 
								 (int)dDays, GetTimeUnit(TEU_DAYS).szAbbrLabel);
	}
	else if (dDays >= 1.0)
	{
		while (dHours >= HOURS2DAYS)
			dHours -= HOURS2DAYS;

		sTime.Format("%d%s%d%s", (int)dDays, GetTimeUnit(TEU_DAYS).szAbbrLabel, 
								 (int)dHours, GetTimeUnit(TEU_HOURS).szAbbrLabel);
	}
	else if (dHours >= 1.0)
	{
		while (dMins >= MINS2HOURS)
			dMins -= MINS2HOURS;

		sTime.Format("%d%s%d%s", (int)dHours, GetTimeUnit(TEU_HOURS).szAbbrLabel, 
								(int)dMins, TIME_MIN_ABBREV);
	}
	else if (dMins > 1.0)
	{
		sTime.Format("%dm", (int)dMins);
	}

	sTime.MakeLower();

	return sTime;
}

int CTimeEdit::Compare(int nFromUnits, int nToUnits)
{
	if (nFromUnits == nToUnits)
		return 0;

	switch (nFromUnits)
	{
	case TEU_HOURS:
		return -1; // less than everything else
	
	case TEU_DAYS:
		return (nToUnits == TEU_HOURS) ? 1 : -1;
	
	case TEU_WEEKS:
		return (nToUnits == TEU_HOURS || nToUnits == TEU_DAYS) ? 1 : -1;
	
	case TEU_MONTHS:
		return (nToUnits == TEU_YEARS) ? -1 : 1;
	
	case TEU_YEARS:
		return 1; // greater than everything else
	}

	// else
	return 0;
}

void CTimeEdit::OnSetReadOnly(BOOL bReadOnly)
{
	EnableButton(1, !bReadOnly && IsWindowEnabled());
}

BOOL CTimeEdit::SetHoursInOneDay(double dHours)
{
	if (dHours <= 0 || dHours > 24)
		return FALSE;

	HOURS2DAYS = dHours;
	return TRUE;
}

BOOL CTimeEdit::SetDaysInOneWeek(double dDays)
{
	if (dDays <= 0 || dDays > 7)
		return FALSE;

	DAYS2WEEKS = dDays;
	return TRUE;
}
