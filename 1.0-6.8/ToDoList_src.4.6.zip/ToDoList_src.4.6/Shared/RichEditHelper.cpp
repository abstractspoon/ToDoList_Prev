// RichEditHelper.cpp: implementation of the CRichEditHelper class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "RichEditHelper.h"
#include "wclassdefines.h"
#include "..\3rdParty\TOM.h"

#include <richole.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define DEFINE_GUIDXXX(name, l, w1, w2, b1, b2, b3, b4, b5, b6, b7, b8) \
        EXTERN_C const GUID CDECL name \
                = { l, w1, w2, { b1, b2,  b3,  b4,  b5,  b6,  b7,  b8 } }

DEFINE_GUIDXXX(IID_ITextDocument,0x8CC497C0,0xA1DF,0x11CE,0x80,0x98,
                0x00,0xAA,0x00,0x47,0xBE,0x5D);

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CReBase::CReBase(HWND hwndRichEdit) : m_hwndRichedit(hwndRichEdit)
{
}

CReBase::~CReBase()
{
	m_hwndRichedit = NULL;
}

CRePauseUndo::CRePauseUndo(HWND hwndRichEdit) : CReBase(hwndRichEdit)
{
	if (m_hwndRichedit)
	{
		ITextDocument *pDoc;
		IUnknown *pUnk = NULL;
		
		SendMessage(m_hwndRichedit, EM_GETOLEINTERFACE, 0, (LPARAM)&pUnk);

		if (pUnk)
		{
			if (pUnk->QueryInterface(IID_ITextDocument, (void**)&pDoc) == NOERROR)
		{
			pDoc->Undo(tomSuspend, NULL);

			pDoc->Release();
			}
			pUnk->Release();
		}
	}
}

CRePauseUndo::~CRePauseUndo()
{
	if (m_hwndRichedit)
	{
		ITextDocument *pDoc;
		IUnknown *pUnk = NULL;
		
		SendMessage(m_hwndRichedit, EM_GETOLEINTERFACE, 0, (LPARAM)&pUnk);

		if (pUnk)
		{
			if (pUnk->QueryInterface(IID_ITextDocument, (void**)&pDoc) == NOERROR)
		{
			pDoc->Undo(tomResume, NULL);	

			pDoc->Release();
			}
			pUnk->Release();
		}
	}
}

BOOL CRichEditHelper::CreateRichEdit20(CWnd& wnd, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID)
{
	InitRichEdit();
	
	return wnd.Create(WC_RICHEDIT20, "", dwStyle, rect, pParentWnd, nID);
}


BOOL CRichEditHelper::InitRichEdit()
{
	static HINSTANCE hRichEdit20 = NULL;
	
	if (!AfxInitRichEdit())
		return FALSE;
	
	if (!hRichEdit20)
		hRichEdit20 = LoadLibrary("riched20.dll");
	
	return (hRichEdit20 != NULL);
}
