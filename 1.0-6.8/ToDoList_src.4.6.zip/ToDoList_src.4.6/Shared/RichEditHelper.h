// RichEditHelper.h: interface for the CRichEditHelper class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RICHEDITHELPER_H__C498C86D_613F_42AD_9C93_6C773E6368E8__INCLUDED_)
#define AFX_RICHEDITHELPER_H__C498C86D_613F_42AD_9C93_6C773E6368E8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

struct ITextDocument;

class CReBase
{
public:
	CReBase(HWND hwndRichEdit);
	virtual ~CReBase();

protected:
	HWND m_hwndRichedit;
};

class CRePauseUndo : public CReBase
{
public:
	CRePauseUndo(HWND hwndRichEdit);
	virtual ~CRePauseUndo();
};

class CRichEditHelper
{
public:
	static BOOL CreateRichEdit20(CWnd& wnd, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID);
	static BOOL InitRichEdit();

protected:
};

#endif // !defined(AFX_RICHEDITHELPER_H__C498C86D_613F_42AD_9C93_6C773E6368E8__INCLUDED_)
