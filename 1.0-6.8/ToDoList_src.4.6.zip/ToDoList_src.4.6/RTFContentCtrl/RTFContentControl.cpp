// RTFContentControl.cpp : implementation file
//

#include "stdafx.h"
#include "RTFContentCtrl.h"
#include "RTFContentControl.h"

#include "..\shared\itasklist.h"
#include "..\shared\filedialogex.h"
#include "..\shared\autoflag.h"
#include "..\todolist\tdcmsg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRTFContentControl

CRTFContentControl::CRTFContentControl() : m_bAllowNotify(TRUE)
{
	// add custom protocol to comments field for linking to task IDs
	GetRichEditCtrl().AddProtocol(TDL_PROTOCOL, TRUE);
}

CRTFContentControl::~CRTFContentControl()
{
}


BEGIN_MESSAGE_MAP(CRTFContentControl, CRulerRichEditCtrl)
	//{{AFX_MSG_MAP(CRTFContentControl)
	ON_WM_CONTEXTMENU()
	ON_WM_CREATE()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_EN_CHANGE(RTF_CONTROL, OnChangeText)
	ON_MESSAGE(WM_SETFONT, OnSetFont)
	ON_WM_STYLECHANGING()
	ON_REGISTERED_MESSAGE(WM_UREN_CUSTOMURL, OnCustomUrl)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRTFContentControl message handlers

void CRTFContentControl::OnChangeText() 
{
	if (m_bAllowNotify)
		GetParent()->SendMessage(WM_TDCN_COMMENTSCHANGE);
}

LRESULT CRTFContentControl::OnSetFont(WPARAM wp, LPARAM lp)
{
	// richedit2.0 sends a EN_CHANGE notification if it contains
	// text when it receives a font change.
	// to us though this is a bogus change so we prevent a notification
	// being sent
	CAutoFlag af(m_bAllowNotify, FALSE);

	return CRulerRichEditCtrl::OnSetFont(wp, lp);
}

// ICustomControl implementation
int CRTFContentControl::GetContent(unsigned char* pContent) const
{
	return GetContent(this, pContent);
}

// hack to get round GetRTF not being const
int CRTFContentControl::GetContent(const CRTFContentControl* pCtrl, unsigned char* pContent)
{
   DWORD dwTick = GetTickCount();
   int nLen = 0;

   if (pContent)
   {
	   CString sContent;

	   // cast away constness
	   sContent = ((CRTFContentControl*)pCtrl)->GetRTF();
       nLen = sContent.GetLength() + 1;

	   if (pContent)
		   CopyMemory(pContent, (LPCTSTR)sContent, nLen - 1);
   }
   else
      nLen = ((CRTFContentControl*)pCtrl)->GetRTFLength();
 
   TRACE("CRTFContentControl::GetContent(%d ms)\n", GetTickCount() - dwTick);

   return nLen;
}

bool CRTFContentControl::SetContent(unsigned char* pContent, int nLength)
{
	LPCTSTR RTFTAG = "{\\rtf";
	const int LENTAG = strlen(RTFTAG);

	// content must begin with rtf tag or be empty
	if (nLength && (nLength < LENTAG || strncmp((const char*)pContent, RTFTAG, LENTAG)))
		return false;

	CAutoFlag af(m_bAllowNotify, FALSE);
	CString sContent((LPCSTR)pContent, nLength);

	SetRTF(sContent);
	GetRichEditCtrl().ParseAndFormatText(TRUE);
	
	return true; 
}

int CRTFContentControl::GetTextContent(char* szContent, int nLength) const
{
	if (!szContent)
		return GetWindowTextLength();

	// else
	if (nLength == -1)
		nLength = lstrlen(szContent);
	
	GetWindowText(szContent, nLength);
	return nLength;
}

bool CRTFContentControl::SetTextContent(const char* szContent)
{
	CAutoFlag af(m_bAllowNotify, TRUE);
	SendMessage(WM_SETTEXT, 0, (LPARAM)szContent);
	return true; 
}

HWND CRTFContentControl::GetHwnd() const
{
	return GetSafeHwnd();
}

bool CRTFContentControl::HasTypeID() const
{
	return true;
}

bool CRTFContentControl::GetTypeID(GUID& id) const
{
	id = RTF_TYPEID;
	return true;
}

void CRTFContentControl::SetReadOnly(bool bReadOnly)
{
	CRulerRichEditCtrl::SetReadOnly((BOOL)bReadOnly);
}

void CRTFContentControl::Release()
{
	delete this;
}

void CRTFContentControl::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	if (pWnd == &GetRichEditCtrl())
	{
		// prepare a simple edit menu
		CMenu menu;

		if (menu.LoadMenu(IDR_POPUP))
		{
			CMenu* pPopup = menu.GetSubMenu(0);

			if (pPopup)
			{
				CUrlRichEditCtrl& re = GetRichEditCtrl();

				CHARRANGE cr;
				re.GetSel(cr);

				BOOL bHasSel = (cr.cpMax - cr.cpMin);
				BOOL bCanEdit = re.IsWindowEnabled() && !(re.GetStyle() & ES_READONLY);

				pPopup->EnableMenuItem(ID_EDIT_CUT, MF_BYCOMMAND | (bCanEdit && bHasSel ? MF_ENABLED : MF_GRAYED));
				pPopup->EnableMenuItem(ID_EDIT_COPY, MF_BYCOMMAND | (bHasSel ? MF_ENABLED : MF_GRAYED));
				pPopup->EnableMenuItem(ID_EDIT_PASTE, MF_BYCOMMAND | (bCanEdit && CanPaste() ? MF_ENABLED : MF_GRAYED));
				pPopup->EnableMenuItem(ID_EDIT_DELETE, MF_BYCOMMAND | (bCanEdit && bHasSel ? MF_ENABLED : MF_GRAYED));

				ITaskList* pClipboard = (ITaskList*)GetParent()->SendMessage(WM_TDCM_GETCLIPBOARD, 0, TRUE);
				BOOL bClipboard = (pClipboard && pClipboard->GetFirstTask());

				pPopup->EnableMenuItem(ID_EDIT_PASTEASREF, MF_BYCOMMAND | (bCanEdit && bClipboard ? MF_ENABLED : MF_GRAYED));
				
				int nUrl = re.GetContextUrl();
				pPopup->EnableMenuItem(ID_EDIT_OPENURL, MF_BYCOMMAND | (nUrl != -1 ? MF_ENABLED : MF_GRAYED));

				if (nUrl != -1)
					pPopup->ModifyMenu(ID_EDIT_OPENURL, MF_BYCOMMAND, ID_EDIT_OPENURL, re.GetUrl(nUrl, TRUE));

				pPopup->EnableMenuItem(ID_EDIT_FILEBROWSE, MF_BYCOMMAND | (bCanEdit ? MF_ENABLED : MF_GRAYED));
				pPopup->EnableMenuItem(ID_EDIT_INSERTDATESTAMP, MF_BYCOMMAND | (bCanEdit ? MF_ENABLED : MF_GRAYED));

				pPopup->CheckMenuItem(ID_EDIT_SHOWTOOLBAR, MF_BYCOMMAND | (IsToolbarVisible() ? MF_CHECKED  : MF_UNCHECKED));
				pPopup->CheckMenuItem(ID_EDIT_SHOWRULER, MF_BYCOMMAND | (IsRulerVisible() ? MF_CHECKED  : MF_UNCHECKED));

				BOOL bWordWrap = HasWordWrap();
				pPopup->CheckMenuItem(ID_EDIT_WORDWRAP, MF_BYCOMMAND | (bWordWrap ? MF_CHECKED  : MF_UNCHECKED));

				// check pos
				if (point.x == -1 && point.y == -1)
				{
					point = GetCaretPos();
					::ClientToScreen(m_rtf, &point);
				}

				UINT nCmdID = ::TrackPopupMenu(*pPopup, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_LEFTBUTTON, 
												point.x, point.y, 0, *this, NULL);

				switch (nCmdID)
				{
				case ID_EDIT_CUT:
					re.Cut();
					break;

				case ID_EDIT_COPY:
					re.Copy();
					break;

				case ID_EDIT_PASTE:
					re.Paste();
					break;

				case ID_EDIT_PASTEASREF:
					{
						if (bClipboard)
						{
							// build single string containing each top level item as a different ref
							CString sRefs, sRef;
							HTASKITEM hClip = pClipboard->GetFirstTask();
							
							while (hClip)
							{
								sRef.Format(" %s%d", TDL_PROTOCOL, pClipboard->GetTaskID(hClip));
								sRefs += sRef;
								
								hClip = pClipboard->GetNextTask(hClip);
							}

							sRefs += ' ';
							re.ReplaceSel(sRefs, TRUE);
						}
					}
					break;
		
				case ID_EDIT_DELETE:
					re.ReplaceSel("");
					break;

				case ID_EDIT_SELECT_ALL:
					re.SetSel(0, -1);
					break;
		
				case ID_EDIT_OPENURL:
					if (nUrl != -1)
						re.GoToUrl(nUrl);
					break;
					
				case ID_EDIT_FILEBROWSE:
					{
						CString sFile;
						
						if (nUrl != -1)
						{
							sFile = re.GetUrl(nUrl, TRUE);

							if (GetFileAttributes(sFile) == 0xffffffff)
								sFile.Empty();
						}
									
						CFileDialogEx dialog(TRUE, NULL, sFile);
						dialog.m_ofn.lpstrTitle = "Select File";
						
						if (dialog.DoModal() == IDOK)
							re.PathReplaceSel(dialog.GetPathName(), TRUE);
					}
					break;
		
				case ID_EDIT_INSERTDATESTAMP:
					{
						COleDateTime date = COleDateTime::GetCurrentTime();
						re.ReplaceSel(date.Format(), TRUE);
					}
					break;

				case ID_EDIT_SHOWTOOLBAR:
					ShowToolbar(!IsToolbarVisible());
					break;

				case ID_EDIT_SHOWRULER:
					ShowRuler(!IsRulerVisible());
					break;

				case ID_EDIT_WORDWRAP:
					SetWordWrap(!bWordWrap);
					break;
				}
			}
		}
	}
}

BOOL CRTFContentControl::CanPaste()
{
	static CLIPFORMAT formats[] = 
	{ 
		(CLIPFORMAT)::RegisterClipboardFormat(CF_RTF),
		(CLIPFORMAT)::RegisterClipboardFormat(CF_RETEXTOBJ), 
		(CLIPFORMAT)::RegisterClipboardFormat(_T("Embedded Object")),
		(CLIPFORMAT)::RegisterClipboardFormat(_T("Rich Text Format")),
		CF_BITMAP,
		CF_TEXT,
		CF_DIB,
		CF_UNICODETEXT
	};
	const long formats_count = sizeof(formats) / sizeof(CLIPFORMAT);
	
	CUrlRichEditCtrl& re = GetRichEditCtrl();
	
	BOOL bCanPaste = FALSE;
	
	for( long i=0;  i<formats_count;  ++i )
		bCanPaste |= re.CanPaste( formats[i] );
	
	return bCanPaste;
}

int CRTFContentControl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CRulerRichEditCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// restore toolbar and ruler state
	BOOL bShowToolbar = AfxGetApp()->GetProfileInt("Settings", "ShowToolbar", TRUE);
	BOOL bShowRuler = AfxGetApp()->GetProfileInt("Settings", "ShowRuler", TRUE);
	BOOL bWordWrap = AfxGetApp()->GetProfileInt("Settings", "WordWrap", TRUE);
	
	ShowToolbar(bShowToolbar);
	ShowRuler(bShowRuler);
	SetWordWrap(bWordWrap);

	GetRichEditCtrl().SetEventMask(GetRichEditCtrl().GetEventMask() | ENM_CHANGE);
	
	// set max edit length
	GetRichEditCtrl().LimitText(1024 * 1024 * 1024); // one gigabyte
	
	m_tbHelper.Initialize(&m_toolbar, this);
	
	return 0;
}

bool CRTFContentControl::ProcessMessage(MSG* /*pMsg*/) 
{
	// we do our processing in PreTranslateMessage
	return false;
}

void CRTFContentControl::OnDestroy() 
{
	CRulerRichEditCtrl::OnDestroy();
	
	// save toolbar and ruler state
	AfxGetApp()->WriteProfileInt("Settings", "ShowToolbar", IsToolbarVisible());
	AfxGetApp()->WriteProfileInt("Settings", "ShowRuler", IsRulerVisible());
	AfxGetApp()->WriteProfileInt("Settings", "WordWrap", HasWordWrap());
}

void CRTFContentControl::OnStyleChanging(int nStyleType, LPSTYLESTRUCT lpStyleStruct)
{
	if (nStyleType == GWL_EXSTYLE)
		lpStyleStruct->styleNew &= ~WS_EX_CLIENTEDGE;

	CRulerRichEditCtrl::OnStyleChanging(nStyleType, lpStyleStruct);
}

LRESULT CRTFContentControl::OnCustomUrl(WPARAM wp, LPARAM lp)
{
	UNREFERENCED_PARAMETER(wp);
	ASSERT (wp == RTF_CONTROL);

	CString sUrl((LPCTSTR)lp);

	if (sUrl.Find(TDL_PROTOCOL) != -1)
	{
		const char* szUrl = (LPCTSTR)sUrl;
		DWORD dwID = atoi(szUrl + sUrl.Find(TDL_PROTOCOL) + lstrlen(TDL_PROTOCOL));

		if (dwID)
			return GetParent()->SendMessage(WM_TDCM_SELECTTASK, 0, dwID);
	}

	return 0;

}

BOOL CRTFContentControl::PreTranslateMessage(MSG* pMsg) 
{
	// handle shortcut keys
	switch (pMsg->message)
	{
	case WM_KEYDOWN:
		{
			BOOL bCtrl = (GetKeyState(VK_CONTROL) & 0x8000);
			BOOL bAlt = (GetKeyState(VK_MENU) & 0x8000);

			if (bCtrl && !bAlt)
			{
				switch (pMsg->wParam)
				{
				case 'c':
				case 'C':
					GetRichEditCtrl().Copy();
					return TRUE;

				case 'v':
				case 'V':
					GetRichEditCtrl().Paste();
					return TRUE;

				case 'x':
				case 'X':
					GetRichEditCtrl().Cut();
					return TRUE;

				case 'a':
				case 'A':
					GetRichEditCtrl().SetSel(0, -1);
					return TRUE;

				case 'b':
				case 'B':
					DoBold();
					return TRUE;

				case 'i':
				case 'I':
					DoItalic();
					return TRUE;

				case 'u':
				case 'U':
					DoUnderline();
					return TRUE;

				case 'l':
				case 'L':
					DoLeftAlign();
					return TRUE;

				case 'e':
				case 'E':
					DoCenterAlign();
					return TRUE;

				case 'r':
				case 'R':
					DoRightAlign();
					return TRUE;
				}
			}
		}
		break;
	}
	
	return CRulerRichEditCtrl::PreTranslateMessage(pMsg);
}
