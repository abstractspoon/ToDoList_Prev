/* ==========================================================================
	File :			RRECToolbar.cpp

	Class :			CRRECToolbar

	Author :		Johan Rosengren, Abstrakt Mekanik AB
					Iain Clarke

	Date :			2004-05-07

	Purpose :		This class encapsulates a toolbar that can be used with 
					"CRulerRichEditCtrl". The class is derived from "CToolBar", 
					and manages a formatting toolbar

	Description :	A "CToolBar"-derived class. Reads a toolbar resource 
					with the ID "TOOLBAR_CONTROL" and adds combo controls for 
					font name and -size, as well as a color picker at the 
					positions "FONT_NAME_POS", "FONT_SIZE_POS" and 
					"FONT_COLOR_POS" respectively.

	Usage :			Created by the rich edit mini-editor.

   ========================================================================*/

#include "stdafx.h"
#include "RRECToolbar.h"
#include "ids.h"

#include <tchar.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern UINT urm_SETCURRENTFONTNAME;
extern UINT urm_SETCURRENTFONTSIZE;
extern UINT urm_SETCURRENTFONTCOLOR;

/////////////////////////////////////////////////////////////////////////////
// CRRECToolbar

CRRECToolbar::CRRECToolbar()
/* ============================================================
	Function :		CRRECToolbar::CRRECToolbar
	Description :	ctor
	Access :		Public
					
	Return :		void
	Parameters :	none

	Usage :			

   ============================================================*/
{
}

CRRECToolbar::~CRRECToolbar()
/* ============================================================
	Function :		CRRECToolbar::~CRRECToolbar
	Description :	dtor
	Access :		Public
					
	Return :		void
	Parameters :	none

	Usage :			

   ============================================================*/
{
}

BOOL CRRECToolbar::Create( CWnd* parent)
/* ============================================================
	Function :		CRRECToolbar::Create
	Description :	Creates the toolbar control
	Access :		Public
					
	Return :		BOOL			-	"TRUE" if success
	Parameters :	CWnd* parent	-	Parent editor
					CRect& rc		-	Rectangle to place 
										toolbar in.

	Usage :			Called from the parent editor

   ============================================================*/
{
	if (CreateEx(parent, TBSTYLE_FLAT | TBSTYLE_WRAPABLE, WS_CHILD | WS_VISIBLE | CBRS_ALIGN_TOP/* | WS_CLIPCHILDREN*/, 
				CRect(0, 0, 0, 0), TOOLBAR_CONTROL) && LoadToolBar(TOOLBAR_CONTROL))
	{
		// very important - turn OFF all the auto positioning and sizing
		// by default have no borders
		UINT nStyle = GetBarStyle();
		nStyle &= ~(CCS_NORESIZE | CCS_NOPARENTALIGN | CBRS_BORDER_ANY);
		nStyle |= (CBRS_SIZE_FIXED | CBRS_TOOLTIPS | CBRS_FLYBY);
		SetBarStyle(nStyle);

		/////////////////////////////////////
		// Map in combo boxes
		//

		// add three separators
		TBBUTTON buttons[] = 
		{
			{ 0, FONT_NAME_POS, 0, TBSTYLE_SEP, 0, NULL },
			{ 0, -1, 0, TBSTYLE_SEP, 0, NULL },
			{ 0, FONT_SIZE_POS, 0, TBSTYLE_SEP, 0, NULL },
			{ 0, -1, 0, TBSTYLE_SEP, 0, NULL },
			{ 0, FONT_COLOR_POS, 0, TBSTYLE_SEP, 0, NULL },
			{ 0, -1, 0, TBSTYLE_SEP, 0, NULL },
		};
		const int BTNCOUNT = sizeof(buttons) / sizeof(TBBUTTON);

		for (int nBtn = 0; nBtn < BTNCOUNT; nBtn++)
			GetToolBarCtrl().InsertButton(nBtn, &buttons[nBtn]);

		CRect rect;

		TBBUTTONINFO tbi;
		tbi.cbSize = sizeof( TBBUTTONINFO );
		tbi.cx = FONT_COMBO_WIDTH;
		tbi.dwMask = TBIF_SIZE;  // By index

		// The font name combo
		GetToolBarCtrl().SetButtonInfo( FONT_NAME_POS, &tbi );
		GetItemRect( FONT_NAME_POS, &rect );
		rect.bottom += COMBO_HEIGHT;

		if (!m_font.Create( WS_CHILD | WS_VSCROLL |	WS_VISIBLE | CBS_AUTOHSCROLL | 
							CBS_DROPDOWNLIST | CBS_SORT | CBS_HASSTRINGS, 
							rect, this, DROPDOWN_FONT ))
			return FALSE;

		m_font.SetFont( CFont::FromHandle( ( HFONT ) ::GetStockObject( DEFAULT_GUI_FONT ) ) );
		m_font.FillCombo();

		// The font size combo
		tbi.cx = COMBO_WIDTH;
		GetToolBarCtrl().SetButtonInfo( FONT_SIZE_POS, &tbi );
		GetItemRect( FONT_SIZE_POS, &rect );
		rect.bottom += COMBO_HEIGHT;
		
		if (!m_size.Create(WS_CHILD | WS_VISIBLE | CBS_AUTOHSCROLL | CBS_DROPDOWNLIST | 
							CBS_HASSTRINGS, rect, this, DROPDOWN_SIZE ))
			return FALSE;

		m_size.SetFont( CFont::FromHandle( ( HFONT ) ::GetStockObject( DEFAULT_GUI_FONT ) ) );
		m_size.FillCombo();
		
		// The color picker
		tbi.cx = COLOR_WIDTH;
		GetToolBarCtrl().SetButtonInfo( FONT_COLOR_POS, &tbi );
		GetItemRect( FONT_COLOR_POS, &rect );
		
		CString color;
		color.LoadString( STRING_COLOR );
		
		if (!m_color.Create(color, WS_VISIBLE |	WS_CHILD, rect, this, BUTTON_COLOR))
			return FALSE;

		CString defaultText;
		CString customText;
		defaultText.LoadString( STRING_DEFAULT );
		customText.LoadString( STRING_CUSTOM );
		
		m_color.SetDefaultText( defaultText );
		m_color.SetCustomText( customText );
		m_color.SetSelectionMode( CP_MODE_TEXT );
		m_color.SetBkColour( RGB( 255, 255, 255 ) );
		
		m_color.SetFont( CFont::FromHandle( ( HFONT ) ::GetStockObject( DEFAULT_GUI_FONT ) ) );

		return TRUE;
	}
	
	return FALSE;
}

BEGIN_MESSAGE_MAP(CRRECToolbar, CToolBar)
	//{{AFX_MSG_MAP(CRRECToolbar)
	ON_CBN_SELCHANGE(DROPDOWN_FONT, OnSelchangeFont)
	ON_CBN_SELCHANGE(DROPDOWN_SIZE, OnSelchangeSize)
	ON_MESSAGE(CPN_SELENDOK, OnColorButton)
	ON_WM_ENABLE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRRECToolbar message handlers

void CRRECToolbar::OnSelchangeFont() 
/* ============================================================
	Function :		CRRECToolbar::OnSelchangeFont
	Description :	Changes the font of the selected text in 
					the editor.
	Access :		Protected
					
	Return :		void
	Parameters :	none

	Usage :			Called from MFC when the selection changes 
					in the font name combo.

   ============================================================*/
{

	CString font;
	int index = m_font.GetCurSel();
	if( index != CB_ERR )
	{
		m_font.GetLBText( index, font );
		GetParent()->SendMessage( urm_SETCURRENTFONTNAME, ( WPARAM ) ( LPCTSTR ) font, 0 );

	}	
}

void CRRECToolbar::OnSelchangeSize() 
/* ============================================================
	Function :		CRRECToolbar::OnSelchangeSize
	Description :	Changes the size of the selected text in 
					the editor.
	Access :		Protected
					
	Return :		void
	Parameters :	none

	Usage :			Called from MFC when the selection changes 
					in the font size combo.

   ============================================================*/
{
	int size = 0;
	int index = m_size.GetCurSel();
	if( index != CB_ERR )
	{

		CString sz;
		m_size.GetLBText( index, sz );
		size = _ttoi( ( LPCTSTR ) sz );

		GetParent()->SendMessage( urm_SETCURRENTFONTSIZE, 0, ( LPARAM ) size );

	}
	
}

LRESULT CRRECToolbar::OnColorButton( WPARAM, LPARAM ) 
/* ============================================================
	Function :		CRRECToolbar::OnColorButton
	Description :	Mapped to the color picker defined 
					"CPN_SELENDOK" message, sent when the color 
					is changed in the picker.
	Access :		Protected
					
	Return :		LRESULT	-	Not used
	Parameters :	WPARAM	-	Not used
					LPARAM	-	Not used

	Usage :			Called from MFC.

   ============================================================*/
{

	COLORREF color = RGB( 0, 0, 0 );
	color = m_color.GetColour();

	GetParent()->SendMessage( urm_SETCURRENTFONTCOLOR, 0, ( LPARAM ) color );
	
	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// CRRECToolbar UI updaters

BOOL CRRECToolbar::SetFontName( const CString& font )
/* ============================================================
	Function :		CRRECToolbar::SetFontName
	Description :	Selects the font name "font" in the font 
					name combo on the toolbar.
	Access :		Public
					
	Return :		void
	Parameters :	none

	Usage :			Call to set the selected font name

   ============================================================*/
{

	if( m_font.m_hWnd )
		return m_font.SelectFontName( font );

	return FALSE;
}

BOOL CRRECToolbar::SetFontSize( int size )
/* ============================================================
	Function :		CRRECToolbar::SetFontSize
	Description :	Selects the font size "size" in the font 
					size combo on the toolbar.
	Access :		Public
					
	Return :		void
	Parameters :	none

	Usage :			Call to set the selected font size

   ============================================================*/
{

	if( m_size.m_hWnd )
		return m_size.SelectSize( size );

	return FALSE;
}

void CRRECToolbar::SetFontColor( COLORREF color )
/* ============================================================
	Function :		CRRECToolbar::SetFontColor
	Description :	Selects the font color "color" in the font 
					color picker on the toolbar.
	Access :		Public
					
	Return :		void
	Parameters :	none

	Usage :			Call to set the color picker color

   ============================================================*/
{

	if( m_color.m_hWnd )
		m_color.SetColour( color );

}

BOOL CRRECToolbar::SetButtonState(int nID, UINT nState)
{
	if (!IsWindowEnabled())
		nState &= ~TBSTATE_ENABLED;
	else
		nState |= TBSTATE_ENABLED;

	return GetToolBarCtrl().SetState(nID, nState);
}



void CRRECToolbar::OnEnable(BOOL bEnable) 
{
	CToolBar::OnEnable(bEnable);
	
	m_color.EnableWindow(bEnable);
	m_font.EnableWindow(bEnable);
	m_size.EnableWindow(bEnable);
}

BOOL CRRECToolbar::IsButtonChecked(int nID) const
{
	return (GetToolBarCtrl().GetState(nID) & TBSTATE_CHECKED);
}

BOOL CRRECToolbar::CheckButton(int nID, BOOL bChecked)
{
	UINT nState = GetToolBarCtrl().GetState(nID);

	if (!bChecked)
		nState &= ~TBSTATE_CHECKED;
	else
		nState |= TBSTATE_CHECKED;

	return SetButtonState(nID, nState);
}

void CRRECToolbar::OnSize(UINT nType, int cx, int cy) 
{
	CToolBar::OnSize(nType, cx, cy);
	
	if (m_font.GetSafeHwnd())
	{
		CRect rDiv;

		// calc length after which we want to start shortening ctrls
		GetItemRect(1, &rDiv); // divider
		const int DEFCTRLSWIDTH = FONT_COMBO_WIDTH + SIZE_COMBO_WIDTH + COLOR_WIDTH +
									(5 * rDiv.Width()) / 2; // 2.5 separators

		// if the toolbar length is less than the default
		// width of the embedded widgets we reduce the 
		// font combo as far as we can.
		TBBUTTONINFO tbi;
		tbi.cbSize = sizeof( TBBUTTONINFO );
		tbi.dwMask = TBIF_SIZE;  // By index
		
		CRect rect;
		GetItemRect(FONT_NAME_POS, &rect);
		
		int nNewWidth = FONT_COMBO_WIDTH - max(0, DEFCTRLSWIDTH - cx);
		nNewWidth = max(nNewWidth, MIN_FONT_COMBO_WIDTH);

		if (nNewWidth != rect.Width())
		{
			rect.right = rect.left + nNewWidth;
			GetDlgItem(DROPDOWN_FONT)->MoveWindow(rect);
			
			// update toolbar item size also
			tbi.cx = (WORD)rect.Width();
			GetToolBarCtrl().SetButtonInfo(FONT_NAME_POS, &tbi);
			
			// move the other two items to suit their toolbar rects
			GetItemRect(FONT_SIZE_POS, &rect);
			GetDlgItem(DROPDOWN_SIZE)->MoveWindow(rect);
			
			GetItemRect(FONT_COLOR_POS, &rect);
			GetDlgItem(BUTTON_COLOR)->MoveWindow(rect);
		}
	}
}
