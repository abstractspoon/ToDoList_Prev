//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by RTFContentCtrl.rc
//
#define TOOLBAR_CONTROL                 10
#define BUTTON_FONT                     20
#define BUTTON_BOLD                     22
#define BUTTON_ITALIC                   23
#define BUTTON_UNDERLINE                24
#define BUTTON_LEFTALIGN                25
#define BUTTON_CENTERALIGN              26
#define BUTTON_RIGHTALIGN               27
#define BUTTON_INDENT                   28
#define BUTTON_OUTDENT                  29
#define BUTTON_BULLET                   30
#define STRING_COLOR                    33
#define STRING_DEFAULT                  34
#define STRING_CUSTOM                   35
#define IDR_POPUP                       16000
#define ID_EDIT_DELETE                  32774
#define ID_EDIT_SHOWTOOLBAR             32776
#define ID_EDIT_SHOWRULER               32777
#define ID_EDIT_WORDWRAP                32778
#define ID_EDIT_INSERTDATESTAMP         32779
#define ID_EDIT_OPENURL                 32780
#define ID_EDIT_FILEBROWSE              32781
#define ID_EDIT_PASTEASREF              32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        16001
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         16000
#define _APS_NEXT_SYMED_VALUE           16000
#endif
#endif
