// FindTaskDlg.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "FindTaskDlg.h"

#include "..\shared\deferwndmove.h"
#include "..\shared\dlgunits.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

enum { COL_TASK, COL_PATH, COL_TASKLIST };
const int TASKLIST_COLWIDTH = 100;

// static interface
BOOL CFindTaskDlg::Show(CWnd* pParent)
{
	CFindTaskDlg& fd = FindDlg(pParent);

	if (fd.GetSafeHwnd())
	{
		fd.ShowWindow(SW_SHOW);
		return TRUE;
	}

	return FALSE;
}

void CFindTaskDlg::AddResult(LPCTSTR szTask, LPCTSTR szPath, LPCTSTR szTaskList, DWORD dwItemData, int nTaskList)
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.GetSafeHwnd())
	{
		int nPos = fd.m_lcResults.GetItemCount();
		
		// add result
		int nIndex = fd.m_lcResults.InsertItem(nPos, szTask);
		fd.m_lcResults.SetItemText(nIndex, COL_PATH, szPath);
		fd.m_lcResults.SetItemText(nIndex, COL_TASKLIST, szTaskList);
		fd.m_lcResults.UpdateWindow();

		// map identifying data
		FTDRESULT result;
		result.dwItemData = dwItemData;
		result.nTaskList = nTaskList;

		fd.m_mapResults[nIndex] = result;
		
		// update 'found' count
		fd.m_sResultsLabel.Format("&Results (%d found):", nPos + 1);
		fd.UpdateData(FALSE);
	}
}

CFindTaskDlg& CFindTaskDlg::FindDlg(CWnd* pParent)
{
	static CFindTaskDlg fd(pParent);

	if (!fd.GetSafeHwnd())
	{
		VERIFY(fd.Create(IDD_FIND_DIALOG, pParent));

		fd.CenterWindow();
	}
	else if (pParent && pParent != fd.GetParent())
		fd.SetParent(pParent);

	return fd;
}

BOOL CFindTaskDlg::GetSearchAllTasklists()
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.GetSafeHwnd())
	{
		fd.UpdateData();
		return fd.m_bAllTasklists;
	}

	return FALSE;
}

CString CFindTaskDlg::GetTitleComments()
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.m_nFindOption == FW_TITLECOMMENTS)
		return fd.m_pageTitleComments.GetText();

	ASSERT(0);
	return "";
}

CString CFindTaskDlg::GetPerson()
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.m_nFindOption == FW_PERSON)
		return fd.m_pagePerson.GetText();

	ASSERT(0);
	return "";
}

BOOL CFindTaskDlg::GetIncludeDone()
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.GetSafeHwnd())
	{
		fd.UpdateData();
		return fd.m_bIncludeDone;
	}

	return FALSE;
}

BOOL CFindTaskDlg::GetMatchCase()
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.m_nFindOption == FW_TITLECOMMENTS)
		return fd.m_pageTitleComments.GetMatchCase();

	else if (fd.m_nFindOption == FW_PERSON)
		return fd.m_pagePerson.GetMatchCase();

	ASSERT(0);
	return FALSE;
}

BOOL CFindTaskDlg::GetMatchWholeWord()
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.m_nFindOption == FW_TITLECOMMENTS)
		return fd.m_pageTitleComments.GetMatchWholeWord();

	else if (fd.m_nFindOption == FW_PERSON)
		return fd.m_pagePerson.GetMatchWholeWord();

	ASSERT(0);
	return FALSE;
}

FIND_WHAT CFindTaskDlg::GetFindWhat()
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.GetSafeHwnd())
	{
		fd.UpdateData();
		return (FIND_WHAT)fd.m_nFindOption;
	}

	return FW_NOTHING;
}

BOOL CFindTaskDlg::GetDateRange(COleDateTime& dateFrom, COleDateTime& dateTo)
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.m_nFindOption == FW_STARTDATE)
	{
		fd.m_pageStartDate.GetDateRange(dateFrom, dateTo);
		return TRUE;
	}
	else if (fd.m_nFindOption == FW_DUEDATE)
	{
		fd.m_pageDueDate.GetDateRange(dateFrom, dateTo);
		return TRUE;
	}
	else if (fd.m_nFindOption == FW_DONEDATE)
	{
		fd.m_pageDoneDate.GetDateRange(dateFrom, dateTo);
		return TRUE;
	}

	ASSERT(0);
	return FALSE;
}

BOOL CFindTaskDlg::GetPriorityRange(int& nFrom, int& nTo)
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.m_nFindOption == FW_PRIORITY)
	{
		fd.m_pagePriority.GetNumberRange(nFrom, nTo);
		return TRUE;
	}

	ASSERT(0);
	return FALSE;
}

BOOL CFindTaskDlg::GetPercentRange(int& nFrom, int& nTo)
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.m_nFindOption == FW_PERCENTDONE)
	{
		fd.m_pagePercent.GetNumberRange(nFrom, nTo);
		return TRUE;
	}

	ASSERT(0);
	return FALSE;
}

BOOL CFindTaskDlg::GetTimeEstRange(double& dFrom, double& dTo)
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.m_nFindOption == FW_TIMEEST)
	{
		fd.m_pageTimeEst.GetNumberRange(dFrom, dTo);
		return TRUE;
	}

	ASSERT(0);
	return FALSE;
}


/////////////////////////////////////////////////////////////////////////////
// CFindTaskDlg dialog

CFindTaskDlg::CFindTaskDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFindTaskDlg::IDD, pParent), m_sResultsLabel("&Results"), m_pageTimeEst(FALSE)
{
	//{{AFX_DATA_INIT(CFindTaskDlg)
	//}}AFX_DATA_INIT

	m_bAllTasklists = AfxGetApp()->GetProfileInt("FindTasks", "SearchAllTaskLists", FALSE);
	m_bIncludeDone = AfxGetApp()->GetProfileInt("FindTasks", "IncludeDoneTasks", FALSE);
	m_nFindOption = AfxGetApp()->GetProfileInt("FindTasks", "LastFindOption", (int)FW_TITLECOMMENTS);

	m_host.AddPage(&m_pageTitleComments, "TitleComments");
	m_host.AddPage(&m_pagePriority, "Priority");
	m_host.AddPage(&m_pagePercent, "Percent");
	m_host.AddPage(&m_pageTimeEst, "TimeEst");
	m_host.AddPage(&m_pageStartDate, "StartDate");
	m_host.AddPage(&m_pageDueDate, "DueDate");
	m_host.AddPage(&m_pageDoneDate, "DoneDate");
	m_host.AddPage(&m_pagePerson, "Person");
}

void CFindTaskDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFindTaskDlg)
	DDX_Control(pDX, IDC_RESULTS, m_lcResults);
	DDX_CBIndex(pDX, IDC_TASKLISTOPTIONS, m_bAllTasklists);
	DDX_Text(pDX, IDC_RESULTSLABEL, m_sResultsLabel);
	DDX_Check(pDX, IDC_INCLUDEDONE, m_bIncludeDone);
	DDX_CBIndex(pDX, IDC_FINDOPTION, m_nFindOption);
	//}}AFX_DATA_MAP

}


BEGIN_MESSAGE_MAP(CFindTaskDlg, CDialog)
	//{{AFX_MSG_MAP(CFindTaskDlg)
	ON_BN_CLICKED(IDC_FIND, OnFind)
	ON_WM_CLOSE()
	ON_CBN_SELCHANGE(IDC_TASKLISTOPTIONS, OnSelchangeTasklistoptions)
	ON_WM_SIZE()
	ON_NOTIFY(LVN_ITEMACTIVATE, IDC_RESULTS, OnItemActivated)
	ON_WM_DESTROY()
	ON_CBN_SELCHANGE(IDC_FINDOPTION, OnSelchangeFindoption)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFindTaskDlg message handlers

void CFindTaskDlg::OnFind() 
{
	// add typed text to combobox
	UpdateData();

	// notify parent
	GetParent()->PostMessage(WM_FTD_FIND);

	// clear results and set focus to results
	m_mapResults.RemoveAll();
	m_lcResults.DeleteAllItems();
	m_lcResults.SetFocus();
	m_sResultsLabel = "&Results (0 found)";
	UpdateData(FALSE);
}

void CFindTaskDlg::OnClose() 
{
	CDialog::OnClose();

	// hide
	ShowWindow(SW_HIDE);
}

BOOL CFindTaskDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	CDialogHelper::SetFont(this, (HFONT)GetStockObject(DEFAULT_GUI_FONT), FALSE);

	m_host.Create(IDC_PAGEHOST, this);

	if (m_nFindOption != FW_TITLECOMMENTS)
		m_host.SetActivePage(m_nFindOption);

	// gripper
	// position resize icon as close to bottom left as pos
	GetDlgItem(IDC_GRIPPER)->ModifyStyle(0, SBS_SIZEGRIP | SBS_SIZEBOXTOPLEFTALIGN | WS_CLIPSIBLINGS);
	CDeferWndMove(1).OffsetCtrl(this, IDC_GRIPPER, 1, 2);

	// setup up result list
	m_lcResults.InsertColumn(COL_TASK, "Task", LVCFMT_LEFT, 200);
	m_lcResults.InsertColumn(COL_PATH, "Path", LVCFMT_LEFT, 100);
	m_lcResults.InsertColumn(COL_TASKLIST, "Tasklist", LVCFMT_LEFT, 100);

	DWORD dwExStyle = m_lcResults.GetExtendedStyle() | 
						LVS_EX_ONECLICKACTIVATE | LVS_EX_TWOCLICKACTIVATE | LVS_EX_UNDERLINEHOT;
	m_lcResults.SetExtendedStyle(dwExStyle);

	// restore column widths
	m_lcResults.SetColumnWidth(COL_PATH, AfxGetApp()->GetProfileInt("FindTasks", "PathColWidth", 100));
	m_lcResults.SetColumnWidth(COL_TASKLIST, AfxGetApp()->GetProfileInt("FindTasks", "TaskListColWidth", 100));

	// restore dialog size
	DWORD dwSize = AfxGetApp()->GetProfileInt("FindTasks", "Size", 0);

	if (dwSize)
		MoveWindow(0, 0, LOWORD(dwSize), HIWORD(dwSize));

	ResizeDlg();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CFindTaskDlg::OnSelchangeTasklistoptions() 
{
	static int nColWidth = TASKLIST_COLWIDTH; // first time it will be shown

	// hide the tasklist column depending on the result
	UpdateData();

	if (m_bAllTasklists) // currently hidden
		m_lcResults.SetColumnWidth(COL_TASKLIST, nColWidth);
	else
	{
		nColWidth = m_lcResults.GetColumnWidth(COL_TASKLIST);
		m_lcResults.SetColumnWidth(COL_TASKLIST, 0);
	}
}

void CFindTaskDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);

	ResizeDlg(cx, cy);
}

void CFindTaskDlg::ResizeDlg(int cx, int cy)
{
	if (m_lcResults.GetSafeHwnd())
	{
		if (!cx && !cy)
		{
			CRect rClient;
			GetClientRect(rClient);

			cx = rClient.right;
			cy = rClient.bottom;

			// check again 
			if (!cx && !cy)
				return;
		}

		// we compare the new size with the lower right hand corner
		// of the results list
		int nBorder = CDlgUnits(*this).ToPixelsX(7);

		CRect rResults;
		m_lcResults.GetWindowRect(rResults);
		ScreenToClient(rResults);

		int nXOffset = cx - nBorder - rResults.right;
		int nYOffset = cy - nBorder - rResults.bottom;

		{
			CDeferWndMove dwm(5);
			
			dwm.ResizeCtrl(this, IDC_DIVIDER, nXOffset);
			dwm.ResizeCtrl(this, IDC_RESULTS, nXOffset, nYOffset);
			dwm.OffsetCtrl(this, IDC_GRIPPER, nXOffset, nYOffset);
		}

		// resize the column headers to fit the available space
		// provided it does not get less than 100
		int nFixed = m_lcResults.GetColumnWidth(COL_PATH) + m_lcResults.GetColumnWidth(COL_TASKLIST);
		
		if (!(m_lcResults.GetStyle() & WS_VSCROLL))
			nFixed += GetSystemMetrics(SM_CXVSCROLL);

		m_lcResults.GetClientRect(rResults);
		m_lcResults.SetColumnWidth(COL_TASK, max(100, rResults.Width() - nFixed));
	}	
}

void CFindTaskDlg::OnItemActivated(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	ASSERT (pNMListView->iItem >= 0);

	FTDRESULT result;

	if (m_mapResults.Lookup(pNMListView->iItem, result))
		GetParent()->SendMessage(WM_FTD_SELECTRESULT, pNMListView->iItem, (LPARAM)&result);
	
	*pResult = 0;
}

void CFindTaskDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	SaveSettings();
}

void CFindTaskDlg::SaveSettings()
{
	UpdateData();

	AfxGetApp()->WriteProfileInt("FindTasks", "SearchAllTaskLists", m_bAllTasklists);
	AfxGetApp()->WriteProfileInt("FindTasks", "IncludeDoneTasks", m_bIncludeDone);
	AfxGetApp()->WriteProfileInt("FindTasks", "LastFindOption", m_nFindOption);

	// save column widths
	AfxGetApp()->WriteProfileInt("FindTasks", "PathColWidth", m_lcResults.GetColumnWidth(COL_PATH));
	AfxGetApp()->WriteProfileInt("FindTasks", "TaskListColWidth", m_lcResults.GetColumnWidth(COL_TASKLIST));

	// save dialog size
	CRect rDialog;
	GetWindowRect(rDialog);
	AfxGetApp()->WriteProfileInt("FindTasks", "Size", MAKELONG(rDialog.Width(), rDialog.Height()));
}


void CFindTaskDlg::OnSelchangeFindoption() 
{
	UpdateData();

	m_host.SetActivePage(m_nFindOption, FALSE);	
}
