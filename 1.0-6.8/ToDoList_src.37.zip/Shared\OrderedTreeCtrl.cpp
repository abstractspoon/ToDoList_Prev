// ToDoCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "orderedtreeCtrl.h"

#include "..\shared\holdredraw.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COrderedTreeCtrl

const UINT MINGUTTER = 16;
const UINT COLPADDING = 3;

#define WM_POSTSUBCLASS (WM_APP+1)

static CMap<int, int&, int, int&> g_mapWidths;

COrderedTreeCtrl::COrderedTreeCtrl() : 
	m_bShowingPosColumn(TRUE), m_bShowGridlines(TRUE), m_crGridlines(OTC_GRIDCOLOR)
{
	AddGutterColumn(OTC_POSCOLUMNID, "Pos"); // for the pos string

	EnableGutterColumnHeaderClicking(OTC_POSCOLUMNID, FALSE);
}

COrderedTreeCtrl::~COrderedTreeCtrl()
{
}

BEGIN_MESSAGE_MAP(COrderedTreeCtrl, CDragDropTreeCtrl)
	//{{AFX_MSG_MAP(COrderedTreeCtrl)
	//}}AFX_MSG_MAP
	ON_WM_STYLECHANGED()
	ON_NOTIFY_REFLECT_EX(TVN_ITEMEXPANDED, OnItemexpanded)
	ON_NOTIFY_REFLECT_EX(NM_CUSTOMDRAW, OnCustomDraw)
	ON_NOTIFY_REFLECT_EX(NM_CLICK, OnClick)
	ON_NOTIFY_REFLECT(TVN_BEGINDRAG, OnBeginDrag)
	ON_MESSAGE(WM_POSTSUBCLASS, OnPostSubclass)
	ON_REGISTERED_MESSAGE(WM_NCG_GETFIRSTVISIBLETOPLEVELITEM, OnGutterGetFirstVisibleTopLevelItem)
	ON_REGISTERED_MESSAGE(WM_NCG_GETNEXTITEM, OnGutterGetNextItem)
	ON_REGISTERED_MESSAGE(WM_NCG_DRAWITEM, OnGutterDrawItem)
	ON_REGISTERED_MESSAGE(WM_NCG_RECALCCOLWIDTH, OnGutterRecalcColWidth)
	ON_REGISTERED_MESSAGE(WM_NCG_POSTNCDRAW, OnGutterPostNcDraw)
	ON_REGISTERED_MESSAGE(WM_NCG_GETITEMRECT, OnGutterGetItemRect)
	ON_REGISTERED_MESSAGE(WM_NCG_GETFIRSTCHILDITEM, OnGutterGetFirstChildItem)
	ON_REGISTERED_MESSAGE(WM_NCG_POSTDRAWITEM, OnGutterPostDrawItem)
	ON_REGISTERED_MESSAGE(WM_NCG_GETSELECTEDITEM, OnGutterGetSelectedItem)
	ON_REGISTERED_MESSAGE(WM_NCG_SETSELECTEDITEM, OnGutterSetSelectedItem)
	ON_REGISTERED_MESSAGE(WM_NCG_HITTEST, OnGutterHitTest)
	ON_REGISTERED_MESSAGE(WM_NCG_NOTIFYCOLUMNCLICK, OnGutterNotifyColumnClick)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COrderedTreeCtrl message handlers

void COrderedTreeCtrl::PreSubclassWindow() 
{
	m_gutter.AddRecalcMessage(TVM_INSERTITEM);
	m_gutter.AddRecalcMessage(TVM_INSERTITEM);
	m_gutter.AddRecalcMessage(TVM_DELETEITEM);
	m_gutter.AddRecalcMessage(TVM_EXPAND);

	m_gutter.AddRedrawMessage(WM_KEYUP); // only way to catch keyboard navigation (at present)
	m_gutter.AddRedrawMessage(TVM_SELECTITEM);
	m_gutter.AddRedrawMessage(TVM_SORTCHILDREN);
	m_gutter.AddRedrawMessage(TVM_SORTCHILDRENCB);
	m_gutter.AddRedrawMessage(WM_COMMAND, EN_KILLFOCUS);

	CDragDropTreeCtrl::PreSubclassWindow();

	// note: its too early to initialize the gutter here because 
	// MFC hasn't done its bit yet, so we post a message instead
	PostMessage(WM_POSTSUBCLASS);
}

void COrderedTreeCtrl::ShowGutterPosColumn(BOOL bShow)
{
	if (m_bShowingPosColumn != bShow)
	{
		m_bShowingPosColumn = bShow;
		m_gutter.RecalcGutter();
	}
}

void COrderedTreeCtrl::ShowGridlines(BOOL bShow)
{
	if (m_bShowGridlines != bShow)
	{
		m_bShowGridlines = bShow;

		if (GetSafeHwnd())
		{
			m_gutter.Redraw();
			Invalidate();
		}
	}
}

void COrderedTreeCtrl::SetGridlineColor(COLORREF color)
{
	if (m_crGridlines != color)
	{
		m_crGridlines = color;

		if (GetSafeHwnd())
		{
			m_gutter.Redraw();
			Invalidate();
		}
	}
}

int COrderedTreeCtrl::AddGutterColumn(UINT nColID, LPCTSTR szTitle, UINT nWidth, UINT nTextAlign)
{
	return m_gutter.AddColumn(nColID, szTitle, nWidth, nTextAlign);
}

void COrderedTreeCtrl::PressGutterColumnHeader(UINT nColID, BOOL bPress)
{
	m_gutter.PressColumnHeader(nColID, bPress);
}

void COrderedTreeCtrl::SetGutterColumnHeaderTitle(UINT nColID, LPCTSTR szTitle)
{
	m_gutter.SetColumnHeaderTitle(nColID, szTitle);
}

void COrderedTreeCtrl::SetGutterColumnSort(UINT nColID, NCGSORT nSortDir)
{
	m_gutter.SetColumnSort(nColID, nSortDir);
}

void COrderedTreeCtrl::EnableGutterColumnHeaderClicking(UINT nColID, BOOL bEnable)
{
	m_gutter.EnableColumnHeaderClicking(nColID, bEnable);
}

LRESULT COrderedTreeCtrl::OnGutterGetFirstVisibleTopLevelItem(WPARAM wParam, LPARAM lParam)
{
	return (LRESULT)GetFirstVisibleTopLevelItem(*((LPINT)lParam));
}

LRESULT COrderedTreeCtrl::OnGutterGetNextItem(WPARAM wParam, LPARAM lParam)
{
	return (LRESULT)GetNextItem((HTREEITEM)lParam, TVGN_NEXT);
}

LRESULT COrderedTreeCtrl::OnGutterGetFirstChildItem(WPARAM wParam, LPARAM lParam)
{
	HTREEITEM hti = (HTREEITEM)lParam;

	if (ItemHasChildren(hti) && IsItemExpanded(hti))
		return (LRESULT)GetChildItem(hti);

	return 0;
}

LRESULT COrderedTreeCtrl::OnGutterDrawItem(WPARAM wParam, LPARAM lParam)
{
	NCGDRAWITEM* pNCGDI = (NCGDRAWITEM*)lParam;

	if (pNCGDI->nColID == OTC_POSCOLUMNID)
	{
		NcDrawItem(pNCGDI->pDC, pNCGDI->dwItem, pNCGDI->dwParentItem, pNCGDI->nColID, CRect(pNCGDI->rItem), 
					pNCGDI->nLevel, pNCGDI->nItemPos, pNCGDI->bSelected, pNCGDI->rWindow);

		return TRUE; // we handled it
	}

	// else
	return FALSE;
}

LRESULT COrderedTreeCtrl::OnGutterPostDrawItem(WPARAM wParam, LPARAM lParam)
{
	NCGDRAWITEM* pNCGDI = (NCGDRAWITEM*)lParam;

	PostNcDrawItem(pNCGDI->pDC, pNCGDI->dwItem, pNCGDI->rItem, pNCGDI->nLevel);

	return FALSE; // to let our parent handle it too
}

LRESULT COrderedTreeCtrl::OnGutterPostNcDraw(WPARAM wParam, LPARAM lParam)
{
	NCGDRAWITEM* pNCGDI = (NCGDRAWITEM*)lParam;

	PostNcDraw(pNCGDI->pDC, pNCGDI->rWindow);

	return FALSE; // to let our parent handle it too
}

LRESULT COrderedTreeCtrl::OnGutterRecalcColWidth(WPARAM wParam, LPARAM lParam)
{
	NCGRECALCCOLUMN* pNCRC = (NCGRECALCCOLUMN*)lParam;

	return RecalcColumnWidth(pNCRC->pDC, pNCRC->nColID, pNCRC->nWidth);
}

LRESULT COrderedTreeCtrl::OnGutterGetItemRect(WPARAM wParam, LPARAM lParam)
{
	NCGITEMRECT* pNCGGI = (NCGITEMRECT*)lParam;

	return GetItemRect((HTREEITEM)pNCGGI->dwItem, &pNCGGI->rItem, TRUE);
}

LRESULT COrderedTreeCtrl::OnGutterGetSelectedItem(WPARAM wParam, LPARAM lParam)
{
	return (LRESULT)GetSelectedItem();
}

LRESULT COrderedTreeCtrl::OnGutterSetSelectedItem(WPARAM wParam, LPARAM lParam)
{
	SelectItem((HTREEITEM)lParam);
	return TRUE; // we handled it.
}

LRESULT COrderedTreeCtrl::OnGutterHitTest(WPARAM wParam, LPARAM lParam)
{
	CPoint point(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));

	UINT nFlags = 0;
	HTREEITEM hti = HitTest(point, &nFlags);

	return (LRESULT)hti;
}

void COrderedTreeCtrl::PostNcDraw(CDC* pDC, const CRect& rWindow)
{
}

void COrderedTreeCtrl::NcDrawItem(CDC* pDC, DWORD dwItem, DWORD dwParentItem, UINT nColID, CRect& rItem, 
								  int nLevel, int nPos, BOOL bSelected, const CRect& rWindow)
{
	HTREEITEM hti = (HTREEITEM)dwItem;

	if (nColID == OTC_POSCOLUMNID) // this is all we deal with
	{
		// extract the parent pos
		CString sPos, sParentPos; 
		static CMap<DWORD, DWORD, CString, LPCTSTR> mapParentPos;

		if (dwParentItem)
			VERIFY(mapParentPos.Lookup(dwParentItem, sParentPos));

		BOOL bHasChildren = ItemHasChildren(hti);

		// default
		if (sParentPos.IsEmpty())
			sPos.Format("%d", nPos);
		else
			sPos.Format("%s.%d", sParentPos, nPos);

		// add to map for our children
		if (bHasChildren)
			mapParentPos[dwItem] = sPos;
		
		// modify for actual output
		if (bHasChildren && !IsItemExpanded(hti))
			sPos += "...";
		
		else if (nLevel == 0)
			sPos += ".";

		if (CRect().IntersectRect(rItem, rWindow)) // something to see
		{
			int nSaveDC = pDC->SaveDC();
			
			// fill background of selected item
			BOOL bFocused = HasFocus(!(GetStyle() & TVS_FULLROWSELECT));
			
			if (bSelected)
			{
				COLORREF crBkColor = GetSysColor(bFocused ? COLOR_HIGHLIGHT : COLOR_3DFACE);
				pDC->FillSolidRect(rItem, crBkColor);
			}
			
			// draw pos
			COLORREF crTextColor = GetSysColor((bSelected && bFocused) ? COLOR_HIGHLIGHTTEXT : COLOR_WINDOWTEXT);
			
			pDC->SetTextColor(crTextColor);
			pDC->SetBkMode(TRANSPARENT);

			rItem.left += COLPADDING;
			pDC->DrawText(sPos, rItem, DT_SINGLELINE | DT_VCENTER | DT_LEFT);
			
			pDC->RestoreDC(nSaveDC);
		}
		
		// vertical divider
		if (!bSelected && m_bShowGridlines)
			pDC->FillSolidRect(rItem.right - 1, rItem.top, 1, rItem.Height(), m_crGridlines);
	}
}

BOOL COrderedTreeCtrl::HasFocus(BOOL bIncEditing)
{
	CWnd* pFocus = GetFocus();
	
	return (pFocus && (pFocus == this || (bIncEditing && pFocus == GetEditControl())));
}

void COrderedTreeCtrl::PostNcDrawItem(CDC* pDC, DWORD dwItem, const CRect& rItem, int nLevel)
{
	if (nLevel == 0 && m_bShowGridlines)
		pDC->FillSolidRect(rItem.left, rItem.bottom - 1, rItem.Width(), 1, m_crGridlines);
}

BOOL COrderedTreeCtrl::OnItemexpanded(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

	m_gutter.RecalcGutter();

	*pResult = 0;
	return FALSE;
}

BOOL COrderedTreeCtrl::OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
	CDragDropTreeCtrl::OnCustomDraw(pNMHDR, pResult);

	NMCUSTOMDRAW* pNMCD = (NMCUSTOMDRAW*)pNMHDR;

	if (pNMCD->dwDrawStage == CDDS_ITEMPREPAINT)
		*pResult |= CDRF_NOTIFYPOSTPAINT;
		
	else if (pNMCD->dwDrawStage == CDDS_ITEMPOSTPAINT)
	{
		CDC* pDC = CDC::FromHandle(pNMCD->hdc);
		NMTVCUSTOMDRAW* pTVCD = (NMTVCUSTOMDRAW*)pNMCD;

		HTREEITEM hti = (HTREEITEM)pTVCD->nmcd.dwItemSpec;

		// if the next visible item is a top level item then draw a horz line below us
		HTREEITEM htiNext = GetNextVisibleItem(hti);

		if (!GetParentItem(htiNext))
		{
			// but if the bottom of the text coincides with the bottom of the 
			// item and we have the then take care not to draw over the focus rect
			// but only if we do _not have TVS_FULLROWSELECT style
			if ((pNMCD->uItemState & CDIS_FOCUS) && !(GetStyle() & TVS_FULLROWSELECT))
			{
				HTREEITEM hti = (HTREEITEM)pTVCD->nmcd.dwItemSpec;

				CRect rText;
				GetItemRect(hti, rText, TRUE);

				if (rText.bottom == pNMCD->rc.bottom)
				{
					pDC->FillSolidRect(pNMCD->rc.left, pNMCD->rc.bottom - 1, rText.left - pNMCD->rc.left, 1, m_crGridlines);
					pDC->FillSolidRect(rText.right, pNMCD->rc.bottom - 1, pNMCD->rc.right - rText.right, 1, m_crGridlines);
				}
				else
					pDC->FillSolidRect(pNMCD->rc.left, pNMCD->rc.bottom - 1, pNMCD->rc.right - pNMCD->rc.left, 1, m_crGridlines);
			}
			else
				pDC->FillSolidRect(pNMCD->rc.left, pNMCD->rc.bottom - 1, pNMCD->rc.right - pNMCD->rc.left, 1, m_crGridlines);
		}

		*pResult |= CDRF_DODEFAULT;
	}

	return FALSE; // to continue routing
}

DWORD COrderedTreeCtrl::GetFirstVisibleTopLevelItem(int& nPos)
{
	CRect rClient;
	GetClientRect(rClient);

	HTREEITEM hti = GetNextItem(NULL, TVGN_CHILD), htiPrev = NULL;
	nPos = 1;

	if (hti)
	{
		// look for the first top level item whose children are visible
		do
		{
			CRect rItem;
			GetItemRect(hti, rItem, FALSE);

			if (rItem.top == 0) // coincides with the top
			{
				ASSERT (hti == GetFirstVisibleItem());
				return (DWORD)hti;
			}
			else if (rItem.bottom <= 0) // not visible
			{
				htiPrev = hti;
				hti = GetNextItem(hti, TVGN_NEXT);
				nPos++;
			}
			else // back peddle to the previous item
			{
				ASSERT (htiPrev);

				nPos--;
				return (DWORD)htiPrev;
			}
		}
		while (hti); 
	}

	// if we got here then either the are no items or we ran out
	// either way returning the previous item is correct
	if (htiPrev)
		nPos--;

	return (DWORD)htiPrev;
}

int COrderedTreeCtrl::RecalcColumnWidth(CDC* pDC, UINT nColID, int& nWidth)
{
	switch (nColID)
	{
	case OTC_POSCOLUMNID:
		if (m_bShowingPosColumn)
		{
			g_mapWidths.RemoveAll(); // to handle a font change
			HTREEITEM hti = GetNextItem(NULL, TVGN_CHILD);
			int nPos = 1;
			int nMaxWidth = 0;

			while (hti)
			{
				int nItemWidth = GetGutterWidth(hti, 0, nPos, pDC);
				nMaxWidth = max(nMaxWidth, nItemWidth);

				hti = GetNextItem(hti, TVGN_NEXT);
				nPos++;
			}

			nWidth = max(nMaxWidth + 2 * COLPADDING, MINGUTTER);
		}
		else
			nWidth = 0;

		return TRUE;
	}

	return 0;
}

int COrderedTreeCtrl::GetGutterWidth(HTREEITEM hti, int nLevel, int nPos, CDC* pDC)
{
	int nMaxWidth = 0;

	if (GetItemState(hti, TVIS_EXPANDED) & TVIS_EXPANDED)
	{
		HTREEITEM htiChild = GetChildItem(hti);
		int nPosChild = 1;
		nLevel++;

		while (htiChild)
		{
			int nWidth = GetGutterWidth(htiChild, nLevel, nPosChild, pDC);
			nMaxWidth = max(nMaxWidth, nWidth);

			htiChild = GetNextItem(htiChild, TVGN_NEXT);
			nPosChild++;
		}
	}
	else if (ItemHasChildren(hti)/* && ShowingEllipsis(nLevel)*/)
	{
		nMaxWidth = GetWidth(-1, pDC); // ellipsis
	}

	return nMaxWidth + GetWidth(nPos, pDC);
}

BOOL COrderedTreeCtrl::OnClick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// make sure the selection is correctly set
	// see if the click was on the 'done' checkbox
	CPoint point(::GetMessagePos());
	ScreenToClient(&point);

	HTREEITEM htiHit = HitTest(point);

	if (htiHit)
		SelectItem(htiHit);

	*pResult = 0;

	return FALSE; // to continue routing
}

void COrderedTreeCtrl::OnBeginDrag(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NMTREEVIEW* pNMTV = (NMTREEVIEW*)pNMHDR;
	SelectItem(pNMTV->itemNew.hItem);

	CDragDropTreeCtrl::OnBeginDrag(pNMHDR, pResult);

	m_gutter.Redraw();
}

int COrderedTreeCtrl::GetWidth(int nNumber, CDC* pDC)
{
	int nWidth = 0;

	if (g_mapWidths.Lookup(nNumber, nWidth))
		return nWidth;

	if (nNumber >= 0)
	{
		CString sNumber;
		sNumber.Format("%d.", nNumber);
		nWidth = pDC->GetTextExtent(sNumber).cx;
	}
	else if (nNumber == -1)
		nWidth = pDC->GetTextExtent("...").cx;

	g_mapWidths[nNumber] = nWidth;
	return nWidth;
}

LRESULT COrderedTreeCtrl::OnPostSubclass(WPARAM wParam, LPARAM lParam)
{
	// initialize the gutter
	m_gutter.Initialize(GetSafeHwnd());
	return 0;
}

LRESULT COrderedTreeCtrl::OnGutterNotifyColumnClick(WPARAM wParam, LPARAM lParam)
{
	NCGITEMCLICK* pNGIC = (NCGITEMCLICK*)lParam;
	ASSERT (pNGIC);

	EndLabelEdit(FALSE); // always
	SelectItem((HTREEITEM)pNGIC->dwItem); // always

	switch (pNGIC->nMsgID)
	{
	case WM_NCLBUTTONDBLCLK:
		if (pNGIC->dwItem)
			Expand((HTREEITEM)pNGIC->dwItem, IsItemExpanded((HTREEITEM)pNGIC->dwItem) ? TVE_COLLAPSE : TVE_EXPAND);
		break;
	}

	return 0L;
}

void COrderedTreeCtrl::OnCancelDrop()
{
}

void COrderedTreeCtrl::OnPostDrop()
{
}

void COrderedTreeCtrl::OnStyleChanged(int nStyleType, LPSTYLESTRUCT lpSS)
{
	if (nStyleType == GWL_STYLE)
	{
		BOOL bButtonsOld = lpSS->styleOld & TVS_HASBUTTONS;
		BOOL bButtonsNew = lpSS->styleNew & TVS_HASBUTTONS;

		if (bButtonsOld != bButtonsNew)
			RecalcGutter();

		else if (bButtonsNew)
		{
			UINT uStyleOld = lpSS->styleOld & (TVS_HASLINES | TVS_LINESATROOT);
			UINT uStyleNew = lpSS->styleNew & (TVS_HASLINES | TVS_LINESATROOT);

			if (uStyleOld != uStyleNew)
				RecalcGutter();
		}
	}

	CDragDropTreeCtrl::OnStyleChanged(nStyleType, lpSS);
}

