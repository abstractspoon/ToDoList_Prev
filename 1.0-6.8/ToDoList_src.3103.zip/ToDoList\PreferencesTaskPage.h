#if !defined(AFX_PREFERENCESTASKPAGE_H__84CBF881_D8CA_4D00_ADD6_1DCB7DE71C5B__INCLUDED_)
#define AFX_PREFERENCESTASKPAGE_H__84CBF881_D8CA_4D00_ADD6_1DCB7DE71C5B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesTaskPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPreferencesTaskPage dialog

class CPreferencesTaskPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPreferencesTaskPage)

// Construction
public:
	CPreferencesTaskPage();
	~CPreferencesTaskPage();

	BOOL GetAutoReSort() const { return m_bAutoReSort; }
	BOOL GetAveragePercentSubCompletion() const { return m_bAveragePercentSubCompletion; }
	BOOL GetIncludeDoneInAverageCalc() const { return m_bIncludeDoneInAverageCalc; }
	BOOL GetUseEarliestDueDate() const { return m_bUseEarliestDueDate; }
	BOOL GetUsePercentDoneInTimeEst() const { return m_bUsePercentDoneInTimeEst; }
	BOOL GetTreatSubCompletedAsDone() const { return m_bTreatSubCompletedAsDone; }
	BOOL GetHidePercentForDoneTasks() const { return m_bHidePercentForDoneTasks; }
	BOOL GetHideZeroTimeEst() const { return m_bHideZeroTimeEst; }
	BOOL GetHideStartDueForDoneTasks() const { return m_bHideStartDueForDoneTasks; }
	BOOL GetShowPercentAsProgressbar() const { return m_bShowPercentAsProgressbar; }
	BOOL GetQueryApplyChangestoSubtasks() const { return m_bQueryApplyChangestoSubtasks; }
	BOOL GetSortVisibleOnly() const { return m_bSortVisibleOnly; }
	BOOL GetUseHighestPriority() const { return m_bUseHighestPriority; }
	BOOL GetAutoCalcTimeEstimates() const { return m_bAutoCalcTimeEst; }
	BOOL GetRoundTimeFractions() const { return m_bRoundTimeFractions; }
	BOOL GetShowNonFilesAsText() const { return m_bShowNonFilesAsText; }
	BOOL GetIncludeDoneInPriorityCalc() const { return m_bIncludeDoneInPriorityCalc; }
	BOOL GetWeightPercentCompletionByTimeEst() const { return m_bWeightPercentCompletionByTimeEst; }
	BOOL GetWeightPercentCompletionByPriority() const { return m_bWeightPercentCompletionByPriority; }
	BOOL GetAutoCalcPercentDone() const { return m_bAutoCalcPercentDone; }
	BOOL GetTrackSelectedTaskOnly() const { return m_bTrackSelectedTaskOnly; }
//	BOOL Get() const { return m_b; }

protected:
// Dialog Data
	//{{AFX_DATA(CPreferencesTaskPage)
	enum { IDD = IDD_PREFTASK_PAGE };
	BOOL	m_bAutoReSort;
	BOOL	m_bHideZeroTimeEst;
	BOOL	m_bTreatSubCompletedAsDone;
	BOOL	m_bHideStartDueForDoneTasks;
	BOOL	m_bQueryApplyChangestoSubtasks;
	BOOL	m_bSortVisibleOnly;
	BOOL	m_bUseHighestPriority;
	BOOL	m_bAutoCalcTimeEst;
	BOOL	m_bRoundTimeFractions;
	BOOL	m_bShowNonFilesAsText;
	BOOL	m_bIncludeDoneInPriorityCalc;
	BOOL	m_bWeightPercentCompletionByTimeEst;
	BOOL	m_bWeightPercentCompletionByPriority;
	BOOL	m_bAutoCalcPercentDone;
	BOOL	m_bTrackSelectedTaskOnly;
	//}}AFX_DATA
	BOOL	m_bShowPercentAsProgressbar;
	BOOL	m_bUseEarliestDueDate;
	BOOL	m_bUsePercentDoneInTimeEst;
	BOOL	m_bHidePercentForDoneTasks;
	BOOL	m_bAveragePercentSubCompletion;
	BOOL	m_bIncludeDoneInAverageCalc;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesTaskPage)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesTaskPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnUsehighestpriority();
	//}}AFX_MSG
	afx_msg void OnAveragepercentChange();
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESTASKPAGE_H__84CBF881_D8CA_4D00_ADD6_1DCB7DE71C5B__INCLUDED_)
