// XmlFile.cpp: implementation of the CXmlFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "XmlFile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////

#include "xmlcharmap.h"
#include "htmlcharmap.h"

CString& XML2TXT(CString& xml) { return CHtmlCharMap::ConvertFromRep(xml); } // we use the html map for backwards compatibility
CString& TXT2XML(CString& txt) { return CXmlCharMap::ConvertToRep(txt); }
CString& TXT2HTML(CString& txt) { return CHtmlCharMap::ConvertToRep(txt); }

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const char SINGLE_QUOTE = 0x27;
const char DOUBLE_QUOTE = 0x22;
const LPCTSTR ENDL = "\n";
const LPCTSTR TAGSTART = "<";
const LPCTSTR TAGEND = ">";
const LPCTSTR CDATAEND = "]]>";

enum
{
	TYPE_ITEM,
	TYPE_COMMENT,
	TYPE_CDATA,

	TYPE_LAST
};

LPCTSTR VALUEDELIMS[] = { "<", "-->", "]]>" };
LPCTSTR TYPENAMES[] = { "", "!--", CDATA };

//////////////////////////////////////////////////////////////

CXmlItem::CXmlItem(CXmlItem* pParent, LPCTSTR szName, LPCTSTR szValue) :
	m_pParent(pParent), m_pSibling(NULL), m_sName(szName), m_sValue(szValue)
{
	m_sName.TrimLeft();
	m_sName.TrimRight();
//	m_sValue.TrimLeft();
//	m_sValue.TrimRight();
}

CXmlItem::CXmlItem(const CXmlItem& xi, CXmlItem* pParent) : m_pParent(pParent), m_pSibling(NULL)
{
	m_sName = xi.GetName();
	m_sValue = xi.GetValue();

	// copy siblings
	const CXmlItem* pXISibling = xi.GetSibling();

	if (pXISibling)
		m_pSibling = new CXmlItem(*pXISibling, pParent);

	// copy children
	POSITION pos = xi.GetFirstItemPos();

	while (pos)
	{
		const CXmlItem* pXIChild = xi.GetNextItem(pos);
		ASSERT (pXIChild);

		AddItem(*pXIChild);
	}
}

CXmlItem::~CXmlItem()
{
	Reset();
}

void CXmlItem::Reset()
{
	// delete children
	POSITION pos = m_mapItems.GetStartPosition();
	
	while (pos)
	{
		CXmlItem* pXI = NULL;
		CString sItem;
		
		m_mapItems.GetNextAssoc(pos, sItem, pXI);
		delete pXI;
	}

	m_mapItems.RemoveAll();

	// and siblings
	// note: because sibling ~tor calls its own Reset() the chain 
	// of siblings will be correctly cleaned up
	delete m_pSibling;
	m_pSibling = NULL;
}

const CXmlItem* CXmlItem::GetItem(CString sItem, LPCTSTR szSubItem) const
{
	return GetItemEx(sItem, szSubItem);
}

CXmlItem* CXmlItem::GetItem(CString sItem, LPCTSTR szSubItem)
{
	// cast away constness
	return (CXmlItem*)GetItemEx(sItem, szSubItem);
}

// special internal version
const CXmlItem* CXmlItem::GetItemEx(CString sItem, LPCTSTR szSubItem) const
{
	CXmlItem* pXI = NULL;
	sItem.MakeUpper();
	
	m_mapItems.Lookup(sItem, pXI);
	
	if (pXI && szSubItem && lstrlen(szSubItem))
		return pXI->GetItem(szSubItem);

	return pXI;
}

const CXmlItem* CXmlItem::FindItem(LPCTSTR szItemName, LPCTSTR szItemValue, BOOL bSearchChildren) const
{
	return FindItemEx(szItemName, szItemValue, bSearchChildren);
}

CXmlItem* CXmlItem::FindItem(LPCTSTR szItemName, LPCTSTR szItemValue, BOOL bSearchChildren)
{
	// cast away constness
	return (CXmlItem*)FindItemEx(szItemName, szItemValue, bSearchChildren);
}

// special internal version
const CXmlItem* CXmlItem::FindItemEx(LPCTSTR szItemName, LPCTSTR szItemValue, BOOL bSearchChildren) const
{
	// check our name and value
	if (m_sName.CompareNoCase(szItemName) == 0 && m_sValue.Compare(szItemValue) == 0)
		return this;

	const CXmlItem* pFound = NULL;

	// search all our children
	if (bSearchChildren)
	{
		POSITION pos = GetFirstItemPos();

		while (pos && !pFound)
		{
			const CXmlItem* pXIChild = GetNextItem(pos);
			ASSERT (pXIChild);

			TRACE("CXmlItem::FindItemEx(%s=%s)\n", pXIChild->GetName(), pXIChild->GetValue());

			if (pXIChild->ValueMatches("258"))
				int a = 5;
			pFound = pXIChild->FindItemEx(szItemName, szItemValue, TRUE); // child will search its own siblings
		}
	}

	// then our siblings
	if (!pFound)
	{
		// only get first sibling as each sibling does its own
		const CXmlItem* pXISibling = GetSibling();

		if (pXISibling)
			pFound = pXISibling->FindItemEx(szItemName, szItemValue, TRUE);
	}

	return pFound;
}

LPCTSTR CXmlItem::GetItemValue(CString sItem, LPCTSTR szSubItem) const
{
	const CXmlItem* pXI = GetItem(sItem, szSubItem);

	if (pXI)
		return pXI->GetValue();
	else
	{
		static CString NULL_VALUE;
		return NULL_VALUE;
	};
}

CXmlItem* CXmlItem::AddItem(CString sName, LPCTSTR szValue)
{
	ASSERT (!sName.IsEmpty());
	
	if (sName.IsEmpty())
		return NULL;

	CXmlItem* pXI = new CXmlItem(this, sName, szValue);
	
	// if an item of the same name already exists then add this
	// item as a sibling to the existing item else its a new item
	// so add and map name to this object
	CXmlItem* pXPExist = GetItem(sName);

	if (pXPExist)
		pXPExist->AddSibling(pXI);
	else
	{
		sName.MakeUpper();
		m_mapItems[sName] = pXI;
	}
	
	return pXI;
}

CXmlItem* CXmlItem::AddItem(const CXmlItem& xi)
{
	CXmlItem* pXI = new CXmlItem(xi, this);
	
	// if an item of the same name already exists then add this
	// item as a sibling to the existing item else its a new item
	// so add and map name to this object
	CXmlItem* pXPExist = GetItem(xi.GetName());

	if (pXPExist)
		pXPExist->AddSibling(pXI);
	else
		m_mapItems[xi.GetName()] = pXI;
	
	return pXI;
}

CXmlItem* CXmlItem::AddItem(CString sName, int nValue)
{
	CString sValue;
	sValue.Format("%d", nValue);

	return AddItem(sName, sValue);
}

CXmlItem* CXmlItem::AddItem(CString sName, const double& fValue)
{
	CString sValue;
	sValue.Format("%.8f", fValue);

	return AddItem(sName, sValue);
}

void CXmlItem::SetValue(LPCTSTR szValue)
{
	m_sValue = szValue;
}

void CXmlItem::SetValue(int nValue)
{
	m_sValue.Format("%d", nValue);
}

void CXmlItem::SetValue(const double& fValue)
{
	m_sValue.Format("%.8f", fValue);
}

BOOL CXmlItem::RemoveItem(CXmlItem* pXI)
{
	if (!pXI)
		return FALSE;

	// lookup by name first
	CString sName = pXI->GetName();
	CXmlItem* pXIMatch = GetItem(sName);

	if (!pXIMatch)
		return FALSE;

	// now search the sibling chain looking for exact match
	CXmlItem* pXIPrevSibling = NULL;

	while (pXIMatch != pXI)
	{
		pXIPrevSibling = pXIMatch;
		pXIMatch = pXIMatch->GetSibling();
	}

	if (!pXIMatch) // no match
		return FALSE;

	// else
	ASSERT (pXIMatch == pXI);

	CXmlItem* pNextSibling = pXI->GetSibling();

	if (!pXIPrevSibling) // head of the chain
	{
		if (!pNextSibling)
			m_mapItems.RemoveKey(sName);
		else
			m_mapItems[sName] = pNextSibling;
	}
	else // somewhere else in the chain
	{
		pXIPrevSibling->m_pSibling = pNextSibling; // can be NULL
	}

	// clear item's sibling
	pXI->m_pSibling = NULL;

	return TRUE;
}

BOOL CXmlItem::DeleteItem(CXmlItem* pXI)
{
	if (RemoveItem(pXI))
	{
		delete pXI;
		return TRUE;
	}

	return FALSE;
}

BOOL CXmlItem::AddSibling(CXmlItem* pXI)
{
	ASSERT (pXI);

	if (!pXI)
		return FALSE;

	// must share the same name and parent
	ASSERT (m_sName.CompareNoCase(pXI->GetName()) == 0 && m_pParent == pXI->GetParent());

	if (!(m_sName.CompareNoCase(pXI->GetName()) == 0 && m_pParent == pXI->GetParent()))
		return FALSE;

	if (!m_pSibling)
		m_pSibling = pXI;
	else
		m_pSibling->AddSibling(pXI); // recursive

	return TRUE;
}

POSITION CXmlItem::GetFirstItemPos() const
{
	return m_mapItems.GetStartPosition();
}

const CXmlItem* CXmlItem::GetNextItem(POSITION& pos) const
{
	if (!pos)
		return NULL;

	CString sTemp;
	CXmlItem* pItem = NULL;

	m_mapItems.GetNextAssoc(pos, sTemp, pItem);
	return pItem;
}

CXmlItem* CXmlItem::GetNextItem(POSITION& pos)
{
	if (!pos)
		return NULL;

	CString sTemp;
	CXmlItem* pItem = NULL;

	m_mapItems.GetNextAssoc(pos, sTemp, pItem);
	return pItem;
}

BOOL CXmlItem::NameMatches(const CXmlItem* pXITest) const
{
	if (!pXITest)
		return FALSE;

	return NameMatches(pXITest->GetName());
}

BOOL CXmlItem::NameMatches(LPCTSTR szName) const
{
	return (m_sName.CompareNoCase(szName) == 0);
}

BOOL CXmlItem::ValueMatches(const CXmlItem* pXITest, BOOL bIgnoreCase) const
{
	if (!pXITest)
		return FALSE;

	// else
	return ValueMatches(pXITest->GetValue());
}

BOOL CXmlItem::ValueMatches(LPCTSTR szValue, BOOL bIgnoreCase) const
{
	if (bIgnoreCase)
		return (m_sValue.CompareNoCase(szValue) == 0);

	// else
	return (m_sValue == szValue);
}

BOOL CXmlItem::ItemValueMatches(const CXmlItem* pXITest, CString sItemName, BOOL bIgnoreCase) const
{
	if (sItemName.IsEmpty())
		return FALSE;

	const CXmlItem* pXIItem = GetItem(sItemName);
	const CXmlItem* pXITestItem = pXITest->GetItem(sItemName);

	if (pXIItem && pXITestItem)
		return pXIItem->ValueMatches(pXITestItem, bIgnoreCase);

	// else
	return FALSE;
}

void CXmlItem::SortItems(LPCTSTR szItemName, LPCTSTR szKeyName, BOOL bAscending)
{
	SortItems(szItemName, szKeyName, XISK_STRING, bAscending);
}

void CXmlItem::SortItemsI(LPCTSTR szItemName, LPCTSTR szKeyName, BOOL bAscending)
{
	SortItems(szItemName, szKeyName, XISK_INT, bAscending);
}

void CXmlItem::SortItemsF(LPCTSTR szItemName, LPCTSTR szKeyName, BOOL bAscending)
{
	SortItems(szItemName, szKeyName, XISK_FLOAT, bAscending);
}

void CXmlItem::SortItems(LPCTSTR szItemName, LPCTSTR szKeyName, XI_SORTKEY nKey, BOOL bAscending)
{
	if (!szItemName || !szKeyName)
		return;

	// 1. sort immediate children first
	CXmlItem* pXIItem = GetItem(szItemName);

	if (!pXIItem)
		return;

	// make sure item has key value
	if (!pXIItem->GetItem(szKeyName))
		return;

	// make sure at least one sibling exists
	BOOL bContinue = (pXIItem->GetSibling() != NULL);

	while (bContinue)
	{
		CXmlItem* pXIPrev = NULL;
		CXmlItem* pXISibling = NULL;

		// get this again because we have to anyway 
		// for subsequent loops
		pXIItem = GetItem(szItemName);

		// reset continue flag so that if there are no
		// switches then the sorting is done
		bContinue = FALSE;

		while (pXISibling = pXIItem->GetSibling())
		{
			int nCompare = CompareItems(pXIItem, pXISibling, szKeyName, nKey);

			if (!bAscending)
				nCompare = -nCompare;

			if (nCompare > 0)
			{
				// switch items
				if (pXIPrev)
					pXIPrev->m_pSibling = pXISibling;

				else // we're at the head of the chain
					m_mapItems[szItemName] = pXISibling;

				pXIItem->m_pSibling = pXISibling->m_pSibling;
				pXISibling->m_pSibling = pXIItem;
				pXIPrev = pXISibling;

				bContinue = TRUE; // loop once more
			}
			else
			{
				pXIPrev = pXIItem;
				pXIItem = pXISibling;
			}
		}
	}

	// 2. sort children's children
	pXIItem = GetItem(szItemName);

	while (pXIItem)
	{
		pXIItem->SortItems(szItemName, szKeyName, nKey, bAscending);
		pXIItem = pXIItem->GetSibling();
	}
}

int CXmlItem::CompareItems(const CXmlItem* pXIItem1, const CXmlItem* pXIItem2, 
						   LPCTSTR szKeyName, XI_SORTKEY nKey)
{
	LPCTSTR szValue1 = pXIItem1->GetItemValue(szKeyName);
	LPCTSTR szValue2 = pXIItem2->GetItemValue(szKeyName);

	double dDiff = 0;
	
	switch (nKey)
	{
	case XISK_STRING:
		dDiff = (double)CString(szValue1).CompareNoCase(szValue2);
		break;
		
	case XISK_INT:
		dDiff = (double)(atoi(szValue1) - atoi(szValue2));
		break;
		
	case XISK_FLOAT:
		dDiff = atof(szValue1) - atof(szValue2);
		break;
	}
	
	return (dDiff < 0) ? -1 : ((dDiff > 0) ? 1 : 0);
}

BOOL CXmlItem::IsCDATA() const 
{ 
	return (m_sName == CDATA); 
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CXmlFile::CXmlFile(LPCTSTR szRootItemName) : 
	m_xiRoot(NULL, szRootItemName), m_sHeader("?xml version=\"1.0\" encoding=\"windows-1252\"?")
{
	// get active code page
	CString sCodePage;

	GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_IDEFAULTANSICODEPAGE, sCodePage.GetBuffer(7), 6);
	sCodePage.ReleaseBuffer();

	// and replace in header
	if (atoi(sCodePage) > 0)
		m_sHeader.Replace("1252", sCodePage);
}

CXmlFile::~CXmlFile()
{

}

BOOL CXmlFile::Load(LPCTSTR szFilePath, LPCTSTR szRootItemName, IXmlParse* pCallback)
{
	if (!szFilePath || !strlen(szFilePath))
		return FALSE;

	if (GetFileHandle() != (HANDLE)CFile::hFileNull)
		Close();

	if (Open(szFilePath, XF_READ))
	{
		BOOL bRes = LoadEx(szRootItemName, pCallback);
		Close();

		return bRes;
	}

	return FALSE;
}

BOOL CXmlFile::Save(LPCTSTR szFilePath, int nMaxAttribLen)
{
	if (!szFilePath || !strlen(szFilePath))
		return FALSE;

	if (GetFileHandle() != (HANDLE)CFile::hFileNull)
		Close();

	if (Open(szFilePath, XF_WRITE))
	{
		BOOL bRes = SaveEx(nMaxAttribLen);
		Close();

		return bRes;
	}

	return FALSE;
}

BOOL CXmlFile::Open(LPCTSTR szFilePath, XF_OPEN nOpenFlag)
{
	if (!szFilePath || !strlen(szFilePath))
		return FALSE;

	if (GetFileHandle() != (HANDLE)CFile::hFileNull)
		Close();

	switch (nOpenFlag)
	{
	case XF_READ:
		return CStdioFile::Open(szFilePath, CFile::shareDenyNone | CFile::modeRead | CFile::typeText);

	case XF_WRITE:
		return CStdioFile::Open(szFilePath, CFile::shareExclusive | CFile::modeWrite | CFile::modeCreate | CFile::typeText);

	case XF_READWRITE:
		return CStdioFile::Open(szFilePath, CFile::shareExclusive | CFile::modeReadWrite | 
											CFile::modeCreate | CFile::modeNoTruncate | CFile::typeText);
	}

	return FALSE;
}

BOOL CXmlFile::SaveEx(int nMaxAttribLen)
{
	if (GetFileHandle() == (HANDLE)CFile::hFileNull)
		return FALSE;

	CExportToXml e2xml(nMaxAttribLen);
	CString sXml;
	
	e2xml.Export(&m_xiRoot, 0, 1, sXml);
	
	// add header
	if (!m_sHeader.IsEmpty())
	{
		CString sHeader;
		sHeader.Format("<%s>%s", m_sHeader, ENDL);
		sXml = sHeader + sXml;
	}
	
	try
	{
		Seek(0, CFile::begin); // move to start
		WriteString(sXml);
	}
	catch (...)
	{
		return FALSE;
	}

	return TRUE;
}

BOOL CXmlFile::LoadEx(LPCTSTR szRootItemName, IXmlParse* pCallback)
{
	m_nLoadError = XFL_NONE; // reset

	if (GetFileHandle() == (HANDLE)CFile::hFileNull)
	{
		m_nLoadError = XFL_BADFILE;
		return FALSE;
	}

	DWORD dwTick = GetTickCount();

	// concatenate entire file into one long string
	CString sLine;
	BOOL bInComment = FALSE;
	char* pFileContents = NULL;

	try
	{
		Seek(0, CFile::begin); // move to start

		// preallocate string to avoid excessive memory allocations
		pFileContents = new char[GetLength() + 1];
		ZeroMemory(pFileContents, GetLength() + 1);

		const UINT BUFLEN = 1024 * 10;
		char BUFFER[BUFLEN];
		BOOL bContinue = TRUE;
		char* pFilePtr = pFileContents;

		while (bContinue)
		{
			UINT nRead = Read(BUFFER, BUFLEN);

			if (nRead)
			{
				CopyMemory(pFilePtr, BUFFER, nRead);
				pFilePtr += BUFLEN;
			}

			bContinue = (nRead == BUFLEN);
		}
	}
	catch (...)
	{
		m_nLoadError = XFL_BADFILE;
		return FALSE;
	}
	
	if (!szRootItemName && lstrlen(m_xiRoot.GetName()))
		szRootItemName = m_xiRoot.GetName();

		
	m_pCallback = pCallback;

	LPCTSTR szFile = pFileContents;
	BOOL bRes = ParseRootItem(szRootItemName, szFile);

	// cleanup
	delete [] pFileContents;
	m_pCallback = NULL;

	return bRes;
}

BOOL CXmlFile::ParseRootItem(LPCTSTR szRootItemName, LPCTSTR& szFile)
{
	DWORD dwTick = GetTickCount();

	m_xiRoot.Reset();

	CString sRootItem(szRootItemName);
	sRootItem.TrimLeft();
	sRootItem.TrimRight();

	// find first valid item in file
	while (lstrlen(szFile))
	{
		CString sItem = GetNextItem(szFile);

		// save off the header string
		if (sItem.Find("?xml") == 0)
		{
			m_sHeader = sItem;
			m_sHeader.MakeLower();
			continue;
		}

		// else
		CString sAttributes;
		BOOL bHasEndTag;
		PreProcessItem(sItem, sAttributes, bHasEndTag);

		if (sItem.CompareNoCase(sRootItem) != 0)
		{
			m_nLoadError = XFL_MISSINGROOT;
			return FALSE;
		}

		// else
		if (!ProcessAttributes(m_xiRoot, sAttributes))
			return TRUE; // terminated by the callback

		if (bHasEndTag)
			return TRUE;

		// else
		break;
	}

	// parse rest of file
	ParseItem(m_xiRoot, szFile);

	TRACE ("ParseRootItem took %d ms\n", GetTickCount() - dwTick);

	return TRUE;
}

void CXmlFile::PreProcessItem(CString& sItem, CString& sAttributes, BOOL& bHasEndTag)
{
	// look for end tag
	int nFind = sItem.ReverseFind('/');

	if (nFind == sItem.GetLength() - 1)
	{
		bHasEndTag = TRUE;
		sItem = sItem.Left(nFind);
	}
	else
		bHasEndTag = FALSE;

	// look for attributes
	nFind = sItem.Find(' ');

	if (nFind != -1)
	{
		sAttributes = sItem.Mid(nFind + 1);
		sItem = sItem.Left(nFind);
	}

	sItem.MakeUpper();
}

BOOL CXmlFile::ProcessAttributes(CXmlItem& xi, CString& sAttributes)
{
	sAttributes.TrimLeft();
		
	while (!sAttributes.IsEmpty())
	{
		// look for attribute="value" pairs
		int nFind = sAttributes.Find('=');
		
		if (nFind > 0)
		{
			CString sAttribute = sAttributes.Left(nFind);
			sAttribute.TrimLeft();
			sAttribute.TrimRight();
			
			sAttributes = sAttributes.Mid(nFind + 1);
			
			// opening quote
			char cQuote = 0;
			
			int nSGFind = sAttributes.Find(SINGLE_QUOTE); 
			int nDGFind = sAttributes.Find(DOUBLE_QUOTE); 
			
			if (nSGFind >= 0 && (nSGFind < nDGFind || nDGFind == -1))
			{
				nFind = nSGFind;
				cQuote = SINGLE_QUOTE;
			}
			else if (nDGFind >= 0)
			{
				nFind = nDGFind;
				cQuote = DOUBLE_QUOTE;
			}
			
			if (cQuote)
			{
				sAttributes = sAttributes.Mid(nFind + 1);
				
				nFind = sAttributes.Find(cQuote); // closing quote
				
				if (nFind >= 0)
				{
					CString sValue = sAttributes.Left(nFind);
					sAttributes = sAttributes.Mid(nFind + 1);
					
					// massage text to convert &quot; to " for instance
					XML2TXT(sValue);

					// add attribute to xi
					xi.AddItem(sAttribute, sValue);

					// check continue
					if (!ContinueParsing(sAttribute, sValue))
						return FALSE;
					
					// next pair
					int nFind = sAttributes.Find(' ');
					
					if (nFind >= 0)
						sAttributes = sAttributes.Mid(nFind + 1);
					else
						break;
				}
				else
					break;
			}
			else
				break;
		}
		else
			break;
	}

	// sAttributes returns with whatever was left over
	sAttributes.TrimLeft();

	return TRUE;
}

BOOL CXmlFile::ParseItem(CXmlItem& xi, LPCTSTR& szFile)
{
	CString sThisItem = xi.GetName();
	CString sCloseTag = "/" + sThisItem;

	while (lstrlen(szFile))
	{
		CString sItem = GetNextItem(szFile);

		if (!sThisItem.IsEmpty())
		{
			BOOL bHasEndTag;
			CString sAttributes, sValue;

			int nItemType = GetItemType(sItem);
			PreProcessItem(sItem, sAttributes, bHasEndTag);

			// if sItem is just the close tag then return
			if (sItem.CompareNoCase(sCloseTag) == 0) 
				return TRUE; 

			else if (!bHasEndTag)
			{
				// else add the item and process the tags
				sValue = GetNextValue(szFile, nItemType);

				// massage data provided its not CDATA
				if (nItemType == TYPE_ITEM && sValue.GetLength())
					XML2TXT(sValue);
			}

			CXmlItem* pXI = xi.AddItem(sItem, sValue);

			// check continue
			if (!ContinueParsing(sItem, sValue))
				return FALSE;

			// process attributes
			if (!ProcessAttributes(*pXI, sAttributes))
				return FALSE; // terminated by the callback

			// check for end tag
			if (!bHasEndTag)
			{
				if (!ParseItem(*pXI, szFile))
					return FALSE;
			}
		}
	}

	return TRUE;
}

void CXmlFile::PreProcessCDATA(CString& sItem, CString& sData)
{
}

void CXmlFile::PreProcessComment(CString& sItem, CString& sComment)
{
}

int CXmlFile::GetItemType(const CString& sItem)
{
	int nType = TYPE_LAST;

	while (--nType && nType != TYPE_ITEM)
	{
		if (sItem.Find(TYPENAMES[nType]) == 0)
			return nType;
	}

	return TYPE_ITEM;
}

CString CXmlFile::GetNextItem(LPCTSTR& szFile)
{
	CString sItem;
	char* pNext = strstr(szFile, "<");

	if (pNext)
	{
        // first check for other types immediately following
		int nType = TYPE_LAST;

		while (--nType && nType != TYPE_ITEM)
		{
			if (strstr(pNext, TYPENAMES[nType]) == pNext + 1)
			{
				szFile = pNext + 1 + lstrlen(TYPENAMES[nType]);
				return TYPENAMES[nType];
			}
        }

        // else standard item
		szFile = pNext + 1;

		char* pEnd = strstr(szFile, ">");

		if (pEnd)
		{
			sItem = CString(szFile, pEnd - szFile);
			szFile = pEnd + 1;
		}
		else 
			szFile += lstrlen(szFile); // end of the line
	}

	sItem.TrimLeft();
	sItem.TrimRight();

	return sItem;
}

CString CXmlFile::GetNextValue(LPCTSTR& szFile, int nItemType)
{
    CString sValue;
	LPCTSTR szDelim = VALUEDELIMS[nItemType];
	
	char* pDelim = strstr(szFile, szDelim);

	if (pDelim)
	{
		sValue = CString(szFile, pDelim - szFile);

		szFile = pDelim;

		if (nItemType != TYPE_ITEM)
			szFile += lstrlen(szDelim);
	}
	else // reached the end of the line
	{
        if (nItemType == TYPE_ITEM)
		    sValue = szFile;

		szFile += lstrlen(szFile);
	}

//	sValue.TrimLeft();
//	sValue.TrimRight();

	return sValue;
}

///////////////////////////////////////////////////////////

CString& CXmlFile::CExportToXml::Export(const CXmlItem* pItem, int nDepth, int nPos, CString& sOutput) const
{
	BOOL bCDATA = pItem->IsCDATA(); // affect processing

	// process children first so attributes can be included in opening tag
	CString sChildXml, sChildAttrib;

	if (pItem->GetItemCount())
	{
		// CDATA can't have children by definition so test here
		ASSERT (!bCDATA);

		POSITION pos = pItem->GetFirstItemPos();
		int nItem = 1;

		while (pos)
		{
			const CXmlItem* pXI = pItem->GetNextItem(pos);
			ASSERT (pXI);
			
			if (pXI->IsAttribute(m_nMaxAttribLen))
			{
				sChildAttrib += ' ';
				sChildAttrib += ExportAsAttribute(pXI);
			}
			else
			{
				CString sTemp;
				sChildXml += Export(pXI, nDepth + 1, nItem++, sTemp);
			}
		}
	}

	CString sDepth(' ', nDepth * 4);

	// format our name and value
	CString sName(pItem->GetName());
	CString sValue(pItem->GetValue());

	// handle CDATA specially
	if (bCDATA)
		sOutput.Format("%s<%s%s%s", sDepth, sName, sValue, CDATAEND, ENDL);
	else
	{
		if (sChildXml.IsEmpty()) // means all children are attributes
		{
			// clean text of '<', '>', '&'
			TXT2XML(sValue); 

			if (sValue.IsEmpty())
				sOutput.Format("%s<%s%s/>%s", sDepth, sName, sChildAttrib, ENDL);
			else
			{
				sOutput.Format("%s<%s%s>%s</%s>%s", 
								sDepth, 
								sName, 
								sChildAttrib, 
								sValue, 
								sName, 
								ENDL);
			}
		}	
		else
		{
			sOutput.Format("%s<%s%s>%s%s%s%s</%s>%s", 
							sDepth, 
							sName, 
							sChildAttrib, 
							sValue, 
							ENDL, 
							sChildXml, 
							sDepth, 
							sName, 
							ENDL);
		}
	}

	// add siblings
	if (pItem->GetSibling())
	{
		CString sTemp;
		sOutput += Export(pItem->GetSibling(), nDepth, nPos + 1, sTemp);
	}

	return sOutput;
}

CString CXmlFile::CExportToXml::ExportAsAttribute(const CXmlItem* pItem) const
{
	if (pItem->IsAttribute(m_nMaxAttribLen))
	{
		CString sValue(pItem->GetValue());
		TXT2XML(sValue); 

		CString sAttrib;
		sAttrib.Format("%s=\"%s\"", pItem->GetName(), sValue);
		return sAttrib;
	}

	ASSERT (0);
	return "";
}

void CXmlFile::Trace() const 
{ 
#ifdef _DEBUG
	CExportToXml e2xml(TRUE);
	CString sXml;
	
	e2xml.Export(&m_xiRoot, 0, 1, sXml);

	// because the string might be long, output it in chunks of 255 chars
	int nPos = 0;

	while (nPos < sXml.GetLength())
	{
		OutputDebugString(sXml.Mid(nPos, 255));
		nPos += 255;
	}

#endif
}

