// MergeToDoList.cpp: implementation of the CMergeToDoList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MergeToDoList.h"
#include "tdlschemadef.h"

#include "..\shared\xmlfileex.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMergeToDoList::CMergeToDoList(TDL_MERGEBY nBy, TDL_MERGEHOW nHow) 
	: m_pXIDestRoot(NULL), m_nMergeBy(nBy), m_nMergeHow(nHow), m_dwNextID(0)
{
}

CMergeToDoList::~CMergeToDoList()
{

}

int CMergeToDoList::Merge(LPCTSTR szSrcPath, LPCTSTR szDestPath)
{
	CXmlFileEx fileSrc;

	if (fileSrc.Load(szSrcPath, TDL_ROOT))
		return Merge(fileSrc.Root(), szDestPath);

	return 0;
}

int CMergeToDoList::Merge(const CXmlItem* pXISrc, CXmlItem* pXIDest)
{
	// all the external methods end up here
	m_pXIDestRoot = pXIDest;
	m_dwNextID = pXIDest->GetItemValueI(TDL_NEXTUNIQUEID);

	int nRes = MergeTasks(pXISrc, pXIDest);

	m_pXIDestRoot = NULL;

	return nRes;
}

int CMergeToDoList::Merge(const CXmlItem* pXISrc, LPCTSTR szDestPath)
{
	CXmlFileEx fileDest;

	if (fileDest.Load(szDestPath, TDL_ROOT))
		return Merge(pXISrc, fileDest.Root());

	return 0;
}

int CMergeToDoList::Merge(LPCTSTR szSrcPath, CXmlItem* pXIDest)
{
	CXmlFileEx fileSrc;

	if (fileSrc.Load(szSrcPath, TDL_ROOT))
		return Merge(fileSrc.Root(), pXIDest);

	return 0;
}

int CMergeToDoList::MergeTasks(const CXmlItem* pXISrc, CXmlItem* pXIDest)
{
	// simple checks first
	if (!pXISrc || !pXIDest)
		return 0;

	ASSERT (!(m_nMergeBy == TDLM_BYTITLE && m_dwNextID == 0));
	ASSERT (!(m_nMergeHow == TDLM_DUP && m_dwNextID == 0));

	if ((m_nMergeBy == TDLM_BYTITLE && m_dwNextID == 0) ||
		(m_nMergeHow == TDLM_DUP && m_dwNextID == 0))
		return 0;

	switch (m_nMergeBy)
	{
	case TDLM_BYID:
		return MergeTasksByID(pXISrc, pXIDest);

	case TDLM_BYTITLE:
		return MergeTasksByTitle(pXISrc, pXIDest);
	}

	// else
	return 0;
}

int CMergeToDoList::MergeTasksByID(const CXmlItem* pXISrc, CXmlItem* pXIDest)
{
	// task ID must be same for both
	DWORD dwSrcID = pXISrc->GetItemValueI(TDL_TASKID);
	DWORD dwDestID = pXIDest->GetItemValueI(TDL_TASKID);
	
	if (dwSrcID != dwDestID)
		return 0;
	
	// if the item is a task (could be the root) merge task attributes
	int nMerged = 0;
	
	if (dwSrcID)
	{
		// keep track of max ID
		m_dwNextID = max(m_dwNextID, dwSrcID);

		if (MergeAttributes(pXISrc, pXIDest))			
			nMerged++;
	}
	
	// now merge child items.
	// need only merge first child since it will handle its siblings
	const CXmlItem* pXISrcChild = pXISrc->GetItem(TDL_TASK);
	
	if (pXISrcChild)
	{
		DWORD dwID = pXISrcChild->GetItemValueI(TDL_TASKID);
		
		// look up this item in the dest by ID
		CXmlItem* pXIDestExist = FindDestTask(dwID);
		CXmlItem* pXIDestChild = NULL;
		
		// if no such item exists or user want to duplicate existing items
		// then create new child and initialize
		if (!pXIDestExist || m_nMergeHow == TDLM_DUP)
		{
			pXIDestChild = pXIDest->AddItem(TDL_TASK);
			pXIDestChild->AddItem(TDL_TASKID, (int)dwID);
		}
		// else if the dest items parent is not pXIDest and the user wants to
		// move existing items then first move the item before merging
		else if (pXIDestExist->GetParent() != pXIDest && m_nMergeHow == TDLM_MOVE)
		{
			CXmlItem* pXIDestParent = pXIDestExist->GetParent();
			
			if (pXIDestParent->RemoveItem(pXIDestExist))
			{
				pXIDestChild = pXIDest->AddItem(*pXIDestExist);
				delete pXIDestExist;
			}
		}
		else // just merge as they are
			pXIDestChild = pXIDestExist;
		
		nMerged += MergeTasksByID(pXISrcChild, pXIDestChild);
	}
	
	// then merge next sibling similarly (if we are a task)
	if (dwSrcID)
	{
		const CXmlItem* pXISrcNext = pXISrc->GetSibling();
		
		if (pXISrcNext)
		{
			DWORD dwID = pXISrcNext->GetItemValueI(TDL_TASKID);
			
			// look up this item in the dest by ID
			CXmlItem* pXIDestExist = FindDestTask(dwID);
			CXmlItem* pXIDestNext = NULL;
			
			// if no such item exists or user want to duplicate existing items
			// then simply add child to dest
			if (!pXIDestExist || m_nMergeHow == TDLM_DUP)
			{
				pXIDestNext = pXIDest->GetParent()->AddItem(TDL_TASK);
				pXIDestNext->AddItem(TDL_TASKID, (int)dwID);
			}
			// else if the dest items parent is not pXIDest and the user wants to
			// move existing items then first move the item before merging
			else if (pXIDestExist->GetParent() != pXIDest->GetParent() && m_nMergeHow == TDLM_MOVE)
			{
				CXmlItem* pXIDestParent = pXIDestExist->GetParent();
				
				if (pXIDestParent->RemoveItem(pXIDestExist))
				{
					pXIDestNext = pXIDest->GetParent()->AddItem(*pXIDestExist);
					delete pXIDestExist;
				}
			}
			else // just merge as they are
				pXIDestNext = pXIDestExist;
			
			nMerged += MergeTasksByID(pXISrcNext, pXIDestNext);
		}
	}
	
	return nMerged;
}

int CMergeToDoList::MergeTasksByTitle(const CXmlItem* pXISrc, CXmlItem* pXIDest)
{
	// merge our attributes first
	int nMerged = 0;
	
	// if both these items are root items (have no parents) then we just
	// merge their children else if the task name does not match then we don't merge
	if (pXISrc->GetParent())
	{
		ASSERT (pXISrc->NameMatches(TDL_TASK));
		ASSERT (pXISrc->NameMatches(pXIDest));
		ASSERT (pXIDest->GetParent());
		ASSERT (pXISrc->ItemValueMatches(pXIDest, TDL_TASKTITLE));

		if (!pXISrc->ItemValueMatches(pXIDest, TDL_TASKTITLE))
			return 0;
	}
	else
		ASSERT (!pXIDest->GetParent());

	TRACE ("CToDoCtrl::Merge(src = %s, dst = %s)\n", 
			pXISrc->GetItemValue(TDL_TASKTITLE), 
			pXIDest->GetItemValue(TDL_TASKTITLE));

	if (MergeAttributes(pXISrc, pXIDest))
		nMerged++;

	// merge children
	// essentially we simply add whatever tasks exist in pXISrc 
	// which do not exist in pXIDest and merge duplicates
	const CXmlItem* pXISrcChild = pXISrc->GetItem(TDL_TASK);

	while (pXISrcChild)
	{
		// cycle pXIDest children looking for a match
		CXmlItem* pXIDestChild = pXIDest->GetItem(TDL_TASK);

		while (pXIDestChild)
		{
			if (pXIDestChild->ItemValueMatches(pXISrcChild, TDL_TASKTITLE))
				break;

			// next child
			pXIDestChild = pXIDestChild->GetSibling();
		}
			
		// if no match found then create new placeholder
		if (!pXIDestChild)
		{
			TRACE ("CToDoCtrl::Merge(adding %s to %s)\n", 
					pXISrc->GetItemValue(TDL_TASKTITLE), 
					pXIDest->GetItemValue(TDL_TASKTITLE));

			pXIDestChild = pXIDest->AddItem(TDL_TASK);
			pXIDestChild->AddItem(TDL_TASKTITLE, pXISrcChild->GetItemValue(TDL_TASKTITLE));
			pXIDestChild->AddItem(TDL_TASKID, (int)m_dwNextID++);
		}

		// finally merge the child items
		nMerged += MergeTasksByTitle(pXISrcChild, pXIDestChild);

		// then do next source child
		pXISrcChild = pXISrcChild->GetSibling();
	}

	return nMerged;
}
BOOL CMergeToDoList::MergeAttributes(const CXmlItem* pXISrc, CXmlItem* pXIDest)
{
	BOOL bChange = FALSE;
	POSITION pos = pXISrc->GetFirstItemPos();

	while (pos)
	{
		const CXmlItem* pXISrcAttrib = pXISrc->GetNextItem(pos);

		// don't merge task ID or subtasks
		if (pXISrcAttrib->NameMatches(TDL_TASK) ||
			pXISrcAttrib->NameMatches(TDL_TASKID))
			continue;

		// does it already exist?
		LPCTSTR szAttrib = pXISrcAttrib->GetName();
		CXmlItem* pXIDestAttrib = pXIDest->GetItem(szAttrib);

		// if not then add it
		if (!pXIDestAttrib)
		{
			pXIDest->AddItem(szAttrib, pXISrcAttrib->GetValue());
			bChange = TRUE;
		}
		// else update it
		else if (!pXIDestAttrib->ValueMatches(pXISrcAttrib))
		{
			pXIDestAttrib->SetValue(pXISrcAttrib->GetValue());
			bChange = TRUE;
		}
	}

	return bChange;
}

CXmlItem* CMergeToDoList::FindDestTask(DWORD dwID) const
{
	if (!dwID)
		return NULL;

	CString sID;
	sID.Format("%d", dwID);

	return m_pXIDestRoot->FindItem(TDL_TASKID, sID);
}
