// TaskFileHtmlExporter.cpp: implementation of the CTaskListHtmlExporter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "todolist.h"
#include "TasklistHtmlExporter.h"
#include "tdlschemadef.h"

#include "..\shared\xmlfile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const LPCTSTR ENDL = "\n";

CTaskListHtmlExporter::CTaskListHtmlExporter()
{
}

CTaskListHtmlExporter::~CTaskListHtmlExporter()
{

}

bool CTaskListHtmlExporter::Export(const ITaskList* pSrcTaskFile, const char* szDestFilePath)
{
	// what follows is definitely a hack!
	// but that's the joy of programming :)
	FONTNAME = AfxGetApp()->GetProfileString("Preferences", "HTMLFont", "Verdana");
	HTMLFONTSIZE = AfxGetApp()->GetProfileInt("Preferences", "HtmlFontSize", 3);
	HTMLNOTES = AfxGetApp()->GetProfileInt("Preferences", "ExportSpaceForNotes", FALSE) ? 
										"<pre>\n\n\n\n\n\n\n\n</pre>" : "";
	STRIKETHRUDONE = AfxGetApp()->GetProfileInt("Preferences", "StrikethroughDone", TRUE);
	ROUNDTIMEFRACTIONS = AfxGetApp()->GetProfileInt("Preferences", "RoundTimeFractions", FALSE);

	CStdioFile fileOut;

	if (fileOut.Open(szDestFilePath, CFile::modeCreate | CFile::modeWrite))
	{
		CString sOutput;

		if (!ExportTask(pSrcTaskFile, NULL, 0, 0, sOutput).IsEmpty())
		{
			fileOut.WriteString("<html>\n<head></head>\n<body>\n");
			fileOut.WriteString(sOutput);
			fileOut.WriteString("</body>\n</html>\n");
			return true;
		}
	}

	return false;
}

CString& CTaskListHtmlExporter::ExportTask(const ITaskList* pTasks, HTASKITEM hTask, int nDepth, int nPos, CString& sOutput) const
{
	// if depth == 0 then we're at the root so just add sub-tasks
	// else insert pItem first
	if (nDepth > 0)
	{
		// if there is a POS child item then this replaces nPos
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKPOS))
			nPos = pTasks->GetTaskPosition(hTask);

		CString sTitle, sID, sItem, sPriority, sStartDate, sDueDate, sDoneDate;
		CString sAllocTo, sAllocBy, sCategory, sStatus, sColor("#000000");
		CString sComments, sPercent, sTimeEst, sTimeSpent, sFileRef;
		char cTemp;

		// ID
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKID))
			sID.Format("(ID: %d) ", pTasks->GetTaskID(hTask));

		// title
		if (nDepth == 1) // toplevel == bold
			sTitle.Format("<b>%s</b>", pTasks->GetTaskTitle(hTask));
		else
			sTitle = pTasks->GetTaskTitle(hTask);

		// priority, start/due/done dates
		int nPercent = pTasks->GetTaskPercentDone(hTask, TRUE);
		BOOL bDone = pTasks->IsTaskDone(hTask) || (nPercent == 100);
		BOOL bRound = TRUE;

		// format color string
		if (bDone)
			sColor = "#c4c4c4";
		else
			sColor = pTasks->GetTaskWebColor(hTask);

		if (bDone && pTasks->TaskHasAttribute(hTask, TDL_TASKDONEDATESTRING))
			sDoneDate.Format(" (completed: %s)", pTasks->GetTaskDoneDateString(hTask));
		else
		{
			if (pTasks->TaskHasAttribute(hTask, TDL_TASKHIGHESTPRIORITY))
				sPriority.Format("[%d] ", pTasks->GetTaskPriority(hTask, TRUE));

			else if (pTasks->TaskHasAttribute(hTask, TDL_TASKPRIORITY))
				sPriority.Format("[%d] ", pTasks->GetTaskPriority(hTask, FALSE));

			if (pTasks->TaskHasAttribute(hTask, TDL_TASKSTARTDATESTRING))
				sStartDate.Format(" (start: %s)", pTasks->GetTaskStartDateString(hTask));

			if (pTasks->TaskHasAttribute(hTask, TDL_TASKDUEDATESTRING))
				sDueDate.Format(" (due: %s)", pTasks->GetTaskDueDateString(hTask));

			int nTimePlaces = ROUNDTIMEFRACTIONS ? 0 : 2;

			if (pTasks->TaskHasAttribute(hTask, TDL_TASKTIMEESTIMATE))
				sTimeEst.Format(" (time est: %.*f hrs)", nTimePlaces, pTasks->GetTaskTimeEstimate(hTask, cTemp, TRUE));

			if (pTasks->TaskHasAttribute(hTask, TDL_TASKTIMESPENT))
				sTimeEst.Format(" (time spent: %.*f hrs)", nTimePlaces, pTasks->GetTaskTimeSpent(hTask, cTemp, TRUE));
		}

		if (pTasks->TaskHasAttribute(hTask, TDL_TASKPERCENTDONE))
			sPercent.Format(" (%d%%) ", nPercent);

		// allocated to
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKALLOCTO))
			sAllocTo.Format(" (allocated to: %s)", pTasks->GetTaskAllocatedTo(hTask));
		
		// allocated by
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKALLOCBY))
			sAllocBy.Format(" (allocated by: %s)", pTasks->GetTaskAllocatedBy(hTask));
		
		// category
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKCATEGORY))
			sCategory.Format(" (category: %s)", pTasks->GetTaskCategory(hTask));
		
		// status
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKSTATUS))
			sStatus.Format(" (status: %s)", pTasks->GetTaskStatus(hTask));
		
		// fileref
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKFILEREFPATH))
		{
			CString sFilePath = pTasks->GetTaskFileReferencePath(hTask);
			sFileRef.Format("<br>(file ref: <a href=\"%s\">%s</a>)", sFilePath, sFilePath);
		}
		
		// comments
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKCOMMENTS))
		{
			CString sItemComments = pTasks->GetTaskComments(hTask);
			TXT2XML(sItemComments); // TODO

			sComments.Format(bDone ? "<br><font color='#c4c4c4'>[%s] </font>" : "<br><font color='#606060'>[%s] </font>", 
							sItemComments);

			// replace carriage returns with <br>
			sComments.Replace(ENDL, "<br>");
			sComments.Replace("\n", "<br>");

			// replace tab characters with multiple &nbsp;
			sComments.Replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;");
		}

		CString sFormat;
		
		if (bDone)
		{
			if (STRIKETHRUDONE)
				sFormat = "%s%s%s<font color='%s'><s>%s%s%s%s%s%s%s%s</s></font>%s<s>%s</s>%s";
			else
				sFormat = "%s%s%s<font color='%s'>%s%s%s%s%s%s%s%s</font>%s%s%s";
		}
		else if (bDone)
			sFormat = "%s%s%s<font color='%s'>%s%s%s%s%s%s%s%s</font>%s%s%s";
		else
			sFormat = "%s%s%s<font color='%s'>%s</font>%s%s%s%s%s%s%s%s%s%s";

		sItem.Format(sFormat, sID, sPriority, sPercent, sColor, 
					sTitle, sAllocTo, sAllocBy, sCategory, sStatus, 
					sStartDate, sDueDate, sTimeEst, sDoneDate, sComments, sFileRef);

		// notes section
		if (!bDone)
			sItem += HTMLNOTES;

		if (nDepth == 1) // toplevel
			sOutput += "<br>";

		sOutput += "<li>";
		sOutput += sItem;
	}
	else
	{
		if (!FONTNAME.IsEmpty())
			sOutput.Format("<font face='%s' size='%d' >", FONTNAME, HTMLFONTSIZE);

		// project name
		CString sProjectName = pTasks->GetProjectName();

		if (!sProjectName.IsEmpty())
		{
			CString sProjTitle;
			sProjTitle.Format("<h2>%s</h2>", sProjectName);
			sOutput += sProjTitle;
		}
	}

	// begin new ordered list for sub-tasks
	hTask = pTasks->GetFirstTask(hTask);

	if (hTask) // at least one sub-task
	{
		sOutput += ENDL;
		sOutput += "<ol>";
		sOutput += ENDL;

		int nChildPos = 1;

		while (hTask)
		{
			CString sTask;
			sOutput += ENDL;
			sOutput += ExportTask(pTasks, hTask, nDepth + 1, nChildPos++, sTask);

			hTask = pTasks->GetNextTask(hTask);
		}

		// end ordered list
		sOutput += "</ol>";
		sOutput += ENDL;
	}

	// end of item
	if (nDepth > 0)
	{
		sOutput += "</li>";
		sOutput += ENDL;
	}
	else if (!FONTNAME.IsEmpty())
		sOutput += "</font>";

	return sOutput;
}

