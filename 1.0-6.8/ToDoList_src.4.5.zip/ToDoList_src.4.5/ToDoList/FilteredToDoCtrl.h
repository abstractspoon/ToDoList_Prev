// FilteredToDoCtrl.h: interface for the CFilteredToDoCtrl class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILTEREDTODOCTRL_H__356A6EB9_C7EC_4395_8716_623AFF4A269B__INCLUDED_)
#define AFX_FILTEREDTODOCTRL_H__356A6EB9_C7EC_4395_8716_623AFF4A269B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ToDoCtrl.h"

enum FILTER_TYPE
{
	FT_ALL,
	FT_NOTDONE,
	FT_DONE, 
	FT_DUETODAY,
	FT_DUETOMORROW,
	FT_DUEENDTHISWEEK, 
	FT_DUEENDNEXTWEEK, 
	FT_DUEENDTHISMONTH,
	FT_DUEENDNEXTMONTH,
	FT_DUEENDTHISYEAR,
	FT_DUEENDNEXTYEAR,
};

struct FTDCFILTER
{
	FTDCFILTER(FILTER_TYPE filter = FT_ALL, LPCTSTR szCategory = NULL, 
				LPCTSTR szAllocTo = NULL, int priority = -1) : 
				nFilter(filter), sCategory(szCategory), 
				sAllocTo(szAllocTo), nPriority(priority) {}

	BOOL operator==(const FTDCFILTER& filter) const
	{
		return (filter.nFilter == nFilter && filter.nPriority == nPriority &&
				filter.sCategory == sCategory && filter.sAllocTo == sAllocTo);
	}
	BOOL operator!=(const FTDCFILTER& filter) const
	{
		return !(*this == filter);
	}
	
	FILTER_TYPE nFilter;
	int nPriority;
	CString sCategory;
	CString sAllocTo;
};

enum FTMATCHRESULT
{
	FTDC_MATCH,
	FTDC_NOMATCHSTATE,
	FTDC_NOMATCHCATEGORY,
	FTDC_NOMATCHALLOCTO,
	FTDC_NOMATCHPRIORITY,
};

class CFilteredToDoCtrl : public CToDoCtrl  
{
public:
	CFilteredToDoCtrl(CContentMgr& mgr, int nDefaultContent = 0);
	virtual ~CFilteredToDoCtrl();

	void SetFilter(const FTDCFILTER& filter);
	FILTER_TYPE GetFilter(FTDCFILTER& filter) const;
	void RefreshFilter();
	void ClearFilter();
	BOOL HasFilter() const { return HasFilter(m_filter); }

	UINT GetTaskCount(UINT* pVisible = 0) const;

protected:
	CTaskFile m_tasksHidden;
	FTDCFILTER m_filter;
	COleDateTime m_dateDue;
	UINT m_nHiddenCount;
	
protected:
	virtual int GetAllTasks(CTaskFile& tasks) const;
	virtual HTREEITEM SetAllTasks(const CTaskFile& tasks);

	void FilterTasks(CTaskFile& tasksHide, HTASKITEM htHide, CTaskFile& tasksShow, HTASKITEM htShow);
	FTMATCHRESULT MatchFilter(const CTaskFile& tasks, HTASKITEM ht) const;
	BOOL MatchCategory(const CTaskFile& tasks, HTASKITEM ht) const;
	BOOL MatchAllocTo(const CTaskFile& tasks, HTASKITEM ht) const;
	BOOL MatchPriority(const CTaskFile& tasks, HTASKITEM ht) const;
	BOOL MatchDueDate(const CTaskFile& tasks, HTASKITEM ht) const;
	void InitDueDate();

	BOOL IsTaskDone(const CTaskFile& tasks, HTASKITEM ht, BOOL bCheckParents = TRUE) const; // checks parents
	static BOOL HasFilter(const FTDCFILTER& filter);
};

#endif // !defined(AFX_FILTEREDTODOCTRL_H__356A6EB9_C7EC_4395_8716_623AFF4A269B__INCLUDED_)
