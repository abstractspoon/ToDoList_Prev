// ToDoCtrlData.cpp: implementation of the CToDoCtrlData class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ToDoCtrl.h"
#include "ToDoCtrlData.h"

#include "..\shared\xmlfile.h"
#include "..\shared\timeedit.h"

#include <float.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////

TODOITEM::TODOITEM(LPCTSTR szTitle, LPCTSTR szComments) :
	sTitle(szTitle), 
	sComments(szComments),
	color(0), 
	nPriority(5),
	nPercentDone(0),
	dTimeEstimate(0),
	dTimeSpent(0),
	nTimeEstUnits(TDCTU_HOURS),
	nTimeSpentUnits(TDCTU_HOURS),
	bFlagged(FALSE),
	dateCreated(COleDateTime::GetCurrentTime()),
	nCalcPriority(-1),
	nCalcPercent(-1),
	dCalcTimeEstimate(-1),
	dCalcTimeSpent(-1),
	dateEarliestDue(-1.0),
	bGoodAsDone(-1),
	bDue(-1)
{ 
	SetModified();
}

TODOITEM::TODOITEM() :
	color(0), 
	nPriority(5),
	nPercentDone(0),
	dTimeEstimate(0),
	dTimeSpent(0),
	nTimeEstUnits(TDCTU_HOURS),
	nTimeSpentUnits(TDCTU_HOURS),
	bFlagged(FALSE),
	dateCreated(COleDateTime::GetCurrentTime()),
	nCalcPriority(-1),
	nCalcPercent(-1),
	dCalcTimeEstimate(-1),
	dCalcTimeSpent(-1),
	dateEarliestDue(-1.0),
	bGoodAsDone(-1),
	bDue(-1)
{ 
	SetModified();
}

TODOITEM::TODOITEM(const TODOITEM& tdi) :
	sTitle(tdi.sTitle),
	sComments(tdi.sComments),
	color(tdi.color), 
	sFileRefPath(tdi.sFileRefPath),
	sAllocTo(tdi.sAllocTo),
	sAllocBy(tdi.sAllocBy),
	sCategory(tdi.sCategory),
	sStatus(tdi.sStatus),
	nPriority(tdi.nPriority),
	nPercentDone(tdi.nPercentDone),
	dTimeEstimate(tdi.dTimeEstimate),
	dTimeSpent(tdi.dTimeSpent),
	nTimeEstUnits(tdi.nTimeEstUnits),
	nTimeSpentUnits(tdi.nTimeSpentUnits),
	dateStart(tdi.dateStart),
	dateDue(tdi.dateDue),
	dateDone(tdi.dateDone),
	dateCreated(tdi.dateCreated),
	bFlagged(tdi.bFlagged),
	sCreatedBy(tdi.sCreatedBy),
	nCalcPriority(-1),
	nCalcPercent(-1),
	dCalcTimeEstimate(-1),
	dCalcTimeSpent(-1),
	dateEarliestDue(-1.0),
	bGoodAsDone(-1),
	bDue(-1)
{ 
    if (dateCreated.m_dt == 0.0)
		dateCreated = COleDateTime::GetCurrentTime();

	SetModified();
}

BOOL TODOITEM::HasCreation() const 
{ 
	return (dateCreated.m_dt > 0) ? TRUE : FALSE; 
}

BOOL TODOITEM::HasStart() const 
{ 
	return (dateStart.m_dt > 0) ? TRUE : FALSE; 
}

BOOL TODOITEM::HasDue() const 
{ 
	return (dateDue.m_dt > 0) ? TRUE : FALSE; 
}

BOOL TODOITEM::IsDone() const 
{ 
	return (dateDone.m_dt > 0) ? TRUE : FALSE; 
}

void TODOITEM::ClearStart() 
{ 
	dateStart.m_dt = 0; 
}

void TODOITEM::ClearDue() 
{ 
	dateDue.m_dt = 0; 
}

void TODOITEM::ClearDone() 
{ 
	dateDone.m_dt = 0; 
}

BOOL TODOITEM::IsDue() const
{ 
	return IsDue(COleDateTime::GetCurrentTime());
}

BOOL TODOITEM::IsDue(const COleDateTime& dateDueBy) const
{ 
	if (IsDone() || !HasDue())
		return FALSE;
	
	return ((double)(int)dateDue.m_dt <= (double)(int)dateDueBy.m_dt); 
}

void TODOITEM::SetModified() 
{ 
	tLastMod = COleDateTime::GetCurrentTime(); 
}

void TODOITEM::ResetCalcs() 
{
	nCalcPriority = nCalcPercent = -1;
	dCalcTimeEstimate = dCalcTimeSpent = -1;
	dateEarliestDue.m_dt = -1;
	bGoodAsDone = bDue = -1;
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const int MAX_TDPRIORITY = 10;
const int MIN_TDPRIORITY = 0;

CToDoCtrlData::CToDoCtrlData(CTreeCtrl& tree, const CWordArray& aStyles) : 
m_tree(tree), m_aStyles(aStyles)
{
	
}

CToDoCtrlData::~CToDoCtrlData()
{
	DeleteAllTasks();
}

TODOITEM* CToDoCtrlData::NewTask(const TODOITEM* pTDIRef)
{
	if (pTDIRef)
		return new TODOITEM(*pTDIRef);
	else
		return new TODOITEM;
}

TODOITEM* CToDoCtrlData::GetTask(DWORD dwID) const
{
	TODOITEM* pTDI;
	
	return (dwID && m_mapTDItems.Lookup(dwID, pTDI)) ? pTDI : NULL;
}

TODOITEM* CToDoCtrlData::GetTask(HTREEITEM hti) const
{
	return GetTask(GetTaskID(hti));
}

void CToDoCtrlData::AddTask(DWORD dwID, TODOITEM* pTDI) 
{ 
	if (dwID && pTDI)
	{
		// must delete duplicates else we'll get a memory leak
		TODOITEM* pExist = GetTask(dwID);
		
		if (pExist)
		{
			m_mapTDItems.RemoveKey(dwID);
			delete pExist;
		}
	}
	
	m_mapTDItems.SetAt(dwID, pTDI); 
}

void CToDoCtrlData::DeleteTask(DWORD dwID)
{
	ASSERT (dwID && GetTask(dwID));
	
	delete GetTask(dwID);
	m_mapTDItems.RemoveKey(dwID);
}

void CToDoCtrlData::DeleteAllTasks(BOOL bIncTree)
{
	POSITION pos = m_mapTDItems.GetStartPosition();
	TODOITEM* pTDI;
	DWORD dwID;
	
	while (pos)
	{
		m_mapTDItems.GetNextAssoc(pos, dwID, pTDI);
		delete pTDI;
	}
	
	m_mapTDItems.RemoveAll();
	
	if (bIncTree && m_tree.GetSafeHwnd()) 
	{
		m_tree.SelectItem(NULL);
		m_tree.DeleteAllItems(); 
	}
}

int CToDoCtrlData::FindTasks(const SEARCHPARAMS& params, CResultArray& aResults) const
{
	if (!GetTaskCount())
		return 0;
	
	HTREEITEM hti = m_tree.GetChildItem(NULL);
	
	while (hti)
	{
		FindTasks(hti, params, aResults);
		hti = m_tree.GetNextItem(hti, TVGN_NEXT);
	}
	
	// else
	return aResults.GetSize();
}

int CToDoCtrlData::FindTasks(HTREEITEM hti, const SEARCHPARAMS& params, CResultArray& aResults) const
{
	SEARCHRESULT result;
	
	if (TaskMatches(hti, params, result))
		aResults.Add(result);
	
	// also check children and their children recursively
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	
	while (htiChild)
	{
		FindTasks(htiChild, params, aResults);
		
		// next
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
	
	return aResults.GetSize();
}

DWORD CToDoCtrlData::FindFirstTask(const SEARCHPARAMS& params, SEARCHRESULT& result) const
{
	if (!GetTaskCount())
		return 0;
	
	HTREEITEM hti = m_tree.GetChildItem(NULL);
	DWORD dwTaskID = 0;
	
	while (hti && !dwTaskID)
	{
		dwTaskID = FindFirstTask(hti, params, result);
		hti = m_tree.GetNextItem(hti, TVGN_NEXT);
	}
	
	// else
	return dwTaskID;
}

DWORD CToDoCtrlData::FindFirstTask(HTREEITEM hti, const SEARCHPARAMS& params, SEARCHRESULT& result) const
{
	if (TaskMatches(hti, params, result))
		return result.dwID;
	
	// also check children and their children recursively
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	DWORD dwTaskID = 0;
	
	while (htiChild && !dwTaskID)
	{
		dwTaskID = FindFirstTask(htiChild, params, result);
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
	
	return dwTaskID;
}

BOOL CToDoCtrlData::TaskMatches(HTREEITEM hti, const SEARCHPARAMS& params, SEARCHRESULT& result) const
{
	TODOITEM* pTDI = GetTask(hti);
	
	if (!pTDI)
		return 0;
	
	BOOL bMatch = FALSE;
	DWORD dwID = m_tree.GetItemData(hti);
	
	BOOL bIncDone = (params.dwFlags & FIND_INCLUDEDONE);
	BOOL bIsDone = IsTaskDone(hti, TDCCHECKALL);
	
	switch (params.nFindWhat)
	{
	case FIND_TITLECOMMENTS:
		if (bIncDone || !bIsDone)
			bMatch = (TaskMatches(pTDI->sTitle, params) || TaskMatches(pTDI->sComments, params));
		break;
		
	case FIND_ALLOCTO:
		if (bIncDone || !bIsDone)
		{
			bMatch = TaskMatches(pTDI->sAllocTo, params);
			if (bMatch)
				result.sMatch = pTDI->sAllocTo;
		}
		break;
		
	case FIND_ALLOCBY:
		if (bIncDone || !bIsDone)
		{
			bMatch = TaskMatches(pTDI->sAllocBy, params);
			if (bMatch)
				result.sMatch = pTDI->sAllocBy;
		}
		break;
		
	case FIND_CREATEDBY:
		if (bIncDone || !bIsDone)
		{
			bMatch = TaskMatches(pTDI->sCreatedBy, params);
			if (bMatch)
				result.sMatch = pTDI->sAllocBy;
		}
		break;
		
	case FIND_STATUS:
		if (bIncDone || !bIsDone)
		{
			bMatch = TaskMatches(pTDI->sStatus, params);
			if (bMatch)
				result.sMatch = pTDI->sStatus;
		}
		break;
		
	case FIND_CATEGORY:
		if (bIncDone || !bIsDone)
		{
			bMatch = TaskMatches(pTDI->sCategory, params);
			if (bMatch)
				result.sMatch = pTDI->sCategory;
		}
		break;
		
	case FIND_CREATIONDATE:
		if (pTDI->HasCreation() && (bIncDone || !bIsDone))
		{
			bMatch = TaskMatches(pTDI->dateCreated, params);
			if (bMatch)
				result.dateMatch = pTDI->dateCreated;
		}
		break;
		
	case FIND_STARTDATE:
		if (pTDI->HasStart() && (bIncDone || !bIsDone))
		{
			bMatch = TaskMatches(pTDI->dateStart, params);
			if (bMatch)
				result.dateMatch = pTDI->dateStart;
		}
		break;
		
	case FIND_DUEDATE:
		if (pTDI->HasDue() && (bIncDone || !bIsDone))
		{
			bMatch = TaskMatches(pTDI->dateDue, params);
			if (bMatch)
				result.dateMatch = pTDI->dateDue;
		}
		break;
		
	case FIND_DONEDATE:
		if (pTDI->IsDone())
		{
			bMatch = TaskMatches(pTDI->dateDone, params);
			if (bMatch)
				result.dateMatch = pTDI->dateDone;
		}
		break;
		
	case FIND_PRIORITY:
		if (bIncDone || !bIsDone)
		{
			bMatch = TaskMatches(pTDI->nPriority, params);
			if (bMatch)
				result.nMatch = pTDI->nPriority;
		}
		break;
		
	case FIND_TASKID:
		if (bIncDone || !bIsDone)
		{
			bMatch = TaskMatches((int)dwID, params);
			if (bMatch)
				result.nMatch = (int)dwID;
		}
		break;
		
	case FIND_PERCENTDONE:
		if (bIncDone || !bIsDone)
		{
			bMatch = TaskMatches(pTDI->nPercentDone, params);
			if (bMatch)
				result.nMatch = pTDI->nPercentDone;
		}
		break;
		
	case FIND_TIMEEST:
		if (bIncDone || !bIsDone)
		{
			bMatch = TaskMatches(pTDI->dTimeEstimate, params);
			if (bMatch)
				result.dMatch = pTDI->dTimeEstimate;
		}
		break;
		
	case FIND_TIMESPENT:
		if (bIncDone || !bIsDone)
		{
			bMatch = TaskMatches(pTDI->dTimeSpent, params);
			if (bMatch)
				result.dMatch = pTDI->dTimeSpent;
		}
		break;
		
	case FIND_FLAG:
		if (bIncDone || !bIsDone)
			bMatch = pTDI->bFlagged;
		break;
	}
	
	if (bMatch)
	{
		result.bDone = bIsDone;
		result.dwID = dwID;
		result.hti = hti;
	}
	
	return bMatch;
}

BOOL CToDoCtrlData::TaskMatches(const COleDateTime& date, const SEARCHPARAMS& params)
{
	return (date >= params.dateFrom && date <= params.dateTo);
}

BOOL CToDoCtrlData::TaskMatches(const CString& sText, const SEARCHPARAMS& params)
{
	CStringArray aWords;
	
	if (!ParseSearchString(params.sText, aWords))
		return FALSE;
	
	BOOL bMatchCase = (params.dwFlags & FIND_MATCHCASE);
	BOOL bMatchWholeWord = (params.dwFlags & FIND_MATCHWHOLEWORD);
	
	// cycle all the words
	for (int nWord = 0; nWord < aWords.GetSize(); nWord++)
	{
		CString sWord = aWords.GetAt(nWord);
		
		if (FindWord(sWord, sText, bMatchCase, bMatchWholeWord))
			return TRUE;
	}
	
	return FALSE;
}

BOOL CToDoCtrlData::TaskMatches(const double& dValue, const SEARCHPARAMS& params)
{
	return (dValue >= params.dFrom && dValue <= params.dTo);
}

BOOL CToDoCtrlData::TaskMatches(int nValue, const SEARCHPARAMS& params)
{
	return (nValue >= params.nFrom && nValue <= params.nTo);
}

BOOL CToDoCtrlData::FindWord(LPCTSTR szWord, LPCTSTR szText, BOOL bMatchCase, BOOL bMatchWholeWord)
{
	CString sWord(szWord), sText(szText);
	
	if (sWord.GetLength() > sText.GetLength())
		return FALSE;
	
	sWord.TrimLeft();
	sWord.TrimRight();
	
	if (!bMatchCase)
	{
		sWord.MakeUpper();
		sText.MakeUpper();
	}
	
	int nFind = sText.Find(sWord);
	
	if (nFind == -1)
		return FALSE;
	
	else if (bMatchWholeWord) // test whole word
	{
		const CString DELIMS("()-\\/{}[]:;,. ?\"'");
		
		// prior and next chars must be delimeters
		char cPrevChar = 0, cNextChar = 0;
		
		// prev
		if (nFind == 0) // word starts at start
			cPrevChar = ' '; // known delim
		else
			cPrevChar = sText[nFind - 1];
		
		// next
		if ((nFind + sWord.GetLength() + 1) < sText.GetLength())
			cNextChar = sText[nFind + sWord.GetLength()];
		else
			cNextChar = ' '; // known delim
		
		if (DELIMS.Find(cPrevChar) == -1 || DELIMS.Find(cNextChar) == -1)
			return FALSE;
	}
	
	return TRUE;
}

int CToDoCtrlData::ParseSearchString(LPCTSTR szLookFor, CStringArray& aWords)
{
	aWords.RemoveAll();
	
	// parse on spaces unless enclosed in double-quotes
	int nLen = lstrlen(szLookFor);
	BOOL bInQuotes = FALSE, bAddWord = FALSE;
	CString sWord;
	
	for (int nPos = 0; nPos < nLen; nPos++)
	{
		switch (szLookFor[nPos])
		{
		case ' ': // word break
			if (bInQuotes)
				sWord += szLookFor[nPos];
			else
				bAddWord = TRUE;
			break;
			
		case '\"':
			// whether its the start or end we add the current word
			// and flip bInQuotes
			bInQuotes = !bInQuotes;
			bAddWord = TRUE;
			break;
			
		default: // everything else
			sWord += szLookFor[nPos];
			
			// also if its the last char then add it
			bAddWord = (nPos == nLen - 1);
			break;
		}
		
		if (bAddWord)
		{
			sWord.TrimLeft();
			sWord.TrimRight();
			
			if (!sWord.IsEmpty())
				aWords.Add(sWord);
			
			sWord.Empty(); // next word
		}
	}
	
	return aWords.GetSize();
}

CString CToDoCtrlData::GetTaskTitle(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->sTitle;
	
	return "";
}

CString CToDoCtrlData::GetTaskComments(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->sComments;
	
	return "";
}

CString CToDoCtrlData::GetTaskCustomComments(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->sCustomComments;
	
	return "";
}

double CToDoCtrlData::GetTaskTimeEstimate(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->dTimeEstimate;
	
	return 0;
}

double CToDoCtrlData::GetTaskTimeSpent(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->dTimeSpent;
	
	return 0;
}

double CToDoCtrlData::GetTaskTimeEstimate(DWORD dwID, int& nUnits) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
	{
		nUnits = pTDI->nTimeEstUnits;
		return pTDI->dTimeEstimate;
	}
	
	return 0;
}

double CToDoCtrlData::GetTaskTimeSpent(DWORD dwID, int& nUnits) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
	{
		nUnits = pTDI->nTimeSpentUnits;
		return pTDI->dTimeSpent;
	}
	
	return 0;
}

CString CToDoCtrlData::GetTaskAllocTo(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->sAllocTo;
	
	return "";
}

CString CToDoCtrlData::GetTaskAllocBy(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->sAllocBy;
	
	return "";
}

CString CToDoCtrlData::GetTaskStatus(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->sStatus;
	
	return "";
}

CString CToDoCtrlData::GetTaskCategory(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->sCategory;
	
	return "";
}

CString CToDoCtrlData::GetTaskCreatedBy(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->sCreatedBy;
	
	return "";
}

COLORREF CToDoCtrlData::GetTaskColor(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->color;
	
	return 0;
}

int CToDoCtrlData::GetTaskPriority(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->nPriority;
	
	return 0;
}

BOOL CToDoCtrlData::IsTaskFlagged(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->bFlagged;
	
	return FALSE;
}

COleDateTime CToDoCtrlData::GetTaskDueDate(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->dateDue;
	
	return COleDateTime();
}

COleDateTime CToDoCtrlData::GetTaskStartDate(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->dateStart;
	
	return COleDateTime();
}

COleDateTime CToDoCtrlData::GetTaskCreationDate(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->dateCreated;
	
	return COleDateTime();
}

COleDateTime CToDoCtrlData::GetTaskDoneDate(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->dateDone;
	
	return COleDateTime();
}

BOOL CToDoCtrlData::IsTaskDone(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->IsDone();
	
	return FALSE;
}
/*
BOOL CToDoCtrlData::IsTaskDue(DWORD dwID) const
{
TODOITEM* pTDI = GetTask(dwID);

  if (pTDI)
		return pTDI->IsDue();
		
		  return FALSE;
		  }
*/
int CToDoCtrlData::GetTaskPercent(DWORD dwID, BOOL bCheckIfDone) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
	{
		if (bCheckIfDone)
			return pTDI->IsDone() ? 100 : pTDI->nPercentDone;
		else
			return pTDI->nPercentDone;
	}
	
	return 0;
}

CString CToDoCtrlData::GetTaskFileRef(DWORD dwID) const
{
	TODOITEM* pTDI = GetTask(dwID);
	
	if (pTDI)
		return pTDI->sFileRefPath;
	
	return "";
}

double CToDoCtrlData::GetTaskTimeEstimate(const HTREEITEM hti) const
{
	return GetTaskTimeEstimate(GetTaskID(hti));
}

CString CToDoCtrlData::GetTaskAllocTo(const HTREEITEM hti) const
{
	return GetTaskAllocTo(GetTaskID(hti));
}

CString CToDoCtrlData::GetTaskAllocBy(const HTREEITEM hti) const
{
	return GetTaskAllocBy(GetTaskID(hti));
}

CString CToDoCtrlData::GetTaskStatus(const HTREEITEM hti) const
{
	return GetTaskStatus(GetTaskID(hti));
}

CString CToDoCtrlData::GetTaskCategory(const HTREEITEM hti) const
{
	return GetTaskCategory(GetTaskID(hti));
}

COLORREF CToDoCtrlData::GetTaskColor(const HTREEITEM hti) const
{
	return GetTaskColor(GetTaskID(hti));
}

BOOL CToDoCtrlData::IsTaskFlagged(const HTREEITEM hti) const
{
	return IsTaskFlagged(GetTaskID(hti));
}

int CToDoCtrlData::GetTaskPriority(const HTREEITEM hti) const
{
	return GetTaskPriority(GetTaskID(hti));
}

BOOL CToDoCtrlData::IsParentTaskDone(HTREEITEM hti) const
{
	if (!hti)
		return FALSE;
	
	HTREEITEM htiParent = m_tree.GetParentItem(hti);
	
	if (!htiParent)
		return FALSE;
	
	TODOITEM* tdiParent = GetTask(GetTaskID(htiParent));
	
	if (!tdiParent)
		return FALSE;
	
	if (tdiParent->IsDone())
		return TRUE;
	
	// else check parent's parent
	return IsParentTaskDone(htiParent);
}


int CToDoCtrlData::AreChildTasksDone(HTREEITEM hti) const
{
	if (!m_tree.ItemHasChildren(hti))
		return -1;
	
	// else check children and their children recursively
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	
	while (htiChild)
	{
		int bDone = IsTaskDone(htiChild, TDCCHECKCHILDREN);
		
		if (!bDone)
			return FALSE;
		
		// next
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
	
	return TRUE;
}
/*
BOOL CToDoCtrlData::IsTaskDue(HTREEITEM hti) const
{
return IsTaskDue(GetTaskID(hti));
}
*/
BOOL CToDoCtrlData::DeleteTask(HTREEITEM hti)
{
	// do children first to ensure entire branch is deleted
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	
	while (htiChild)
	{
		DeleteTask(htiChild);
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
	
	// then this item
	DWORD dwID = GetTaskID(hti);
	
	if (m_tree.DeleteItem(hti))
	{
		// delete mapping
		DeleteTask(dwID);
		return TRUE;
	}
	
	return FALSE;
}

void CToDoCtrlData::Sort(TDC_SORTBY nBy, BOOL bAscending, HTREEITEM htiRoot)
{
	CHTIMap mapHTI;
	BuildHTIMap(mapHTI, htiRoot);
	
	TDSORTSTRUCT ss = { this, &mapHTI, nBy, bAscending };
	
	Sort(htiRoot, ss);
}

void CToDoCtrlData::Sort(HTREEITEM hti, const TDSORTSTRUCT& ss)
{
	// don't sort if not expanded and not the root item (hti == NULL)
	if (hti && hti != TVI_ROOT && ss.pData->HasStyle(TDCS_SORTVISIBLETASKSONLY))
	{
		if (!(m_tree.GetItemState(hti, TVIS_EXPANDED) & TVIS_EXPANDED))
			return;
	}
	
	TVSORTCB tvs = { hti, CompareFunc, (LPARAM)&ss };
	
	// sort this items children first
	m_tree.SortChildrenCB(&tvs);
	
	// then its childrens children
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	
	while (htiChild)
	{
		Sort(htiChild, ss);
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
}

int CALLBACK CToDoCtrlData::CompareFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	int nCompare = 0;
	
	TDSORTSTRUCT* pSS = (TDSORTSTRUCT*)lParamSort;
	
	// sort by id can be optimized since the IDs are the lParams
	if (pSS->nSortBy == TDC_SORTBYID)
		return (pSS->bAscending ? (lParam1 - lParam2) : (lParam2 - lParam1));
	
	// else all the rest require the task lookup
	TODOITEM* tdi1 = pSS->pData->GetTask(lParam1);
	TODOITEM* tdi2 = pSS->pData->GetTask(lParam2);
	
	HTREEITEM hti1 = NULL, hti2 = NULL;
	VERIFY(pSS->pMapHTItems->Lookup(lParam1, hti1) && hti1);
	VERIFY(pSS->pMapHTItems->Lookup(lParam2, hti2) && hti2);
	
	// figure out if either or both tasks are completed
	// but only if the user has specified to sort these differently
	BOOL bHideDone = pSS->pData->HasStyle(TDCS_HIDESTARTDUEFORDONETASKS);
	BOOL bSortDoneBelow = pSS->pData->HasStyle(TDCS_SORTDONETASKSATBOTTOM);
	BOOL bDone1 = FALSE, bDone2 = FALSE;
	
	if (bSortDoneBelow || 
		pSS->nSortBy == TDC_SORTBYDONE || pSS->nSortBy == TDC_SORTBYDONEDATE ||
		(bHideDone && (pSS->nSortBy == TDC_SORTBYSTARTDATE || pSS->nSortBy == TDC_SORTBYDUEDATE)))
	{
		bDone1 = pSS->pData->IsTaskDone(hti1, TDCCHECKALL);
		bDone2 = pSS->pData->IsTaskDone(hti2, TDCCHECKALL);
		
		// can also do a partial optimization
		if (bSortDoneBelow && (pSS->nSortBy != TDC_SORTBYDONE && pSS->nSortBy != TDC_SORTBYDONEDATE))
		{
			if (bDone1 != bDone2)
				return bDone1 ? 1 : -1;
		}
	}
	
	switch (pSS->nSortBy)
	{
	case TDC_SORTBYNAME:
		nCompare = Compare(tdi1->sTitle, tdi2->sTitle);
		break;
		
	case TDC_SORTBYDONE:
		nCompare = Compare(bDone1, bDone2);
		break;
		
	case TDC_SORTBYFLAG:
		nCompare = Compare(tdi1->bFlagged, tdi2->bFlagged);
		break;
		
	case TDC_SORTBYCREATIONDATE:
		nCompare = Compare(tdi1->dateCreated, tdi2->dateCreated);
		break;
		
	case TDC_SORTBYDONEDATE:
		{
			COleDateTime date1 = tdi1->dateDone; // default
			COleDateTime date2 = tdi2->dateDone; // default
			
			// sort tasks 'good as done' between done and not-done
			if (date1 <= 0 && bDone1)
				date1 = 0.1;
			
			if (date2 <= 0 && bDone2)
				date2 = 0.1;
			
			nCompare = Compare(date1, date2);
		}
		break;
		
	case TDC_SORTBYDUEDATE:
		{
			COleDateTime date1, date2;
			
			BOOL bUseEarliestDueDate = pSS->pData->HasStyle(TDCS_USEEARLIESTDUEDATE);
			
			if (!bHideDone || !bDone1)
			{
				if (bUseEarliestDueDate)
					date1 = pSS->pData->GetEarliestDueDate(hti1, tdi1);
				else
					date1 = tdi1->dateDue;
			}
			
			if (!bHideDone || !bDone2)
			{
				if (bUseEarliestDueDate)
					date2 = pSS->pData->GetEarliestDueDate(hti2, tdi2);
				else
					date2 = tdi2->dateDue;
			}
			
			// Sort undated options below others
			BOOL bHasDue1 = (date1.m_dt > 0) ? 1 : 0;
			BOOL bHasDue2 = (date2.m_dt > 0) ? 1 : 0;
			
			if (bHasDue1 != bHasDue2)
				return bHasDue1 ? -1 : 1;
			
			else if (!bHasDue1) //  and !bHasStart2
				return 0;
			
			// compare
			nCompare = Compare(date1, date2);
		}
		break;
		
	case TDC_SORTBYSTARTDATE:
		{
			BOOL bHasStart1 = tdi1->HasStart() && !(bHideDone && bDone1);
			BOOL bHasStart2 = tdi2->HasStart() && !(bHideDone && bDone2);
			
			if (bHasStart1 != bHasStart2)
				return bHasStart1 ? -1 : 1;
			
			else if (!bHasStart1) //  and !bHasStart2
				return 0;
			
			nCompare = Compare(tdi1->dateStart, tdi2->dateStart);
		}
		break;
		
	case TDC_SORTBYPRIORITY:
		{
			// done items have even less than zero priority!
			// and due items have greater than the highest priority
			int nPriority1 = tdi1->nPriority; // default
			int nPriority2 = tdi2->nPriority; // default
			
			BOOL bUseHighestPriority = pSS->pData->HasStyle(TDCS_USEHIGHESTPRIORITY);
			
			// item1
			if (bDone1)
				nPriority1 = -1;
			
			else if (pSS->pData->IsTaskDue(hti1, tdi1))
				nPriority1 = tdi1->nPriority + 11;
			
			else if (bUseHighestPriority)
				nPriority1 = pSS->pData->GetHighestPriority(hti1, tdi1);
			
			// item2
			if (bDone2)
				nPriority2 = -1;
			
			else if (pSS->pData->IsTaskDue(hti2, tdi2))
				nPriority2 = tdi2->nPriority + 11;
			
			else if (bUseHighestPriority)
				nPriority2 = pSS->pData->GetHighestPriority(hti2, tdi2);
			
			nCompare = Compare(nPriority1, nPriority2);
		}
		break;
		
	case TDC_SORTBYCOLOR:
		nCompare = Compare((int)tdi1->color, (int)tdi2->color);
		break;
		
	case TDC_SORTBYALLOCTO:
		nCompare = Compare(tdi1->sAllocTo, tdi2->sAllocTo, TRUE);
		break;
		
	case TDC_SORTBYALLOCBY:
		nCompare = Compare(tdi1->sAllocBy, tdi2->sAllocBy, TRUE);
		break;
		
	case TDC_SORTBYCREATEDBY:
		nCompare = Compare(tdi1->sCreatedBy, tdi2->sCreatedBy, TRUE);
		break;
		
	case TDC_SORTBYSTATUS:
		nCompare = Compare(tdi1->sStatus, tdi2->sStatus, TRUE);
		break;
		
	case TDC_SORTBYCATEGORY:
		nCompare = Compare(tdi1->sCategory, tdi2->sCategory, TRUE);
		break;
		
	case TDC_SORTBYPERCENT:
		{
			int nPercent1 = pSS->pData->CalcPercentDone(hti1, tdi1);
			int nPercent2 = pSS->pData->CalcPercentDone(hti2, tdi2);
			
			nCompare = Compare(nPercent1, nPercent2);
		}
		break;
		
	case TDC_SORTBYTIMEEST:
		{
			double dTime1 = pSS->pData->CalcTimeEstimate(hti1, tdi1, TDCTU_HOURS);
			double dTime2 = pSS->pData->CalcTimeEstimate(hti2, tdi2, TDCTU_HOURS);
			
			nCompare = Compare(dTime1, dTime2);
		}
		break;
		
	case TDC_SORTBYTIMESPENT:
		{
			double dTime1 = pSS->pData->CalcTimeSpent(hti1, tdi1, TDCTU_HOURS);
			double dTime2 = pSS->pData->CalcTimeSpent(hti2, tdi2, TDCTU_HOURS);
			
			nCompare = Compare(dTime1, dTime2);
		}
		break;
		
	default:
		ASSERT(0);
		break;
	}
	
	if (!pSS->bAscending)
		nCompare = -nCompare;
	
	return nCompare;
}

int CToDoCtrlData::Compare(const COleDateTime& date1, const COleDateTime& date2)
{
	return (date1 < date2) ? -1 : (date1 > date2) ? 1 : 0;
}

int CToDoCtrlData::Compare(const CString& sText1, const CString& sText2, BOOL bCheckEmpty)
{
	if (bCheckEmpty)
	{
		BOOL bEmpty1 = sText1.IsEmpty();
		BOOL bEmpty2 = sText2.IsEmpty();
		
		if (bEmpty1 != bEmpty2)
			return bEmpty1 ? 1 : -1;
	}
	
	return sText1.CompareNoCase(sText2);
}

int CToDoCtrlData::Compare(int nNum1, int nNum2)
{
    return (nNum1 - nNum2);
}

int CToDoCtrlData::Compare(const double& dNum1, const double& dNum2)
{
    return (dNum1 < dNum2) ? -1 : (dNum1 > dNum2) ? 1 : 0;
}

int CToDoCtrlData::GetItemPos(HTREEITEM hti, HTREEITEM htiSearch) const
{
	// traverse the entire tree util we find the item
	if (!htiSearch)
		htiSearch = TVI_ROOT;
	
	int nPos = 1; // always 1-based
	HTREEITEM htiChild = m_tree.GetChildItem(htiSearch);
	
	while (htiChild)
	{
		if (htiChild == hti)
			return nPos;
		
		// try items children
		int nChildPos = GetItemPos(hti, htiChild);
		
		if (nChildPos)
			return nChildPos;
		
		nPos++;
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
	
	return 0; // not found
}

void CToDoCtrlData::ResetCachedCalculations()
{
	// sets the bNeedRecalc flag on all items
	POSITION pos = m_mapTDItems.GetStartPosition();
	TODOITEM* pTDI;
	DWORD dwID;
	
	while (pos)
	{
		m_mapTDItems.GetNextAssoc(pos, dwID, pTDI);
		
		pTDI->ResetCalcs();
		m_mapTDItems[dwID] = pTDI;
	}
}

int CToDoCtrlData::CalcPercentDone(const HTREEITEM hti, const TODOITEM* pTDI) const
{
	// simple optimization
	// try pre-calculated value first
	if (pTDI->nCalcPercent >= 0)
		return pTDI->nCalcPercent;
	
	int nPercent = 0;
	
	if (!HasStyle(TDCS_AVERAGEPERCENTSUBCOMPLETION))
	{
		if (pTDI->IsDone())
			nPercent = 100;
		
		else if(HasStyle(TDCS_AUTOCALCPERCENTDONE))
			nPercent = CalcPercentFromTime(hti, pTDI);
		
		else
			nPercent = pTDI->nPercentDone;
	}
	else
	{
		// else
		double dTotalPercent = 0, dTotalWeighting = 0, dPercent = 0;
		
		SumPercentDone(hti, pTDI, dTotalPercent, dTotalWeighting);
		
		if (dTotalWeighting > 0)
			dPercent = dTotalPercent / dTotalWeighting;
		else
			ASSERT (dTotalPercent == 0); // sanity check
		
		nPercent = (int)dPercent;
	}
	
	// else update calc'ed value
	pTDI->nCalcPercent = nPercent;
	
	return pTDI->nCalcPercent;
}

int CToDoCtrlData::CalcPercentFromTime(const HTREEITEM hti, const TODOITEM* pTDI) const
{
	ASSERT (HasStyle(TDCS_AUTOCALCPERCENTDONE)); // sanity check
	
	double dSpent = CalcTimeSpent(hti, pTDI, TEU_HOURS);
	double dEstimate = CalcTimeEstimate(hti, pTDI, TEU_HOURS);
	
	if (dSpent > 0 && dEstimate > 0)
		return min(100, (int)(100 * dSpent / dEstimate));
	else
		return 0;
}

void CToDoCtrlData::SumPercentDone(const HTREEITEM hti, const TODOITEM* pTDI,
                                   double& dTotalPercent, double& dTotalWeighting) const
{
	ASSERT (HasStyle(TDCS_AVERAGEPERCENTSUBCOMPLETION)); // sanity check
	
	if (!m_tree.ItemHasChildren(hti))
	{
		double dWeighting = 1; // default
		double dPercent = 0;
		
		// base percent
		if (pTDI->IsDone())
			dPercent = 100;
		
		else if(HasStyle(TDCS_AUTOCALCPERCENTDONE))
			dPercent = CalcPercentFromTime(hti, pTDI);
		
		else
			dPercent = pTDI->nPercentDone;
		
		// weighting
		if (HasStyle(TDCS_WEIGHTPERCENTCALCBYTIMEEST))
			dWeighting *= CTimeEdit::GetTime(pTDI->dTimeEstimate,	pTDI->nTimeEstUnits, TEU_HOURS);
		
		if (HasStyle(TDCS_WEIGHTPERCENTCALCBYPRIORITY))
			dWeighting *= pTDI->nPriority;
		
		dPercent *= dWeighting;
		
		dTotalWeighting += dWeighting;
		dTotalPercent += dPercent;
	}
	else // aggregate child percentages
	{
		HTREEITEM htiChild = m_tree.GetChildItem(hti);
		
		while (htiChild)
		{
			TODOITEM* tdiChild = GetTask(htiChild);
			ASSERT(tdiChild);
			
			if (!tdiChild->IsDone() || HasStyle(TDCS_INCLUDEDONEINAVERAGECALC))
			{
				SumPercentDone(htiChild, tdiChild, dTotalPercent, dTotalWeighting);
			}
			
			htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
		}
	}
}

double CToDoCtrlData::CalcTimeEstimate(const HTREEITEM hti, const TODOITEM* pTDI, int nUnits) const
{
	// update calc'ed value in hours
	if (pTDI->dCalcTimeEstimate < 0)
	{	
		double dTime = 0;
		
		if (!m_tree.ItemHasChildren(hti))
		{
			dTime = CTimeEdit::GetTime(pTDI->dTimeEstimate, pTDI->nTimeEstUnits, TEU_HOURS);
			
			if (HasStyle(TDCS_USEPERCENTDONEINTIMEEST))
			{
				if (pTDI->IsDone())
					dTime = 0;
				else
					dTime *= ((100 - pTDI->nPercentDone) / 100.0); // estimating time left
			}
		}
		else // children
		{
			HTREEITEM htiChild = m_tree.GetChildItem(hti);
			
			while (htiChild)
			{
				TODOITEM* tdiChild = GetTask(htiChild);
				ASSERT(tdiChild);
				
				dTime += CalcTimeEstimate(htiChild, tdiChild, TEU_HOURS);
				
				htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
			}
		}
		
		// update calc'ed value
		pTDI->dCalcTimeEstimate = dTime;
	}
	
	// its in hours (always) so we need to convert it to nUnits
	return CTimeEdit::GetTime(pTDI->dCalcTimeEstimate, TEU_HOURS, nUnits);
}

double CToDoCtrlData::CalcTimeSpent(const HTREEITEM hti, const TODOITEM* pTDI, int nUnits) const
{
	// update calc'ed value in hours
	if (pTDI->dCalcTimeSpent < 0)
	{
		double dTime = 0;
		
		if (!m_tree.ItemHasChildren(hti))
		{
			dTime = CTimeEdit::GetTime(pTDI->dTimeSpent, pTDI->nTimeSpentUnits, TEU_HOURS);
		}
		else // children
		{
			HTREEITEM htiChild = m_tree.GetChildItem(hti);
			
			while (htiChild)
			{
				TODOITEM* tdiChild = GetTask(htiChild);
				ASSERT(tdiChild);
				
				dTime += CalcTimeSpent(htiChild, tdiChild, TEU_HOURS);
				
				htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
			}
		}
		
		// update calc'ed value
		pTDI->dCalcTimeSpent = dTime;
	}
	
	// convert it back from hours to nUnits
	return CTimeEdit::GetTime(pTDI->dCalcTimeSpent, TEU_HOURS, nUnits);
}

void CToDoCtrlData::BuildHTIMap(CHTIMap& mapHTI, HTREEITEM htiRoot) const
{
	mapHTI.RemoveAll();
	
	// traverse toplevel items
	HTREEITEM hti = m_tree.GetChildItem(htiRoot);
	
	while (hti)
	{
		UpdateHTIMapEntry(mapHTI, hti);
		hti = m_tree.GetNextItem(hti, TVGN_NEXT);
	}
}

void CToDoCtrlData::UpdateHTIMapEntry(CHTIMap& mapHTI, HTREEITEM hti) const
{
	// update our own mapping
	mapHTI[GetTaskID(hti)] = hti;
	
	// then our children
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	
	while (htiChild)
	{
		UpdateHTIMapEntry(mapHTI, htiChild);
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
}

BOOL CToDoCtrlData::IsTaskDue(HTREEITEM hti) const
{
	TODOITEM* pTDI = GetTask(hti);
	
	if (!pTDI)
		return FALSE;
	
	return IsTaskDue(hti, pTDI);
}

double CToDoCtrlData::GetEarliestDueDate(HTREEITEM hti) const
{
	TODOITEM* pTDI = GetTask(hti);
	
	if (!pTDI)
		return 0;
	
	return GetEarliestDueDate(hti, pTDI);
}

int CToDoCtrlData::GetHighestPriority(HTREEITEM hti) const
{
	TODOITEM* pTDI = GetTask(hti);
	
	if (!pTDI)
		return 0;
	
	return GetHighestPriority(hti, pTDI);
}

int CToDoCtrlData::CalcPercentDone(const HTREEITEM hti) const
{
	TODOITEM* pTDI = GetTask(hti);
	
	if (!pTDI)
		return 0;
	
	return CalcPercentDone(hti, pTDI);
}

double CToDoCtrlData::CalcTimeEstimate(const HTREEITEM hti, int nUnits) const
{
	TODOITEM* pTDI = GetTask(hti);
	
	if (!pTDI)
		return 0;
	
	return CalcTimeEstimate(hti, pTDI, nUnits);
}

double CToDoCtrlData::CalcTimeSpent(const HTREEITEM hti, int nUnits) const
{
	TODOITEM* pTDI = GetTask(hti);
	
	if (!pTDI)
		return 0;
	
	return CalcTimeSpent(hti, pTDI, nUnits);
}

BOOL CToDoCtrlData::IsTaskFullyDone(const HTREEITEM hti, const TODOITEM* pTDI, BOOL bCheckSiblings) const
{
	if (bCheckSiblings)
	{
		// note: its not intuitive to apply the sibling rule to top level tasks
		// so we only apply it to tasks whose parent is not the root
		HTREEITEM htiParent = m_tree.GetParentItem(hti);
		
		if (htiParent && htiParent != TVI_ROOT)
		{
			HTREEITEM htiSibling = m_tree.GetChildItem(htiParent);
			
			while (htiSibling)
			{
				if (htiSibling != hti) // else we would recurse
				{
					TODOITEM* tdiSibling = GetTask(htiSibling);
					
					if (tdiSibling)
					{
						// exit on first failure
						if (!IsTaskFullyDone(htiSibling, tdiSibling, FALSE)) // FALSE: we're doing the siblings
							return FALSE;
					}
				}
				
				htiSibling = m_tree.GetNextItem(htiSibling, TVGN_NEXT);
			}
		}
	}
	
	// check children
	BOOL bTreatSubCompleteDone = HasStyle(TDCS_TREATSUBCOMPLETEDASDONE);
	
	if (bTreatSubCompleteDone && m_tree.ItemHasChildren(hti))
	{
		HTREEITEM htiChild = m_tree.GetChildItem(hti);
		
		while (htiChild)
		{
			TODOITEM* tdiChild = GetTask(htiChild);
			
			if (tdiChild)
			{
				// exit on first failure
				if (!IsTaskFullyDone(htiChild, tdiChild, FALSE)) // FALSE: we're doing the siblings
					return FALSE;
			}
			
			htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
		}
	}
	else 
		return pTDI->IsDone(); // no children => relies on our state only
	
	// if we got here there were no sibling or child failures
	return TRUE;
}

BOOL CToDoCtrlData::IsTaskDue(HTREEITEM hti, const TODOITEM* pTDI) const
{
	// some optimizations
	// check chached value
	if (pTDI->bDue >= 0)
		return pTDI->bDue;

	double dDue = GetEarliestDueDate(hti,  pTDI);
	BOOL bDue = (dDue > 0 && dDue < COleDateTime::GetCurrentTime());

	// update cached value
	pTDI->bDue = bDue;
	
	return pTDI->bDue;
}

double CToDoCtrlData::GetEarliestDueDate(HTREEITEM hti, const TODOITEM* pTDI) const
{
	ASSERT (hti);
	ASSERT (pTDI);
	
	// some optimizations
	if (pTDI->dateEarliestDue.m_dt >= 0)
		return pTDI->dateEarliestDue;
	
	double dEarliest = pTDI->dateDue;
	
	if (IsTaskDone(hti, TDCCHECKCHILDREN))
		dEarliest = 0;
	
	else if (HasStyle(TDCS_USEEARLIESTDUEDATE) && m_tree.ItemHasChildren(hti))
	{
		// check children
		dEarliest = pTDI->HasDue() ? pTDI->dateDue : DBL_MAX;
		
		HTREEITEM htiChild = m_tree.GetChildItem(hti);
		
		while (htiChild)
		{
			TODOITEM* tdiChild = GetTask(htiChild);
			
			if (!tdiChild)
				return 0;
			
			double dChildDue = GetEarliestDueDate(htiChild, tdiChild);
			
			if (dChildDue > 0 && dChildDue < dEarliest)
				dEarliest = dChildDue;
			
			htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
		}
	}
	
	// update calc'ed value
	pTDI->dateEarliestDue = (dEarliest == DBL_MAX) ? 0 : dEarliest;
	
	return pTDI->dateEarliestDue;
}

int CToDoCtrlData::GetHighestPriority(HTREEITEM hti, const TODOITEM* pTDI) const
{
	ASSERT (hti);
	ASSERT(pTDI);
	
	// some optimizations
	// try pre-calculated value first
	if (pTDI->nCalcPriority >= 0)
		return pTDI->nCalcPriority;
	
	int nHighest = pTDI->nPriority;
	
	if (nHighest < MAX_TDPRIORITY)
	{
		if (pTDI->IsDone())
			nHighest = MIN_TDPRIORITY;

		else if (IsTaskDue(hti, pTDI))
			nHighest = MAX_TDPRIORITY;
		
		else if (HasStyle(TDCS_USEHIGHESTPRIORITY) && m_tree.ItemHasChildren(hti))
		{
			// check children
			nHighest = MIN_TDPRIORITY;
			
			HTREEITEM htiChild = m_tree.GetChildItem(hti);
			
			while (htiChild)
			{
				if (HasStyle(TDCS_INCLUDEDONEINPRIORITYCALC) || !IsTaskDone(htiChild, TDCCHECKALL))
				{
					TODOITEM* tdiChild = GetTask(htiChild);
					
					if (!tdiChild)
						return MIN_TDPRIORITY;

					int nChildHighest = GetHighestPriority(htiChild, tdiChild);
					
					// optimization
					if (nChildHighest == MAX_TDPRIORITY)
						return MAX_TDPRIORITY;
					else 
						nHighest = max(nChildHighest, nHighest);
				}
				
				htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
			}
		}
	}
	
	// update calc'ed value
	pTDI->nCalcPriority = max(pTDI->nPriority, nHighest);
	
	return pTDI->nCalcPriority;
}

BOOL CToDoCtrlData::IsTaskDone(HTREEITEM hti, DWORD dwExtraCheck) const
{
	if (!hti)
		return FALSE;
	
	TODOITEM* pTDI = GetTask(hti);
	
	if (!pTDI)
		return FALSE;
	
	// check cached value
	if (dwExtraCheck == TDCCHECKALL && pTDI->bGoodAsDone >= 0)
		return pTDI->bGoodAsDone;
	
	if (pTDI->IsDone())
		return TRUE;
	
	BOOL bDone = FALSE;
	
	if (dwExtraCheck & TDCCHECKPARENT)
	{
		HTREEITEM htiParent = m_tree.GetParentItem(hti);
		
		if (htiParent && IsTaskDone(htiParent, TDCCHECKPARENT))
			bDone = TRUE;
	}
	
	// else check children for 'good-as-done'
	if (!bDone)
	{
		BOOL bTreatSubCompleteDone = HasStyle(TDCS_TREATSUBCOMPLETEDASDONE);
		
		if ((dwExtraCheck & TDCCHECKCHILDREN) && bTreatSubCompleteDone)
		{
			if (AreChildTasksDone(hti) == 1)
				bDone = TRUE;
		}
	}
	
	// update cached value
	if (dwExtraCheck == TDCCHECKALL)
		pTDI->bGoodAsDone = bDone;
	   
	// else return as is
	return bDone;
}

BOOL CToDoCtrlData::IsTaskTimeTrackable(HTREEITEM hti) const
{
	if (!hti)
		return FALSE;
	
	// not trackable if a container or complete
	if (m_tree.ItemHasChildren(hti) || IsTaskDone(hti, TDCCHECKNONE))
		return FALSE;
	
	return TRUE;
}

int CToDoCtrlData::SetTaskAttributeAsParent(HTREEITEM hti, TDC_ATTRIBUTE nAttrib)
{
	HTREEITEM htiParent = m_tree.GetParentItem(hti);
	
	if (!htiParent)
		return FALSE;
	
	DWORD dwID = m_tree.GetItemData(hti);
	DWORD dwParentID = m_tree.GetItemData(htiParent);
	
	switch (nAttrib)
	{
	case TDCA_TASKNAME:
		return SetTaskTitle(dwID, GetTaskTitle(dwParentID));
		
	case TDCA_DONEDATE:
		return SetTaskDoneDate(dwID, GetTaskDoneDate(dwParentID));
		break;
		
	case TDCA_DUEDATE:
		return SetTaskDueDate(dwID, GetTaskDueDate(dwParentID));
		break;
		
	case TDCA_STARTDATE:
		return SetTaskStartDate(dwID, GetTaskStartDate(dwParentID));
		break;
		
	case TDCA_PRIORITY:
		return SetTaskPriority(dwID, GetTaskPriority(dwParentID));
		break;
		
	case TDCA_COLOR:
		return SetTaskColor(dwID, GetTaskColor(dwParentID));
		break;
		
	case TDCA_ALLOCTO:
		return SetTaskAllocTo(dwID, GetTaskAllocTo(dwParentID));
		break;
		
	case TDCA_ALLOCBY:
		return SetTaskAllocBy(dwID, GetTaskAllocBy(dwParentID));
		break;
		
	case TDCA_STATUS:
		return SetTaskStatus(dwID, GetTaskStatus(dwParentID));
		break;
		
	case TDCA_CATEGORY:
		return SetTaskCategory(dwID, GetTaskCategory(dwParentID));
		break;
		
	case TDCA_PERCENT:
		return SetTaskPercent(dwID, GetTaskPercent(dwParentID, FALSE));
		break;
		
	case TDCA_TIMEEST:
		return SetTaskTimeEstimate(dwID, GetTaskTimeEstimate(dwParentID));
		break;
		
	case TDCA_FILEREF:
		return SetTaskFileRef(dwID, GetTaskFileRef(dwParentID));
		break;
		
	case TDCA_COMMENTS:
		return SetTaskComments(dwID, GetTaskComments(dwParentID));
		break;
	}
	
	// all else
	return FALSE;
}

void CToDoCtrlData::ApplyLastChangeToSubtasks(const HTREEITEM hti, const TODOITEM* pTDI, TDC_ATTRIBUTE nAttrib)
{
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	TODOITEM* tdiChild;
	
	while (htiChild)
	{
		DWORD dwIDChild = GetTaskID(htiChild);
		tdiChild = GetTask(dwIDChild);
		ASSERT (tdiChild);
		
		// apply the change based on nAttrib
		switch (nAttrib)
		{
		case TDCA_DONEDATE:
			tdiChild->dateDone = pTDI->dateDone;
			break;
			
		case TDCA_DUEDATE:
			tdiChild->dateDue = pTDI->dateDue;
			break;
			
		case TDCA_STARTDATE:
			tdiChild->dateStart = pTDI->dateStart;
			break;
			
		case TDCA_PRIORITY:
			tdiChild->nPriority = pTDI->nPriority;
			break;
			
		case TDCA_COLOR:
			tdiChild->color = pTDI->color;
			break;
			
		case TDCA_ALLOCTO:
			tdiChild->sAllocTo = pTDI->sAllocTo;
			break;
			
		case TDCA_ALLOCBY:
			tdiChild->sAllocBy = pTDI->sAllocBy;
			break;
			
		case TDCA_STATUS:
			tdiChild->sStatus = pTDI->sStatus;
			break;
			
		case TDCA_CATEGORY:
			tdiChild->sCategory = pTDI->sCategory;
			break;
			
		case TDCA_PERCENT:
			tdiChild->nPercentDone = pTDI->nPercentDone;
			break;
			
		case TDCA_TIMEEST:
			tdiChild->dTimeEstimate = pTDI->dTimeEstimate;
			break;
			
		case TDCA_FILEREF:
			tdiChild->sFileRefPath = pTDI->sFileRefPath;
			break;
			
		default:
			ASSERT (0);
			return;
		}
		
		// and its children too
		if (m_tree.ItemHasChildren(htiChild))
			ApplyLastChangeToSubtasks(htiChild, tdiChild, nAttrib);
		
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
}

int CToDoCtrlData::SetTaskColor(DWORD dwID, COLORREF color)
{
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			// if the color is 0 then add 1 to discern from unset
			if (!color)
				color++;
			
			if (pTDI->color != color)
			{
				pTDI->color = color;
				pTDI->SetModified();
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskComments(DWORD dwID, LPCTSTR szComments)
{
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			if (pTDI->sComments != szComments)
			{
				pTDI->sComments = szComments;
				pTDI->SetModified();
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskCustomComments(DWORD dwID, const CString& sComments)
{
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			if (pTDI->sCustomComments.GetLength() != sComments.GetLength() ||
				memcmp((LPCTSTR)pTDI->sCustomComments, (LPCTSTR)sComments, sComments.GetLength()))
			{
				pTDI->sCustomComments = sComments;
				pTDI->SetModified();
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskTitle(DWORD dwID, LPCTSTR szTitle)
{
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			if (pTDI->sTitle != szTitle)
			{
				pTDI->sTitle = szTitle;
				pTDI->SetModified();
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskFlag(DWORD dwID, BOOL bFlagged)
{
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			if (pTDI->bFlagged != bFlagged)
			{
				pTDI->bFlagged = bFlagged;
				pTDI->SetModified();
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskPriority(DWORD dwID, int nPriority)
{
	if (dwID && nPriority >= 0 && nPriority <= 10)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			if (pTDI->nPriority != nPriority)
			{
				pTDI->nPriority = nPriority;
				pTDI->SetModified();
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskStartDate(DWORD dwID, const COleDateTime& date)
{
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			// whole days only
			COleDateTime dateDay = (double)(int)date.m_dt;
			
			if (pTDI->dateStart != dateDay)
			{
				pTDI->dateStart = dateDay;
				pTDI->SetModified();
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskDoneDate(DWORD dwID, const COleDateTime& date)
{
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			// whole days only
			COleDateTime dateDay = (double)(int)date.m_dt;
			
			if (pTDI->dateDone != dateDay)
			{
				pTDI->dateDone = dateDay;
				pTDI->SetModified();
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskDueDate(DWORD dwID, const COleDateTime& date)
{
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			// whole days only
			COleDateTime dateDay = (double)(int)date.m_dt;
			
			if (pTDI->dateDue != dateDay)
			{
				pTDI->dateDue = dateDay;
				pTDI->SetModified();
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskDone(DWORD dwID, BOOL bDone, int& nPrevPercent)
{
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			BOOL bWasDone = pTDI->IsDone();
			
			if (bWasDone != bDone)
			{
				if (!bDone)
				{
					// restore last known percentage unless is 100%
					if (pTDI->nPercentDone == 100)
						pTDI->nPercentDone = 0;
					
					nPrevPercent = pTDI->nPercentDone;
				}
				
				pTDI->dateDone = bDone ? COleDateTime::GetCurrentTime() : COleDateTime();
				pTDI->SetModified();
				return SET_CHANGE;
			}
			
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskPercent(DWORD dwID, int nPercent)
{
	if (nPercent < 0 || nPercent > 100)
		return FALSE;
	
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			if (pTDI->nPercentDone != nPercent)
			{
				pTDI->nPercentDone = nPercent;
				pTDI->SetModified();
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskTimeEstimate(DWORD dwID, const double& dTime, int nUnits)
{
	if (dTime < 0)
		return FALSE;
	
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			if (pTDI->dTimeEstimate != dTime || pTDI->nTimeEstUnits != nUnits)
			{
				pTDI->dTimeEstimate = dTime;
				pTDI->nTimeEstUnits = nUnits;
				pTDI->SetModified();
				return SET_CHANGE;
			}	
			
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskTimeSpent(DWORD dwID, const double& dTime, int nUnits)
{
	if (dTime < 0)
		return FALSE;
	
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			if (pTDI->dTimeSpent != dTime || pTDI->nTimeSpentUnits != nUnits)
			{
				pTDI->dTimeSpent = dTime;
				pTDI->nTimeSpentUnits = nUnits;
				pTDI->SetModified();
				return SET_CHANGE;
			}	
			
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskAllocTo(DWORD dwID, LPCTSTR szAllocTo)
{
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			if (pTDI->sAllocTo != szAllocTo)
			{
				pTDI->sAllocTo = szAllocTo;
				pTDI->SetModified();
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskAllocBy(DWORD dwID, LPCTSTR szAllocBy)
{
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			if (pTDI->sAllocBy != szAllocBy)
			{
				pTDI->sAllocBy = szAllocBy;
				pTDI->SetModified();
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskStatus(DWORD dwID, LPCTSTR szStatus)
{
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			if (pTDI->sStatus != szStatus)
			{
				pTDI->sStatus = szStatus;
				pTDI->SetModified();
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskCategory(DWORD dwID, LPCTSTR szCategory)
{
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			if (pTDI->sCategory != szCategory)
			{
				pTDI->sCategory = szCategory;
				pTDI->SetModified();
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskFileRef(DWORD dwID, LPCTSTR szFilePath)
{
	if (dwID)
	{
		TODOITEM* pTDI = GetTask(dwID);
		
		if (pTDI)
		{
			if (pTDI->sFileRefPath.CompareNoCase(szFilePath))
			{
				pTDI->sFileRefPath = szFilePath;
				pTDI->SetModified();
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::MapTimeUnits(const CString& sUnits)
{
	if (sUnits.IsEmpty())
		return TDCTU_HOURS; // default
	
	switch (sUnits[0])
	{
	case 'D':
	case 'd': return TDCTU_DAYS;
		
	case 'W':
	case 'w': return TDCTU_WEEKS;
		
	case 'M':
	case 'm': return TDCTU_MONTHS;
		
	case 'Y':
	case 'y': return TDCTU_YEARS;
	}
	
	// all else
	return TDCTU_HOURS;
}

CString CToDoCtrlData::MapTimeUnits(int nUnits)
{
	switch (nUnits)
	{
	case TDCTU_DAYS:	return "D";
	case TDCTU_WEEKS:	return "W";
	case TDCTU_MONTHS:	return "M";
	case TDCTU_YEARS:	return "Y";
	}
	
	// all else
	return "H";
}

HTREEITEM CToDoCtrlData::FindItem(DWORD dwID, HTREEITEM htiStart) const
{
	// try htiStart first
	if (htiStart && m_tree.GetItemData(htiStart) == dwID)
		return htiStart;
	
	// else try htiStart's children
	HTREEITEM htiFound = NULL;
	HTREEITEM htiChild = m_tree.GetChildItem(htiStart);
	
	while (htiChild && !htiFound)
	{
		htiFound = FindItem(dwID, htiChild);
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
	
	return htiFound;
}

void CToDoCtrlData::LoadTreeExpandedState(LPCTSTR szRegKey)
{
	int nCount = AfxGetApp()->GetProfileInt(szRegKey, "Count", 0);
	CString sItem;
	
	CHTIMap map;
	BuildHTIMap(map);
	
	while (nCount--)
	{
		sItem.Format("Item%d", nCount);
		
		DWORD dwID = (DWORD)AfxGetApp()->GetProfileInt(szRegKey, sItem, 0);
		HTREEITEM hti = NULL;
		
		if (dwID && map.Lookup(dwID, hti) && hti)
			m_tree.Expand(hti, TVE_EXPAND);
	}
}

int CToDoCtrlData::SaveTreeExpandedState(LPCTSTR szRegKey, HTREEITEM hti, int nStart)
{
	CTreeCtrlHelper tch(m_tree);
	
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	int nCount = nStart;
	
	while (htiChild)
	{
		if (tch.IsItemExpanded(htiChild))
		{
			CString sItem;
			sItem.Format("Item%d", nCount);
			
			AfxGetApp()->WriteProfileInt(szRegKey, sItem, (int)GetTaskID(htiChild));
			nCount++;
			
			// now its children
			nCount += SaveTreeExpandedState(szRegKey, htiChild, nCount);
		}
		
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}	
	
	return (nCount - nStart);
}

