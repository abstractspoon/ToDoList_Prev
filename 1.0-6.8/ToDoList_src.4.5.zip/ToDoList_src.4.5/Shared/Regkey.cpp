#include "stdafx.h"
#include "regkey.h"
#include <winerror.h>

CRegKey::CRegKey()
{
	m_hKeyRoot = NULL;
	m_hKey = NULL;
	m_sPath.Empty();
}

CRegKey::CRegKey(CRegKey& regKey)
{
	m_hKeyRoot = NULL;
	m_hKey = NULL;
	m_sPath.Empty();

	try
	{
		Open(regKey.m_hKeyRoot, regKey.m_sPath);
	}
	catch (...)
	{
	}
}

CRegKey::~CRegKey()
{
	Close();
}

CRegKey& CRegKey::operator=(CRegKey regKey)
{
	m_hKey = regKey.m_hKey;
	m_sPath = regKey.m_sPath;

    return *this; 
}

LONG CRegKey::Open(HKEY hKeyRoot, const char* pszPath)
{
	DWORD dwDisp;
	LONG lResult;

	// if the key has aleady been opened then close it first
	if (m_hKey)
	{
		ASSERT(0);
		return ERROR_ACCESS_DENIED;
	}

	m_sPath = pszPath;
	m_hKeyRoot = hKeyRoot;

	lResult = RegCreateKeyEx(hKeyRoot, pszPath, 0L, NULL,
				REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, 
				&m_hKey, &dwDisp);

	return lResult;
}

BOOL CRegKey::KeyExists(HKEY hKeyRoot, const char* pszPath)
{
	BOOL bExistingKey;
	DWORD dwDisp;
	HKEY hTemp;

	// open a temporary key
	RegCreateKeyEx(hKeyRoot, pszPath, 0L, NULL,
				REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, 
				&hTemp, &dwDisp);
	
	// make sure we close it
	RegCloseKey(hTemp);

	// test for existing
	bExistingKey = (dwDisp == REG_OPENED_EXISTING_KEY);

	// and then delete the physical entry from the registry if new
	if (!bExistingKey)
		Delete(hKeyRoot, pszPath);

	return bExistingKey;
}

LONG CRegKey::RecurseDeleteKey(HKEY key, LPCTSTR lpszKey)
{
	HKEY rslt;
	LONG lRes;
	FILETIME time;
	TCHAR szBuffer[256];
	DWORD dwSize = 256;

	lRes = RegOpenKeyEx(key, lpszKey, 0, KEY_ALL_ACCESS, &rslt);

	if (lRes != ERROR_SUCCESS)
		return lRes;

	while (RegEnumKeyEx(rslt, 0, szBuffer, &dwSize, NULL, NULL, NULL, &time) == ERROR_SUCCESS)
	{
		lRes = RecurseDeleteKey(rslt, szBuffer);

		if (lRes != ERROR_SUCCESS)
			return lRes;

		dwSize = 256;
	}

	RegCloseKey(rslt);

	return RegDeleteKey(key, lpszKey);
}

LONG CRegKey::Delete(HKEY hKeyRoot, const char* pszPath)
{
	return RecurseDeleteKey(hKeyRoot, pszPath);
}

void CRegKey::Close()
{
	if (m_hKey)
	{
		RegCloseKey(m_hKey);
	}
		
	m_hKey = NULL;
}

LONG CRegKey::Write(const char* pszKey, DWORD dwVal) 
{
	ASSERT(m_hKey);
	ASSERT(pszKey);
	return RegSetValueEx(m_hKey, pszKey, 0L, REG_DWORD,
		(CONST BYTE*) &dwVal, sizeof(DWORD));
}

LONG CRegKey::Write(const char* pszKey, const char* pszData) 
{
	ASSERT(m_hKey);
	ASSERT(pszKey);
	ASSERT(pszData);

#ifndef _NOT_USING_MFC_
	ASSERT(AfxIsValidAddress(pszData, strlen(pszData), FALSE));
#endif

	return RegSetValueEx(m_hKey, pszKey, 0L, REG_SZ,
		(CONST BYTE*) pszData, strlen(pszData) + 1);
}

LONG CRegKey::Write(const char* pszKey, const BYTE* pData, DWORD dwLength) 
{
	ASSERT(m_hKey);
	ASSERT(pszKey);
	ASSERT(pData && dwLength > 0);

#ifndef _NOT_USING_MFC_
	ASSERT(AfxIsValidAddress(pData, dwLength, FALSE));
#endif

	return RegSetValueEx (m_hKey, pszKey, 0L, REG_BINARY,
		pData, dwLength);
}

LONG CRegKey::Read(const char* pszKey, DWORD& dwVal) 
{
	ASSERT(m_hKey);
	ASSERT(pszKey);

	DWORD dwType;
	DWORD dwSize = sizeof (DWORD);
	DWORD dwDest;

	LONG lRet = RegQueryValueEx (m_hKey, (LPSTR) pszKey, NULL, 
		&dwType, (BYTE *) &dwDest, &dwSize);

	if (lRet == ERROR_SUCCESS)
		dwVal = dwDest;

	return lRet;
}

LONG CRegKey::Read(const char* pszKey, CString& sVal) 
{
	ASSERT(m_hKey);
//	ASSERT(pszKey);

	DWORD dwType;
	DWORD dwSize = 200;
	char  string[200];

	LONG lReturn = RegQueryValueEx (m_hKey, (LPSTR) pszKey, NULL,
		&dwType, (BYTE *) string, &dwSize);

	if (lReturn == ERROR_SUCCESS)
		sVal = string;

	return lReturn;
}

LONG CRegKey::Read(const char* pszKey, BYTE* pData, DWORD& dwLen) 
{
	ASSERT(m_hKey);
	ASSERT(pszKey);

	DWORD dwType;

	return RegQueryValueEx(m_hKey, (LPSTR) pszKey, NULL,
		&dwType, pData, &dwLen);

}

#ifndef _NOT_USING_MFC_

CString CRegKey::GetAppRegPath(LPCTSTR szAppName)
{
	CString sRegPath, sAppName;

	if (szAppName && strlen(szAppName))
		sAppName = szAppName;
	else
		sAppName = AfxGetAppName();

	// construct reg path
	sRegPath = "Software\\";
	sRegPath += CString(AfxGetApp()->m_pszRegistryKey);
	sRegPath += '\\';
	sRegPath += sAppName;
	sRegPath += '\\';

	return sRegPath;
}

#endif
