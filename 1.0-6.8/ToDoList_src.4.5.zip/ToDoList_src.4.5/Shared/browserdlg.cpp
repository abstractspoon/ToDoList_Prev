// browserdlg.cpp : implementation file
//

#include "stdafx.h"
#include "browserdlg.h"

#include <afxdisp.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBrowserDlg dialog


CBrowserDlg::CBrowserDlg() : CRuntimeDlg()
{
	//{{AFX_DATA_INIT(CBrowserDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	AddControl("static", "", WS_CHILD, 0, 0, 0, 0, 0, (UINT)-1);
}


void CBrowserDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBrowserDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBrowserDlg, CDialog)
	//{{AFX_MSG_MAP(CBrowserDlg)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBrowserDlg message handlers

int CBrowserDlg::DoModal(LPCTSTR szCaption, LPCTSTR szUrlPath, CWnd* pParentWnd)
{
	m_sUrl = szUrlPath;

	return CRuntimeDlg::DoModal(szCaption, (DWORD)RTD_DEFSTYLE | WS_THICKFRAME, (DWORD)RTD_DEFEXSTYLE,
								rectAuto, pParentWnd);
}

BOOL CBrowserDlg::OnInitDialog() 
{
	CRuntimeDlg::OnInitDialog();

	AfxEnableControlContainer();
	
	if (m_browser.Create("", WS_CHILD | WS_TABSTOP | WS_VISIBLE, CRect(0, 0, 400, 400),
					this, 1))
	{
		AutoFit();
		CenterWindow();
		
		if (!m_sUrl.IsEmpty())
		{
			COleVariant vFlags(0L), vFrame(""), vData(""), vHeaders("");
			m_browser.Navigate(m_sUrl, vFlags, vFrame, vData, vHeaders);
		}
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CBrowserDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	if (m_browser.GetSafeHwnd())
		m_browser.MoveWindow(0, 0, cx, cy);
}
