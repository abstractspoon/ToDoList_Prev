// ToDoCtrlData.cpp: implementation of the CToDoCtrlData class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ToDoCtrl.h"
#include "ToDoCtrlData.h"

#include "..\shared\xmlfile.h"
#include "..\shared\timeedit.h"

#include <float.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const int MAX_TDPRIORITY = 10;
const int MIN_TDPRIORITY = 0;

CToDoCtrlData::CToDoCtrlData(CTreeCtrl& tree, const CWordArray& aStyles) : 
	m_tree(tree), m_aStyles(aStyles)
{
	
}

CToDoCtrlData::~CToDoCtrlData()
{
	
}

int CToDoCtrlData::FindTasks(const SEARCHPARAMS& params, CDWordArray& aResults) const
{
	if (!GetTaskCount())
		return 0;
	
	HTREEITEM hti = m_tree.GetNextItem(NULL, TVGN_CHILD);
	
	while (hti)
	{
		FindTasks(hti, params, aResults);
		hti = m_tree.GetNextItem(hti, TVGN_NEXT);
	}
	
	// else
	return aResults.GetSize();
}

int CToDoCtrlData::FindTasks(HTREEITEM hti, const SEARCHPARAMS& params, CDWordArray& aResults) const
{
	if (TaskMatches(hti, params))
		aResults.Add(m_tree.GetItemData(hti));
	
	// also check children and their children recursively
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	
	while (htiChild)
	{
		FindTasks(htiChild, params, aResults);
		
		// next
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
	
	return aResults.GetSize();
}

DWORD CToDoCtrlData::FindFirstTask(const SEARCHPARAMS& params) const
{
	if (!GetTaskCount())
		return 0;
	
	HTREEITEM hti = m_tree.GetNextItem(NULL, TVGN_CHILD);
	DWORD dwTaskID = 0;
	
	while (hti && !dwTaskID)
	{
		dwTaskID = FindFirstTask(hti, params);
		hti = m_tree.GetNextItem(hti, TVGN_NEXT);
	}
	
	// else
	return dwTaskID;
}

DWORD CToDoCtrlData::FindFirstTask(HTREEITEM hti, const SEARCHPARAMS& params) const
{
	if (TaskMatches(hti, params))
		return m_tree.GetItemData(hti);
	
	// also check children and their children recursively
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	DWORD dwTaskID = 0;
	
	while (htiChild && !dwTaskID)
	{
		dwTaskID = FindFirstTask(htiChild, params);
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
	
	return dwTaskID;
}

BOOL CToDoCtrlData::TaskMatches(HTREEITEM hti, const SEARCHPARAMS& params) const
{
	TODOITEM tdi;
	
	if (!GetTask(hti, tdi))
		return 0;
	
	BOOL bMatch = FALSE;
	DWORD dwID = m_tree.GetItemData(hti);
	
	BOOL bIncDone = (params.dwFlags & FIND_INCLUDEDONE);
	BOOL bIsDone = tdi.IsDone();
	
	switch (params.nFindWhat)
	{
	case FIND_TITLECOMMENTS:
		if (bIncDone || !bIsDone)
			bMatch = (TaskMatches(tdi.sTitle, params) || TaskMatches(tdi.sComments, params));
		break;
		
	case FIND_ALLOCTO:
		if (bIncDone || !bIsDone)
			bMatch = TaskMatches(tdi.sAllocTo, params);
		break;
		
	case FIND_ALLOCBY:
		if (bIncDone || !bIsDone)
			bMatch = TaskMatches(tdi.sAllocBy, params);
		break;
		
	case FIND_STATUS:
		if (bIncDone || !bIsDone)
			bMatch = TaskMatches(tdi.sStatus, params);
		break;
		
	case FIND_CATEGORY:
		if (bIncDone || !bIsDone)
			bMatch = TaskMatches(tdi.sCategory, params);
		break;
		
	case FIND_STARTDATE:
		if (tdi.HasStart() && (bIncDone || !bIsDone))
			bMatch = TaskMatches(tdi.dateStart, params);
		break;
		
	case FIND_DUEDATE:
		if (tdi.HasDue() && (bIncDone || !bIsDone))
			bMatch = TaskMatches(tdi.dateDue, params);
		break;
		
	case FIND_DONEDATE:
		if (tdi.IsDone())
			bMatch = TaskMatches(tdi.dateDone, params);
		break;
		
	case FIND_PRIORITY:
		if (bIncDone || !bIsDone)
			bMatch = TaskMatches(tdi.nPriority, params);
		break;
		
	case FIND_TASKID:
		if (bIncDone || !bIsDone)
			bMatch = TaskMatches((int)dwID, params);
		break;
		
	case FIND_PERCENTDONE:
		if (bIncDone || !bIsDone)
			bMatch = TaskMatches(tdi.nPercentDone, params);
		break;
		
	case FIND_TIMEEST:
		if (bIncDone || !bIsDone)
			bMatch = TaskMatches(tdi.dTimeEstimate, params);
		break;
		
	case FIND_TIMESPENT:
		if (bIncDone || !bIsDone)
			bMatch = TaskMatches(tdi.dTimeSpent, params);
		break;
	}
	
	return bMatch;
}

BOOL CToDoCtrlData::TaskMatches(const COleDateTime& date, const SEARCHPARAMS& params)
{
	return (date >= params.dateFrom && date <= params.dateTo);
}

BOOL CToDoCtrlData::TaskMatches(const CString& sText, const SEARCHPARAMS& params)
{
	CStringArray aWords;
	
	if (!ParseSearchString(params.sText, aWords))
		return FALSE;
	
	BOOL bMatchCase = (params.dwFlags & FIND_MATCHCASE);
	BOOL bMatchWholeWord = (params.dwFlags & FIND_MATCHWHOLEWORD);
	
	// cycle all the words
	for (int nWord = 0; nWord < aWords.GetSize(); nWord++)
	{
		CString sWord = aWords.GetAt(nWord);
		
		if (FindWord(sWord, sText, bMatchCase, bMatchWholeWord))
			return TRUE;
	}
	
	return FALSE;
}

BOOL CToDoCtrlData::TaskMatches(const double& dValue, const SEARCHPARAMS& params)
{
	return (dValue >= params.dFrom && dValue <= params.dTo);
}

BOOL CToDoCtrlData::TaskMatches(int nValue, const SEARCHPARAMS& params)
{
	return (nValue >= params.nFrom && nValue <= params.nTo);
}

BOOL CToDoCtrlData::FindWord(LPCTSTR szWord, LPCTSTR szText, BOOL bMatchCase, BOOL bMatchWholeWord)
{
	CString sWord(szWord), sText(szText);
	
	if (sWord.GetLength() > sText.GetLength())
		return FALSE;
	
	sWord.TrimLeft();
	sWord.TrimRight();
	
	if (!bMatchCase)
	{
		sWord.MakeUpper();
		sText.MakeUpper();
	}
	
	int nFind = sText.Find(sWord);
	
	if (nFind == -1)
		return FALSE;
	
	else if (bMatchWholeWord) // test whole word
	{
		const CString DELIMS("()-\\/{}[]:;,. ?\"'");
		
		// prior and next chars must be delimeters
		char cPrevChar = 0, cNextChar = 0;
		
		// prev
		if (nFind == 0) // word starts at start
			cPrevChar = ' '; // known delim
		else
			cPrevChar = sText[nFind - 1];
		
		// next
		if ((nFind + sWord.GetLength() + 1) < sText.GetLength())
			cNextChar = sText[nFind + sWord.GetLength()];
		else
			cNextChar = ' '; // known delim
		
		if (DELIMS.Find(cPrevChar) == -1 || DELIMS.Find(cNextChar) == -1)
			return FALSE;
	}
	
	return TRUE;
}

int CToDoCtrlData::ParseSearchString(LPCTSTR szLookFor, CStringArray& aWords)
{
	aWords.RemoveAll();
	
	// parse on spaces unless enclosed in double-quotes
	int nLen = lstrlen(szLookFor);
	BOOL bInQuotes = FALSE, bAddWord = FALSE;
	CString sWord;
	
	for (int nPos = 0; nPos < nLen; nPos++)
	{
		switch (szLookFor[nPos])
		{
		case ' ': // word break
			if (bInQuotes)
				sWord += szLookFor[nPos];
			else
				bAddWord = TRUE;
			break;
			
		case '\"':
			// whether its the start or end we add the current word
			// and flip bInQuotes
			bInQuotes = !bInQuotes;
			bAddWord = TRUE;
			break;
			
		default: // everything else
			sWord += szLookFor[nPos];
			
			// also if its the last char then add it
			bAddWord = (nPos == nLen - 1);
			break;
		}
		
		if (bAddWord)
		{
			sWord.TrimLeft();
			sWord.TrimRight();
			
			if (!sWord.IsEmpty())
				aWords.Add(sWord);
			
			sWord.Empty(); // next word
		}
	}
	
	return aWords.GetSize();
}

CString CToDoCtrlData::GetTaskTitle(DWORD dwID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
		return tdi.sTitle;
	
	return "";
}

CString CToDoCtrlData::GetTaskComments(DWORD dwID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
		return tdi.sComments;
	
	return "";
}

double CToDoCtrlData::GetTaskTimeEstimate(DWORD dwID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
		return tdi.dTimeEstimate;
	
	return 0;
}

double CToDoCtrlData::GetTaskTimeSpent(DWORD dwID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
		return tdi.dTimeSpent;
	
	return 0;
}

double CToDoCtrlData::GetTaskTimeEstimate(DWORD dwID, int& nUnits) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
	{
		nUnits = tdi.nTimeEstUnits;
		return tdi.dTimeEstimate;
	}
	
	return 0;
}

double CToDoCtrlData::GetTaskTimeSpent(DWORD dwID, int& nUnits) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
	{
		nUnits = tdi.nTimeSpentUnits;
		return tdi.dTimeSpent;
	}
	
	return 0;
}

CString CToDoCtrlData::GetTaskAllocTo(DWORD dwID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
		return tdi.sAllocTo;
	
	return "";
}

CString CToDoCtrlData::GetTaskAllocBy(DWORD dwID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
		return tdi.sAllocBy;
	
	return "";
}

CString CToDoCtrlData::GetTaskStatus(DWORD dwID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
		return tdi.sStatus;
	
	return "";
}

CString CToDoCtrlData::GetTaskCategory(DWORD dwID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
		return tdi.sCategory;
	
	return "";
}

COLORREF CToDoCtrlData::GetTaskColor(DWORD dwID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
		return tdi.color;
	
	return 0;
}

int CToDoCtrlData::GetTaskPriority(DWORD dwID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
		return tdi.nPriority;
	
	return 0;
}

COleDateTime CToDoCtrlData::GetTaskDueDate(DWORD dwID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
		return tdi.dateDue;
	
	return COleDateTime();
}

COleDateTime CToDoCtrlData::GetTaskStartDate(DWORD dwID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
		return tdi.dateStart;
	
	return COleDateTime();
}

COleDateTime CToDoCtrlData::GetTaskDoneDate(DWORD dwID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
		return tdi.dateDone;
	
	return COleDateTime();
}

BOOL CToDoCtrlData::IsTaskDone(DWORD dwID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
		return tdi.IsDone();
	
	return FALSE;
}

BOOL CToDoCtrlData::IsTaskDue(DWORD dwID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
		return tdi.IsDue();
	
	return FALSE;
}

int CToDoCtrlData::GetTaskPercent(DWORD dwID, BOOL bCheckIfDone) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
	{
		if (bCheckIfDone)
			return tdi.IsDone() ? 100 : tdi.nPercentDone;
		else
			return tdi.nPercentDone;
	}
	
	return 0;
}

CString CToDoCtrlData::GetTaskFileRef(DWORD dwID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwID, tdi))
		return tdi.sFileRefPath;
	
	return "";
}

double CToDoCtrlData::GetTaskTimeEstimate(const HTREEITEM hti) const
{
	return GetTaskTimeEstimate(GetTaskID(hti));
}

CString CToDoCtrlData::GetTaskAllocTo(const HTREEITEM hti) const
{
	return GetTaskAllocTo(GetTaskID(hti));
}

CString CToDoCtrlData::GetTaskAllocBy(const HTREEITEM hti) const
{
	return GetTaskAllocBy(GetTaskID(hti));
}

CString CToDoCtrlData::GetTaskStatus(const HTREEITEM hti) const
{
	return GetTaskStatus(GetTaskID(hti));
}

CString CToDoCtrlData::GetTaskCategory(const HTREEITEM hti) const
{
	return GetTaskCategory(GetTaskID(hti));
}

COLORREF CToDoCtrlData::GetTaskColor(const HTREEITEM hti) const
{
	return GetTaskColor(GetTaskID(hti));
}

int CToDoCtrlData::GetTaskPriority(const HTREEITEM hti) const
{
	return GetTaskPriority(GetTaskID(hti));
}

BOOL CToDoCtrlData::IsParentTaskDone(HTREEITEM hti) const
{
	if (!hti)
		return FALSE;
	
	HTREEITEM htiParent = m_tree.GetParentItem(hti);
	
	if (!htiParent)
		return FALSE;
	
	TODOITEM tdiParent;
	
	if (!GetTask(GetTaskID(htiParent), tdiParent))
		return FALSE;
	
	if (tdiParent.IsDone())
		return TRUE;
	
	// else check parent's parent
	return IsParentTaskDone(htiParent);
}


int CToDoCtrlData::AreChildTasksDone(HTREEITEM hti) const
{
	if (!m_tree.ItemHasChildren(hti))
		return -1;
	
	// else check children and their children recursively
	TODOITEM tdi;
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	
	while (htiChild)
	{
		int bDone = IsTaskDone(htiChild, TDCCHECKCHILDREN);
		
		if (!bDone)
			return FALSE;
		
		// next
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
	
	return TRUE;
}

BOOL CToDoCtrlData::IsTaskDue(HTREEITEM hti) const
{
	return IsTaskDue(GetTaskID(hti));
}

BOOL CToDoCtrlData::DeleteTask(HTREEITEM hti)
{
	// do children first to ensure entire branch is deleted
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	
	while (htiChild)
	{
		DeleteTask(htiChild);
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
	
	// then this item
	DWORD dwID = GetTaskID(hti);
	
	if (m_tree.DeleteItem(hti))
	{
		// delete mapping
		DeleteTask(dwID);
		return TRUE;
	}
	
	return FALSE;
}

void CToDoCtrlData::Sort(TDC_SORTBY nBy, BOOL bAscending)
{
	CHTIMap mapHTI;
	BuildHTIMap(mapHTI);
	
	TDSORTSTRUCT ss = { this, &mapHTI, nBy, bAscending };
	
	Sort(NULL, ss);
}

void CToDoCtrlData::Sort(HTREEITEM hti, const TDSORTSTRUCT& ss)
{
	// don't sort if not expanded and not the root item (hti == NULL)
	if (hti && ss.pData->HasStyle(TDCS_SORTVISIBLETASKSONLY))
	{
		if (!(m_tree.GetItemState(hti, TVIS_EXPANDED) & TVIS_EXPANDED))
			return;
	}
	
	TVSORTCB tvs = { hti, CompareFunc, (LPARAM)&ss };
	
	// sort this items children first
	m_tree.SortChildrenCB(&tvs);
	
	// then its childrens children
	HTREEITEM htiChild = hti ? m_tree.GetChildItem(hti) : m_tree.GetNextItem(NULL, TVGN_CHILD);
	
	while (htiChild)
	{
		Sort(htiChild, ss);
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
}

int CALLBACK CToDoCtrlData::CompareFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	TDSORTSTRUCT* pSS = (TDSORTSTRUCT*)lParamSort;
	
	// sort by id can be optimized since the IDs are the lParams
	if (pSS->nSortBy == TDC_SORTBYID)
		return pSS->bAscending ? lParam1 - lParam2 : lParam2 - lParam1;
	
	// else all the rest require the task lookup
	TODOITEM tdi1, tdi2;
	
	VERIFY(pSS->pData->GetTask(lParam1, tdi1));
	VERIFY(pSS->pData->GetTask(lParam2, tdi2));
	
	HTREEITEM hti1 = NULL, hti2 = NULL;
	VERIFY(pSS->pMapHTItems->Lookup(lParam1, hti1) && hti1);
	VERIFY(pSS->pMapHTItems->Lookup(lParam2, hti2) && hti2);

	switch (pSS->nSortBy)
	{
	case TDC_SORTBYNAME:
		return Compare(tdi1.sTitle, tdi2.sTitle, pSS->bAscending);
		
	case TDC_SORTBYDONE:
		{
			BOOL bDone1 = tdi1.IsDone(); // default
			BOOL bDone2 = tdi2.IsDone(); // default
			
			if (pSS->pData->HasStyle(TDCS_TREATSUBCOMPLETEDASDONE)) // check 'good as' too
			{
				if (!bDone1 && pSS->pData->AreChildTasksDone(hti1) == 1)
					bDone1 = TRUE;
				
				if (!bDone2 && pSS->pData->AreChildTasksDone(hti2) == 1)
						bDone2 = TRUE;
			}
			
			return Compare(bDone1, bDone2, pSS->bAscending);
		}
		
	case TDC_SORTBYDONEDATE:
		{
			COleDateTime date1 = tdi1.dateDone; // default
			COleDateTime date2 = tdi2.dateDone; // default
			
			// see if tasks are as good as done too
			if (pSS->pData->HasStyle(TDCS_TREATSUBCOMPLETEDASDONE))
			{
				if (date1 <= 0 && pSS->pData->AreChildTasksDone(hti1) == 1)
					date1 = 0.1; // will sort lowest
				
				if (date2 <= 0 && pSS->pData->AreChildTasksDone(hti2) == 1)
					date2 = 0.1; // will sort lowest
			}
			return Compare(date1, date2, pSS->bAscending);
		}
		
	case TDC_SORTBYDUEDATE:
		{
			double date1 = 0.0;
			double date2 = 0.0;

			BOOL bTreatSubCompleteDone = pSS->pData->HasStyle(TDCS_TREATSUBCOMPLETEDASDONE);
			BOOL bUseEarliestDueDate = pSS->pData->HasStyle(TDCS_USEEARLIESTDUEDATE);
			
			if (!tdi1.IsDone())
			{
				BOOL bSubComplete = bTreatSubCompleteDone && pSS->pData->AreChildTasksDone(hti1) == 1;
				
				if (!bSubComplete)
				{
					if (bUseEarliestDueDate)
						date1 = pSS->pData->GetEarliestDueDate(hti1, tdi1);
					else
						date1 = tdi1.dateDue;
				}
			}
			
			if (!tdi2.IsDone())
			{
				BOOL bSubComplete = bTreatSubCompleteDone && pSS->pData->AreChildTasksDone(hti2) == 1;
				
				if (!bSubComplete)
				{
					if (bUseEarliestDueDate)
						date2 = pSS->pData->GetEarliestDueDate(hti2, tdi2);
					else
						date2 = tdi2.dateDue;
				}
			}
			
			// compare
			return Compare(date1, date2, pSS->bAscending);
		}
		
	case TDC_SORTBYSTARTDATE:
		return Compare(tdi1.dateStart, tdi2.dateStart, pSS->bAscending);
		
	case TDC_SORTBYPRIORITY:
		{
			// done items have even less than zero priority!
			// and due items have greater than the highest priority
			int nPriority1 = tdi1.nPriority; // default
			int nPriority2 = tdi2.nPriority; // default
			
			BOOL bUseHighestPriority = pSS->pData->HasStyle(TDCS_USEHIGHESTPRIORITY);

			// item1
			if (pSS->pData->IsTaskDone(hti1, TDCCHECKALL))
				nPriority1 = -1;

			else if (tdi1.IsDue())
				nPriority1 = 11;
			
			else if (bUseHighestPriority)
				nPriority1 = pSS->pData->GetHighestPriority(hti1, tdi1);
			
			// item2
			if (pSS->pData->IsTaskDone(hti2, TDCCHECKALL))
				nPriority2 = -1;
			
			else if (tdi2.IsDue())
				nPriority2 = 11;
			
			else if (bUseHighestPriority)
				nPriority2 = pSS->pData->GetHighestPriority(hti2, tdi2);
			
			return Compare(nPriority1, nPriority2, pSS->bAscending);
		}
		
	case TDC_SORTBYCOLOR:
		return Compare((int)tdi1.color, (int)tdi2.color, pSS->bAscending);
		
	case TDC_SORTBYALLOCTO:
		return Compare(tdi1.sAllocTo, tdi2.sAllocTo, pSS->bAscending);
		
	case TDC_SORTBYALLOCBY:
		return Compare(tdi1.sAllocBy, tdi2.sAllocBy, pSS->bAscending);
		
	case TDC_SORTBYSTATUS:
		return Compare(tdi1.sStatus, tdi2.sStatus, pSS->bAscending);
		
	case TDC_SORTBYCATEGORY:
		return Compare(tdi1.sCategory, tdi2.sCategory, pSS->bAscending);
		
	case TDC_SORTBYPERCENT:
		{
			int nPercent1 = pSS->pData->CalcPercentDone(hti1, tdi1);
			int nPercent2 = pSS->pData->CalcPercentDone(hti2, tdi2);
			
			return Compare(nPercent1, nPercent2, pSS->bAscending);
		}
		
	case TDC_SORTBYTIMEEST:
		{
			double dTime1 = pSS->pData->CalcTimeEstimate(hti1, tdi1, TDCTU_HOURS);
			double dTime2 = pSS->pData->CalcTimeEstimate(hti2, tdi2, TDCTU_HOURS);
			
			return Compare(dTime1, dTime2, pSS->bAscending);
		}
		break;
		
	case TDC_SORTBYTIMESPENT:
		{
			double dTime1 = pSS->pData->CalcTimeSpent(hti1, tdi1, TDCTU_HOURS);
			double dTime2 = pSS->pData->CalcTimeSpent(hti2, tdi2, TDCTU_HOURS);
			
			return Compare(dTime1, dTime2, pSS->bAscending);
		}
		break;
	}
	
	return 0;
}

int CToDoCtrlData::Compare(const COleDateTime& date1, const COleDateTime& date2, BOOL bAscending)
{
    int nCompare = 0;
	
	if (date1 > 0 && date2 > 0)
        nCompare = (date1 < date2) ? -1 : (date1 > date2) ? 1 : 0;
	
    else if (date1 > 0)
        nCompare = 1;
	
	else if (date2 > 0)
		nCompare = -1;
	
	// else
    return bAscending ? nCompare : -nCompare;
}

int CToDoCtrlData::Compare(const CString& sText1, const CString& sText2, BOOL bAscending)
{
    int nCompare = sText1.CompareNoCase(sText2);
	
    return bAscending ? nCompare : -nCompare;
}

int CToDoCtrlData::Compare(int nNum1, int nNum2, BOOL bAscending)
{
    int nCompare = (nNum1 - nNum2);
	
    return bAscending ? nCompare : -nCompare;
}

int CToDoCtrlData::Compare(const double& dNum1, const double& dNum2, BOOL bAscending)
{
    int nCompare = (dNum1 < dNum2) ? -1 : (dNum1 > dNum2) ? 1 : 0;
	
    return bAscending ? nCompare : -nCompare;
}

int CToDoCtrlData::GetItemPos(HTREEITEM hti, HTREEITEM htiSearch) const
{
	// traverse the entire tree util we find the item
	if (!htiSearch)
		htiSearch = TVI_ROOT;
	
	int nPos = 1; // always 1-based
	HTREEITEM htiChild = m_tree.GetChildItem(htiSearch);
	
	while (htiChild)
	{
		if (htiChild == hti)
			return nPos;
		
		// try items children
		int nChildPos = GetItemPos(hti, htiChild);
		
		if (nChildPos)
			return nChildPos;
		
		nPos++;
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
	
	return 0; // not found
}

void CToDoCtrlData::ResetCachedCalculations()
{
	// sets the bNeedRecalc flag on all items
	POSITION pos = m_mapTDItems.GetStartPosition();
	TODOITEM tdi;
	DWORD dwID;

	while (pos)
	{
		m_mapTDItems.GetNextAssoc(pos, dwID, tdi);

		tdi.ResetCalcs();
		m_mapTDItems[dwID] = tdi;
	}
}

/*
int CToDoCtrlData::CalcPercentDone(const HTREEITEM hti, const TODOITEM& tdi) const
{
	// simple optimization
	if (tdi.IsDone())
		return 100;
	
	// else
	double dPercent = (double)tdi.nPercentDone; // default

	BOOL bHasChildren = m_tree.ItemHasChildren(hti);
	
	if (HasStyle(TDCS_AUTOCALCPERCENTDONE) && !bHasChildren)
	{
		double dTimeEst = CTimeEdit::GetTime(tdi.dTimeEstimate, tdi.nTimeEstUnits, TEU_HOURS);

		if (dTimeEst)
		{
			double dTimeSpent = CTimeEdit::GetTime(tdi.dTimeSpent, tdi.nTimeSpentUnits, TEU_HOURS);
			dPercent = min(100, (dTimeSpent * 100) / dTimeEst);
		}
		else
			dPercent = 0;
	}
	else if (HasStyle(TDCS_AVERAGEPERCENTSUBCOMPLETION) && bHasChildren)
	{
		double dTotalWeighting = 0;
		HTREEITEM htiChild = m_tree.GetChildItem(hti);
		
		while (htiChild)
		{
			TODOITEM tdiChild;
			VERIFY(GetTask(htiChild, tdiChild));
			
			if (!tdiChild.IsDone() || HasStyle(TDCS_INCLUDEDONEINAVERAGECALC))
			{
				double dChildPercent = (double)CalcPercentDone(htiChild, tdiChild);
				double dChildWeight = 1;

				if (HasStyle(TDCS_WEIGHTPERCENTCALCBYTIMEEST))
					dChildWeight *= CTimeEdit::GetTime(tdiChild.dTimeEstimate, tdiChild.nTimeEstUnits, TEU_HOURS);

				if (HasStyle(TDCS_WEIGHTPERCENTCALCBYPRIORITY))
					dChildWeight *= tdiChild.nPriority;

				dTotalWeighting += dChildWeight;
				dPercent += (dChildPercent * dChildWeight);
			}
			
			htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
		}
		
		// average
		if (dTotalWeighting > 0)
			dPercent /= dTotalWeighting;
		else
			ASSERT(dPercent == 0);
	}
	
	return (int)dPercent;
}
*/

int CToDoCtrlData::CalcPercentDone(const HTREEITEM hti, const TODOITEM& tdi) const
{
	// simple optimization
	if (!HasStyle(TDCS_AVERAGEPERCENTSUBCOMPLETION))
	{
		if (tdi.IsDone())
			return 100;
		
		else if(HasStyle(TDCS_AUTOCALCPERCENTDONE))
			return CalcPercentFromTime(hti, tdi);

		else
			return tdi.nPercentDone;
	}
	
	// else
	double dTotalPercent = 0, dTotalWeighting = 0, dPercent = 0;
	
	SumPercentDone(hti, tdi, dTotalPercent, dTotalWeighting);
	
	if (dTotalWeighting > 0)
		dPercent = dTotalPercent / dTotalWeighting;
	else
		ASSERT (dTotalPercent == 0); // sanity check
	
	return (int)dPercent;
}

int CToDoCtrlData::CalcPercentFromTime(const HTREEITEM hti, const TODOITEM& tdi) const
{
	ASSERT (HasStyle(TDCS_AUTOCALCPERCENTDONE)); // sanity check
	
	double dSpent = CalcTimeSpent(hti, tdi, TEU_HOURS);
	double dEstimate = CalcTimeEstimate(hti, tdi, TEU_HOURS);

	if (dSpent > 0 && dEstimate > 0)
		return min(100, (int)(100 * dSpent / dEstimate));
	else
		return 0;
}

void CToDoCtrlData::SumPercentDone(const HTREEITEM hti, const TODOITEM& tdi,
                                   double& dTotalPercent, double& dTotalWeighting) const
{
	ASSERT (HasStyle(TDCS_AVERAGEPERCENTSUBCOMPLETION)); // sanity check
	
	if (!m_tree.ItemHasChildren(hti))
	{
		double dWeighting = 1; // default
		double dPercent = 0;

		// base percent
		if (tdi.IsDone())
			dPercent = 100;
		
		else if(HasStyle(TDCS_AUTOCALCPERCENTDONE))
			dPercent = CalcPercentFromTime(hti, tdi);

		else
			dPercent = tdi.nPercentDone;
		
		// weighting
		if (HasStyle(TDCS_WEIGHTPERCENTCALCBYTIMEEST))
			dWeighting *= CTimeEdit::GetTime(tdi.dTimeEstimate,	tdi.nTimeEstUnits, TEU_HOURS);
		
		if (HasStyle(TDCS_WEIGHTPERCENTCALCBYPRIORITY))
			dWeighting *= tdi.nPriority;
		
		dPercent *= dWeighting;
		
		dTotalWeighting += dWeighting;
		dTotalPercent += dPercent;
	}
	else // aggregate child percentages
	{
		HTREEITEM htiChild = m_tree.GetChildItem(hti);
		
		while (htiChild)
		{
			TODOITEM tdiChild;
			VERIFY(GetTask(htiChild, tdiChild));
			
			if (!tdiChild.IsDone() || HasStyle(TDCS_INCLUDEDONEINAVERAGECALC))
			{
				SumPercentDone(htiChild, tdiChild, dTotalPercent, dTotalWeighting);
			}
			
			htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
		}
	}
}

double CToDoCtrlData::CalcTimeEstimate(const HTREEITEM hti, const TODOITEM& tdi, int nUnits) const
{
	double dTime = 0;
	
	if (!m_tree.ItemHasChildren(hti))
	{
		dTime = CTimeEdit::GetTime(tdi.dTimeEstimate, tdi.nTimeEstUnits, nUnits);
		
		if (HasStyle(TDCS_USEPERCENTDONEINTIMEEST))
		{
			if (tdi.IsDone())
				dTime = 0;
			else
				dTime *= ((100 - tdi.nPercentDone) / 100.0); // estimating time left
		}
	}
	else // children
	{
		HTREEITEM htiChild = m_tree.GetChildItem(hti);
		
		while (htiChild)
		{
			TODOITEM tdiChild;
			VERIFY(GetTask(htiChild, tdiChild));
			
			dTime += CalcTimeEstimate(htiChild, tdiChild, nUnits);
			
			htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
		}
	}
	
	return dTime;
}

double CToDoCtrlData::CalcTimeSpent(const HTREEITEM hti, const TODOITEM& tdi, int nUnits) const
{
	double dTime = 0;
	
	if (!m_tree.ItemHasChildren(hti))
	{
		dTime = CTimeEdit::GetTime(tdi.dTimeSpent, tdi.nTimeSpentUnits, nUnits);
	}
	else // children
	{
		HTREEITEM htiChild = m_tree.GetChildItem(hti);
		
		while (htiChild)
		{
			TODOITEM tdiChild;
			VERIFY(GetTask(htiChild, tdiChild));
			
			dTime += CalcTimeSpent(htiChild, tdiChild, nUnits);
			
			htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
		}
	}
	
	return dTime;
}

void CToDoCtrlData::BuildHTIMap(CHTIMap& mapHTI)
{
	mapHTI.RemoveAll();
	
	// traverse toplevel items
	HTREEITEM hti = m_tree.GetNextItem(NULL, TVGN_CHILD);
	
	while (hti)
	{
		UpdateHTIMapEntry(mapHTI, hti);
		hti = m_tree.GetNextItem(hti, TVGN_NEXT);
	}
}

void CToDoCtrlData::UpdateHTIMapEntry(CHTIMap& mapHTI, HTREEITEM hti)
{
	// update our own mapping
	mapHTI[GetTaskID(hti)] = hti;
	
	// then our children
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	
	while (htiChild)
	{
		UpdateHTIMapEntry(mapHTI, htiChild);
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
}

HTREEITEM CToDoCtrlData::GetTopLevelTask(HTREEITEM htiSubtask) const
{
	if (!htiSubtask)
		return NULL;
	
	HTREEITEM htiParent = m_tree.GetParentItem(htiSubtask);
	
	while (htiParent)
	{
		htiSubtask = htiParent; // cache this because the next parent might be the root
		htiParent = m_tree.GetParentItem(htiSubtask);
	}
	
	return htiSubtask; // return the one before the root
}

double CToDoCtrlData::GetEarliestDueDate(HTREEITEM hti) const
{
	TODOITEM tdi;
	VERIFY(GetTask(hti, tdi));

	return GetEarliestDueDate(hti, tdi);
}

int CToDoCtrlData::GetHighestPriority(HTREEITEM hti) const
{
	TODOITEM tdi;
	VERIFY(GetTask(hti, tdi));

	return GetHighestPriority(hti, tdi);
}

int CToDoCtrlData::CalcPercentDone(const HTREEITEM hti) const
{
	TODOITEM tdi;
	VERIFY(GetTask(hti, tdi));

	return CalcPercentDone(hti, tdi);
}

double CToDoCtrlData::CalcTimeEstimate(const HTREEITEM hti, int nUnits) const
{
	TODOITEM tdi;
	VERIFY(GetTask(hti, tdi));

	return CalcTimeEstimate(hti, tdi, nUnits);
}

double CToDoCtrlData::CalcTimeSpent(const HTREEITEM hti, int nUnits) const
{
	TODOITEM tdi;
	VERIFY(GetTask(hti, tdi));

	return CalcTimeSpent(hti, tdi, nUnits);
}

BOOL CToDoCtrlData::IsTaskFullyDone(const HTREEITEM hti, const TODOITEM& tdi, BOOL bCheckSiblings) const
{
	if (bCheckSiblings)
	{
		HTREEITEM htiParent = m_tree.GetParentItem(hti);
		HTREEITEM htiSibling = htiParent ? m_tree.GetChildItem(htiParent) : 
		m_tree.GetNextItem(NULL, TVGN_CHILD);
		
		while (htiSibling)
		{
			if (htiSibling != hti) // else we would recurse
			{
				TODOITEM tdiSibling;
				
				if (GetTask(htiSibling, tdiSibling))
				{
					// exit on first failure
					if (!IsTaskFullyDone(htiSibling, tdiSibling, FALSE)) // FALSE: we're doing the siblings
						return FALSE;
				}
			}
			
			htiSibling = m_tree.GetNextItem(htiSibling, TVGN_NEXT);
		}
	}
	
	// check children
	if (m_tree.ItemHasChildren(hti))
	{
		HTREEITEM htiChild = m_tree.GetChildItem(hti);
		
		while (htiChild)
		{
			TODOITEM tdiChild;
			
			if (GetTask(htiChild, tdiChild))
			{
				// exit on first failure
				if (!IsTaskFullyDone(htiChild, tdiChild, FALSE)) // FALSE: we're doing the siblings
					return FALSE;
			}
			
			htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
		}
	}
	else 
		return tdi.IsDone(); // no children => relies on our state only
	
	// if we got here there were no sibling or child failures
	return TRUE;
}

double CToDoCtrlData::GetEarliestDueDate(HTREEITEM hti, const TODOITEM& tdi) const
{
	ASSERT (hti);
	
	// some optimizations
	if (!m_tree.ItemHasChildren(hti))
		return tdi.dateDue;
	
	// check children
	double dEarliest = tdi.HasDue() ? tdi.dateDue : DBL_MAX;
	
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	
	while (htiChild)
	{
		TODOITEM tdiChild;
		
		if (!GetTask(htiChild, tdiChild))
			return 0;
		
		double dChildDue = GetEarliestDueDate(htiChild, tdiChild);
		
		if (dChildDue > 0 && dChildDue < dEarliest)
			dEarliest = dChildDue;
		
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
	
	return (dEarliest == DBL_MAX) ? 0 : dEarliest;
	
}

int CToDoCtrlData::GetHighestPriority(HTREEITEM hti, const TODOITEM& tdi) const
{
	ASSERT (hti);
	
	// some optimizations
	if (!m_tree.ItemHasChildren(hti))
		return tdi.nPriority;
	
	// check children
	int nHighest = MIN_TDPRIORITY;
	
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	
	while (htiChild)
	{
		TODOITEM tdiChild;
		
		if (!GetTask(htiChild, tdiChild))
			return MIN_TDPRIORITY;
		
		if (HasStyle(TDCS_INCLUDEDONEINPRIORITYCALC) || !tdiChild.IsDone())
		{
			int nChildHighest = GetHighestPriority(htiChild, tdiChild);
			
			// optimization
			if (nChildHighest == MAX_TDPRIORITY)
				return MAX_TDPRIORITY;
			else 
				nHighest = max(nChildHighest, nHighest);
		}

		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
	
	return max(tdi.nPriority, nHighest);
}

BOOL CToDoCtrlData::IsTaskDone(HTREEITEM hti, DWORD dwExtraCheck) const
{
	if (!hti)
		return FALSE;
	
	TODOITEM tdi;
	
	if (!GetTask(hti, tdi))
		return FALSE;
	
	if (tdi.IsDone())
		return TRUE;
	
	if (dwExtraCheck & TDCCHECKPARENT)
	{
		HTREEITEM htiParent = m_tree.GetParentItem(hti);
		
		if (htiParent && IsTaskDone(htiParent, TDCCHECKPARENT))
			return TRUE;
	}
	
	// else check children for 'good-as-done'
	BOOL bTreatSubCompleteDone = HasStyle(TDCS_TREATSUBCOMPLETEDASDONE);
	
	if ((dwExtraCheck & TDCCHECKCHILDREN) && bTreatSubCompleteDone)
	{
		if (AreChildTasksDone(hti) == 1)
			return TRUE;
	}
	
	// else return as is
	return (tdi.IsDone());
}

BOOL CToDoCtrlData::IsTaskTimeTrackable(HTREEITEM hti)
{
	if (!hti)
		return FALSE;
	
	if (m_tree.ItemHasChildren(hti) || IsTaskDone(hti, FALSE))
		return FALSE;

	return TRUE;
}

int CToDoCtrlData::SetTaskAttributeAsParent(HTREEITEM hti, TDC_ATTRIBUTE nAttrib)
{
	HTREEITEM htiParent = m_tree.GetParentItem(hti);
	
	if (!htiParent)
		return FALSE;
	
	DWORD dwID = m_tree.GetItemData(hti);
	DWORD dwParentID = m_tree.GetItemData(htiParent);
	
	switch (nAttrib)
	{
	case TDCA_TASKNAME:
		return SetTaskTitle(dwID, GetTaskTitle(dwParentID));
		
	case TDCA_DONEDATE:
		return SetTaskDoneDate(dwID, GetTaskDoneDate(dwParentID));
		break;
		
	case TDCA_DUEDATE:
		return SetTaskDueDate(dwID, GetTaskDueDate(dwParentID));
		break;
		
	case TDCA_STARTDATE:
		return SetTaskStartDate(dwID, GetTaskStartDate(dwParentID));
		break;
		
	case TDCA_PRIORITY:
		return SetTaskPriority(dwID, GetTaskPriority(dwParentID));
		break;
		
	case TDCA_COLOR:
		return SetTaskColor(dwID, GetTaskColor(dwParentID));
		break;
		
	case TDCA_ALLOCTO:
		return SetTaskAllocTo(dwID, GetTaskAllocTo(dwParentID));
		break;
		
	case TDCA_ALLOCBY:
		return SetTaskAllocBy(dwID, GetTaskAllocBy(dwParentID));
		break;
		
	case TDCA_STATUS:
		return SetTaskStatus(dwID, GetTaskStatus(dwParentID));
		break;
		
	case TDCA_CATEGORY:
		return SetTaskCategory(dwID, GetTaskCategory(dwParentID));
		break;
		
	case TDCA_PERCENT:
		return SetTaskPercent(dwID, GetTaskPercent(dwParentID, FALSE));
		break;
		
	case TDCA_TIMEEST:
		return SetTaskTimeEstimate(dwID, GetTaskTimeEstimate(dwParentID));
		break;
		
	case TDCA_FILEREF:
		return SetTaskFileRef(dwID, GetTaskFileRef(dwParentID));
		break;
		
	case TDCA_COMMENTS:
		return SetTaskComments(dwID, GetTaskComments(dwParentID));
		break;
	}
	
	// all else
	return FALSE;
}

void CToDoCtrlData::ApplyLastChangeToSubtasks(const HTREEITEM hti, const TODOITEM& tdi, TDC_ATTRIBUTE nAttrib)
{
	HTREEITEM htiChild = m_tree.GetChildItem(hti);
	TODOITEM tdiChild;
	
	while (htiChild)
	{
		DWORD dwIDChild = GetTaskID(htiChild);
		VERIFY (GetTask(dwIDChild, tdiChild));
		
		// apply the change based on nAttrib
		switch (nAttrib)
		{
		case TDCA_DONEDATE:
			tdiChild.dateDone = tdi.dateDone;
			break;
			
		case TDCA_DUEDATE:
			tdiChild.dateDue = tdi.dateDue;
			break;
			
		case TDCA_STARTDATE:
			tdiChild.dateStart = tdi.dateStart;
			break;
			
		case TDCA_PRIORITY:
			tdiChild.nPriority = tdi.nPriority;
			break;
			
		case TDCA_COLOR:
			tdiChild.color = tdi.color;
			break;
			
		case TDCA_ALLOCTO:
			tdiChild.sAllocTo = tdi.sAllocTo;
			break;
			
		case TDCA_ALLOCBY:
			tdiChild.sAllocBy = tdi.sAllocBy;
			break;
			
		case TDCA_STATUS:
			tdiChild.sStatus = tdi.sStatus;
			break;
			
		case TDCA_CATEGORY:
			tdiChild.sCategory = tdi.sCategory;
			break;
			
		case TDCA_PERCENT:
			tdiChild.nPercentDone = tdi.nPercentDone;
			break;
			
		case TDCA_TIMEEST:
			tdiChild.dTimeEstimate = tdi.dTimeEstimate;
			break;
			
		case TDCA_FILEREF:
			tdiChild.sFileRefPath = tdi.sFileRefPath;
			break;
			
		default:
			ASSERT (0);
			return;
		}
		
		// update task
		UpdateTask(dwIDChild, tdiChild);
		
		// and its children too
		if (m_tree.ItemHasChildren(htiChild))
			ApplyLastChangeToSubtasks(htiChild, tdiChild, nAttrib);
		
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
}

int CToDoCtrlData::SetTaskColor(DWORD dwID, COLORREF color)
{
	if (dwID)
	{
		TODOITEM tdi;
		
		if (GetTask(dwID, tdi))
		{
			// if the color is 0 then add 1 to discern from unset
			if (!color)
				color++;

			if (tdi.color != color)
			{
				tdi.color = color;
				UpdateTask(dwID, tdi);
				
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskComments(DWORD dwID, LPCTSTR szComments)
{
	if (dwID)
	{
		TODOITEM tdi;
		
		if (GetTask(dwID, tdi))
		{
			if (tdi.sComments != szComments)
			{
				tdi.sComments = szComments;
				UpdateTask(dwID, tdi);
				
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskTitle(DWORD dwID, LPCTSTR szTitle)
{
	if (dwID)
	{
		TODOITEM tdi;
		
		if (GetTask(dwID, tdi))
		{
			if (tdi.sTitle != szTitle)
			{
				tdi.sTitle = szTitle;
				UpdateTask(dwID, tdi);
				
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskPriority(DWORD dwID, int nPriority)
{
	if (dwID && nPriority >= 0 && nPriority <= 10)
	{
		TODOITEM tdi;
		
		if (GetTask(dwID, tdi))
		{
			if (tdi.nPriority != nPriority)
			{
				tdi.nPriority = nPriority;
				UpdateTask(dwID, tdi);
				
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskStartDate(DWORD dwID, const COleDateTime& date)
{
	if (dwID)
	{
		TODOITEM tdi;
		
		if (GetTask(dwID, tdi))
		{
			// whole days only
			COleDateTime dateDay = (double)(int)date.m_dt;
			
			if (tdi.dateStart != dateDay)
			{
				tdi.dateStart = dateDay;
				UpdateTask(dwID, tdi);
				
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskDoneDate(DWORD dwID, const COleDateTime& date)
{
	if (dwID)
	{
		TODOITEM tdi;
		
		if (GetTask(dwID, tdi))
		{
			// whole days only
			COleDateTime dateDay = (double)(int)date.m_dt;
			
			if (tdi.dateDone != dateDay)
			{
				tdi.dateDone = dateDay;
				UpdateTask(dwID, tdi);
				
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskDueDate(DWORD dwID, const COleDateTime& date)
{
	if (dwID)
	{
		TODOITEM tdi;
		
		if (GetTask(dwID, tdi))
		{
			// whole days only
			COleDateTime dateDay = (double)(int)date.m_dt;
			
			if (tdi.dateDue != dateDay)
			{
				tdi.dateDue = dateDay;
				UpdateTask(dwID, tdi);
				
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskDone(DWORD dwID, BOOL bDone, int& nPrevPercent)
{
	if (dwID)
	{
		TODOITEM tdi;
		
		if (GetTask(dwID, tdi))
		{
			BOOL bWasDone = tdi.IsDone();
			
			if (bWasDone != bDone)
			{
				if (!bDone)
				{
					// restore last known percentage unless is 100%
					if (tdi.nPercentDone == 100)
						tdi.nPercentDone = 0;
					
					nPrevPercent = tdi.nPercentDone;
				}
				
				tdi.dateDone = bDone ? COleDateTime::GetCurrentTime() : COleDateTime();
				UpdateTask(dwID, tdi);
				
				return SET_CHANGE;
			}
			
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskPercent(DWORD dwID, int nPercent)
{
	if (nPercent < 0 || nPercent > 100)
		return FALSE;
	
	if (dwID)
	{
		TODOITEM tdi;
		
		if (GetTask(dwID, tdi))
		{
			if (tdi.nPercentDone != nPercent)
			{
				tdi.nPercentDone = nPercent;
				UpdateTask(dwID, tdi);
				
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskTimeEstimate(DWORD dwID, const double& dTime, int nUnits)
{
	if (dTime < 0)
		return FALSE;
	
	if (dwID)
	{
		TODOITEM tdi;
		
		if (GetTask(dwID, tdi))
		{
			if (tdi.dTimeEstimate != dTime || tdi.nTimeEstUnits != nUnits)
			{
				tdi.dTimeEstimate = dTime;
				tdi.nTimeEstUnits = nUnits;
				
				UpdateTask(dwID, tdi);
				
				return SET_CHANGE;
			}	
			
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskTimeSpent(DWORD dwID, const double& dTime, int nUnits)
{
	if (dTime < 0)
		return FALSE;
	
	if (dwID)
	{
		TODOITEM tdi;
		
		if (GetTask(dwID, tdi))
		{
			if (tdi.dTimeSpent != dTime || tdi.nTimeSpentUnits != nUnits)
			{
				tdi.dTimeSpent = dTime;
				tdi.nTimeSpentUnits = nUnits;
				
				UpdateTask(dwID, tdi);
				
				return SET_CHANGE;
			}	
			
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskAllocTo(DWORD dwID, LPCTSTR szAllocTo)
{
	if (dwID)
	{
		TODOITEM tdi;
		
		if (GetTask(dwID, tdi))
		{
			if (tdi.sAllocTo.CompareNoCase(szAllocTo))
			{
				tdi.sAllocTo = szAllocTo;
				UpdateTask(dwID, tdi);
				
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskAllocBy(DWORD dwID, LPCTSTR szAllocBy)
{
	if (dwID)
	{
		TODOITEM tdi;
		
		if (GetTask(dwID, tdi))
		{
			if (tdi.sAllocBy.CompareNoCase(szAllocBy))
			{
				tdi.sAllocBy = szAllocBy;
				UpdateTask(dwID, tdi);
				
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskStatus(DWORD dwID, LPCTSTR szStatus)
{
	if (dwID)
	{
		TODOITEM tdi;
		
		if (GetTask(dwID, tdi))
		{
			if (tdi.sStatus.CompareNoCase(szStatus))
			{
				tdi.sStatus = szStatus;
				UpdateTask(dwID, tdi);
				
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskCategory(DWORD dwID, LPCTSTR szCategory)
{
	if (dwID)
	{
		TODOITEM tdi;
		
		if (GetTask(dwID, tdi))
		{
			if (tdi.sCategory.CompareNoCase(szCategory))
			{
				tdi.sCategory = szCategory;
				UpdateTask(dwID, tdi);
				
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::SetTaskFileRef(DWORD dwID, LPCTSTR szFilePath)
{
	if (dwID)
	{
		TODOITEM tdi;
		
		if (GetTask(dwID, tdi))
		{
			if (tdi.sFileRefPath.CompareNoCase(szFilePath))
			{
				tdi.sFileRefPath = szFilePath;
				UpdateTask(dwID, tdi);
				
				return SET_CHANGE;
			}
			return SET_NOCHANGE;
		}
	}
	
	return SET_FAILED;
}

int CToDoCtrlData::MapTimeUnits(const CString& sUnits)
{
	if (sUnits.IsEmpty())
		return TDCTU_HOURS; // default
	
	switch (sUnits[0])
	{
	case 'D':
	case 'd': return TDCTU_DAYS;
		
	case 'W':
	case 'w': return TDCTU_WEEKS;
		
	case 'M':
	case 'm': return TDCTU_MONTHS;
		
	case 'Y':
	case 'y': return TDCTU_YEARS;
	}
	
	// all else
	return TDCTU_HOURS;
}

CString CToDoCtrlData::MapTimeUnits(int nUnits)
{
	switch (nUnits)
	{
	case TDCTU_DAYS:	return "D";
	case TDCTU_WEEKS:	return "W";
	case TDCTU_MONTHS:	return "M";
	case TDCTU_YEARS:	return "Y";
	}
	
	// all else
	return "H";
}

HTREEITEM CToDoCtrlData::FindItem(DWORD dwID, HTREEITEM htiStart)
{
	// try htiStart first
	if (htiStart && m_tree.GetItemData(htiStart) == dwID)
		return htiStart;

	// else try htiStart's children
	HTREEITEM htiFound = NULL;
	HTREEITEM htiChild = htiStart ? m_tree.GetChildItem(htiStart) : 
									m_tree.GetNextItem(NULL, TVGN_CHILD);

	while (htiChild && !htiFound)
	{
		htiFound = FindItem(dwID, htiChild);
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}

	return htiFound;
}
