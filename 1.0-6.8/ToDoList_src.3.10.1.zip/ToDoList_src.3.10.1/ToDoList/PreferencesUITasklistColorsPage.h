#if !defined(AFX_PREFERENCESUITASKLISTCOLORSPAGE_H__9612D6FB_2A00_46DA_99A4_1AC6270F060D__INCLUDED_)
#define AFX_PREFERENCESUITASKLISTCOLORSPAGE_H__9612D6FB_2A00_46DA_99A4_1AC6270F060D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesUITasklistPageColors.h : header file
//

#include "..\shared\fileedit.h"
#include "..\shared\colorbutton.h"
#include "..\shared\fontcombobox.h"
#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUITasklistColorsPage dialog

const COLORREF GRIDLINECOLOR = RGB(192, 192, 192);
const COLORREF TASKDONECOLOR = RGB(192, 192, 192);

class CPreferencesUITasklistColorsPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPreferencesUITasklistColorsPage)

// Construction
public:
	CPreferencesUITasklistColorsPage();
	~CPreferencesUITasklistColorsPage();

	BOOL GetColorPriority() const { return m_bColorPriority; }
	BOOL GetColorTextByPriority() const { return m_bColorPriority && m_bColorTextByPriority; }
	int GetPriorityColors(CDWordArray& aColors) const;
	BOOL GetTreeFont(CString& sFaceName, int& nPointSize) const;
	COLORREF GetGridlineColor() const { return m_bSpecifyGridColor ? m_crGridlines : GRIDLINECOLOR; }
	COLORREF GetTaskDoneColor() const { return m_bSpecifyDoneColor ? m_crDone : GRIDLINECOLOR; }
	CString GetCheckboxImagePath() const { return m_bSpecifyCheckboxImage ? m_sCheckboxImagePath : ""; }
	COLORREF GetCheckboxMaskColor() const { return m_bSpecifyCheckboxImage ? m_crCheckboxMask : -1; }
	BOOL GetColorTaskBackground() const { return m_bColorTaskBackground; }
	BOOL GetCommentsUseTreeFont() const { return m_bSpecifyTreeFont && m_bCommentsUseTreeFont; }

protected:
// Dialog Data
	//{{AFX_DATA(CPreferencesUITasklistColorsPage)
	enum { IDD = IDD_PREFUITASKLISTCOLORS_PAGE };
	BOOL	m_bColorTaskBackground;
	BOOL	m_bCommentsUseTreeFont;
	BOOL	m_bHLSColorGradient;
	//}}AFX_DATA
	BOOL	m_bSpecifyCheckboxImage;
	CString	m_sCheckboxImagePath;
	BOOL	m_bSpecifyGridColor;
	BOOL	m_bSpecifyDoneColor;
	CColorButton	m_btDoneColor;
	CColorButton	m_btGridlineColor;
	CComboBox	m_cbFontSize;
	CFontComboBox	m_cbFonts;
	BOOL	m_bSpecifyTreeFont;
	CColorButton	m_btCheckboxMaskColor;
	CFileEdit	m_eCheckboxImagePath;
	CCheckListBox	m_lbColumnVisibility;
	CColorButton	m_btSetColor;
	CColorButton	m_btLowColor;
	CColorButton	m_btHighColor;
	BOOL	m_bColorTextByPriority;
	BOOL	m_bColorPriority;
	int		m_bGradientPriorityColors;
	int		m_nSelPriorityColor;
	BOOL	m_bShowTimeColumn;
	CDWordArray m_aPriorityColors;
	COLORREF m_crLow, m_crHigh;
	CString m_sTreeFont;
	int		m_nFontSize;
	COLORREF m_crGridlines, m_crDone;
	COLORREF m_crCheckboxMask;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesUITasklistColorsPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	virtual void OnOK();

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesUITasklistColorsPage)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	virtual BOOL OnInitDialog();
	afx_msg void OnSpecifytreefont();
	afx_msg void OnSetgridlinecolor();
	afx_msg void OnSpecifygridlinecolor();
	afx_msg void OnSetdonecolor();
	afx_msg void OnSpecifydonecolor();
	afx_msg void OnCheckboxmaskcolor();
	afx_msg void OnSpecifycheckimage();
	afx_msg void OnLowprioritycolor();
	afx_msg void OnHighprioritycolor();
	afx_msg void OnSetprioritycolor();
	afx_msg void OnChangePriorityColorOption();
	afx_msg void OnColorPriority();
	afx_msg void OnSelchangePrioritycolors();
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESUITASKLISTPAGE_H__9612D6FB_2A00_46DA_99A4_1AC6270F060D__INCLUDED_)
