#if !defined(AFX_PREFERENCESUIPAGE_H__5AE787F2_44B0_4A48_8D75_24C6C16B45DF__INCLUDED_)
#define AFX_PREFERENCESUIPAGE_H__5AE787F2_44B0_4A48_8D75_24C6C16B45DF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesUIPage.h : header file
//

#include "..\shared\fileedit.h"

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUIPage dialog

class CPreferencesUIPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPreferencesUIPage)

// Construction
public:
	CPreferencesUIPage();
	~CPreferencesUIPage();

	BOOL GetShowCtrlsAsColumns() const { return m_bShowCtrlsAsColumns; }
	BOOL GetShowCommentsAlways() const { return m_bShowCommentsAlways; }
	BOOL GetAutoReposCtrls() const { return m_bAutoReposCtrls; }
	CString GetToolbarImagePath() const { return m_bSpecifyToolbarImage ? m_sToolbarImagePath : ""; }
	BOOL GetSharedCommentsHeight() const { return m_bSharedCommentsHeight; }
	BOOL GetAutoHideTabbar() const { return m_bAutoHideTabbar; }
	BOOL GetStackTabbarItems() const { return m_bStackTabbarItems; }
	BOOL GetRightAlignLabels() const { return m_bRightAlignLabels; }

protected:
// Dialog Data
	//{{AFX_DATA(CPreferencesUIPage)
	enum { IDD = IDD_PREFUI_PAGE };
	CFileEdit	m_eToolbarImagePath;
	BOOL	m_bShowCtrlsAsColumns;
	BOOL	m_bShowCommentsAlways;
	BOOL	m_bAutoReposCtrls;
	BOOL	m_bSpecifyToolbarImage;
	CString	m_sToolbarImagePath;
	BOOL	m_bSharedCommentsHeight;
	BOOL	m_bAutoHideTabbar;
	BOOL	m_bStackTabbarItems;
	BOOL	m_bRightAlignLabels;
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesUIPage)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
public:
	virtual void OnOK();

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesUIPage)
	//}}AFX_MSG
	virtual BOOL OnInitDialog();
	afx_msg void OnSpecifytoolbarimage();
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESUIPAGE_H__5AE787F2_44B0_4A48_8D75_24C6C16B45DF__INCLUDED_)
