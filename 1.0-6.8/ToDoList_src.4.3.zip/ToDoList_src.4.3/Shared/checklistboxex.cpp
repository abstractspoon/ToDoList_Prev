// checklistboxex.cpp : implementation file
//

#include "stdafx.h"
#include "checklistboxex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCheckListBoxEx

CCheckListBoxEx::CCheckListBoxEx()
{
}

CCheckListBoxEx::~CCheckListBoxEx()
{
}


BEGIN_MESSAGE_MAP(CCheckListBoxEx, CCheckListBox)
	//{{AFX_MSG_MAP(CCheckListBoxEx)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCheckListBoxEx message handlers

BOOL CCheckListBoxEx::OnChildNotify(UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pLResult) 
{
	switch (message)
	{
	case WM_DRAWITEM:
		PreDrawItem((LPDRAWITEMSTRUCT)lParam);
		return TRUE;

	case WM_MEASUREITEM:
		PreMeasureItem((LPMEASUREITEMSTRUCT)lParam);
		return TRUE;
	}
	
	// else default
	return CCheckListBox::OnChildNotify(message, wParam, lParam, pLResult);
}

void CCheckListBoxEx::PreDrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	CCheckListBox::PreDrawItem(lpDrawItemStruct);
}

void CCheckListBoxEx::PreMeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{
	CCheckListBox::PreMeasureItem(lpMeasureItemStruct);
}
