#if !defined(AFX_PREFERENCESUIPAGE_H__5AE787F2_44B0_4A48_8D75_24C6C16B45DF__INCLUDED_)
#define AFX_PREFERENCESUIPAGE_H__5AE787F2_44B0_4A48_8D75_24C6C16B45DF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesUIPage.h : header file
//

#include "..\shared\fileedit.h"

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUIPage dialog

enum 
{ 
	PUIP_TOP,
	PUIP_BOTTOM,
	PUIP_ABOVE,
	PUIP_BELOW,
};

class CPreferencesUIPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPreferencesUIPage)

// Construction
public:
	CPreferencesUIPage();
	~CPreferencesUIPage();

	BOOL GetShowCtrlsAsColumns() const { return m_bShowCtrlsAsColumns; }
	BOOL GetShowCommentsAlways() const { return m_bShowCommentsAlways; }
	BOOL GetAutoReposCtrls() const { return m_bAutoReposCtrls; }
	BOOL GetSharedCommentsHeight() const { return m_bSharedCommentsHeight; }
	BOOL GetAutoHideTabbar() const { return m_bAutoHideTabbar; }
	BOOL GetStackTabbarItems() const { return m_bStackTabbarItems; }
	BOOL GetRightAlignLabels() const { return m_bRightAlignLabels; }
	BOOL GetFocusTreeOnEnter() const { return m_bFocusTreeOnEnter; }
	BOOL GetLargeToolbarIcons() const { return m_bLargeToolbarIcons; }
	int GetNewTaskPos() const { return m_nNewTaskPos; }
	int GetNewSubtaskPos() const { return m_nNewSubtaskPos; }
	BOOL GetKeepTabsOrdered() const { return m_bKeepTabsOrdered; }
	BOOL GetShowTasklistCloseButton() const { return m_bShowTasklistCloseButton; }
	BOOL GetEnableCtrlMBtnClose() const { return m_bEnableCtrlMBtnClose; }
	BOOL GetEnableHeaderSorting() const { return m_bEnableHeaderSorting; }
	BOOL GetAutoReSort() const { return m_bAutoReSort; }
	BOOL GetSortVisibleOnly() const { return m_bSortVisibleOnly; }
	BOOL GetSortDoneTasksAtBottom() const { return m_bSortDoneTasksAtBottom; }
//	BOOL Get() const { return ; }

protected:
// Dialog Data
	//{{AFX_DATA(CPreferencesUIPage)
	enum { IDD = IDD_PREFUI_PAGE };
	BOOL	m_bShowCtrlsAsColumns;
	BOOL	m_bShowCommentsAlways;
	BOOL	m_bAutoReposCtrls;
	BOOL	m_bSpecifyToolbarImage;
	BOOL	m_bSharedCommentsHeight;
	BOOL	m_bAutoHideTabbar;
	BOOL	m_bStackTabbarItems;
	BOOL	m_bRightAlignLabels;
	BOOL	m_bFocusTreeOnEnter;
	BOOL	m_bLargeToolbarIcons;
	int		m_nNewTaskPos;
	int		m_nNewSubtaskPos;
	BOOL	m_bKeepTabsOrdered;
	BOOL	m_bShowTasklistCloseButton;
	BOOL	m_bEnableCtrlMBtnClose;
	//}}AFX_DATA
	BOOL	m_bAutoReSort;
	BOOL	m_bSortVisibleOnly;
	BOOL	m_bSortDoneTasksAtBottom;
	BOOL	m_bEnableHeaderSorting;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesUIPage)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
public:
	virtual void OnOK();

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesUIPage)
	//}}AFX_MSG
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESUIPAGE_H__5AE787F2_44B0_4A48_8D75_24C6C16B45DF__INCLUDED_)
