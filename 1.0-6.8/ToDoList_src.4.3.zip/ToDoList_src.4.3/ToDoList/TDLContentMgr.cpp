// TDLContentMgr.cpp: implementation of the CTDLContentMgr class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "todolist.h"
#include "TDLContentMgr.h"
#include "ToDoCommentsCtrl.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTDLContentMgr::CTDLContentMgr() 
{

}

CTDLContentMgr::~CTDLContentMgr()
{

}

BOOL CTDLContentMgr::CreateDefaultContentControl(CContentCtrl& ctrl, UINT nCtrlID, DWORD nStyle, 
									DWORD dwExStyle, const CRect& rect, HWND hwndParent)
{
	CToDoCommentsCtrl* pComments = new CToDoCommentsCtrl;

	nStyle |= ES_MULTILINE | ES_WANTRETURN | WS_VSCROLL;

	if (pComments->Create(nStyle, rect, CWnd::FromHandle(hwndParent), nCtrlID))
	{
		pComments->ModifyStyleEx(0, dwExStyle, 0);

		return ctrl.Attach(pComments);
	}

	// else
	delete pComments;
	return FALSE;
}
