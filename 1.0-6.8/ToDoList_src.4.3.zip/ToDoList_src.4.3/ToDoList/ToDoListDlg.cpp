// ToDoListDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ToDoList.h"
#include "ToDoListDlg.h"
#include "ToolsCmdlineParser.h"
#include "ToolsUserInputDlg.h"
#include "Toolshelper.h"
#include "exportDlg.h"
#include "tasklisthtmlexporter.h"
#include "tasklisttxtexporter.h"
#include "tdcmsg.h"

#include "..\shared\aboutdlg.h"
#include "..\shared\holdredraw.h"
#include "..\shared\autoflag.h"
#include "..\shared\deferWndMove.h"
#include "..\shared\enbitmap.h"
#include "..\shared\spellcheckdlg.h"
#include "..\shared\encolordialog.h"
#include "..\shared\winclasses.h"
#include "..\shared\datehelper.h"
#include "..\shared\osversion.h"
#include "..\shared\filedialogex.h"
#include "..\shared\misc.h"
#include "..\shared\browserdlg.h"
#include "..\shared\themed.h"

#include "..\3rdparty\gui.h"

#ifdef _AFXDLL
#  define COMPILE_MULTIMON_STUBS
#endif

#include <multimon.h>
#include <afxpriv.h>        // for WM_KICKIDLE

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const UINT WM_POSTINITDIALOG = (WM_USER+1);

/////////////////////////////////////////////////////////////////////////////
// CToDoListDlg dialog

// popup menus
enum { FILEALL, NEWTASK, EDITTASK, VIEW, MOVE, SORT, DELETETASK, TOOLS, HELP };
enum { TRAYICON, TASKCONTEXT, TABCTRL };
enum { TB_TOOLBARHIDDEN, TB_TOOLBARONLY, TB_TOOLBARANDMENU };
enum { LOAD_CANCELLED, LOAD_FAILED, LOAD_SUCCESS };

const LPCTSTR XMLFILEFILTER = "Task Lists (*.xml)|*.xml||";
const LPCTSTR XSLFILEFILTER = "Stylesheets (*.xsl)|*.xsl||";
const LPCTSTR TRANSFORMFILEFILTER = "Web Pages (*.htm, *.html)|*.htm;*.html|Text Files (*.txt)|*.txt|All Files (*.*)|*.*||";
const LPCTSTR ALLFILEFILTER = "All Files (*.*)|*.*||";
const int TD_VERSION = 31000;

enum 
{
	TIMER_READONLYSTATUS = 1,
	TIMER_TIMESTAMPCHANGE,
	TIMER_AUTOSAVE,
	TIMER_CHECKOUTSTATUS,
	TIMER_DUEITEMS,
};

// macro to help prevent re-entrancy in timer (or other) functions
#define NOREENTRANT  \
	static BOOL bInTimer = FALSE; \
	if (bInTimer) \
       return; \
	CAutoFlag af(bInTimer, TRUE);

enum 
{
	INTERVAL_READONLYSTATUS = 1000,
	INTERVAL_TIMESTAMPCHANGE = 10000,
	//	INTERVAL_AUTOSAVE, // dynamically determined
	INTERVAL_CHECKOUTSTATUS = 5000,
	INTERVAL_DUEITEMS = 60000,
};

CToDoListDlg::CToDoListDlg() : CDialog(IDD_TODOLIST_DIALOG), 
		m_bVisible(-1), 
		m_mruList(0, "MRU", "TaskList%d", 16, AFX_ABBREV_FILENAME_LEN, "Recent Tasklists"),
		m_nLastSelItem(-1),
		m_bSimpleMode(FALSE),
		m_stFilePath(TRUE),
		m_bInNewTask(FALSE),
		m_bSaving(FALSE),
		m_mgrShortcuts(FALSE),
		m_nToolbarOption(-1),
		m_pPrefs(NULL),
		m_bClosing(FALSE),
		m_mgrToDoCtrls(m_tabCtrl),
		m_bFindShowing(FALSE)
{
	//{{AFX_DATA_INIT(CToDoListDlg)
	//}}AFX_DATA_INIT
	
	// load app icon
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	if (COSVersion() >= OSV_XP)
	{
		// except under XP icons can look right shoddy
		m_hIcon = AfxGetApp()->LoadIcon(IDI_MAINFRAMEXP);
	}
	else
		m_hIcon = AfxGetApp()->LoadIcon(IDI_MAINFRAME);
	
	// init preferences
	ResetPrefs();
}

CToDoListDlg::~CToDoListDlg()
{
	delete m_pPrefs;
}

void CToDoListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CToDoListDlg)
	DDX_Control(pDX, IDC_TABCONTROL, m_tabCtrl);
	DDX_Control(pDX, IDC_FILENAME, m_stFilePath);
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_FILENAME, m_sStatus);
}

BEGIN_MESSAGE_MAP(CToDoListDlg, CDialog)
//{{AFX_MSG_MAP(CToDoListDlg)
ON_COMMAND(ID_VIEW_EXPANDTASK, OnViewExpandtask)
ON_UPDATE_COMMAND_UI(ID_VIEW_EXPANDTASK, OnUpdateViewExpandtask)
ON_COMMAND(ID_VIEW_COLLAPSETASK, OnViewCollapsetask)
ON_UPDATE_COMMAND_UI(ID_VIEW_COLLAPSETASK, OnUpdateViewCollapsetask)
ON_COMMAND(ID_VIEW_COLLAPSEALL, OnViewCollapseall)
ON_COMMAND(ID_VIEW_EXPANDALL, OnViewExpandall)
ON_UPDATE_COMMAND_UI(ID_VIEW_EXPANDALL, OnUpdateViewExpandall)
ON_UPDATE_COMMAND_UI(ID_VIEW_COLLAPSEALL, OnUpdateViewCollapseall)
ON_UPDATE_COMMAND_UI(ID_TOOLS_USEREXPORT1, OnUpdateUserExport1)
ON_UPDATE_COMMAND_UI(ID_TOOLS_USERIMPORT1, OnUpdateUserImport1)
ON_UPDATE_COMMAND_UI(ID_WINDOW1, OnUpdateWindow)
ON_WM_ACTIVATE()
ON_WM_ENABLE()
ON_WM_DESTROY()
ON_COMMAND(ID_NEWTASK, OnNewtask)
ON_COMMAND(ID_NEWSUBTASK, OnNewsubtask)
ON_UPDATE_COMMAND_UI(ID_NEWSUBTASK, OnUpdateNewsubtask)
ON_COMMAND(ID_TOOLS_TRANSFORM, OnToolsTransformactivetasklist)
ON_COMMAND(ID_VIEW_SORTTASKLISTTABS, OnViewSorttasklisttabs)
ON_UPDATE_COMMAND_UI(ID_VIEW_SORTTASKLISTTABS, OnUpdateViewSorttasklisttabs)
ON_WM_MEASUREITEM()
ON_COMMAND(ID_EDIT_INCTASKPERCENTDONE, OnEditInctaskpercentdone)
ON_UPDATE_COMMAND_UI(ID_EDIT_INCTASKPERCENTDONE, OnUpdateEditInctaskpercentdone)
ON_COMMAND(ID_EDIT_DECTASKPERCENTDONE, OnEditDectaskpercentdone)
ON_UPDATE_COMMAND_UI(ID_EDIT_DECTASKPERCENTDONE, OnUpdateEditDectaskpercentdone)
ON_COMMAND(ID_EDIT_DECTASKPRIORITY, OnEditDectaskpriority)
ON_UPDATE_COMMAND_UI(ID_EDIT_DECTASKPRIORITY, OnUpdateEditDectaskpriority)
ON_COMMAND(ID_EDIT_INCTASKPRIORITY, OnEditInctaskpriority)
ON_UPDATE_COMMAND_UI(ID_EDIT_INCTASKPRIORITY, OnUpdateEditInctaskpriority)
ON_COMMAND(ID_EDIT_FLAGTASK, OnEditFlagtask)
ON_UPDATE_COMMAND_UI(ID_EDIT_FLAGTASK, OnUpdateEditFlagtask)
ON_WM_SYSCOMMAND()
ON_COMMAND(ID_FILE_OPENARCHIVE, OnFileOpenarchive)
ON_UPDATE_COMMAND_UI(ID_FILE_OPENARCHIVE, OnUpdateFileOpenarchive)
//}}AFX_MSG_MAP
ON_COMMAND_RANGE(ID_WINDOW1, ID_WINDOW16, OnWindow)
ON_COMMAND_RANGE(ID_TOOLS_USERIMPORT1, ID_TOOLS_USERIMPORT8, OnUserImport)
ON_COMMAND_RANGE(ID_TOOLS_USEREXPORT1, ID_TOOLS_USEREXPORT8, OnUserExport)
ON_COMMAND(ID_VIEW_NEXT, OnViewNext)
ON_UPDATE_COMMAND_UI(ID_VIEW_NEXT, OnUpdateViewNext)
ON_COMMAND(ID_VIEW_PREV, OnViewPrev)
ON_UPDATE_COMMAND_UI(ID_VIEW_PREV, OnUpdateViewPrev)
ON_WM_SYSCOMMAND()
ON_UPDATE_COMMAND_UI(ID_IMPORT_TASKLIST, OnUpdateImport)
ON_UPDATE_COMMAND_UI(ID_NEWTASK, OnUpdateNewtask)
ON_COMMAND(ID_TOOLS_CHECKOUT, OnToolsCheckout)
ON_UPDATE_COMMAND_UI(ID_TOOLS_CHECKOUT, OnUpdateToolsCheckout)
ON_COMMAND(ID_TOOLS_CHECKIN, OnToolsCheckin)
ON_UPDATE_COMMAND_UI(ID_TOOLS_CHECKIN, OnUpdateToolsCheckin)
ON_COMMAND(ID_TOOLS_TOGGLECHECKIN, OnToolsToggleCheckin)
ON_UPDATE_COMMAND_UI(ID_TOOLS_TOGGLECHECKIN, OnUpdateToolsToggleCheckin)
ON_COMMAND(ID_TOOLS_EXPORT, OnExport)
ON_UPDATE_COMMAND_UI(ID_TOOLS_EXPORT, OnUpdateExport)
ON_UPDATE_COMMAND_UI(ID_TOOLS_TRANSFORM, OnUpdateExport) // use same text as export
ON_COMMAND(ID_NEXTTOPLEVELTASK, OnNexttopleveltask)
ON_COMMAND(ID_PREVTOPLEVELTASK, OnPrevtopleveltask)
ON_UPDATE_COMMAND_UI(ID_NEXTTOPLEVELTASK, OnUpdateNexttopleveltask)
ON_UPDATE_COMMAND_UI(ID_PREVTOPLEVELTASK, OnUpdatePrevtopleveltask)
ON_COMMAND(ID_EDIT_FINDTASKS, OnFindTasks)
ON_COMMAND(ID_VIEW_MOVETASKLISTRIGHT, OnViewMovetasklistright)
ON_UPDATE_COMMAND_UI(ID_VIEW_MOVETASKLISTRIGHT, OnUpdateViewMovetasklistright)
ON_COMMAND(ID_VIEW_MOVETASKLISTLEFT, OnViewMovetasklistleft)
ON_UPDATE_COMMAND_UI(ID_VIEW_MOVETASKLISTLEFT, OnUpdateViewMovetasklistleft)
ON_COMMAND(ID_VIEW_MENUONLY, OnViewMenuonly)
ON_UPDATE_COMMAND_UI(ID_VIEW_MENUONLY, OnUpdateViewMenuonly)
ON_COMMAND(ID_VIEW_TOOLBARANDMENU, OnViewToolbarandmenu)
ON_UPDATE_COMMAND_UI(ID_VIEW_TOOLBARANDMENU, OnUpdateViewToolbarandmenu)
ON_COMMAND(ID_VIEW_TOOLBARONLY, OnViewToolbaronly)
ON_UPDATE_COMMAND_UI(ID_VIEW_TOOLBARONLY, OnUpdateViewToolbaronly)
ON_COMMAND(ID_SORT, OnSort)
ON_UPDATE_COMMAND_UI(ID_SORT, OnUpdateSort)
ON_COMMAND(ID_NEWTASK_ATTOP, OnNewtaskAttop)
ON_UPDATE_COMMAND_UI(ID_NEWTASK_ATTOP, OnUpdateNewtaskAttop)
ON_COMMAND(ID_NEWTASK_ATBOTTOM, OnNewtaskAtbottom)
ON_UPDATE_COMMAND_UI(ID_NEWTASK_ATBOTTOM, OnUpdateNewtaskAtbottom)
ON_COMMAND(ID_EDIT_SPELLCHECKCOMMENTS, OnSpellcheckcomments)
ON_UPDATE_COMMAND_UI(ID_EDIT_SPELLCHECKCOMMENTS, OnUpdateSpellcheckcomments)
ON_COMMAND(ID_EDIT_SPELLCHECKTITLE, OnSpellchecktitle)
ON_UPDATE_COMMAND_UI(ID_EDIT_SPELLCHECKTITLE, OnUpdateSpellchecktitle)
ON_COMMAND(ID_FILE_ENCRYPT, OnFileEncrypt)
ON_UPDATE_COMMAND_UI(ID_FILE_ENCRYPT, OnUpdateFileEncrypt)
ON_COMMAND(ID_FILE_RESETVERSION, OnFileResetversion)
ON_UPDATE_COMMAND_UI(ID_FILE_RESETVERSION, OnUpdateFileResetversion)
ON_COMMAND(ID_TOOLS_SPELLCHECKTASKLIST, OnSpellcheckTasklist)
ON_UPDATE_COMMAND_UI(ID_TOOLS_SPELLCHECKTASKLIST, OnUpdateSpellcheckTasklist)
ON_COMMAND(ID_EDIT_PASTEAFTER, OnEditPasteAfter)
ON_UPDATE_COMMAND_UI(ID_EDIT_PASTEAFTER, OnUpdateEditPasteAfter)
ON_COMMAND(ID_EDIT_CLOCK_TASK, OnEditTimeTrackTask)
ON_UPDATE_COMMAND_UI(ID_EDIT_CLOCK_TASK, OnUpdateEditTimeTrackTask)
ON_WM_DRAWITEM()
ON_COMMAND(ID_VIEW_NEXT_SEL, OnViewNextSel)
ON_UPDATE_COMMAND_UI(ID_VIEW_NEXT_SEL, OnUpdateViewNextSel)
ON_COMMAND(ID_VIEW_PREV_SEL, OnViewPrevSel)
ON_UPDATE_COMMAND_UI(ID_VIEW_PREV_SEL, OnUpdateViewPrevSel)
ON_COMMAND(ID_EDIT_CUT, OnEditCut)
ON_UPDATE_COMMAND_UI(ID_EDIT_CUT, OnUpdateEditCut)
ON_COMMAND_RANGE(ID_NEWTASK_SPLITTASKINTO_TWO, ID_NEWTASK_SPLITTASKINTO_FIVE, OnSplitTaskIntoPieces)
ON_UPDATE_COMMAND_UI_RANGE(ID_NEWTASK_SPLITTASKINTO_TWO, ID_NEWTASK_SPLITTASKINTO_FIVE, OnUpdateSplitTaskIntoPieces)
ON_COMMAND_RANGE(ID_TOOLS_SHOWTASKS_DUETODAY, ID_TOOLS_SHOWTASKS_DUEENDNEXTMONTH, OnToolsShowtasksDue)
ON_COMMAND(ID_DELETETASK, OnDeleteTask)
ON_COMMAND(ID_DELETEALLTASKS, OnDeleteAllTasks)
ON_WM_SIZE()
ON_WM_GETMINMAXINFO()
ON_COMMAND(ID_SAVE_NORMAL, OnSave)
ON_COMMAND(ID_LOAD_NORMAL, OnLoad)
ON_COMMAND(ID_NEW, OnNew)
ON_UPDATE_COMMAND_UI(ID_DELETETASK, OnUpdateDeletetask)
ON_UPDATE_COMMAND_UI(ID_EDIT_TASKCOLOR, OnUpdateTaskcolor)
ON_UPDATE_COMMAND_UI(ID_EDIT_TASKDONE, OnUpdateTaskdone)
ON_UPDATE_COMMAND_UI(ID_DELETEALLTASKS, OnUpdateDeletealltasks)
ON_UPDATE_COMMAND_UI(ID_SAVE_NORMAL, OnUpdateSave)
ON_UPDATE_COMMAND_UI(ID_NEW, OnUpdateNew)
ON_WM_ERASEBKGND()
ON_COMMAND(ID_NEWTASK_ATTOPSELECTED, OnNewtaskAttopSelected)
ON_COMMAND(ID_NEWTASK_ATBOTTOMSELECTED, OnNewtaskAtbottomSelected)
ON_COMMAND(ID_NEWTASK_AFTERSELECTEDTASK, OnNewtaskAfterselectedtask)
ON_COMMAND(ID_NEWTASK_BEFORESELECTEDTASK, OnNewtaskBeforeselectedtask)
ON_UPDATE_COMMAND_UI(ID_SORT, OnUpdateSort)
ON_COMMAND(ID_NEWSUBTASK_ATBOTTOM, OnNewsubtaskAtbottom)
ON_COMMAND(ID_NEWSUBTASK_ATTOP, OnNewsubtaskAttop)
ON_COMMAND(ID_EDIT_TASKCOLOR, OnEditTaskcolor)
ON_COMMAND(ID_EDIT_TASKDONE, OnEditTaskdone)
ON_COMMAND(ID_EDIT_TASKTEXT, OnEditTasktext)
ON_COMMAND(ID_MOVETASKDOWN, OnMovetaskdown)
ON_UPDATE_COMMAND_UI(ID_MOVETASKDOWN, OnUpdateMovetaskdown)
ON_COMMAND(ID_MOVETASKUP, OnMovetaskup)
ON_UPDATE_COMMAND_UI(ID_MOVETASKUP, OnUpdateMovetaskup)
ON_WM_CLOSE()
ON_COMMAND(ID_TRAYICON_CLOSE, OnTrayiconClose)
ON_WM_WINDOWPOSCHANGING()
ON_UPDATE_COMMAND_UI(ID_NEWSUBTASK_ATBOTTOM, OnUpdateNewsubtaskAtBottom)
ON_COMMAND(ID_SAVEAS, OnSaveas)
ON_UPDATE_COMMAND_UI(ID_SAVEAS, OnUpdateSaveas)
ON_WM_CONTEXTMENU()
//	ON_WM_GETDLGCODE()
ON_COMMAND(ID_TRAYICON_SHOW, OnTrayiconShow)
ON_WM_QUERYENDSESSION()
ON_UPDATE_COMMAND_UI(ID_FILE_MRU_FILE1, OnUpdateRecentFileMenu)
ON_COMMAND(ID_ABOUT, OnAbout)
ON_COMMAND(ID_PREFERENCES, OnPreferences)
ON_WM_COPYDATA()
ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
ON_COMMAND(ID_EDIT_PASTESUB, OnEditPasteSub)
ON_COMMAND(ID_EDIT_COPYASTEXT, OnEditCopyastext)
ON_COMMAND(ID_EDIT_COPYASHTML, OnEditCopyashtml)
ON_UPDATE_COMMAND_UI(ID_EDIT_PASTESUB, OnUpdateEditPasteSub)
ON_UPDATE_COMMAND_UI(ID_NEWTASK_ATTOPSELECTED, OnUpdateNewtaskAttopSelected)
ON_UPDATE_COMMAND_UI(ID_NEWTASK_ATBOTTOMSELECTED, OnUpdateNewtaskAtbottomSelected)
ON_UPDATE_COMMAND_UI(ID_NEWTASK_AFTERSELECTEDTASK, OnUpdateNewtaskAfterselectedtask)
ON_UPDATE_COMMAND_UI(ID_NEWTASK_BEFORESELECTEDTASK, OnUpdateNewtaskBeforeselectedtask)
ON_UPDATE_COMMAND_UI(ID_NEWSUBTASK_ATTOP, OnUpdateNewsubtaskAttop)
ON_COMMAND(ID_SIMPLEMODE, OnSimplemode)
ON_UPDATE_COMMAND_UI(ID_SIMPLEMODE, OnUpdateSimplemode)
ON_COMMAND(ID_OPEN_RELOAD, OnReload)
ON_UPDATE_COMMAND_UI(ID_OPEN_RELOAD, OnUpdateReload)
ON_COMMAND(ID_ARCHIVE_COMPLETEDTASKS, OnArchiveCompletedtasks)
ON_UPDATE_COMMAND_UI(ID_ARCHIVE_COMPLETEDTASKS, OnUpdateArchiveCompletedtasks)
ON_COMMAND(ID_PRINT, OnPrint)
ON_UPDATE_COMMAND_UI(ID_PRINT, OnUpdatePrint)
ON_COMMAND(ID_MOVETASKRIGHT, OnMovetaskright)
ON_UPDATE_COMMAND_UI(ID_MOVETASKRIGHT, OnUpdateMovetaskright)
ON_COMMAND(ID_MOVETASKLEFT, OnMovetaskleft)
ON_UPDATE_COMMAND_UI(ID_MOVETASKLEFT, OnUpdateMovetaskleft)
ON_NOTIFY(TCN_SELCHANGE, IDC_TABCONTROL, OnSelchangeTabcontrol)
ON_NOTIFY(TCN_SELCHANGING, IDC_TABCONTROL, OnSelchangingTabcontrol)
ON_NOTIFY(NM_MCLICK, IDC_TABCONTROL, OnMBtnClickTabcontrol)
ON_COMMAND(ID_CLOSE, OnCloseTasklist)
ON_COMMAND(ID_SAVEALL, OnSaveall)
ON_UPDATE_COMMAND_UI(ID_SAVEALL, OnUpdateSaveall)
ON_COMMAND(ID_CLOSEALL, OnCloseall)
ON_UPDATE_COMMAND_UI(ID_CLOSEALL, OnUpdateCloseall)
ON_COMMAND(ID_EXIT, OnExit)
ON_UPDATE_COMMAND_UI(ID_EXIT, OnUpdateExit)
ON_UPDATE_COMMAND_UI(ID_MOVETASK, OnUpdateMovetask)
ON_WM_TIMER()
ON_COMMAND(ID_IMPORT_TASKLIST, OnImportTasklist)
ON_COMMAND_RANGE(ID_SORT_BYDONEDATE, ID_SORT_NONE, OnSortBy)
ON_UPDATE_COMMAND_UI_RANGE(ID_SORT_BYDONEDATE, ID_SORT_NONE, OnUpdateSortBy)
ON_UPDATE_COMMAND_UI(ID_EDIT_TASKTEXT, OnUpdateEditTasktext)
ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
ON_COMMAND(ID_TRAYICON_CREATETASK, OnTrayiconCreatetask)
ON_COMMAND_RANGE(ID_EDIT_SETPRIORITY0, ID_EDIT_SETPRIORITY10, OnSetPriority)
ON_UPDATE_COMMAND_UI_RANGE(ID_EDIT_SETPRIORITY0, ID_EDIT_SETPRIORITY10, OnUpdateSetPriority)
ON_COMMAND(ID_EDIT_SETFILEREF, OnEditSetfileref)
ON_UPDATE_COMMAND_UI(ID_EDIT_SETFILEREF, OnUpdateEditSetfileref)
ON_COMMAND(ID_EDIT_OPENFILEREF, OnEditOpenfileref)
ON_UPDATE_COMMAND_UI(ID_EDIT_OPENFILEREF, OnUpdateEditOpenfileref)
ON_UPDATE_COMMAND_UI(ID_EDIT_COPYASHTML, OnUpdateEditCopy)
ON_UPDATE_COMMAND_UI(ID_EDIT_COPYASTEXT, OnUpdateEditCopy)
ON_UPDATE_COMMAND_UI(ID_TOOLS_USERTOOL1, OnUpdateUserTool1)
ON_COMMAND_RANGE(ID_TOOLS_USERTOOL1, ID_TOOLS_USERTOOL16, OnUserTool)
ON_WM_INITMENUPOPUP()
ON_NOTIFY(NM_CLICK, IDC_TRAYICON, OnTrayIconClick)
ON_NOTIFY(NM_DBLCLK, IDC_TRAYICON, OnTrayIconDblClk)
ON_NOTIFY(NM_RCLICK, IDC_TRAYICON, OnTrayIconRClick)
ON_REGISTERED_MESSAGE(WM_TDCN_SORT, OnToDoCtrlNotifySort)
ON_REGISTERED_MESSAGE(WM_TDCN_MODIFY, OnToDoCtrlNotifyMod)
ON_REGISTERED_MESSAGE(WM_TDCN_MINWIDTHCHANGE, OnToDoCtrlNotifyMinWidthChange)
ON_REGISTERED_MESSAGE(WM_TDL_SHOWWINDOW , OnToDoListShowWindow)
ON_REGISTERED_MESSAGE(WM_TDL_GETVERSION , OnToDoListGetVersion)
ON_COMMAND_EX_RANGE(ID_FILE_MRU_FILE1, ID_FILE_MRU_FILE16, OnOpenRecentFile)
ON_REGISTERED_MESSAGE(WM_FTD_FIND, OnFindDlgFind)
ON_REGISTERED_MESSAGE(WM_FTD_SELECTRESULT, OnFindSelectResult)
ON_REGISTERED_MESSAGE(WM_FTD_SELECTALL, OnFindSelectAll)
ON_REGISTERED_MESSAGE(WM_FTD_CLOSE, OnFindDlgClose)
ON_REGISTERED_MESSAGE(WM_TLDT_DROPFILE, OnDropFile)
ON_REGISTERED_MESSAGE(WM_PTP_TESTTOOL, OnPreferencesTestTool)
ON_MESSAGE(WM_GETICON, OnGetIcon)
ON_MESSAGE(WM_POSTINITDIALOG, OnPostInitDialog)
ON_MESSAGE(WM_HOTKEY, OnHotkey)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CToDoListDlg message handlers

BOOL CToDoListDlg::Create(BOOL bForceVisible, LPCTSTR szTDListPath)
{
	m_sCmdLineFilePath = szTDListPath;
	m_bVisible = bForceVisible ? 1 : -1;
	
	return CDialog::Create(IDD_TODOLIST_DIALOG);
}

int CToDoListDlg::GetVersion()
{
	return TD_VERSION;
}

BOOL CToDoListDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// import export manager
	m_mgrImportExport.Initialize();
	
	// drop target
	m_dropTarget.Register(this, this);
	
	// shortcut manager
	InitShortcutManager();
	
	// trayicon
	// we always create the trayicon (for simplicity) but we only
	// show it if required
	BOOL bUseSysTray = Prefs().GetUseSysTray();
	UINT nIDTrayIcon = (COSVersion() >= OSV_XP) ? IDI_MAINFRAMEXP : IDI_TRAYICON;
	
	m_ti.Create(WS_CHILD | (bUseSysTray ? WS_VISIBLE : 0), this, IDC_TRAYICON, nIDTrayIcon, 
		"ToDoList � AbstractSpoon 2003-05");
	
	// toolbar
	InitToolbar();
	
	// tabctrl
	BOOL bStackTabbar = Prefs().GetStackTabbarItems();
	
	m_tabCtrl.ModifyStyle(bStackTabbar ? 0 : TCS_MULTILINE, bStackTabbar ? TCS_MULTILINE : 0);
	UpdateTabSwitchTooltip();
	
	if (m_ilTabCtrl.Create(IDB_SOURCECONTROL, 16, 1, RGB(0, 255, 0)))
		m_tabCtrl.SetImageList(&m_ilTabCtrl);
	
	// statusbar font
	::SendMessage(m_stFilePath, WM_SETFONT, (WPARAM)GetStockObject(DEFAULT_GUI_FONT), 0);
	
	LoadSettings();
	
	// due items timer
	SetTimer(TIMER_DUEITEMS, TRUE);
	
	// late initialization
	PostMessage(WM_POSTINITDIALOG);
	
	return FALSE;  // return TRUE  unless you set the focus to a control
}

void CToDoListDlg::InitShortcutManager()
{
	// setup defaults first
	m_mgrShortcuts.AddShortcut(ID_LOAD_NORMAL, 'O', HOTKEYF_CONTROL);
	m_mgrShortcuts.AddShortcut(ID_OPEN_RELOAD, 'O', HOTKEYF_CONTROL | HOTKEYF_SHIFT);
	m_mgrShortcuts.AddShortcut(ID_SAVE_NORMAL, 'S', HOTKEYF_CONTROL);
	m_mgrShortcuts.AddShortcut(ID_IMPORT_TASKLIST, 'I', HOTKEYF_CONTROL);
	m_mgrShortcuts.AddShortcut(ID_NEWTASK_BEFORESELECTEDTASK, 'N', HOTKEYF_CONTROL);
	m_mgrShortcuts.AddShortcut(ID_NEWSUBTASK_ATTOP, 'N', HOTKEYF_CONTROL | HOTKEYF_SHIFT);
	m_mgrShortcuts.AddShortcut(ID_NEWTASK_AFTERSELECTEDTASK, 'N', HOTKEYF_CONTROL | HOTKEYF_ALT);
	m_mgrShortcuts.AddShortcut(ID_SIMPLEMODE, 'M', HOTKEYF_CONTROL);
	m_mgrShortcuts.AddShortcut(ID_PRINT, 'P', HOTKEYF_CONTROL);
	m_mgrShortcuts.AddShortcut(ID_VIEW_NEXT, VK_TAB, HOTKEYF_CONTROL);
	m_mgrShortcuts.AddShortcut(ID_VIEW_PREV, VK_TAB, HOTKEYF_CONTROL | HOTKEYF_SHIFT);
	m_mgrShortcuts.AddShortcut(ID_EDIT_COPY, 'C', HOTKEYF_CONTROL);
	m_mgrShortcuts.AddShortcut(ID_EDIT_PASTE, 'V', HOTKEYF_CONTROL);
	m_mgrShortcuts.AddShortcut(ID_EDIT_OPENFILEREF, 'G', HOTKEYF_CONTROL);
	m_mgrShortcuts.AddShortcut(ID_EXIT, VK_F4, HOTKEYF_ALT);
	m_mgrShortcuts.AddShortcut(ID_CLOSE, 'C', HOTKEYF_CONTROL | HOTKEYF_ALT);
	m_mgrShortcuts.AddShortcut(ID_MOVETASKDOWN, VK_DOWN, HOTKEYF_CONTROL | HOTKEYF_EXT);
	m_mgrShortcuts.AddShortcut(ID_MOVETASKUP, VK_UP, HOTKEYF_CONTROL | HOTKEYF_EXT);
	m_mgrShortcuts.AddShortcut(ID_MOVETASKLEFT, VK_LEFT, HOTKEYF_CONTROL | HOTKEYF_EXT);
	m_mgrShortcuts.AddShortcut(ID_MOVETASKRIGHT, VK_RIGHT, HOTKEYF_CONTROL | HOTKEYF_EXT);
	m_mgrShortcuts.AddShortcut(ID_DELETETASK, VK_DELETE, HOTKEYF_EXT);
	m_mgrShortcuts.AddShortcut(ID_EDIT_TASKTEXT, VK_F2, 0);
	m_mgrShortcuts.AddShortcut(ID_EDIT_TASKDONE, VK_SPACE, 0);
	m_mgrShortcuts.AddShortcut(ID_TOOLS_EXPORT, 'E', HOTKEYF_CONTROL);
	m_mgrShortcuts.AddShortcut(ID_HELP, VK_F1, 0);
	m_mgrShortcuts.AddShortcut(ID_VIEW_TOOLBARANDMENU, 'M', HOTKEYF_CONTROL | HOTKEYF_ALT | HOTKEYF_SHIFT);
	m_mgrShortcuts.AddShortcut(ID_WINDOW1, '1', HOTKEYF_ALT);
	m_mgrShortcuts.AddShortcut(ID_WINDOW2, '2', HOTKEYF_ALT);
	m_mgrShortcuts.AddShortcut(ID_WINDOW3, '3', HOTKEYF_ALT);
	m_mgrShortcuts.AddShortcut(ID_WINDOW4, '4', HOTKEYF_ALT);
	m_mgrShortcuts.AddShortcut(ID_WINDOW5, '5', HOTKEYF_ALT);
	m_mgrShortcuts.AddShortcut(ID_WINDOW6, '6', HOTKEYF_ALT);
	m_mgrShortcuts.AddShortcut(ID_WINDOW7, '7', HOTKEYF_ALT);
	m_mgrShortcuts.AddShortcut(ID_WINDOW8, '8', HOTKEYF_ALT);
	m_mgrShortcuts.AddShortcut(ID_WINDOW9, '9', HOTKEYF_ALT);
	m_mgrShortcuts.AddShortcut(ID_TOOLS_TRANSFORM, 'T', HOTKEYF_CONTROL);
	m_mgrShortcuts.AddShortcut(ID_EDIT_FINDTASKS, 'F', HOTKEYF_CONTROL);
	
	// now init shortcut mgr which will override the defaults
	// with the users actual settings
	if (m_mgrShortcuts.Initialize(this))
	{
		// fix for previously adding escape key as a shortcut for IDCLOSE 
		// (big mistake)
		if (m_mgrShortcuts.GetShortcut(IDCLOSE) == VK_ESCAPE)
			m_mgrShortcuts.DeleteShortcut(IDCLOSE);
	}
}

LRESULT CToDoListDlg::OnGetIcon(WPARAM bLargeIcon, LPARAM /*not used*/)
{
	return (LRESULT)m_hIcon;
}

BOOL CToDoListDlg::InitToolbar()
{
	if (!m_toolbar.GetSafeHwnd())
	{
		UINT nIDToolbarImage = Prefs().GetLargeToolbarIcons() ? IDB_TOOLBAR24 : IDB_TOOLBAR16;
		
		VERIFY (m_toolbar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_ALIGN_TOP)
			&& m_toolbar.LoadToolBar(IDR_TOOLBAR, nIDToolbarImage));
		
		// very important - turn OFF all the auto positioning and sizing
		// by default have no borders
		UINT nStyle = m_toolbar.GetBarStyle();
		nStyle &= ~(CCS_NORESIZE | CCS_NOPARENTALIGN | CBRS_BORDER_ANY);
		nStyle |= (CBRS_SIZE_FIXED | CBRS_TOOLTIPS | CBRS_FLYBY);
		m_toolbar.SetBarStyle(nStyle);
		
		m_toolbar.GetToolBarCtrl().HideButton(ID_TOOLS_TOGGLECHECKIN, !Prefs().GetEnableSourceControl());
	}
	
	return (NULL != m_toolbar.GetSafeHwnd());
}

BOOL CToDoListDlg::PreTranslateMessage(MSG* pMsg)
{
	UINT nCmdID = m_mgrShortcuts.ProcessMessage(pMsg);
	
	if (nCmdID)
	{
		BOOL bSendMessage = TRUE; // default
		
		switch (nCmdID)
		{
		case ID_EDIT_COPY:
			// tree must have the focus
			if (!GetToDoCtrl().TreeHasFocus())
			{
				bSendMessage = FALSE;
				GetToDoCtrl().ClearCopiedItem();
			}
			break;
			
		case ID_EDIT_PASTE: // tree must have the focus
			bSendMessage = GetToDoCtrl().TreeHasFocus();
			break;
		}
		
		if (bSendMessage)
		{
			SendMessage(WM_COMMAND, nCmdID);
			return TRUE;
		}
	}
	
	// try toolbar helper
	if (m_tbHelper.ProcessMessage(pMsg))
		return TRUE;
	
	// try active task list
	if (GetTDCCount() && GetToDoCtrl().PreTranslateMessage(pMsg))
		return TRUE;
	
	// don't call CDialog::PreTranslateMessage() because
	// it eats tooltip messages
	// so we need to check for <escape>
	switch (pMsg->message)
	{
	case WM_KEYDOWN:
		{
			switch (pMsg->wParam)
			{
			case VK_ESCAPE:
				if (::IsChild(*this, pMsg->hwnd))
				{
					OnCancel();
					return TRUE;
				}
			}
		}
		break;
	}
	
	return CWnd::PreTranslateMessage(pMsg);
}

void CToDoListDlg::OnCancel()
{
	// if the close button has been configured to Minimize to tray
	// then do that here else normal minimize 
	int nOption = Prefs().GetSysTrayOption();
	
	if (nOption == STO_ONMINCLOSE || nOption == STO_ONCLOSE)
		MinimizeToTray(Prefs().GetAutoSaveOnSysTray());
	
	else
		SendMessage(WM_SYSCOMMAND, SC_MINIMIZE, 0);
}

void CToDoListDlg::OnDeleteTask() 
{
	if (GetToDoCtrl().GetSelectedItem())
		GetToDoCtrl().DeleteSelectedTask();
}

void CToDoListDlg::OnDeleteAllTasks() 
{
	if (GetToDoCtrl().DeleteAllTasks())
	{
		m_mgrToDoCtrls.ClearFilePath(GetSelToDoCtrl()); // this will ensure that the user must explicitly overwrite the original file
		UpdateStatusbar();
	}
}

void CToDoListDlg::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);
	
	BOOL bMaximized = (nType == SIZE_MAXIMIZED);
	
	if (nType != SIZE_MINIMIZED)
		ResizeDlg(cx, cy, bMaximized);
	
	m_stFilePath.EnableGripper(!bMaximized);
	
	// if not maximized then set topmost if that's the preference
	BOOL bTopMost = (Prefs().GetAlwaysOnTop() && !bMaximized) ? 1 : 0;
	
	// do nothing if no change
	BOOL bIsTopMost = (GetExStyle() & WS_EX_TOPMOST) ? 1 : 0;
	
	if (bTopMost != bIsTopMost)
		SetWindowPos(bTopMost ? &wndTopMost : &wndNoTopMost, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
}

BOOL CToDoListDlg::CalcToDoCtrlRect(CRect& rect, int cx, int cy, BOOL bMaximized)
{
	if (!cx && !cy)
	{
		CRect rClient;
		GetClientRect(rClient);
		
		cx = rClient.right;
		cy = rClient.bottom;
		bMaximized = IsZoomed();
		
		// check again 
		if (!cx && !cy)
			return FALSE;
	}
	
	CRect rTaskList(0, 0, cx, cy);
	
	// resize toolbar regardless
	CRect rToolbar = OffsetCtrl(AFX_IDW_TOOLBAR);
	
	rToolbar.right = cx;
	rToolbar.top = GetDlgItem(IDC_HORZDIVIDERTOP)->IsWindowVisible() ? 3 : 0;
	rToolbar.bottom = rToolbar.top + HIWORD(m_toolbar.GetToolBarCtrl().GetButtonSize()) + 2;
	
	if (m_nToolbarOption != TB_TOOLBARHIDDEN) // showing toolbar
		rTaskList.top = rToolbar.bottom;
	
	// resize and pos divider
	CRect rDivider(0, rTaskList.top, cx, rTaskList.top + 2);
	rTaskList.top = rDivider.bottom + 1;
	
	// resize tabctrl
	// hide and disable tabctrl if not needed
	BOOL bNeedTabCtrl = (GetTDCCount() > 1 || !Prefs().GetAutoHideTabbar());
	
	if (bNeedTabCtrl)
	{
		CRect rTabs(0, 0, cx, 0);
		m_tabCtrl.AdjustRect(TRUE, rTabs);
		int nTabHeight = rTabs.Height() - 5;
		
		rTabs = OffsetCtrl(IDC_TABCONTROL); // not actually a move
		rTabs.right = cx + 1;
		rTabs.bottom = rTabs.top + nTabHeight;
		
		rTabs.OffsetRect(0, rTaskList.top - rTabs.top);
		rTaskList.top = rTabs.bottom; // hide the bottom of the tab ctrl
	}
	
	// resize filepath static
	CRect rFilePath = OffsetCtrl(IDC_FILENAME);
	rFilePath.OffsetRect(0, cy - rFilePath.bottom);
	rFilePath.right = cx;
	
	// finally the active todoctrl
	rTaskList.bottom = rFilePath.top - 1;
	
	rect = rTaskList;
	rect.DeflateRect(1, 1);
	
	return TRUE;
}

void CToDoListDlg::ResizeDlg(int cx, int cy, BOOL bMaximized)
{
	if (GetTDCCount() && GetToDoCtrl().GetSafeHwnd())
	{
		if (!cx && !cy)
		{
			CRect rClient;
			GetClientRect(rClient);
			
			cx = rClient.right;
			cy = rClient.bottom;
			bMaximized = IsZoomed();
			
			// check again 
			if (!cx && !cy)
				return;
		}
		
		// resize in one go
		CDeferWndMove dwm(6);
		CRect rTaskList(0, 0, cx, cy);
		
		// resize toolbar regardless
		CRect rToolbar = OffsetCtrl(AFX_IDW_TOOLBAR);
		
		rToolbar.right = cx;
		rToolbar.top = GetDlgItem(IDC_HORZDIVIDERTOP)->IsWindowVisible() ? 3 : 0;
		rToolbar.bottom = rToolbar.top + HIWORD(m_toolbar.GetToolBarCtrl().GetButtonSize()) + 2;
		
		dwm.MoveWindow(&m_toolbar, rToolbar);
		
		if (m_nToolbarOption != TB_TOOLBARHIDDEN) // showing toolbar
			rTaskList.top = rToolbar.bottom;
		
		// resize and pos divider
		CRect rDivider(0, rTaskList.top, cx, rTaskList.top + 2);
		rTaskList.top = rDivider.bottom + 1;
		
		dwm.ResizeCtrl(this, IDC_HORZDIVIDERTOP, cx - OffsetCtrl(IDC_HORZDIVIDER).Width());
		dwm.MoveWindow(GetDlgItem(IDC_HORZDIVIDERBOTTOM), rDivider);
		
		// resize tabctrl
		CRect rTabs(0, 0, cx, 0);
		m_tabCtrl.AdjustRect(TRUE, rTabs);
		int nTabHeight = rTabs.Height() - 5;
		
		rTabs = OffsetCtrl(IDC_TABCONTROL); // not actually a move
		rTabs.right = cx + 1;
		rTabs.bottom = rTabs.top + nTabHeight;
		
		rTabs.OffsetRect(0, rTaskList.top - rTabs.top);
		
		dwm.MoveWindow(&m_tabCtrl, rTabs);//, FALSE);
		
		// hide and disable tabctrl if not needed
		BOOL bNeedTabCtrl = (GetTDCCount() > 1 || !Prefs().GetAutoHideTabbar());
		
		m_tabCtrl.ShowWindow(bNeedTabCtrl ? SW_SHOW : SW_HIDE);
		m_tabCtrl.EnableWindow(bNeedTabCtrl);
		
		if (bNeedTabCtrl)
			rTaskList.top = rTabs.bottom + 1; // hide the bottom of the tab ctrl
		
		// resize filepath static
		CRect rFilePath = OffsetCtrl(IDC_FILENAME);
		rFilePath.OffsetRect(0, cy - rFilePath.bottom);
		rFilePath.right = cx;
		
		dwm.MoveWindow(&m_stFilePath, rFilePath);
		
		// finally the active todoctrl
		rTaskList.bottom = rFilePath.top - 1;
		
		// if we are themed then shrink slightly so that
		// edit controls do not merge with window border
		if (CThemed().IsNonClientThemed())
			rTaskList.DeflateRect(1, 1);
		
		dwm.MoveWindow(&GetToDoCtrl(), rTaskList);
	}
}

CRect CToDoListDlg::OffsetCtrl(UINT uCtrlID, int cx, int cy)
{
	CWnd* pCtrl = GetDlgItem(uCtrlID);
	
	if (pCtrl)
	{
		CRect rChild;
		pCtrl->GetWindowRect(rChild);
		ScreenToClient(rChild);
		
		if (cx || cy)
		{
			rChild.OffsetRect(cx, cy);
			pCtrl->MoveWindow(rChild);
		}
		return rChild;
	}
	
	return CRect(0, 0, 0, 0);
}

void CToDoListDlg::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	CDialog::OnGetMinMaxInfo(lpMMI);
	
	// don't handle if maximized or minimized
	if (!IsZoomed() && !IsIconic())
	{
		int nMinWidth = 352;
		
		if (GetTDCCount()) // ie there is at least CToDoCtrl
		{
			CRect rClient, rWindow;
			
			GetClientRect(rClient);
			GetWindowRect(rWindow);
			
			// odd 'bug'. when the window is being restored the client
			// rect is NULL and this generates an invalid min size
			if (!rClient.IsRectNull())
				nMinWidth = GetToDoCtrl().GetMinWidth() + (rWindow.Width() - rClient.Width());
		}
		
		lpMMI->ptMinTrackSize.x = nMinWidth; // so caption and toolbar is fully visible
		lpMMI->ptMinTrackSize.y = 460; // arbitrary
	}
}

void CToDoListDlg::OnSave() 
{
	if (!SaveTaskList(GetSelToDoCtrl()))
	{
		// check readonly status and notify user
		// TODO
	}
	else
		UpdateCaption();
}

BOOL CToDoListDlg::SaveTaskList(int nIndex, LPCTSTR szFilePath)
{
	CAutoFlag af(m_bSaving, TRUE);
	CString sFilePath = szFilePath ? szFilePath : m_mgrToDoCtrls.GetFilePath(nIndex);
	
	CToDoCtrl& tdc = GetToDoCtrl(nIndex);
	
	tdc.Flush();
	
	// conditions for saving
	// 1. Save As... ie szFilePath != NULL and not empty
	// 2. tasklist has been modified
	
	if ((szFilePath && !sFilePath.IsEmpty()) || tdc.IsModified())
	{
		CPreferencesDlg& prefs = Prefs();
		
		// do this in a loop in case the save fails for _any_ reason
		while (TRUE)
		{
			if (sFilePath.IsEmpty()) // means first time save
			{
				// activate tasklist
				SelectToDoCtrl(nIndex); 
				
				CFileDialogEx dialog(FALSE, "xml", sFilePath, 
					OFN_OVERWRITEPROMPT, XMLFILEFILTER, this);
				
				// incorporate tasklist name into title
				CString sName = m_mgrToDoCtrls.GetFriendlyProjectName(nIndex);
				CString sTitle;
				sTitle.Format("Save Task List (%s) - ToDoList � AbstractSpoon", sName);
				dialog.m_ofn.lpstrTitle = sTitle;
				
				if (dialog.DoModal() != IDOK)
					return FALSE; // user elected not to proceed
				
				// else make sure the file is not readonly
				sFilePath = dialog.GetPathName();
				
				if (CDriveInfo::IsReadonlyPath(sFilePath) > 0)
				{
					CString sMessage;
					sMessage.Format("The file '%s' is read-only.\n\nPlease select another filename", 
						sFilePath);
					
					if (MessageBox(sMessage, ABBREVCOPYRIGHT, MB_OKCANCEL) == IDCANCEL)
						return FALSE; // user elected not to proceed
					else
					{
						sFilePath.Empty(); // try again
						continue;
					}
				}
			}
			
			// update source control status
			BOOL bSrcControl = m_mgrToDoCtrls.PathSupportsSourceControl(sFilePath);

			tdc.SetStyle(TDCS_ENABLESOURCECONTROL, bSrcControl);
			tdc.SetStyle(TDCS_CHECKOUTONLOAD, bSrcControl ? prefs.GetAutoCheckOut() : FALSE);
			
			CWaitCursor cursor;
			CTaskFile tasks;
			
			if (tdc.Save(tasks, sFilePath))
			{
				m_mgrToDoCtrls.SetModifiedStatus(nIndex, FALSE);
				m_mgrToDoCtrls.RefreshLastModified(nIndex);
				m_mgrToDoCtrls.RefreshReadOnlyStatus(nIndex);
				m_mgrToDoCtrls.RefreshPathType(nIndex);
				
				m_mruList.Add(sFilePath);
				
				UpdateCaption();
				UpdateStatusbar();
				
				// export to html?
				if (prefs.GetAutoHtmlExport())
				{
					CString sExportPath = prefs.GetAutoExportFolderPath();
					char szDrive[_MAX_DRIVE], szFolder[_MAX_DIR], szFName[_MAX_FNAME];
					
					_splitpath(sFilePath, szDrive, szFolder, szFName, NULL);
					
					if (!sExportPath.IsEmpty() && CreateFolder(sExportPath))
						_makepath(sFilePath.GetBuffer(MAX_PATH), NULL, sExportPath, szFName, ".html");
					else
						_makepath(sFilePath.GetBuffer(MAX_PATH), szDrive, szFolder, szFName, ".html");
					
					sFilePath.ReleaseBuffer();
					
					// if the users wants all attributes exported then
					// we can simply export the tasks retrieved from CToDoCtrl::Save
					if (prefs.GetExportVisibleColsOnly())
						Export2Html(tdc, sFilePath, prefs.GetSaveExportStylesheet());
					else
						Export2Html(tasks, sFilePath, prefs.GetSaveExportStylesheet());
				}
				
				// we're done
				break;
			}
			else // ask the user if they want to try again
			{
				CString sMessage;
				sMessage.Format("The tasklist could not be saved to '%s'.\n\nPlease ensure you have sufficient disk space and the required access rights and try again.", 
					sFilePath);
				
				if (MessageBox(sMessage, ABBREVCOPYRIGHT, MB_OKCANCEL | MB_ICONEXCLAMATION) == IDCANCEL)
					return FALSE; // user elected not to proceed
				else
				{
					sFilePath.Empty(); // try again
					continue;
				}
			}
		}
	}
	
	return TRUE;
}

void CToDoListDlg::UpdateStatusbar()
{
	int nSel = GetSelToDoCtrl();
	const CToDoCtrl& tdc = GetToDoCtrl(nSel);
	CString sFilePath = tdc.GetFilePath();
	
	if (!sFilePath.IsEmpty())
		m_sStatus.Format("%s (%d tasks, version %d)", sFilePath, tdc.GetTaskCount(), tdc.GetFileVersion());
	else
		m_sStatus.Format("(%d tasks)", tdc.GetTaskCount());
	
	UpdateData(FALSE);
}

void CToDoListDlg::UpdateDefaultSortItem()
{
	TDC_SORTBY nSortBy = GetToDoCtrl().GetSortBy();
	
	if (nSortBy >= 0)
		m_tbHelper.SetDefaultMenuID(ID_SORT, GetSortID(nSortBy));
}

void CToDoListDlg::OnLoad() 
{
	CFileDialogEx dialog(TRUE, "xml", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_ALLOWMULTISELECT, 
		XMLFILEFILTER, this);
	
	const UINT BUFSIZE = 1024 * 5;
	static char FILEBUF[BUFSIZE] = { 0 };
	
	dialog.m_ofn.lpstrTitle = "Open Task List";
	dialog.m_ofn.lpstrFile = FILEBUF;
	dialog.m_ofn.nMaxFile = BUFSIZE;
	
	if (dialog.DoModal() == IDOK)
	{
		UpdateWindow();
		CWaitCursor cursor;
		
		POSITION pos = dialog.GetStartPosition();
		
		while (pos)
		{
			CString sTaskList = dialog.GetNextPathName(pos);
			int nResult = OpenTaskList(sTaskList);
			
			switch (nResult)
			{
			case LOAD_FAILED:
				{
					CString sMessage;
					sMessage.Format("'%s' does not appear to be a valid task list.", sTaskList);
					MessageBox(sMessage, ABBREVCOPYRIGHT, MB_OK);
				}
				break;
				
			case LOAD_SUCCESS:
				ResizeDlg();
				UpdateWindow();
				break;
			}
		}
		
		RefreshTabOrder();
	}
}

void CToDoListDlg::SaveSettings()
{
	// pos
	WINDOWPLACEMENT wp;
	GetWindowPlacement(&wp);
	
	AfxGetApp()->WriteProfileInt("Pos", "TopLeft", MAKELPARAM(wp.rcNormalPosition.left, wp.rcNormalPosition.top));
	AfxGetApp()->WriteProfileInt("Pos", "BottomRight", MAKELPARAM(wp.rcNormalPosition.right, wp.rcNormalPosition.bottom));
	AfxGetApp()->WriteProfileInt("Pos", "Hidden", !m_bVisible);
	AfxGetApp()->WriteProfileInt("Pos", "Maximized", IsZoomed());
	
	// version
	AfxGetApp()->WriteProfileInt("Version", "Version", GetVersion());
	
	// last open files
	int nTDC = GetTDCCount();
	int nSel = GetSelToDoCtrl(); // and last active file
	
	if (nTDC) // but don't overwrite files saved in OnQueryEndSession() or OnClose()
	{
		AfxGetApp()->WriteProfileInt("Settings", "NumLastFiles", nTDC);
		
		while (nTDC--)
		{
			CString sKey;
			sKey.Format("LastFile%d", nTDC);
			AfxGetApp()->WriteProfileString("Settings", sKey, m_mgrToDoCtrls.GetFilePath(nTDC));
			
			if (nSel == nTDC)
				AfxGetApp()->WriteProfileString("Settings", "LastActiveFile", m_mgrToDoCtrls.GetFilePath(nTDC));
		}
	}
	
	// other settings
	AfxGetApp()->WriteProfileInt("Settings", "SimpleMode", m_bSimpleMode);
	AfxGetApp()->WriteProfileInt("Settings", "ToolbarOption", m_nToolbarOption);
	
	if (m_findDlg.GetSafeHwnd())
		AfxGetApp()->WriteProfileInt("Settings", "FindTasksVisible", m_bFindShowing);
	
	m_mruList.WriteList();
}

LRESULT CToDoListDlg::OnPostInitDialog(WPARAM wp, LPARAM lp)
{
	// toolbar
	m_nToolbarOption = -1;
	int nTBOption = AfxGetApp()->GetProfileInt("Settings", "ToolbarOption", TB_TOOLBARANDMENU);
	
	if (nTBOption == -1)
		nTBOption = TB_TOOLBARANDMENU;
	
	SetToolbarOption(nTBOption);
	
	// due task notifications
	int nDueBy = Prefs().GetNotifyDueByOnLoad();
	
	if (nDueBy != PFP_INVALID)
	{
		UpdateWindow();
		m_tabCtrl.UpdateWindow();
		
		int nCtrls = GetTDCCount();
		
		for (int nCtrl = 0; nCtrl < nCtrls; nCtrl++)
			DoDueTaskNotification(&GetToDoCtrl(nCtrl), nDueBy);
	}
	
	// find tasks dialog
	if (AfxGetApp()->GetProfileInt("Settings", "FindTasksVisible", 0))
	{
		OnFindTasks();
		
		if (Prefs().GetRefreshFindOnLoad())
			m_findDlg.RefreshSearch();
	}
	
	return 0L;
}

void CToDoListDlg::LoadSettings()
{
	// MRU
	m_mruList.ReadList();
	
	// settings
	m_bSimpleMode = AfxGetApp()->GetProfileInt("Settings", "SimpleMode", m_bSimpleMode);
	
	// open cmdline tasklist
	if (!m_sCmdLineFilePath.IsEmpty() && ::GetFileAttributes(m_sCmdLineFilePath) != 0xffffffff)
		OpenTaskList(m_sCmdLineFilePath);
	
	m_sCmdLineFilePath.IsEmpty(); // always
	
	// load last files
	if (!GetTDCCount())
	{
		CString sLastActiveFile = AfxGetApp()->GetProfileString("Settings", "LastActiveFile");
		int nTDCCount = AfxGetApp()->GetProfileInt("Settings", "NumLastFiles", 0);
		
		for (int nTDC = 0; nTDC < nTDCCount; nTDC++)
		{
			CString sKey;
			sKey.Format("LastFile%d", nTDC);
			CString sLastFile = AfxGetApp()->GetProfileString("Settings", sKey);
			
			if (!sLastFile.IsEmpty())
				OpenTaskList(sLastFile, FALSE);
		}
		
		// select 
		if (GetTDCCount())
		{
			if (!SelectToDoCtrl(sLastActiveFile))
				SelectToDoCtrl(0); // the first one
		}
	}
	
	if (!GetTDCCount())
		CreateNewTaskList(TRUE);
	
	// pos
	RestorePosition();
	
	int nDefShowState = AfxGetApp()->m_nCmdShow;
	
	// set visibility
	CPreferencesDlg& prefs = Prefs();
	
	BOOL bHidden = AfxGetApp()->GetProfileInt("Pos", "Hidden", FALSE);
	
	BOOL bMaximized = AfxGetApp()->GetProfileInt("Pos", "Maximized", FALSE) || (nDefShowState == SW_SHOWMAXIMIZED);
	BOOL bMinimized = (nDefShowState == SW_SHOWMINIMIZED || nDefShowState == SW_SHOWMINNOACTIVE);
	
	if (bMinimized)
		bMaximized = FALSE; // can't be max-ed and min-ed
	
	if (m_bVisible == -1) // not yet set
	{
		m_bVisible = TRUE;
		
		// the only reason it can be hidden is if it uses the systray
		// and the user has elected to not have it show at startup
		// and it was hidden the last time it closed or its set to run
		// minimized and that is the trigger to hide it
		if (!prefs.GetShowOnStartup() && prefs.GetUseSysTray())
		{
			if (bHidden)
				m_bVisible = FALSE;
			
			// also if wp.showCmd == minimized and we would hide to sys
			// tray when minimized then hide here too
			else if (nDefShowState == SW_SHOWMINIMIZED || nDefShowState == SW_SHOWMINNOACTIVE)
			{
				int nSysTrayOption = Prefs().GetSysTrayOption();
				
				if (nSysTrayOption == STO_ONMINIMIZE || nSysTrayOption == STO_ONMINCLOSE)
					m_bVisible = FALSE;
			}
		}
	}
	
	int nShowCmd = m_bVisible ? (bMaximized ? SW_SHOWMAXIMIZED : 
	(bMinimized ? SW_SHOWMINIMIZED : SW_SHOW)) : SW_HIDE;
	
	ShowWindow(nShowCmd);
	
	// don't set topmost if maximized
	if (prefs.GetAlwaysOnTop() && !bMaximized)
		SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
	
	// hotkey
	UpdateGlobalHotkey();
	
	// time periods
	CTimeEdit::SetHoursInOneDay(prefs.GetHoursInOneDay());
	CTimeEdit::SetDaysInOneWeek(prefs.GetDaysInOneWeek());
}

void CToDoListDlg::RestorePosition()
{
	DWORD dwTopLeft = (DWORD)AfxGetApp()->GetProfileInt("Pos", "TopLeft", -1);
	DWORD dwBottomRight = (DWORD)AfxGetApp()->GetProfileInt("Pos", "BottomRight", -1);
	
	CRect rect(0, 0, 0, 0);
	
	if (dwTopLeft != -1 && dwBottomRight != -1)
	{
		// get min size before we resize
		MINMAXINFO mmi;
		SendMessage(WM_GETMINMAXINFO, 0, (LPARAM)&mmi);
		
		CRect rTemp(GET_X_LPARAM(dwTopLeft), GET_Y_LPARAM(dwTopLeft), 
			GET_X_LPARAM(dwBottomRight), GET_Y_LPARAM(dwBottomRight));
		
		rTemp.right = max(rTemp.right, rTemp.left + mmi.ptMinTrackSize.x);
		rTemp.bottom = max(rTemp.bottom, rTemp.top + mmi.ptMinTrackSize.y);
		
		// ensure this intersects with the desktop
		if (NULL != MonitorFromRect(rTemp, MONITOR_DEFAULTTONULL))
		{
			rect = rTemp;
			MoveWindow(rect);
		}
	}
	
	// first time or monitors changed?
	if (rect.IsRectEmpty())
	{
		MoveWindow(0, 0, 800, 600);
		CenterWindow();
	}
}

void CToDoListDlg::OnNew() 
{
	CreateNewTaskList(TRUE);
	RefreshTabOrder();
}

void CToDoListDlg::CreateNewTaskList(BOOL bAddDefTask)
{
	CToDoCtrl* pNew = NewToDoCtrl();
	
	if (pNew)
	{
		int nNew = AddToDoCtrl(pNew);
		
		// insert a default task
		if (bAddDefTask && pNew->GetTaskCount() == 0)
			VERIFY (NewTask("Task", TDC_INSERTATTOP, TRUE, FALSE));
		
		// clear modified flag
		pNew->SetModified(FALSE);
		m_mgrToDoCtrls.SetModifiedStatus(nNew, FALSE);
	}
	
	UpdateCaption();
	UpdateStatusbar();
}

void CToDoListDlg::OnUpdateDeletetask(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	pCmdUI->Enable(!tdc.IsReadOnly() && tdc.HasSelection());	
}

void CToDoListDlg::OnUpdateEditTasktext(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	pCmdUI->Enable(nSelCount == 1 && !tdc.IsReadOnly());	
}

void CToDoListDlg::OnUpdateTaskcolor(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	pCmdUI->Enable(!tdc.IsReadOnly() && tdc.HasSelection() && 
		Prefs().GetTextColorOption() == COLOROPT_DEFAULT);	
}

void CToDoListDlg::OnUpdateTaskdone(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	if (nSelCount == 1)
		pCmdUI->SetCheck(tdc.IsSelectedTaskDone() ? 1 : 0);
	
	pCmdUI->Enable(!tdc.IsReadOnly() && GetToDoCtrl().GetSelectedItem());	
}

void CToDoListDlg::OnUpdateDeletealltasks(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	pCmdUI->Enable(!tdc.IsReadOnly() && GetToDoCtrl().GetTaskCount());	
}

void CToDoListDlg::OnUpdateSave(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	pCmdUI->Enable(GetTDCCount() && tdc.IsModified() && !tdc.IsReadOnly());	
}

void CToDoListDlg::OnUpdateNew(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(TRUE);	
}

BOOL CToDoListDlg::OnEraseBkgnd(CDC* pDC) 
{
	// don't try to clip out children because the repainting
	// goes horribly wrong
	return CDialog::OnEraseBkgnd(pDC);
}

void CToDoListDlg::OnSortBy(UINT nCmdID)
{
	TDC_SORTBY nSortBy = GetSortBy(nCmdID);
	
	if (nSortBy != (TDC_SORTBY)-1)
	{
		m_tbHelper.SetDefaultMenuID(ID_SORT, nCmdID);
		
		GetToDoCtrl().Sort(nSortBy);
	}
}

void CToDoListDlg::OnUpdateSortBy(CCmdUI* pCmdUI)
{
	// we only need to handle this if the menubar is visible
	// because otherwise CToolbarHelper handles it
	//	if (m_nToolbarOption == TB_TOOLBARHIDDEN)
	{
		TDC_SORTBY nSortBy = GetToDoCtrl().GetSortBy();
		UINT nCmdID = GetSortID(nSortBy);
		
		pCmdUI->SetCheck(nCmdID == pCmdUI->m_nID ? 1 : 0);
	}
}

TDC_SORTBY CToDoListDlg::GetSortBy(UINT nSortID)
{
	switch (nSortID)
	{
	case ID_SORT_BYNAME:		return TDC_SORTBYNAME;
	case ID_SORT_BYID:			return TDC_SORTBYID;
	case ID_SORT_BYALLOCTO:		return TDC_SORTBYALLOCTO;
	case ID_SORT_BYALLOCBY:		return TDC_SORTBYALLOCBY;
	case ID_SORT_BYSTATUS:		return TDC_SORTBYSTATUS;
	case ID_SORT_BYCATEGORY:	return TDC_SORTBYCATEGORY;
	case ID_SORT_BYPERCENT:		return TDC_SORTBYPERCENT;
	case ID_SORT_BYCOLOR:		return TDC_SORTBYCOLOR;
	case ID_SORT_BYTIMEEST:		return TDC_SORTBYTIMEEST;
	case ID_SORT_BYTIMESPENT:	return TDC_SORTBYTIMESPENT;
	case ID_SORT_BYSTARTDATE:	return TDC_SORTBYSTARTDATE;
	case ID_SORT_BYDUEDATE:		return TDC_SORTBYDUEDATE;
	case ID_SORT_BYDONEDATE:	return TDC_SORTBYDONEDATE;
	case ID_SORT_BYDONE:		return TDC_SORTBYDONE;
	case ID_SORT_BYPRIORITY:	return TDC_SORTBYPRIORITY;
	case ID_SORT_NONE:	        return TDC_SORTBYNONE;
	}
	
	ASSERT (0);
	return (TDC_SORTBY)-1;
}

UINT CToDoListDlg::GetSortID(TDC_SORTBY nSortBy)
{
	switch (nSortBy)
	{
	case TDC_SORTBYNAME:		return ID_SORT_BYNAME;
	case TDC_SORTBYID:			return ID_SORT_BYID;
	case TDC_SORTBYALLOCTO:		return ID_SORT_BYALLOCTO;
	case TDC_SORTBYALLOCBY:		return ID_SORT_BYALLOCBY;
	case TDC_SORTBYSTATUS:		return ID_SORT_BYSTATUS;
	case TDC_SORTBYCATEGORY:	return ID_SORT_BYCATEGORY;
	case TDC_SORTBYPERCENT:		return ID_SORT_BYPERCENT;
	case TDC_SORTBYCOLOR:		return ID_SORT_BYCOLOR;
	case TDC_SORTBYTIMEEST:		return ID_SORT_BYTIMEEST;
	case TDC_SORTBYTIMESPENT:	return ID_SORT_BYTIMESPENT;
	case TDC_SORTBYSTARTDATE:	return ID_SORT_BYSTARTDATE;
	case TDC_SORTBYDUEDATE:		return ID_SORT_BYDUEDATE;
	case TDC_SORTBYDONEDATE:	return ID_SORT_BYDONEDATE;
	case TDC_SORTBYDONE:		return ID_SORT_BYDONE;
	case TDC_SORTBYPRIORITY:	return ID_SORT_BYPRIORITY;
	case TDC_SORTBYFLAG:	    return ID_SORT_BYFLAG;
	case TDC_SORTBYNONE:	    return ID_SORT_NONE;
	}
	
	ASSERT (0);
	return 0;
}

void CToDoListDlg::OnNewtaskAttopSelected() 
{
	VERIFY (NewTask("Task", TDC_INSERTATTOPOFSELTASKPARENT));
}

void CToDoListDlg::OnNewtaskAtbottomSelected() 
{
	VERIFY (NewTask("Task", TDC_INSERTATBOTTOMOFSELTASKPARENT));
}

void CToDoListDlg::OnNewtaskAfterselectedtask() 
{
	VERIFY (NewTask("Task", TDC_INSERTAFTERSELTASK));
}

void CToDoListDlg::OnNewtaskBeforeselectedtask() 
{
	VERIFY (NewTask("Task", TDC_INSERTBEFORESELTASK));
}

void CToDoListDlg::OnNewsubtaskAtbottom() 
{
	VERIFY (NewTask("Task", TDC_INSERTATBOTTOMOFSELTASK));
}

void CToDoListDlg::OnNewsubtaskAttop() 
{
	VERIFY (NewTask("Task", TDC_INSERTATTOPOFSELTASK));
}

BOOL CToDoListDlg::NewTask(LPCTSTR szTitle, TDC_INSERTWHERE nInsertWhere, BOOL bSelect, BOOL bEdit)
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	if (tdc.IsReadOnly())
		return FALSE;
	
	// handle special case when tasklist is empty
	if (!tdc.GetTaskCount())
		nInsertWhere = TDC_INSERTATBOTTOM;
	
	if (!tdc.NewTask(szTitle, nInsertWhere, bSelect, bEdit))
		return FALSE;
	
	// else init attributes other than defaults
	CAutoFlag af(m_bInNewTask, TRUE);
	CPreferencesDlg& prefs = Prefs();
	
	if (prefs.GetUseParentAttrib(PTPA_ALLOCTO))
		tdc.SetSelectedTaskAttributeAsParent(TDCA_ALLOCTO);
	
	if (prefs.GetUseParentAttrib(PTPA_ALLOCBY))
		tdc.SetSelectedTaskAttributeAsParent(TDCA_ALLOCBY);
	
	if (prefs.GetUseParentAttrib(PTPA_STATUS))
		tdc.SetSelectedTaskAttributeAsParent(TDCA_STATUS);
	
	if (prefs.GetUseParentAttrib(PTPA_CATEGORY))
		tdc.SetSelectedTaskAttributeAsParent(TDCA_CATEGORY);
	
	if (prefs.GetUseParentAttrib(PTPA_TIMEEST))
		tdc.SetSelectedTaskAttributeAsParent(TDCA_TIMEEST);
	
	if (prefs.GetUseParentAttrib(PTPA_PRIORITY))
		tdc.SetSelectedTaskAttributeAsParent(TDCA_PRIORITY);
	
	if (prefs.GetUseParentAttrib(PTPA_COLOR))
		tdc.SetSelectedTaskAttributeAsParent(TDCA_COLOR);
	
	return TRUE;
}

void CToDoListDlg::OnUpdateSort(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	// note: we're still allowed to sort when readonly but the result is not saved
	pCmdUI->Enable(GetTDCCount() && GetToDoCtrl().GetTaskCount());	
}

void CToDoListDlg::OnEditTaskcolor() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	if (!tdc.IsReadOnly() && tdc.HasSelection())
	{
		CEnColorDialog dialog(tdc.GetSelectedTaskColor(), CC_FULLOPEN | CC_RGBINIT);
		
		if (dialog.DoModal() == IDOK)
			tdc.SetSelectedTaskColor(dialog.GetColor());
	}
}

void CToDoListDlg::OnEditTaskdone() 
{
	GetToDoCtrl().SetSelectedTaskDone(!GetToDoCtrl().IsSelectedTaskDone());
}

void CToDoListDlg::OnEditTasktext() 
{
	GetToDoCtrl().EditSelectedTask();
}

void CToDoListDlg::OnTrayIconClick(NMHDR* pNMHDR, LRESULT* pResult)
{
	Show(Prefs().GetToggleTrayVisibility());
	
	*pResult = 0;
}

LRESULT CToDoListDlg::OnToDoListShowWindow(WPARAM wp, LPARAM lp)
{
	Show(FALSE);
	return 0;
}

LRESULT CToDoListDlg::OnToDoListGetVersion(WPARAM wp, LPARAM lp)
{
	return GetVersion();
}

void CToDoListDlg::OnTrayIconDblClk(NMHDR* pNMHDR, LRESULT* pResult)
{
	Show(FALSE);
	
	*pResult = 0;
}

void CToDoListDlg::OnTrayiconCreatetask() 
{
	Show(FALSE);
	
	// create a task at the top of the tree
	GetToDoCtrl().NewTask("Task", TDC_INSERTATTOP);
}

void CToDoListDlg::OnTrayIconRClick(NMHDR* pNMHDR, LRESULT* pResult)
{
	SetForegroundWindow();
	
	// show context menu
	CMenu menu;
	
	if (menu.LoadMenu(IDR_MISC))
	{
		CMenu* pSubMenu = menu.GetSubMenu(TRAYICON);
		pSubMenu->SetDefaultItem(ID_TRAYICON_SHOW);
		
		NM_TRAYICON* pNMTI = (NM_TRAYICON*)pNMHDR;
		
		if (pSubMenu)
		{
			pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON, pNMTI->ptAction.x, pNMTI->ptAction.y, this);
			PostMessage(WM_NULL);
		}
	}
}

void CToDoListDlg::OnClose() 
{
	int nSysTrayOption = Prefs().GetSysTrayOption();
	
	if (nSysTrayOption == STO_ONCLOSE || nSysTrayOption == STO_ONMINCLOSE)
		MinimizeToTray(Prefs().GetAutoSaveOnSysTray());
	
	else // shutdown but user can cancel
		DoExit();
}

void CToDoListDlg::MinimizeToTray(BOOL bAutoSave)
{
	// save prev state so we can restore properly
	AfxGetApp()->WriteProfileInt("Pos", "Maximized", IsZoomed());
	
	if (bAutoSave)
	{
		// save all
		int nCtrl = GetTDCCount();
		
		while (nCtrl--)
		{
			if (!SaveTaskList(nCtrl))
				return; // user cancelled
			else
				m_mgrToDoCtrls.UpdateTabItemText(nCtrl);
		}
		
		UpdateCaption();
	}
	
	// hide main window and release resources
	MinToTray(*this); // courtesy of floyd
	SetProcessWorkingSetSize(GetCurrentProcess(), -1, -1); 
	m_bVisible = FALSE;
	
	// hide find dialog
	m_bFindShowing = m_findDlg.IsWindowVisible();
	m_findDlg.Show(FALSE);
}

void CToDoListDlg::OnTrayiconClose() 
{
	DoExit();
}

LRESULT CToDoListDlg::OnToDoCtrlNotifySort(WPARAM wp, LPARAM lp)
{
	UpdateDefaultSortItem();
	
	return 0;
}

LRESULT CToDoListDlg::OnToDoCtrlNotifyMinWidthChange(WPARAM wp, LPARAM lp)
{
	CheckMinWidth();
	
	return 0;
}

LRESULT CToDoListDlg::OnToDoCtrlNotifyMod(WPARAM wp, LPARAM lp)
{
	int nSel = GetSelToDoCtrl();
	
	if (nSel == -1)
		return 0L;
	
	BOOL bWasMod = m_mgrToDoCtrls.GetModifiedStatus(nSel);
	m_mgrToDoCtrls.SetModifiedStatus(nSel, TRUE);
	
	// update the caption only if the control is not currently modified
	// or the project name changed
	if (!bWasMod || lp == TDCA_PROJNAME)
		UpdateCaption();
	
	// update due items
	if (lp == TDCA_DONEDATE || lp == TDCA_DUEDATE)
		OnTimerDueItems(nSel);
	
	// decide whether to resort or not
	CPreferencesDlg& prefs = Prefs();
	
	if (!m_bInNewTask && lp != TDCA_PROJNAME && lp != TDCA_NONE && prefs.GetAutoReSort())
	{
		// we only sort if the thing that changed is the current sort key
		CToDoCtrl& tdc = GetToDoCtrl();
		
		TDC_SORTBY nSortBy = tdc.GetSortBy();
		
		switch (lp)
		{
		case TDCA_TASKNAME:
			if (TDC_SORTBYNAME != nSortBy)
				return 0;
			break;
			
		case TDCA_DONEDATE:
			if (!prefs.GetSortDoneTasksAtBottom())
			{
				// also check percent and priority
				if (TDC_SORTBYPERCENT != nSortBy && 
					TDC_SORTBYDONEDATE != nSortBy &&
					TDC_SORTBYDONE != nSortBy &&
					TDC_SORTBYPRIORITY != nSortBy &&
					TDC_SORTBYSTARTDATE != nSortBy &&
					TDC_SORTBYDUEDATE != nSortBy)
					return 0;
			}
			break;
			
		case TDCA_DUEDATE:
			// also check priority
			if (TDC_SORTBYDUEDATE != nSortBy && TDC_SORTBYPRIORITY != nSortBy)
				return 0;
			break;
			
		case TDCA_STARTDATE:
			if (TDC_SORTBYSTARTDATE != nSortBy)
				return 0;
			break;
			
		case TDCA_PRIORITY:
			if (TDC_SORTBYPRIORITY != nSortBy)
				return 0;
			break;
			
		case TDCA_COLOR:
			if (TDC_SORTBYCOLOR != nSortBy)
				return 0;
			break;
			
		case TDCA_ALLOCTO:
			if (TDC_SORTBYALLOCTO != nSortBy)
				return 0;
			break;
			
		case TDCA_ALLOCBY:
			if (TDC_SORTBYALLOCBY != nSortBy)
				return 0;
			break;
			
		case TDCA_PERCENT:
			if (TDC_SORTBYPERCENT != nSortBy)
				return 0;
			break;
			
		case TDCA_STATUS:
			if (TDC_SORTBYSTATUS != nSortBy)
				return 0;
			break;
			
		case TDCA_CATEGORY:
			if (TDC_SORTBYCATEGORY != nSortBy)
				return 0;
			break;
			
		case TDCA_TIMEEST:
			if (TDC_SORTBYTIMEEST != nSortBy)
				return 0;
			break;
			
		case TDCA_TIMESPENT:
			if (TDC_SORTBYTIMESPENT != nSortBy)
				return 0;
			break;
			
		default:
			return 0;
		}
		
		tdc.Sort(nSortBy);
	}
	else if (lp == TDCA_PROJNAME)
		RefreshTabOrder();
	
	return 0L;
}

void CToDoListDlg::UpdateCaption()
{
	int nSel = GetSelToDoCtrl();
	
	CString sProjectName = m_mgrToDoCtrls.UpdateTabItemText(nSel);
	CToDoCtrl& tdc = GetToDoCtrl();
	
	if (m_mgrToDoCtrls.GetReadOnlyStatus(nSel) > 0)
		sProjectName += " [read-only]";
	
	else if (tdc.CompareFileFormat() == TDCFF_NEWER)
		sProjectName += " [read-only: newer format]";
	
	else if (m_mgrToDoCtrls.GetReadOnlyStatus(nSel) == 0 && 
		m_mgrToDoCtrls.PathSupportsSourceControl(nSel))
	{
		if (tdc.IsCheckedOut())
			sProjectName += " [checked out]";
		else
			sProjectName += " [checked in]";
	}
	else if (!Prefs().GetEnableSourceControl() && m_mgrToDoCtrls.IsSourceControlled(nSel))
	{
		sProjectName += " [read-only: under source control]";
	}
	
	CString sCaption;
	sCaption.Format("%s - %s 2005", sProjectName, ABBREVCOPYRIGHT);
	SetWindowText(sCaption);
}

void CToDoListDlg::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos) 
{
	CDialog::OnWindowPosChanging(lpwndpos);
}

void CToDoListDlg::OnUpdateNewsubtaskAtBottom(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount == 1);
}

BOOL CToDoListDlg::Export2Html(CToDoCtrl& tdc, LPCTSTR szFilePath, LPCTSTR szStylesheet) const
{
	CWaitCursor cursor;
	
	tdc.Flush();
	
	// options
	BOOL bVisColsOnly = Prefs().GetExportVisibleColsOnly();
	
	CTaskFile tasks;
	tdc.GetTasklist(tasks, bVisColsOnly);
	
	return Export2Html(tasks, szFilePath, szStylesheet);
}

BOOL CToDoListDlg::Export2Html(const CTaskFile& tasks, LPCTSTR szFilePath, LPCTSTR szStylesheet) const
{
	CWaitCursor cursor;
	
	if (GetFileAttributes(szStylesheet) != 0xffffffff)
		return tasks.TransformToFile(szStylesheet, szFilePath);
	
	// else default export
	return m_mgrImportExport.ExportTaskListToHtml(&tasks, szFilePath);
}


/*
BOOL CToDoListDlg::Export2Text(CToDoCtrl& tdc, LPCTSTR szFilePath, LPCTSTR szTitle) const
{
CWaitCursor cursor;

  tdc.Flush();
  
	// options
	BOOL bVisColsOnly = Prefs().GetExportVisibleColsOnly();
	BOOL bPreview  = Prefs().GetPreviewExport();
	
	  CTaskFile tasks;
	  tdc.GetTasks(tasks, TDCF_ALL, bVisColsOnly);
	  
		if (szTitle)
		tasks.SetProjectName(szTitle);
		else
		tasks.SetProjectName(tdc.GetProjectName());
		
		  return CTaskListTxtExporter().Export(&tasks, szFilePath);
		  }
*/
void CToDoListDlg::OnSaveas() 
{
	int nSel = GetSelToDoCtrl();
	CToDoCtrl& tdc = GetToDoCtrl(nSel);
	
	// display the dialog
	CFileDialogEx dialog(FALSE, "xml", tdc.GetFilePath(), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, 
		XMLFILEFILTER, this);
	
	dialog.m_ofn.lpstrTitle = "Save Task List As";
	
	int nRes = dialog.DoModal();
	
	if (nRes == IDOK)
		SaveTaskList(nSel, dialog.GetPathName());
}

void CToDoListDlg::OnUpdateSaveas(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	pCmdUI->Enable(tdc.GetTaskCount() || tdc.IsModified());
}

void CToDoListDlg::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	UINT nMenuID = 0;
	
	if (pWnd == &m_tabCtrl)
	{
		// if point.x,y are both -1 then we just use the cursor pos
		// which is what windows appears to do mostly/sometimes
		if (point.x == -1 && point.y == -1)
		{
			CRect rTab;
			
			if (m_tabCtrl.GetItemRect(m_tabCtrl.GetCurSel(), rTab))
			{
				point = rTab.CenterPoint();
				m_tabCtrl.ClientToScreen(&point);
				
				// load popup menu
				nMenuID = TABCTRL;
			}
		}
		else
		{
			// activate clicked tab
			TCHITTESTINFO tcht = { { point.x, point.y }, TCHT_NOWHERE  };
			m_tabCtrl.ScreenToClient(&tcht.pt);
			
			int nTab = m_tabCtrl.HitTest(&tcht);
			
			if (nTab != -1 && !(tcht.flags & TCHT_NOWHERE))
			{
				if (nTab != m_tabCtrl.GetCurSel())
					SelectToDoCtrl(nTab);
				
				m_tabCtrl.SetFocus(); // give user feedback
				
				// load popup menu
				nMenuID = TABCTRL;
			}
		}
	}
	else if (pWnd == &GetToDoCtrl()) // try active todoctrl
		nMenuID = TASKCONTEXT;
	
	// show the menu
	if (nMenuID)
	{
		CMenu menu;
		
		if (menu.LoadMenu(IDR_MISC))
		{
			CMenu* pPopup = menu.GetSubMenu(nMenuID);
			
			if (pPopup)
			{
				CToolbarHelper::PrepareMenuItems(pPopup, this);
				
				pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON, point.x, point.y, this);
			}
		}
	}
	else
		CDialog::OnContextMenu(pWnd, point);
}
/*
UINT CToDoListDlg::OnGetDlgCode() 
{
return (CDialog::OnGetDlgCode());
}
*/
void CToDoListDlg::OnTrayiconShow() 
{
	Show(FALSE);
}

LRESULT CToDoListDlg::OnHotkey(WPARAM wp, LPARAM lp)
{
	Show(FALSE);
	return 0L;
}

void CToDoListDlg::Show(BOOL bAllowToggle)
{
	// refresh active tasklist
	int nIndex = GetSelToDoCtrl();
	
	OnTimerReadOnlyStatus(nIndex);
	OnTimerTimestampChange(nIndex);
	OnTimerCheckoutStatus(nIndex);
	
	if (!m_bVisible || !IsWindowVisible()) // restore from the tray
	{
		m_bVisible = TRUE;
		SetProcessWorkingSetSize(GetCurrentProcess(), 0, 0); 
		RestoreFromTray(*this, AfxGetApp()->GetProfileInt("Pos", "Maximized", FALSE));
		
		int nTBOption = m_nToolbarOption;
		m_nToolbarOption = -1;
		
		SetToolbarOption(nTBOption);
		
		// restore find dialog
		if (m_bFindShowing)
			m_findDlg.Show();
	}
	else if (IsIconic())
	{
		ShowWindow(SW_RESTORE);
		SetForegroundWindow();
	}
	// if we're already visible then either bring to the foreground 
	// or hide if we're right at the top of the z-order
	else if (!bAllowToggle || IsObscured(*this))
		SetForegroundWindow();
	else
	{
		m_bVisible = FALSE;
		MinToTray(*this);
		SetProcessWorkingSetSize(GetCurrentProcess(), -1, -1); 
	}
}

BOOL CToDoListDlg::OnQueryEndSession() 
{
	if (!CDialog::OnQueryEndSession())
		return FALSE;
	
	SaveAll(TRUE, TRUE, TRUE);
	SaveSettings();
	
	int nCtrl = GetTDCCount();
	
	while (nCtrl--)
		CloseToDoCtrl(nCtrl, TRUE);
	
	DestroyWindow(); // because otherwise we would get left in an undefined state
	
	return TRUE;
}

void CToDoListDlg::OnUpdateRecentFileMenu(CCmdUI* pCmdUI) 
{
	m_mruList.UpdateMenu(pCmdUI);	
}

BOOL CToDoListDlg::OnOpenRecentFile(UINT nID)
{
	ASSERT(nID >= ID_FILE_MRU_FILE1);
	ASSERT(nID < ID_FILE_MRU_FILE1 + (UINT)m_mruList.GetSize());
	
	int nIndex = nID - ID_FILE_MRU_FILE1;
	CString sPathName = m_mruList[nIndex];
	
	int nResult = OpenTaskList(sPathName);
	
	switch (nResult)
	{
	case LOAD_FAILED:
		{
			MessageBox("The selected task list could not be opened.\n\nPlease check that "
				"it has not been moved or deleted.", ABBREVCOPYRIGHT, MB_OK);
			m_mruList.Remove(nIndex);
		}
		break;
		
	default:
		RefreshTabOrder();
		break;
	}
	
	// always return TRUE to say we handled it
	return TRUE;
}

void CToDoListDlg::RefreshTabOrder()
{
	if (Prefs().GetKeepTabsOrdered())
	{
		int nSelOrg = GetSelToDoCtrl();
		int nSel = m_mgrToDoCtrls.SortToDoCtrlsByName();
		
		if (nSel != nSelOrg)
			SelectToDoCtrl(nSel);
	}
}

int CToDoListDlg::OpenTaskList(LPCTSTR szFilePath, BOOL bNotifyDueTasks)
{
	// see if the tasklist is already open
	if (SelectToDoCtrl(szFilePath))
		return LOAD_SUCCESS;
	
	// init archive params?
	CString sArchivePath;
	TDC_ARCHIVE nRemove = TDC_REMOVENONE;
	CPreferencesDlg& prefs = Prefs();
	
	if (prefs.GetAutoArchive())
	{
		if (prefs.GetRemoveArchivedTasks())
		{
			if (prefs.GetRemoveOnlyOnAbsoluteCompletion())
				nRemove = TDC_REMOVEIFSIBLINGSANDSUBTASKSCOMPLETE;
			else
				nRemove = TDC_REMOVEALL;
		}
		
		sArchivePath = m_mgrToDoCtrls.GetArchivePath(szFilePath);
	}
	
	CToDoCtrl* pCtrl = NewToDoCtrl();
	
	int nResult = OpenTaskList(pCtrl, szFilePath, sArchivePath, nRemove);
	
	if (nResult == LOAD_SUCCESS)
	{
		int nIndex = AddToDoCtrl(pCtrl);
		
		// notify user of due tasks if req
		if (bNotifyDueTasks)
			DoDueTaskNotification(pCtrl, prefs.GetNotifyDueByOnLoad());
		
		// save checkout status
		if (prefs.GetAutoCheckOut())
			m_mgrToDoCtrls.SetLastCheckoutStatus(nIndex, pCtrl->IsCheckedOut());
		
		UpdateCaption();
		UpdateStatusbar();
		UpdateDefaultSortItem();
		OnTimerDueItems(nIndex);
		
		// notify user if file is readonly for any reason except checked in
		if (prefs.GetNotifyReadOnly())
		{
			CString sMessage;
			
			if (CDriveInfo::IsReadonlyPath(szFilePath))
				sMessage.Format("The file '%s' is currently read-only \nand you will not be able "
				"to make any changes to it.", szFilePath);
			
			else if (!prefs.GetEnableSourceControl() && m_mgrToDoCtrls.IsSourceControlled(nIndex))
				sMessage.Format("The file '%s' is currently held under source control \nand "
				"you will not be able to make any changes to it.\n\nTo edit the file you need to enable source control and check the file out.", szFilePath);
			
            else if (pCtrl->CompareFileFormat() == TDCFF_NEWER)
                sMessage.Format("The file '%s' has a more recent file format than your \ncurrent "
				"version of ToDoList and you will therefore not be able to make "
				"any \nchanges to it.", szFilePath);
			
			if (!sMessage.IsEmpty())
				MessageBox(sMessage, ABBREVCOPYRIGHT);
		}
		
		// update search
		if (prefs.GetRefreshFindOnLoad() && m_findDlg.GetSafeHwnd())
			m_findDlg.RefreshSearch();
	}
	else if (GetTDCCount() >= 1) // only delete if there's another ctrl existing
	{
		pCtrl->DestroyWindow();
		delete pCtrl;
	}
	else // re-add
	{
		AddToDoCtrl(pCtrl);
	}
	
	return nResult;
}

int CToDoListDlg::OpenTaskList(CToDoCtrl* pCtrl, LPCTSTR szFilePath, LPCTSTR szArchivePath, TDC_ARCHIVE nRemove)
{
	CPreferencesDlg& prefs = Prefs();
	CWaitCursor cursor;
	CString sFilePath(szFilePath);
	
	if (sFilePath.IsEmpty())
		sFilePath = (LPCTSTR)pCtrl->GetFilePath(); // ie. reload
	
	else // initialize source control prior to loading
	{
		BOOL bSrcControl = m_mgrToDoCtrls.PathSupportsSourceControl(szFilePath);

		pCtrl->SetStyle(TDCS_ENABLESOURCECONTROL, bSrcControl);
		pCtrl->SetStyle(TDCS_CHECKOUTONLOAD, bSrcControl ? prefs.GetAutoCheckOut() : FALSE);
	}
	
	TDC_OPEN nResult = pCtrl->Load(sFilePath, szArchivePath, nRemove);
	
	switch (nResult)
	{
	case TDCO_SUCCESS:
		{
			m_mruList.Add(sFilePath);
			
			// update readonly status
			pCtrl->SetReadonly(IsReadOnly(*pCtrl)); // takes source control into account too
			
			return LOAD_SUCCESS;
		}
		
	case TDCO_CANCELLED:
		return LOAD_CANCELLED;
	}
	
	// else
	return LOAD_FAILED;
}

BOOL CToDoListDlg::DoDueTaskNotification(const CToDoCtrl* pCtrl, int nDueBy)
{
	// check prefs
	if (nDueBy == -1)
		return TRUE; // nothing to do
	
	ASSERT (pCtrl);
	
	if (!pCtrl)
		return FALSE;
	
	CPreferencesDlg& prefs = Prefs();
	
	// preferences
	BOOL bPreview = prefs.GetPreviewExport();
	BOOL bVisColsOnly = prefs.GetExportVisibleColsOnly();
	BOOL bParentTitleCommentsOnly = prefs.GetExportParentTitleCommentsOnly();
	BOOL bDueTaskTitlesOnly = prefs.GetDueTaskTitlesOnly();
	
	DWORD dwFlags = (bVisColsOnly ? TDCGT_VISIBLECOLSONLY : 0) | TDCGT_ISODATES |
		(bParentTitleCommentsOnly ? TDCGT_PARENTTITLECOMMENTSONLY : 0) |
		(bDueTaskTitlesOnly ? TDCGT_TITLESONLY : 0);
	
	CString sDueBy("today");
	TDC_FILTER nFilter = TDCF_DUE;
	
	switch (nDueBy)
	{
	case PFP_DUETODAY:
		break; // done
		
	case PFP_DUETOMORROW:
		sDueBy = "tomorrow";
		nFilter = TDCF_DUETOMORROW;
		break;
		
	case PFP_DUETHISWEEK:
		sDueBy = "by the end of this week";
		nFilter = TDCF_DUETHISWEEK;
		break;
		
	case PFP_DUENEXTWEEK:
		sDueBy = "by the end of next week";
		nFilter = TDCF_DUENEXTWEEK;
		break;
		
	case PFP_DUETHISMONTH:
		sDueBy = "by the end of this month";
		nFilter = TDCF_DUETHISMONTH;
		break;
		
	case PFP_DUENEXTMONTH:
		sDueBy = "by the end of next month";
		nFilter = TDCF_DUENEXTMONTH;
		break;
		
	default:
		ASSERT (0);
		return FALSE;
	}
	
	CTaskFile tasks;
	
	if (!pCtrl->GetTasks(tasks, nFilter, dwFlags, prefs.GetDueTaskPerson()))
		return FALSE;
	
	// set an appropriate title
	CString sTitle;
	sTitle.Format("The following tasks are due %s:", sDueBy);
	
	// display in browser?
	if (prefs.GetDisplayDueTasksInHtml())
	{
		char szTempFile[MAX_PATH], szTempPath[MAX_PATH];
		
		if (!::GetTempPath(MAX_PATH, szTempPath))
			return TRUE;
		
		// always use the same file
		_makepath(szTempFile, NULL, szTempPath, "ToDoList.due", "html");
		
		tasks.SetProjectName(sTitle);
		
		CString sStylesheet = prefs.GetDueTaskStylesheet();
		BOOL bRes = FALSE;
		
		if (GetFileAttributes(sStylesheet) != 0xffffffff)
			bRes = tasks.TransformToFile(sStylesheet, szTempFile);
		else
			bRes = m_mgrImportExport.ExportTaskListToHtml(&tasks, szTempFile);
		
		if (bRes)
		{
			CBrowserDlg dialog;
			dialog.DoModal("Due Tasks", szTempFile, this);
		}
	}
	else // format as message
	{
		CString sDueTasks = m_mgrImportExport.ExportTaskListToText(&tasks);
		
		// remove double line spacing
		sDueTasks.Replace("\n\n", "\n");
		sDueTasks = sTitle + "\n" + sDueTasks;
		
		MessageBox(sDueTasks, ABBREVCOPYRIGHT);
	}
	
	return TRUE;
}

void CToDoListDlg::EnsureVisible()
{
	// make sure app window is visible
	if (!IsWindowVisible())
	{
		m_bVisible = TRUE;
		ShowWindow(SW_SHOWNORMAL);
		
		if (m_nToolbarOption == -1)
		{
			RestorePosition();
			
			int nTBOption = AfxGetApp()->GetProfileInt("Settings", "ToolbarOption", TB_TOOLBARANDMENU);
			SetToolbarOption(nTBOption);
		}
	}
}

void CToDoListDlg::OnAbout() 
{
	const LPCTSTR COPYRIGHT = "Copyright � 2003-05 <a href=www.abstractspoon.com>"
		"<font color=\"#006000\" face=\"tahoma\">"
		"<u><b>Abstract</b><i>Spoon </i>Software</u></font></a>"
		"<br>All Icons Copyright � 2005 <a href=\"www.awicons.com/\">AWIcons</a>"
		"<br><br><b>Credits</b>"
		"<br>&bull; Paul DiLascia (of course)"
		"<br>&bull; :floyd: (part of the System Tray code)"
		"<br>&bull; Hans Dietrich (HTML control)"
		"<br>&bull; Armen Hakobyan (Enhanced folder dialog)"
		"<br>&bull; Open Office (Spellcheck Engine and Dictionaries)"
		"<br>&bull; Alex Hazanov (MSXML wrapper classes)"
		"<br>&bull; Richard Butler (Encryption)"
		"<br>&bull; Johan Rosegren (RTF control)";
	
	CAboutDlg dialog(IDI_MAINFRAME, "<b>ToDoList 4.3.5</b>", 
		"A simple and effective way to keep on top of your programming tasks (freeware)",
		COPYRIGHT, 1, 2, 13);
	
	dialog.DoModal();
}

void CToDoListDlg::OnPreferences() 
{
	CPreferencesDlg& curPrefs = Prefs(); // current prefs
	
	BOOL bSourceControl = curPrefs.GetEnableSourceControl(); // so we can tell if it has changed
	BOOL bLanOnly = curPrefs.GetSourceControlLanOnly(); // likewise
	BOOL bLargecons = curPrefs.GetLargeToolbarIcons(); // "
	BOOL bAutoHideTabbar = curPrefs.GetAutoHideTabbar(); // "
	BOOL bStackTabbar = curPrefs.GetStackTabbarItems(); // "
	BOOL bTrackActiveTasklist = curPrefs.GetTrackActiveTasklistOnly();
	BOOL bCloseBtn = curPrefs.GetShowTasklistCloseButton();
	
	// kill timers
	SetTimer(TIMER_READONLYSTATUS, FALSE);
	SetTimer(TIMER_TIMESTAMPCHANGE, FALSE);
	SetTimer(TIMER_CHECKOUTSTATUS, FALSE);
	SetTimer(TIMER_AUTOSAVE, FALSE);
	
	UINT nRet = curPrefs.DoModal();
	
	// updates prefs
	ResetPrefs();
	
	if (nRet == IDOK)
	{
		CPreferencesDlg& prefs = Prefs(); // new prefs
		
		// mark all todoctrls as needing refreshing
		m_mgrToDoCtrls.SetAllNeedPreferenceUpdate(TRUE); 
		
		// recreate fonts and recreate in UpdateToDoCtrlPrefs
		m_fontTree.DeleteObject();
		m_fontComments.DeleteObject();
		
		BOOL bResizeDlg = FALSE;
		
		// topmost
		BOOL bTopMost = (prefs.GetAlwaysOnTop() && !IsZoomed());
		
		SetWindowPos(bTopMost ? &wndTopMost : &wndNoTopMost, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
		
		// tray icon
		m_ti.ShowTrayIcon(prefs.GetUseSysTray());
		
		// source control
		if (bSourceControl != prefs.GetEnableSourceControl() ||
			bLanOnly != prefs.GetSourceControlLanOnly())
		{
			bSourceControl = prefs.GetEnableSourceControl();
			bLanOnly = prefs.GetSourceControlLanOnly();
			
			// update all open files to ensure they're in the right state
			int nCtrl = GetTDCCount();
			
			while (nCtrl--)
			{
				CToDoCtrl& tdc = GetToDoCtrl(nCtrl);
				
				// check files in if we're disabling sc and this file is
				// checked out. however although we 
				// are checking in, the file cannot be edited by the user
				// until they remove the file from under source control
				if (!bSourceControl && tdc.IsCheckedOut())
				{
					if (tdc.IsModified())
						tdc.Save(NULL, FALSE);
					
					tdc.CheckIn();
				}
				// else checkout if we're enabling and auto-checkout
				// is also enabled
				else if (bSourceControl)
				{
					// there can be two reasons for wanting to check out a file
					// either the autocheckout preference is set or its a local
					// file which is not checked out but has been modified and source
					// control now covers all files in which case we save it first
					BOOL bPathSupports = m_mgrToDoCtrls.PathSupportsSourceControl(nCtrl);
					BOOL bNeedsSave = bPathSupports && !tdc.IsCheckedOut() && tdc.IsModified();
					BOOL bWantCheckOut = bNeedsSave || (bPathSupports && prefs.GetAutoCheckOut());

					if (bNeedsSave)
						tdc.Save(NULL, FALSE); // save silently

					tdc.SetStyle(TDCS_ENABLESOURCECONTROL, bPathSupports);
					tdc.SetStyle(TDCS_CHECKOUTONLOAD, bPathSupports && prefs.GetAutoCheckOut());

					if (bWantCheckOut && !tdc.IsCheckedOut())
						tdc.CheckOut();
				}
				
				// re-sync
				tdc.SetReadonly(IsReadOnly(tdc));
		
				m_mgrToDoCtrls.SetModifiedStatus(nCtrl, tdc.IsModified());
				m_mgrToDoCtrls.RefreshLastModified(nCtrl);
				m_mgrToDoCtrls.UpdateTabItemText(nCtrl);
			}
		}
		
		m_toolbar.GetToolBarCtrl().HideButton(ID_TOOLS_TOGGLECHECKIN, !bSourceControl);
		
		// toolbar image
		if (prefs.GetLargeToolbarIcons() != bLargecons)
		{
			UINT nIDToolbarImage = !bLargecons ? IDB_TOOLBAR24 : IDB_TOOLBAR16;
			
			m_toolbar.LoadToolBar(IDR_TOOLBAR, nIDToolbarImage);
			PrepareToolbar(m_nToolbarOption);
			
			bResizeDlg = TRUE;
		}
		
		// menubar close button
		if (prefs.GetShowTasklistCloseButton() != bCloseBtn && m_nToolbarOption != TB_TOOLBARONLY)
		{
			m_menubar.LoadMenu(IDR_MAINFRAME);
			
			if (!bCloseBtn) // needs adding
				m_menubar.AddMDIButton(MEB_CLOSE, ID_CLOSE, -1, TRUE);
			
			SetMenu(&m_menubar);
		}
		
		// tools
		if (m_nToolbarOption != TB_TOOLBARHIDDEN)
			AppendTools2Toolbar(m_nToolbarOption == TB_TOOLBARANDMENU);
		
		if (m_nToolbarOption == TB_TOOLBARONLY)
			m_tbHelper.SetDefaultMenuID(ID_NEWTASK, GetNewTaskCmdID());
		
		// tab bar
		bResizeDlg |= (bAutoHideTabbar != prefs.GetAutoHideTabbar());
		
		if (bStackTabbar != prefs.GetStackTabbarItems())
		{
			bResizeDlg = TRUE;
			m_tabCtrl.ModifyStyle(!bStackTabbar ? 0 : TCS_MULTILINE, !bStackTabbar ? TCS_MULTILINE : 0);
		}
		
		// hotkey
		UpdateGlobalHotkey();
		
		// time periods
		CTimeEdit::SetHoursInOneDay(prefs.GetHoursInOneDay());
		CTimeEdit::SetDaysInOneWeek(prefs.GetDaysInOneWeek());
		
		RefreshTabOrder();
		
		// time tracking
		if (bTrackActiveTasklist != prefs.GetTrackActiveTasklistOnly())
			PauseTimeTracking(FALSE);
		
		UpdateCaption();
		UpdateTabSwitchTooltip();
		
		// active tasklist prefs
		UpdateToDoCtrlPreferences();
		
		if (bResizeDlg)
			ResizeDlg();
	}
	
	// finally set or terminate the various status check timers
	SetTimer(TIMER_READONLYSTATUS, Prefs().GetReadonlyReloadOption() != RO_NO);
	SetTimer(TIMER_TIMESTAMPCHANGE, Prefs().GetTimestampReloadOption() != RO_NO);
	SetTimer(TIMER_AUTOSAVE, Prefs().GetAutoSaveFrequency());
	SetTimer(TIMER_CHECKOUTSTATUS, Prefs().GetCheckoutOnCheckin() || 
		Prefs().GetCheckinOnNoEditTime());
}

void CToDoListDlg::UpdateGlobalHotkey()
{
	static DWORD dwPrevHotkey = 0;
	DWORD dwHotkey = Prefs().GetGlobalHotkey();
	
	if (dwPrevHotkey == dwHotkey)
		return;
	
	// map modifiers to those wanted by RegisterHotKey
	DWORD dwPrefMods = HIWORD(dwHotkey);
	DWORD dwVKey = LOWORD(dwHotkey);
	
	DWORD dwMods = (dwPrefMods & HOTKEYF_ALT) ? MOD_ALT : 0;
	dwMods |= (dwPrefMods & HOTKEYF_CONTROL) ? MOD_CONTROL : 0;
	dwMods |= (dwPrefMods & HOTKEYF_SHIFT) ? MOD_SHIFT : 0;
	
	RegisterHotKey(*this, 1, dwMods, dwVKey);
}

void CToDoListDlg::PauseTimeTracking(BOOL bPause)
{
	// time tracking
	int nCtrl = GetTDCCount();
	int nSel = GetSelToDoCtrl();
	BOOL bTrackActiveOnly = Prefs().GetTrackActiveTasklistOnly();
	
	while (nCtrl--)
	{
		BOOL bSel = (nCtrl == nSel);
		CToDoCtrl& tdc = GetToDoCtrl(nCtrl);
		
		tdc.PauseTimeTracking(bPause ? TRUE : (bSel ? FALSE : bTrackActiveOnly));
	}
}

BOOL CToDoListDlg::IsReadOnly(const CToDoCtrl& tdc) const
{
    LPCTSTR szPath = tdc.GetFilePath();
	BOOL bReadOnly = CDriveInfo::IsReadonlyPath(szPath) >  0;
	
    if (!bReadOnly)
        bReadOnly = (tdc.CompareFileFormat() == TDCFF_NEWER);
	
	if (!bReadOnly)
		bReadOnly = (m_mgrToDoCtrls.PathSupportsSourceControl(szPath) && !tdc.IsCheckedOut());
	
	if (!bReadOnly && !Prefs().GetEnableSourceControl())
		bReadOnly = tdc.IsSourceControlled();
	
	return bReadOnly;
}

void CToDoListDlg::CheckMinWidth()
{
	if (GetTDCCount())
	{
		CRect rTDC;
		GetToDoCtrl().GetClientRect(rTDC);
		int nMinWidth = GetToDoCtrl().GetMinWidth();
		
		if (rTDC.Width() < nMinWidth)
		{
			CRect rWindow;
			GetWindowRect(rWindow);
			
			SetWindowPos(NULL, 0, 0, rWindow.Width() - 1, rWindow.Height(), SWP_NOZORDER | SWP_NOMOVE);
		}
	}
}

void CToDoListDlg::ShowMenuBar(BOOL bShow, BOOL bResize)
{
	if (bShow) // showing menubar
	{
		m_menubar.DestroyMenu();
		
		if (!m_menubar.LoadMenu(IDR_MAINFRAME))
			return;
		
		// add tasklist close button
		if (Prefs().GetShowTasklistCloseButton())
			m_menubar.AddMDIButton(MEB_CLOSE, ID_CLOSE, -1);
		
		if (!SetMenu(&m_menubar))
			return;
	}
	else // showing toolbar
	{
		// destroy existing menu
		CMenu* pMenu = GetMenu();
		
		if (pMenu)
			pMenu->DestroyMenu();
		
		// and hide
		SetMenu(NULL);
	}
	
	// resize active todoctrl
	if (bResize)
	{
		CRect rTDC;
		
		if (CalcToDoCtrlRect(rTDC))
			GetToDoCtrl().MoveWindow(rTDC);
	}
}

BOOL CToDoListDlg::OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct) 
{
	switch (pCopyDataStruct->dwData)
	{
	case OPENTASKLIST:
		{
			LPCTSTR szFilePath = (LPCTSTR)pCopyDataStruct->lpData;
			OpenTaskList(szFilePath);
		}
		break;
	}
	
	return CDialog::OnCopyData(pWnd, pCopyDataStruct);
}

void CToDoListDlg::OnEditCopy() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	tdc.Flush();
	tdc.CopySelectedTask();
}

void CToDoListDlg::OnEditCut() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	tdc.Flush();
	tdc.CutSelectedTask();
}

void CToDoListDlg::OnUpdateEditCut(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount);	
}

void CToDoListDlg::OnEditPasteSub() 
{
	GetToDoCtrl().PasteOnSelectedTask();
}

void CToDoListDlg::OnUpdateEditPasteSub(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	// modify the text appropriately if the tasklist is empty
	if (nSelCount == 0)
		pCmdUI->SetText("Paste as a Top-level Task");
	
	pCmdUI->Enable(!tdc.IsReadOnly() && tdc.CanPaste());	
}

void CToDoListDlg::OnEditPasteAfter() 
{
	GetToDoCtrl().PasteAfterSelectedTask();
}

void CToDoListDlg::OnUpdateEditPasteAfter(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	pCmdUI->Enable(!tdc.IsReadOnly() && tdc.CanPaste() && nSelCount == 1);	
}

void CToDoListDlg::OnEditCopyastext() 
{
	CopySelectedTasksToClipboard(FALSE);
}

void CToDoListDlg::OnEditCopyashtml() 
{
	CopySelectedTasksToClipboard(TRUE);
}

void CToDoListDlg::CopySelectedTasksToClipboard(BOOL bHtml)
{
	CToDoCtrl& tdc = GetToDoCtrl();
	tdc.Flush();
	
	CTaskFile tasks;
	BOOL bVisColsOnly = Prefs().GetExportVisibleColsOnly();
	BOOL bParentTitleCommentsOnly = Prefs().GetExportParentTitleCommentsOnly();
	DWORD dwFlags = (bVisColsOnly ? TDCGT_VISIBLECOLSONLY : 0) | TDCGT_ISODATES |
		(bParentTitleCommentsOnly ? TDCGT_PARENTTITLECOMMENTSONLY : 0);
	
	tdc.GetSelectedTasks(tasks, dwFlags);
	
	CString sTasks = bHtml ? m_mgrImportExport.ExportTaskListToHtml(&tasks) :
	m_mgrImportExport.ExportTaskListToText(&tasks);
	
	Misc::CopyTexttoclipboard(sTasks, *this);
}

void CToDoListDlg::OnUpdateEditCopy(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetSelectedCount() > 0);
}

void CToDoListDlg::OnUpdateNewtaskAttopSelected(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	// enable this when the tasklist is empty even if no 
	// item is selected.
	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount <= 1);
}

void CToDoListDlg::OnUpdateNewtaskAtbottomSelected(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	// enable this when the tasklist is empty even if no 
	// item is selected.
	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount <= 1);
}

void CToDoListDlg::OnUpdateNewtaskAfterselectedtask(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	// enable this when the tasklist is empty even if no 
	// item is selected.
	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount <= 1);
}

void CToDoListDlg::OnUpdateNewtaskBeforeselectedtask(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	// enable this when the tasklist is empty even if no 
	// item is selected.
	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount <= 1);
}

void CToDoListDlg::OnUpdateNewsubtaskAttop(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount <= 1);
}

void CToDoListDlg::OnSimplemode() 
{
	m_bSimpleMode = !m_bSimpleMode;
	
	GetToDoCtrl().SetStyle(TDCS_SIMPLEMODE, m_bSimpleMode);	
}

void CToDoListDlg::OnUpdateSimplemode(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bSimpleMode ? 1 : 0);
}

void CToDoListDlg::OnReload() 
{
	int nSel = GetSelToDoCtrl();
	
	if (m_mgrToDoCtrls.GetModifiedStatus(nSel))
	{ 
		if (IDNO == MessageBox("If you reload the tasklist you will lose your current \nchanges."
			"\n\nAre you sure you want to continue?",
			ABBREVCOPYRIGHT, MB_YESNO | MB_DEFBUTTON2))
		{
			return;
		}
	}
	
	// else reload
	ReloadTaskList(nSel, TRUE);
	RefreshTabOrder();
}

void CToDoListDlg::ReloadTaskList(int nIndex, BOOL bNotifyDueTasks)
{
	CToDoCtrl& tdc = GetToDoCtrl(nIndex);
	
	if (OpenTaskList(&tdc) == LOAD_SUCCESS)
	{
		CPreferencesDlg& prefs = Prefs();
		
		// update file status
		if (prefs.GetAutoCheckOut())
			m_mgrToDoCtrls.SetLastCheckoutStatus(nIndex, tdc.IsCheckedOut());
		
		m_mgrToDoCtrls.RefreshLastModified(nIndex);
		m_mgrToDoCtrls.SetModifiedStatus(nIndex, FALSE);
		
		// notify user of due tasks if req
		if (bNotifyDueTasks)
			DoDueTaskNotification(&tdc, prefs.GetNotifyDueByOnLoad());
		
		UpdateCaption();
		UpdateStatusbar();
		UpdateDefaultSortItem();
	}
}

void CToDoListDlg::OnUpdateReload(CCmdUI* pCmdUI) 
{
	int nSel = GetSelToDoCtrl();
	
	pCmdUI->Enable(!m_mgrToDoCtrls.GetFilePath(nSel).IsEmpty());
}

void CToDoListDlg::OnArchiveCompletedtasks() 
{
	TDC_ARCHIVE nRemove = TDC_REMOVENONE;
	
	if (Prefs().GetRemoveArchivedTasks())
	{
		if (Prefs().GetRemoveOnlyOnAbsoluteCompletion())
			nRemove = TDC_REMOVEIFSIBLINGSANDSUBTASKSCOMPLETE;
		else
			nRemove = TDC_REMOVEALL;
	}
	
	CWaitCursor cursor;
	
	if (m_mgrToDoCtrls.ArchiveDoneTasks(GetSelToDoCtrl(), nRemove) > 0)
		UpdateCaption();
}

void CToDoListDlg::OnUpdateArchiveCompletedtasks(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	pCmdUI->Enable(!tdc.IsReadOnly() && !m_mgrToDoCtrls.GetArchivePath(tdc.GetFilePath()).IsEmpty());
}

void CToDoListDlg::OnPrint() 
{
	// export to html and then print in IE
	char szTempFile[MAX_PATH], szTempPath[MAX_PATH];
	
	if (!::GetTempPath(MAX_PATH, szTempPath))
		return;
	
	// always use the same file
	_makepath(szTempFile, NULL, szTempPath, "ToDoList.print", "html");
	
	if (!Export2Html(GetToDoCtrl(), szTempFile, Prefs().GetPrintStylesheet()))
		return;
	
	// print from browser
	int nRes = (int)ShellExecute(*this, "print", szTempFile, NULL, NULL, SW_HIDE);
				
	if (nRes < 32)
	{
		CString sMessage("ToDoList was unable to print the active tasklist via your default "
			"browser, which may mean that your browser does not support the "
			"'print' command.\n\nPlease see your browser help for more information.");
		
		MessageBox(sMessage, "Tasklist could not be printed", MB_OK);
	}
}

void CToDoListDlg::OnUpdatePrint(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetTaskCount());
}

void CToDoListDlg::OnMovetaskdown() 
{
	m_tbHelper.SetDefaultMenuID(ID_MOVETASK, ID_MOVETASKDOWN);
	
	GetToDoCtrl().MoveSelectedTask(MOVE_DOWN);	
}

void CToDoListDlg::OnUpdateMovetaskdown(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanMoveSelectedTask(MOVE_DOWN));	
}

void CToDoListDlg::OnMovetaskup() 
{
	m_tbHelper.SetDefaultMenuID(ID_MOVETASK, ID_MOVETASKUP);
	
	GetToDoCtrl().MoveSelectedTask(MOVE_UP);	
}

void CToDoListDlg::OnUpdateMovetaskup(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanMoveSelectedTask(MOVE_UP));	
}

void CToDoListDlg::OnMovetaskright() 
{
	m_tbHelper.SetDefaultMenuID(ID_MOVETASK, ID_MOVETASKRIGHT);
	
	GetToDoCtrl().MoveSelectedTask(MOVE_RIGHT);	
}

void CToDoListDlg::OnUpdateMovetaskright(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanMoveSelectedTask(MOVE_RIGHT));	
}

void CToDoListDlg::OnMovetaskleft() 
{
	m_tbHelper.SetDefaultMenuID(ID_MOVETASK, ID_MOVETASKLEFT);
	
	GetToDoCtrl().MoveSelectedTask(MOVE_LEFT);	
}

void CToDoListDlg::OnUpdateMovetaskleft(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanMoveSelectedTask(MOVE_LEFT));	
}

CToDoCtrl& CToDoListDlg::GetToDoCtrl()
{
	return GetToDoCtrl(GetSelToDoCtrl());
}

CToDoCtrl& CToDoListDlg::GetToDoCtrl(int nIndex)
{
	return m_mgrToDoCtrls.GetToDoCtrl(nIndex);
}

CToDoCtrl* CToDoListDlg::NewToDoCtrl()
{
	CToDoCtrl* pCtrl = NULL;
	BOOL bReuse = FALSE;
	
	// if the active tasklist is untitled and unmodified then reuse it
	if (GetTDCCount())
	{
		int nSel = GetSelToDoCtrl();
		CToDoCtrl& tdc = GetToDoCtrl();
		
		// make sure that we don't accidently reuse a just edited tasklist
		tdc.Flush(); 
		
		if (tdc.GetFilePath().IsEmpty() && !m_mgrToDoCtrls.GetModifiedStatus(nSel))
		{
			pCtrl = &tdc;
			m_mgrToDoCtrls.RemoveToDoCtrl(nSel);
			
			// make sure we reset the selection to a valid index
			if (GetTDCCount())
			{
				// try leaving the selection as-is
				if (nSel >= GetTDCCount())
					nSel--; // try the preceding item
				
				SelectToDoCtrl(nSel);
			}
			
			return pCtrl;
		}
	}
	
	// else
	pCtrl = new CToDoCtrl;
	
	if (pCtrl && CreateToDoCtrl(pCtrl))
		return pCtrl;
	
	// else
	delete pCtrl;
	return NULL;
}

BOOL CToDoListDlg::CreateToDoCtrl(CToDoCtrl* pCtrl)
{
	// note: size not important since tdc will get resized
	// in AddToDoCtrl()
	if (pCtrl->Create(CRect(0, 0, 10, 10), this, IDC_TODOLIST, FALSE))
	{
		if (!m_ilToDoCtrl.GetSafeHandle())
			InitCheckboxImageList();
		
		UpdateToDoCtrlPreferences(pCtrl);
		
		return TRUE;
	}
	
	return FALSE;
}

BOOL CToDoListDlg::InitCheckboxImageList()
{
	if (m_ilToDoCtrl.GetSafeHandle())
		return TRUE;
	
	CThemed th;
	CBitmap bitmap;
	
	if (th.Open(this, "BUTTON") && th.IsNonClientThemed())
	{
		const int nStates[] = { -1, CBS_UNCHECKEDNORMAL, CBS_CHECKEDNORMAL };
		const int nNumStates = sizeof(nStates) / sizeof(int);
		
		th.BuildImageList(m_ilToDoCtrl, BP_CHECKBOX, nStates, nNumStates);
	}
	
	// unthemed + fallback
	if (!m_ilToDoCtrl.GetSafeHandle())
	{
		bitmap.LoadBitmap(IDB_TODO);
		
		BITMAP BM;
		bitmap.GetBitmap(&BM);
		
		if (m_ilToDoCtrl.Create(BM.bmWidth / 3, BM.bmHeight, ILC_COLOR32 | ILC_MASK, 0, 1))
			m_ilToDoCtrl.Add(&bitmap, 255);
	}
	
	return (NULL != m_ilToDoCtrl.GetSafeHandle());
}

int CToDoListDlg::AddToDoCtrl(CToDoCtrl* pCtrl, BOOL bResizeDlg)
{
	// add tdc first to ensure tab controls has some
	// items before we query it for its size
	int nSel = m_mgrToDoCtrls.AddToDoCtrl(pCtrl);
	
	// make sure size is right
	CRect rTDC;
	
	if (CalcToDoCtrlRect(rTDC))
		pCtrl->MoveWindow(rTDC);
	
	SelectToDoCtrl(nSel);
	pCtrl->SetFocusToTree();
	
	// make sure the tab control is correctly sized
	if (bResizeDlg)
		ResizeDlg();
	
	// if this is the only control then set or terminate the various status 
	// check timers
	if (GetTDCCount() == 1)
	{
		CPreferencesDlg& prefs = Prefs();
		
		SetTimer(TIMER_READONLYSTATUS, prefs.GetReadonlyReloadOption() != RO_NO);
		SetTimer(TIMER_TIMESTAMPCHANGE, prefs.GetTimestampReloadOption() != RO_NO);
		SetTimer(TIMER_AUTOSAVE, prefs.GetAutoSaveFrequency());
		SetTimer(TIMER_CHECKOUTSTATUS, prefs.GetCheckoutOnCheckin() ||
			prefs.GetCheckinOnNoEditTime());
	}
	
	return nSel;
}

void CToDoListDlg::OnMBtnClickTabcontrol(NMHDR* pNMHDR, LRESULT* pResult) 
{
	if (Prefs().GetEnableCtrlMBtnClose())
	{
		NMTCMBTNCLK* pTCHDR = (NMTCMBTNCLK*)pNMHDR;
		
		// check valid tab + ctrl key
		if (pTCHDR->iTab >= 0 && (pTCHDR->flags & MK_CONTROL))
		{
			CloseToDoCtrl(pTCHDR->iTab, FALSE);
			
			if (!GetTDCCount())
				CreateNewTaskList(FALSE);
		}
	}
	*pResult = 0;
}

void CToDoListDlg::OnSelchangeTabcontrol(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// show the incoming selection
	int nCurSel = GetSelToDoCtrl();
	
	if (nCurSel != -1)
	{
		UpdateToDoCtrlPreferences();
		UpdateDefaultSortItem();
		
		CToDoCtrl& tdc = GetToDoCtrl(nCurSel);
		
		// make sure size is right
		CRect rTDC;
		
		if (CalcToDoCtrlRect(rTDC))
			tdc.MoveWindow(rTDC);
		
		tdc.EnableWindow(TRUE);
		tdc.SetFocusToTree();
		tdc.ShowWindow(SW_SHOW);
		tdc.PauseTimeTracking(FALSE); // always
		
		// update status bar
		UpdateStatusbar();
		UpdateCaption();
	}
	
	// hide the outgoing selection
	if (m_nLastSelItem != -1)
	{
		CToDoCtrl& tdc = GetToDoCtrl(m_nLastSelItem);
		
		tdc.ShowWindow(SW_HIDE);
		tdc.EnableWindow(FALSE);
		tdc.PauseTimeTracking(Prefs().GetTrackActiveTasklistOnly());
		
		m_nLastSelItem = -1; // reset
	}
	
	if (nCurSel != -1)
	{
		// notify user of due tasks if req
		DoDueTaskNotification(&GetToDoCtrl(nCurSel), Prefs().GetNotifyDueByOnSwitch());
	}
	
	*pResult = 0;
}

void CToDoListDlg::OnSelchangingTabcontrol(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// cache the outgoing selection
	m_nLastSelItem = GetSelToDoCtrl();
	
	// and flush
	if (m_nLastSelItem != -1)
		GetToDoCtrl(m_nLastSelItem).Flush();
	
	*pResult = 0;
}

BOOL CToDoListDlg::ConfirmSaveTaskList(int nIndex, BOOL bClosingTaskList, BOOL bClosingDown)
{
	bClosingTaskList |= bClosingDown; // sanity check
	
	// save changes
	CToDoCtrl& tdc = GetToDoCtrl(nIndex);
	
	if (tdc.IsModified())
	{
		if (bClosingTaskList && (tdc.GetFilePath().IsEmpty() || Prefs().GetConfirmSaveOnExit()))
		{
			// activate tasklist
			SelectToDoCtrl(nIndex); 
			
			CString sMessage, sName = m_mgrToDoCtrls.GetFriendlyProjectName(nIndex);
			sMessage.Format("Would you like to save the changes to '%s' \nbefore closing?", sName);
			
			// don't allow user to cancel if closing down
			int nRet = MessageBox(sMessage, ABBREVCOPYRIGHT, bClosingDown ? MB_YESNO : MB_YESNOCANCEL);
			
			if (nRet == IDYES)
				SaveTaskList(nIndex);
			
			else if (!bClosingDown && nRet == IDCANCEL)
				return FALSE;
			
			else if (nRet == IDNO)
				tdc.SetModified(FALSE);
		}
		else
			SaveTaskList(nIndex); 
	}
	
	return TRUE; // user did not cancel
}

BOOL CToDoListDlg::CloseToDoCtrl(int nIndex, BOOL bClosingDown)
{
	ASSERT (nIndex >= 0);
	ASSERT (nIndex < GetTDCCount());
	
	CToDoCtrl& tdc = GetToDoCtrl(nIndex);
	int nSel = GetSelToDoCtrl(); // cache this
	
	tdc.Flush();
	
	if (!ConfirmSaveTaskList(nIndex, TRUE, bClosingDown))
		return FALSE;
	
	CWaitCursor cursor;
	
	// checkin as our final task
	if (Prefs().GetCheckinOnClose() && m_mgrToDoCtrls.PathSupportsSourceControl(nIndex))
		tdc.CheckIn();
	
	m_mgrToDoCtrls.RemoveToDoCtrl(nIndex);
	
	tdc.DestroyWindow();
	delete (&tdc); // created with new
	
	// make sure we reset the selection to a valid index
	if (nIndex == nSel && GetTDCCount())
	{
		// try leaving the selection as-is
		if (nSel >= GetTDCCount())
			nSel--; // try the preceding item
		
		SelectToDoCtrl(nSel);
	}
	
	if (!bClosingDown && GetTDCCount())
		ResizeDlg();
	
	return TRUE;
}

void CToDoListDlg::OnCloseTasklist() 
{
	// close
	CloseToDoCtrl(GetSelToDoCtrl(), FALSE);
	
	// if empty then create a new dummy item		
	if (!GetTDCCount())
		CreateNewTaskList(FALSE);
	else
		ResizeDlg();
}

BOOL CToDoListDlg::SelectToDoCtrl(LPCTSTR szFilePath)
{
	if (!szFilePath || !*szFilePath)
		return FALSE;
	
	int nCtrl = GetTDCCount();
	
	while (nCtrl--)
	{
		if (m_mgrToDoCtrls.GetFilePath(nCtrl).CompareNoCase(szFilePath) == 0)
		{
			SelectToDoCtrl(nCtrl);
			return TRUE;
		}
	}
	
	return FALSE;
}

void CToDoListDlg::SelectToDoCtrl(int nIndex)
{
	ASSERT (nIndex >= 0);
	ASSERT (nIndex < GetTDCCount());
	
	int nCurSel = GetSelToDoCtrl(); // cache this
	
	// resize tdc first
	CRect rTDC;
	
	if (CalcToDoCtrlRect(rTDC))
		GetToDoCtrl(nIndex).MoveWindow(rTDC);
	
	m_tabCtrl.SetCurSel(nIndex); // this changes the selected CToDoCtrl
	m_tabCtrl.UpdateWindow();
	
	if (!m_bClosing)
	{
		UpdateToDoCtrlPreferences();
		UpdateDefaultSortItem();
	}
	
	// show the chosen item
	CToDoCtrl& tdc = GetToDoCtrl();
	
	tdc.EnableWindow(TRUE);
	tdc.SetFocusToTree();
	tdc.ShowWindow(SW_SHOW);
	tdc.PauseTimeTracking(FALSE); // always
	
	// before hiding the previous selection
	if (nCurSel != -1 && nCurSel != nIndex)
	{
		CToDoCtrl& tdc = GetToDoCtrl(nCurSel);
		
		tdc.ShowWindow(SW_HIDE);
		tdc.EnableWindow(FALSE);
		tdc.PauseTimeTracking(Prefs().GetTrackActiveTasklistOnly());
	}
	
	if (!m_bClosing)
	{
		OnTimerReadOnlyStatus(nIndex);
		OnTimerTimestampChange(nIndex);
		OnTimerCheckoutStatus(nIndex);
	}
	
	UpdateCaption();
	UpdateStatusbar();
}

void CToDoListDlg::UpdateToDoCtrlPreferences()
{
	// check if this has already been done since the last prefs change
	int nSel = GetSelToDoCtrl();
	
	if (m_mgrToDoCtrls.GetNeedsPreferenceUpdate(nSel))
	{
		UpdateToDoCtrlPreferences(&GetToDoCtrl(nSel));
		
		// reset flag
		m_mgrToDoCtrls.SetNeedsPreferenceUpdate(nSel, FALSE);
	}
}

void CToDoListDlg::UpdateToDoCtrlPreferences(CToDoCtrl* pCtrl)
{
	CPreferencesDlg& prefs = Prefs();
	CToDoCtrl& tdc = *pCtrl;
	
	CTDCStyles styles;
	
	styles[TDCS_COLORTEXTBYPRIORITY] = (prefs.GetTextColorOption() == COLOROPT_PRIORITY);
	styles[TDCS_COLORTEXTBYCATEGORY] = (prefs.GetTextColorOption() == COLOROPT_CATEGORY);
	styles[TDCS_SHOWINFOTIPS] = prefs.GetShowInfoTips();
	styles[TDCS_SHOWCOMMENTSINLIST] = prefs.GetShowComments();
	styles[TDCS_COLORPRIORITY] = prefs.GetColorPriority();
	styles[TDCS_TREATSUBCOMPLETEDASDONE] = prefs.GetTreatSubCompletedAsDone();
	styles[TDCS_HIDEPERCENTFORDONETASKS] = prefs.GetHidePercentForDoneTasks();
	styles[TDCS_HIDESTARTDUEFORDONETASKS] = prefs.GetHideStartDueForDoneTasks();
	styles[TDCS_HIDEZEROTIMEEST] = prefs.GetHideZeroTimeEst();
	styles[TDCS_CONFIRMDELETE] = prefs.GetConfirmDelete();
	styles[TDCS_AVERAGEPERCENTSUBCOMPLETION] = prefs.GetAveragePercentSubCompletion();
	styles[TDCS_INCLUDEDONEINAVERAGECALC] = prefs.GetIncludeDoneInAverageCalc();
	styles[TDCS_SHOWBUTTONSINTREE] = prefs.GetShowButtonsInTree();
	styles[TDCS_USEEARLIESTDUEDATE] = prefs.GetUseEarliestDueDate();
	styles[TDCS_USEPERCENTDONEINTIMEEST] = prefs.GetUsePercentDoneInTimeEst();
	styles[TDCS_SHOWCTRLSASCOLUMNS] = prefs.GetShowCtrlsAsColumns();
	styles[TDCS_SHOWCOMMENTSALWAYS] = prefs.GetShowCommentsAlways();
	styles[TDCS_AUTOREPOSCTRLS] = prefs.GetAutoReposCtrls();
	styles[TDCS_SHOWPERCENTASPROGRESSBAR] = prefs.GetShowPercentAsProgressbar();
	styles[TDCS_STRIKETHOUGHDONETASKS] = prefs.GetStrikethroughDone();
	styles[TDCS_SHOWPATHINHEADER] = prefs.GetShowPathInHeader();
	styles[TDCS_FULLROWSELECTION] = prefs.GetFullRowSelection();
	styles[TDCS_TREECHECKBOXES] = prefs.GetTreeCheckboxes();
	styles[TDCS_COLUMNHEADERCLICKING] = prefs.GetEnableHeaderSorting();
	styles[TDCS_SORTVISIBLETASKSONLY] = prefs.GetSortVisibleOnly();
	styles[TDCS_SHAREDCOMMENTSHEIGHT] = prefs.GetSharedCommentsHeight();
	styles[TDCS_TASKCOLORISBACKGROUND] = prefs.GetColorTaskBackground();
	styles[TDCS_COMMENTSUSETREEFONT] = prefs.GetCommentsUseTreeFont();
	styles[TDCS_SHOWDATESINISO] = prefs.GetDisplayDatesInISO();
	styles[TDCS_USEHIGHESTPRIORITY] = prefs.GetUseHighestPriority();
	styles[TDCS_AUTOCALCTIMEESTIMATES] = prefs.GetAutoCalcTimeEstimates();
	styles[TDCS_SHOWWEEKDAYINDATES] = prefs.GetShowWeekdayInDates();
	styles[TDCS_ROUNDTIMEFRACTIONS] = prefs.GetRoundTimeFractions();
	styles[TDCS_SHOWNONFILEREFSASTEXT] = prefs.GetShowNonFilesAsText();
	styles[TDCS_INCLUDEDONEINPRIORITYCALC] = prefs.GetIncludeDoneInPriorityCalc();
	styles[TDCS_WEIGHTPERCENTCALCBYTIMEEST] = prefs.GetWeightPercentCompletionByTimeEst();
	styles[TDCS_WEIGHTPERCENTCALCBYPRIORITY] = prefs.GetWeightPercentCompletionByPriority();
	styles[TDCS_RIGHTALIGNLABELS] = prefs.GetRightAlignLabels();
	styles[TDCS_SHOWPARENTSASFOLDERS] = prefs.GetShowParentsAsFolders();
	styles[TDCS_FOCUSTREEONENTER] = prefs.GetFocusTreeOnEnter();
	styles[TDCS_AUTOCALCPERCENTDONE] = prefs.GetAutoCalcPercentDone();
	styles[TDCS_TRACKSELECTEDTASKONLY] = prefs.GetTrackSelectedTaskOnly();
	styles[TDCS_HIDEPRIORITYNUMBER] = prefs.GetHidePriorityNumber();
	styles[TDCS_SIMPLEMODE] = m_bSimpleMode;
	styles[TDCS_PAUSETIMETRACKINGONSCRNSAVER] = prefs.GetNoTrackOnScreenSaver();
	styles[TDCS_SHOWFIRSTCOMMENTLINEINLIST] = prefs.GetDisplayFirstCommentLine();
	styles[TDCS_DISPLAYHMSTIMEFORMAT] = prefs.GetUseHMSTimeFormat();
	styles[TDCS_SORTDONETASKSATBOTTOM] = prefs.GetSortDoneTasksAtBottom();
	
	// source control
	BOOL bSrcControl = m_mgrToDoCtrls.PathSupportsSourceControl(tdc.GetFilePath());

	styles[TDCS_ENABLESOURCECONTROL] = bSrcControl;
	styles[TDCS_CHECKOUTONLOAD] = bSrcControl && prefs.GetAutoCheckOut();
	
	tdc.SetStyles(styles);
	
	tdc.ShowColumn(TDCC_POSITION, prefs.GetShowColumn(PTPC_POSITION));
	tdc.ShowColumn(TDCC_ID, prefs.GetShowColumn(PTPC_ID));
	tdc.ShowColumn(TDCC_PERCENT, prefs.GetShowColumn(PTPC_PERCENT));
	tdc.ShowColumn(TDCC_PRIORITY, prefs.GetShowColumn(PTPC_PRIORITY));
	tdc.ShowColumn(TDCC_TIMEEST, prefs.GetShowColumn(PTPC_TIMEEST));
	tdc.ShowColumn(TDCC_TIMESPENT, prefs.GetShowColumn(PTPC_TIMESPENT));
	tdc.ShowColumn(TDCC_STARTDATE, prefs.GetShowColumn(PTPC_STARTDATE));
	tdc.ShowColumn(TDCC_DUEDATE, prefs.GetShowColumn(PTPC_DUEDATE));
	tdc.ShowColumn(TDCC_DONEDATE, prefs.GetShowColumn(PTPC_DONEDATE));
	tdc.ShowColumn(TDCC_ALLOCTO, prefs.GetShowColumn(PTPC_ALLOCTO));
	tdc.ShowColumn(TDCC_ALLOCBY, prefs.GetShowColumn(PTPC_ALLOCBY));
	tdc.ShowColumn(TDCC_STATUS, prefs.GetShowColumn(PTPC_STATUS));
	tdc.ShowColumn(TDCC_CATEGORY, prefs.GetShowColumn(PTPC_CATEGORY));
	tdc.ShowColumn(TDCC_FILEREF, prefs.GetShowColumn(PTPC_FILEREF));
	tdc.ShowColumn(TDCC_DONE, prefs.GetShowColumn(PTPC_DONE));
	tdc.ShowColumn(TDCC_TRACKTIME, prefs.GetShowColumn(PTPC_TRACKTIME));
	tdc.ShowColumn(TDCC_FLAG, prefs.GetShowColumn(PTPC_FLAG));
	
	tdc.SetMaxInfotipCommentsLength(prefs.GetMaxInfoTipCommentsLength());
	
	// update default task preferences
	int nUnits;
	double dTimeEst = prefs.GetDefaultTimeEst(nUnits);
	
	tdc.SetDefaultTaskAttributes("Task", NULL, prefs.GetDefaultColor(),
								dTimeEst, nUnits, prefs.GetDefaultAllocTo(),
								prefs.GetDefaultAllocBy(), prefs.GetDefaultStatus(),
								prefs.GetDefaultCategory(), prefs.GetDefaultPriority(),
								prefs.GetAutoDefaultStartDate());
	
	CheckMinWidth();
	
	// fonts
	if (!m_fontTree.GetSafeHandle() || !m_fontComments.GetSafeHandle())
	{
		CString sFaceName;
		int nFontSize;
		
		if (!m_fontTree.GetSafeHandle() && prefs.GetTreeFont(sFaceName, nFontSize))
			m_fontTree.Attach(Misc::CreateFont(sFaceName, nFontSize));
		
		if (!m_fontComments.GetSafeHandle() && prefs.GetCommentsFont(sFaceName, nFontSize))
			m_fontComments.Attach(Misc::CreateFont(sFaceName, nFontSize));
	}
	
	tdc.SetTreeFont(m_fontTree);
	tdc.SetCommentsFont(m_fontComments);
	
	tdc.SetGridlineColor(prefs.GetGridlineColor());
	tdc.SetTaskCompletedColor(prefs.GetTaskDoneColor());
	tdc.SetAlternateLineColor(prefs.GetAlternateLineColor());
	
	// checkbox images
	tdc.SetCheckImageList(m_ilToDoCtrl);
	
	// colors
	CDWordArray aColors;
	prefs.GetPriorityColors(aColors);
	tdc.SetPriorityColors(aColors);
	
	CTDCColorMap mapColors;
	CCatColorArray aCatColors;
	int nColor = prefs.GetCategoryColors(aCatColors);
	
	while (nColor--)
	{
		CATCOLOR& cc = aCatColors[nColor];
		mapColors[cc.sCategory] = cc.color;
	}
	tdc.SetCategoryColors(mapColors);
	
	tdc.Flush(); // clear any outstanding issues
}

void CToDoListDlg::UpdateTabSwitchTooltip()
{
	CToolTipCtrl* pTT = m_tabCtrl.GetToolTips();
	
	if (pTT)
	{
		// get the string for tab switching
		CString sShortcut = m_mgrShortcuts.GetShortcutTextByCmd(ID_VIEW_NEXT);
		
		if (sShortcut.IsEmpty())
			sShortcut = m_mgrShortcuts.GetShortcutTextByCmd(ID_VIEW_PREV);
		
		pTT->DelTool(&m_tabCtrl); // always
		
		if (!sShortcut.IsEmpty())
		{
			sShortcut = "Use '" + sShortcut + "' to switch tasklists";
			pTT->AddTool(&m_tabCtrl, sShortcut);
		}
	}
}

void CToDoListDlg::SetTimer(UINT nTimerID, BOOL bOn)
{
	if (bOn)
	{
		UINT nPeriod = 0;
		
		switch (nTimerID)
		{
		case TIMER_READONLYSTATUS:
			nPeriod = INTERVAL_READONLYSTATUS;
			break;
			
		case TIMER_TIMESTAMPCHANGE:
			nPeriod = INTERVAL_TIMESTAMPCHANGE;
			break;
			
		case TIMER_AUTOSAVE:
			nPeriod = Prefs().GetAutoSaveFrequency() * 60000;
			break;
			
		case TIMER_CHECKOUTSTATUS:
			nPeriod = INTERVAL_CHECKOUTSTATUS;
			break;
			
		case TIMER_DUEITEMS:
			nPeriod = INTERVAL_DUEITEMS;
			break;
		}
		
		if (nPeriod)
		{
			UINT nID = CDialog::SetTimer(nTimerID, nPeriod, NULL);
			ASSERT (nID);
		}
	}
	else
		KillTimer(nTimerID);
}

void CToDoListDlg::OnSaveall() 
{
	SaveAll(FALSE, FALSE, TRUE);
}

void CToDoListDlg::OnUpdateSaveall(CCmdUI* pCmdUI) 
{
	int nCtrl = GetTDCCount();
	
	while (nCtrl--)
	{
		if (GetToDoCtrl(nCtrl).IsModified())
		{
			pCmdUI->Enable();
			return;
		}
	}
	
	// else nothing modified
	pCmdUI->Enable(FALSE);
}

void CToDoListDlg::OnCloseall() 
{
	// delete tasklists
	int nCtrl = GetTDCCount();
	
	while (nCtrl--)
		CloseToDoCtrl(nCtrl, FALSE);
	
	// if empty then create a new dummy item		
	if (!GetTDCCount())
		CreateNewTaskList(FALSE);
	else
		ResizeDlg();
}

void CToDoListDlg::OnUpdateCloseall(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetTDCCount());
}

void CToDoListDlg::OnExit()
{
    OnClose();
}

void CToDoListDlg::OnUpdateExit(CCmdUI* pCmdUI)
{
    if (Prefs().GetSysTrayOption() == STO_ONCLOSE || Prefs().GetSysTrayOption() == STO_ONMINCLOSE)
        pCmdUI->SetText("Minimize to S&ystem Tray");
    else
        pCmdUI->SetText("E&xit ToDoList");
}

void CToDoListDlg::DoExit() 
{
    // save all first to ensure new tasklists get reloaded on startup
    if (!SaveAll(TRUE, FALSE, TRUE))
        return; // user cancelled
	
	SaveSettings(); // before we close the tasklists
	
	// hide thw window as soon as possible so users do not
	// see the machinations of closing down
	ShowWindow(SW_HIDE);
	
	// delete tasklists
	CAutoFlag af(m_bClosing, TRUE);
	int nCtrl = GetTDCCount();
	
	while (nCtrl--)
		VERIFY(CloseToDoCtrl(nCtrl, FALSE)); // shouldn't fail now
	
	// if there are any still open then the user must have cancelled else destroy the window
	ASSERT (!GetTDCCount());
	
	if (!GetTDCCount())
		DestroyWindow();	
}

void CToDoListDlg::OnUpdateMovetask(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount == 1);	
}

void CToDoListDlg::OnTimer(UINT nIDEvent) 
{
	CDialog::OnTimer(nIDEvent);
	
	// if we are disabled (== modal dialog visible) then do not respond
	if (!IsWindowEnabled())
		return;
	
	// if no controls are active kill the timers
	if (!GetTDCCount())
	{
		SetTimer(TIMER_READONLYSTATUS, FALSE);
		SetTimer(TIMER_TIMESTAMPCHANGE, FALSE);
		SetTimer(TIMER_AUTOSAVE, FALSE);
		SetTimer(TIMER_CHECKOUTSTATUS, FALSE);
		return;
	}
	
	// don't check whilst in the middle of saving
	if (m_bSaving)
		return;
	
	switch (nIDEvent)
	{
	case TIMER_READONLYSTATUS:
		OnTimerReadOnlyStatus();
		break;
		
	case TIMER_TIMESTAMPCHANGE:
		OnTimerTimestampChange();
		break;
		
	case TIMER_AUTOSAVE:
		OnTimerAutoSave();
		break;
		
	case TIMER_CHECKOUTSTATUS:
		OnTimerCheckoutStatus();
		break;
		
	case TIMER_DUEITEMS:
		OnTimerDueItems();
		break;
	}
}

void CToDoListDlg::OnTimerDueItems(int nCtrl)
{
	// prevent re-entrancy
	static BOOL bInTimer = FALSE; // first time only
	
	if (bInTimer)
		return;
	
	CAutoFlag af(bInTimer, TRUE);
	
	SEARCHPARAMS sp;
	SEARCHRESULT result;
	
	sp.dwFlags = 0;
	sp.nFindWhat = FIND_DUEDATE;
	sp.dateTo = COleDateTime::GetCurrentTime();
	
	int nFrom = (nCtrl == -1) ? 0 : nCtrl;
	int nTo = (nCtrl == -1) ? GetTDCCount() - 1 : nCtrl;
	BOOL bRepaint = FALSE;
	
	for (nCtrl = nFrom; nCtrl <= nTo; nCtrl++)
	{
		CToDoCtrl& tdc = GetToDoCtrl(nCtrl);
		
		BOOL bDueItems = tdc.FindFirstTask(sp, result);
		
		if (bDueItems != m_mgrToDoCtrls.GetDueItemStatus(nCtrl))
		{
			m_mgrToDoCtrls.SetDueItemStatus(nCtrl, bDueItems);
			bRepaint = TRUE;
		}
	}
	
	if (bRepaint)
		m_tabCtrl.Invalidate(FALSE);
}

void CToDoListDlg::OnTimerReadOnlyStatus(int nCtrl)
{
	NOREENTRANT // macro helper
		
		CPreferencesDlg& prefs = Prefs();
	
	// work out whether we should check remote files or not
	BOOL bCheckRemoteFiles = (nCtrl != -1);
	
	if (!bCheckRemoteFiles)
	{
		static nElapsed = 0;
		UINT nRemoteFileCheckInterval = prefs.GetRemoteFileCheckFrequency() * 1000; // in ms
		
		nElapsed %= nRemoteFileCheckInterval;
		bCheckRemoteFiles = !nElapsed;
		
		nElapsed += INTERVAL_READONLYSTATUS;
	}
	
	int nReloadOption = prefs.GetReadonlyReloadOption();
	
	ASSERT (nReloadOption != RO_NO);
	
	// process files
	CString sFileList;
	int nFrom = (nCtrl == -1) ? 0 : nCtrl;
	int nTo = (nCtrl == -1) ? GetTDCCount() - 1 : nCtrl;
	
	for (nCtrl = nFrom; nCtrl <= nTo; nCtrl++)
	{
		CToDoCtrl& tdc = GetToDoCtrl(nCtrl);
		
		// don't check removeable drives
		int nType = m_mgrToDoCtrls.GetFilePathType(nCtrl);
		
        if (nType == TDCM_UNDEF || nType == TDCM_REMOVABLE)
			continue;
		
		// check remote files?
		if (!bCheckRemoteFiles && nType == TDCM_REMOTE)
			continue;
		
		CString sFilePath = tdc.GetFilePath();
		
		if (m_mgrToDoCtrls.RefreshReadOnlyStatus(nCtrl))
		{
			BOOL bReadOnly = m_mgrToDoCtrls.GetReadOnlyStatus(nCtrl);
			BOOL bReload = FALSE;
			
			if (nReloadOption == RO_ASK)
			{
				CString sMessage;
				sMessage.Format("The status of the file '%s' has changed \nfrom '%s' to '%s'.", 
					sFilePath, 
					bReadOnly ? "writable" : "read-only", 
					bReadOnly ? "read-only" : "writable");
				
				if (!bReadOnly) // might been modified
					sMessage += "\n\nWould you like to reload the it?";
				
				bReload = (MessageBox(sMessage, ABBREVCOPYRIGHT, !m_mgrToDoCtrls.GetReadOnlyStatus(nCtrl) ? MB_YESNO : MB_OK) == IDYES);
			}
			else
				bReload = !bReadOnly; // now writable
			
			if (bReload)
			{
				ReloadTaskList(nCtrl, FALSE);
				
				// notify the user if we haven't already and the trayicon is visible
				if (nReloadOption != RO_ASK && prefs.GetSysTrayOption() != STO_NONE)
				{
					sFileList += tdc.GetFriendlyProjectName();
					sFilePath += "\n";
				}
			}
			else // update the UI
			{
				m_mgrToDoCtrls.UpdateTabItemText(nCtrl);
				
				if (nCtrl == m_tabCtrl.GetCurSel())
				{
					UpdateCaption();
					tdc.SetReadonly(IsReadOnly(tdc));
				}
			}
		}
	}
	
	// do we need to notify the user?
	// don't if they are busy typing
	if (!sFileList.IsEmpty() && !CWinClasses::IsEditControl(::GetFocus()))
	{
		CString sMessage;
		sMessage.Format("The following tasklists have been reloaded:\n\n%s", sFileList);
		//		m_ti.ShowBalloon(sMessage, "Readonly Status Change", NIIF_INFO);
	}
}

void CToDoListDlg::OnTimerTimestampChange(int nCtrl)
{
	NOREENTRANT // macro helper
		
		CPreferencesDlg& prefs = Prefs();
	int nReloadOption = prefs.GetTimestampReloadOption();
	
	ASSERT (nReloadOption != RO_NO);
	
	// work out whether we should check remote files or not
	BOOL bCheckRemoteFiles = (nCtrl != -1);
	
	if (!bCheckRemoteFiles)
	{
		static nElapsed = 0;
		UINT nRemoteFileCheckInterval = prefs.GetRemoteFileCheckFrequency() * 1000; // in ms
		
		nElapsed %= nRemoteFileCheckInterval;
		bCheckRemoteFiles = !nElapsed;
		
		nElapsed += INTERVAL_TIMESTAMPCHANGE;
	}
	
	// process files
	CString sFileList;
	int nFrom = (nCtrl == -1) ? 0 : nCtrl;
	int nTo = (nCtrl == -1) ? GetTDCCount() - 1 : nCtrl;
	
	for (nCtrl = nFrom; nCtrl <= nTo; nCtrl++)
	{
		CToDoCtrl& tdc = GetToDoCtrl(nCtrl);
		CString sFilePath = tdc.GetFilePath();
		
		// don't check removeable drives
		int nType = m_mgrToDoCtrls.GetFilePathType(nCtrl);
		
        if (nType == TDCM_UNDEF || nType == TDCM_REMOVABLE)
			continue;
		
		// check remote files?
		if (!bCheckRemoteFiles && nType == TDCM_REMOTE)
			continue;
		
		if (m_mgrToDoCtrls.RefreshLastModified(nCtrl))
		{
			BOOL bReload = TRUE; // default
			
			if (nReloadOption == RO_ASK)
			{
				CString sMessage;
				sMessage.Format("The file '%s' has been modified outside of ToDoList."
					"\n\nWould you like to reload it?", 
					sFilePath);
				
				bReload = (MessageBox(sMessage, ABBREVCOPYRIGHT, MB_YESNO) == IDYES);
			}
			
			if (bReload)
			{
				ReloadTaskList(nCtrl, FALSE);
				
				// notify the user if we haven't already and the trayicon is visible
				if (nReloadOption != RO_ASK && prefs.GetSysTrayOption() != STO_NONE)
				{
					sFileList += tdc.GetFriendlyProjectName();
					sFilePath += "\n";
				}
				
				// update UI
				m_mgrToDoCtrls.UpdateTabItemText(nCtrl);
				
				if (nCtrl == m_tabCtrl.GetCurSel())
				{
					UpdateCaption();
					tdc.SetReadonly(IsReadOnly(tdc));
				}
			}
		}
	}
	
	// do we need to notify the user?
	// but not if they are busy typing
	if (!sFileList.IsEmpty() && !CWinClasses::IsEditControl(::GetFocus()))
	{
		CString sMessage;
		sMessage.Format("The following tasklists have been reloaded:\n\n%s", sFileList);
		//		m_ti.ShowBalloon(sMessage, "File Timestamp Change", NIIF_INFO);
	}
}

void CToDoListDlg::OnTimerAutoSave()
{
	NOREENTRANT // macro helper
		
		// don't save if the user is editing a task label
		if (!GetToDoCtrl().IsTreeLabelEditing())
			SaveAll(FALSE, FALSE, FALSE);
		else
			TRACE("Skipped auto save because of a label edit\n");
}

void CToDoListDlg::OnTimerCheckoutStatus(int nCtrl)
{
	NOREENTRANT // macro helper
		
		CPreferencesDlg& prefs = Prefs();
	
	// work out whether we should check remote files or not
	BOOL bCheckRemoteFiles = (nCtrl != -1);
	
	if (!bCheckRemoteFiles)
	{
		static nElapsed = 0;
		UINT nRemoteFileCheckInterval = prefs.GetRemoteFileCheckFrequency() * 1000; // in ms
		
		nElapsed %= nRemoteFileCheckInterval;
		bCheckRemoteFiles = !nElapsed;
		
		nElapsed += INTERVAL_CHECKOUTSTATUS;
	}
	
	// process files
	CString sFileList;
	int nFrom = (nCtrl == -1) ? 0 : nCtrl;
	int nTo = (nCtrl == -1) ? GetTDCCount() - 1 : nCtrl;
	
	for (nCtrl = nFrom; nCtrl <= nTo; nCtrl++)
	{
		CToDoCtrl& tdc = GetToDoCtrl(nCtrl);
		
		if (!m_mgrToDoCtrls.PathSupportsSourceControl(nCtrl))
            continue;
		
		// try to check out only if the previous attempt failed
		if (!tdc.IsCheckedOut() && prefs.GetCheckoutOnCheckin())
		{
			// we only try to check if the previous checkout failed
			if (!m_mgrToDoCtrls.GetLastCheckoutStatus(nCtrl))
			{
				if (tdc.CheckOut())
				{
					// update timestamp 
					m_mgrToDoCtrls.RefreshLastModified(nCtrl);
					m_mgrToDoCtrls.SetLastCheckoutStatus(nCtrl, TRUE);
					
					if (nCtrl == m_tabCtrl.GetCurSel())
					{
						UpdateCaption();
						tdc.SetReadonly(IsReadOnly(tdc));
					}
					
					m_mgrToDoCtrls.UpdateTabItemText(nCtrl);
					
					// notify the user if the trayicon is visible
					if (prefs.GetSysTrayOption() != STO_NONE)
					{
						sFileList += tdc.GetFriendlyProjectName();
						sFileList += "\n";
					}
				}
				else // make sure we try again later
					m_mgrToDoCtrls.SetLastCheckoutStatus(nCtrl, FALSE);
			}
		}
		// only checkin if sufficient time has elapsed since last mod
		// and there are no mods outstanding
		else if (tdc.IsCheckedOut() && prefs.GetCheckinOnNoEditTime())
		{
			if (!tdc.IsModified())
			{
				double dElapsed = COleDateTime::GetCurrentTime() - tdc.GetLastTaskModified();
				dElapsed *= 24 * 60; // convert to minutes
				
				if (dElapsed > (double)prefs.GetCheckinOnNoEditTime())
				{
					if (tdc.CheckIn())	
					{
						tdc.SetReadonly(TRUE);
						m_mgrToDoCtrls.RefreshLastModified(nCtrl);
						m_mgrToDoCtrls.SetLastCheckoutStatus(nCtrl, TRUE);
						
						UpdateCaption();
					}
				}
			}
		}
	}
	// do we need to notify the user?
	// but not if they are busy typing
	if (!sFileList.IsEmpty() && !CWinClasses::IsEditControl(::GetFocus()))
	{
		CString sMessage;
		sMessage.Format("The following tasklists have been checked out:\n\n%s", sFileList);
		//		m_ti.ShowBalloon(sMessage, "Source Control Change", NIIF_INFO);
	}
}

void CToDoListDlg::OnImportTasklist() 
{
	CFileDialogEx dialog(TRUE, "xml", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, XMLFILEFILTER, this);
	
	dialog.m_ofn.lpstrTitle = "Import Task List";
	
	if (dialog.DoModal() == IDOK)
	{
		CToDoCtrl& tdc = GetToDoCtrl();
		
		if (tdc.Import(dialog.GetPathName(), TRUE))
		{
			m_mgrToDoCtrls.SetModifiedStatus(GetSelToDoCtrl(), tdc.IsModified());
			UpdateCaption();
		}
		else
		{
			CString sMessage;
			sMessage.Format("'%s' does not appear to be a valid task list.", dialog.GetPathName());
			MessageBox(sMessage, ABBREVCOPYRIGHT, MB_OK);
		}
	}
}

void CToDoListDlg::OnSetPriority(UINT nCmdID) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	if (!tdc.IsReadOnly() && tdc.HasSelection())
		tdc.SetSelectedTaskPriority(nCmdID - ID_EDIT_SETPRIORITY0);
}

void CToDoListDlg::OnUpdateSetPriority(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount);
	
	if (nSelCount == 1)
		pCmdUI->SetCheck((int)(pCmdUI->m_nID - ID_EDIT_SETPRIORITY0) == tdc.GetSelectedTaskPriority());
	else
		pCmdUI->SetCheck(0);
}

void CToDoListDlg::OnEditSetfileref() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	if (!tdc.IsReadOnly() && tdc.HasSelection())
	{
		CString sFileRef = tdc.GetSelectedTaskFileRef();
		
		CFileDialogEx dialog(TRUE, NULL, sFileRef, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "All Files (*.*)|*.*||");
		dialog.m_ofn.lpstrTitle = "Select File to which Task Refers";
		
		if (dialog.DoModal() == IDOK)
			tdc.SetSelectedTaskFileRef(dialog.GetPathName());
	}
}

void CToDoListDlg::OnUpdateEditSetfileref(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	pCmdUI->Enable(!tdc.IsReadOnly() && tdc.HasSelection());
}

void CToDoListDlg::OnEditOpenfileref() 
{
	GetToDoCtrl().GotoSelectedTaskFileRef();
}

void CToDoListDlg::OnUpdateEditOpenfileref(CCmdUI* pCmdUI) 
{
	CString sFileRef = GetToDoCtrl().GetSelectedTaskFileRef();
	
	if (sFileRef.IsEmpty())
		pCmdUI->Enable(FALSE);
	else
	{
		pCmdUI->Enable(TRUE);
		pCmdUI->SetText(sFileRef);
	}
}

void CToDoListDlg::OnUpdateUserTool1(CCmdUI* pCmdUI) 
{
	if (pCmdUI->m_pMenu)
	{
		CUserToolArray aTools;
		Prefs().GetUserTools(aTools);
		
		CToolsHelper th(ID_TOOLS_USERTOOL1);
		th.UpdateMenu(pCmdUI, aTools);
	}
	else if (m_nToolbarOption == TB_TOOLBARANDMENU) // just enable all items
	{
		for (UINT nToolID = ID_TOOLS_USERTOOL1; nToolID <= ID_TOOLS_USERTOOL16; nToolID++)
			m_toolbar.GetToolBarCtrl().EnableButton(nToolID);
	}
}
void CToDoListDlg::OnUserTool(UINT nCmdID) 
{
	int nTool = nCmdID - ID_TOOLS_USERTOOL1;
	USERTOOL ut;
	
	if (Prefs().GetUserTool(nTool, ut))
	{
		CToolsHelper th(ID_TOOLS_USERTOOL1);
		CToDoCtrl& tdc = GetToDoCtrl();
		CString sFullPath = tdc.GetFilePath();
		
		// Save before executing the user tool
		OnSave();
		
		th.RunTool(ut, tdc.GetFilePath(), tdc.GetSelectedTaskID(), this);
	}
}

LRESULT CToDoListDlg::OnPreferencesTestTool(WPARAM wp, LPARAM lp)
{
	USERTOOL* pTool = (USERTOOL*)lp;
	
	if (pTool)
	{
		CToolsHelper th(ID_TOOLS_USERTOOL1);
		CToDoCtrl& tdc = GetToDoCtrl();
		
		th.TestTool(*pTool, tdc.GetFilePath(), tdc.GetSelectedTaskID(), &Prefs());
	}
	
	return 0;
}

void CToDoListDlg::OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu) 
{
	CDialog::OnInitMenuPopup(pPopupMenu, nIndex, bSysMenu);
	
	// we only need handle this for the main menu if the toolbar is not visible
	if ((m_nToolbarOption == TB_TOOLBARHIDDEN) || !bSysMenu)
		CToolbarHelper::PrepareMenuItems(pPopupMenu, this);	
}

void CToDoListDlg::OnViewNext() 
{
	if (GetTDCCount() < 2)
		return;
	
	int nNext = GetSelToDoCtrl() + 1;
	
	if (nNext >= GetTDCCount())
		nNext = 0;
	
	SelectToDoCtrl(nNext);
}

void CToDoListDlg::OnUpdateViewNext(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetTDCCount() > 1);
}

void CToDoListDlg::OnViewPrev() 
{
	if (GetTDCCount() < 2)
		return;
	
	int nPrev = GetSelToDoCtrl() - 1;
	
	if (nPrev < 0)
		nPrev = GetTDCCount() - 1;
	
	SelectToDoCtrl(nPrev);
}

void CToDoListDlg::OnUpdateViewPrev(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetTDCCount() > 1);
}

void CToDoListDlg::OnSysCommand(UINT nID, LPARAM lParam) 
{
	// we don't minimize if we're going to be hiding to then system tray
	if (nID == SC_MINIMIZE)
	{
		int nSysTrayOption = Prefs().GetSysTrayOption();
		
		if (nSysTrayOption == STO_ONMINIMIZE || nSysTrayOption == STO_ONMINCLOSE)
		{
			MinimizeToTray(Prefs().GetAutoSaveOnSysTray());
			return; // eat it
		}
	}
	else if (nID == SC_HOTKEY)
		Show(FALSE);
	
	// else
	CDialog::OnSysCommand(nID, lParam);
}

void CToDoListDlg::OnUpdateImport(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!GetToDoCtrl().IsReadOnly());
}

UINT CToDoListDlg::MapNewTaskPos(int nPos, BOOL bSubtask)
{
	if (!bSubtask) // task
	{
		switch (nPos)
		{
		case PUIP_TOP:		return ID_NEWTASK_ATTOP;
		case PUIP_BOTTOM:	return ID_NEWTASK_ATBOTTOM;
		case PUIP_BELOW:	return ID_NEWTASK_AFTERSELECTEDTASK;
			
		case PUIP_ABOVE: 
		default:			return ID_NEWTASK_BEFORESELECTEDTASK;
		}
	}
	else // subtask
	{
		if (nPos == PUIP_BOTTOM)
			return ID_NEWSUBTASK_ATBOTTOM;
		else
			return ID_NEWSUBTASK_ATTOP;
	}
}

UINT CToDoListDlg::GetNewTaskCmdID()
{
	return MapNewTaskPos(Prefs().GetNewTaskPos(), FALSE);
}

UINT CToDoListDlg::GetNewSubtaskCmdID()
{
	return MapNewTaskPos(Prefs().GetNewSubtaskPos(), TRUE);
}

void CToDoListDlg::OnNewtask() 
{
	// convert to users choice
	SendMessage(WM_COMMAND, GetNewTaskCmdID());
}

void CToDoListDlg::OnUpdateNewtask(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!GetToDoCtrl().IsReadOnly());
}

void CToDoListDlg::OnNewsubtask() 
{
	// convert to users choice
	SendMessage(WM_COMMAND, GetNewSubtaskCmdID());
}

void CToDoListDlg::OnUpdateNewsubtask(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
}

void CToDoListDlg::OnToolsCheckout() 
{
	CAutoFlag af(m_bSaving, TRUE);
	int nSel = GetSelToDoCtrl();
	
	if (!m_mgrToDoCtrls.GetReadOnlyStatus(nSel))
	{
		CString sCheckedOutTo;
		CToDoCtrl& tdc = GetToDoCtrl(nSel);
		
		if (tdc.CheckOut(sCheckedOutTo))
		{
			tdc.SetReadonly(FALSE);
			m_mgrToDoCtrls.SetLastCheckoutStatus(nSel, TRUE);
			m_mgrToDoCtrls.RefreshLastModified(nSel);
			
			TRACE ("Checkout timestamp of '%s' = %d\n", tdc.GetFilePath(), m_mgrToDoCtrls.GetLastModified(nSel));
			
			UpdateCaption();
		}
		else // failed
		{
			m_mgrToDoCtrls.SetLastCheckoutStatus(nSel, FALSE);
			
			// notify user
			CString sMessage;
			
			if (!sCheckedOutTo.IsEmpty())
				sMessage.Format("'%s' could not be checked out\nbecause it is currently checked out to '%s'", 
				tdc.GetFilePath(), sCheckedOutTo);
			else
				// if sCheckedOutTo is empty then the error is most likely because
				// the file has been deleted or cannot be opened for editing
				sMessage.Format("'%s' could not be checked out.\n\nPlease check that it has not been moved or deleted and that you have the required access rights.", 
				tdc.GetFilePath());
			
			MessageBox(sMessage, ABBREVCOPYRIGHT, MB_OK | MB_ICONEXCLAMATION);
		}
	}
}

void CToDoListDlg::OnUpdateToolsCheckout(CCmdUI* pCmdUI) 
{
	int nSel = GetSelToDoCtrl();
	CToDoCtrl& tdc = GetToDoCtrl(nSel);
	
	BOOL bEnable = (tdc.CompareFileFormat() != TDCFF_NEWER);
	
	if (bEnable)
	{
		bEnable &= m_mgrToDoCtrls.PathSupportsSourceControl(nSel);
		
		if (bEnable)
			bEnable &= (!m_mgrToDoCtrls.GetReadOnlyStatus(nSel) && !tdc.IsCheckedOut());
	}
	
	pCmdUI->Enable(bEnable);
}

void CToDoListDlg::OnToolsToggleCheckin() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	if (tdc.IsCheckedOut())
		OnToolsCheckin();
	else
		OnToolsCheckout();
}

void CToDoListDlg::OnUpdateToolsToggleCheckin(CCmdUI* pCmdUI) 
{
	BOOL bEnable = Prefs().GetEnableSourceControl();
	
	if (bEnable)
	{
		int nSel = GetSelToDoCtrl();
		CToDoCtrl& tdc = GetToDoCtrl(nSel);
		
		bEnable &= (tdc.CompareFileFormat() != TDCFF_NEWER);
		bEnable &= m_mgrToDoCtrls.PathSupportsSourceControl(nSel);
		bEnable &= (!m_mgrToDoCtrls.GetReadOnlyStatus(nSel));
		
		if (bEnable)
			pCmdUI->SetCheck(tdc.IsCheckedOut() ? 1 : 0);
	}
	
	pCmdUI->Enable(bEnable);
}

void CToDoListDlg::OnToolsCheckin() 
{
	CAutoFlag af(m_bSaving, TRUE);
	int nSel = GetSelToDoCtrl();
	CToDoCtrl& tdc = GetToDoCtrl(nSel);
	
	if (!m_mgrToDoCtrls.GetReadOnlyStatus(nSel) && !tdc.IsReadOnly())
	{
		ASSERT (!tdc.GetFilePath().IsEmpty());
		
		tdc.Flush();
		
		// save modifications
		if (tdc.IsModified())
		{
			if (Prefs().GetConfirmSaveOnExit())
			{
				int nRet = MessageBox("Would you like to save your changes before checking in?", 
					ABBREVCOPYRIGHT, MB_YESNOCANCEL);
				
				switch (nRet)
				{
				case IDYES:
					SaveTaskList(nSel);
					break;
					
				case IDNO:
					ReloadTaskList(nSel, FALSE);
					break;
					
				case IDCANCEL:
					return;
				}
			}
			else
				SaveTaskList(nSel); 
		}
		
		if (tdc.CheckIn())	
		{
			tdc.SetReadonly(TRUE);
			m_mgrToDoCtrls.RefreshLastModified(nSel);
			UpdateCaption();
		}
	}
	
	m_mgrToDoCtrls.SetLastCheckoutStatus(nSel, TRUE); // so we won't try to immediately check it out again
}

void CToDoListDlg::OnUpdateToolsCheckin(CCmdUI* pCmdUI) 
{
	int nSel = GetSelToDoCtrl();
	CToDoCtrl& tdc = GetToDoCtrl(nSel);
	
	BOOL bEnable = (tdc.CompareFileFormat() != TDCFF_NEWER);
	
	if (bEnable)
	{
		bEnable &= m_mgrToDoCtrls.PathSupportsSourceControl(nSel);
		
		if (bEnable)
			bEnable &= (!m_mgrToDoCtrls.GetReadOnlyStatus(nSel) && tdc.IsCheckedOut());
	}
	
	pCmdUI->Enable(bEnable);
}

void CToDoListDlg::OnExport() 
{
	int nTDCCount = GetTDCCount();
	ASSERT (nTDCCount >= 1);
	
	CExportDlg dialog(m_mgrImportExport, nTDCCount == 1, GetToDoCtrl().GetFilePath(), 
		Prefs().GetAutoExportFolderPath());
	
	if (dialog.DoModal() == IDOK)
	{
		// build filter
		BOOL bIncDone = dialog.GetIncludeCompletedTasks();
		BOOL bIncNotDone = dialog.GetIncludeUncompletedTasks();
		
		TDC_FILTER nFilter = ((bIncDone && bIncNotDone) ? TDCF_ALL :
								(bIncDone ? TDCF_DONE : 
								(bIncNotDone ? TDCF_NOTDONE : TDCF_NONE)));
								
								ASSERT (nFilter != TDCF_NONE);
								
								int nFormat = dialog.GetExportFormat();
								BOOL bSelTaskOnly = dialog.GetExportSelTaskOnly();
								
								CString sExportPath = dialog.GetExportPath();
								ASSERT (!sExportPath.IsEmpty());
								
								// preferences
								BOOL bPreview = Prefs().GetPreviewExport();
								BOOL bVisColsOnly = Prefs().GetExportVisibleColsOnly();
								BOOL bParentTitleCommentsOnly = Prefs().GetExportParentTitleCommentsOnly();
								
								// export
								CWaitCursor cursor;
								CTaskFile tasks;
								
								DWORD dwFlags = (bVisColsOnly ? TDCGT_VISIBLECOLSONLY : 0) | TDCGT_ISODATES |
									(bParentTitleCommentsOnly ? TDCGT_PARENTTITLECOMMENTSONLY : 0);
								
								if (nTDCCount == 1 || !dialog.GetExportAllTasklists())
								{
									CToDoCtrl& tdc = GetToDoCtrl();
									
									tdc.Flush();
									
									if (bSelTaskOnly)
										tdc.GetSelectedTasks(tasks, dwFlags);
									else
										tdc.GetTasklist(tasks, dwFlags);
									
									// project name
									tasks.SetProjectName(tdc.GetFriendlyProjectName());
									
									if (m_mgrImportExport.ExportTaskList(&tasks, sExportPath, nFormat))
									{
										// and preview
										if (bPreview)
											ShellExecute(*this, NULL, sExportPath, NULL, NULL, SW_SHOWNORMAL);
									}
								}
								else // multiple tasklists
								{
									for (int nCtrl = 0; nCtrl < nTDCCount; nCtrl++)
									{
										CToDoCtrl& tdc = GetToDoCtrl(nCtrl);
										tdc.Flush();
										
										if (bSelTaskOnly)
											tdc.GetSelectedTasks(tasks, dwFlags);
										else
											tdc.GetTasklist(tasks, dwFlags);
										
										// project name
										tasks.SetProjectName(tdc.GetFriendlyProjectName());
										
										// build filepath
										char szFilePath[MAX_PATH], szFName[_MAX_FNAME];
										_splitpath(tdc.GetFilePath(), NULL, NULL, szFName, NULL);
										_makepath(szFilePath, NULL, sExportPath, szFName, m_mgrImportExport.GetExporterFileExtension(nFormat));
										
										m_mgrImportExport.ExportTaskList(&tasks, szFilePath, nFormat);
									}
								}
	}
}

void CToDoListDlg::OnUpdateExport(CCmdUI* pCmdUI) 
{
	// make sure at least one control has items
	int nCtrl = GetTDCCount();
	
	while (nCtrl--)
	{
		if (GetToDoCtrl().GetTaskCount())
		{
			pCmdUI->Enable(TRUE);
			return;
		}
	}
	
	// else
	pCmdUI->Enable(FALSE);
}

void CToDoListDlg::OnToolsTransformactivetasklist() 
{
	// get file paths
	// and store for further use this session
	static CString sStylesheet, sOutputPath;
	
	// stylesheet
	{
		CFileDialogEx dialog(TRUE, "xsl", sStylesheet, OFN_HIDEREADONLY, XSLFILEFILTER, this);
		
		dialog.m_ofn.lpstrTitle = "Select Stylesheet - ToDoList � AbstractSpoon";
		
		if (dialog.DoModal() != IDOK)
			return; // user elected not to proceed
		
		sStylesheet = dialog.GetPathName();
	}
	
	// output
	{
		CFileDialogEx dialog(FALSE, "html", sOutputPath, OFN_OVERWRITEPROMPT, TRANSFORMFILEFILTER, this);
		
		dialog.m_ofn.lpstrTitle = "Save Transformation As - ToDoList � AbstractSpoon";
		
		if (dialog.DoModal() != IDOK)
			return; // user elected not to proceed
		
		sOutputPath = dialog.GetPathName();
	}
	
	// export
	CWaitCursor cursor;
	CTaskFile tasks;
	
	CToDoCtrl& tdc = GetToDoCtrl();
	tdc.Flush();
	
	// preferences
	BOOL bPreview = Prefs().GetPreviewExport();
	BOOL bVisColsOnly = Prefs().GetExportVisibleColsOnly();
	BOOL bParentTitleCommentsOnly = Prefs().GetExportParentTitleCommentsOnly();
	
	DWORD dwFlags = (bVisColsOnly ? TDCGT_VISIBLECOLSONLY : 0) | TDCGT_ISODATES |
		(bParentTitleCommentsOnly ? TDCGT_PARENTTITLECOMMENTSONLY : 0);
	
	tdc.GetTasklist(tasks, dwFlags);
	//	tasks.SetProjectName(tdc.GetFriendlyProjectName());
	
	CString sOutput;
	
	if (tasks.Transform(sStylesheet, sOutput))
	{
		CFile output;
		
		if (output.Open(sOutputPath, CFile::modeCreate | CFile::modeWrite))
		{
			output.Write((void*)(LPCTSTR)sOutput, sOutput.GetLength());
			output.Close();
			
			// and preview
			if (bPreview)
				ShellExecute(*this, NULL, sOutputPath, NULL, NULL, SW_SHOWNORMAL);
		}
	}
}

void CToDoListDlg::OnNexttopleveltask() 
{
	GetToDoCtrl().GotoTopLevelTask(TDCG_NEXT);
}

void CToDoListDlg::OnPrevtopleveltask() 
{
	GetToDoCtrl().GotoTopLevelTask(TDCG_PREV);
}

void CToDoListDlg::OnUpdateNexttopleveltask(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanGotoTopLevelTask(TDCG_NEXT));
}

void CToDoListDlg::OnUpdatePrevtopleveltask(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanGotoTopLevelTask(TDCG_PREV));
}

void CToDoListDlg::OnFindTasks() 
{
	if (!m_findDlg.GetSafeHwnd())
		VERIFY(m_findDlg.Initialize(this));
	
	if (IsWindowVisible())
		m_findDlg.Show();
	
	m_bFindShowing = TRUE;
}

int CToDoListDlg::MapFindWhat(FIND_WHAT fw)
{
	switch (fw)
	{
	case FW_TITLECOMMENTS: return FIND_TITLECOMMENTS;
	case FW_PRIORITY: return FIND_PRIORITY;
	case FW_PERCENTDONE: return FIND_PERCENTDONE;
	case FW_ALLOCTO: return FIND_ALLOCTO;
	case FW_ALLOCBY: return FIND_ALLOCBY;
	case FW_STATUS: return FIND_STATUS;
	case FW_CATEGORY: return FIND_CATEGORY;
	case FW_TIMEEST: return FIND_TIMEEST;
	case FW_TIMESPENT: return FIND_TIMESPENT;
	case FW_STARTDATE: return FIND_STARTDATE;
	case FW_DUEDATE: return FIND_DUEDATE;
	case FW_DONEDATE: return FIND_DONEDATE;
	case FW_TASKID: return FIND_TASKID;
	case FW_FLAG: return FIND_FLAG;
	}
	
	ASSERT(0);
	return -1;
}

LRESULT CToDoListDlg::OnFindDlgClose(WPARAM wp, LPARAM lp)
{
	m_bFindShowing = FALSE;
	return 0L;
}

LRESULT CToDoListDlg::OnFindDlgFind(WPARAM wp, LPARAM lp)
{
	// set up the search
	BOOL bSearchAll = m_findDlg.GetSearchAllTasklists();
	int nSelTaskList = GetSelToDoCtrl();
	
	int nFrom = bSearchAll ? 0 : nSelTaskList;
	int nTo = bSearchAll ? GetTDCCount() - 1 : nSelTaskList;
	
	// search params
	SEARCHPARAMS sp;
	
	sp.dwFlags = m_findDlg.GetIncludeDone() ? FIND_INCLUDEDONE : 0;
	sp.nFindWhat = MapFindWhat(m_findDlg.GetFindWhat());
	
	// find specific params
	switch (sp.nFindWhat)
	{
	case FIND_TITLECOMMENTS:
	case FIND_ALLOCTO:
	case FIND_ALLOCBY:
	case FIND_STATUS:
	case FIND_CATEGORY:
		sp.dwFlags |= m_findDlg.GetMatchCase() ? FIND_MATCHCASE : 0;
		sp.dwFlags |= m_findDlg.GetMatchWholeWord() ? FIND_MATCHWHOLEWORD : 0;
		sp.sText = m_findDlg.GetText();
		break;
		
	case FIND_PRIORITY:
	case FIND_PERCENTDONE:
	case FIND_TASKID:
		m_findDlg.GetRange(sp.nFrom, sp.nTo);
		break;
		
	case FIND_TIMEEST:
	case FIND_TIMESPENT:
		m_findDlg.GetRange(sp.dFrom, sp.dTo);
		break;
		
	case FIND_STARTDATE:
	case FIND_DUEDATE:
	case FIND_DONEDATE:
		m_findDlg.GetRange(sp.dateFrom, sp.dateTo);
		break;
		
	case FIND_FLAG:
		break; // no additional info req
		
	default:
		ASSERT(0);
		return 0;
	}
	
	// do the search and populate the results
	for (int nCtrl = nFrom; nCtrl <= nTo; nCtrl++)
	{
		CToDoCtrl& tdc = GetToDoCtrl(nCtrl);
		CResultArray aResults;
		
		if (tdc.FindTasks(sp, aResults))
		{
			// use tasklist title from tabctrl
			char szTitle[128] = "";
			
			if (bSearchAll)
			{
				TCITEM tci = { TCIF_TEXT, 0, 0, szTitle, 127, 0, 0 };
				m_tabCtrl.GetItem(nCtrl, &tci);
			}
			
			for (int nResult = 0; nResult < aResults.GetSize(); nResult++)
			{
				AddFindResult(aResults[nResult], sp, nCtrl, szTitle);
			}
		}
	}
	
	if (m_findDlg.GetResultCount() == 1 && m_findDlg.GetAutoSelectSingles())
	{
		POSITION pos = m_findDlg.GetFirstResultPos();
		ASSERT (pos);
		
		if (pos)
		{
			FTDRESULT result;
			VERIFY(m_findDlg.GetNextResult(pos, result));
			
			OnFindSelectResult(0, (LPARAM)&result);
			m_findDlg.Show(FALSE);
		}
	}
	
	return 0;
}

void CToDoListDlg::AddFindResult(const SEARCHRESULT& result, const SEARCHPARAMS& params, 
								 int nTaskList, LPCTSTR szTaskList)
{
	CToDoCtrl& tdc = GetToDoCtrl(nTaskList);
	HTREEITEM htiRes = result.hti;
	CString sPath;
				
	if (szTaskList && *szTaskList)
		sPath.Format("%s / %s", szTaskList, tdc.GetItemPath(htiRes));
	else
		sPath = tdc.GetItemPath(htiRes);
	
	// format the match string
	CString sMatch;
	
	switch (params.nFindWhat)
	{
	case FIND_ALLOCTO:
	case FIND_ALLOCBY:
	case FIND_STATUS:
	case FIND_CATEGORY:
		sMatch = result.sMatch;
		break;
		
	case FIND_PRIORITY:
	case FIND_PERCENTDONE:
	case FIND_TASKID:
		sMatch.Format("%d", result.nMatch);
		break;
		
	case FIND_TIMEEST:
	case FIND_TIMESPENT:
		sMatch.Format("%0.2f", result.dMatch);
		break;
		
	case FIND_STARTDATE:
	case FIND_DUEDATE:
	case FIND_DONEDATE:
		sMatch = CDateHelper::FormatDate(result.dateMatch, 
			Prefs().GetDisplayDatesInISO(),	
			Prefs().GetShowWeekdayInDates());
		break;
	}
				
	m_findDlg.AddResult(tdc.GetItemText(htiRes), sMatch, sPath, result.dwID, nTaskList);
}

LRESULT CToDoListDlg::OnFindSelectResult(WPARAM wp, LPARAM lp)
{
	// extract HTREEITEM
	FTDRESULT* pResult = (FTDRESULT*)lp;
	ASSERT (pResult->dwItemData); // HTREEITEM
	
	CToDoCtrl& tdc = GetToDoCtrl(pResult->nTaskList);
	
	CHoldRedraw hr(tdc); // prevents flickering
	
	if (m_tabCtrl.GetCurSel() != pResult->nTaskList)
		SelectToDoCtrl(pResult->nTaskList);
	
	tdc.SetFocusToTree();
	
	if (tdc.GetSelectedTaskID() != pResult->dwItemData)
		tdc.SelectTask(pResult->dwItemData);
	
	return 0;
}

LRESULT CToDoListDlg::OnFindSelectAll(WPARAM wp, LPARAM lp)
{
	if (!m_findDlg.GetResultCount())
		return 0;
	
	CWaitCursor cursor;
	
	// not the most efficient technique but achieves the 
	// most correct result
	for (int nTDC = 0; nTDC < GetTDCCount(); nTDC++)
	{
		CToDoCtrl& tdc = GetToDoCtrl(nTDC);
		
		tdc.DeselectAll();
		
		POSITION pos = m_findDlg.GetFirstResultPos();
		
		while (pos)
		{
			FTDRESULT result;
			
			if (m_findDlg.GetNextResult(pos, result) && (nTDC == result.nTaskList))
			{
				tdc.MultiSelectItem((HTREEITEM)result.dwItemData, 1, FALSE);
			}
		}
	}
	
	// redraw the active tasklist
	if (m_findDlg.GetResultCount(GetSelToDoCtrl()))
		CRedrawAll(GetToDoCtrl(), TRUE); 
	
	return 0;
}

LRESULT CToDoListDlg::OnDropFile(WPARAM wParam, LPARAM lParam)
{
	OpenTaskList((LPCTSTR)lParam);
	
	return 0;
}

void CToDoListDlg::OnViewMovetasklistright() 
{
	m_mgrToDoCtrls.MoveToDoCtrl(GetSelToDoCtrl(), 1);
}

void CToDoListDlg::OnUpdateViewMovetasklistright(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!Prefs().GetKeepTabsOrdered() &&
		m_mgrToDoCtrls.CanMoveToDoCtrl(GetSelToDoCtrl(), 1));
}

void CToDoListDlg::OnViewMovetasklistleft() 
{
	m_mgrToDoCtrls.MoveToDoCtrl(GetSelToDoCtrl(), -1);
}

void CToDoListDlg::OnUpdateViewMovetasklistleft(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!Prefs().GetKeepTabsOrdered() &&
		m_mgrToDoCtrls.CanMoveToDoCtrl(GetSelToDoCtrl(), -1));
}

void CToDoListDlg::OnToolsShowtasksDue(UINT nCmdID) 
{
	int nDueBy = PFP_DUETODAY;
	CString sDueBy("today");
	
	switch (nCmdID)
	{
	case ID_TOOLS_SHOWTASKS_DUETODAY:
		break; // done
		
	case ID_TOOLS_SHOWTASKS_DUETOMORROW:
		sDueBy = "tomorrow";
		nDueBy = PFP_DUETOMORROW;
		break;
		
	case ID_TOOLS_SHOWTASKS_DUEENDTHISWEEK:
		sDueBy = "by the end of this week";
		nDueBy = PFP_DUETHISWEEK;
		break;
		
	case ID_TOOLS_SHOWTASKS_DUEENDNEXTWEEK:
		sDueBy = "by the end of next week";
		nDueBy = PFP_DUENEXTWEEK;
		break;
		
	case ID_TOOLS_SHOWTASKS_DUEENDTHISMONTH:
		sDueBy = "by the end of this month";
		nDueBy = PFP_DUETHISMONTH;
		break;
		
	case ID_TOOLS_SHOWTASKS_DUEENDNEXTMONTH:
		sDueBy = "by the end of next month";
		nDueBy = PFP_DUENEXTMONTH;
		break;
		
	default:
		ASSERT(0);
		return;
	}
	
	if (!DoDueTaskNotification(&GetToDoCtrl(), nDueBy))
	{
		MessageBox(CString("There are no tasks due ") + sDueBy, ABBREVCOPYRIGHT);
	}
}

void CToDoListDlg::OnViewMenuonly() 
{
	SetToolbarOption(TB_TOOLBARHIDDEN);
}

void CToDoListDlg::OnUpdateViewMenuonly(CCmdUI* pCmdUI) 
{
	pCmdUI->SetRadio(m_nToolbarOption == TB_TOOLBARHIDDEN);
}

void CToDoListDlg::OnViewToolbarandmenu() 
{
	SetToolbarOption(TB_TOOLBARANDMENU);
}

void CToDoListDlg::OnUpdateViewToolbarandmenu(CCmdUI* pCmdUI) 
{
	pCmdUI->SetRadio(m_nToolbarOption == TB_TOOLBARANDMENU);
}

void CToDoListDlg::OnViewToolbaronly() 
{
	SetToolbarOption(TB_TOOLBARONLY);
}

void CToDoListDlg::OnUpdateViewToolbaronly(CCmdUI* pCmdUI) 
{
	pCmdUI->SetRadio(m_nToolbarOption == TB_TOOLBARONLY);
}

void CToDoListDlg::SetToolbarOption(int nOption)
{
	if (nOption == m_nToolbarOption)
		return; // nothing to do
	
	VERIFY(InitToolbar());
	
	PrepareToolbar(nOption);
	ShowMenuBar(nOption != TB_TOOLBARONLY, FALSE); 
	GetDlgItem(IDC_HORZDIVIDERTOP)->ShowWindow(nOption == TB_TOOLBARANDMENU ? SW_SHOW : SW_HIDE);
	
	m_nToolbarOption = nOption;
	
	ResizeDlg();
	
	// redraw toolbar
	m_toolbar.UpdateWindow();
}

void CToDoListDlg::PrepareToolbar(int nOption)
{
	switch (nOption)
	{
	case TB_TOOLBARHIDDEN:
		m_toolbar.EnableWindow(FALSE);
		m_toolbar.ShowWindow(SW_HIDE);
		m_tbHelper.Release();
		break;
		
	case TB_TOOLBARANDMENU:
		m_toolbar.EnableWindow(TRUE);
		m_toolbar.ShowWindow(SW_SHOW);
		
		// hide inappropriate buttons
		if (!m_toolbar.GetToolBarCtrl().IsButtonHidden(ID_MOVETASK))
		{
			m_toolbar.GetToolBarCtrl().HideButton(ID_MOVETASK, TRUE);
			m_toolbar.GetToolBarCtrl().DeleteButton(m_toolbar.CommandToIndex(ID_MOVETASK) + 1);
		}
		
		// remove drop buttons
		if (m_tbHelper.IsInitialized())
			m_tbHelper.Release(TRUE);
		
		// reinit for tooltip support
		if (m_tbHelper.Initialize(&m_toolbar, this))
		{
			m_tbHelper.EnableMultilineText();
			m_tbHelper.SetTooltip(ID_SORT, CToolbarHelper::GetTip(GetSortID(GetToDoCtrl().GetSortBy())));
			m_tbHelper.SetTooltip(ID_NEWTASK, "New Task");
			m_tbHelper.SetTooltip(ID_NEWSUBTASK, "New Subtask");
			m_tbHelper.SetTooltip(ID_EDIT_TASKTEXT, "Edit Task Text");
			m_tbHelper.SetTooltip(ID_LOAD_NORMAL, "Open Tasklist");
			m_tbHelper.SetTooltip(ID_DELETETASK, "Delete Task");
			m_tbHelper.SetTooltip(ID_PREFERENCES, "Preferences");
			m_tbHelper.SetTooltip(ID_HELP, "Help");
			m_tbHelper.SetTooltip(ID_SIMPLEMODE, "Maximize Tasklist");
		}
		
		AppendTools2Toolbar(TRUE);
		break;
		
	case TB_TOOLBARONLY:
		m_toolbar.EnableWindow(TRUE);
		m_toolbar.ShowWindow(SW_SHOW);
		
		// show previously hidden buttons
		if (m_toolbar.GetToolBarCtrl().IsButtonHidden(ID_MOVETASK))
		{
			m_toolbar.GetToolBarCtrl().HideButton(ID_MOVETASK, FALSE);
			
			TBBUTTON tbb = { -1, 0, 0, TBSTYLE_SEP, 0, -1 };
			m_toolbar.GetToolBarCtrl().InsertButton(m_toolbar.CommandToIndex(ID_MOVETASK) + 1, &tbb);
		}
		
		if (!m_tbHelper.IsInitialized())
			m_tbHelper.Initialize(&m_toolbar, this);
		
		m_tbHelper.SetTooltip(ID_MOVETASK, "Move Tasks (Alt+M)");
		m_tbHelper.SetTooltip(ID_SORT, "Sort Tasks (Alt+S)");
		m_tbHelper.SetTooltip(ID_NEWTASK, "New Task (Alt+N)");
		m_tbHelper.SetTooltip(ID_EDIT_TASKTEXT, "Edit Selected Task (Alt+E)");
		m_tbHelper.SetTooltip(ID_LOAD_NORMAL, "New/Open/Save... (Alt+F)");
		m_tbHelper.SetTooltip(ID_DELETETASK, "Delete Tasks (Alt+D)");
		m_tbHelper.SetTooltip(ID_PREFERENCES, "Tools (Alt+T)");
		m_tbHelper.SetTooltip(ID_HELP, "Help (Alt+H)");
		m_tbHelper.SetTooltip(ID_SIMPLEMODE, "View (Alt+V)");
		
		m_tbHelper.EnableMultilineText();
		m_tbHelper.SetDropButton(ID_SORT, IDR_MAINFRAME, SORT, 0, 'S');
		m_tbHelper.SetDropButton(ID_NEWTASK, IDR_MAINFRAME, NEWTASK, GetNewTaskCmdID(), 'N');
		m_tbHelper.SetDropButton(ID_EDIT_TASKTEXT, IDR_MAINFRAME, EDITTASK, ID_EDIT_TASKTEXT, 'E');
		m_tbHelper.SetDropButton(ID_LOAD_NORMAL, IDR_MAINFRAME, FILEALL, ID_LOAD_NORMAL, 'F');
		m_tbHelper.SetDropButton(ID_DELETETASK, IDR_MAINFRAME, DELETETASK, ID_DELETETASK, 'D');
		m_tbHelper.SetDropButton(ID_PREFERENCES, IDR_MAINFRAME, TOOLS, ID_PREFERENCES, 'T');
		m_tbHelper.SetDropButton(ID_MOVETASK, IDR_MAINFRAME, MOVE, 0, 'M');
		m_tbHelper.SetDropButton(ID_HELP, IDR_MAINFRAME, HELP, ID_HELP, 'H');
		m_tbHelper.SetDropButton(ID_SIMPLEMODE, IDR_MAINFRAME, VIEW, ID_SIMPLEMODE, 'V');
		
		AppendTools2Toolbar(FALSE);
		break;
	}
	
	UpdateDefaultSortItem();
	
	GetToDoCtrl().Invalidate(); // for win9x
}

void CToDoListDlg::AppendTools2Toolbar(BOOL bAppend)
{
	CToolsHelper th(ID_TOOLS_USERTOOL1);
	
	if (bAppend)
	{
		// then re-add
		CUserToolArray aTools;
		Prefs().GetUserTools(aTools);
		
		th.AppendToolsToToolbar(aTools, m_toolbar, ID_PREFERENCES, &m_tbHelper);
	}
	else // remove
		th.RemoveToolsFromToolbar(m_toolbar, ID_PREFERENCES);
}

void CToDoListDlg::OnSort() 
{
	// we should get this only when both the toolbar and menu are visible
	ASSERT (m_nToolbarOption == TB_TOOLBARANDMENU);
	
	GetToDoCtrl().Resort();
}

void CToDoListDlg::ResetPrefs()
{
	delete m_pPrefs;
	m_pPrefs = new CPreferencesDlg(&m_mgrShortcuts, IDR_MAINFRAME);
}

CPreferencesDlg& CToDoListDlg::Prefs() const
{
	ASSERT (m_pPrefs);
	return *m_pPrefs;
}

void CToDoListDlg::OnNewtaskAttop() 
{
	VERIFY (NewTask("Task", TDC_INSERTATTOP));
}

void CToDoListDlg::OnUpdateNewtaskAttop(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	pCmdUI->Enable(!tdc.IsReadOnly());
}

void CToDoListDlg::OnNewtaskAtbottom() 
{
	VERIFY (NewTask("Task", TDC_INSERTATBOTTOM));
}

void CToDoListDlg::OnUpdateNewtaskAtbottom(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	pCmdUI->Enable(!tdc.IsReadOnly());
}

void CToDoListDlg::OnSpellcheckcomments() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	tdc.SpellcheckSelectedTask(FALSE);
}

void CToDoListDlg::OnUpdateSpellcheckcomments(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	pCmdUI->Enable(!tdc.GetSelectedTaskComments().IsEmpty());
}

void CToDoListDlg::OnSpellchecktitle() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	tdc.SpellcheckSelectedTask(TRUE);
}

void CToDoListDlg::OnUpdateSpellchecktitle(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	pCmdUI->Enable(!tdc.GetSelectedTaskTitle().IsEmpty());
}

void CToDoListDlg::OnFileEncrypt() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	if (!tdc.IsReadOnly())
		tdc.EnableEncryption(!tdc.IsEncrypted());
}

void CToDoListDlg::OnUpdateFileEncrypt(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	pCmdUI->Enable(tdc.CanEncrypt() && !tdc.IsReadOnly());
	pCmdUI->SetCheck(tdc.IsEncrypted() ? 1 : 0);
}

void CToDoListDlg::OnFileResetversion() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	if (!tdc.IsReadOnly())
	{
		tdc.ResetFileVersion();
		tdc.SetModified();
		
		UpdateStatusbar();
		UpdateCaption();
	}
}

void CToDoListDlg::OnUpdateFileResetversion(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	pCmdUI->Enable(!tdc.IsReadOnly());
}

void CToDoListDlg::OnSpellcheckTasklist() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	tdc.Spellcheck();
}

void CToDoListDlg::OnUpdateSpellcheckTasklist(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	pCmdUI->Enable(tdc.GetTaskCount());
}

BOOL CToDoListDlg::SaveAll(BOOL bClosingTaskLists, BOOL bClosingDown, BOOL bFlush)
{
	int nCtrl = GetTDCCount();
	
	while (nCtrl--)
	{
		CToDoCtrl& tdc = GetToDoCtrl(nCtrl);
		
		if (bFlush)
			tdc.Flush();
		
		if (!ConfirmSaveTaskList(nCtrl, bClosingTaskLists, bClosingDown))
			return FALSE; // user cancelled
		else
			m_mgrToDoCtrls.UpdateTabItemText(nCtrl);
	}
	
	UpdateCaption();
    return TRUE;
}

void CToDoListDlg::OnEditTimeTrackTask() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	tdc.TimeTrackSelectedTask(!tdc.IsSelectedTaskBeingTimeTracked());
}

void CToDoListDlg::OnUpdateEditTimeTrackTask(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	pCmdUI->Enable(tdc.CanTimeTrackSelectedTask());
	pCmdUI->SetCheck(tdc.IsSelectedTaskBeingTimeTracked() ? 1 : 0);
}

void CToDoListDlg::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	if (nIDCtl == IDC_TABCONTROL)
	{
		CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
		CToDoCtrl& tdc = GetToDoCtrl(lpDrawItemStruct->itemID);
		
		if (m_mgrToDoCtrls.GetDueItemStatus(lpDrawItemStruct->itemID))
		{
			// draw a little tag in the top left corner in the colour
			// of the highest priority
			COLORREF crTag = tdc.GetPriorityColor(10);
			
			for (int nHPos = 0; nHPos < 6; nHPos++)
			{
				for (int nVPos = 0; nVPos < 6 - nHPos; nVPos++)
				{
					pDC->SetPixelV(lpDrawItemStruct->rcItem.left + nHPos, 
						lpDrawItemStruct->rcItem.top + nVPos, crTag);
				}
			}
		}
		
		return;
	}
	else if (nIDCtl == 0 && lpDrawItemStruct->itemID == ID_CLOSE)
	{
		if (CMenuEx::DrawMDIButton(IDB_XPCLOSE, lpDrawItemStruct))
			return;
	}
	
	CDialog::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

void CToDoListDlg::OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct) 
{
	if (nIDCtl == 0 && lpMeasureItemStruct->itemID == ID_CLOSE)
	{
		if (CMenuEx::MeasureMDIButton(IDB_XPCLOSE, lpMeasureItemStruct))
			return;
	}
	
	CDialog::OnMeasureItem(nIDCtl, lpMeasureItemStruct);
}

void CToDoListDlg::OnViewNextSel() 
{
	GetToDoCtrl().SelectNextTasksInHistory();
}

void CToDoListDlg::OnUpdateViewNextSel(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanSelectNextTasksInHistory());
}

void CToDoListDlg::OnViewPrevSel() 
{
	GetToDoCtrl().SelectPrevTasksInHistory();
}

void CToDoListDlg::OnUpdateViewPrevSel(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanSelectPrevTasksInHistory());
}

void CToDoListDlg::OnSplitTaskIntoPieces(UINT nCmdID) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nNumPieces = 2 + (nCmdID - ID_NEWTASK_SPLITTASKINTO_TWO);
	
	tdc.SplitSelectedTask(nNumPieces);
}

void CToDoListDlg::OnUpdateSplitTaskIntoPieces(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	pCmdUI->Enable(tdc.CanSplitSelectedTask());
}

void CToDoListDlg::OnViewExpandtask() 
{
	GetToDoCtrl().ExpandSelectedTask(TRUE);
}

void CToDoListDlg::OnUpdateViewExpandtask(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanExpandSelectedTask(TRUE));
}

void CToDoListDlg::OnViewCollapsetask() 
{
	GetToDoCtrl().ExpandSelectedTask(FALSE);
}

void CToDoListDlg::OnUpdateViewCollapsetask(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanExpandSelectedTask(FALSE));
}

void CToDoListDlg::OnViewCollapseall() 
{
	GetToDoCtrl().ExpandAllTasks(FALSE);
}

void CToDoListDlg::OnViewExpandall() 
{
	GetToDoCtrl().ExpandAllTasks(TRUE);
}

void CToDoListDlg::OnUpdateViewExpandall(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetTaskCount());
}

void CToDoListDlg::OnUpdateViewCollapseall(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetTaskCount());
}

void CToDoListDlg::OnUpdateUserExport1(CCmdUI* pCmdUI) 
{
	m_mgrImportExport.UpdateExportMenu(pCmdUI, 8);
}

void CToDoListDlg::OnUserExport(UINT nCmdID) 
{
	int nExp = nCmdID - ID_TOOLS_USEREXPORT1;
	
	// get user to pick a file path
	CFileDialogEx dialog(FALSE, 
		m_mgrImportExport.GetExporterFileExtension(nExp), 
		NULL, 
		OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY, 
		m_mgrImportExport.GetExporterFileFilter(nExp), 
		this);
	
	dialog.m_ofn.lpstrTitle = "Export Task List - ToDoList � AbstractSpoon";
	
	if (dialog.DoModal() == IDOK)
	{
		// preferences
		BOOL bVisColsOnly = Prefs().GetExportVisibleColsOnly();
		BOOL bParentTitleCommentsOnly = Prefs().GetExportParentTitleCommentsOnly();
		
		DWORD dwFlags = (bVisColsOnly ? TDCGT_VISIBLECOLSONLY : 0) | TDCGT_ISODATES |
			(bParentTitleCommentsOnly ? TDCGT_PARENTTITLECOMMENTSONLY : 0);
		
		CWaitCursor cursor;
		CTaskFile tasks;
		
		CToDoCtrl& tdc = GetToDoCtrl();
		
		tdc.GetTasklist(tasks, dwFlags);
		
		// project name
		tasks.SetProjectName(tdc.GetFriendlyProjectName());
		
		if (m_mgrImportExport.ExportTaskList(&tasks, dialog.GetPathName(), nExp))
		{
			UpdateWindow();
			
			// and preview
			if (Prefs().GetPreviewExport())
				ShellExecute(*this, NULL, dialog.GetPathName(), NULL, NULL, SW_SHOWNORMAL);
		}
	}
}

void CToDoListDlg::OnUpdateUserImport1(CCmdUI* pCmdUI) 
{
	m_mgrImportExport.UpdateImportMenu(pCmdUI, 8);
}

void CToDoListDlg::OnUserImport(UINT nCmdID) 
{
	int nImp = nCmdID - ID_TOOLS_USERIMPORT1;
	
	// get user to pick a file path
	CFileDialogEx dialog(TRUE, 
		m_mgrImportExport.GetImporterFileExtension(nImp), 
		NULL, 
		OFN_HIDEREADONLY, 
		m_mgrImportExport.GetImporterFileFilter(nImp), 
		this);
	
	dialog.m_ofn.lpstrTitle = "Import Task List - ToDoList � AbstractSpoon";
	
	if (dialog.DoModal() == IDOK)
	{
		CWaitCursor cursor;
		CTaskFile tasks;
		
		m_mgrImportExport.ImportTaskList(dialog.GetPathName(), &tasks, nImp);
		
		CToDoCtrl& tdc = GetToDoCtrl();
		
		tdc.SetTasks(tasks, TRUE);
	}
}

void CToDoListDlg::OnWindow(UINT nCmdID) 
{
	int nTDC = (int)(nCmdID - ID_WINDOW1);
	
	if (nTDC < GetTDCCount())
		SelectToDoCtrl(nTDC);
}

void CToDoListDlg::OnUpdateWindow(CCmdUI* pCmdUI) 
{
	if (pCmdUI->m_pMenu)
	{
		ASSERT (ID_WINDOW1 == pCmdUI->m_nID);
		const UINT MAXWINDOWS = 16;
		
		// delete existing tool entries first
		for (int nWnd = 0; nWnd < MAXWINDOWS; nWnd++)
			pCmdUI->m_pMenu->DeleteMenu(ID_WINDOW1 + nWnd, MF_BYCOMMAND);
		
		int nSel = GetSelToDoCtrl();
		int nPos = 0, nTDCCount = GetTDCCount();
		ASSERT (nTDCCount);
		
		for (nWnd = 0; nWnd < nTDCCount; nWnd++)
		{
			CToDoCtrl& tdc = GetToDoCtrl(nWnd);
			
			CString sMenuItem;
			
			if (nPos < 9)
				sMenuItem.Format("&%d %s", nPos + 1, tdc.GetFriendlyProjectName());
			else
				sMenuItem = tdc.GetFriendlyProjectName();
			
			UINT nFlags = MF_BYPOSITION | MF_STRING | (nSel == nWnd ? MF_CHECKED : MF_UNCHECKED);
			pCmdUI->m_pMenu->InsertMenu(pCmdUI->m_nIndex++, nFlags, ID_WINDOW1 + nWnd, sMenuItem);
			
			nPos++;
		}
		
		// update end menu count
		pCmdUI->m_nIndex--; // point to last menu added
		pCmdUI->m_nIndexMax = pCmdUI->m_pMenu->GetMenuItemCount();
		
		pCmdUI->m_bEnableChanged = TRUE;    // all the added items are enabled
	}
}

void CToDoListDlg::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
{
	CDialog::OnActivate(nState, pWndOther, bMinimized);
	
	if (nState != WA_INACTIVE && GetTDCCount())
		GetToDoCtrl().SetFocusToTree();
}

BOOL CToDoListDlg::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	UpdateWindow();
	
	return CDialog::OnCommand(wParam, lParam);
}

void CToDoListDlg::OnEnable(BOOL bEnable) 
{
	CDialog::OnEnable(bEnable);
	
	// pause time tracking if disabling else enable as usual
	PauseTimeTracking(!bEnable);
}

void CToDoListDlg::OnDestroy() 
{
	CDialog::OnDestroy();
}

void CToDoListDlg::OnViewSorttasklisttabs() 
{
	int nSel = m_mgrToDoCtrls.SortToDoCtrlsByName();
	SelectToDoCtrl(nSel);
}

void CToDoListDlg::OnUpdateViewSorttasklisttabs(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetTDCCount() > 1 && !Prefs().GetKeepTabsOrdered());
}


void CToDoListDlg::OnEditInctaskpercentdone() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	tdc.IncrementSelectedTaskPercentDone(5);
}

void CToDoListDlg::OnUpdateEditInctaskpercentdone(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	pCmdUI->Enable(nSelCount && !tdc.IsReadOnly());	
}

void CToDoListDlg::OnEditDectaskpercentdone() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	tdc.IncrementSelectedTaskPercentDone(-5);
}

void CToDoListDlg::OnUpdateEditDectaskpercentdone(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	pCmdUI->Enable(nSelCount && !tdc.IsReadOnly());	
}

void CToDoListDlg::OnEditDectaskpriority() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	tdc.IncrementSelectedTaskPriority(-1);
}

void CToDoListDlg::OnUpdateEditDectaskpriority(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	pCmdUI->Enable(nSelCount && !tdc.IsReadOnly());	
}

void CToDoListDlg::OnEditInctaskpriority() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	tdc.IncrementSelectedTaskPriority(1);
}

void CToDoListDlg::OnUpdateEditInctaskpriority(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	pCmdUI->Enable(nSelCount && !tdc.IsReadOnly());	
}

void CToDoListDlg::OnEditFlagtask() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	tdc.SetSelectedTaskFlag(!tdc.IsSelectedTaskFlagged());
}

void CToDoListDlg::OnUpdateEditFlagtask(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();
	
	pCmdUI->Enable(nSelCount && !tdc.IsReadOnly());	
	pCmdUI->SetCheck(tdc.IsSelectedTaskFlagged() ? 1 : 0);
}

void CToDoListDlg::OnFileOpenarchive() 
{
	CString sArchivePath = m_mgrToDoCtrls.GetArchivePath(GetSelToDoCtrl());
	BOOL bArchiveExists = (GetFileAttributes(sArchivePath) != 0xffffffff);
	
	if (bArchiveExists)
		OpenTaskList(sArchivePath, FALSE);
}

void CToDoListDlg::OnUpdateFileOpenarchive(CCmdUI* pCmdUI) 
{
	CString sArchivePath = m_mgrToDoCtrls.GetArchivePath(GetSelToDoCtrl());
	BOOL bArchiveExists = (GetFileAttributes(sArchivePath) != 0xffffffff);
	
	pCmdUI->Enable(bArchiveExists);
}
