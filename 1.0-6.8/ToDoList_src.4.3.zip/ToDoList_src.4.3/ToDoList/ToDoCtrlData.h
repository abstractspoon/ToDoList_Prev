// ToDoCtrlData.h: interface for the CToDoCtrlData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TODOCTRLDATA_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_)
#define AFX_TODOCTRLDATA_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "tdcstruct.h"
#include "tdcenum.h"
#include <afxtempl.h>

class TODOITEM
{
public:
	TODOITEM(LPCTSTR szTitle, LPCTSTR szComments = NULL); 
	TODOITEM(); 
	TODOITEM(const TODOITEM& tdi); 
	
	BOOL HasStart() const;
	BOOL HasDue() const;
	BOOL IsDone() const;
	
	void ClearStart();
	void ClearDue();
	void ClearDone();
	
	BOOL IsDue() const;
	BOOL IsDue(const COleDateTime& dateDueBy) const;

	void SetModified();
	void ResetCalcs(); 

//  ------------------------------------------
	
	CString sTitle;
	CString sComments, sCustomComments;
	COLORREF color;
	COleDateTime dateStart, dateDue, dateDone;
	int nPriority;
	CString sAllocTo, sAllocBy;
	CString sStatus, sCategory;
	int nPercentDone;
	CString sFileRefPath;
	double dTimeEstimate, dTimeSpent;
	int nTimeEstUnits, nTimeSpentUnits;
	COleDateTime tLastMod;
	BOOL bFlagged;
	
	// cached calculations for drawing optimization
	int nCalcPriority;
	int nCalcPercent;
	double dCalcTimeEstimate, dCalcTimeSpent;
	COleDateTime dateEarliestDue;
};

typedef CMap<DWORD, DWORD, TODOITEM*, TODOITEM*&> CTDIMap;
typedef CMap<DWORD, DWORD, HTREEITEM, HTREEITEM&> CHTIMap;

// sort helper structure
class CToDoCtrlData;

struct TDSORTSTRUCT
{
	CToDoCtrlData* pData;
	const CHTIMap* pMapHTItems;
	TDC_SORTBY nSortBy;
	BOOL bAscending;
};

class CXmlItem;

class CToDoCtrlData  
{
	friend class CToDoCtrl;
	
protected:
	CToDoCtrlData(CTreeCtrl& tree, const CWordArray& aStyles);
	virtual ~CToDoCtrlData();
	
	inline UINT GetTaskCount() const { return m_mapTDItems.GetCount(); }
	inline DWORD GetTaskID(HTREEITEM hti) const { return hti ? m_tree.GetItemData(hti) : 0; }
	inline HTREEITEM GetItem(DWORD dwID) { return FindItem(dwID, NULL); }
	
	TODOITEM* NewTask(const TODOITEM* pTDIRef = NULL);
	TODOITEM* GetTask(DWORD dwID) const;
	TODOITEM* GetTask(HTREEITEM hti) const;
	void DeleteTask(DWORD dwID);
	void DeleteAllTasks(BOOL bIncTree = TRUE);
	void AddTask(DWORD dwID, TODOITEM* pTDI);
	
	void Sort(TDC_SORTBY nBy, BOOL bAscending);
	
	// Gets
	CString GetTaskTitle(DWORD dwID) const;
	COleDateTime GetTaskDoneDate(DWORD dwID) const;
	COleDateTime GetTaskDueDate(DWORD dwID) const;
	COleDateTime GetTaskStartDate(DWORD dwID) const;
	BOOL IsTaskDone(DWORD dwID) const;
	BOOL IsTaskDue(DWORD dwID) const;
	COLORREF GetTaskColor(DWORD dwID) const; // -1 on no item selected
	CString GetTaskComments(DWORD dwID) const;
	CString GetTaskCustomComments(DWORD dwID) const;
	int GetTaskPercent(DWORD dwID, BOOL bCheckIfDone) const;
	double GetTaskTimeEstimate(DWORD dwID) const; // in hours
	double GetTaskTimeSpent(DWORD dwID) const; // in hours
	double GetTaskTimeEstimate(DWORD dwID, int& nUnits) const;
	double GetTaskTimeSpent(DWORD dwID, int& nUnits) const;
	CString GetTaskAllocTo(DWORD dwID) const;
	CString GetTaskAllocBy(DWORD dwID) const;
	CString GetTaskStatus(DWORD dwID) const;
	CString GetTaskCategory(DWORD dwID) const;
	CString GetTaskFileRef(DWORD dwID) const;
	int GetTaskPriority(DWORD dwID) const;
	BOOL IsTaskFlagged(DWORD dwID) const;
	
	COLORREF GetTaskColor(const HTREEITEM hti) const;
	double GetTaskTimeEstimate(const HTREEITEM hti) const;
	double GetTaskTimeSpent(const HTREEITEM hti) const;
	CString GetTaskAllocTo(const HTREEITEM hti) const;
	CString GetTaskAllocBy(const HTREEITEM hti) const;
	CString GetTaskStatus(const HTREEITEM hti) const;
	CString GetTaskCategory(const HTREEITEM hti) const;
	int GetTaskPriority(const HTREEITEM hti) const;
	BOOL IsTaskDue(HTREEITEM hti) const;
	BOOL DeleteTask(HTREEITEM hti);
	int GetItemPos(HTREEITEM hti, HTREEITEM htiSearch) const; // returns 0 if not found
	BOOL IsParentTaskDone(HTREEITEM hti) const; // this is recursive
	int AreChildTasksDone(HTREEITEM hti) const; // 1=yes, 0=no, -1=no children
	BOOL IsTaskFlagged(HTREEITEM hti) const;
	
	double GetEarliestDueDate(HTREEITEM hti) const;
	int GetHighestPriority(HTREEITEM hti) const;
	int CalcPercentDone(const HTREEITEM hti) const;
	double CalcTimeEstimate(const HTREEITEM hti, int nUnits) const;
	double CalcTimeSpent(const HTREEITEM hti, int nUnits) const;
	
	double GetEarliestDueDate(HTREEITEM hti, const TODOITEM* pTDI) const;
	int GetHighestPriority(HTREEITEM hti, const TODOITEM* pTDI) const;
	double CalcTimeEstimate(const HTREEITEM hti, const TODOITEM* pTDI, int nUnits) const;
	double CalcTimeSpent(const HTREEITEM hti, const TODOITEM* pTDI, int nUnits) const;
	int CalcPercentDone(const HTREEITEM hti, const TODOITEM* pTDI) const;
	int CalcPercentFromTime(const HTREEITEM hti, const TODOITEM* pTDI) const; // spent / estimate
	
	// non-const versions that update calcs
	double GetEarliestDueDate(HTREEITEM hti, TODOITEM* tdi);
	int GetHighestPriority(HTREEITEM hti, TODOITEM* tdi);
	int CalcPercentDone(const HTREEITEM hti, TODOITEM* tdi);
	double CalcTimeEstimate(const HTREEITEM hti, TODOITEM* tdi, int nUnits);
	double CalcTimeSpent(const HTREEITEM hti, TODOITEM* tdi, int nUnits);

	// Sets. 0 = failed, 1 = success, -1 = success (no change)
	int SetTaskStartDate(DWORD dwID, const COleDateTime& date);
	int SetTaskDoneDate(DWORD dwID, const COleDateTime& date);
	int SetTaskDueDate(DWORD dwID, const COleDateTime& date);
	int SetTaskDone(DWORD dwID, BOOL bDone, int& nPrevPercent);
	int SetTaskColor(DWORD dwID, COLORREF color);
	int SetTaskComments(DWORD dwID, LPCTSTR szComments);
	int SetTaskCustomComments(DWORD dwID, const CString& sComments); // can't be LPCTSTR cos not NULL terminated
	int SetTaskPercent(DWORD dwID, int nPercent);
	int SetTaskTimeEstimate(DWORD dwID, const double& dTime, int nUnits = TDCTU_HOURS);
	int SetTaskTimeSpent(DWORD dwID, const double& dTime, int nUnits = TDCTU_HOURS);
	int SetTaskAllocTo(DWORD dwID, LPCTSTR szAllocTo);
	int SetTaskAllocBy(DWORD dwID, LPCTSTR szAllocBy);
	int SetTaskStatus(DWORD dwID, LPCTSTR szStatus);
	int SetTaskCategory(DWORD dwID, LPCTSTR szCategory);
	int SetTaskFileRef(DWORD dwID, LPCTSTR szFilePath);
	int SetTaskPriority(DWORD dwID, int nPriority); // 0-10 (10 is highest)
	int SetTaskTitle(DWORD dwID, LPCTSTR szTitle);
	int SetTaskAttributeAsParent(HTREEITEM hti, TDC_ATTRIBUTE nAttrib);
	int SetTaskFlag(DWORD dwID, BOOL bFlagged);
	
	int FindTasks(const SEARCHPARAMS& params, CResultArray& aResults) const;
	DWORD FindFirstTask(const SEARCHPARAMS& params, SEARCHRESULT& result) const;
	
	void BuildHTIMap(CHTIMap& mapHTI);
	void UpdateHTIMapEntry(CHTIMap& mapHTI, HTREEITEM hti);
	BOOL IsTaskFullyDone(const HTREEITEM hti, const TODOITEM* pTDI, BOOL bCheckSiblings) const;
	
	// internal use only
	void SumPercentDone(const HTREEITEM hti, const TODOITEM* pTDI,
						double& dTotalPercent, double& dTotalWeighting) const;
	
	void ResetCachedCalculations();
	
	BOOL IsTaskTimeTrackable(HTREEITEM hti);
	BOOL IsTaskDone(HTREEITEM hti, DWORD dwExtraCheck = 0) const;
	void ApplyLastChangeToSubtasks(const HTREEITEM hti, const TODOITEM* pTDI, TDC_ATTRIBUTE nAttrib);

	int SaveTreeExpandedState(LPCTSTR szRegKey, HTREEITEM hti = NULL, int nStart = 0); 
	void LoadTreeExpandedState(LPCTSTR szRegKey); 
	
	static int MapTimeUnits(const CString& sUnits);
	static CString MapTimeUnits(int nUnits);
	
protected:
	CTDIMap m_mapTDItems; // the real data
	CTreeCtrl& m_tree; // CToDoCtrl tree
	const CWordArray& m_aStyles; // CToDoCtrl styles
	
protected:
	static int ParseSearchString(LPCTSTR szLookFor, CStringArray& aWords);
	static BOOL FindWord(LPCTSTR szWord, LPCTSTR szText, BOOL bMatchCase, BOOL bMatchWholeWord);
	
	DWORD FindFirstTask(HTREEITEM hti, const SEARCHPARAMS& params, SEARCHRESULT& result) const;
	int FindTasks(HTREEITEM hti, const SEARCHPARAMS& params, CResultArray& aResults) const;
	BOOL TaskMatches(HTREEITEM pTDI, const SEARCHPARAMS& params, SEARCHRESULT& result) const;
	static BOOL TaskMatches(const COleDateTime& date, const SEARCHPARAMS& params);
	static BOOL TaskMatches(const CString& sText, const SEARCHPARAMS& params);
	static BOOL TaskMatches(const double& dValue, const SEARCHPARAMS& params);
	static BOOL TaskMatches(int nValue, const SEARCHPARAMS& params);
	
	HTREEITEM FindItem(DWORD dwID, HTREEITEM htiStart);
	
	// for sorting
	void Sort(HTREEITEM hti, const TDSORTSTRUCT& ss);
	static int CALLBACK CompareFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort); 
	static int Compare(const COleDateTime& date1, const COleDateTime& date2);
	static int Compare(const CString& sText1, const CString& sText2, BOOL bCheckEmpty = FALSE);
	static int Compare(int nNum1, int nNum2);
	static int Compare(const double& dNum1, const double& dNum2);
	
	inline BOOL HasStyle(int nStyle) const { return m_aStyles[nStyle] ? TRUE : FALSE; }
};

#endif // !defined(AFX_TODOCTRLDATA_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_)
