// PreferencesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesDlg.h"

#include "..\shared\winclasses.h"
#include "..\shared\wclassdefines.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesDlg dialog

// default priority colors
const COLORREF PRIORITYLOWCOLOR = RGB(30, 225, 0);
const COLORREF PRIORITYHIGHCOLOR = RGB(255, 0, 0);

// matches order of pages
enum 
{ 
	PAGE_GEN, 
	PAGE_MULTIUSER, 
	PAGE_FILE, 
	PAGE_UI, 
	PAGE_UITASK, 
	PAGE_TASK, 
	PAGE_TASKDEF, 
	PAGE_TOOL, 
	PAGE_SHORTCUT 
};
const char PATHDELIM = '>';

CPreferencesDlg::CPreferencesDlg(CShortcutManager* pMgr, UINT nMenuID, CWnd* pParent /*=NULL*/)
	: CDialog(IDD_PREFERENCES, pParent), m_pageShortcuts(pMgr, nMenuID, FALSE)
{
}

CPreferencesDlg::~CPreferencesDlg()
{
}

void CPreferencesDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesDlg)
	DDX_Control(pDX, IDC_PAGES, m_tcPages);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPreferencesDlg, CDialog)
	//{{AFX_MSG_MAP(CPreferencesDlg)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_HELP2, OnHelp)
	ON_NOTIFY(TVN_SELCHANGED, IDC_PAGES, OnSelchangedPages)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesDlg message handlers

BOOL CPreferencesDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_tcPages.SetIndent(0);

	AddPage(&m_pageGen, "General");
	AddPage(&m_pageMultiUser, "Multiple Users");
	AddPage(&m_pageFile, "File Actions");
	AddPage(&m_pageUI, "User Interface>General");
	AddPage(&m_pageUITasklist, "User Interface>Task List>Attributes");
	AddPage(&m_pageUITasklistColors, "User Interface>Task List>Fonts/Colors/Images");
	AddPage(&m_pageTask, "Tasks>Attributes");
	AddPage(&m_pageTaskDef, "Tasks>Defaults");
	AddPage(&m_pageExport, "Exporting");
	AddPage(&m_pageTool, "Tools");
	AddPage(&m_pageShortcuts, "Keyboard Shortcuts");

	CRect rPPHost;
	GetDlgItem(IDC_HOSTFRAME)->GetWindowRect(rPPHost);
	ScreenToClient(rPPHost);

	if (m_pphost.Create(rPPHost, this))
		SetActivePage(AfxGetApp()->GetProfileInt("Preferences", "StartPage", 0));

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreferencesDlg::OnOK()
{
	CDialog::OnOK();

	m_pphost.OnOK();
}

void CPreferencesDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	AfxGetApp()->WriteProfileInt("Preferences", "StartPage", m_pphost.GetActiveIndex());
}

BOOL CPreferencesDlg::PreTranslateMessage(MSG* pMsg) 
{
	// special handling for hotkeys
	if (CWinClasses::IsClass(pMsg->hwnd, WC_HOTKEY))
		return FALSE;

	// handle F1 help
	if (pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_F1)
	{
		OnHelp();
		return TRUE;
	}
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CPreferencesDlg::OnHelp() 
{
	// who is the active page?
	int nSel = m_pphost.GetActiveIndex();
	CString sHelpPage = "pref.htm";

	switch (nSel)
	{
	case PAGE_GEN:
		sHelpPage += "#gen";
		break;
		
	case PAGE_MULTIUSER:
		sHelpPage += "#multiuser";
		break;
		
	case PAGE_FILE:
		sHelpPage += "#file";
		break;
		
	case PAGE_UI:
		sHelpPage += "#ui";
		break;
		
	case PAGE_UITASK:
		sHelpPage += "#uitask";
		break;
		
	case PAGE_TASK:
		sHelpPage += "#tasks";
		break;
		
	case PAGE_TASKDEF:
		sHelpPage += "#taskdefs";
		break;
		
	case PAGE_TOOL:
		sHelpPage += "#tools";
		break;
		
	case PAGE_SHORTCUT:
		sHelpPage += "#shortcut";
		break;
	}

	AfxGetApp()->WinHelp((DWORD)(LPCTSTR)sHelpPage);
}

void CPreferencesDlg::AddPage(CPropertyPage* pPage, LPCTSTR szPath)
{
	CString sPath(szPath);

	if (m_pphost.AddPage(pPage))
	{
		HTREEITEM htiParent = TVI_ROOT; // default
		int nFind = sPath.Find(PATHDELIM);

		while (nFind != -1)
		{
			CString sParent = sPath.Left(nFind);
			sPath = sPath.Mid(nFind + 1);

			// see if parent already exists
			HTREEITEM htiParentParent = htiParent;
			htiParent = m_tcPages.GetChildItem(htiParentParent);

			while (htiParent)
			{
				if (sParent.CompareNoCase(m_tcPages.GetItemText(htiParent)) == 0)
					break;

				htiParent = m_tcPages.GetNextItem(htiParent, TVGN_NEXT);
			}

			if (!htiParent)
			{
				htiParent = m_tcPages.InsertItem(sParent, htiParentParent);

				// embolden root items
				if (htiParentParent == TVI_ROOT)
					m_tcPages.SetItemState(htiParent, TVIS_BOLD, TVIS_BOLD);
			}

			nFind = sPath.Find(PATHDELIM);
		}

		HTREEITEM hti = m_tcPages.InsertItem(sPath, htiParent); // whatever's left
		m_tcPages.EnsureVisible(hti);

		// embolden root items
		if (htiParent == TVI_ROOT)
			m_tcPages.SetItemState(hti, TVIS_BOLD, TVIS_BOLD);

		// map both ways
		m_tcPages.SetItemData(hti, (DWORD)pPage);
		m_mapPP2HTI[(void*)pPage] = (void*)hti;
	}
}

void CPreferencesDlg::OnSelchangedPages(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

	HTREEITEM htiSel = m_tcPages.GetSelectedItem();

	while (m_tcPages.ItemHasChildren(htiSel))
		htiSel = m_tcPages.GetChildItem(htiSel);

	CPropertyPage* pPage = (CPropertyPage*)m_tcPages.GetItemData(htiSel);
	ASSERT (pPage);

	if (pPage)
	{
		m_pphost.SetActivePage(pPage, FALSE);

		// update caption
		CString sCaption;
		sCaption.Format("Preferences (%s) - ToDoList � AbstractSpoon", GetItemPath(htiSel));
		SetWindowText(sCaption);
	}

	m_tcPages.SetFocus();
	
	*pResult = 0;
}

void CPreferencesDlg::SetActivePage(int nPage)
{
	m_pphost.SetActivePage(nPage, FALSE);

	// synchronize tree
	CPropertyPage* pPage = m_pphost.GetActivePage();
	HTREEITEM hti = NULL;

	if (m_mapPP2HTI.Lookup(pPage, (void*&)hti) && hti)
		m_tcPages.SelectItem(hti);
}

CString CPreferencesDlg::GetItemPath(HTREEITEM hti)
{
	CString sPath = m_tcPages.GetItemText(hti);

	while (hti = m_tcPages.GetParentItem(hti))
		sPath = m_tcPages.GetItemText(hti) + " > " + sPath;

	return sPath;
}
