// RTFContentControl.cpp : implementation file
//

#include "stdafx.h"
#include "RTFContentCtrl.h"
#include "RTFContentControl.h"

#include "..\shared\autoflag.h"
#include "..\todolist\tdcmsg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRTFContentControl

CRTFContentControl::CRTFContentControl() : m_bAllowNotify(TRUE)
{
}

CRTFContentControl::~CRTFContentControl()
{
}


BEGIN_MESSAGE_MAP(CRTFContentControl, CRulerRichEditCtrl)
	//{{AFX_MSG_MAP(CRTFContentControl)
	ON_WM_CONTEXTMENU()
	ON_WM_CREATE()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_EN_CHANGE(RTF_CONTROL, OnChangeText)
	ON_MESSAGE(WM_SETFONT, OnSetFont)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRTFContentControl message handlers

void CRTFContentControl::OnChangeText() 
{
	if (m_bAllowNotify)
		GetParent()->SendMessage(WM_TDCN_COMMENTSCHANGE);
}

LRESULT CRTFContentControl::OnSetFont(WPARAM wp, LPARAM lp)
{
	// richedit2.0 sends a EN_CHANGE notification if it contains
	// text when it receives a font change.
	// to us though this is a bogus change so we prevent a notification
	// being sent
	CAutoFlag af(m_bAllowNotify, FALSE);

	return CRulerRichEditCtrl::OnSetFont(wp, lp);
}

// ICustomControl implementation
int CRTFContentControl::GetContent(unsigned char* pContent) const
{
	return GetContent(this, pContent);
}

// hack to get round GetRTF not being const
int CRTFContentControl::GetContent(const CRTFContentControl* pCtrl, unsigned char* pContent)
{
	CString sContent;

	// cast away constness
	sContent = ((CRTFContentControl*)pCtrl)->GetRTF();

	if (pContent)
		CopyMemory(pContent, (LPCTSTR)sContent, sContent.GetLength());

	return sContent.GetLength();
}

bool CRTFContentControl::SetContent(unsigned char* pContent, int nLength)
{
	LPCTSTR RTFTAG = "{\\rtf";
	const int LENTAG = strlen(RTFTAG);

	// content must begin with rtf tag
	if (nLength < LENTAG || strncmp((const char*)pContent, RTFTAG, LENTAG))
		return false;

	CAutoFlag af(m_bAllowNotify, FALSE);
	CString sContent((LPCSTR)pContent, nLength);

	SetRTF(sContent);
	return true; 
}

int CRTFContentControl::GetTextContent(char* szContent, int nLength) const
{
	if (!szContent)
		return GetWindowTextLength();

	// else
	if (nLength == -1)
		nLength = lstrlen(szContent);
	
	GetWindowText(szContent, nLength);
	return nLength;
}

bool CRTFContentControl::SetTextContent(const char* szContent)
{
	CAutoFlag af(m_bAllowNotify, TRUE);
	SendMessage(WM_SETTEXT, 0, (LPARAM)szContent);
	return true; 
}

HWND CRTFContentControl::GetHwnd() const
{
	return GetSafeHwnd();
}

bool CRTFContentControl::HasTypeID() const
{
	return true;
}

bool CRTFContentControl::GetTypeID(GUID& id) const
{
	id = RTF_TYPEID;
	return true;
}

void CRTFContentControl::SetReadOnly(bool bReadOnly)
{
	CRulerRichEditCtrl::SetReadOnly((BOOL)bReadOnly);
}

void CRTFContentControl::Release()
{
	delete this;
}

void CRTFContentControl::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	if (pWnd == &GetRichEditCtrl())
	{
		// prepare a simple edit menu
		CMenu menu;

		if (menu.LoadMenu(IDR_POPUP))
		{
			CMenu* pPopup = menu.GetSubMenu(0);

			if (pPopup)
			{
				CHARRANGE cr;
				GetRichEditCtrl().GetSel(cr);

				BOOL bHasSel = (cr.cpMax - cr.cpMin);

				pPopup->EnableMenuItem(ID_EDIT_CUT, MF_BYCOMMAND | (bHasSel ? MF_ENABLED : MF_GRAYED));
				pPopup->EnableMenuItem(ID_EDIT_COPY, MF_BYCOMMAND | (bHasSel ? MF_ENABLED : MF_GRAYED));
				pPopup->EnableMenuItem(ID_EDIT_PASTE, MF_BYCOMMAND | (GetRichEditCtrl().CanPaste(CF_TEXT) ? MF_ENABLED : MF_GRAYED));
				pPopup->EnableMenuItem(ID_EDIT_DELETE, MF_BYCOMMAND | (bHasSel ? MF_ENABLED : MF_GRAYED));

				pPopup->CheckMenuItem(ID_EDIT_SHOWTOOLBAR, MF_BYCOMMAND | (IsToolbarVisible() ? MF_CHECKED  : MF_UNCHECKED));
				pPopup->CheckMenuItem(ID_EDIT_SHOWRULER, MF_BYCOMMAND | (IsRulerVisible() ? MF_CHECKED  : MF_UNCHECKED));

				BOOL bWordWrap = HasWordWrap();
				pPopup->CheckMenuItem(ID_EDIT_WORDWRAP, MF_BYCOMMAND | (bWordWrap ? MF_CHECKED  : MF_UNCHECKED));

				// check pos
				if (point.x == -1 && point.y == -1)
				{
					point = GetCaretPos();
					::ClientToScreen(m_rtf, &point);
				}

				UINT nCmdID = ::TrackPopupMenu(*pPopup, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_LEFTBUTTON, 
												point.x, point.y, 0, *this, NULL);

				switch (nCmdID)
				{
				case ID_EDIT_CUT:
					GetRichEditCtrl().Cut();
					break;

				case ID_EDIT_COPY:
					GetRichEditCtrl().Copy();
					break;

				case ID_EDIT_PASTE:
					GetRichEditCtrl().Paste();
					break;

				case ID_EDIT_DELETE:
					GetRichEditCtrl().ReplaceSel("");
					break;

				case ID_EDIT_SELECT_ALL:
					GetRichEditCtrl().SetSel(0, -1);
					break;
		
				case ID_EDIT_INSERTDATESTAMP:
					{
						COleDateTime date = COleDateTime::GetCurrentTime();
						GetRichEditCtrl().ReplaceSel(date.Format(), TRUE);
					}
					break;

				case ID_EDIT_SHOWTOOLBAR:
					ShowToolbar(!IsToolbarVisible());
					break;

				case ID_EDIT_SHOWRULER:
					ShowRuler(!IsRulerVisible());
					break;

				case ID_EDIT_WORDWRAP:
					SetWordWrap(!bWordWrap);
					break;
				}
			}
		}
	}
}

int CRTFContentControl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CRulerRichEditCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// restore toolbar and ruler state
	BOOL bShowToolbar = AfxGetApp()->GetProfileInt("Settings", "ShowToolbar", TRUE);
	BOOL bShowRuler = AfxGetApp()->GetProfileInt("Settings", "ShowRuler", TRUE);
	BOOL bWordWrap = AfxGetApp()->GetProfileInt("Settings", "WordWrap", TRUE);
	
	ShowToolbar(bShowToolbar);
	ShowRuler(bShowRuler);
	SetWordWrap(bWordWrap);
		
	return 0;
}

bool CRTFContentControl::ProcessMessage(MSG* pMsg) 
{
	return (PreTranslateMessage(pMsg) != FALSE);
	
	// handle shortcut keys
	switch (pMsg->message)
	{
	case WM_KEYDOWN:
		{
			BOOL bCtrl = (GetKeyState(VK_CONTROL) & 0x8000);

			if (bCtrl)
			{
				switch (pMsg->wParam)
				{
				case 'c':
				case 'C':
					GetRichEditCtrl().Copy();
					return true;

				case 'v':
				case 'V':
					GetRichEditCtrl().Paste();
					return true;

				case 'x':
				case 'X':
					GetRichEditCtrl().Cut();
					return true;

				case 'a':
				case 'A':
					GetRichEditCtrl().SetSel(0, -1);
					return true;

				case 'b':
				case 'B':
					DoBold();
					return true;

				case 'i':
				case 'I':
					DoItalic();
					return true;

				case 'u':
				case 'U':
					DoUnderline();
					return true;

				}
			}
		}
		break;
	}
	
	return false;
	
}

void CRTFContentControl::OnDestroy() 
{
	CRulerRichEditCtrl::OnDestroy();
	
	// save toolbar and ruler state
	AfxGetApp()->WriteProfileInt("Settings", "ShowToolbar", IsToolbarVisible());
	AfxGetApp()->WriteProfileInt("Settings", "ShowRuler", IsRulerVisible());
	AfxGetApp()->WriteProfileInt("Settings", "WordWrap", HasWordWrap());
}
