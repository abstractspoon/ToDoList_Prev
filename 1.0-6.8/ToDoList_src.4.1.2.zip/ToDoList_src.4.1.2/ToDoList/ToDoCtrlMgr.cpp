// ToDoListDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ToDoCtrlMgr.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CToDoCtrlMgr dialog

#define ASSERTVALIDINDEX(i) { ASSERT (i >= 0 && i < GetCount()); }

CToDoCtrlMgr::CToDoCtrlMgr()
{
}

CToDoCtrlMgr::~CToDoCtrlMgr()
{
}

CToDoCtrl& CToDoCtrlMgr::GetToDoCtrl(int nIndex)
{
	ASSERTVALIDINDEX(nIndex);

	return *(m_aToDoCtrls[nIndex].pTDC);
}

const CToDoCtrl& CToDoCtrlMgr::GetToDoCtrl(int nIndex) const
{
	ASSERTVALIDINDEX(nIndex);

	return *(m_aToDoCtrls[nIndex].pTDC);
}

CToDoCtrlMgr::TDCITEM& CToDoCtrlMgr::GetTDCItem(int nIndex)
{
	ASSERTVALIDINDEX(nIndex);

	return m_aToDoCtrls[nIndex];
}

CString CToDoCtrlMgr::GetFilePath(int nIndex)
{
	ASSERTVALIDINDEX(nIndex);

	return GetToDoCtrl(nIndex).GetFilePath();
}

void CToDoCtrlMgr::ClearFilePath(int nIndex)
{
	ASSERTVALIDINDEX(nIndex);

	GetToDoCtrl(nIndex).ClearFilePath();
}

BOOL CToDoCtrlMgr::IsFilePathEmpty(int nIndex)
{
	ASSERTVALIDINDEX(nIndex);

	return GetFilePath(nIndex).IsEmpty();
}

BOOL CToDoCtrlMgr::GetFilePathType(int nIndex)
{
	ASSERTVALIDINDEX(nIndex);

	return GetTDCItem(nIndex).GetPathType();
}

int CToDoCtrlMgr::RefreshPathType(int nIndex) 
{
	ASSERTVALIDINDEX(nIndex);

	TDCITEM& tdci = GetTDCItem(nIndex);

	tdci.RefreshPathType();
	return tdci.nPathType;
}

BOOL CToDoCtrlMgr::RefreshLastModified(int nIndex)
{
	ASSERTVALIDINDEX(nIndex);

	TDCITEM& tdci = GetTDCItem(nIndex);

	time_t timeNow = ::GetLastModified(tdci.pTDC->GetFilePath());
	time_t timePrev = GetTDCItem(nIndex).tLastMod;

	GetTDCItem(nIndex).tLastMod = timeNow;

	return (timeNow > 0 && timePrev > 0 && timeNow != timePrev);
}

BOOL CToDoCtrlMgr::RefreshReadOnlyStatus(int nIndex)
{
	ASSERTVALIDINDEX(nIndex);

	TDCITEM& tdci = GetTDCItem(nIndex);

	BOOL bReadOnlyNow = CDriveInfo::IsReadonlyPath(tdci.pTDC->GetFilePath());
	BOOL bReadOnlyPrev = tdci.bLastStatusReadOnly;

	GetTDCItem(nIndex).bLastStatusReadOnly = bReadOnlyNow;

	return (bReadOnlyNow != -1 && bReadOnlyPrev != -1 && bReadOnlyNow != bReadOnlyPrev);
}

int CToDoCtrlMgr::GetReadOnlyStatus(int nIndex)
{
	ASSERTVALIDINDEX(nIndex);

	return GetTDCItem(nIndex).bLastStatusReadOnly;
}

void CToDoCtrlMgr::SetDueItemStatus(int nIndex, BOOL bDueItems)
{
	ASSERTVALIDINDEX(nIndex);

	GetTDCItem(nIndex).bDueItems = bDueItems;
}

BOOL CToDoCtrlMgr::GetDueItemStatus(int nIndex)
{
	ASSERTVALIDINDEX(nIndex);

	return GetTDCItem(nIndex).bDueItems;
}

int CToDoCtrlMgr::GetLastCheckoutStatus(int nIndex)
{
	ASSERTVALIDINDEX(nIndex);

	return GetTDCItem(nIndex).bLastCheckoutSuccess;
}

void CToDoCtrlMgr::SetLastCheckoutStatus(int nIndex, BOOL bStatus)
{
	ASSERTVALIDINDEX(nIndex);

	GetTDCItem(nIndex).bLastCheckoutSuccess = bStatus;
}

void CToDoCtrlMgr::SetModifiedStatus(int nIndex, BOOL bMod)
{
	ASSERTVALIDINDEX(nIndex);

	GetTDCItem(nIndex).bModified = bMod;
}

BOOL CToDoCtrlMgr::GetModifiedStatus(int nIndex)
{
	ASSERTVALIDINDEX(nIndex);

	return GetTDCItem(nIndex).bModified;
}

void CToDoCtrlMgr::RemoveToDoCtrl(int nIndex)
{
	ASSERTVALIDINDEX(nIndex);

	m_aToDoCtrls.RemoveAt(nIndex);
}

int CToDoCtrlMgr::AddToDoCtrl(CToDoCtrl* pCtrl)
{
	return m_aToDoCtrls.Add(TDCITEM(pCtrl));
}

time_t CToDoCtrlMgr::GetLastModified(int nIndex)
{
	ASSERTVALIDINDEX(nIndex);

	return GetTDCItem(nIndex).tLastMod;
}

void CToDoCtrlMgr::MoveToDoCtrl(int nIndex, int nNumPlaces)
{
	ASSERTVALIDINDEX(nIndex);

	TDCITEM tdci = GetTDCItem(nIndex); // make a copy
	RemoveToDoCtrl(nIndex);

	nIndex += nNumPlaces;
	m_aToDoCtrls.InsertAt(nIndex, tdci);
}

