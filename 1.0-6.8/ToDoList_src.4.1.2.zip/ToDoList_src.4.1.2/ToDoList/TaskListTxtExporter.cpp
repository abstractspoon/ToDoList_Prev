// TaskListTxtExporter.cpp: implementation of the CTaskListTxtExporter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "todolist.h"
#include "TaskListTxtExporter.h"
#include "tdlschemadef.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const LPCTSTR ENDL = "\n";

CTaskListTxtExporter::CTaskListTxtExporter()
{
}

CTaskListTxtExporter::~CTaskListTxtExporter()
{

}

bool CTaskListTxtExporter::Export(const ITaskList* pSrcTaskFile, const char* szDestFilePath)
{
	// what follows is definitely a hack!
	// but that's the joy of programming :)
	INDENT = CString(' ', AfxGetApp()->GetProfileInt("Preferences", "TextIndent", 2));
	TEXTNOTES = AfxGetApp()->GetProfileInt("Preferences", "ExportSpaceForNotes", FALSE) ? 
											"\n\n\n\n\n\n\n\n" : "";
	
	CStdioFile fileOut;

	if (fileOut.Open(szDestFilePath, CFile::modeCreate | CFile::modeWrite))
	{
		CString sOutput;

		if (!ExportTask(pSrcTaskFile, NULL, 0, 0, sOutput).IsEmpty())
		{
			fileOut.WriteString(sOutput);
			return true;
		}
	}

	return false;
}

CString& CTaskListTxtExporter::ExportTask(const ITaskList* pTasks, HTASKITEM hTask, int nDepth, int nPos, CString& sOutput) const
{
	// if depth == 0 then we're at the root so just add sub-tasks
	// else insert pItem first
	if (nDepth > 0)
	{
		// first create string to hold TABs
		CString sTabs;

		for (int nTab = 0; nTab < nDepth; nTab++)
			sTabs += INDENT;

		// if there is a POS child item then this replaces nPos
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKPOS))
			nPos = pTasks->GetTaskPosition(hTask);

		CString sID, sItem, sPriority, sStartDate, sDueDate, sDoneDate;
		CString sAllocTo, sAllocBy, sCategory, sStatus;
		CString sComments, sPercent, sTimeEst, sTimeSpent, sFileRef;
		char cTemp;

		// ID
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKID))
			sID.Format("(ID: %d) ", pTasks->GetTaskID(hTask));

		// title
		CString sTitle(pTasks->GetTaskTitle(hTask));

		// priority, start/due/done dates
		int nPercent = pTasks->GetTaskPercentDone(hTask);
		BOOL bDone = pTasks->IsTaskDone(hTask) || (nPercent == 100);
		BOOL bRound = TRUE;

		if (bDone && pTasks->TaskHasAttribute(hTask, TDL_TASKDONEDATESTRING))
			sDoneDate.Format(" (completed: %s)", pTasks->GetTaskDoneDateString(hTask));
		else
		{
			if (pTasks->TaskHasAttribute(hTask, TDL_TASKPRIORITY))
				sPriority.Format("[%d] ", pTasks->GetTaskPriority(hTask));

			if (pTasks->TaskHasAttribute(hTask, TDL_TASKSTARTDATESTRING))
				sStartDate.Format(" (start: %s)", pTasks->GetTaskStartDateString(hTask));

			if (pTasks->TaskHasAttribute(hTask, TDL_TASKDUEDATESTRING))
				sDueDate.Format(" (due: %s)", pTasks->GetTaskDueDateString(hTask));

			if (pTasks->TaskHasAttribute(hTask, TDL_TASKTIMEESTIMATE))
				sTimeEst.Format(" (time est: %.*f hrs)", bRound ? 0 : 2, pTasks->GetTaskTimeEstimate(hTask, cTemp));

			if (pTasks->TaskHasAttribute(hTask, TDL_TASKTIMESPENT))
				sTimeEst.Format(" (time spent: %.*f hrs)", bRound ? 0 : 2, pTasks->GetTaskTimeSpent(hTask, cTemp));
		}

		if (pTasks->TaskHasAttribute(hTask, TDL_TASKPERCENTDONE))
			sPercent.Format(" (%d%%) ", nPercent);

		// allocated to
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKALLOCTO))
			sAllocTo.Format(" (allocated to: %s)", pTasks->GetTaskAllocatedTo(hTask));
		
		// allocated by
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKALLOCBY))
			sAllocBy.Format(" (allocated by: %s)", pTasks->GetTaskAllocatedBy(hTask));
		
		// category
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKCATEGORY))
			sCategory.Format(" (category: %s)", pTasks->GetTaskCategory(hTask));
		
		// status
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKSTATUS))
			sStatus.Format(" (status: %s)", pTasks->GetTaskStatus(hTask));
		
		// fileref
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKFILEREFPATH))
			sFileRef.Format("%s%s(file ref: %s)", ENDL, sTabs, pTasks->GetTaskFileReferencePath(hTask));
		
		// comments
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKCOMMENTS))
			sComments.Format("%s%s[%s]", ENDL, sTabs, pTasks->GetTaskComments(hTask));

		sItem.Format("%d. %s%s%s%s%s%s%s%s%s%s%s%s%s%s%s", 
					nPos, sID, sPriority, sPercent, sTitle, 
					sAllocTo, sAllocBy, sCategory, sStatus, 
					sDoneDate, sStartDate, sDueDate, sTimeEst, sTimeSpent, sFileRef, sComments, ENDL);

		// notes section
		if (!bDone)
			sItem += TEXTNOTES;

		// indent to match depth
		sOutput += sTabs;
		sOutput += sItem;
	}
	else
	{
		CString sProjectName = pTasks->GetProjectName();

		if (!sProjectName.IsEmpty())
		{
			CString sUnderline('-', sProjectName.GetLength());
			sOutput.Format("%s%s%s%s", sProjectName, ENDL, sUnderline, ENDL);
		}
	}

	// begin new ordered list for sub-tasks
	hTask = pTasks->GetFirstTask(hTask);

	if (hTask) // at least one sub-task
	{
		int nChildPos = 1;

		while (hTask)
		{
			CString sTask;
			sOutput += ENDL;
			sOutput += ExportTask(pTasks, hTask, nDepth + 1, nChildPos++, sTask);

			hTask = pTasks->GetNextTask(hTask);
		}
	}

	// extra line between top level items
	if (nDepth == 1)
		sOutput += ENDL;

	return sOutput;
}

