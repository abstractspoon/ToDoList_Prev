#if !defined(AFX_ORDEREDTREECTRL_H__7E73ADE2_3848_4ED1_9E8B_8881813B4262__INCLUDED_)
#define AFX_ORDEREDTREECTRL_H__7E73ADE2_3848_4ED1_9E8B_8881813B4262__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ToDoCtrl.h : header file
//

#include "..\shared\dragdroptreectrl.h"
#include "..\shared\ncgutter.h"
#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////
// COrderedTreeCtrl window

class COrderedTreeCtrl : public CDragDropTreeCtrl
{
// Construction
public:
	COrderedTreeCtrl();
	virtual ~COrderedTreeCtrl();

	int AddGutterColumn(LPCTSTR szTitle = NULL, UINT nWidth = 0, UINT nTextAlign = DT_LEFT);
	void PressGutterColumnHeader(int nColumn, BOOL bPress = TRUE);
	void SetGutterColumnHeaderTitle(int nColumn, LPCTSTR szTitle);
	void EnableGutterColumnHeaderClicking(int nColumn, BOOL bEnable = TRUE);

	void ShowGutterPosColumn(BOOL bShow = TRUE);

	void RedrawGutter() { m_gutter.Redraw(); }
	void RecalcGutter() { m_gutter.RecalcGutter(); }
	int GetGutterWidth() { return m_gutter.GetGutterWidth(); }

	BOOL HasFocus();

protected:
	CNcGutter m_gutter;
	BOOL m_bShowingPosColumn;

#ifdef _DEBUG
	int m_nNcDrawCount;
#endif

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COrderedTreeCtrl)
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

	// Generated message map functions
protected:
	//{{AFX_MSG(COrderedTreeCtrl)
	//}}AFX_MSG
	afx_msg BOOL OnItemexpanded(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBeginDrag(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg LRESULT OnPostSubclass(WPARAM wParam, LPARAM lParam);
	afx_msg void OnStyleChanged(int nStyleType, LPSTYLESTRUCT lpSS);
	afx_msg BOOL OnClick(NMHDR* pNMHDR, LRESULT* pResult);

	// callbacks for gutter
	afx_msg LRESULT OnGutterGetFirstVisibleTopLevelItem(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterGetNextItem(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterGetFirstChildItem(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterDrawItem(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterPostDrawItem(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterPostNcDraw(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterRecalcColWidth(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterGetItemRect(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterGetSelectedItem(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterSetSelectedItem(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterHitTest(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterNotifyColumnClick(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
	virtual void OnCancelDrop();
	virtual void OnPostDrop();

protected:
	// returns the top level item whose child is the first visible item (or itself)
	DWORD GetFirstVisibleTopLevelItem(int& nPos); // return 0 if no items

	void NcDrawItem(CDC* pDC, DWORD dwItem, DWORD dwParentItem, int nCol, CRect& rItem, int nLevel, 
					int nPos, BOOL bSelected, const CRect& rWindow);
	void PostNcDrawItem(CDC* pDC, DWORD dwItem, const CRect& rItem, int nLevel);
	void PostNcDraw(CDC* pDC, const CRect& rWindow);

	BOOL ShowingEllipsis(int nLevel);
	BOOL RecalcColumnWidth(CDC* pDC, int nCol, int& nWidth);
	int GetGutterWidth(HTREEITEM hti, int nLevel, int nPos, CDC* pDC);
	static int GetWidth(int nNumber, CDC* pDC); // includes a trailing '.'

	inline void EndLabelEdit(BOOL bCancel) { SendMessage(TVM_ENDEDITLABELNOW, bCancel, 0); }


};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ORDEREDTREECTRL_H__7E73ADE2_3848_4ED1_9E8B_8881813B4262__INCLUDED_)
