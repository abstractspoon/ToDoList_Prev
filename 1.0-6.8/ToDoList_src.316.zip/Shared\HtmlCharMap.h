#if !defined(AFX_HTMLCHARMAP_H__7E73ADE2_3848_4ED1_9E8B_8881813B4262__INCLUDED_)
#define AFX_HTMLCHARMAP_H__7E73ADE2_3848_4ED1_9E8B_8881813B4262__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// HtmlCharMap.h: interface and implementation
//
/////////////////////////////////////////////////////////////////////////////////

#include <afxtempl.h>

struct HTMLCHARMAPITEM
{
	unsigned char c; // the character required
	LPCTSTR szHtmlRep; // html representation
};
static HTMLCHARMAPITEM HTMLCHARARRAY[] = 
{
	{ '<', "&lt;" },
	{ '>', "&gt;" },
	{ '\"', "&quot;" },
	{ '\'', "&#39;" },
//	{ '-', "&shy;" },
	{ '�', "&copy;" },
	{ '�', "&reg;" },
	{ 153, "&#153;" },
//	{ '', "&ordm;" },
//	{ '', "&ordf;" },
	{ '�', "&macr;" },
	{ 151, "&#151;" },
	{ 150, "&#150;" },
	{ '�', "&sup1;" },
	{ '�', "&sup2;" },
	{ '�', "&sup3;" },
	{ '�', "&para;" },
	{ '�', "&#183;" },
	{ '�', "&#171;" },
	{ '�', "&#187;" },
	{ '�', "&#188;" },
	{ '�', "&#189;" },
	{ '�', "&#190;" },
	{ '�', "&pound;" },
	{ '�', "&ETH;" },
	{ '�', "&eth;" },
	{ '�', "&szlig;" },
	{ '�', "&thorn;" },
	{ '�', "&Aacute;" },
	{ '�', "&aacute;" },
	{ '�', "&Acirc;" },
	{ '�', "&acirc;" },
	{ '�', "&AElig;" },
	{ '�', "&aelig;" },
	{ '�', "&Agrave;" },
	{ '�', "&agrave;" },
	{ '�', "&Aring;" },
	{ '�', "&aring;" },
	{ '�', "&Atilde;" },
	{ '�', "&atilde;" },
	{ '�', "&Auml;" },
	{ '�', "&auml;" },
	{ '�', "&Ccedil;" },
	{ '�', "&ccedil;" },
	{ '�', "&Eacute;" },
	{ '�', "&eacute;" },
	{ '�', "&Ecirc;" },
	{ '�', "&ecirc;" },
	{ '�', "&Egrave;" },
	{ '�', "&egrave;" },
	{ '�', "&Euml;" },
	{ '�', "&euml;" },
	{ '�', "&Iacute;" },
	{ '�', "&iacute;" },
	{ '�', "&Icirc;" },
	{ '�', "&icirc;" },
	{ '�', "&Igrave;" },
	{ '�', "&igrave;" },
	{ '�', "&Iuml;" },
	{ '�', "&iuml;" },
	{ '�', "&Ntilde;" },
	{ '�', "&ntilde;" },
	{ '�', "&Oacute;" },
	{ '�', "&oacute;" },
	{ '�', "&Ocirc;" },
	{ '�', "&ocirc;" },
	{ '�', "&Ograve;" },
	{ '�', "&ograve;" },
	{ '�', "&Oslash;" },
	{ '�', "&oslash;" },
	{ '�', "&Otilde;" },
	{ '�', "&otilde;" },
	{ '�', "&Ouml;" },
	{ '�', "&ouml;" },
	{ '�', "&Uacute;" },
	{ '�', "&uacute;" },
	{ '�', "&Ucirc;" },
	{ '�', "&ucirc;" },
	{ '�', "&Ugrave;" },
	{ '�', "&ugrave;" },
	{ '�', "&Uuml;" },
	{ '�', "&uuml;" },
	{ '�', "&Yacute;" },
	{ '�', "&yacute;" },
	{ '�', "&yuml;" },
	{ '&', "&amp;" },

};

const INT SIZEOFHTMLCHARARRAY = sizeof(HTMLCHARARRAY) / sizeof(HTMLCHARMAPITEM);

class CHtmlCharMap
{
public:
	static CString& ConvertFromRep(CString& sText)
	{
		CString sResult;

		// look for '&...;' pairs
		int nStart = sText.Find('&', 0);

		while (nStart != -1)
		{
			int nEnd = sText.Find(';', nStart);

			if (nEnd != -1)
			{
				sResult += sText.Left(nStart);

				CString sRep = sText.Mid(nStart, nEnd - nStart + 1);
				Translate(sRep, sResult);

				sText = sText.Mid(nEnd + 1);
				nStart = sText.Find('&', 0);
			}
			else
				break;
		}

		// add whatevers left
		sResult += sText;

		sText = sResult;
		return sText;
	}

	static CString& ConvertToRep(CString& sText)
	{
		CString sResult;

		for (int nChar = 0; nChar < sText.GetLength(); nChar++)
			Translate(sText[nChar], sResult);

		sText = sResult;
		return sText;
	}

protected:
	static void Translate(LPCTSTR szHtmlRep, CString& sAppendTo)
	{
		static CMap<CString, LPCTSTR, unsigned char, unsigned char&> mapHtmlRep;

		// init map once only
		if (!mapHtmlRep.GetCount())
		{
			int nItem = SIZEOFHTMLCHARARRAY;

			while (nItem--)
				mapHtmlRep.SetAt(HTMLCHARARRAY[nItem].szHtmlRep, HTMLCHARARRAY[nItem].c);
		}

		unsigned char c = 0;

		if (mapHtmlRep.Lookup(szHtmlRep, c))
			sAppendTo += c;
		else
			sAppendTo += szHtmlRep;
	}


	static void Translate(unsigned char c, CString& sAppendTo)
	{
		static CMap<unsigned char, unsigned char, CString, LPCTSTR> mapChar;

		// init map once only
		if (!mapChar.GetCount())
		{
			int nItem = SIZEOFHTMLCHARARRAY;

			while (nItem--)
				mapChar.SetAt(HTMLCHARARRAY[nItem].c, HTMLCHARARRAY[nItem].szHtmlRep);
		}

		CString sHtmlRep;

		if (mapChar.Lookup(c, sHtmlRep))
			sAppendTo += sHtmlRep;
		else
			sAppendTo += c;
	}
};


#endif // AFX_HTMLCHARMAP_H__7E73ADE2_3848_4ED1_9E8B_8881813B4262__INCLUDED_
