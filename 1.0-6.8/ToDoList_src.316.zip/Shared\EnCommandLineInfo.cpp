// EnCommandLineInfo.cpp: implementation of the CEnCommandLineInfo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "EnCommandLineInfo.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEnCommandLineInfo::CEnCommandLineInfo()
{
	m_nLastParameter = -1;		
}

CEnCommandLineInfo::~CEnCommandLineInfo()
{

}

void CEnCommandLineInfo::ParseParam(LPCTSTR lpszParam, BOOL bFlag, BOOL bLast)
{
	CString sLookup;

	if (bFlag) 
	{
		m_sLastOption = lpszParam; 	   // save in case other value specified
		m_sLastOption.MakeUpper();

		// this is a "flag" (begins with / or -)
		m_mapCommandLine[m_sLastOption] = "";    // default value is "TRUE"
		m_nLastParameter = -1;		
	} 
	else // must be a parameter for the last option
	{
		m_nLastParameter++;

		sLookup.Format("%s_PARAMETER_%d", m_sLastOption, m_nLastParameter);
		m_mapCommandLine[sLookup] = lpszParam;
	}
	
	// Call base class so MFC can see this param/token.
	CCommandLineInfo::ParseParam(lpszParam, bFlag, bLast);
}

BOOL CEnCommandLineInfo::GetOption(LPCTSTR szFlag, CStringArray* pParams)
{
	CString sFlag(szFlag), sLookup, sParameter;
	sFlag.MakeUpper();

	if (!m_mapCommandLine.Lookup(sFlag, CString()))
		return FALSE;

	if (pParams)
	{
		pParams->RemoveAll();

		int nParam = 0;
		sLookup.Format("%s_PARAMETER_%d", sFlag, nParam);

		while (m_mapCommandLine.Lookup(sLookup, sParameter))
		{
			pParams->Add(sParameter);

			nParam++;
			sLookup.Format("%s_PARAMETER_%d", sFlag, nParam);
		}
	}

	return TRUE;
}

