// ToDoListDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ToDoList.h"
#include "ToDoListDlg.h"
#include "ToolsCmdlineParser.h"
#include "ToolsUserInputDlg.h"
#include "Toolshelper.h"
#include "exportDlg.h"

#include "..\shared\aboutdlg.h"
#include "..\shared\holdredraw.h"
#include "..\shared\autoflag.h"
#include "..\shared\deferWndMove.h"
#include "..\shared\enbitmap.h"
#include "..\shared\spellcheckdlg.h"
#include "..\shared\encolordialog.h"
#include "..\shared\winclasses.h"
#include "..\shared\datehelper.h"
#include "..\shared\osversion.h"

#include "..\3rdparty\gui.h"

#ifdef _AFXDLL
#  define COMPILE_MULTIMON_STUBS
#endif

#include <multimon.h>
#include <afxpriv.h>        // for WM_KICKIDLE

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CToDoListDlg dialog

// popup menus
enum { FILEALL, NEWTASK, EDITTASK, VIEW, MOVE, SORT, DELETETASK, TOOLS, HELP };
enum { TRAYICON, TASKCONTEXT, TABCTRL };
enum { SAVEASXML, SAVEASHTM, SAVEASTXT };
enum { IM_NONE = -1, IM_READONLY, IM_CHECKEDIN, IM_CHECKEDOUT };
enum { TB_TOOLBARHIDDEN, TB_TOOLBARONLY, TB_TOOLBARANDMENU };
enum { LOAD_CANCELLED, LOAD_FAILED, LOAD_SUCCESS };

const LPCTSTR SAVEASXMLFILTER = "Task Lists (*.xml)|*.xml||";
const LPCTSTR SAVEASHTMFILTER = "Web Pages (*.htm, *.html)|*.htm;*.html||";
const LPCTSTR SAVEASTXTFILTER = "Plain Text (*.txt)|*.txt||";
const int TD_VERSION = 31000;

enum 
{
	TIMER_READONLYSTATUS = 1,
	TIMER_TIMESTAMPCHANGE,
	TIMER_AUTOSAVE,
	TIMER_CHECKOUTSTATUS,
	TIMER_DUEITEMS,
};

enum 
{
	INTERVAL_READONLYSTATUS = 1000,
	INTERVAL_TIMESTAMPCHANGE = 10000,
//	INTERVAL_AUTOSAVE, // dynamically determined
	INTERVAL_CHECKOUTSTATUS = 5000,
	INTERVAL_DUEITEMS = 60000,
};

CToDoListDlg::CToDoListDlg() : CDialog(IDD_TODOLIST_DIALOG), 
		m_bVisible(-1), 
		m_mruList(0, "MRU", "TaskList%d", 16, AFX_ABBREV_FILENAME_LEN, "Recent Tasklists"),
		m_nLastSelItem(-1),
		m_bSimpleMode(FALSE),
		m_stFilePath(TRUE),
		m_bInNewTask(FALSE),
		m_bSaving(FALSE),
		m_bInTimer(FALSE),
		m_mgrShortcuts(FALSE),
		m_nToolbarOption(-1),
		m_pPrefs(NULL),
		m_bClosing(FALSE)
{
	//{{AFX_DATA_INIT(CToDoListDlg)
	//}}AFX_DATA_INIT

	// load app icon
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	if (COSVersion() >= OSV_XP)
	{
		// except under XP icons can look right shoddy
		m_hIcon = AfxGetApp()->LoadIcon(IDI_MAINFRAMEXP);
	}
	else
		m_hIcon = AfxGetApp()->LoadIcon(IDI_MAINFRAME);

	// init preferences
	ResetPrefs();
}

CToDoListDlg::~CToDoListDlg()
{
	delete m_pPrefs;
}

void CToDoListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CToDoListDlg)
	DDX_Control(pDX, IDC_TABCONTROL, m_tabCtrl);
	DDX_Control(pDX, IDC_FILENAME, m_stFilePath);
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_FILENAME, m_sStatus);
}

BEGIN_MESSAGE_MAP(CToDoListDlg, CDialog)
	//{{AFX_MSG_MAP(CToDoListDlg)
	ON_COMMAND(ID_VIEW_EXPANDTASK, OnViewExpandtask)
	ON_UPDATE_COMMAND_UI(ID_VIEW_EXPANDTASK, OnUpdateViewExpandtask)
	ON_COMMAND(ID_VIEW_COLLAPSETASK, OnViewCollapsetask)
	ON_UPDATE_COMMAND_UI(ID_VIEW_COLLAPSETASK, OnUpdateViewCollapsetask)
	ON_COMMAND(ID_VIEW_COLLAPSEALL, OnViewCollapseall)
	ON_COMMAND(ID_VIEW_EXPANDALL, OnViewExpandall)
	ON_UPDATE_COMMAND_UI(ID_VIEW_EXPANDALL, OnUpdateViewExpandall)
	ON_UPDATE_COMMAND_UI(ID_VIEW_COLLAPSEALL, OnUpdateViewCollapseall)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_VIEW_NEXT, OnViewNext)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NEXT, OnUpdateViewNext)
	ON_COMMAND(ID_VIEW_PREV, OnViewPrev)
	ON_UPDATE_COMMAND_UI(ID_VIEW_PREV, OnUpdateViewPrev)
	ON_WM_SYSCOMMAND()
	ON_UPDATE_COMMAND_UI(ID_IMPORT_TASKLIST, OnUpdateImport)
	ON_UPDATE_COMMAND_UI(ID_NEWTASK, OnUpdateNewtask)
	ON_COMMAND(ID_TOOLS_CHECKOUT, OnToolsCheckout)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_CHECKOUT, OnUpdateToolsCheckout)
	ON_COMMAND(ID_TOOLS_CHECKIN, OnToolsCheckin)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_CHECKIN, OnUpdateToolsCheckin)
	ON_COMMAND(ID_TOOLS_TOGGLECHECKIN, OnToolsToggleCheckin)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_TOGGLECHECKIN, OnUpdateToolsToggleCheckin)
	ON_COMMAND(ID_TOOLS_EXPORT, OnExport)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_EXPORT, OnUpdateExport)
	ON_COMMAND(ID_NEXTTOPLEVELTASK, OnNexttopleveltask)
	ON_COMMAND(ID_PREVTOPLEVELTASK, OnPrevtopleveltask)
	ON_UPDATE_COMMAND_UI(ID_NEXTTOPLEVELTASK, OnUpdateNexttopleveltask)
	ON_UPDATE_COMMAND_UI(ID_PREVTOPLEVELTASK, OnUpdatePrevtopleveltask)
	ON_COMMAND(ID_EDIT_FINDTASKS, OnFindTasks)
	ON_COMMAND(ID_VIEW_MOVETASKLISTRIGHT, OnViewMovetasklistright)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MOVETASKLISTRIGHT, OnUpdateViewMovetasklistright)
	ON_COMMAND(ID_VIEW_MOVETASKLISTLEFT, OnViewMovetasklistleft)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MOVETASKLISTLEFT, OnUpdateViewMovetasklistleft)
	ON_COMMAND(ID_VIEW_MENUONLY, OnViewMenuonly)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MENUONLY, OnUpdateViewMenuonly)
	ON_COMMAND(ID_VIEW_TOOLBARANDMENU, OnViewToolbarandmenu)
	ON_UPDATE_COMMAND_UI(ID_VIEW_TOOLBARANDMENU, OnUpdateViewToolbarandmenu)
	ON_COMMAND(ID_VIEW_TOOLBARONLY, OnViewToolbaronly)
	ON_UPDATE_COMMAND_UI(ID_VIEW_TOOLBARONLY, OnUpdateViewToolbaronly)
	ON_COMMAND(ID_SORT, OnSort)
	ON_UPDATE_COMMAND_UI(ID_SORT, OnUpdateSort)
	ON_COMMAND(ID_NEWTASK_ATTOP, OnNewtaskAttop)
	ON_UPDATE_COMMAND_UI(ID_NEWTASK_ATTOP, OnUpdateNewtaskAttop)
	ON_COMMAND(ID_NEWTASK_ATBOTTOM, OnNewtaskAtbottom)
	ON_UPDATE_COMMAND_UI(ID_NEWTASK_ATBOTTOM, OnUpdateNewtaskAtbottom)
	ON_COMMAND(ID_EDIT_SPELLCHECKCOMMENTS, OnSpellcheckcomments)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SPELLCHECKCOMMENTS, OnUpdateSpellcheckcomments)
	ON_COMMAND(ID_EDIT_SPELLCHECKTITLE, OnSpellchecktitle)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SPELLCHECKTITLE, OnUpdateSpellchecktitle)
	ON_COMMAND(ID_FILE_ENCRYPT, OnFileEncrypt)
	ON_UPDATE_COMMAND_UI(ID_FILE_ENCRYPT, OnUpdateFileEncrypt)
	ON_COMMAND(ID_FILE_RESETVERSION, OnFileResetversion)
	ON_UPDATE_COMMAND_UI(ID_FILE_RESETVERSION, OnUpdateFileResetversion)
	ON_COMMAND(ID_TOOLS_SPELLCHECKTASKLIST, OnSpellcheckTasklist)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_SPELLCHECKTASKLIST, OnUpdateSpellcheckTasklist)
	ON_COMMAND(ID_EDIT_PASTEAFTER, OnEditPasteAfter)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTEAFTER, OnUpdateEditPasteAfter)
	ON_COMMAND(ID_EDIT_CLOCK_TASK, OnEditTimeTrackTask)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CLOCK_TASK, OnUpdateEditTimeTrackTask)
	ON_WM_DRAWITEM()
	ON_COMMAND(ID_VIEW_NEXT_SEL, OnViewNextSel)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NEXT_SEL, OnUpdateViewNextSel)
	ON_COMMAND(ID_VIEW_PREV_SEL, OnViewPrevSel)
	ON_UPDATE_COMMAND_UI(ID_VIEW_PREV_SEL, OnUpdateViewPrevSel)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CUT, OnUpdateEditCut)
	ON_COMMAND_RANGE(ID_NEWTASK_SPLITTASKINTO_TWO, ID_NEWTASK_SPLITTASKINTO_FIVE, OnSplitTaskIntoPieces)
	ON_UPDATE_COMMAND_UI_RANGE(ID_NEWTASK_SPLITTASKINTO_TWO, ID_NEWTASK_SPLITTASKINTO_FIVE, OnUpdateSplitTaskIntoPieces)
	ON_COMMAND_RANGE(ID_TOOLS_SHOWTASKS_DUETODAY, ID_TOOLS_SHOWTASKS_DUEENDNEXTMONTH, OnToolsShowtasksDue)
	ON_COMMAND(ID_DELETETASK, OnDeleteTask)
	ON_COMMAND(ID_DELETEALLTASKS, OnDeleteAllTasks)
	ON_WM_SIZE()
	ON_WM_GETMINMAXINFO()
	ON_COMMAND(ID_SAVE_NORMAL, OnSave)
	ON_COMMAND(ID_LOAD_NORMAL, OnLoad)
	ON_WM_DESTROY()
	ON_COMMAND(ID_NEW, OnNew)
	ON_UPDATE_COMMAND_UI(ID_DELETETASK, OnUpdateDeletetask)
	ON_UPDATE_COMMAND_UI(ID_EDIT_TASKCOLOR, OnUpdateTaskcolor)
	ON_UPDATE_COMMAND_UI(ID_EDIT_TASKDONE, OnUpdateTaskdone)
	ON_UPDATE_COMMAND_UI(ID_DELETEALLTASKS, OnUpdateDeletealltasks)
	ON_UPDATE_COMMAND_UI(ID_SAVE_NORMAL, OnUpdateSave)
	ON_UPDATE_COMMAND_UI(ID_NEW, OnUpdateNew)
	ON_WM_ERASEBKGND()
	ON_COMMAND(ID_NEWTASK_ATTOPSELECTED, OnNewtaskAttopSelected)
	ON_COMMAND(ID_NEWTASK_ATBOTTOMSELECTED, OnNewtaskAtbottomSelected)
	ON_COMMAND(ID_NEWTASK_AFTERSELECTEDTASK, OnNewtaskAfterselectedtask)
	ON_COMMAND(ID_NEWTASK_BEFORESELECTEDTASK, OnNewtaskBeforeselectedtask)
	ON_UPDATE_COMMAND_UI(ID_SORT, OnUpdateSort)
	ON_COMMAND(ID_NEWSUBTASK_ATBOTTOM, OnNewsubtaskAtbottom)
	ON_COMMAND(ID_NEWSUBTASK_ATTOP, OnNewsubtaskAttop)
	ON_COMMAND(ID_EDIT_TASKCOLOR, OnEditTaskcolor)
	ON_COMMAND(ID_EDIT_TASKDONE, OnEditTaskdone)
	ON_COMMAND(ID_EDIT_TASKTEXT, OnEditTasktext)
	ON_COMMAND(ID_MOVETASKDOWN, OnMovetaskdown)
	ON_UPDATE_COMMAND_UI(ID_MOVETASKDOWN, OnUpdateMovetaskdown)
	ON_COMMAND(ID_MOVETASKUP, OnMovetaskup)
	ON_UPDATE_COMMAND_UI(ID_MOVETASKUP, OnUpdateMovetaskup)
	ON_WM_CLOSE()
	ON_COMMAND(ID_TRAYICON_CLOSE, OnTrayiconClose)
	ON_WM_WINDOWPOSCHANGING()
	ON_UPDATE_COMMAND_UI(ID_NEWSUBTASK_ATBOTTOM, OnUpdateNewsubtaskAtBottom)
	ON_COMMAND(ID_SAVEAS, OnSaveas)
	ON_UPDATE_COMMAND_UI(ID_SAVEAS, OnUpdateSaveas)
	ON_WM_CONTEXTMENU()
	ON_WM_GETDLGCODE()
	ON_COMMAND(ID_TRAYICON_SHOW, OnTrayiconShow)
	ON_WM_QUERYENDSESSION()
	ON_UPDATE_COMMAND_UI(ID_FILE_MRU_FILE1, OnUpdateRecentFileMenu)
	ON_COMMAND(ID_ABOUT, OnAbout)
	ON_COMMAND(ID_PREFERENCES, OnPreferences)
	ON_WM_COPYDATA()
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_PASTESUB, OnEditPasteSub)
	ON_COMMAND(ID_EDIT_COPYASTEXT, OnEditCopyastext)
	ON_COMMAND(ID_EDIT_COPYASHTML, OnEditCopyashtml)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTESUB, OnUpdateEditPasteSub)
	ON_UPDATE_COMMAND_UI(ID_NEWTASK_ATTOPSELECTED, OnUpdateNewtaskAttopSelected)
	ON_UPDATE_COMMAND_UI(ID_NEWTASK_ATBOTTOMSELECTED, OnUpdateNewtaskAtbottomSelected)
	ON_UPDATE_COMMAND_UI(ID_NEWTASK_AFTERSELECTEDTASK, OnUpdateNewtaskAfterselectedtask)
	ON_UPDATE_COMMAND_UI(ID_NEWTASK_BEFORESELECTEDTASK, OnUpdateNewtaskBeforeselectedtask)
	ON_UPDATE_COMMAND_UI(ID_NEWSUBTASK_ATTOP, OnUpdateNewsubtaskAttop)
	ON_COMMAND(ID_SIMPLEMODE, OnSimplemode)
	ON_UPDATE_COMMAND_UI(ID_SIMPLEMODE, OnUpdateSimplemode)
	ON_COMMAND(ID_OPEN_RELOAD, OnReload)
	ON_UPDATE_COMMAND_UI(ID_OPEN_RELOAD, OnUpdateReload)
	ON_COMMAND(ID_ARCHIVE_COMPLETEDTASKS, OnArchiveCompletedtasks)
	ON_UPDATE_COMMAND_UI(ID_ARCHIVE_COMPLETEDTASKS, OnUpdateArchiveCompletedtasks)
	ON_COMMAND(ID_TOOLS_EXPORTTOHTML, OnExportTohtml)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_EXPORTTOHTML, OnUpdateExportTohtml)
	ON_COMMAND(ID_TOOLS_EXPORTTOPLAINTEXT, OnExportToplaintext)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_EXPORTTOPLAINTEXT, OnUpdateExportToplaintext)
	ON_COMMAND(ID_PRINT, OnPrint)
	ON_UPDATE_COMMAND_UI(ID_PRINT, OnUpdatePrint)
	ON_COMMAND(ID_MOVETASKRIGHT, OnMovetaskright)
	ON_UPDATE_COMMAND_UI(ID_MOVETASKRIGHT, OnUpdateMovetaskright)
	ON_COMMAND(ID_MOVETASKLEFT, OnMovetaskleft)
	ON_UPDATE_COMMAND_UI(ID_MOVETASKLEFT, OnUpdateMovetaskleft)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TABCONTROL, OnSelchangeTabcontrol)
	ON_NOTIFY(TCN_SELCHANGING, IDC_TABCONTROL, OnSelchangingTabcontrol)
	ON_COMMAND(ID_CLOSE, OnCloseTasklist)
	ON_COMMAND(ID_SAVEALL, OnSaveall)
	ON_UPDATE_COMMAND_UI(ID_SAVEALL, OnUpdateSaveall)
	ON_COMMAND(ID_CLOSEALL, OnCloseall)
	ON_UPDATE_COMMAND_UI(ID_CLOSEALL, OnUpdateCloseall)
	ON_COMMAND(ID_EXIT, OnExit)
	ON_UPDATE_COMMAND_UI(ID_EXIT, OnUpdateExit)
	ON_UPDATE_COMMAND_UI(ID_MOVETASK, OnUpdateMovetask)
	ON_WM_TIMER()
	ON_COMMAND(ID_IMPORT_TASKLIST, OnImportTasklist)
	ON_COMMAND_RANGE(ID_SORT_BYDONEDATE, ID_SORT_NONE, OnSortBy)
	ON_UPDATE_COMMAND_UI_RANGE(ID_SORT_BYDONEDATE, ID_SORT_NONE, OnUpdateSortBy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_TASKTEXT, OnUpdateEditTasktext)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
	ON_COMMAND(ID_TRAYICON_CREATETASK, OnTrayiconCreatetask)
	ON_COMMAND_RANGE(ID_EDIT_SETPRIORITY0, ID_EDIT_SETPRIORITY10, OnSetPriority)
	ON_UPDATE_COMMAND_UI_RANGE(ID_EDIT_SETPRIORITY0, ID_EDIT_SETPRIORITY10, OnUpdateSetPriority)
	ON_COMMAND(ID_EDIT_SETFILEREF, OnEditSetfileref)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SETFILEREF, OnUpdateEditSetfileref)
	ON_COMMAND(ID_EDIT_OPENFILEREF, OnEditOpenfileref)
	ON_UPDATE_COMMAND_UI(ID_EDIT_OPENFILEREF, OnUpdateEditOpenfileref)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPYASHTML, OnUpdateEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPYASTEXT, OnUpdateEditCopy)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_USERTOOL1, OnUpdateUserTool1)
	ON_COMMAND_RANGE(ID_TOOLS_USERTOOL1, ID_TOOLS_USERTOOL16, OnUserTool)
	ON_WM_INITMENUPOPUP()
	ON_NOTIFY(NM_CLICK, IDC_TRAYICON, OnTrayIconClick)
	ON_NOTIFY(NM_DBLCLK, IDC_TRAYICON, OnTrayIconDblClk)
	ON_NOTIFY(NM_RCLICK, IDC_TRAYICON, OnTrayIconRClick)
	ON_REGISTERED_MESSAGE(WM_TDCN_SORT, OnToDoCtrlNotifySort)
	ON_REGISTERED_MESSAGE(WM_TDCN_MODIFY, OnToDoCtrlNotifyMod)
	ON_REGISTERED_MESSAGE(WM_TDCN_MINWIDTHCHANGE, OnToDoCtrlNotifyMinWidthChange)
	ON_REGISTERED_MESSAGE(WM_TDL_SHOWWINDOW , OnToDoListShowWindow)
	ON_REGISTERED_MESSAGE(WM_TDL_GETVERSION , OnToDoListGetVersion)
	ON_COMMAND_EX_RANGE(ID_FILE_MRU_FILE1, ID_FILE_MRU_FILE16, OnOpenRecentFile)
	ON_REGISTERED_MESSAGE(WM_FTD_FIND, OnFindDlgFind)
	ON_REGISTERED_MESSAGE(WM_FTD_SELECTRESULT, OnFindSelectResult)
	ON_REGISTERED_MESSAGE(WM_FTD_SELECTALL, OnFindSelectAll)
	ON_REGISTERED_MESSAGE(WM_TLDT_DROPFILE, OnDropFile)
	ON_REGISTERED_MESSAGE(WM_PTP_TESTTOOL, OnPreferencesTestTool)
	ON_MESSAGE(WM_GETICON, OnGetIcon)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CToDoListDlg message handlers

BOOL CToDoListDlg::Create(BOOL bForceVisible, LPCTSTR szTDListPath)
{
 	m_sCmdLineFilePath = szTDListPath;
	m_bVisible = bForceVisible ? 1 : -1;
	
	return CDialog::Create(IDD_TODOLIST_DIALOG);
}

int CToDoListDlg::GetVersion()
{
	return TD_VERSION;
}

BOOL CToDoListDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// drop target
	m_dropTarget.Register(this, this);

	// shortcut manager
	if (m_mgrShortcuts.Initialize())
	{
		if (m_mgrShortcuts.IsEmpty()) // defaults
		{
			m_mgrShortcuts.AddShortcut(ID_LOAD_NORMAL, 'O', HOTKEYF_CONTROL);
			m_mgrShortcuts.AddShortcut(ID_OPEN_RELOAD, 'O', HOTKEYF_CONTROL | HOTKEYF_SHIFT);
			m_mgrShortcuts.AddShortcut(ID_SAVE_NORMAL, 'S', HOTKEYF_CONTROL);
			m_mgrShortcuts.AddShortcut(ID_IMPORT_TASKLIST, 'I', HOTKEYF_CONTROL);
			m_mgrShortcuts.AddShortcut(ID_NEWTASK_BEFORESELECTEDTASK, 'N', HOTKEYF_CONTROL);
			m_mgrShortcuts.AddShortcut(ID_NEWSUBTASK_ATTOP, 'N', HOTKEYF_CONTROL | HOTKEYF_SHIFT);
			m_mgrShortcuts.AddShortcut(ID_NEWTASK_AFTERSELECTEDTASK, 'N', HOTKEYF_CONTROL | HOTKEYF_ALT);
			m_mgrShortcuts.AddShortcut(ID_SIMPLEMODE, 'M', HOTKEYF_CONTROL);
			m_mgrShortcuts.AddShortcut(ID_PRINT, 'P', HOTKEYF_CONTROL);
			m_mgrShortcuts.AddShortcut(ID_VIEW_NEXT, VK_TAB, HOTKEYF_CONTROL);
			m_mgrShortcuts.AddShortcut(ID_VIEW_PREV, VK_TAB, HOTKEYF_CONTROL | HOTKEYF_SHIFT);
			m_mgrShortcuts.AddShortcut(ID_EDIT_COPY, 'C', HOTKEYF_CONTROL);
			m_mgrShortcuts.AddShortcut(ID_EDIT_PASTE, 'V', HOTKEYF_CONTROL);
			m_mgrShortcuts.AddShortcut(ID_EDIT_OPENFILEREF, 'G', HOTKEYF_CONTROL);
			m_mgrShortcuts.AddShortcut(ID_EXIT, VK_F4, HOTKEYF_ALT);
			m_mgrShortcuts.AddShortcut(ID_CLOSE, 'C', HOTKEYF_CONTROL | HOTKEYF_ALT);
			m_mgrShortcuts.AddShortcut(ID_MOVETASKDOWN, VK_DOWN, HOTKEYF_CONTROL | HOTKEYF_EXT);
			m_mgrShortcuts.AddShortcut(ID_MOVETASKUP, VK_UP, HOTKEYF_CONTROL | HOTKEYF_EXT);
			m_mgrShortcuts.AddShortcut(ID_MOVETASKLEFT, VK_LEFT, HOTKEYF_CONTROL | HOTKEYF_EXT);
			m_mgrShortcuts.AddShortcut(ID_MOVETASKRIGHT, VK_RIGHT, HOTKEYF_CONTROL | HOTKEYF_EXT);
			m_mgrShortcuts.AddShortcut(ID_DELETETASK, VK_DELETE, HOTKEYF_EXT);
			m_mgrShortcuts.AddShortcut(ID_EDIT_TASKTEXT, VK_F2, 0);
			m_mgrShortcuts.AddShortcut(ID_EDIT_TASKDONE, VK_SPACE, 0);
			m_mgrShortcuts.AddShortcut(ID_TOOLS_EXPORT, 'E', HOTKEYF_CONTROL);
			m_mgrShortcuts.AddShortcut(ID_HELP, VK_F1, 0);
			m_mgrShortcuts.AddShortcut(ID_VIEW_TOOLBARANDMENU, 'M', HOTKEYF_CONTROL | HOTKEYF_ALT | HOTKEYF_SHIFT);
		}

		// fix for adding escape key as a shortcur for IDCLOSE (big mistake)
		if (m_mgrShortcuts.GetShortcut(IDCLOSE) == VK_ESCAPE)
			m_mgrShortcuts.DeleteShortcut(IDCLOSE);
	}

	// trayicon
	// we always create the trayicon (for simplicity) but we only
	// show it if required
	BOOL bUseSysTray = Prefs().GetUseSysTray();
	UINT nIDTrayIcon = (COSVersion() >= OSV_XP) ? IDI_MAINFRAMEXP : IDI_TRAYICON;

	m_ti.Create(WS_CHILD | (bUseSysTray ? WS_VISIBLE : 0), this, IDC_TRAYICON, nIDTrayIcon, 
				"ToDoList � AbstractSpoon 2003-05");

	// toolbar
	InitToolbar();

	// tabctrl
	BOOL bStackTabbar = Prefs().GetStackTabbarItems();

	m_tabCtrl.ModifyStyle(bStackTabbar ? 0 : TCS_MULTILINE, bStackTabbar ? TCS_MULTILINE : 0);
	UpdateTabSwitchTooltip();

	if (m_ilTabCtrl.Create(IDB_SOURCECONTROL, 16, 1, RGB(0, 255, 0)))
		m_tabCtrl.SetImageList(&m_ilTabCtrl);

	// statusbar font
	::SendMessage(m_stFilePath, WM_SETFONT, (WPARAM)GetStockObject(DEFAULT_GUI_FONT), 0);

	// open cmdline tasklist
	if (!m_sCmdLineFilePath.IsEmpty() && ::GetFileAttributes(m_sCmdLineFilePath) != 0xffffffff)
		OpenTaskList(m_sCmdLineFilePath);

	m_sCmdLineFilePath.IsEmpty();

	LoadSettings();

	// due items timer
	SetTimer(TIMER_DUEITEMS, TRUE);

	GetToDoCtrl().SetFocus();

	return FALSE;  // return TRUE  unless you set the focus to a control
}

LRESULT CToDoListDlg::OnGetIcon(WPARAM bLargeIcon, LPARAM /*not used*/)
{
	return (LRESULT)m_hIcon;
}

BOOL CToDoListDlg::InitToolbar()
{
	if (!m_toolbar.GetSafeHwnd())
	{
		UINT nIDToolbarImage = Prefs().GetLargeToolbarIcons() ? IDB_TOOLBAR24 : IDB_TOOLBAR16;

		VERIFY (m_toolbar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_ALIGN_TOP)
				&& m_toolbar.LoadToolBar(IDR_TOOLBAR, nIDToolbarImage));

		// very important - turn OFF all the auto positioning and sizing
		// by default have no borders
		UINT nStyle = m_toolbar.GetBarStyle();
		nStyle &= ~(CCS_NORESIZE | CCS_NOPARENTALIGN | CBRS_BORDER_ANY);
		nStyle |= (CBRS_SIZE_FIXED | CBRS_TOOLTIPS | CBRS_FLYBY);
		m_toolbar.SetBarStyle(nStyle);

		// toolbar
		int nTBOption = AfxGetApp()->GetProfileInt("Settings", "ToolbarOption", TB_TOOLBARANDMENU);

		switch (nTBOption)
		{
		case TB_TOOLBARONLY:
			PostMessage(WM_COMMAND, ID_VIEW_TOOLBARONLY, (LPARAM)GetSafeHwnd());
			break;

		case TB_TOOLBARANDMENU:
			PostMessage(WM_COMMAND, ID_VIEW_TOOLBARANDMENU, (LPARAM)GetSafeHwnd());
			break;

		case TB_TOOLBARHIDDEN:
			PostMessage(WM_COMMAND, ID_VIEW_MENUONLY, (LPARAM)GetSafeHwnd());
			break;
		}

		m_toolbar.GetToolBarCtrl().HideButton(ID_TOOLS_TOGGLECHECKIN, !Prefs().GetEnableSourceControl());
	}

	return (NULL != m_toolbar.GetSafeHwnd());
}

BOOL CToDoListDlg::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN)
		int a = 5;

	UINT nCmdID = m_mgrShortcuts.ProcessMessage(pMsg);
	
	if (nCmdID)
	{
		BOOL bSendMessage = TRUE; // default

		switch (nCmdID)
		{
			case ID_EDIT_COPY:
				// tree must have the focus
				if (!GetToDoCtrl().TreeHasFocus())
				{
					bSendMessage = FALSE;
					GetToDoCtrl().ClearCopiedItem();
				}
				break;

			case ID_EDIT_PASTE: // tree must have the focus
				bSendMessage = GetToDoCtrl().TreeHasFocus();
				break;
		}

		if (bSendMessage)
		{
			SendMessage(WM_COMMAND, nCmdID);
			return TRUE;
		}
	}

	// try toolbar helper
	if (m_tbHelper.ProcessMessage(pMsg))
		return TRUE;

	// try active task list
	if (GetTDCCount() && GetToDoCtrl().PreTranslateMessage(pMsg))
		return TRUE;

	// don't pass on mouse moves else tooltips don't work (??)
	if (pMsg->message == WM_MOUSEMOVE)
		return FALSE;
	
	// else
	return CDialog::PreTranslateMessage(pMsg);
}

void CToDoListDlg::OnCancel()
{
	// if the close button has been configured to Minimize to tray
	// then do that here else normal minimize 
	int nOption = Prefs().GetSysTrayOption();

	if (nOption == STO_ONMINCLOSE || nOption == STO_ONCLOSE)
		MinimizeToTray(Prefs().GetAutoSaveOnSysTray());

	else
		SendMessage(WM_SYSCOMMAND, SC_MINIMIZE, 0);
}

void CToDoListDlg::OnDeleteTask() 
{
	if (GetToDoCtrl().GetSelectedItem())
		GetToDoCtrl().DeleteSelectedTask();
}

void CToDoListDlg::OnDeleteAllTasks() 
{
	if (GetToDoCtrl().DeleteAllTasks())
	{
		GetTDCItem().GetFilePath().Empty(); // this will ensure that the user must explicitly overwrite the original file
		UpdateStatusbar();
	}
}

void CToDoListDlg::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);

	BOOL bMaximized = (nType == SIZE_MAXIMIZED);
	
	if (nType != SIZE_MINIMIZED)
		ResizeDlg(cx, cy, bMaximized);

	m_stFilePath.EnableGripper(!bMaximized);

	// special maximize bugfix for dual-head video cards like the geforce2
	// TODO

	// if not maximized then set topmost if that's the preference
	BOOL bTopMost = (Prefs().GetAlwaysOnTop() && !bMaximized);

	SetWindowPos(bTopMost ? &wndTopMost : &wndNoTopMost, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
}

void CToDoListDlg::ResizeDlg(int cx, int cy, BOOL bMaximized)
{
	if (GetTDCCount() && GetToDoCtrl().GetSafeHwnd())
	{
		if (!cx && !cy)
		{
			CRect rClient;
			GetClientRect(rClient);

			cx = rClient.right;
			cy = rClient.bottom;
			bMaximized = IsZoomed();

			// check again 
			if (!cx && !cy)
				return;
		}

		// resize in one go
		CDeferWndMove dwm(6);
		CRect rTaskList(0, 0, cx, cy);

		// resize toolbar regardless
		CRect rToolbar = OffsetCtrl(AFX_IDW_TOOLBAR);

		rToolbar.right = cx;
		rToolbar.top = GetDlgItem(IDC_HORZDIVIDERTOP)->IsWindowVisible() ? 3 : 0;
		rToolbar.bottom = rToolbar.top + HIWORD(m_toolbar.GetToolBarCtrl().GetButtonSize()) + 2;

		dwm.MoveWindow(&m_toolbar, rToolbar);

		if (m_nToolbarOption != TB_TOOLBARHIDDEN) // showing toolbar
			rTaskList.top = rToolbar.bottom;

		// resize and pos divider
		CRect rDivider(0, rTaskList.top, cx, rTaskList.top + 2);
		rTaskList.top = rDivider.bottom + 1;

		dwm.ResizeCtrl(this, IDC_HORZDIVIDERTOP, cx - OffsetCtrl(IDC_HORZDIVIDER).Width());
		dwm.MoveWindow(GetDlgItem(IDC_HORZDIVIDERBOTTOM), rDivider);

		// resize tabctrl
		CRect rTabs(0, 0, cx, 0);
		m_tabCtrl.AdjustRect(TRUE, rTabs);
		int nTabHeight = rTabs.Height() - 5;

		rTabs = OffsetCtrl(IDC_TABCONTROL); // not actually a move
		rTabs.right = cx + 1;
		rTabs.bottom = rTabs.top + nTabHeight;

		rTabs.OffsetRect(0, rTaskList.top - rTabs.top);

		dwm.MoveWindow(&m_tabCtrl, rTabs);//, FALSE);

		// hide and disable tabctrl if not needed
		BOOL bNeedTabCtrl = (GetTDCCount() > 1 || !Prefs().GetAutoHideTabbar());

		m_tabCtrl.ShowWindow(bNeedTabCtrl ? SW_SHOW : SW_HIDE);
		m_tabCtrl.EnableWindow(bNeedTabCtrl);

		if (bNeedTabCtrl)
			rTaskList.top = rTabs.bottom; // hide the bottom of the tab ctrl

		// resize filepath static
		CRect rFilePath = OffsetCtrl(IDC_FILENAME);
		rFilePath.OffsetRect(0, cy - rFilePath.bottom);
		rFilePath.right = cx;

		dwm.MoveWindow(&m_stFilePath, rFilePath);

		// finally the active todoctrl
		rTaskList.bottom = rFilePath.top - 1;

		dwm.MoveWindow(&GetToDoCtrl(), rTaskList);
	}
}

CRect CToDoListDlg::OffsetCtrl(UINT uCtrlID, int cx, int cy)
{
	CWnd* pCtrl = GetDlgItem(uCtrlID);

	if (pCtrl)
	{
		CRect rChild;
		pCtrl->GetWindowRect(rChild);
		ScreenToClient(rChild);

		if (cx || cy)
		{
			rChild.OffsetRect(cx, cy);
			pCtrl->MoveWindow(rChild);
		}
		return rChild;
	}

	return CRect(0, 0, 0, 0);
}

void CToDoListDlg::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	CDialog::OnGetMinMaxInfo(lpMMI);

	// don't handle if maximized
	if (!IsZoomed())
	{
		int nMinWidth = 352;
		
		if (GetTDCCount()) // ie there is at least CToDoCtrl
		{
			CRect rClient, rWindow;

			GetClientRect(rClient);
			GetWindowRect(rWindow);

			int nTDCMinWidth = GetToDoCtrl().GetMinWidth() + (rWindow.Width() - rClient.Width());
			nMinWidth = max(nMinWidth, nTDCMinWidth);
		}

		lpMMI->ptMinTrackSize.x = nMinWidth; // so caption and toolbar is fully visible
		lpMMI->ptMinTrackSize.y = 420; // arbitrary
	}
}

void CToDoListDlg::OnSave() 
{
	if (!SaveTaskList(GetTDCItem(), FALSE))
	{
		// check readonly status and notify user
		// TODO
	}
	else
	{
		UpdateCaption();
		UpdateTabItemText();
	}
}

BOOL CToDoListDlg::SaveTaskList(TDCITEM& tdci, LPCTSTR szFilePath)
{
	CAutoFlag af(m_bSaving, TRUE);
	CString sFilePath = szFilePath ? szFilePath : tdci.GetFilePath();

	tdci.pTDC->Flush();

	// conditions for saving
	// 1. Save As... ie szFilePath != NULL and not empty
	// 2. tasklist has been modified
	if ((szFilePath && !sFilePath.IsEmpty()) || tdci.pTDC->IsModified())
	{
		if (sFilePath.IsEmpty()) // means first time save
		{
			CFileDialog dialog(FALSE, "xml", sFilePath, 0, SAVEASXMLFILTER, this);

			dialog.m_ofn.lpstrTitle = "Save Task List - ToDoList � AbstractSpoon";
			dialog.m_ofn.Flags |= OFN_OVERWRITEPROMPT;

			while (sFilePath.IsEmpty())
			{
				if (dialog.DoModal() != IDOK)
					return FALSE; // user elected not to proceed

				// else make sure the file is not readonly
				sFilePath = dialog.GetPathName();

				if (CDriveInfo::IsReadonlyPath(sFilePath) > 0)
				{
					CString sMessage;
					sMessage.Format("The file '%s' is read-only.\n\nPlease select another filename", 
									sFilePath);

					if (MessageBox(sMessage, ABBREVCOPYRIGHT, MB_OKCANCEL) == IDCANCEL)
						return FALSE; // user elected not to proceed
					else
						sFilePath.Empty(); // to try again
				}
			}

			// update source control status
			if (Prefs().GetEnableSourceControl() && 
				(!Prefs().GetSourceControlLanOnly() || !CDriveInfo::IsRemotePath(sFilePath)))
			{
				tdci.pTDC->SetStyle(TDCS_ENABLESOURCECONTROL, TRUE);
				tdci.pTDC->SetStyle(TDCS_CHECKOUTONLOAD, Prefs().GetAutoCheckOut());
			}
		}

		CWaitCursor cursor;

		if (tdci.pTDC->Save(sFilePath))
		{
			tdci.bModified = FALSE;
			tdci.tLastMod = GetLastModified(sFilePath);
			tdci.bLastStatusReadOnly = FALSE;
            tdci.RefreshPathType();

			m_mruList.Add(sFilePath);

			UpdateCaption();
			UpdateStatusbar();

			// export to html?
			if (Prefs().GetAutoHtmlExport())
			{
				CString sExportPath = Prefs().GetAutoExportFolderPath();
				char szDrive[_MAX_DRIVE], szFolder[_MAX_DIR], szFName[_MAX_FNAME];

				_splitpath(sFilePath, szDrive, szFolder, szFName, NULL);
		
				if (!sExportPath.IsEmpty() && CreateFolder(sExportPath))
					_makepath(sFilePath.GetBuffer(MAX_PATH), NULL, sExportPath, szFName, ".html");
				else
					_makepath(sFilePath.GetBuffer(MAX_PATH), szDrive, szFolder, szFName, ".html");

				sFilePath.ReleaseBuffer();

				Export2Html(tdci.pTDC, sFilePath, FALSE);
			}
		}
		else
			return FALSE;
	}

	return TRUE;
}

void CToDoListDlg::UpdateStatusbar()
{
	TDCITEM& tdci = GetTDCItem();

	if (!tdci.GetFilePath().IsEmpty())
		m_sStatus.Format("%s (version %d)", tdci.GetFilePath(), tdci.pTDC->GetFileVersion());
	else
		m_sStatus.Empty();

	UpdateData(FALSE);
}

void CToDoListDlg::UpdateDefaultSortItem()
{
	TDCITEM& tdci = GetTDCItem();
	TDC_SORTBY nSortBy = tdci.pTDC->GetSortBy();

	if (nSortBy >= 0)
		m_tbHelper.SetDefaultMenuID(ID_SORT, GetSortID(nSortBy));
}

void CToDoListDlg::OnLoad() 
{
	CFileDialog dialog(TRUE, "xml", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_ALLOWMULTISELECT, 
						SAVEASXMLFILTER, this);
	
	const UINT BUFSIZE = 1024 * 5;
	static char FILEBUF[BUFSIZE] = { 0 };

	dialog.m_ofn.lpstrTitle = "Open Task List";
	dialog.m_ofn.lpstrFile = FILEBUF;
	dialog.m_ofn.nMaxFile = BUFSIZE;

	if (dialog.DoModal() == IDOK)
	{
		UpdateWindow();
		CWaitCursor cursor;

		POSITION pos = dialog.GetStartPosition();

		while (pos)
		{
			CString sTaskList = dialog.GetNextPathName(pos);
			int nResult = OpenTaskList(sTaskList);

			switch (nResult)
			{
			case LOAD_FAILED:
				{
					CString sMessage;
					sMessage.Format("'%s' does not appear to be a valid task list.", sTaskList);
					MessageBox(sMessage, ABBREVCOPYRIGHT, MB_OK);
				}
				break;

			case LOAD_SUCCESS:
				UpdateWindow();
				break;
			}
		}
	}
}

void CToDoListDlg::OnDestroy() 
{
	CDialog::OnDestroy();
}

void CToDoListDlg::SaveSettings()
{
	// pos
	WINDOWPLACEMENT wp;
	GetWindowPlacement(&wp);

	AfxGetApp()->WriteProfileInt("Pos", "TopLeft", MAKELPARAM(wp.rcNormalPosition.left, wp.rcNormalPosition.top));
	AfxGetApp()->WriteProfileInt("Pos", "BottomRight", MAKELPARAM(wp.rcNormalPosition.right, wp.rcNormalPosition.bottom));
	AfxGetApp()->WriteProfileInt("Pos", "Hidden", !m_bVisible);
	AfxGetApp()->WriteProfileInt("Pos", "Maximized", IsZoomed());

	// version
	AfxGetApp()->WriteProfileInt("Version", "Version", GetVersion());

	// last open files
	int nTDC = GetTDCCount();
	int nSel = GetSelToDoCtrl(); // and last active file

	if (nTDC) // but don't overwrite files saved in OnQueryEndSession() or OnClose()
	{
		AfxGetApp()->WriteProfileInt("Settings", "NumLastFiles", nTDC);

		while (nTDC--)
		{
			CString sKey;
			sKey.Format("LastFile%d", nTDC);
			AfxGetApp()->WriteProfileString("Settings", sKey, GetTDCItem(nTDC).GetFilePath());

			if (nSel == nTDC)
				AfxGetApp()->WriteProfileString("Settings", "LastActiveFile", GetTDCItem(nTDC).GetFilePath());
		}
	}

	// other settings
	AfxGetApp()->WriteProfileInt("Settings", "SimpleMode", m_bSimpleMode);
	AfxGetApp()->WriteProfileInt("Settings", "ToolbarOption", m_nToolbarOption);

	if (m_findDlg.GetSafeHwnd())
		AfxGetApp()->WriteProfileInt("Settings", "FindTasksVisible", m_findDlg.IsWindowVisible());

	m_mruList.WriteList();
}

void CToDoListDlg::LoadSettings()
{
	// MRU
	m_mruList.ReadList();

	// settings
	m_bSimpleMode = AfxGetApp()->GetProfileInt("Settings", "SimpleMode", m_bSimpleMode);

	// load last file only if an existing file is not loaded
	if (!GetTDCCount())
	{
		CString sLastActiveFile = AfxGetApp()->GetProfileString("Settings", "LastActiveFile");
		int nTDCCount = AfxGetApp()->GetProfileInt("Settings", "NumLastFiles", 0);

		for (int nTDC = 0; nTDC < nTDCCount; nTDC++)
		{
			CString sKey;
			sKey.Format("LastFile%d", nTDC);
			CString sLastFile = AfxGetApp()->GetProfileString("Settings", sKey);

			if (!sLastFile.IsEmpty())
				OpenTaskList(sLastFile);
		}

		// select 
		if (GetTDCCount())
		{
			if (!SelectToDoCtrl(sLastActiveFile))
				SelectToDoCtrl(0); // the first one
		}
	}

	// open a 'dummy' todolist if none
	if (GetTDCCount() == 0)
		CreateNewTaskList(TRUE);

	// pos
	WINDOWPLACEMENT wp;
	GetWindowPlacement(&wp);

	int nDefShowState = AfxGetApp()->m_nCmdShow;

	DWORD dwTopLeft = (DWORD)AfxGetApp()->GetProfileInt("Pos", "TopLeft", -1);
	DWORD dwBottomRight = (DWORD)AfxGetApp()->GetProfileInt("Pos", "BottomRight", -1);

	// get min size before we resize
	MINMAXINFO mmi;
	SendMessage(WM_GETMINMAXINFO, 0, (LPARAM)&mmi);
	CRect rect(0, 0, 0, 0);

	if (dwTopLeft != -1 && dwBottomRight != -1)
	{
		CRect rTemp(GET_X_LPARAM(dwTopLeft), GET_Y_LPARAM(dwTopLeft), 
					GET_X_LPARAM(dwBottomRight), GET_Y_LPARAM(dwBottomRight));

		rTemp.right = max(rTemp.right, rTemp.left + max(400, mmi.ptMinTrackSize.x));
		rTemp.bottom = max(rTemp.bottom, rTemp.top + mmi.ptMinTrackSize.y);
		
		// ensure this intersects with the desktop
		if (NULL != MonitorFromRect(rect, MONITOR_DEFAULTTONULL))
		{
			rect = rTemp;
			MoveWindow(rect);
		}
	}

	// first time or monitors changed?
	if (rect.IsRectEmpty())
	{
		CRect rect(0, 0, max(400, mmi.ptMinTrackSize.x), mmi.ptMinTrackSize.y);

		CenterWindow();
	}

	// set visibility
	BOOL bMaximized = AfxGetApp()->GetProfileInt("Pos", "Maximized", FALSE);
	BOOL bHidden = AfxGetApp()->GetProfileInt("Pos", "Hidden", FALSE);

	if (m_bVisible == -1) // not yet set
	{
		m_bVisible = (!Prefs().GetUseSysTray() || Prefs().GetShowOnStartup() || !bHidden);

		// also if wp.showCmd == minimized and we would hide to sys
		// tray when minimized then hide here too
		if (m_bVisible && nDefShowState == SW_SHOWMINNOACTIVE)
		{
			int nSysTrayOption = Prefs().GetSysTrayOption();

			if (nSysTrayOption == STO_ONMINIMIZE || nSysTrayOption == STO_ONMINCLOSE)
				m_bVisible = FALSE;
		}
	}

	ShowWindow(m_bVisible ? (bMaximized ? SW_SHOWMAXIMIZED : SW_SHOW) : SW_HIDE);

	// don't set topmost if maximized
	if (Prefs().GetAlwaysOnTop() && !bMaximized)
		SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);

	// find tasks dialog
	if (AfxGetApp()->GetProfileInt("Settings", "FindTasksVisible", 0))
	{
		OnFindTasks();

		if (Prefs().GetRefreshFindOnLoad())
			m_findDlg.RefreshSearch();
	}
}

void CToDoListDlg::OnNew() 
{
	CreateNewTaskList(TRUE);
}

void CToDoListDlg::CreateNewTaskList(BOOL bAddDefTask)
{
	CToDoCtrl* pNew = NewToDoCtrl();

	if (pNew)
	{
		AddToDoCtrl(pNew);

		// insert a default task
		if (bAddDefTask && pNew->GetTaskCount() == 0)
			VERIFY (NewTask("Task", TDC_INSERTATTOP, TRUE, FALSE));

		// clear modified flag
		pNew->SetModified(FALSE);
		GetTDCItem().bModified = FALSE;
	}

	UpdateCaption();
	UpdateStatusbar();
}

void CToDoListDlg::OnUpdateDeletetask(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	pCmdUI->Enable(!tdc.IsReadOnly() && tdc.HasSelection());	
}

void CToDoListDlg::OnUpdateEditTasktext(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();

	pCmdUI->Enable(nSelCount == 1 || (!nSelCount && tdc.CanPaste() && !tdc.IsReadOnly()));	
}

void CToDoListDlg::OnUpdateTaskcolor(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	pCmdUI->Enable(!tdc.IsReadOnly() && tdc.HasSelection() && !Prefs().GetColorTextByPriority());	
}

void CToDoListDlg::OnUpdateTaskdone(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();

	if (nSelCount == 1)
		pCmdUI->SetCheck(tdc.IsSelectedTaskDone() ? 1 : 0);
	
	pCmdUI->Enable(!tdc.IsReadOnly() && GetToDoCtrl().GetSelectedItem());	
}

void CToDoListDlg::OnUpdateDeletealltasks(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	pCmdUI->Enable(!tdc.IsReadOnly() && GetToDoCtrl().GetTaskCount());	
}

void CToDoListDlg::OnUpdateSave(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	pCmdUI->Enable(GetTDCCount() && tdc.IsModified() && !tdc.IsReadOnly());	
}

void CToDoListDlg::OnUpdateNew(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(TRUE);	
}

BOOL CToDoListDlg::OnEraseBkgnd(CDC* pDC) 
{
	// don't try to clip out children because the repainting
	// goes horribly wrong
	return CDialog::OnEraseBkgnd(pDC);
}

void CToDoListDlg::OnSortBy(UINT nCmdID)
{
	TDC_SORTBY nSortBy = GetSortBy(nCmdID);

	if (nSortBy != (TDC_SORTBY)-1)
	{
		m_tbHelper.SetDefaultMenuID(ID_SORT, nCmdID);

		GetToDoCtrl().Sort(nSortBy);
	}
}

void CToDoListDlg::OnUpdateSortBy(CCmdUI* pCmdUI)
{
	// we only need to handle this if the menubar is visible
	// because otherwise CToolbarHelper handles it
//	if (m_nToolbarOption == TB_TOOLBARHIDDEN)
	{
		TDC_SORTBY nSortBy = GetToDoCtrl().GetSortBy();
		UINT nCmdID = GetSortID(nSortBy);

		pCmdUI->SetCheck(nCmdID == pCmdUI->m_nID ? 1 : 0);
	}
}

TDC_SORTBY CToDoListDlg::GetSortBy(UINT nSortID)
{
	switch (nSortID)
	{
	case ID_SORT_BYNAME:		   return TDC_SORTBYNAME;
	case ID_SORT_BYID:			return TDC_SORTBYID;
	case ID_SORT_BYALLOCTO:		return TDC_SORTBYALLOCTO;
	case ID_SORT_BYALLOCBY:		return TDC_SORTBYALLOCBY;
	case ID_SORT_BYSTATUS:		return TDC_SORTBYSTATUS;
	case ID_SORT_BYCATEGORY:	return TDC_SORTBYCATEGORY;
	case ID_SORT_BYPERCENT:		return TDC_SORTBYPERCENT;
	case ID_SORT_BYCOLOR:		return TDC_SORTBYCOLOR;
	case ID_SORT_BYTIMEEST:		return TDC_SORTBYTIMEEST;
	case ID_SORT_BYTIMESPENT:	return TDC_SORTBYTIMESPENT;
	case ID_SORT_BYSTARTDATE:	return TDC_SORTBYSTARTDATE;
	case ID_SORT_BYDUEDATE:		return TDC_SORTBYDUEDATE;
	case ID_SORT_BYDONEDATE:	return TDC_SORTBYDONEDATE;
	case ID_SORT_BYDONE:		   return TDC_SORTBYDONE;
	case ID_SORT_BYPRIORITY:	return TDC_SORTBYPRIORITY;
	case ID_SORT_NONE:	      return TDC_SORTBYNONE;
	}

	ASSERT (0);
	return (TDC_SORTBY)-1;
}

UINT CToDoListDlg::GetSortID(TDC_SORTBY nSortBy)
{
	switch (nSortBy)
	{
	case TDC_SORTBYNAME:		   return ID_SORT_BYNAME;
	case TDC_SORTBYID:			return ID_SORT_BYID;
	case TDC_SORTBYALLOCTO:		return ID_SORT_BYALLOCTO;
	case TDC_SORTBYALLOCBY:		return ID_SORT_BYALLOCBY;
	case TDC_SORTBYSTATUS:		return ID_SORT_BYSTATUS;
	case TDC_SORTBYCATEGORY:	return ID_SORT_BYCATEGORY;
	case TDC_SORTBYPERCENT:		return ID_SORT_BYPERCENT;
	case TDC_SORTBYCOLOR:		return ID_SORT_BYCOLOR;
	case TDC_SORTBYTIMEEST:		return ID_SORT_BYTIMEEST;
	case TDC_SORTBYTIMESPENT:	return ID_SORT_BYTIMESPENT;
	case TDC_SORTBYSTARTDATE:	return ID_SORT_BYSTARTDATE;
	case TDC_SORTBYDUEDATE:		return ID_SORT_BYDUEDATE;
	case TDC_SORTBYDONEDATE:	return ID_SORT_BYDONEDATE;
	case TDC_SORTBYDONE:		   return ID_SORT_BYDONE;
	case TDC_SORTBYPRIORITY:	return ID_SORT_BYPRIORITY;
	case TDC_SORTBYNONE:	      return ID_SORT_NONE;
	}

	ASSERT (0);
	return 0;
}

void CToDoListDlg::OnNewtaskAttopSelected() 
{
	VERIFY (NewTask("Task", TDC_INSERTATTOPOFSELTASKPARENT));
}

void CToDoListDlg::OnNewtaskAtbottomSelected() 
{
	VERIFY (NewTask("Task", TDC_INSERTATBOTTOMOFSELTASKPARENT));
}

void CToDoListDlg::OnNewtaskAfterselectedtask() 
{
	VERIFY (NewTask("Task", TDC_INSERTAFTERSELTASK));
}

void CToDoListDlg::OnNewtaskBeforeselectedtask() 
{
	VERIFY (NewTask("Task", TDC_INSERTBEFORESELTASK));
}

void CToDoListDlg::OnNewsubtaskAtbottom() 
{
	VERIFY (NewTask("Task", TDC_INSERTATBOTTOMOFSELTASK));
}

void CToDoListDlg::OnNewsubtaskAttop() 
{
	VERIFY (NewTask("Task", TDC_INSERTATTOPOFSELTASK));
}

BOOL CToDoListDlg::NewTask(LPCTSTR szTitle, TDC_INSERTWHERE nInsertWhere, BOOL bSelect, BOOL bEdit)
{
	CToDoCtrl& tdc = GetToDoCtrl();

	if (tdc.IsReadOnly())
		return FALSE;

	// handle special case when tasklist is empty
	if (!tdc.GetTaskCount())
		nInsertWhere = TDC_INSERTATBOTTOM;

	if (!tdc.NewTask(szTitle, nInsertWhere, bSelect, bEdit))
		return FALSE;

	// else init attributes other than defaults
	CAutoFlag af(m_bInNewTask, TRUE);
	CPreferencesDlg& pref = Prefs();

	if (pref.GetUseParentAttrib(PTPA_ALLOCTO))
		tdc.SetSelectedTaskAttributeAsParent(TDCA_ALLOCTO);

	if (pref.GetUseParentAttrib(PTPA_ALLOCBY))
		tdc.SetSelectedTaskAttributeAsParent(TDCA_ALLOCBY);

	if (pref.GetUseParentAttrib(PTPA_STATUS))
		tdc.SetSelectedTaskAttributeAsParent(TDCA_STATUS);

	if (pref.GetUseParentAttrib(PTPA_CATEGORY))
		tdc.SetSelectedTaskAttributeAsParent(TDCA_CATEGORY);

	if (pref.GetUseParentAttrib(PTPA_TIMEEST))
		tdc.SetSelectedTaskAttributeAsParent(TDCA_TIMEEST);

	if (pref.GetUseParentAttrib(PTPA_PRIORITY))
		tdc.SetSelectedTaskAttributeAsParent(TDCA_PRIORITY);

	if (pref.GetUseParentAttrib(PTPA_COLOR))
		tdc.SetSelectedTaskAttributeAsParent(TDCA_COLOR);

	return TRUE;
}

void CToDoListDlg::OnUpdateSort(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	// note: we're still allowed to sort when readonly but the result is not saved
	pCmdUI->Enable(GetTDCCount() && GetToDoCtrl().GetTaskCount());	
}

void CToDoListDlg::OnEditTaskcolor() 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	if (!tdc.IsReadOnly() && tdc.HasSelection())
	{
		CEnColorDialog dialog(tdc.GetSelectedTaskColor(), CC_FULLOPEN | CC_RGBINIT);

		if (dialog.DoModal() == IDOK)
			tdc.SetSelectedTaskColor(dialog.GetColor());
	}
}

void CToDoListDlg::OnEditTaskdone() 
{
	GetToDoCtrl().SetSelectedTaskDone(!GetToDoCtrl().IsSelectedTaskDone());
}

void CToDoListDlg::OnEditTasktext() 
{
	GetToDoCtrl().EditSelectedTask();
}

void CToDoListDlg::OnTrayIconClick(NMHDR* pNMHDR, LRESULT* pResult)
{
	Show(Prefs().GetToggleTrayVisibility());

	*pResult = 0;
}

LRESULT CToDoListDlg::OnToDoListShowWindow(WPARAM wp, LPARAM lp)
{
	Show(FALSE);
	return 0;
}

LRESULT CToDoListDlg::OnToDoListGetVersion(WPARAM wp, LPARAM lp)
{
	return GetVersion();
}

void CToDoListDlg::OnTrayIconDblClk(NMHDR* pNMHDR, LRESULT* pResult)
{
	Show(FALSE);

	*pResult = 0;
}

void CToDoListDlg::OnTrayiconCreatetask() 
{
	Show(FALSE);

	// create a task at the top of the tree
	GetToDoCtrl().NewTask("Task", TDC_INSERTATTOP);
}

void CToDoListDlg::OnTrayIconRClick(NMHDR* pNMHDR, LRESULT* pResult)
{
	SetForegroundWindow();

	// show context menu
	CMenu menu;

	if (menu.LoadMenu(IDR_MISC))
	{
		CMenu* pSubMenu = menu.GetSubMenu(TRAYICON);
		pSubMenu->SetDefaultItem(ID_TRAYICON_SHOW);

		NM_TRAYICON* pNMTI = (NM_TRAYICON*)pNMHDR;

		if (pSubMenu)
		{
			pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON, pNMTI->ptAction.x, pNMTI->ptAction.y, this);
			PostMessage(WM_NULL);
		}
	}
}

void CToDoListDlg::OnClose() 
{
	int nSysTrayOption = Prefs().GetSysTrayOption();

	if (nSysTrayOption == STO_ONCLOSE || nSysTrayOption == STO_ONMINCLOSE)
		MinimizeToTray(Prefs().GetAutoSaveOnSysTray());

	else // shutdown but user can cancel
		DoExit();
}

void CToDoListDlg::MinimizeToTray(BOOL bAutoSave)
{
	// save prev state so we can restore properly
	AfxGetApp()->WriteProfileInt("Pos", "Maximized", IsZoomed());

	if (bAutoSave)
	{
		// save all
		int nCtrl = GetTDCCount();
		
		while (nCtrl--)
		{
			if (!SaveTaskList(GetTDCItem(nCtrl), FALSE))
				return; // user cancelled
			else
				UpdateTabItemText(nCtrl);
		}
		
		UpdateCaption();
	}
	
	MinToTray(*this); // courtesy of floyd
	m_bVisible = FALSE;
}

void CToDoListDlg::OnTrayiconClose() 
{
	DoExit();
}

LRESULT CToDoListDlg::OnToDoCtrlNotifySort(WPARAM wp, LPARAM lp)
{
	UpdateDefaultSortItem();

	return 0;
}

LRESULT CToDoListDlg::OnToDoCtrlNotifyMinWidthChange(WPARAM wp, LPARAM lp)
{
	CheckMinWidth();

	return 0;
}

LRESULT CToDoListDlg::OnToDoCtrlNotifyMod(WPARAM wp, LPARAM lp)
{
	TDCITEM& tdci = GetTDCItem();

	BOOL bWasMod = tdci.bModified;
	tdci.bModified = TRUE;

	// update the caption only if the control is not currently modified
	// or the project name changed
	if (!bWasMod || lp == TDCA_PROJNAME)
		UpdateCaption();

	// update due items
	if (lp == TDCA_DONEDATE || TDCA_DUEDATE)
		OnTimerDueItems(GetSelToDoCtrl());

	// decide whether to resort or not
	if (!m_bInNewTask && lp != TDCA_PROJNAME && lp != TDCA_NONE && Prefs().GetAutoReSort())
	{
		// we only sort if the thing that changed is the current sort key
		TDC_SORTBY nSortBy = tdci.pTDC->GetSortBy();

		switch (lp)
		{
		case TDCA_TASKNAME:
			if (TDC_SORTBYNAME != nSortBy)
				return 0;
			break;

		case TDCA_DONEDATE:
			// also check percent and priority
			if (TDC_SORTBYPERCENT != nSortBy && 
				TDC_SORTBYDONEDATE != nSortBy &&
				TDC_SORTBYDONE != nSortBy &&
				TDC_SORTBYPRIORITY != nSortBy &&
				TDC_SORTBYSTARTDATE != nSortBy &&
				TDC_SORTBYDUEDATE != nSortBy)
				return 0;
			break;

		case TDCA_DUEDATE:
			// also check priority
			if (TDC_SORTBYDUEDATE != nSortBy && TDC_SORTBYPRIORITY != nSortBy)
				return 0;
			break;

		case TDCA_STARTDATE:
			if (TDC_SORTBYSTARTDATE != nSortBy)
				return 0;
			break;

		case TDCA_PRIORITY:
			if (TDC_SORTBYPRIORITY != nSortBy)
				return 0;
			break;

		case TDCA_COLOR:
			if (TDC_SORTBYCOLOR != nSortBy)
				return 0;
			break;

		case TDCA_ALLOCTO:
			if (TDC_SORTBYALLOCTO != nSortBy)
				return 0;
			break;

		case TDCA_PERCENT:
			if (TDC_SORTBYPERCENT != nSortBy)
				return 0;
			break;

		case TDCA_TIMEEST:
			if (TDC_SORTBYTIMEEST != nSortBy)
				return 0;
			break;

		default:
			return 0;
		}

		GetToDoCtrl().Sort(nSortBy);
	}

	return 0L;
}

void CToDoListDlg::UpdateCaption()
{
	CString sProjectName = UpdateTabItemText();

	const TDCITEM& tdci = GetTDCItem();

	if (tdci.bLastStatusReadOnly > 0)
		sProjectName += " [read-only]";

	else if (tdci.pTDC->CompareFileFormat() == TDCFF_NEWER)
		sProjectName += " [read-only: newer format]";
	
	else if (tdci.bLastStatusReadOnly == 0 && PathSupportsSourceControl(tdci.GetFilePath()))
	{
		if (tdci.pTDC->IsCheckedOut())
			sProjectName += " [checked out]";
		else
			sProjectName += " [checked in]";
	}
	else if (!Prefs().GetEnableSourceControl() && CToDoCtrl::IsUnderSourceControl(tdci.GetFilePath()))
		sProjectName += " [read-only: under source control]";

	CString sCaption;
	sCaption.Format("%s - %s 2005", sProjectName, ABBREVCOPYRIGHT);
	SetWindowText(sCaption);
}

CString CToDoListDlg::UpdateTabItemText(int nIndex)
{
	if (nIndex < 0)
	{
		nIndex = GetSelToDoCtrl();

		if (nIndex < 0)
			return "";
	}

	TDCITEM& tdci = GetTDCItem(nIndex);

	// project name
	CString sProjectName = tdci.pTDC->GetFriendlyProjectName();

	if (tdci.pTDC->IsModified() && !tdci.pTDC->IsReadOnly())
		sProjectName += "*";

	// appropriate icon
	int nImage = IM_NONE;

	if (PathSupportsSourceControl(tdci.GetFilePath()))
        nImage = tdci.pTDC->IsCheckedOut() ? IM_CHECKEDOUT : IM_CHECKEDIN;

	else if (IsReadOnly(tdci))
		nImage = IM_READONLY;
	
    // update tab array
	TCITEM tci;
	tci.mask = TCIF_TEXT | TCIF_IMAGE;
	tci.pszText = (LPTSTR)(LPCTSTR)sProjectName;
	tci.iImage = nImage;

	m_tabCtrl.SetItem(nIndex, &tci);

	return sProjectName;
}

BOOL CToDoListDlg::PathSupportsSourceControl(LPCTSTR szPath, const CPreferencesDlg* pPref) const
{
    int nType = CDriveInfo::GetPathType(szPath);

    switch (nType)
    {
    case DRIVE_FIXED:          
    case DRIVE_REMOTE:         
        break;

    default: // everything else
        return FALSE;
    }

	BOOL bEnableSourceControl = FALSE, bLanOnly = FALSE;
	
	if (pPref)
	{
		bEnableSourceControl = pPref->GetEnableSourceControl();
		bLanOnly = pPref->GetSourceControlLanOnly();
	}
	else
	{
		CPreferencesGenPage pref;


		bEnableSourceControl = pref.GetEnableSourceControl();
		bLanOnly = pref.GetSourceControlLanOnly();
	}

    return (bEnableSourceControl && (!bLanOnly || nType == DRIVE_REMOTE));
}

void CToDoListDlg::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos) 
{
	CDialog::OnWindowPosChanging(lpwndpos);
}

void CToDoListDlg::OnUpdateNewsubtaskAtBottom(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();

	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount == 1);
}

BOOL CToDoListDlg::Export2Html(CToDoCtrl* pCtrl, LPCTSTR szFilePath, BOOL bPreview, 
							   TDC_FILTER nFilter, BOOL bSelTaskOnly, LPCTSTR szTitle) 
{
	CWaitCursor cursor;
		
	pCtrl->Flush();

	// options
	DWORD dwOptions = TDCE_INCLUDEPROJECTNAME;
	dwOptions |= Prefs().GetExportVisibleOnly() ? TDCE_VISIBLECOLSONLY : 0;
	dwOptions |= Prefs().GetExportParentTitleCommentsOnly() ? TDCE_PARENTTITLECOMMENTSONLY : 0;
	dwOptions |= Prefs().GetExportSpaceForNotes() ? TDCE_SPACEFORNOTES : 0;

	CString sOutput;

	if (bSelTaskOnly)
		pCtrl->ExportSelectedTask2Html(sOutput, dwOptions, Prefs().GetHtmlFont(), 
										Prefs().GetHtmlFontSize());
	else // all tasks
		pCtrl->Export2Html(sOutput, dwOptions, Prefs().GetHtmlFont(), 
							Prefs().GetHtmlFontSize(), nFilter);
	
	if (!sOutput.IsEmpty())
	{
		CStdioFile file;
		
		if (file.Open(szFilePath, CFile::shareExclusive | CFile::modeWrite | CFile::modeCreate | CFile::typeText))
		{
			// add header
			CString sHeader;
			
			if (szTitle)
				sHeader.Format("<html>\n<head></head>\n<body>\n<H2>%s</H2>", szTitle);
			else
				sHeader = "<html>\n<head></head>\n<body>\n";

			sOutput = sHeader + sOutput;
			
			// and footer
			sOutput += "</body>\n</html>\n";
			
			// save to file 
			file.WriteString(sOutput);
			file.Close();
			
			// and preview
			if (bPreview)
				ShellExecute(*this, NULL, szFilePath, NULL, NULL, SW_SHOWNORMAL);

			return TRUE;
		}
	}

	return FALSE;
}

BOOL CToDoListDlg::Export2Text(CToDoCtrl* pCtrl, LPCTSTR szFilePath, BOOL bPreview, 
							   TDC_FILTER nFilter, BOOL bSelTaskOnly, LPCTSTR szTitle) 
{
	CWaitCursor cursor;
		
	pCtrl->Flush();

	// options
	DWORD dwOptions = TDCE_INCLUDEPROJECTNAME;
	dwOptions |= Prefs().GetExportVisibleOnly() ? TDCE_VISIBLECOLSONLY : 0;
	dwOptions |= Prefs().GetExportParentTitleCommentsOnly() ? TDCE_PARENTTITLECOMMENTSONLY : 0;
	dwOptions |= Prefs().GetExportSpaceForNotes() ? TDCE_SPACEFORNOTES : 0;

	CString sOutput;

	if (bSelTaskOnly)
		pCtrl->ExportSelectedTask2Text(sOutput, dwOptions, Prefs().GetTextIndent());
	else // all tasks
		pCtrl->Export2Text(sOutput, dwOptions, Prefs().GetTextIndent(), nFilter);

	if (!sOutput.IsEmpty())
	{
		CStdioFile file;
		
		if (file.Open(szFilePath, CFile::shareExclusive | CFile::modeWrite | CFile::modeCreate | CFile::typeText))
		{
			// save to file 
			file.WriteString(sOutput);
			file.Close();
			
			// and preview
			if (bPreview)
				ShellExecute(*this, NULL, szFilePath, NULL, NULL, SW_SHOWNORMAL);

			return TRUE;
		}
	}

	return FALSE;
}

void CToDoListDlg::OnSaveas() 
{
	DoSaveAs(SAVEASXML);
}

BOOL CToDoListDlg::DoSaveAs(int nType)
{
	// remove extension from filename and get the dialog to add it back in
	CString sFilePath = GetTDCItem().GetFilePath();
	char szDrive[_MAX_DRIVE], szPath[MAX_PATH], szFName[_MAX_FNAME];

	_splitpath(sFilePath, szDrive, szPath, szFName, NULL);
	_makepath(sFilePath.GetBuffer(MAX_PATH + 1), szDrive, szPath, szFName, NULL);
	sFilePath.ReleaseBuffer();

	CString sFilter, szExt;
	
	switch (nType)
	{
	case SAVEASXML:
		szExt = "xml";
		sFilter = SAVEASXMLFILTER;
		break;
		
	case SAVEASHTM:
		szExt = "html";
		sFilter = SAVEASHTMFILTER;
		break;
		
	case SAVEASTXT:
		szExt = "txt";
		sFilter = SAVEASTXTFILTER;
		break;

	default:
		return FALSE;
	}

	// display the dialog
	CFileDialog dialog(FALSE, szExt, sFilePath, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, sFilter, this);

	dialog.m_ofn.lpstrTitle = "Save Task List As";

	int nRes = dialog.DoModal();

	// release filter buffer
	sFilter.ReleaseBuffer();
	
	if (nRes == IDOK)
	{
		TDCITEM& tdci = GetTDCItem();
		tdci.pTDC->Flush();

		switch (nType)
		{
		case SAVEASXML:
			SaveTaskList(tdci, dialog.GetPathName());
			break;
			
		case SAVEASHTM:
			Export2Html(tdci.pTDC, dialog.GetPathName(), Prefs().GetPreviewExport());
			break;
			
		case SAVEASTXT:
			Export2Text(tdci.pTDC, dialog.GetPathName(), Prefs().GetPreviewExport());
			break;
		}
	
		return TRUE;
	}
	
	return FALSE;
}

void CToDoListDlg::OnUpdateSaveas(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	pCmdUI->Enable(tdc.GetTaskCount() || tdc.IsModified());
}

void CToDoListDlg::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	UINT nMenuID = 0;

	if (pWnd == &m_tabCtrl)
	{
		// if point.x,y are both -1 then we just use the cursor pos
		// which is what windows appears to do mostly/sometimes
		if (point.x == -1 && point.y == -1)
		{
			CRect rTab;

			if (m_tabCtrl.GetItemRect(m_tabCtrl.GetCurSel(), rTab))
			{
				point = rTab.CenterPoint();
				m_tabCtrl.ClientToScreen(&point);

				// load popup menu
				nMenuID = TABCTRL;
			}
		}
		else
		{
			// activate clicked tab
			TCHITTESTINFO tcht = { { point.x, point.y }, TCHT_NOWHERE  };
			m_tabCtrl.ScreenToClient(&tcht.pt);

			int nTab = m_tabCtrl.HitTest(&tcht);

			if (nTab != -1 && !(tcht.flags & TCHT_NOWHERE))
			{
				if (nTab != m_tabCtrl.GetCurSel())
					SelectToDoCtrl(nTab);

				m_tabCtrl.SetFocus(); // give user feedback

				// load popup menu
				nMenuID = TABCTRL;
			}
		}
	}
	else if (pWnd == &GetToDoCtrl()) // try active todoctrl
		nMenuID = TASKCONTEXT;
	
	// show the menu
	if (nMenuID)
	{
		CMenu menu;

		if (menu.LoadMenu(IDR_MISC))
		{
			CMenu* pPopup = menu.GetSubMenu(nMenuID);

			if (pPopup)
			{
				CToolbarHelper::PrepareMenuItems(pPopup, this);
				
				pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON, point.x, point.y, this);
			}
		}
	}
}

UINT CToDoListDlg::OnGetDlgCode() 
{
	return (CDialog::OnGetDlgCode());
}

void CToDoListDlg::OnTrayiconShow() 
{
	Show(FALSE);
}

void CToDoListDlg::Show(BOOL bAllowToggle)
{
	// refresh active tasklist
	int nIndex = GetSelToDoCtrl();

	OnTimerReadOnlyStatus(nIndex);
	OnTimerTimestampChange(nIndex);
	OnTimerCheckoutStatus(nIndex);

	if (!m_bVisible) // restore from the tray
	{
		m_bVisible = TRUE;
		RestoreFromTray(*this, AfxGetApp()->GetProfileInt("Pos", "Maximized", FALSE));
	}
	else if (IsIconic())
	{
		ShowWindow(SW_RESTORE);
		SetForegroundWindow();
	}
	// if we're already visible then either bring to the foreground 
	// or hide if we're right at the top of the z-order
	else if (!bAllowToggle || IsObscured(*this))
		SetForegroundWindow();
	else
	{
		m_bVisible = FALSE;
		MinToTray(*this);
	}
}

BOOL CToDoListDlg::OnQueryEndSession() 
{
	if (!CDialog::OnQueryEndSession())
		return FALSE;

	SaveAll(TRUE, TRUE, TRUE);
	SaveSettings();

	int nCtrl = GetTDCCount();

	while (nCtrl--)
		CloseToDoCtrl(nCtrl, TRUE);

	DestroyWindow(); // because otherwise we would get left in an undefined state

	return TRUE;
}

void CToDoListDlg::OnUpdateRecentFileMenu(CCmdUI* pCmdUI) 
{
	m_mruList.UpdateMenu(pCmdUI);	
}

BOOL CToDoListDlg::OnOpenRecentFile(UINT nID)
{
	ASSERT(nID >= ID_FILE_MRU_FILE1);
	ASSERT(nID < ID_FILE_MRU_FILE1 + (UINT)m_mruList.GetSize());

	int nIndex = nID - ID_FILE_MRU_FILE1;
	CString sPathName = m_mruList[nIndex];

	int nResult = OpenTaskList(sPathName);

	switch (nResult)
	{
	case LOAD_FAILED:
		{
			MessageBox("The selected task list could not be opened.\n\nPlease check that "
						"it has not been moved or deleted.", ABBREVCOPYRIGHT, MB_OK);
			m_mruList.Remove(nIndex);
		}
		break;
	}

	// always return TRUE to say we handled it
	return TRUE;
}

int CToDoListDlg::OpenTaskList(LPCTSTR szFilePath)
{
	// see if the tasklist is already open
	if (SelectToDoCtrl(szFilePath))
		return LOAD_SUCCESS;

	// init archive params?
	CString sArchivePath;
	TDC_ARCHIVE nRemove = TDC_REMOVENONE;

	if (Prefs().GetAutoArchive())
	{
		if (Prefs().GetRemoveArchivedTasks())
		{
			if (Prefs().GetRemoveOnlyOnAbsoluteCompletion())
				nRemove = TDC_REMOVEIFSIBLINGSANDSUBTASKSCOMPLETE;
			else
				nRemove = TDC_REMOVEALL;
		}

		sArchivePath = GetArchivePath(szFilePath);
	}

	CToDoCtrl* pCtrl = NewToDoCtrl();
	int nResult = OpenTaskList(pCtrl, szFilePath, sArchivePath, nRemove);

	if (nResult == LOAD_SUCCESS)
	{
		int nIndex = AddToDoCtrl(pCtrl);

		// notify user of due tasks if req
		DoDueTaskNotification(pCtrl);

		// save checkout status
		if (Prefs().GetAutoCheckOut())
			GetTDCItem(nIndex).bLastCheckoutSuccess = pCtrl->IsCheckedOut();

		UpdateCaption();
		UpdateStatusbar();
		UpdateDefaultSortItem();
		OnTimerDueItems(nIndex);

		// notify user if file is readonly for any reason except checked in
		if (Prefs().GetNotifyReadOnly())
		{
			CString sMessage;

			if (CDriveInfo::IsReadonlyPath(szFilePath))
				sMessage.Format("The file '%s' is currently read-only \nand you will not be able "
								"to make any changes to it.", szFilePath);
	
			else if (!Prefs().GetEnableSourceControl() && CToDoCtrl::IsUnderSourceControl(szFilePath))
				sMessage.Format("The file '%s' is currently held under source control \nand "
								"you will not be able to make any changes to it.\n\nTo edit the file you need to enable source control and check the file out.", szFilePath);

            else if (pCtrl->CompareFileFormat() == TDCFF_NEWER)
                sMessage.Format("The file '%s' has a more recent file format than your \ncurrent "
								"version of ToDoList and you will therefore not be able to make "
								"any \nchanges to it.", szFilePath);
		
			if (!sMessage.IsEmpty())
				MessageBox(sMessage, ABBREVCOPYRIGHT);
		}

		// update search
		if (Prefs().GetRefreshFindOnLoad() && m_findDlg.GetSafeHwnd())
			m_findDlg.RefreshSearch();
	}
	else if (GetTDCCount() >= 1) // only delete if there's another ctrl existing
	{
		pCtrl->DestroyWindow();
		delete pCtrl;
	}
	else // re-add
	{
		AddToDoCtrl(pCtrl);
	}

	return nResult;
}

int CToDoListDlg::OpenTaskList(CToDoCtrl* pCtrl, LPCTSTR szFilePath, LPCTSTR szArchivePath, TDC_ARCHIVE nRemove)
{
	CString sFilePath(szFilePath);

	if (sFilePath.IsEmpty())
		sFilePath = (LPCTSTR)pCtrl->GetFilePath(); // ie. reload

	// else initialize source control
	else if (PathSupportsSourceControl(szFilePath))
	{
		// these styles must be set prior to loading
		pCtrl->SetStyle(TDCS_ENABLESOURCECONTROL, Prefs().GetEnableSourceControl());
		pCtrl->SetStyle(TDCS_CHECKOUTONLOAD, Prefs().GetAutoCheckOut());
	}

	TDC_OPEN nResult = pCtrl->Load(sFilePath, szArchivePath, nRemove);

	switch (nResult)
	{
	case TDCO_SUCCESS:
		{
			m_mruList.Add(sFilePath);

			// update readonly status
			pCtrl->SetReadonly(IsReadOnly(pCtrl)); // takes source control into account too

			return LOAD_SUCCESS;
		}

	case TDCO_CANCELLED:
		return LOAD_CANCELLED;
	}

	// else
	return LOAD_FAILED;
}

BOOL CToDoListDlg::DoDueTaskNotification(const CToDoCtrl* pCtrl, int nDueBy)
{
	// check prefs
	if (nDueBy == -1)
	{
		if (!Prefs().GetNotifyDue()) 
			return TRUE;

		// else
		nDueBy = Prefs().GetNotifyDueBy();
	}

	ASSERT (pCtrl);

	if (!pCtrl)
		return FALSE;

	CString sDueBy("today");
	TDC_FILTER nFilter = TDCF_DUE;
	
	switch (nDueBy)
	{
	case PFP_DUETODAY:
		break; // done
		
	case PFP_DUETOMORROW:
		sDueBy = "tomorrow";
		nFilter = TDCF_DUETOMORROW;
		break;
		
	case PFP_DUETHISWEEK:
		sDueBy = "by the end of this week";
		nFilter = TDCF_DUETHISWEEK;
		break;
		
	case PFP_DUENEXTWEEK:
		sDueBy = "by the end of next week";
		nFilter = TDCF_DUENEXTWEEK;
		break;
		
	case PFP_DUETHISMONTH:
		sDueBy = "by the end of this month";
		nFilter = TDCF_DUETHISMONTH;
		break;
		
	case PFP_DUENEXTMONTH:
		sDueBy = "by the end of next month";
		nFilter = TDCF_DUENEXTMONTH;
		break;
		
	default:
		ASSERT (0);
		return FALSE;
	}
	
	// display in browser?
	if (Prefs().GetDisplayDueTasksInHtml())
	{
		CString sTitle;
		sTitle.Format("Tasks due %s", sDueBy);

		char szTempFile[MAX_PATH], szTempPath[MAX_PATH];
		
		if (!::GetTempPath(MAX_PATH, szTempPath))
			return FALSE;
		
		// always use the same file
		_makepath(szTempFile, NULL, szTempPath, "ToDoList.due", "html");

		return Export2Html((CToDoCtrl*)pCtrl, szTempFile, TRUE, nFilter, FALSE, sTitle);
	}
	else // format as message
	{
		// options
		DWORD dwOptions = 0;
		dwOptions |= Prefs().GetExportVisibleOnly() ? TDCE_VISIBLECOLSONLY : 0;
		dwOptions |= Prefs().GetExportParentTitleCommentsOnly() ? TDCE_PARENTTITLECOMMENTSONLY : 0;
	//	dwOptions |= Prefs().GetExportSpaceForNotes() ? TDCE_SPACEFORNOTES : 0;

		CString sDueTasks;
		pCtrl->Export2Text(sDueTasks, dwOptions, 2, nFilter);
		sDueTasks.TrimLeft();

		if (!sDueTasks.IsEmpty())
		{
			CString sMessage;
			sMessage.Format("The following tasks are due %s:\n\n%s", sDueBy, sDueTasks);

			MessageBox(sMessage, ABBREVCOPYRIGHT);
			return TRUE;
		}
	}

	return FALSE;
}

CString CToDoListDlg::GetArchivePath(LPCTSTR szFilePath)
{
	CString sArchivePath, sFilePath(szFilePath);
	sFilePath.MakeLower();
	
	if (!sFilePath.IsEmpty() && sFilePath.Find(".done.") == -1) // don't archive archives!
	{
		char szDrive[_MAX_DRIVE], szPath[MAX_PATH], szFName[_MAX_FNAME];
		_splitpath(szFilePath, szDrive, szPath, szFName, NULL);
		
		sArchivePath.Format("%s%s%s.done.xml", szDrive, szPath, szFName);
	}

	return sArchivePath;
}

void CToDoListDlg::OnAbout() 
{
	const LPCTSTR COPYRIGHT = "Copyright � 2003-05<br><a href=www.abstractspoon.com>"
							  "<font color=\"#006000\" face=\"tahoma\">"
							  "<u><b>Abstract</b><i>Spoon </i>Software</u></font></a>"
							  "<br><br><b>Credits</b>"
							  "<br>&bull; Paul DiLascia (of course)"
							  "<br>&bull; :floyd: (part of the System Tray code)"
							  "<br>&bull; Hans Dietrich (HTML control)"
							  "<br>&bull; Armen Hakobyan (Enhanced folder dialog)"
							  "<br>&bull; Open Office (Spellcheck Engine and Dictionaries)"
							  "<br>&bull; Richard Butler (Encryption)"
							  "<br>&bull; <a href=\"www.awicons.com/\">AWIcons</a> (Icons)";

	CAboutDlg dialog(IDI_MAINFRAMEXP, "<b>ToDoList 4.0.1</b>", 
					"A simple and effective way to keep on top of your programming tasks (freeware)",
					COPYRIGHT, 1, 2, 11);
	
	dialog.DoModal();
}

void CToDoListDlg::OnPreferences() 
{
	BOOL bSourceControl = Prefs().GetEnableSourceControl(); // so we can tell if it has changed
	BOOL bLargecons = Prefs().GetLargeToolbarIcons(); // likewise
	BOOL bAutoHideTabbar = Prefs().GetAutoHideTabbar(); // "
	BOOL bStackTabbar = Prefs().GetStackTabbarItems(); // "

	UINT nRet = Prefs().DoModal();

	// updates prefs
	ResetPrefs();
	
	if (nRet == IDOK)
	{
		BOOL bResizeDlg = FALSE;

		// topmost
		BOOL bTopMost = (Prefs().GetAlwaysOnTop() && !IsZoomed());

		SetWindowPos(bTopMost ? &wndTopMost : &wndNoTopMost, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);

		// tray icon
		m_ti.ShowTrayIcon(Prefs().GetUseSysTray());

		// source control
		if (bSourceControl != Prefs().GetEnableSourceControl())
		{
			bSourceControl = Prefs().GetEnableSourceControl();

			// update all open files to ensure they're in the right state
			int nCtrl = GetTDCCount();

			while (nCtrl--)
			{
				TDCITEM& tdci = GetTDCItem(nCtrl);

				// check files in if we're disabling sc. however although we 
				// are checking in, the file cannot be edited by the user
				// until they remove the file from under source control
				if (!bSourceControl && tdci.pTDC->IsCheckedOut())
					tdci.pTDC->CheckIn();

				// else checout if we're enabling and auto-checkout
				// is also enabled
				else if (bSourceControl && Prefs().GetAutoCheckOut())
				{
					if (PathSupportsSourceControl(tdci.GetFilePath()))
					{
						tdci.pTDC->SetStyle(TDCS_ENABLESOURCECONTROL);
						tdci.pTDC->SetStyle(TDCS_CHECKOUTONLOAD);
						tdci.pTDC->CheckOut();
					}
				}

				tdci.pTDC->SetReadonly(IsReadOnly(tdci.pTDC));
				UpdateTabItemText(nCtrl);
			}

		}

		m_toolbar.GetToolBarCtrl().HideButton(ID_TOOLS_TOGGLECHECKIN, !bSourceControl);

		// toolbar image
		if (Prefs().GetLargeToolbarIcons() != bLargecons)
		{
			UINT nIDToolbarImage = !bLargecons ? IDB_TOOLBAR24 : IDB_TOOLBAR16;

			m_toolbar.LoadToolBar(IDR_TOOLBAR, nIDToolbarImage);
			PrepareToolbar(m_nToolbarOption);

			bResizeDlg = TRUE;
		}

		// tools
		if (m_nToolbarOption != TB_TOOLBARHIDDEN)
			AppendTools2Toolbar(m_nToolbarOption == TB_TOOLBARANDMENU);

		// tab bar
		bResizeDlg |= (bAutoHideTabbar != Prefs().GetAutoHideTabbar());

		if (bStackTabbar != Prefs().GetStackTabbarItems())
		{
			bResizeDlg = TRUE;
			m_tabCtrl.ModifyStyle(!bStackTabbar ? 0 : TCS_MULTILINE, !bStackTabbar ? TCS_MULTILINE : 0);
		}

		UpdateCaption();
		UpdateTabSwitchTooltip();

		// active tasklist prefs
		UpdateToDoCtrlPreferences();

		if (bResizeDlg)
			ResizeDlg();
	}
}

BOOL CToDoListDlg::IsReadOnly(const TDCITEM& tdci) const
{
    LPCTSTR szPath = tdci.pTDC->GetFilePath();
	BOOL bReadOnly = CDriveInfo::IsReadonlyPath(szPath) >  0;

    if (!bReadOnly)
        bReadOnly = (tdci.pTDC->CompareFileFormat() == TDCFF_NEWER);
	if (!bReadOnly)
		bReadOnly = (PathSupportsSourceControl(szPath) && !tdci.pTDC->IsCheckedOut());

	if (!bReadOnly && !Prefs().GetEnableSourceControl())
		bReadOnly = CToDoCtrl::IsUnderSourceControl(szPath);

	return bReadOnly;
}

void CToDoListDlg::CheckMinWidth()
{
	if (GetTDCCount())
	{
		CRect rTDC;
		GetToDoCtrl().GetClientRect(rTDC);
		int nMinWidth = GetToDoCtrl().GetMinWidth();
		
		if (rTDC.Width() < nMinWidth)
		{
			CRect rWindow;
			GetWindowRect(rWindow);
			
			SetWindowPos(NULL, 0, 0, rWindow.Width() - 1, rWindow.Height(), SWP_NOZORDER | SWP_NOMOVE);
		}
	}
}

void CToDoListDlg::ShowMenuBar(BOOL bShow, BOOL bResize)
{
	if (bShow) // showing menubar
	{
		CMenu menu;

		if (!menu.LoadMenu(IDR_MAINFRAME))
			return;

		if (!SetMenu(&menu))
			return;

		DrawMenuBar();
		menu.Detach();
	}
	else // showing toolbar
	{
		// destroy existing menu
		CMenu* pMenu = GetMenu();

		if (pMenu)
			pMenu->DestroyMenu();

		// and hide
		SetMenu(NULL);
	}

	// resize active todoctrl
	if (bResize)
		ResizeDlg();
}

BOOL CToDoListDlg::OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct) 
{
	switch (pCopyDataStruct->dwData)
	{
	case OPENTASKLIST:
		{
			LPCTSTR szFilePath = (LPCTSTR)pCopyDataStruct->lpData;
			OpenTaskList(szFilePath);
		}
		break;
	}
	
	return CDialog::OnCopyData(pWnd, pCopyDataStruct);
}

void CToDoListDlg::OnEditCopy() 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	tdc.Flush();
	tdc.CopySelectedTask();
}

void CToDoListDlg::OnEditCut() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	tdc.Flush();
	tdc.CutSelectedTask();
}

void CToDoListDlg::OnUpdateEditCut(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();

	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount);	
}

void CToDoListDlg::OnEditPasteSub() 
{
	GetToDoCtrl().PasteOnSelectedTask();
}

void CToDoListDlg::OnUpdateEditPasteSub(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();

	// modify the text appropriately if the tasklist is empty
	if (nSelCount == 0)
		pCmdUI->SetText("Paste as a Top-level Task");

	pCmdUI->Enable(!tdc.IsReadOnly() && tdc.CanPaste());	
}

void CToDoListDlg::OnEditPasteAfter() 
{
	GetToDoCtrl().PasteAfterSelectedTask();
}

void CToDoListDlg::OnUpdateEditPasteAfter(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();

	pCmdUI->Enable(!tdc.IsReadOnly() && tdc.CanPaste() && nSelCount == 1);	
}

void CToDoListDlg::OnEditCopyastext() 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	tdc.Flush();
	tdc.CopySelectedTaskToClipboardAsText(Prefs().GetExportVisibleOnly(), Prefs().GetTextIndent());
}

void CToDoListDlg::OnEditCopyashtml() 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	tdc.Flush();
	tdc.CopySelectedTaskToClipboardAsHtml(Prefs().GetExportVisibleOnly(), Prefs().GetHtmlFont());
}

void CToDoListDlg::OnUpdateEditCopy(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetSelectedCount() > 0);
}

void CToDoListDlg::OnUpdateNewtaskAttopSelected(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();

	// enable this when the tasklist is empty even if no 
	// item is selected.
	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount <= 1);
}

void CToDoListDlg::OnUpdateNewtaskAtbottomSelected(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();

	// enable this when the tasklist is empty even if no 
	// item is selected.
	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount <= 1);
}

void CToDoListDlg::OnUpdateNewtaskAfterselectedtask(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();

	// enable this when the tasklist is empty even if no 
	// item is selected.
	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount <= 1);
}

void CToDoListDlg::OnUpdateNewtaskBeforeselectedtask(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();

	// enable this when the tasklist is empty even if no 
	// item is selected.
	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount <= 1);
}

void CToDoListDlg::OnUpdateNewsubtaskAttop(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();

	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount <= 1);
}

void CToDoListDlg::OnSimplemode() 
{
	m_bSimpleMode = !m_bSimpleMode;

	GetToDoCtrl().SetStyle(TDCS_SIMPLEMODE, m_bSimpleMode);	
}

void CToDoListDlg::OnUpdateSimplemode(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bSimpleMode ? 1 : 0);
}

void CToDoListDlg::OnReload() 
{
	TDCITEM& tdci = GetTDCItem();

	if (tdci.pTDC->IsModified())
	{ 
		if (IDNO == MessageBox("If you reload the tasklist you will lose your current \nchanges."
								"\n\nAre you sure you want to continue?",
								ABBREVCOPYRIGHT, MB_YESNO | MB_DEFBUTTON2))
		{
			return;
		}
	}

	// else reload
	ReloadTaskList(tdci);
}

void CToDoListDlg::ReloadTaskList(TDCITEM& tdci)
{
	if (OpenTaskList(tdci.pTDC) == TDCO_SUCCESS)
	{
		// update file status
		if (Prefs().GetAutoCheckOut())
			tdci.bLastCheckoutSuccess = tdci.pTDC->IsCheckedOut();

		tdci.tLastMod = GetLastModified(tdci.GetFilePath());
		tdci.bModified = FALSE;
		
		// notify user of due tasks if req
		DoDueTaskNotification(tdci.pTDC);

		UpdateCaption();
		UpdateStatusbar();
		UpdateDefaultSortItem();
	}
}

void CToDoListDlg::OnUpdateReload(CCmdUI* pCmdUI) 
{
	TDCITEM& tdci = GetTDCItem();

	pCmdUI->Enable(!tdci.GetFilePath().IsEmpty());
}

void CToDoListDlg::OnArchiveCompletedtasks() 
{
	TDC_ARCHIVE nRemove = TDC_REMOVENONE;

	if (Prefs().GetRemoveArchivedTasks())
	{
		if (Prefs().GetRemoveOnlyOnAbsoluteCompletion())
			nRemove = TDC_REMOVEIFSIBLINGSANDSUBTASKSCOMPLETE;
		else
			nRemove = TDC_REMOVEALL;
	}

	if (GetToDoCtrl().ArchiveDoneTasks(GetArchivePath(GetTDCItem().GetFilePath()), nRemove) > 0)
	{
		UpdateCaption();
	}
}

void CToDoListDlg::OnUpdateArchiveCompletedtasks(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!GetToDoCtrl().IsReadOnly() && !GetArchivePath(GetTDCItem().GetFilePath()).IsEmpty());
}

void CToDoListDlg::OnExportTohtml() 
{
	DoSaveAs(SAVEASHTM);
}

void CToDoListDlg::OnUpdateExportTohtml(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetTaskCount());
}

void CToDoListDlg::OnExportToplaintext() 
{
	DoSaveAs(SAVEASTXT);
}

void CToDoListDlg::OnUpdateExportToplaintext(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetTaskCount());
}

void CToDoListDlg::OnPrint() 
{
	// export to html and then print in IE
	char szTempFile[MAX_PATH], szTempPath[MAX_PATH];
	
	if (!::GetTempPath(MAX_PATH, szTempPath))
		return;
	
	// always use the same file
	_makepath(szTempFile, NULL, szTempPath, "ToDoList.print", "html");
	
	if (!Export2Html(&GetToDoCtrl(), szTempFile, FALSE))
		return;
	
	// print from browser
	int nRes = (int)ShellExecute(*this, "print", szTempFile, NULL, NULL, SW_HIDE);
				
	if (nRes < 32)
	{
		CString sMessage("ToDoList was unable to print the active tasklist via your default "
						"browser, which probably means that your browser does not support the "
						"'print' command.\n\nPlease see your browser help for more information.");
		
		MessageBox(sMessage, "Tasklist could not be printed", MB_OK);
	}
}

void CToDoListDlg::OnUpdatePrint(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetTaskCount());
}

void CToDoListDlg::OnMovetaskdown() 
{
	m_tbHelper.SetDefaultMenuID(ID_MOVETASK, ID_MOVETASKDOWN);

	GetToDoCtrl().MoveSelectedTask(MOVE_DOWN);	
}

void CToDoListDlg::OnUpdateMovetaskdown(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanMoveSelectedTask(MOVE_DOWN));	
}

void CToDoListDlg::OnMovetaskup() 
{
	m_tbHelper.SetDefaultMenuID(ID_MOVETASK, ID_MOVETASKUP);

	GetToDoCtrl().MoveSelectedTask(MOVE_UP);	
}

void CToDoListDlg::OnUpdateMovetaskup(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanMoveSelectedTask(MOVE_UP));	
}

void CToDoListDlg::OnMovetaskright() 
{
	m_tbHelper.SetDefaultMenuID(ID_MOVETASK, ID_MOVETASKRIGHT);

	GetToDoCtrl().MoveSelectedTask(MOVE_RIGHT);	
}

void CToDoListDlg::OnUpdateMovetaskright(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanMoveSelectedTask(MOVE_RIGHT));	
}

void CToDoListDlg::OnMovetaskleft() 
{
	m_tbHelper.SetDefaultMenuID(ID_MOVETASK, ID_MOVETASKLEFT);

	GetToDoCtrl().MoveSelectedTask(MOVE_LEFT);	
}

void CToDoListDlg::OnUpdateMovetaskleft(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanMoveSelectedTask(MOVE_LEFT));	
}

CToDoCtrl& CToDoListDlg::GetToDoCtrl()
{
	return GetToDoCtrl(GetSelToDoCtrl());
}

CToDoCtrl& CToDoListDlg::GetToDoCtrl(int nIndex)
{
	ASSERT (nIndex >= 0);
	ASSERT (nIndex < GetTDCCount());

	return *(m_aToDoCtrls[nIndex].pTDC);
}

CToDoListDlg::TDCITEM& CToDoListDlg::GetTDCItem()
{
	return GetTDCItem(GetSelToDoCtrl());
}

CToDoListDlg::TDCITEM& CToDoListDlg::GetTDCItem(int nIndex)
{
	ASSERT (nIndex >= 0);
	ASSERT (nIndex < GetTDCCount());

	return m_aToDoCtrls[nIndex];
}

CToDoCtrl* CToDoListDlg::NewToDoCtrl()
{
	CToDoCtrl* pCtrl = NULL;
	BOOL bReuse = FALSE;
	
	// if the active tasklist is untitled and unmodified then reuse it
	if (GetTDCCount())
	{
		TDCITEM& tdci = GetTDCItem();
		
		// make sure that we don't accidently reuse a just edited tasklist
		tdci.pTDC->Flush(); 

		if (tdci.GetFilePath().IsEmpty() && !tdci.bModified)
		{
			pCtrl = tdci.pTDC;

			m_aToDoCtrls.RemoveAt(GetSelToDoCtrl());
			m_tabCtrl.DeleteItem(GetSelToDoCtrl());

			return pCtrl;
		}
	}

	// else
	pCtrl = new CToDoCtrl;

	if (pCtrl && CreateToDoCtrl(pCtrl))
		return pCtrl;

	// else
	delete pCtrl;
	return NULL;
}

BOOL CToDoListDlg::CreateToDoCtrl(CToDoCtrl* pCtrl)
{
	CRect rToDo;
	GetDlgItem(IDC_TODOFRAME)->GetWindowRect(rToDo);
	ScreenToClient(rToDo);
	
	if (pCtrl->Create(rToDo, this, IDC_TODOLIST, FALSE))
	{
		if (!m_ilToDoCtrl.GetSafeHandle())
			InitCheckboxImageList();

		UpdateToDoCtrlPreferences(pCtrl);

		return TRUE;
	}

	return FALSE;
}

BOOL CToDoListDlg::InitCheckboxImageList()
{
	if (m_ilToDoCtrl.GetSafeHandle())
		return TRUE;

	CBitmap image;

	if (image.LoadBitmap(IDB_TODO))
	{
		BITMAP BM;
		image.GetBitmap(&BM);

		if (m_ilToDoCtrl.Create(BM.bmWidth / 3, BM.bmHeight, ILC_COLOR32 | ILC_MASK, 0, 1))
			m_ilToDoCtrl.Add(&image, 255);
	}

	return (NULL != m_ilToDoCtrl.GetSafeHandle());
}

int CToDoListDlg::AddToDoCtrl(CToDoCtrl* pCtrl) 
{
	TDCITEM tdci(pCtrl);

	int nSel = m_aToDoCtrls.Add(tdci);

	m_tabCtrl.InsertItem(nSel, "");
	SelectToDoCtrl(nSel);

	// make sure size is right
	ResizeDlg();

	return nSel;
}

void CToDoListDlg::OnSelchangeTabcontrol(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// show the incoming selection
	int nCurSel = GetSelToDoCtrl();

	if (nCurSel != -1)
	{
		UpdateToDoCtrlPreferences();
		UpdateDefaultSortItem();

		CToDoCtrl& tdc = GetToDoCtrl(nCurSel);

		tdc.EnableWindow(TRUE);
		tdc.SetFocus();
		tdc.ShowWindow(SW_SHOW);
	
		// make sure size is right
		ResizeDlg();

		// update status bar
		UpdateStatusbar();
		UpdateCaption();
	}
	
	// hide the outgoing selection
	if (m_nLastSelItem != -1)
	{
		CToDoCtrl& tdc = GetToDoCtrl(m_nLastSelItem);

		tdc.ShowWindow(SW_HIDE);
		tdc.EnableWindow(FALSE);

		m_nLastSelItem = -1; // reset
	}

	*pResult = 0;
}

void CToDoListDlg::OnSelchangingTabcontrol(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// cache the outgoing selection
	m_nLastSelItem = GetSelToDoCtrl();

	// and flush
	if (m_nLastSelItem != -1)
		GetToDoCtrl(m_nLastSelItem).Flush();

	*pResult = 0;
}

BOOL CToDoListDlg::ConfirmSaveTaskList(TDCITEM& tdci, BOOL bClosingTaskList, BOOL bClosingDown)
{
	bClosingTaskList |= bClosingDown; // sanity check

	// save changes
	if (tdci.pTDC->IsModified())
	{
		if (bClosingTaskList && (tdci.GetFilePath().IsEmpty() || Prefs().GetConfirmSaveOnExit()))
		{
			CString sMessage;
			sMessage.Format("Would you like to save the changes to '%s' \nbefore closing?", 
							tdci.pTDC->GetFriendlyProjectName());
			
			// don't allow user to cancel if closing down
			int nRet = MessageBox(sMessage, ABBREVCOPYRIGHT, bClosingDown ? MB_YESNO : MB_YESNOCANCEL);
			
			if (nRet == IDYES)
				SaveTaskList(tdci);
			
			else if (!bClosingDown && nRet == IDCANCEL)
				return FALSE;

			else if (nRet == IDNO)
				tdci.pTDC->SetModified(FALSE);
		}
		else
			SaveTaskList(tdci); 
	}

	return TRUE; // user did not cancel
}

BOOL CToDoListDlg::CloseToDoCtrl(int nIndex, BOOL bClosingDown)
{
	ASSERT (nIndex >= 0);
	ASSERT (nIndex < GetTDCCount());

	TDCITEM tdci = GetTDCItem(nIndex);
	int nSel = GetSelToDoCtrl(); // cache this

	tdci.pTDC->Flush();

	if (!ConfirmSaveTaskList(tdci, TRUE, bClosingDown))
		return FALSE;
	
	m_aToDoCtrls.RemoveAt(nIndex);
	m_tabCtrl.DeleteItem(nIndex);

	// checkin as our final task
	if (Prefs().GetCheckinOnClose() && PathSupportsSourceControl(tdci.GetFilePath()))
		tdci.pTDC->CheckIn();

	tdci.pTDC->DestroyWindow();
	delete tdci.pTDC;

	// make sure we reset the selection to a valid index
	if (nIndex == nSel && GetTDCCount())
	{
		// try leaving the selection as-is
		if (nSel >= GetTDCCount())
			nSel--; // try the preceding item

		SelectToDoCtrl(nSel);
	}

	if (!bClosingDown)
		ResizeDlg();

	return TRUE;
}

void CToDoListDlg::OnCloseTasklist() 
{
	// if there is only one list and its not been modified or saved
	// then leave as is
	// 01/06/2004 - disabled now that we create a default task
	// for new tasklists
/*	if (GetTDCCount() == 1)
	{
		TDCITEM& tdci = GetTDCItem();

		if (!tdci.bModified && tdci.GetFilePath().IsEmpty())
			return;
	}
*/
	// close
	CloseToDoCtrl(GetSelToDoCtrl(), FALSE);
	
	// if empty then create a new dummy item		
	if (!GetTDCCount())
		CreateNewTaskList(FALSE);
	else
		ResizeDlg();
}

BOOL CToDoListDlg::SelectToDoCtrl(LPCTSTR szFilePath)
{
	if (!szFilePath || !lstrlen(szFilePath))
		return FALSE;

	int nCtrl = GetTDCCount();

	while (nCtrl--)
	{
		if (GetTDCItem(nCtrl).GetFilePath().CompareNoCase(szFilePath) == 0)
		{
			SelectToDoCtrl(nCtrl);
			return TRUE;
		}
	}

	return FALSE;
}

void CToDoListDlg::SelectToDoCtrl(int nIndex)
{
	ASSERT (nIndex >= 0);
	ASSERT (nIndex < GetTDCCount());

	int nCurSel = GetSelToDoCtrl();

	m_tabCtrl.SetCurSel(nIndex); // this changes the selected CToDoCtrl

	if (!m_bClosing)
	{
		// make sure size is right
		ResizeDlg();

		UpdateToDoCtrlPreferences();
		UpdateDefaultSortItem();
	}

	// show the chosen item
	CToDoCtrl& tdc = GetToDoCtrl();

	tdc.EnableWindow(TRUE);
	tdc.SetFocus();
	tdc.ShowWindow(SW_SHOW);

	// before hiding the previous selection
	if (nCurSel != -1 && nCurSel != nIndex)
	{
		CToDoCtrl& tdc = GetToDoCtrl(nCurSel);

		tdc.ShowWindow(SW_HIDE);
		tdc.EnableWindow(FALSE);
	}

	if (!m_bClosing)
	{
		OnTimerReadOnlyStatus(nIndex);
		OnTimerTimestampChange(nIndex);
		OnTimerCheckoutStatus(nIndex);
	}

	UpdateCaption();
	UpdateStatusbar();
}

void CToDoListDlg::UpdateToDoCtrlPreferences(CToDoCtrl* pCtrl)
{
	CPreferencesDlg& pref = Prefs();
	CToDoCtrl& tdc = *pCtrl;

	CTDCStyles styles;
	
	DWORD dwTick = GetTickCount();

	styles[TDCS_COLORTEXTBYPRIORITY] = pref.GetColorTextByPriority();
	styles[TDCS_SHOWINFOTIPS] = pref.GetShowInfoTips();
	styles[TDCS_SHOWCOMMENTSINLIST] = pref.GetShowComments();
	styles[TDCS_COLORPRIORITY] = pref.GetColorPriority();
	styles[TDCS_TREATSUBCOMPLETEDASDONE] = pref.GetTreatSubCompletedAsDone();
	styles[TDCS_HIDEPERCENTFORDONETASKS] = pref.GetHidePercentForDoneTasks();
	styles[TDCS_HIDESTARTDUEFORDONETASKS] = pref.GetHideStartDueForDoneTasks();
	styles[TDCS_HIDEZEROTIMEEST] = pref.GetHideZeroTimeEst();
	styles[TDCS_CONFIRMDELETE] = pref.GetConfirmDelete();
	styles[TDCS_AVERAGEPERCENTSUBCOMPLETION] = pref.GetAveragePercentSubCompletion();
	styles[TDCS_INCLUDEDONEINAVERAGECALC] = pref.GetIncludeDoneInAverageCalc();
	styles[TDCS_SHOWBUTTONSINTREE] = pref.GetShowButtonsInTree();
	styles[TDCS_USEEARLIESTDUEDATE] = pref.GetUseEarliestDueDate();
	styles[TDCS_USEPERCENTDONEINTIMEEST] = pref.GetUsePercentDoneInTimeEst();
	styles[TDCS_SHOWCTRLSASCOLUMNS] = pref.GetShowCtrlsAsColumns();
	styles[TDCS_SHOWCOMMENTSALWAYS] = pref.GetShowCommentsAlways();
	styles[TDCS_AUTOREPOSCTRLS] = pref.GetAutoReposCtrls();
	styles[TDCS_SHOWPERCENTASPROGRESSBAR] = pref.GetShowPercentAsProgressbar();
	styles[TDCS_QUERYAPPLYCHANGESTOSUBTASKS] = pref.GetQueryApplyChangestoSubtasks();
	styles[TDCS_STRIKETHOUGHDONETASKS] = pref.GetStrikethroughDone();
	styles[TDCS_SHOWPATHINHEADER] = pref.GetShowPathInHeader();
	styles[TDCS_FULLROWSELECTION] = pref.GetFullRowSelection();
	styles[TDCS_TREECHECKBOXES] = pref.GetTreeCheckboxes();
	styles[TDCS_COLUMNHEADERCLICKING] = pref.GetEnableHeaderSorting();
	styles[TDCS_SORTVISIBLETASKSONLY] = pref.GetSortVisibleOnly();
	styles[TDCS_SHAREDCOMMENTSHEIGHT] = pref.GetSharedCommentsHeight();
	styles[TDCS_TASKCOLORISBACKGROUND] = pref.GetColorTaskBackground();
	styles[TDCS_COMMENTSUSETREEFONT] = pref.GetCommentsUseTreeFont();
	styles[TDCS_SHOWDATESINISO] = pref.GetDisplayDatesInISO();
	styles[TDCS_USEHIGHESTPRIORITY] = pref.GetUseHighestPriority();
	styles[TDCS_AUTOCALCTIMEESTIMATES] = pref.GetAutoCalcTimeEstimates();
	styles[TDCS_SHOWWEEKDAYINDATES] = pref.GetShowWeekdayInDates();
	styles[TDCS_ROUNDTIMEFRACTIONS] = pref.GetRoundTimeFractions();
	styles[TDCS_SHOWNONFILEREFSASTEXT] = pref.GetShowNonFilesAsText();
	styles[TDCS_INCLUDEDONEINPRIORITYCALC] = pref.GetIncludeDoneInPriorityCalc();
	styles[TDCS_WEIGHTPERCENTCALCBYTIMEEST] = pref.GetWeightPercentCompletionByTimeEst();
	styles[TDCS_WEIGHTPERCENTCALCBYPRIORITY] = pref.GetWeightPercentCompletionByPriority();
	styles[TDCS_RIGHTALIGNLABELS] = pref.GetRightAlignLabels();
	styles[TDCS_SHOWPARENTSASFOLDERS] = pref.GetShowParentsAsFolders();
	styles[TDCS_FOCUSTREEONENTER] = pref.GetFocusTreeOnEnter();
	styles[TDCS_AUTOCALCPERCENTDONE] = pref.GetAutoCalcPercentDone();
	styles[TDCS_TRACKSELECTEDTASKONLY] = pref.GetTrackSelectedTaskOnly();
	styles[TDCS_HIDEPRIORITYNUMBER] = pref.GetHidePriorityNumber();
	styles[TDCS_SIMPLEMODE] = m_bSimpleMode;
	styles[TDCS_PAUSETIMETRACKINGONSCRNSAVER] = pref.GetPauseTimeTrackingOnScrnSaver();
	styles[TDCS_SHOWFIRSTCOMMENTLINEINLIST] = pref.GetDisplayFirstCommentLine();

	// source control
	styles[TDCS_ENABLESOURCECONTROL] = PathSupportsSourceControl(tdc.GetFilePath());
	styles[TDCS_CHECKOUTONLOAD] = pref.GetAutoCheckOut();

	tdc.SetStyles(styles);

	TRACE("CToDoListDlg::UpdateToDoCtrlPreferences(styles) took %d ms\n", GetTickCount() - dwTick);
	dwTick = GetTickCount();

	tdc.ShowColumn(TDCC_POSITION, pref.GetShowColumn(PTPC_POSITION));
	tdc.ShowColumn(TDCC_ID, pref.GetShowColumn(PTPC_ID));
	tdc.ShowColumn(TDCC_PERCENT, pref.GetShowColumn(PTPC_PERCENT));
	tdc.ShowColumn(TDCC_PRIORITY, pref.GetShowColumn(PTPC_PRIORITY));
	tdc.ShowColumn(TDCC_TIMEEST, pref.GetShowColumn(PTPC_TIMEEST));
	tdc.ShowColumn(TDCC_TIMESPENT, pref.GetShowColumn(PTPC_TIMESPENT));
	tdc.ShowColumn(TDCC_STARTDATE, pref.GetShowColumn(PTPC_STARTDATE));
	tdc.ShowColumn(TDCC_DUEDATE, pref.GetShowColumn(PTPC_DUEDATE));
	tdc.ShowColumn(TDCC_DONEDATE, pref.GetShowColumn(PTPC_DONEDATE));
	tdc.ShowColumn(TDCC_ALLOCTO, pref.GetShowColumn(PTPC_ALLOCTO));
	tdc.ShowColumn(TDCC_ALLOCBY, pref.GetShowColumn(PTPC_ALLOCBY));
	tdc.ShowColumn(TDCC_STATUS, pref.GetShowColumn(PTPC_STATUS));
	tdc.ShowColumn(TDCC_CATEGORY, pref.GetShowColumn(PTPC_CATEGORY));
	tdc.ShowColumn(TDCC_FILEREF, pref.GetShowColumn(PTPC_FILEREF));
	tdc.ShowColumn(TDCC_DONE, pref.GetShowColumn(PTPC_DONE));
	tdc.ShowColumn(TDCC_TRACKTIME, pref.GetShowColumn(PTPC_TRACKTIME));

	TRACE("CToDoListDlg::UpdateToDoCtrlPreferences(columns) took %d ms\n", GetTickCount() - dwTick);
	dwTick = GetTickCount();

	// update default task preferences
	int nUnits;
	double dTimeEst = Prefs().GetDefaultTimeEst(nUnits);

	tdc.SetDefaultTaskAttributes("Task", NULL, pref.GetDefaultColor(),
								dTimeEst, nUnits, pref.GetDefaultAllocTo(),
								pref.GetDefaultAllocBy(), pref.GetDefaultStatus(),
								pref.GetDefaultCategory(), pref.GetDefaultPriority(),
								pref.GetDefaultStartDate());

	CheckMinWidth();

	CString sTreeFont;
	int nFontSize;

	if (pref.GetTreeFont(sTreeFont, nFontSize))
		tdc.SetTreeFont(sTreeFont, nFontSize);
	else
		tdc.SetTreeFont(NULL);

	tdc.SetGridlineColor(pref.GetGridlineColor());
	tdc.SetTaskCompletedColor(pref.GetTaskDoneColor());
	tdc.SetAlternateLineColor(pref.GetAlternateLineColor());

	// checkbox images
	tdc.SetCheckImageList(&m_ilToDoCtrl);
	
	CDWordArray aColors;
	pref.GetPriorityColors(aColors);
	tdc.SetPriorityColors(aColors);

	// finally set or terminate the various status check timers
	SetTimer(TIMER_READONLYSTATUS, pref.GetReadonlyReloadOption() != RO_NO);
	SetTimer(TIMER_TIMESTAMPCHANGE, pref.GetTimestampReloadOption() != RO_NO);
	SetTimer(TIMER_CHECKOUTSTATUS, pref.GetCheckoutOnCheckin());
	SetTimer(TIMER_AUTOSAVE, pref.GetAutoSaveFrequency());

	TRACE("CToDoListDlg::UpdateToDoCtrlPreferences(rest) took %d ms\n", GetTickCount() - dwTick);
}

void CToDoListDlg::UpdateTabSwitchTooltip()
{
	CToolTipCtrl* pTT = m_tabCtrl.GetToolTips();

	if (pTT)
	{
		// get the string for tab switching
		CString sShortcut = m_mgrShortcuts.GetShortcutTextByCmd(ID_VIEW_NEXT);

		if (sShortcut.IsEmpty())
			sShortcut = m_mgrShortcuts.GetShortcutTextByCmd(ID_VIEW_PREV);

		pTT->DelTool(&m_tabCtrl); // always

		if (!sShortcut.IsEmpty())
		{
			sShortcut = "Use '" + sShortcut + "' to switch tasklists";
			pTT->AddTool(&m_tabCtrl, sShortcut);
		}
	}
}

void CToDoListDlg::SetTimer(UINT nTimerID, BOOL bOn)
{
	if (bOn)
	{
		UINT nPeriod = 0;
		
		switch (nTimerID)
		{
		case TIMER_READONLYSTATUS:
			nPeriod = INTERVAL_READONLYSTATUS;
			break;
			
		case TIMER_TIMESTAMPCHANGE:
			nPeriod = INTERVAL_TIMESTAMPCHANGE;
			break;
			
		case TIMER_AUTOSAVE:
			nPeriod = Prefs().GetAutoSaveFrequency() * 60000;
			break;
			
		case TIMER_CHECKOUTSTATUS:
			nPeriod = INTERVAL_CHECKOUTSTATUS;
			break;
			
		case TIMER_DUEITEMS:
			nPeriod = INTERVAL_DUEITEMS;
			break;
		}
		
		if (nPeriod)
		{
			UINT nID = CDialog::SetTimer(nTimerID, nPeriod, NULL);
			ASSERT (nID);
		}
	}
	else
		KillTimer(nTimerID);
}

void CToDoListDlg::OnSaveall() 
{
	SaveAll(FALSE, FALSE, TRUE);
}

void CToDoListDlg::OnUpdateSaveall(CCmdUI* pCmdUI) 
{
	int nCtrl = GetTDCCount();

	while (nCtrl--)
	{
		if (GetTDCItem(nCtrl).pTDC->IsModified())
		{
			pCmdUI->Enable();
			return;
		}
	}

	// else nothing modified
	pCmdUI->Enable(FALSE);
}

void CToDoListDlg::OnCloseall() 
{
	// delete tasklists
	int nCtrl = GetTDCCount();

	while (nCtrl--)
		CloseToDoCtrl(nCtrl, FALSE);

	// if empty then create a new dummy item		
	if (!GetTDCCount())
		CreateNewTaskList(FALSE);
	else
		ResizeDlg();
}

void CToDoListDlg::OnUpdateCloseall(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetTDCCount());
}

void CToDoListDlg::OnExit()
{
    OnClose();
}

void CToDoListDlg::OnUpdateExit(CCmdUI* pCmdUI)
{
    if (Prefs().GetSysTrayOption() == STO_ONCLOSE || Prefs().GetSysTrayOption() == STO_ONMINCLOSE)
        pCmdUI->SetText("Minimize to S&ystem Tray");
    else
        pCmdUI->SetText("E&xit ToDoList");
}

void CToDoListDlg::DoExit() 
{
    // save all first to ensure new tasklists get reloaded on startup
    if (!SaveAll(TRUE, FALSE, TRUE))
        return; // user cancelled
	
	SaveSettings(); // before we close the tasklists

	// delete tasklists
	CAutoFlag af(m_bClosing, TRUE);
	int nCtrl = GetTDCCount();
	
	while (nCtrl--)
	{
		if (!CloseToDoCtrl(nCtrl, FALSE))
			break;
	}
	
	// if there are any still open then the user must have cancelled else destroy the window
	if (!GetTDCCount())
		DestroyWindow();	
}

void CToDoListDlg::OnUpdateMovetask(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();

	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount == 1);	
}

void CToDoListDlg::OnTimer(UINT nIDEvent) 
{
	CDialog::OnTimer(nIDEvent);

	// if we are disabled (== modal dialog visible) then do not respond
	if (!IsWindowEnabled())
		return;

	// if no controls are active kill the timers
	if (!GetTDCCount())
	{
		SetTimer(TIMER_READONLYSTATUS, FALSE);
		SetTimer(TIMER_TIMESTAMPCHANGE, FALSE);
		SetTimer(TIMER_AUTOSAVE, FALSE);
		SetTimer(TIMER_CHECKOUTSTATUS, FALSE);
		return;
	}

	// don't check whilst in the middle of saving and prevent reentrancy
	if (m_bSaving || m_bInTimer)
		return;

	CAutoFlag af(m_bInTimer, TRUE);

	switch (nIDEvent)
	{
	case TIMER_READONLYSTATUS:
		OnTimerReadOnlyStatus();
		break;

	case TIMER_TIMESTAMPCHANGE:
		OnTimerTimestampChange();
		break;

	case TIMER_AUTOSAVE:
		OnTimerAutoSave();
		break;

	case TIMER_CHECKOUTSTATUS:
		OnTimerCheckoutStatus();
		break;

	case TIMER_DUEITEMS:
		OnTimerDueItems();
		break;
	}
}

void CToDoListDlg::OnTimerDueItems(int nCtrl)
{
	SEARCHPARAMS sp;
	SEARCHRESULT result;

	sp.dwFlags = 0;
	sp.nFindWhat = FIND_DUEDATE;
	sp.dateTo = COleDateTime::GetCurrentTime();

	int nFrom = (nCtrl == -1) ? 0 : nCtrl;
	int nTo = (nCtrl == -1) ? nCtrl : GetTDCCount() - 1;
	BOOL bRepaint = FALSE;
	
	for (nCtrl = nFrom; nCtrl <= nTo; nCtrl++)
	{
		TDCITEM& tdci = GetTDCItem(nCtrl);

		BOOL bDueItems = tdci.pTDC->FindFirstTask(sp, result);

		if (bDueItems != tdci.bDueItems)
		{
			tdci.bDueItems = bDueItems;
			bRepaint = TRUE;
		}
	}

	if (bRepaint)
		m_tabCtrl.Invalidate(FALSE);
}

void CToDoListDlg::OnTimerReadOnlyStatus(int nCtrl)
{
	CPreferencesDlg& prefs = Prefs();
	
	// work out whether we should check remote files or not
	BOOL bCheckRemoteFiles = (nCtrl != -1);

	if (!bCheckRemoteFiles)
	{
		static nElapsed = 0;
		UINT nRemoteFileCheckInterval = prefs.GetRemoteFileCheckFrequency() * 1000; // in ms

		nElapsed %= nRemoteFileCheckInterval;
		bCheckRemoteFiles = !nElapsed;
		
		nElapsed += INTERVAL_READONLYSTATUS;
	}
	
	int nReloadOption = prefs.GetReadonlyReloadOption();
	
	ASSERT (nReloadOption != RO_NO);
	
	// process files
	CString sFileList;
	int nFrom = (nCtrl == -1) ? 0 : nCtrl;
	int nTo = (nCtrl == -1) ? nCtrl : GetTDCCount() - 1;
	
	for (nCtrl = nFrom; nCtrl <= nTo; nCtrl++)
	{
		TDCITEM& tdci = GetTDCItem(nCtrl);
		
		// don't check removeable drives
        if (tdci.IsPathType(TDCITEM::UNDEF) ||
			tdci.IsPathType(TDCITEM::REMOVABLE))
			continue;
		
		// check remote files
		if (!bCheckRemoteFiles && tdci.IsPathType(TDCITEM::REMOTE))
			continue;

		CString sFilePath = tdci.GetFilePath();
		BOOL bLastStatusReadOnly = tdci.bLastStatusReadOnly;
		tdci.bLastStatusReadOnly = CDriveInfo::IsReadonlyPath(sFilePath);
		
		if (bLastStatusReadOnly != -1 && tdci.bLastStatusReadOnly != -1 &&
			bLastStatusReadOnly != tdci.bLastStatusReadOnly)
		{
			BOOL bReload = FALSE;

			if (nReloadOption == RO_ASK)
			{
				CString sMessage;
				sMessage.Format("The status of the file '%s' has changed \nfrom '%s' to '%s'.", 
								sFilePath, tdci.bLastStatusReadOnly ? "writable" : "read-only", 
								tdci.bLastStatusReadOnly ? "read-only" : "writable");
								
				if (!tdci.bLastStatusReadOnly) // might been modified
					sMessage += "\n\nWould you like to reload the it?";
					
				bReload = (MessageBox(sMessage, ABBREVCOPYRIGHT, !tdci.bLastStatusReadOnly ? MB_YESNO : MB_OK) == IDYES);
			}
			else
				bReload = !tdci.bLastStatusReadOnly; // now writable
				
			if (bReload)
			{
				ReloadTaskList(tdci);

				// notify the user if we haven't already and the trayicon is visible
				if (nReloadOption != RO_ASK && prefs.GetSysTrayOption() != STO_NONE)
				{
					sFileList += tdci.pTDC->GetFriendlyProjectName();
					sFilePath += "\n";
				}
			}
			else // update the UI
			{
				UpdateTabItemText(nCtrl);
				
				if (nCtrl == m_tabCtrl.GetCurSel())
				{
					UpdateCaption();
					tdci.pTDC->SetReadonly(IsReadOnly(tdci.pTDC));
				}
			}
		}
	}

	// do we need to notify the user?
	// don't if they are busy typing
	if (!sFileList.IsEmpty() && !CWinClasses::IsEditControl(::GetFocus()))
	{
		CString sMessage;
		sMessage.Format("The following tasklists have been reloaded:\n\n%s", sFileList);
//		m_ti.ShowBalloon(sMessage, "Readonly Status Change", NIIF_INFO);
	}
}

void CToDoListDlg::OnTimerTimestampChange(int nCtrl)
{
	CPreferencesDlg& prefs = Prefs();
	int nReloadOption = prefs.GetTimestampReloadOption();
	
	ASSERT (nReloadOption != RO_NO);

	// work out whether we should check remote files or not
	BOOL bCheckRemoteFiles = (nCtrl != -1);

	if (!bCheckRemoteFiles)
	{
		static nElapsed = 0;
		UINT nRemoteFileCheckInterval = prefs.GetRemoteFileCheckFrequency() * 1000; // in ms


		nElapsed %= nRemoteFileCheckInterval;
		bCheckRemoteFiles = !nElapsed;
		
		nElapsed += INTERVAL_TIMESTAMPCHANGE;
	}

	// process files
	CString sFileList;
	int nFrom = (nCtrl == -1) ? 0 : nCtrl;
	int nTo = (nCtrl == -1) ? nCtrl : GetTDCCount() - 1;
	
	for (nCtrl = nFrom; nCtrl <= nTo; nCtrl++)
	{
		TDCITEM& tdci = GetTDCItem(nCtrl);
		CString sFilePath = tdci.GetFilePath();

		// don't check removeable drives
		if (tdci.IsPathType(TDCITEM::UNDEF) || tdci.IsPathType(TDCITEM::REMOVABLE))
			continue;
		
		// check remote files
		if (!bCheckRemoteFiles && tdci.IsPathType(TDCITEM::REMOTE))
			continue;
		
		time_t tLastMod = tdci.tLastMod;
		time_t tCurMod = GetLastModified(sFilePath); // can be 0 if file is no longer accessible
		
		tdci.tLastMod = tCurMod;
		
		if (tLastMod != 0 && tCurMod != 0 && tLastMod < tCurMod)
		{
			BOOL bReload = TRUE; // default

			if (nReloadOption == RO_ASK)
			{
				CString sMessage;
				sMessage.Format("The file '%s' has been modified outside of ToDoList."
								"\n\nWould you like to reload it?", 
								sFilePath);
				
				bReload = (MessageBox(sMessage, ABBREVCOPYRIGHT, MB_YESNO) == IDYES);
			}

			if (bReload)
			{
				ReloadTaskList(tdci);

				// notify the user if we haven't already and the trayicon is visible
				if (nReloadOption != RO_ASK && prefs.GetSysTrayOption() != STO_NONE)
				{
					sFileList += tdci.pTDC->GetFriendlyProjectName();
					sFilePath += "\n";
				}

				// update UI
				UpdateTabItemText(nCtrl);
					
				if (nCtrl == m_tabCtrl.GetCurSel())
				{
					UpdateCaption();
					tdci.pTDC->SetReadonly(IsReadOnly(tdci.pTDC));
				}
			}
		}
	}

	// do we need to notify the user?
	// but not if they are busy typing
	if (!sFileList.IsEmpty() && !CWinClasses::IsEditControl(::GetFocus()))
	{
		CString sMessage;
		sMessage.Format("The following tasklists have been reloaded:\n\n%s", sFileList);
//		m_ti.ShowBalloon(sMessage, "File Timestamp Change", NIIF_INFO);
	}
}

void CToDoListDlg::OnTimerAutoSave()
{
	// don't save if the user is editing a task label
	if (!GetToDoCtrl().IsTreeLabelEditing())
		SaveAll(FALSE, FALSE, FALSE);
	else
		TRACE("Skipped auto save because of a label edit\n");
}

void CToDoListDlg::OnTimerCheckoutStatus(int nCtrl)
{
	CPreferencesDlg& prefs = Prefs();

	// work out whether we should check remote files or not
	BOOL bCheckRemoteFiles = (nCtrl != -1);

	if (!bCheckRemoteFiles)
	{
		static nElapsed = 0;
		UINT nRemoteFileCheckInterval = prefs.GetRemoteFileCheckFrequency() * 1000; // in ms

		nElapsed %= nRemoteFileCheckInterval;
		bCheckRemoteFiles = !nElapsed;
		
		nElapsed += INTERVAL_CHECKOUTSTATUS;
	}

	// process files
	CString sFileList;
	int nFrom = (nCtrl == -1) ? 0 : nCtrl;
	int nTo = (nCtrl == -1) ? nCtrl : GetTDCCount() - 1;
	
	for (nCtrl = nFrom; nCtrl <= nTo; nCtrl++)
	{
		TDCITEM& tdci = GetTDCItem(nCtrl);

		if (!PathSupportsSourceControl(tdci.GetFilePath()))
            continue;

		// try to check out only if the previous attempt failed
		if (!tdci.bLastCheckoutSuccess && !tdci.pTDC->IsCheckedOut())
		{
            if (tdci.pTDC->CheckOut())
            {
                UpdateTabItemText(nCtrl);
                
                // update timestamp 
                CString sFilePath = tdci.GetFilePath();
                
                tdci.tLastMod = GetLastModified(sFilePath);
                tdci.bLastCheckoutSuccess = TRUE;
                
                if (nCtrl == m_tabCtrl.GetCurSel())
                {
                    UpdateCaption();
                    tdci.pTDC->SetReadonly(IsReadOnly(tdci.pTDC));
                }

				// notify the user if the trayicon is visible
				if (prefs.GetSysTrayOption() != STO_NONE)
				{
					sFileList += tdci.pTDC->GetFriendlyProjectName();
					sFilePath += "\n";
				}
            }
            else
                tdci.bLastCheckoutSuccess = FALSE;
		}
	}
	// do we need to notify the user?
	// but not if they are busy typing
	if (!sFileList.IsEmpty() && !CWinClasses::IsEditControl(::GetFocus()))
	{
		CString sMessage;
		sMessage.Format("The following tasklists have been checked out:\n\n%s", sFileList);
//		m_ti.ShowBalloon(sMessage, "Source Control Change", NIIF_INFO);
	}
}

void CToDoListDlg::OnImportTasklist() 
{
	CFileDialog dialog(TRUE, "xml", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, SAVEASXMLFILTER, this);
	
	dialog.m_ofn.lpstrTitle = "Import Task List";

	if (dialog.DoModal() == IDOK)
	{
		if (GetToDoCtrl().Import(dialog.GetPathName()))
		{
			UpdateCaption();
		}
		else
			MessageBox("The selected file does not appear to be a valid task list.", 
						ABBREVCOPYRIGHT, MB_OK);
	}
}


void CToDoListDlg::OnSetPriority(UINT nCmdID) 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	if (!tdc.IsReadOnly() && tdc.HasSelection())
		tdc.SetSelectedTaskPriority(nCmdID - ID_EDIT_SETPRIORITY0);
}

void CToDoListDlg::OnUpdateSetPriority(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nSelCount = tdc.GetSelectedCount();

	pCmdUI->Enable(!tdc.IsReadOnly() && nSelCount);

	if (nSelCount == 1)
		pCmdUI->SetCheck((int)(pCmdUI->m_nID - ID_EDIT_SETPRIORITY0) == tdc.GetSelectedTaskPriority());
	else
		pCmdUI->SetCheck(0);
}

void CToDoListDlg::OnEditSetfileref() 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	if (!tdc.IsReadOnly() && tdc.HasSelection())
	{
		CString sFileRef = tdc.GetSelectedTaskFileRef();

		CFileDialog dialog(TRUE, NULL, sFileRef, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "All Files (*.*)|*.*||");
		dialog.m_ofn.lpstrTitle = "Select File to which Task Refers";

		if (dialog.DoModal() == IDOK)
			tdc.SetSelectedTaskFileRef(dialog.GetPathName());
	}
}

void CToDoListDlg::OnUpdateEditSetfileref(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	pCmdUI->Enable(!tdc.IsReadOnly() && tdc.HasSelection());
}

void CToDoListDlg::OnEditOpenfileref() 
{
	GetToDoCtrl().GotoSelectedTaskFileRef();
}

void CToDoListDlg::OnUpdateEditOpenfileref(CCmdUI* pCmdUI) 
{
	CString sFileRef = GetToDoCtrl().GetSelectedTaskFileRef();

	if (sFileRef.IsEmpty())
		pCmdUI->Enable(FALSE);
	else
	{
		pCmdUI->Enable(TRUE);
		pCmdUI->SetText(sFileRef);
	}
}

void CToDoListDlg::OnUpdateUserTool1(CCmdUI* pCmdUI) 
{
	if (pCmdUI->m_pMenu)
	{
		CUserToolArray aTools;
		Prefs().GetUserTools(aTools);

      CToolsHelper th(ID_TOOLS_USERTOOL1);
      th.UpdateMenu(pCmdUI, aTools);
	}
	else if (m_nToolbarOption == TB_TOOLBARANDMENU) // just enable all items
	{
		for (UINT nToolID = ID_TOOLS_USERTOOL1; nToolID <= ID_TOOLS_USERTOOL16; nToolID++)
			m_toolbar.GetToolBarCtrl().EnableButton(nToolID);
	}
}
void CToDoListDlg::OnUserTool(UINT nCmdID) 
{
	int nTool = nCmdID - ID_TOOLS_USERTOOL1;
   USERTOOL ut;

   if (Prefs().GetUserTool(nTool, ut))
   {
      CToolsHelper th(ID_TOOLS_USERTOOL1);
      CToDoCtrl& tdc = GetToDoCtrl();
      CString sFullPath = tdc.GetFilePath();

      th.RunTool(ut, tdc.GetFilePath(), tdc.GetSelectedTaskID(), this);
   }
}

LRESULT CToDoListDlg::OnPreferencesTestTool(WPARAM wp, LPARAM lp)
{
   USERTOOL* pTool = (USERTOOL*)lp;

   if (pTool)
   {
      CToolsHelper th(ID_TOOLS_USERTOOL1);
      CToDoCtrl& tdc = GetToDoCtrl();
      
      th.TestTool(*pTool, tdc.GetFilePath(), tdc.GetSelectedTaskID(), &Prefs());
   }

   return 0;
}

void CToDoListDlg::OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu) 
{
	CDialog::OnInitMenuPopup(pPopupMenu, nIndex, bSysMenu);
	
	// we only need handle this for the main menu if the toolbar is not visible
	if ((m_nToolbarOption == TB_TOOLBARHIDDEN) || !bSysMenu)
		CToolbarHelper::PrepareMenuItems(pPopupMenu, this);	
}

void CToDoListDlg::OnViewNext() 
{
	if (GetTDCCount() < 2)
		return;

	int nNext = GetSelToDoCtrl() + 1;
					
	if (nNext >= GetTDCCount())
		nNext = 0;
					
	SelectToDoCtrl(nNext);
}

void CToDoListDlg::OnUpdateViewNext(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetTDCCount() > 1);
}

void CToDoListDlg::OnViewPrev() 
{
	if (GetTDCCount() < 2)
		return;

	int nPrev = GetSelToDoCtrl() - 1;
	
	if (nPrev < 0)
		nPrev = GetTDCCount() - 1;
	
	SelectToDoCtrl(nPrev);
}

void CToDoListDlg::OnUpdateViewPrev(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetTDCCount() > 1);
}

void CToDoListDlg::OnSysCommand(UINT nID, LPARAM lParam) 
{
	// we don't minimize if we're going to be hiding to then system tray
	if (nID == SC_MINIMIZE)
	{
		int nSysTrayOption = Prefs().GetSysTrayOption();

		if (nSysTrayOption == STO_ONMINIMIZE || nSysTrayOption == STO_ONMINCLOSE)
		{
			MinimizeToTray(Prefs().GetAutoSaveOnSysTray());
			return; // eat it
		}
	}
/*	else if (nID == SC_MAXIMIZE) 
	{
		HMONITOR hMonitor = MonitorFromWindow(GetSafeHwnd(), MONITOR_DEFAULTTONEAREST);
		ASSERT (hMonitor);

		if (hMonitor)
		{
			MONITORINFO mi; 
			mi.cbSize = sizeof(mi);

			GetMonitorInfo(hMonitor, &mi);

			CDialog::OnSysCommand(nID, lParam);

			SetWindowPos(NULL, mi.rcWork.left, mi.rcWork.top, 
							mi.rcWork.right - mi.rcWork.left,
							mi.rcWork.bottom - mi.rcWork.top,
							SWP_SHOWWINDOW);
			return;
		}
	}
*/
	// else
	CDialog::OnSysCommand(nID, lParam);
}

void CToDoListDlg::OnUpdateImport(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!GetToDoCtrl().IsReadOnly());
}

void CToDoListDlg::OnUpdateNewtask(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!GetToDoCtrl().IsReadOnly());
}

void CToDoListDlg::OnToolsCheckout() 
{
	CAutoFlag af(m_bSaving, TRUE);
	TDCITEM& tdci = GetTDCItem();

	if (!tdci.bLastStatusReadOnly)
	{
		CString sCheckedOutTo;

		if (tdci.pTDC->CheckOut(sCheckedOutTo))
		{
			tdci.pTDC->SetReadonly(FALSE);
			tdci.bLastCheckoutSuccess = TRUE;
			tdci.tLastMod = GetLastModified(tdci.GetFilePath());

			TRACE ("Checkout timestamp of '%s' = %d\n", tdci.GetFilePath(), tdci.tLastMod);

			UpdateCaption();
		}
		else // failed
		{
			tdci.bLastCheckoutSuccess = FALSE;

			// notify user
			CString sMessage;
			sMessage.Format("'%s' could not be checked out\nbecause it is currently checked out to '%s'", 
							tdci.GetFilePath(), sCheckedOutTo);

			MessageBox(sMessage, ABBREVCOPYRIGHT, MB_OK | MB_ICONEXCLAMATION);
		}
	}
}

void CToDoListDlg::OnUpdateToolsCheckout(CCmdUI* pCmdUI) 
{
	TDCITEM& tdci = GetTDCItem();

	BOOL bEnable = (tdci.pTDC->CompareFileFormat() != TDCFF_NEWER);

	if (bEnable)
	{
		bEnable &= PathSupportsSourceControl(tdci.GetFilePath());

		if (bEnable)
			bEnable &= (!tdci.bLastStatusReadOnly && !tdci.pTDC->IsCheckedOut());
	}

	pCmdUI->Enable(bEnable);
}

void CToDoListDlg::OnToolsToggleCheckin() 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	if (tdc.IsCheckedOut())
		OnToolsCheckin();
	else
		OnToolsCheckout();
}

void CToDoListDlg::OnUpdateToolsToggleCheckin(CCmdUI* pCmdUI) 
{
	BOOL bEnable = Prefs().GetEnableSourceControl();
	
	if (bEnable)
	{
		TDCITEM& tdci = GetTDCItem();

		bEnable &= (tdci.pTDC->CompareFileFormat() != TDCFF_NEWER);
		bEnable &= PathSupportsSourceControl(tdci.GetFilePath());
		bEnable &= (!tdci.bLastStatusReadOnly);

		if (bEnable)
			pCmdUI->SetCheck(tdci.pTDC->IsCheckedOut() ? 1 : 0);
	}

	pCmdUI->Enable(bEnable);
}

void CToDoListDlg::OnToolsCheckin() 
{
	CAutoFlag af(m_bSaving, TRUE);
	TDCITEM& tdci = GetTDCItem();

	if (!tdci.bLastStatusReadOnly && !tdci.pTDC->IsReadOnly())
	{
		ASSERT (!tdci.GetFilePath().IsEmpty());

		tdci.pTDC->Flush();

		// save modifications
		if (tdci.pTDC->IsModified())
		{
			if (Prefs().GetConfirmSaveOnExit())
			{
				int nRet = MessageBox("Would you like to save your changes before checking in?", 
										ABBREVCOPYRIGHT, MB_YESNOCANCEL);
				
				switch (nRet)
				{
				case IDYES:
					SaveTaskList(tdci);
					break;

				case IDNO:
					ReloadTaskList(tdci);
					break;

				case IDCANCEL:
					return;
				}
			}
			else
				SaveTaskList(tdci); 
		}

		if (tdci.pTDC->CheckIn())	
		{
			tdci.pTDC->SetReadonly(TRUE);
			tdci.tLastMod = GetLastModified(tdci.GetFilePath());
			UpdateCaption();
		}
	}
	
	tdci.bLastCheckoutSuccess = TRUE; // so we won't try to immediately check it out again
}

void CToDoListDlg::OnUpdateToolsCheckin(CCmdUI* pCmdUI) 
{
	TDCITEM& tdci = GetTDCItem();

	BOOL bEnable = (tdci.pTDC->CompareFileFormat() != TDCFF_NEWER);

	if (bEnable)
	{
		bEnable &= PathSupportsSourceControl(tdci.GetFilePath());

		if (bEnable)
			bEnable &= (!tdci.bLastStatusReadOnly && tdci.pTDC->IsCheckedOut());
	}

	pCmdUI->Enable(bEnable);
}

void CToDoListDlg::OnExport() 
{
	int nTDCCount = GetTDCCount();
	ASSERT (nTDCCount >= 1);

	CExportDlg dialog(nTDCCount == 1, GetTDCItem().GetFilePath(), Prefs().GetAutoExportFolderPath());

	if (dialog.DoModal() == IDOK)
	{
		// build filter
		BOOL bIncDone = dialog.GetIncludeCompletedTasks();
		BOOL bIncNotDone = dialog.GetIncludeUncompletedTasks();
		
		TDC_FILTER nFilter = ((bIncDone && bIncNotDone) ? TDCF_ALL :
								(bIncDone ? TDCF_DONE : 
								(bIncNotDone ? TDCF_NOTDONE : TDCF_NONE)));

		ASSERT (nFilter != TDCF_NONE);

		int nFormat = dialog.GetExportFormat();
		BOOL bSelTaskOnly = dialog.GetExportSelTaskOnly();

		CString sExportPath = dialog.GetExportPath();
		ASSERT (!sExportPath.IsEmpty());

		// preferences
		BOOL bPreview = Prefs().GetPreviewExport();
		
		// export
		if (nTDCCount == 1 || !dialog.GetExportAllTasklists())
		{
			switch (nFormat)
			{
			case ED_HTMLFMT:
				Export2Html(&GetToDoCtrl(), sExportPath, bPreview, nFilter, bSelTaskOnly);
				break;
				
			case ED_TEXTFMT:
				Export2Text(&GetToDoCtrl(), sExportPath, bPreview, nFilter, bSelTaskOnly);
				break;
			}
		}
		else // multiple tasklists
		{
			BOOL bOneFile = dialog.GetExportOneFile();
			CString sOutput;

			for (int nCtrl = 0; nCtrl < nTDCCount; nCtrl++)
			{
				CString sTDCOutput;
				CToDoCtrl& tdc = GetToDoCtrl(nCtrl);

				tdc.Flush();

				// options
				DWORD dwOptions = TDCE_INCLUDEPROJECTNAME;
				dwOptions |= Prefs().GetExportVisibleOnly() ? TDCE_VISIBLECOLSONLY : 0;
				dwOptions |= Prefs().GetExportParentTitleCommentsOnly() ? TDCE_PARENTTITLECOMMENTSONLY : 0;
				dwOptions |= Prefs().GetExportSpaceForNotes() ? TDCE_SPACEFORNOTES : 0;
				
				switch (nFormat)
				{
				case ED_HTMLFMT:
					tdc.Export2Html(sTDCOutput, dwOptions, Prefs().GetHtmlFont(), 
									Prefs().GetHtmlFontSize(), nFilter);
					break;
					
				case ED_TEXTFMT:
					tdc.Export2Text(sTDCOutput, dwOptions, Prefs().GetTextIndent(), nFilter);
					break;
				}


				if (!sTDCOutput.IsEmpty())
				{
					if (bOneFile)
						sOutput += "<p>" + sTDCOutput + "</p>";
					else
					{
						CStdioFile file;
						sOutput = sTDCOutput;

						// build file path
						char szFilePath[MAX_PATH], szFName[_MAX_FNAME];
						_splitpath(tdc.GetFilePath(), NULL, NULL, szFName, NULL);
						_makepath(szFilePath, NULL, sExportPath, szFName, nFormat == ED_HTMLFMT ? "html" : "txt");
						
						if (file.Open(szFilePath, CFile::shareExclusive | CFile::modeWrite | CFile::modeCreate | CFile::typeText))
						{
							// add header
							sOutput = "<html>\n<head></head>\n<body>\n" + sOutput;
							
							// and footer
							sOutput += "</body>\n</html>\n";
							
							// save to file 
							file.WriteString(sOutput);
							file.Close();
							
							// and preview
							if (bPreview)
								ShellExecute(*this, NULL, szFilePath, NULL, NULL, SW_SHOWNORMAL);
						}
					}
				}
			}
			
			if (bOneFile && !sOutput.IsEmpty())
			{
				CStdioFile file;
				
				if (file.Open(sExportPath, CFile::shareExclusive | CFile::modeWrite | CFile::modeCreate | CFile::typeText))
				{
					// add header
					sOutput = "<html>\n<head></head>\n<body>\n" + sOutput;
					
					// and footer
					sOutput += "</body>\n</html>\n";
					
					// save to file 
					file.WriteString(sOutput);
					file.Close();
					
					// and preview
					if (bPreview)
						ShellExecute(*this, NULL, sExportPath, NULL, NULL, SW_SHOWNORMAL);
				}
			}
		}
	}
}

void CToDoListDlg::OnUpdateExport(CCmdUI* pCmdUI) 
{
	// make sure at least one control has items
	int nCtrl = GetTDCCount();

	while (nCtrl--)
	{
		if (GetToDoCtrl().GetTaskCount())
		{
			pCmdUI->Enable(TRUE);
			return;
		}
	}

	// else
	pCmdUI->Enable(FALSE);
}

void CToDoListDlg::OnNexttopleveltask() 
{
	GetToDoCtrl().GotoTopLevelTask(TDCG_NEXT);
}

void CToDoListDlg::OnPrevtopleveltask() 
{
	GetToDoCtrl().GotoTopLevelTask(TDCG_PREV);
}

void CToDoListDlg::OnUpdateNexttopleveltask(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanGotoTopLevelTask(TDCG_NEXT));
}

void CToDoListDlg::OnUpdatePrevtopleveltask(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanGotoTopLevelTask(TDCG_PREV));
}

void CToDoListDlg::OnFindTasks() 
{
	if (!m_findDlg.GetSafeHwnd())
		VERIFY(m_findDlg.Initialize(this));

	m_findDlg.Show();
}

int CToDoListDlg::MapFindWhat(FIND_WHAT fw)
{
	switch (fw)
	{
	case FW_TITLECOMMENTS: return FIND_TITLECOMMENTS;
	case FW_PRIORITY: return FIND_PRIORITY;
	case FW_PERCENTDONE: return FIND_PERCENTDONE;
	case FW_ALLOCTO: return FIND_ALLOCTO;
	case FW_ALLOCBY: return FIND_ALLOCBY;
	case FW_STATUS: return FIND_STATUS;
	case FW_CATEGORY: return FIND_CATEGORY;
	case FW_TIMEEST: return FIND_TIMEEST;
	case FW_TIMESPENT: return FIND_TIMESPENT;
	case FW_STARTDATE: return FIND_STARTDATE;
	case FW_DUEDATE: return FIND_DUEDATE;
	case FW_DONEDATE: return FIND_DONEDATE;
	case FW_TASKID: return FIND_TASKID;
	}

	ASSERT(0);
	return -1;
}

LRESULT CToDoListDlg::OnFindDlgFind(WPARAM wp, LPARAM lp)
{
	// set up the search
	BOOL bSearchAll = m_findDlg.GetSearchAllTasklists();
	int nSelTaskList = GetSelToDoCtrl();

	int nFrom = bSearchAll ? 0 : nSelTaskList;
	int nTo = bSearchAll ? GetTDCCount() - 1 : nSelTaskList;

	// search params
	SEARCHPARAMS sp;

	sp.dwFlags = m_findDlg.GetIncludeDone() ? FIND_INCLUDEDONE : 0;
	sp.nFindWhat = MapFindWhat(m_findDlg.GetFindWhat());

	// find specific params
	switch (sp.nFindWhat)
	{
	case FIND_TITLECOMMENTS:
	case FIND_ALLOCTO:
	case FIND_ALLOCBY:
	case FIND_STATUS:
	case FIND_CATEGORY:
		sp.dwFlags |= m_findDlg.GetMatchCase() ? FIND_MATCHCASE : 0;
		sp.dwFlags |= m_findDlg.GetMatchWholeWord() ? FIND_MATCHWHOLEWORD : 0;
		sp.sText = m_findDlg.GetText();
		break;
		
	case FIND_PRIORITY:
	case FIND_PERCENTDONE:
	case FIND_TASKID:
		m_findDlg.GetRange(sp.nFrom, sp.nTo);
		break;
				
	case FIND_TIMEEST:
	case FIND_TIMESPENT:
		m_findDlg.GetRange(sp.dFrom, sp.dTo);
		break;
		
	case FIND_STARTDATE:
	case FIND_DUEDATE:
	case FIND_DONEDATE:
		m_findDlg.GetRange(sp.dateFrom, sp.dateTo);
		break;
		
	default:
		ASSERT(0);
		return 0;
	}

	// do the search and populate the results
	for (int nCtrl = nFrom; nCtrl <= nTo; nCtrl++)
	{
		CToDoCtrl& tdc = GetToDoCtrl(nCtrl);
		CResultArray aResults;

		if (tdc.FindTasks(sp, aResults))
		{
			// use tasklist title from tabctrl
			char szTitle[128] = "";

			if (bSearchAll)
			{
				TCITEM tci = { TCIF_TEXT, 0, 0, szTitle, 127, 0, 0 };
				m_tabCtrl.GetItem(nCtrl, &tci);
			}

			for (int nResult = 0; nResult < aResults.GetSize(); nResult++)
			{
				AddFindResult(aResults[nResult], sp, nCtrl, szTitle);
			}
		}
	}

	if (m_findDlg.GetResultCount() == 1 && m_findDlg.GetAutoSelectSingles())
	{
		POSITION pos = m_findDlg.GetFirstResultPos();
		ASSERT (pos);

		if (pos)
		{
			FTDRESULT result;
			VERIFY(m_findDlg.GetNextResult(pos, result));

			OnFindSelectResult(0, (LPARAM)&result);
			m_findDlg.Show(FALSE);
		}
	}

	return 0;
}

void CToDoListDlg::AddFindResult(const SEARCHRESULT& result, const SEARCHPARAMS& params, 
								 int nTaskList, LPCTSTR szTaskList)
{
	CToDoCtrl& tdc = GetToDoCtrl(nTaskList);
	HTREEITEM htiRes = (HTREEITEM)result.dwID;
	CString sPath;
				
	if (szTaskList && lstrlen(szTaskList))
		sPath.Format("%s / %s", szTaskList, tdc.GetItemPath(htiRes));
	else
		sPath = tdc.GetItemPath(htiRes);

	// format the match string
	CString sMatch;

	switch (params.nFindWhat)
	{
	case FIND_ALLOCTO:
	case FIND_ALLOCBY:
	case FIND_STATUS:
	case FIND_CATEGORY:
		sMatch = result.sMatch;
		break;
		
	case FIND_PRIORITY:
	case FIND_PERCENTDONE:
	case FIND_TASKID:
		sMatch.Format("%d", result.nMatch);
		break;
				
	case FIND_TIMEEST:
	case FIND_TIMESPENT:
		sMatch.Format("%0.2f", result.dMatch);
		break;
		
	case FIND_STARTDATE:
	case FIND_DUEDATE:
	case FIND_DONEDATE:
		sMatch = CDateHelper::FormatDate(result.dateMatch, 
										Prefs().GetDisplayDatesInISO(),	
										Prefs().GetShowWeekdayInDates());
		break;
	}
				
	m_findDlg.AddResult(tdc.GetItemText(htiRes), sMatch, sPath, (DWORD)htiRes, nTaskList);
}

LRESULT CToDoListDlg::OnFindSelectResult(WPARAM wp, LPARAM lp)
{
	// extract HTREEITEM
	FTDRESULT* pResult = (FTDRESULT*)lp;
	ASSERT (pResult->dwItemData); // HTREEITEM

	CToDoCtrl& tdc = GetToDoCtrl(pResult->nTaskList);

	CHoldRedraw hr(tdc); // prevents flickering

	if (m_tabCtrl.GetCurSel() != pResult->nTaskList)
		SelectToDoCtrl(pResult->nTaskList);

	tdc.SetFocus();

	if (tdc.GetSelectedItem() != (HTREEITEM)pResult->dwItemData)
		tdc.SelectItem((HTREEITEM)pResult->dwItemData);

	return 0;
}

LRESULT CToDoListDlg::OnFindSelectAll(WPARAM wp, LPARAM lp)
{
	if (!m_findDlg.GetResultCount())
		return 0;

	CWaitCursor cursor;

	// not the most efficient technique but achieves the 
	// most correct result
	for (int nTDC = 0; nTDC < GetTDCCount(); nTDC++)
	{
		CToDoCtrl& tdc = GetToDoCtrl(nTDC);

		tdc.DeselectAll();

		POSITION pos = m_findDlg.GetFirstResultPos();

		while (pos)
		{
			FTDRESULT result;

			if (m_findDlg.GetNextResult(pos, result) && (nTDC == result.nTaskList))
			{
				tdc.MultiSelectItem((HTREEITEM)result.dwItemData, 1, FALSE);
			}
		}
	}

	// redraw the active tasklist
	if (m_findDlg.GetResultCount(GetSelToDoCtrl()))
		CRedrawAll(GetToDoCtrl(), TRUE); 

	return 0;
}

LRESULT CToDoListDlg::OnDropFile(WPARAM wParam, LPARAM lParam)
{
	OpenTaskList((LPCTSTR)lParam);

	return 0;
}

void CToDoListDlg::OnViewMovetasklistright() 
{
	int nSel = GetSelToDoCtrl();

	ASSERT (nSel < GetTDCCount() - 1);

	if (nSel < GetTDCCount() - 1)
	{
		TCITEM tci;
		char szText[128];
		tci.mask = TCIF_TEXT | TCIF_IMAGE;
		tci.pszText = szText;
		tci.cchTextMax = 127;

		m_tabCtrl.GetItem(nSel, &tci); // save off

		TDCITEM tdci = m_aToDoCtrls[nSel]; // save off

		m_aToDoCtrls.RemoveAt(nSel);
		m_tabCtrl.DeleteItem(nSel);

		nSel++;
		m_aToDoCtrls.InsertAt(nSel, tdci);
		m_tabCtrl.InsertItem(nSel, &tci);
	}

}

void CToDoListDlg::OnUpdateViewMovetasklistright(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetSelToDoCtrl() < GetTDCCount() - 1);
}

void CToDoListDlg::OnViewMovetasklistleft() 
{
	int nSel = GetSelToDoCtrl();

	ASSERT (nSel > 0);

	if (nSel > 0)
	{
		TCITEM tci;
		char szText[128];
		tci.mask = TCIF_TEXT | TCIF_IMAGE;
		tci.pszText = szText;
		tci.cchTextMax = 127;

		m_tabCtrl.GetItem(nSel, &tci); // save off

		TDCITEM tdci = m_aToDoCtrls[nSel]; // save off

		m_aToDoCtrls.RemoveAt(nSel);
		m_tabCtrl.DeleteItem(nSel);

		nSel--;
		m_aToDoCtrls.InsertAt(nSel, tdci);
		m_tabCtrl.InsertItem(nSel, &tci);
	}
}

void CToDoListDlg::OnUpdateViewMovetasklistleft(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetSelToDoCtrl() > 0);
}


void CToDoListDlg::OnToolsShowtasksDue(UINT nCmdID) 
{
	int nDueBy = PFP_DUETODAY;
	CString sDueBy("today");

	switch (nCmdID)
	{
	case ID_TOOLS_SHOWTASKS_DUETODAY:
		break; // done
		
	case ID_TOOLS_SHOWTASKS_DUETOMORROW:
		sDueBy = "tomorrow";
		nDueBy = PFP_DUETOMORROW;
		break;
		
	case ID_TOOLS_SHOWTASKS_DUEENDTHISWEEK:
		sDueBy = "by the end of this week";
		nDueBy = PFP_DUETHISWEEK;
		break;
		
	case ID_TOOLS_SHOWTASKS_DUEENDNEXTWEEK:
		sDueBy = "by the end of next week";
		nDueBy = PFP_DUENEXTWEEK;
		break;
		
	case ID_TOOLS_SHOWTASKS_DUEENDTHISMONTH:
		sDueBy = "by the end of this month";
		nDueBy = PFP_DUETHISMONTH;
		break;
		
	case ID_TOOLS_SHOWTASKS_DUEENDNEXTMONTH:
		sDueBy = "by the end of next month";
		nDueBy = PFP_DUENEXTMONTH;
		break;
		
	default:
		ASSERT(0);
		return;
	}

	if (!DoDueTaskNotification(&GetToDoCtrl(), nDueBy))
	{
		MessageBox(CString("There are no tasks due ") + sDueBy, ABBREVCOPYRIGHT);
	}
}

void CToDoListDlg::OnViewMenuonly() 
{
	SetToolbarOption(TB_TOOLBARHIDDEN);
}

void CToDoListDlg::OnUpdateViewMenuonly(CCmdUI* pCmdUI) 
{
	pCmdUI->SetRadio(m_nToolbarOption == TB_TOOLBARHIDDEN);
}

void CToDoListDlg::OnViewToolbarandmenu() 
{
	SetToolbarOption(TB_TOOLBARANDMENU);
}

void CToDoListDlg::OnUpdateViewToolbarandmenu(CCmdUI* pCmdUI) 
{
	pCmdUI->SetRadio(m_nToolbarOption == TB_TOOLBARANDMENU);
}

void CToDoListDlg::OnViewToolbaronly() 
{
	SetToolbarOption(TB_TOOLBARONLY);
}

void CToDoListDlg::OnUpdateViewToolbaronly(CCmdUI* pCmdUI) 
{
	pCmdUI->SetRadio(m_nToolbarOption == TB_TOOLBARONLY);
}

void CToDoListDlg::SetToolbarOption(int nOption)
{
	if (nOption == m_nToolbarOption)
		return; // nothing to do

	VERIFY(InitToolbar());

	PrepareToolbar(nOption);
	ShowMenuBar(nOption != TB_TOOLBARONLY, FALSE); 
	GetDlgItem(IDC_HORZDIVIDERTOP)->ShowWindow(nOption == TB_TOOLBARANDMENU ? SW_SHOW : SW_HIDE);

	m_nToolbarOption = nOption;

	ResizeDlg();
}

void CToDoListDlg::PrepareToolbar(int nOption)
{
	switch (nOption)
	{
	case TB_TOOLBARHIDDEN:
		m_toolbar.EnableWindow(FALSE);
		m_toolbar.ShowWindow(SW_HIDE);
		m_tbHelper.Release();
		break;

	case TB_TOOLBARANDMENU:
		m_toolbar.EnableWindow(TRUE);
		m_toolbar.ShowWindow(SW_SHOW);

		// hide inappropriate buttons
		if (!m_toolbar.GetToolBarCtrl().IsButtonHidden(ID_MOVETASK))
		{
			m_toolbar.GetToolBarCtrl().HideButton(ID_MOVETASK, TRUE);
			m_toolbar.GetToolBarCtrl().DeleteButton(m_toolbar.CommandToIndex(ID_MOVETASK) + 1);
		}

		// remove drop buttons
		if (m_tbHelper.IsInitialized())
			m_tbHelper.Release(TRUE);

		// reinit for tooltip support
		if (m_tbHelper.Initialize(&m_toolbar, this))
		{
			m_tbHelper.EnableMultilineText();
			m_tbHelper.SetTooltip(ID_SORT, CToolbarHelper::GetTip(GetSortID(GetToDoCtrl().GetSortBy())));
			m_tbHelper.SetTooltip(ID_NEWTASK_BEFORESELECTEDTASK, "New Task");
			m_tbHelper.SetTooltip(ID_EDIT_TASKTEXT, "Edit Task Text");
			m_tbHelper.SetTooltip(ID_LOAD_NORMAL, "Open Tasklist");
			m_tbHelper.SetTooltip(ID_DELETETASK, "Delete Task");
			m_tbHelper.SetTooltip(ID_PREFERENCES, "Preferences");
			m_tbHelper.SetTooltip(ID_HELP, "Help");
			m_tbHelper.SetTooltip(ID_SIMPLEMODE, "Hide Show Edit Fields");
		}

		AppendTools2Toolbar(TRUE);
		break;

	case TB_TOOLBARONLY:
		m_toolbar.EnableWindow(TRUE);
		m_toolbar.ShowWindow(SW_SHOW);
		
		// show previously hidden buttons
		if (m_toolbar.GetToolBarCtrl().IsButtonHidden(ID_MOVETASK))
		{
			m_toolbar.GetToolBarCtrl().HideButton(ID_MOVETASK, FALSE);

			TBBUTTON tbb = { -1, 0, 0, TBSTYLE_SEP, 0, -1 };
			m_toolbar.GetToolBarCtrl().InsertButton(m_toolbar.CommandToIndex(ID_MOVETASK) + 1, &tbb);
		}

		if (!m_tbHelper.IsInitialized())
			m_tbHelper.Initialize(&m_toolbar, this);

		m_tbHelper.SetTooltip(ID_MOVETASK, "Move Tasks (Alt+M)");
		m_tbHelper.SetTooltip(ID_SORT, "Sort Tasks (Alt+S)");
		m_tbHelper.SetTooltip(ID_NEWTASK_BEFORESELECTEDTASK, "New Task (Alt+N)");
		m_tbHelper.SetTooltip(ID_EDIT_TASKTEXT, "Edit Selected Task (Alt+E)");
		m_tbHelper.SetTooltip(ID_LOAD_NORMAL, "New/Open/Save... (Alt+F)");
		m_tbHelper.SetTooltip(ID_DELETETASK, "Delete Tasks (Alt+D)");
		m_tbHelper.SetTooltip(ID_PREFERENCES, "Tools (Alt+T)");
		m_tbHelper.SetTooltip(ID_HELP, "Help (Alt+H)");
		m_tbHelper.SetTooltip(ID_SIMPLEMODE, "View (Alt+V)");
			
		m_tbHelper.EnableMultilineText();
		m_tbHelper.SetDropButton(ID_SORT, IDR_MAINFRAME, SORT, 0, 'S');
		m_tbHelper.SetDropButton(ID_NEWTASK_BEFORESELECTEDTASK, IDR_MAINFRAME, NEWTASK, ID_NEWTASK_BEFORESELECTEDTASK, 'N');
		m_tbHelper.SetDropButton(ID_EDIT_TASKTEXT, IDR_MAINFRAME, EDITTASK, ID_EDIT_TASKTEXT, 'E');
		m_tbHelper.SetDropButton(ID_LOAD_NORMAL, IDR_MAINFRAME, FILEALL, ID_LOAD_NORMAL, 'F');
		m_tbHelper.SetDropButton(ID_DELETETASK, IDR_MAINFRAME, DELETETASK, ID_DELETETASK, 'D');
		m_tbHelper.SetDropButton(ID_PREFERENCES, IDR_MAINFRAME, TOOLS, ID_PREFERENCES, 'T');
		m_tbHelper.SetDropButton(ID_MOVETASK, IDR_MAINFRAME, MOVE, 0, 'M');
		m_tbHelper.SetDropButton(ID_HELP, IDR_MAINFRAME, HELP, ID_HELP, 'H');
		m_tbHelper.SetDropButton(ID_SIMPLEMODE, IDR_MAINFRAME, VIEW, ID_SIMPLEMODE, 'V');

		AppendTools2Toolbar(FALSE);
		break;
	}

	UpdateDefaultSortItem();
	
	GetToDoCtrl().Invalidate(); // for win9x
}

void CToDoListDlg::AppendTools2Toolbar(BOOL bAppend)
{
   CToolsHelper th(ID_TOOLS_USERTOOL1);

	if (bAppend)
	{
		// then re-add
		CUserToolArray aTools;
		Prefs().GetUserTools(aTools);

      th.AppendToolsToToolbar(aTools, m_toolbar, ID_PREFERENCES, &m_tbHelper);
	}
	else // remove
      th.RemoveToolsFromToolbar(m_toolbar, ID_PREFERENCES);
}

void CToDoListDlg::OnSort() 
{
	// we should get this only when both the toolbar and menu are visible
	ASSERT (m_nToolbarOption == TB_TOOLBARANDMENU);

	GetToDoCtrl().ReSort();
}

void CToDoListDlg::ResetPrefs()
{
	delete m_pPrefs;
	m_pPrefs = new CPreferencesDlg(&m_mgrShortcuts, IDR_MAINFRAME);
}

CPreferencesDlg& CToDoListDlg::Prefs() const
{
	ASSERT (m_pPrefs);
	return *m_pPrefs;
}

void CToDoListDlg::OnNewtaskAttop() 
{
	VERIFY (NewTask("Task", TDC_INSERTATTOP));
}

void CToDoListDlg::OnUpdateNewtaskAttop(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	pCmdUI->Enable(!tdc.IsReadOnly());
}

void CToDoListDlg::OnNewtaskAtbottom() 
{
	VERIFY (NewTask("Task", TDC_INSERTATBOTTOM));
}

void CToDoListDlg::OnUpdateNewtaskAtbottom(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	pCmdUI->Enable(!tdc.IsReadOnly());
}

void CToDoListDlg::OnSpellcheckcomments() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	tdc.SpellcheckSelectedTask(FALSE);
}

void CToDoListDlg::OnUpdateSpellcheckcomments(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	pCmdUI->Enable(!tdc.GetSelectedTaskComments().IsEmpty());
}

void CToDoListDlg::OnSpellchecktitle() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	tdc.SpellcheckSelectedTask(TRUE);
}

void CToDoListDlg::OnUpdateSpellchecktitle(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	pCmdUI->Enable(!tdc.GetSelectedTaskTitle().IsEmpty());
}

void CToDoListDlg::OnFileEncrypt() 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	if (!tdc.IsReadOnly())
		tdc.EnableEncryption(!tdc.IsEncrypted());
}

void CToDoListDlg::OnUpdateFileEncrypt(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	pCmdUI->Enable(tdc.CanEncrypt() && !tdc.IsReadOnly());
	pCmdUI->SetCheck(tdc.IsEncrypted() ? 1 : 0);
}

void CToDoListDlg::OnFileResetversion() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	
	if (!tdc.IsReadOnly())
	{
		tdc.ResetFileVersion();
		tdc.SetModified();

		UpdateStatusbar();
		UpdateCaption();
	}
}

void CToDoListDlg::OnUpdateFileResetversion(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	pCmdUI->Enable(!tdc.IsReadOnly());
}

void CToDoListDlg::OnSpellcheckTasklist() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	tdc.Spellcheck();
}

void CToDoListDlg::OnUpdateSpellcheckTasklist(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	pCmdUI->Enable(tdc.GetTaskCount());
}

BOOL CToDoListDlg::SaveAll(BOOL bClosingTaskLists, BOOL bClosingDown, BOOL bFlush)
{
	int nCtrl = GetTDCCount();
	
	while (nCtrl--)
	{
		TDCITEM& tdci = GetTDCItem(nCtrl);

		if (bFlush)
			tdci.pTDC->Flush();

		if (!ConfirmSaveTaskList(tdci, bClosingTaskLists, bClosingDown))
			return FALSE; // user cancelled
		else
			UpdateTabItemText(nCtrl);
	}
	
	UpdateCaption();
    return TRUE;
}

void CToDoListDlg::OnEditTimeTrackTask() 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	tdc.TimeTrackSelectedTask(!tdc.IsSelectedTaskBeingTimeTracked());
}

void CToDoListDlg::OnUpdateEditTimeTrackTask(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	pCmdUI->Enable(tdc.CanTimeTrackSelectedTask());
	pCmdUI->SetCheck(tdc.IsSelectedTaskBeingTimeTracked() ? 1 : 0);
}

void CToDoListDlg::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	if (nIDCtl == IDC_TABCONTROL)
	{
		CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
		TDCITEM& tdci = GetTDCItem(lpDrawItemStruct->itemID);

		if (tdci.bDueItems)
		{
			// draw a little tag in the top left corner in the colour
			// of the highest priority
			COLORREF crTag = tdci.pTDC->GetPriorityColor(10);

			for (int nHPos = 0; nHPos < 6; nHPos++)
			{
				for (int nVPos = 0; nVPos < 6 - nHPos; nVPos++)
				{
					pDC->SetPixelV(lpDrawItemStruct->rcItem.left + nHPos, 
								   lpDrawItemStruct->rcItem.top + nVPos, crTag);
				}
			}
		}

		return;
	}
	
	CDialog::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

void CToDoListDlg::OnViewNextSel() 
{
	GetToDoCtrl().SelectNextTasksInHistory();
}

void CToDoListDlg::OnUpdateViewNextSel(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanSelectNextTasksInHistory());
}

void CToDoListDlg::OnViewPrevSel() 
{
	GetToDoCtrl().SelectPrevTasksInHistory();
}

void CToDoListDlg::OnUpdateViewPrevSel(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanSelectPrevTasksInHistory());
}

void CToDoListDlg::OnSplitTaskIntoPieces(UINT nCmdID) 
{
	CToDoCtrl& tdc = GetToDoCtrl();
	int nNumPieces = 2 + (nCmdID - ID_NEWTASK_SPLITTASKINTO_TWO);
	
	tdc.SplitSelectedTask(nNumPieces);
}

void CToDoListDlg::OnUpdateSplitTaskIntoPieces(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	pCmdUI->Enable(tdc.CanSplitSelectedTask());
}

void CToDoListDlg::OnViewExpandtask() 
{
	GetToDoCtrl().ExpandSelectedTask(TRUE);
}

void CToDoListDlg::OnUpdateViewExpandtask(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanExpandSelectedTask(TRUE));
}

void CToDoListDlg::OnViewCollapsetask() 
{
	GetToDoCtrl().ExpandSelectedTask(FALSE);
}

void CToDoListDlg::OnUpdateViewCollapsetask(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanExpandSelectedTask(FALSE));
}

void CToDoListDlg::OnViewCollapseall() 
{
	GetToDoCtrl().ExpandAllTasks(FALSE);
}

void CToDoListDlg::OnViewExpandall() 
{
	GetToDoCtrl().ExpandAllTasks(TRUE);
}

void CToDoListDlg::OnUpdateViewExpandall(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetTaskCount());
}

void CToDoListDlg::OnUpdateViewCollapseall(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetTaskCount());
}
