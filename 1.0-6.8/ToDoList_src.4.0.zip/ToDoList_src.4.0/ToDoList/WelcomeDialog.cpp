// WelcomeDialog.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "WelcomeDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWelcomeDialog dialog

static LPCTSTR WELCOMETEXT =
"<font face=\"tahoma\">\
Please note that this is not a splash screen and requires you to make an important choice.\
<br><br>Because <b>ToDoList</b> is a relatively small application, it can be successfully run from a \
floppy disk or other removable media which allows you to take your current tasklists with you \
wherever you go.\
<br><br>As a result, you may wish to run <b>ToDoList</b> on computers for which you do not have registry \
access. And since <b>ToDoList</b> typically uses the registry to save your preferences this may result \
in problems.\
<br><br>If you think that this may be applicable to you or you simply wish to be able to backup or \
share your preferences then select 'Use an Ini File' from the droplist below.\
<br><br>Enjoy!\
<br><br><a href=www.abstractspoon.com><font color=\"#006000\" face=\"tahoma\"><u><b>Abstract</b>\
<i>Spoon</i> Software</u></font></a>";

CWelcomeDialog::CWelcomeDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CWelcomeDialog::IDD, pParent), m_sText(WELCOMETEXT)
{
	//{{AFX_DATA_INIT(CWelcomeDialog)
	m_bUseIniFile = 0;
	//}}AFX_DATA_INIT
	m_stText.SetBkColor(GetSysColor(COLOR_3DFACE));
}


void CWelcomeDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWelcomeDialog)
	DDX_Control(pDX, IDC_TEXT, m_stText);
	DDX_Text(pDX, IDC_TEXT, m_sText);
	DDX_CBIndex(pDX, IDC_PREFCHOICE, m_bUseIniFile);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWelcomeDialog, CDialog)
	//{{AFX_MSG_MAP(CWelcomeDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWelcomeDialog message handlers
