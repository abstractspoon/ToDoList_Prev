// ToDoList.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "ToDoList.h"
#include "ToDoListDlg.h"
#include "PreferencesGenPage.h"
#include "welcomedialog.h"

#include "..\shared\LimitSingleInstance.h"
#include "..\shared\encommandlineinfo.h"
#include "..\shared\driveinfo.h"

#include <afxpriv.h>

#include <shlwapi.h>
#pragma comment(lib, "shlwapi.lib")

#ifndef NOHTMLHELP
#	include <htmlhelp.h>
#	pragma comment(lib, "htmlhelp.lib")
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CLimitSingleInstance g_SingleInstanceObj(_T("{3A4EFC98-9BA9-473D-A3CF-6B0FE644470D}")); 

BOOL CALLBACK FindOtherInstance(HWND hwnd, LPARAM lParam);

/////////////////////////////////////////////////////////////////////////////
// CToDoListApp

BEGIN_MESSAGE_MAP(CToDoListApp, CWinApp)
	//{{AFX_MSG_MAP(CToDoListApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CToDoListApp construction

CToDoListApp::CToDoListApp() : m_pTDL(NULL)
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CToDoListApp object

CToDoListApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CToDoListApp initialization

BOOL CToDoListApp::InitInstance()
{
	AfxOleInit(); // for handling drag and drop via explorer

	CEnCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	if (!InitPreferences(&cmdInfo))
		return FALSE;

	// does the user want single instance only
	BOOL bSingleInstance = !CPreferencesGenPage().GetMultiInstance();

	if (bSingleInstance && g_SingleInstanceObj.IsAnotherInstanceRunning())
	{
		HWND hWnd = NULL;
		EnumWindows(FindOtherInstance, (LPARAM)&hWnd);
		
		if (hWnd)
		{
			// check version
			int nVer = ::SendMessage(hWnd, WM_TDL_GETVERSION, 0, 0);

			if (nVer < CToDoListDlg::GetVersion())
				MessageBox(NULL, "There is an earlier version of ToDoList already running."
								"\n\nTo run the more recent version, you will need to close "
								"the earlier version first and then retry.",
								ABBREVCOPYRIGHT, MB_OK);

			::SendMessage(hWnd, WM_TDL_SHOWWINDOW, 0, 0);

			// pass on file to open
			if (!cmdInfo.m_strFileName.IsEmpty())
			{
				COPYDATASTRUCT cds;

				cds.dwData = OPENTASKLIST;
				cds.cbData = MAX_PATH;
				cds.lpData = (LPVOID)cmdInfo.m_strFileName.GetBuffer(MAX_PATH);

				SendMessage(hWnd, WM_COPYDATA, NULL, (LPARAM)&cds);
				
				cmdInfo.m_strFileName.ReleaseBuffer();
			}

			::SetForegroundWindow(hWnd);

			return FALSE;
		}
	}

	BOOL bForceVisible = cmdInfo.GetOption("v");

	m_pTDL = new CToDoListDlg;
	
	if (m_pTDL && m_pTDL->Create(bForceVisible, cmdInfo.m_strFileName))
	{
		m_pMainWnd = m_pTDL;
		return TRUE;
	}

	// else
	return FALSE;
}

int CToDoListApp::ExitInstance() 
{
	delete m_pTDL;

	return CWinApp::ExitInstance();
}

BOOL CToDoListApp::OnIdle(LONG lCount) 
{
	m_pTDL->SendMessage(WM_KICKIDLE);

	return CWinApp::OnIdle(lCount);
}

BOOL CALLBACK FindOtherInstance(HWND hwnd, LPARAM lParam)
{
	CString sCaption;

	int nLen = ::GetWindowTextLength(hwnd);
	::GetWindowText(hwnd, sCaption.GetBuffer(nLen + 1), nLen + 1);
	sCaption.ReleaseBuffer();
	sCaption.MakeLower();

	if (sCaption.Find("todolist � abstractspoon") != -1)
	{
		HWND* pWnd = (HWND*)lParam;
		*pWnd = hwnd;
		return FALSE;
	}

	return TRUE;
}


BOOL CToDoListApp::PreTranslateMessage(MSG* pMsg) 
{
	// give first chance to main window for handling accelerators
	if (m_pMainWnd && m_pMainWnd->PreTranslateMessage(pMsg))
		return TRUE;

	return CWinApp::PreTranslateMessage(pMsg);
}

void CToDoListApp::OnHelp() 
{ 
	DoHelp();
}

void CToDoListApp::WinHelp(DWORD dwData, UINT nCmd) 
{
	if (nCmd == HELP_CONTEXT)
		DoHelp((LPCTSTR)dwData);
}

void CToDoListApp::DoHelp(const CString& sHelpRef)
{
	// 1. look for todolist.chm in the registry
	CString sHelpTopic, sHelpFile = GetProfileString("Help", "CHMFile");

	if (GetFileAttributes(sHelpFile) == 0xffffffff)
	{
		// 2. try exe folder
		GetModuleFileName(NULL, sHelpFile.GetBuffer(MAX_PATH + 1), MAX_PATH);
		sHelpFile.ReleaseBuffer();
		sHelpFile.MakeLower();

		sHelpFile.Replace(".exe", ".chm");

		// try again
		if (GetFileAttributes(sHelpFile) == 0xffffffff)
		{
			LPCTSTR szMessage = "ToDoList was unable to locate the help documentation. This may "
								"be because \nyou have not downloaded it or this is the first "
								"time you have accessed it. \n\nWould you like to browse for it?";
			// 3. ask the user
			if (MessageBox(*m_pMainWnd, szMessage, "ToDoList � AbstractSpoon", MB_OKCANCEL) == IDOK)
			{
				CFileDialog dialog(TRUE, "chm", sHelpFile, OFN_PATHMUSTEXIST, "Help Files (*.chm)|*.chm||");

				dialog.m_ofn.lpstrTitle = "Locate Help File - ToDoList � AbstractSpoon";

				if (dialog.DoModal() == IDOK)
					sHelpFile = dialog.GetPathName();
				else
					return;
			}
			else
				return;
		}
	}

	ASSERT (!sHelpFile.IsEmpty());

#ifndef NOHTMLHELP
	if (!sHelpRef.IsEmpty())
		sHelpTopic.Format("%s::/%s", sHelpFile, sHelpRef);
	else
		sHelpTopic = sHelpFile;

	// show help
	if (NULL != ::HtmlHelp(NULL, sHelpTopic, HH_DISPLAY_TOPIC, NULL))
#else
	if (32 < (int)ShellExecute(*m_pMainWnd, NULL, sHelpFile, NULL, NULL, SW_SHOWNORMAL))
#endif
		WriteProfileString("Help", "CHMFile", sHelpFile);
}

BOOL CToDoListApp::InitPreferences(const CEnCommandLineInfo* pInfo)
{
	BOOL bUseIni = FALSE;

	// get the ini file path
	char szIniPath[MAX_PATH + 1];
    CString sIniPath;

    // try command line first
    if (pInfo->GetOption("i", sIniPath) && !sIniPath.IsEmpty())
    {
        lstrcpy(szIniPath, sIniPath);
        bUseIni = TRUE;
    }
    else
    {
        char szFolder[MAX_PATH], szAppName[_MAX_FNAME], szDrive[_MAX_DRIVE];

        // then try current working dir followed by app folder
 	    GetModuleFileName(NULL, szIniPath, MAX_PATH);
        _splitpath(szIniPath, szDrive, szFolder, szAppName, NULL);

        GetCurrentDirectory(MAX_PATH, szIniPath);
        _makepath(szIniPath, NULL, szIniPath, szAppName, ".ini");

        bUseIni = (GetFileAttributes(szIniPath) != 0xffffffff);

        if (!bUseIni)
        {
            _makepath(szIniPath, szDrive, szFolder, szAppName, ".ini");
            bUseIni = (GetFileAttributes(szIniPath) != 0xffffffff);
        }
   }

	// if it doesn't check registry has been used before
	if (!bUseIni)
	{
		HKEY hKey = NULL;

		LONG lResult = RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\Abstractspoon\\ToDoList", 
									0L, KEY_ALL_ACCESS, &hKey);

		if (lResult == ERROR_FILE_NOT_FOUND) // first time
		{
			// don't bother the user if we're being run off removeable media
			if (CDriveInfo::IsRemovablePath(szIniPath))
				bUseIni = TRUE;
			else
			{
				CWelcomeDialog dialog;

				if (dialog.DoModal() == IDOK)
					bUseIni = dialog.GetUseIniFile();
				else
					return FALSE;
			}
		}
		else if (hKey == NULL)
			bUseIni = TRUE;
	}

	// finally
	if (bUseIni)
	{
		free((void*)m_pszProfileName);
		m_pszProfileName = _strdup(szIniPath);
	}
	else
		SetRegistryKey(_T("AbstractSpoon"));

	return TRUE;
}
