// NcGutter.h: interface for the CNcGutter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NCGUTTER_H__A356B1B6_1B4D_4013_8F39_8D9D2442E149__INCLUDED_)
#define AFX_NCGUTTER_H__A356B1B6_1B4D_4013_8F39_8D9D2442E149__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "subclass.h"
#include "hottracker.h"
#include <afxtempl.h>

// wParam == ctrl id
const UINT WM_NCG_GETFIRSTVISIBLETOPLEVELITEM = ::RegisterWindowMessage("WM_NCG_GETFIRSTVISIBLETOPLEVELITEM");
const UINT WM_NCG_GETNEXTITEM = ::RegisterWindowMessage("WM_NCG_GETNEXTITEM");
const UINT WM_NCG_POSTDRAWITEM = ::RegisterWindowMessage("WM_NCG_POSTDRAWITEM");
const UINT WM_NCG_DRAWITEM = ::RegisterWindowMessage("WM_NCG_DRAWITEM");
const UINT WM_NCG_RECALCCOLWIDTH = ::RegisterWindowMessage("WM_NCG_RECALCCOLWIDTH");
const UINT WM_NCG_WIDTHCHANGE = ::RegisterWindowMessage("WM_NCG_WIDTHCHANGE");
const UINT WM_NCG_POSTNCDRAW = ::RegisterWindowMessage("WM_NCG_POSTNCDRAW");
const UINT WM_NCG_GETITEMRECT = ::RegisterWindowMessage("WM_NCG_GETITEMRECT");
const UINT WM_NCG_GETFIRSTCHILDITEM = ::RegisterWindowMessage("WM_NCG_GETFIRSTCHILDITEM");
const UINT WM_NCG_HITTEST = ::RegisterWindowMessage("WM_NCG_HITTEST");
const UINT WM_NCG_GETSELECTEDITEM = ::RegisterWindowMessage("WM_NCG_GETSELECTEDITEM");
const UINT WM_NCG_SETSELECTEDITEM = ::RegisterWindowMessage("WM_NCG_SETSELECTEDITEM");
const UINT WM_NCG_NOTIFYITEMCLICK = ::RegisterWindowMessage("WM_NCG_NOTIFYITEMCLICK"); // sent if an item is clicked when already selected
const UINT WM_NCG_NOTIFYCOLUMNCLICK = ::RegisterWindowMessage("WM_NCG_NOTIFYCOLUMNCLICK"); 
const UINT WM_NCG_NOTIFYHEADERCLICK = ::RegisterWindowMessage("WM_NCG_NOTIFYHEADERCLICK"); 
const UINT WM_NCG_GETCURSOR = ::RegisterWindowMessage("WM_NCG_GETCURSOR"); 

struct NCGDRAWITEM
{
	NCGDRAWITEM() { pDC = NULL; dwItem = dwParentItem = 0; nColID = 0; rItem = NULL; nLevel = 0; 
					nItemPos = 0; rWindow = NULL; bSelected = FALSE; }

	CDC* pDC;
	DWORD dwItem;
	DWORD dwParentItem; // always zero unless control responds to WM_NCG_GETFIRSTCHILDITEM
	int nColID;
	const CRect* rItem;
	int nLevel;			// always zero unless control responds to WM_NCG_GETFIRSTCHILDITEM
	int nItemPos;
	const CRect* rWindow;
	BOOL bSelected;
};

struct NCGRECALCCOLUMN
{
	int nColID;
	CDC* pDC;
	int nWidth; // fill in on return
};

struct NCGITEMRECT
{
	NCGITEMRECT() { dwItem = 0; ::SetRectEmpty(&rItem); }

	DWORD dwItem;
	RECT rItem; // return client coords
};

struct NCGITEMCLICK
{
	DWORD dwItem;
	int nColID; // -1 if client click
	UINT nMsgID; // WM_...
	POINT ptClick;
};

struct NCGHDRCLICK
{
	int nColID; 
	UINT nMsgID; // WM_...
	BOOL bPressed; // notifyee can modify to indicate what the final state should be
};

struct NCGGETCURSOR
{
	int nColID;
	DWORD dwItem;
};

const UINT NCG_CLIENTCOLUMNID = 0xffff;

class CNcGutter : protected CSubclassWnd  
{
public:
	CNcGutter();
	virtual ~CNcGutter();

	BOOL Initialize(HWND hwnd);
	BOOL IsInitialized() { return IsHooked(); }

	// add WM_ messages that should cause a recalc
	// use nNotification for 
	void AddRecalcMessage(UINT nMessage, UINT nNotification = 0); 
	void AddRedrawMessage(UINT nMessage, UINT nNotification = 0); // add WM_ messages that should cause a redraw

	void Redraw();
	void RecalcGutter();
	int GetGutterWidth();

	int AddColumn(UINT nID, LPCTSTR szTitle = NULL, UINT nWidth = 0, UINT nTextAlign = DT_LEFT); // returns the index of the added column
	void ShowHeader(BOOL bShow = TRUE);
	void PressColumnHeader(UINT nID, BOOL bPress = TRUE);
	void SetColumnHeaderTitle(UINT nID, LPCTSTR szTitle);
	void EnableColumnHeaderClicking(UINT nID, BOOL bEnable = TRUE);

protected:
	CMap<DWORD, DWORD, char, char> m_mapRecalcMessages;
	CMap<DWORD, DWORD, char, char> m_mapRedrawMessages;
	BOOL m_bSetRedraw;
	BOOL m_bClickSelChange;
	DWORD m_dwItemClick;
	BOOL m_bShowHeader;
	CBitmap m_bmClient, m_bmNonClient;
	BOOL m_bFirstRecalc;
	CHotTracker m_hotTrack;

	struct COLUMNDESC
	{
		COLUMNDESC(UINT nID = 0) : nColID(nID), nWidth(0), bCalcWidth(TRUE), bPressed(FALSE), 
								nTextAlign(DT_LEFT), bClickable(TRUE) {}

		UINT nColID;
		CString sTitle;
		BOOL bCalcWidth;
		UINT nWidth;
		BOOL bPressed;
		UINT nTextAlign;
		BOOL bClickable;
	};

	CArray<COLUMNDESC, COLUMNDESC&> m_aColumns;

protected:
	virtual LRESULT WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp);

	// specific message handlers
	void OnPrint(HDC hdc, UINT& nFlags);
	void OnNcPaint();
	void OnPaint();
	void OnHotChange(int nPrevHot, int nHot);
	void OnNcButtonDown(UINT nMsg, CPoint point);
	void OnNcButtonUp(UINT nMsg, CPoint point);
	void OnButtonDown(UINT nMsg, CPoint point);
	void OnButtonUp(UINT nMsg, CPoint point);
	LRESULT OnNcHitTest(CPoint point);
	BOOL OnSetCursor(); // returns TRUE if the cursor was set
	LRESULT OnNcCalcSize(LPNCCALCSIZE_PARAMS lpncsp);

	// these test for messages added with AddRecalcMessage/AddRedrawMessage
	BOOL WantsRecalc(UINT nMsg, WPARAM wp, LPARAM lp, LRESULT& lr);
	BOOL WantsRedraw(UINT nMsg, WPARAM wp, LPARAM lp, LRESULT& lr);

	DWORD GetFirstVisibleTopLevelItem(int& nItem); // return 0 if no items
	void NcDrawItem(CDC* pDC, DWORD dwItem, DWORD dwParentItem, int nLevel, int nPos, 
					const CRect& rWindow, const CRect& rClient, CRect& rItem);
	void PostNcDraw(CDC* pDC, const CRect& rWindow);
	void PostNcDrawItem(CDC* pDC, DWORD dwItem, const CRect& rItem, int nLevel);
	DWORD GetNextItem(DWORD dwItem); // return 0 at end
	CRect GetItemRect(DWORD dwItem);
	DWORD GetFirstChildItem(DWORD dwItem);
	DWORD GetSelectedItem();
	DWORD HitTest(CPoint point);
	BOOL SetSelectedItem(DWORD dwItem);

	enum HCHDRPART { NONCLIENT, CLIENT };
	void NcDrawHeader(CDC* pDC, const CRect& rHeader, HCHDRPART nPart, const CPoint& ptCursor);
	void UpdateHeaderHotRects();
	int HeaderHitTest(CPoint ptScreen); // returns column index or -1
	void UnpressAllColumnHeaders(int nExcludeCol = -1);
	int RecalcGutterWidth();
	int ColumnHitTest(CPoint ptScreen);
	int GetColumnIndex(UINT nID); // can return -1

	BOOL PrepareBitmap(CDC* pDC, CBitmap* pBitmap, const CRect& rect, BOOL bClient);
};

#endif // !defined(AFX_NCGUTTER_H__A356B1B6_1B4D_4013_8F39_8D9D2442E149__INCLUDED_)
