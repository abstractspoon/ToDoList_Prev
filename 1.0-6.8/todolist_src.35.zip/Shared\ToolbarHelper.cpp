// ToolbarHelper.cpp: implementation of the CToolbarHelper class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ToolbarHelper.h"

#include "enbitmap.h"
#include <afxpriv.h>        // for WM_KICKIDLE

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// simple helper class for determining whether commands are disabled or not

class CCmdUITH : public CCmdUI
{

public:
	CCmdUITH() { m_bEnabled = TRUE; }
	virtual void Enable(BOOL bOn = TRUE) { m_bEnabled = bOn; }
	virtual void SetCheck(int nCheck = 1) {} // dummy
	virtual void SetRadio(BOOL bOn = TRUE) {} // dummy
	virtual void SetText(LPCTSTR lpszText) {} // dummy

public:
	BOOL m_bEnabled;
};

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CToolbarHelper::CToolbarHelper() : m_pToolbar(NULL), m_bMultiline(FALSE), m_nMultilineWidth(200)
{

}

CToolbarHelper::~CToolbarHelper()
{

}

BOOL CToolbarHelper::Initialize(CToolBar* pToolbar, CWnd* pToolbarParent)
{
	if (!pToolbarParent || !HookWindow(*pToolbarParent))
		return FALSE;

	ASSERT_VALID(pToolbar);

	m_pToolbar = pToolbar;
	m_pToolbar->GetToolBarCtrl().SetExtendedStyle(TBSTYLE_EX_DRAWDDARROWS);

	return TRUE;
}

BOOL CToolbarHelper::SetDropButton(UINT nBtnCmdID, UINT nMenuID, int nSubMenu, UINT nDefCmdID, char cHotkey)
{
	int nIndex = m_pToolbar->CommandToIndex(nBtnCmdID);

	if (nIndex == -1)
		return FALSE;

	DWORD dwStyle = m_pToolbar->GetButtonStyle(nIndex) | TBSTYLE_DROPDOWN;
	m_pToolbar->SetButtonStyle(nIndex, dwStyle);

	DropMenu dm = { nMenuID, nSubMenu, nDefCmdID, cHotkey };
	m_mapDropMenus[nBtnCmdID] = dm;

	m_pToolbar->RedrawWindow();

	return TRUE;
}

BOOL CToolbarHelper::SetDefaultMenuID(UINT nBtnCmdID, UINT nDefCmdID)
{
	DropMenu dm;
	
	if (m_mapDropMenus.Lookup(nBtnCmdID, dm))
	{
		dm.nDefCmdID = nDefCmdID;
		m_mapDropMenus[nBtnCmdID] = dm;

		return TRUE;
	}

	return FALSE;
}

BOOL CToolbarHelper::DisplayDropMenu(UINT nCmdID, BOOL bPressBtn)
{
	// see if we have a menu for it
	DropMenu dm;
	
	if (m_mapDropMenus.Lookup(nCmdID, dm))
	{
		CMenu menu, *pSubMenu;
		
		if (menu.LoadMenu(dm.nMenuID))
		{
			pSubMenu = menu.GetSubMenu(dm.nSubMenu);
			
			if (pSubMenu)
			{
				PrepareMenuItems(pSubMenu, GetCWnd());
				pSubMenu->SetDefaultItem(dm.nDefCmdID);
				
				CRect rItem;
				int nIndex = m_pToolbar->CommandToIndex(nCmdID);

				m_pToolbar->GetItemRect(nIndex, rItem);
				m_pToolbar->ClientToScreen(rItem);
			
				if (bPressBtn)
					m_pToolbar->GetToolBarCtrl().PressButton(nCmdID, TRUE);

				pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON, rItem.left, rItem.bottom, GetCWnd());

				if (bPressBtn)
					m_pToolbar->GetToolBarCtrl().PressButton(nCmdID, FALSE);
				
				return TRUE; // we handled it
			}
		}
	}

	return FALSE;
}

LRESULT CToolbarHelper::WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case WM_NOTIFY:
		{
			LPNMHDR pNMHDR = (LPNMHDR)lp;
			
			switch (pNMHDR->code)
			{
			case TBN_DROPDOWN:
				// check its our toolbar
				if (pNMHDR->hwndFrom == m_pToolbar->GetSafeHwnd())
				{
					// load the menu
					LPNMTOOLBAR pNMTB = (LPNMTOOLBAR)pNMHDR;
					
					if (DisplayDropMenu((UINT)pNMTB->iItem))
						return FALSE; // we handled it
				}
				break;
				
			case TTN_NEEDTEXT:
				{
					// to be thorough we will need to handle UNICODE versions of the message also !!
					TOOLTIPTEXT* pTTT = (TOOLTIPTEXT*)pNMHDR;
					UINT nID = pNMHDR->idFrom;
					
					if (pTTT->uFlags & TTF_IDISHWND) // idFrom is actually the HWND of the tool 
						nID = ::GetDlgCtrlID((HWND)nID);

					// get cursor pos
					CPoint point(::GetMessagePos());
					m_pToolbar->ScreenToClient(&point);
					
					// get tip
					static CString sTipText;
										
					sTipText = GetTip(nID, &point);
					
					if (!sTipText.IsEmpty()) // will be zero on a separator
					{
						pTTT->lpszText = (LPTSTR)(LPCTSTR)sTipText;
						return TRUE;
					}
				}
				break;

			case TTN_SHOW:
				{
					CWnd* pTooltipCtrl = CWnd::FromHandle(pNMHDR->hwndFrom);
					ASSERT (pTooltipCtrl);

					int nWidth = pTooltipCtrl->SendMessage(TTM_SETMAXTIPWIDTH, 0, 
															m_bMultiline ? m_nMultilineWidth : UINT_MAX);
				}
				break;
			}
		}
		break;
	
	case WM_COMMAND:
		{
			HWND hCtrlFrom = (HWND)lp;

			// if m_pToolbar sent the command and we have a mapping for it then
			// change it to the default cmd for that button
			if (hCtrlFrom == *m_pToolbar)
			{
				DropMenu dm;
				UINT nCmdID = LOWORD(wp);

				if (m_mapDropMenus.Lookup(nCmdID, dm))
				{
					// if we have an enabled default command then send it
					if (dm.nDefCmdID && IsCmdEnabled(dm.nDefCmdID))
						wp = MAKEWPARAM(dm.nDefCmdID, HIWORD(wp));
					else
					{
						BOOL bRes = DisplayDropMenu(nCmdID, TRUE);

						if (bRes)
							return 0L; // we handled it
					}
				}
			}
		}
		break;

	case WM_KICKIDLE:
		{
		    m_pToolbar->OnUpdateCmdUI((CFrameWnd*)GetCWnd(), FALSE);
		}
		break;
	}

	return CSubclassWnd::WindowProc(hRealWnd, msg, wp, lp);
}

// static helper
void CToolbarHelper::PrepareMenuItems(CMenu* pMenu, CWnd* pWnd)
{
	// update item states
	CCmdUI state;
	
	state.m_pMenu = pMenu;
	state.m_nIndexMax = pMenu->GetMenuItemCount();
	
	for (state.m_nIndex = 0; state.m_nIndex < state.m_nIndexMax; state.m_nIndex++)
	{
		UINT nCmdID = pMenu->GetMenuItemID(state.m_nIndex);
		
		if (nCmdID == (UINT)-1) // submenu
		{
			CMenu* pSubMenu = pMenu->GetSubMenu(state.m_nIndex);

			if (pSubMenu)
				PrepareMenuItems(pSubMenu, pWnd);
		}
		else if (nCmdID != 0)
		{
			state.m_nID = nCmdID;
			pWnd->OnCmdMsg(state.m_nID, CN_UPDATE_COMMAND_UI, &state, NULL);
		}
	}
}

BOOL CToolbarHelper::IsCmdEnabled(UINT nCmdID) const
{
	CWnd* pParent = CWnd::FromHandle(GetHwnd());

	if (pParent)
	{
		CCmdUITH state;
		
		state.m_nIndexMax = 1;
		state.m_nIndex = 0;
		state.m_nID = nCmdID;

		pParent->OnCmdMsg(nCmdID, CN_UPDATE_COMMAND_UI, &state, NULL);

		return state.m_bEnabled;
	}

	return TRUE;
}

CString CToolbarHelper::GetTip(UINT nID, LPPOINT pPoint) const
{
	if (!nID)
		return ""; // separator

	// are we over the dropbutton?
	BOOL bOverDropBtn = FALSE;

	if (pPoint)
	{
		CSize sizeBtn(m_pToolbar->GetToolBarCtrl().GetButtonSize());
		CRect rButton;

		m_pToolbar->GetToolBarCtrl().GetRect(nID, rButton);
		rButton.left += sizeBtn.cx;

		if (rButton.PtInRect(*pPoint))
			bOverDropBtn = TRUE;
	}

	CString sTip;

	// do we have a mapping for this
	DropMenu dm;
				
	if (!bOverDropBtn && m_mapDropMenus.Lookup(nID, dm))
	{
		// try the default item first
		if (dm.nDefCmdID && IsCmdEnabled(dm.nDefCmdID))
		{
			sTip = GetTip(dm.nDefCmdID);

			if (!sTip.IsEmpty())
				return sTip;
		}
	}

	if (sTip.LoadString(nID) && !sTip.IsEmpty())
	{	
		// tip text starts at '\n' 
		int nStartTip = sTip.Find('\n');
		
		if (nStartTip != -1) 
			sTip = sTip.Right(sTip.GetLength() - nStartTip - 1);

		else // strip '...' if present
			sTip.Replace(".", "");

		sTip.TrimLeft();
		sTip.TrimRight();
	}
	
	return sTip;
}

void CToolbarHelper::EnableMultilineText(BOOL bEnable, int nWidth)
{
	m_bMultiline = bEnable;
	m_nMultilineWidth = nWidth;
}

BOOL CToolbarHelper::ProcessMessage(MSG* pMsg)
{
	if (!IsWindowEnabled() || !m_pToolbar->IsWindowEnabled())
		return FALSE;

	// see if key press matches any hotkey
	if (pMsg->message == WM_SYSKEYDOWN && pMsg->wParam != VK_MENU && (GetKeyState(VK_MENU) & 0x8000))
	{
		int nKey = (int)pMsg->wParam;
		char cLower = 0, cUpper = 0;

		if (islower(nKey))
		{
			cLower = (char)nKey;
			cUpper = toupper(nKey);
		}
		else if (isupper(nKey))
		{
			cUpper = (char)nKey;
			cLower = tolower(nKey);
		}
		else
			cUpper = cLower = nKey;

		// iterate the buttons the hard way
		POSITION pos = m_mapDropMenus.GetStartPosition();

		while (pos)
		{
			DropMenu dm;
			UINT nCmdID = 0;

			m_mapDropMenus.GetNextAssoc(pos, nCmdID, dm);

			if (nCmdID && (dm.cHotKey == cLower || dm.cHotKey == cUpper))
			{
				DisplayDropMenu(nCmdID, TRUE);
				return TRUE;
			}
		}
	}

	return FALSE;
}

