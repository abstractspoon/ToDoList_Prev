#if !defined(AFX_PREFERENCESUIPAGE_H__5AE787F2_44B0_4A48_8D75_24C6C16B45DF__INCLUDED_)
#define AFX_PREFERENCESUIPAGE_H__5AE787F2_44B0_4A48_8D75_24C6C16B45DF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesUIPage.h : header file
//

#include "..\shared\fileedit.h"
#include "..\shared\colorbutton.h"
#include "..\shared\fontcombobox.h"
#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUIPage dialog

enum PTP_COLUMN
{
	PTPC_PRIORITY,
	PTPC_PERCENT,
	PTPC_TIMEEST,
	PTPC_STARTDATE,
	PTPC_DUEDATE,
	PTPC_DONEDATE,
	PTPC_PERSON,
	PTPC_FILEREF,
	PTPC_POSITION,
	PTPC_ID,
	PTPC_DONE,
};

const COLORREF GRIDLINECOLOR = RGB(192, 192, 192);
const COLORREF TASKDONECOLOR = RGB(192, 192, 192);

class CPreferencesUIPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPreferencesUIPage)

// Construction
public:
	CPreferencesUIPage();
	~CPreferencesUIPage();

	BOOL GetColorPriority() const { return m_bColorPriority; }
	BOOL GetColorTextByPriority() const { return m_bColorPriority && m_bColorTextByPriority; }
	BOOL GetShowInfoTips() const { return m_bShowInfoTips; }
	BOOL GetShowComments() const { return m_bShowComments; }
	BOOL GetShowColumn(PTP_COLUMN nColumn) const;
	BOOL GetVaryCommentsHeight() const { return m_bVaryCommentsHeight; }
	BOOL GetShowButtonsInTree() const { return m_bShowButtonsInTree; }
	BOOL GetShowCtrlsAsColumns() const { return m_bShowCtrlsAsColumns; }
	BOOL GetShowCommentsAlways() const { return m_bShowCommentsAlways; }
	int GetPriorityColors(CDWordArray& aColors) const;
	BOOL GetTreeFont(CString& sFaceName, int& nPointSize) const;
	BOOL GetAutoReposCtrls() const { return m_bAutoReposCtrls; }
	COLORREF GetGridlineColor() const { return m_bSpecifyGridColor ? m_crGridlines : GRIDLINECOLOR; }
	COLORREF GetTaskDoneColor() const { return m_bSpecifyDoneColor ? m_crDone : GRIDLINECOLOR; }
	BOOL GetShowPathInHeader() const { return m_bShowPathInHeader; }
	BOOL GetStrikethroughDone() const { return m_bStrikethroughDone; }
	BOOL GetFullRowSelection() const { return m_bFullRowSelection; }
	BOOL GetTreeCheckboxes() const { return m_bTreeCheckboxes; }
	CString GetToolbarImagePath() const { return m_bSpecifyToolbarImage ? m_sToolbarImagePath : ""; }

protected:
// Dialog Data
	//{{AFX_DATA(CPreferencesUIPage)
	enum { IDD = IDD_PREFUI_PAGE };
	CFileEdit	m_eToolbarImagePath;
	CColorButton	m_btDoneColor;
	CColorButton	m_btGridlineColor;
	CComboBox	m_cbFontSize;
	CFontComboBox	m_cbFonts;
	BOOL	m_bSpecifyTreeFont;
	BOOL	m_bShowCtrlsAsColumns;
	BOOL	m_bShowCommentsAlways;
	BOOL	m_bAutoReposCtrls;
	BOOL	m_bSpecifyGridColor;
	BOOL	m_bSpecifyDoneColor;
	BOOL	m_bShowPathInHeader;
	BOOL	m_bStrikethroughDone;
	BOOL	m_bFullRowSelection;
	BOOL	m_bTreeCheckboxes;
	BOOL	m_bSpecifyToolbarImage;
	CString	m_sToolbarImagePath;
	//}}AFX_DATA
	CCheckListBox	m_lbColumnVisibility;
	CColorButton	m_btSetColor;
	CColorButton	m_btLowColor;
	CColorButton	m_btHighColor;
	BOOL	m_bColorTextByPriority;
	BOOL	m_bShowInfoTips;
	BOOL	m_bShowComments;
	BOOL	m_bShowPercentColumn;
	BOOL	m_bShowPriorityColumn;
	BOOL	m_bColorPriority;
	BOOL	m_bVaryCommentsHeight;
	BOOL	m_bShowButtonsInTree;
	int		m_bIndividualPriorityColors;
	int		m_nSelPriorityColor;
	BOOL	m_bShowTimeColumn;
	int		m_nSelColumnVisibility;
	CDWordArray m_aPriorityColors;
	COLORREF m_crLow, m_crHigh;
	CString m_sTreeFont;
	int		m_nFontSize;
	COLORREF m_crGridlines, m_crDone;

	struct COLUMNPREF
	{
		COLUMNPREF() {}
		COLUMNPREF(LPCTSTR name, PTP_COLUMN col, BOOL visible) { szName = name; nCol = col; bVisible = visible; }

		LPCTSTR szName;
		PTP_COLUMN nCol;
		BOOL bVisible;
	};
	CArray<COLUMNPREF, COLUMNPREF&> m_aColPrefs;


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesUIPage)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
public:
	virtual void OnOK();

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesUIPage)
	afx_msg void OnSpecifytreefont();
	afx_msg void OnSetgridlinecolor();
	afx_msg void OnSpecifygridlinecolor();
	afx_msg void OnSetdonecolor();
	afx_msg void OnSpecifydonecolor();
	afx_msg void OnSpecifytoolbarimage();
	//}}AFX_MSG
	virtual BOOL OnInitDialog();
	afx_msg void OnLowprioritycolor();
	afx_msg void OnHighprioritycolor();
	afx_msg void OnSetprioritycolor();
	afx_msg void OnChangePriorityColorOption();
	afx_msg void OnColorPriority();
	afx_msg void OnSelchangePrioritycolors();
	afx_msg void OnColVisibilityChange();
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESUIPAGE_H__5AE787F2_44B0_4A48_8D75_24C6C16B45DF__INCLUDED_)
