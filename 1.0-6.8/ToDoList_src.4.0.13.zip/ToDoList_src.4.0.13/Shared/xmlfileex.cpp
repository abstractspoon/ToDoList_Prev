// xmlfileex.cpp: implementation of the CXmlFileEx class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "xmlfileex.h"

#include "..\shared\iencryption.h"
#include "..\3rdparty\base64coder.h"
#include "..\shared\passworddialog.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CXmlFileEx::CXmlFileEx(LPCTSTR szRootItemName, LPCTSTR szPassword)
 : CXmlFile(szRootItemName), m_pEncryptor(NULL), m_sPassword(szPassword)
{

}

CXmlFileEx::~CXmlFileEx()
{

}

BOOL CXmlFileEx::Encrypt(LPCTSTR szPassword)
{
  if (!szPassword)
    szPassword = m_sPassword;

	if (!(*szPassword) || !InitEncryptor())
		return FALSE;

	// 1. export everything below the root to a string
	CExportToXml e2xml;
	CString sXml, sItemXml;

	POSITION pos = m_xiRoot.GetFirstItemPos();
	int nItem = 1;

	while (pos)
	{
		const CXmlItem* pXI = m_xiRoot.GetNextItem(pos);
		ASSERT (pXI);

		e2xml.Export(pXI, 1, nItem, sItemXml);
		sXml += sItemXml;
		nItem++;
	}

	// 2. encrypt it
	unsigned char* pEncrypted = NULL;
	int nLenEncrypted = 0;

	if (!m_pEncryptor->Encrypt((unsigned char*)(LPCTSTR)sXml, sXml.GetLength() + 1, szPassword, // RB - Added sPassword parameter instead of NULL
								pEncrypted, nLenEncrypted))
		return FALSE;

	// 3. convert the binary to a string
	Base64Coder b64;

	b64.Encode(pEncrypted, nLenEncrypted);
	const char* pEncodedDataBuffer = b64.EncodedMessage();

	// 4. replace file contents with a single CDATA item
	m_xiRoot.DeleteAllItems();
	m_xiRoot.AddItem(CDATA, pEncodedDataBuffer);
	m_xiRoot.AddItem("DATALEN", nLenEncrypted);

	// 5. cleanup
	m_pEncryptor->FreeBuffer(pEncrypted);

	return TRUE;
}

BOOL CXmlFileEx::Decrypt(LPCTSTR szPassword)
{
  if (!szPassword)
    szPassword = m_sPassword;
  
		CXmlItem* pXI = GetItem(CDATA);
    
    if (pXI && !pXI->GetSibling())
    {
      // we don't try to decrypt if no encryption capabilities
      if (!CanEncrypt())
      {
        CString sExplanation;
        sExplanation.Format("The file '%s' is encrypted, but you do not have the necessary components installed to decrypt it.",
          GetFilePath());
        
        AfxMessageBox(sExplanation, MB_OK);
        m_nLoadError = XFL_CANCELLED;
        return FALSE;
      }
      
      // else keep getting password till success or user cancels
      while (TRUE)
      {
        CString sPassword(szPassword);
        
        if (sPassword.IsEmpty())
        {
          CString sExplanation;
          sExplanation.Format("The file '%s' is encrypted.\n\nPlease enter your password below.",
            GetFilePath());
          
          if (!CPasswordDialog::RetrievePassword(FALSE, sPassword, sExplanation, 5))
          {
            // RB - Set m_nLoadError to avoid "The selected task list could not be opened..." message when cancelling
            m_nLoadError = XFL_CANCELLED;
            return FALSE;
          }
        }
        
        CString sFile;
        
        if (Decrypt(pXI->GetValue(), sFile, sPassword))
        {
          m_sPassword = sPassword;
          
          sFile.TrimLeft();
          sFile.TrimRight();
          
          // delete the cdata item
          m_xiRoot.DeleteItem(pXI);
          
          LPCTSTR szFile = sFile;
          
          // reparse decrypted xml
          ParseItem(m_xiRoot, szFile);
          
          return TRUE;
        }
        else
        {
          // RB - Added code to format the error message before calling AfxMessage
          CString sExplanation;
          sExplanation.Format("The file '%s' could not be decrypted using the supplied password.\n\nWound you like to try again?",
            GetFilePath());
          
          if (IDNO == AfxMessageBox(sExplanation, MB_YESNO))
          {
            m_nLoadError = XFL_CANCELLED;
            return FALSE;
          }
        }
      }
    }
    
    return TRUE; // might be garbage. who knows?
    
}

BOOL CXmlFileEx::Load(LPCTSTR szFilePath, LPCTSTR szRootItemName, IXmlParse* pCallback, BOOL bDecrypt)
{
	m_bDecrypt = bDecrypt;

	return CXmlFile::Load(szFilePath, szRootItemName, pCallback);
}

BOOL CXmlFileEx::Open(LPCTSTR szFilePath, XF_OPEN nOpenFlags, BOOL bDecrypt)
{
	m_bDecrypt = bDecrypt;

	return CXmlFile::Open(szFilePath, nOpenFlags);
}

BOOL CXmlFileEx::LoadEx(LPCTSTR szRootItemName, IXmlParse* pCallback)
{
	if (!CXmlFile::LoadEx(szRootItemName, pCallback))
		return FALSE;

	// we assume the file is encrypted if it contains a single CDATA element
	if (m_bDecrypt)
    return Decrypt();

  return TRUE;
}


BOOL CXmlFileEx::Decrypt(LPCTSTR szInput, CString& sOutput, LPCTSTR szPassword)
{
	if (!InitEncryptor())
		return FALSE;

	// 1. convert the input string back to binary
	Base64Coder b64;
	b64.Decode(szInput);

	DWORD nReqBufLen = 0;
	unsigned char* pDecodedDataBuffer = b64.DecodedMessage(nReqBufLen);

	nReqBufLen = GetItemValueI("DATALEN");
	
	// 2. decrypt it
	unsigned char* pDecrypted = NULL;
	int nLenDecrypted = 0;

	if (!m_pEncryptor->Decrypt((unsigned char*)pDecodedDataBuffer, nReqBufLen, szPassword,
								pDecrypted, nLenDecrypted))
		return FALSE;

	// 3. result should be a null-terminated string
	sOutput = pDecrypted;

	// 4. cleanup
	m_pEncryptor->FreeBuffer(pDecrypted);

	return TRUE;
}

BOOL CXmlFileEx::InitEncryptor()
{
	if (m_pEncryptor)
		return TRUE;

	m_pEncryptor = CreateEncryptionInterface("EncryptDecrypt.dll");

	return (m_pEncryptor != NULL);
}

BOOL CXmlFileEx::CanEncrypt()
{
	return CXmlFileEx().InitEncryptor();
}
