#if !defined(AFX_URLRICHEDITCTRL_H__B5421D69_41F2_4FCF_AC58_13D2B3D3D3C8__INCLUDED_)
#define AFX_URLRICHEDITCTRL_H__B5421D69_41F2_4FCF_AC58_13D2B3D3D3C8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// urlricheditctrl.h : header file
//

#include <Richole.h>

/////////////////////////////////////////////////////////////////////////////
// CUrlRichEditCtrl window

const UINT WM_UREN_CUSTOMURL = ::RegisterWindowMessage("WM_UREN_CUSTOMURL"); // lParam == full url

struct URLITEM
{
	CHARRANGE cr;
	CString sUrl;
	BOOL bWantNotify;
};

#include <afxtempl.h>

typedef CArray<URLITEM, URLITEM&> CUrlArray;
typedef CMap<CString, LPCTSTR, BOOL, BOOL&> CProtocolMap;

class CUrlRichEditCtrl : public CRichEditCtrl
{
	// Construction
public:
	CUrlRichEditCtrl();
	
	int GetUrlCount() const { return m_aUrls.GetSize(); }
	int UrlHitTest(const CPoint& point) const; // returns -1 if not found
	CString GetUrl(int nURL, BOOL bAsFile = FALSE) const;
	void PathReplaceSel(LPCTSTR lpszPath, BOOL bCanUndo = FALSE);
	BOOL GoToUrl(const CString& sUrl) const; // must exist 
	CPoint GetContextMenuPos() { return m_ptContextMenu; }
	BOOL AddProtocol(LPCTSTR szProtocol, BOOL bWantNotify = TRUE);
	
	// Attributes
protected:
	CUrlArray m_aUrls;
	HCURSOR m_hHandCursor;
	CPoint m_ptLBtnDown;
	int m_nLBtnDownUrl;
	CProtocolMap m_mapProtocols;
	CPoint m_ptContextMenu;
	
	// Operations
public:
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUrlRichEditCtrl)
protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL
	
	// Implementation
public:
	virtual ~CUrlRichEditCtrl();
	
	// Generated message map functions
protected:
	//{{AFX_MSG(CUrlRichEditCtrl)
	afx_msg BOOL OnChangeText();
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnRButtonUp(UINT nHitTest, CPoint point);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG
	afx_msg LRESULT OnSetFont(WPARAM wp, LPARAM lp);
	afx_msg LRESULT OnSetText(WPARAM wp, LPARAM lp);
	afx_msg LRESULT OnDropFiles(WPARAM wp, LPARAM lp);
	
	DECLARE_MESSAGE_MAP()

	virtual LRESULT SendNotifyCustomUrl(LPCTSTR szUrl) const;
		
		// Interface Map
public:
	BEGIN_INTERFACE_PART(RichEditOleCallback, IRichEditOleCallback)
		INIT_INTERFACE_PART(CRichEditView, RichEditOleCallback)
		STDMETHOD(GetNewStorage) (LPSTORAGE*);
		STDMETHOD(GetInPlaceContext) (LPOLEINPLACEFRAME*, LPOLEINPLACEUIWINDOW*, LPOLEINPLACEFRAMEINFO);
		STDMETHOD(ShowContainerUI) (BOOL);
		STDMETHOD(QueryInsertObject) (LPCLSID, LPSTORAGE, LONG);
		STDMETHOD(DeleteObject) (LPOLEOBJECT);
		STDMETHOD(QueryAcceptData) (LPDATAOBJECT, CLIPFORMAT*, DWORD,BOOL, HGLOBAL);
		STDMETHOD(ContextSensitiveHelp) (BOOL);
		STDMETHOD(GetClipboardData) (CHARRANGE*, DWORD, LPDATAOBJECT*);
		STDMETHOD(GetDragDropEffect) (BOOL, DWORD, LPDWORD);
		STDMETHOD(GetContextMenu) (WORD, LPOLEOBJECT, CHARRANGE*, HMENU*);
	END_INTERFACE_PART(RichEditOleCallback)
		
	DECLARE_INTERFACE_MAP()
		
protected:
	void ParseAndFormatText(BOOL bForceReformat = FALSE);
	int GetLineHeight() const;
	int CharFromPoint(const CPoint& point); 
	void SetFirstVisibleLine(int nLine);
	CPoint GetCaretPos();

	static BOOL IsDelim(char ch);
	static void InsertInOrder(URLITEM& urli, CUrlArray& aUrls);

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_URLRICHEDITCTRL_H__B5421D69_41F2_4FCF_AC58_13D2B3D3D3C8__INCLUDED_)
