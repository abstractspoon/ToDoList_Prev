#if !defined(AFX_PREFERENCESGENPAGE_H__7A8CC153_F3FB_4FBA_8EB9_B8ADF0A59982__INCLUDED_)
#define AFX_PREFERENCESGENPAGE_H__7A8CC153_F3FB_4FBA_8EB9_B8ADF0A59982__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesGenPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPreferencesGenPage dialog

enum // tray options
{
	STO_NONE = -1,
	STO_ONMINIMIZE,
	STO_ONCLOSE,
	STO_ONMINCLOSE,
};

enum // source control
{
	STSS_NONE,
	STSS_LANONLY,
	STSS_ALL,
};

enum // reload
{
	RO_NO,
	RO_ASK,
	RO_AUTO,
};

class CPreferencesGenPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPreferencesGenPage)

// Construction
public:
	CPreferencesGenPage();
	~CPreferencesGenPage();

	BOOL GetAlwaysOnTop() const { return m_bAlwaysOnTop; }
	BOOL GetUseSysTray() const { return m_bUseSysTray; }
	int GetSysTrayOption() const { return !m_bUseSysTray ? STO_NONE : m_nSysTrayOption; }
	BOOL GetAutoSaveOnSysTray() const { return m_bUseSysTray && m_bAutoSaveOnSysTray; }
	BOOL GetConfirmDelete() const { return m_bConfirmDelete; }
	BOOL GetConfirmSaveOnExit() const { return !m_bUseSysTray && m_bConfirmSaveOnExit; }
	BOOL GetShowOnStartup() const { return m_bAutoSaveOnSysTray && m_bShowOnStartup; }
	BOOL GetToggleTrayVisibility() const { return m_bToggleTrayVisibility; }
	BOOL GetEnableSourceControl() const { return m_bEnableSourceControl; }
	BOOL GetSourceControlLanOnly() const { return m_bEnableSourceControl && m_bSourceControlLanOnly; }
	BOOL GetAutoCheckOut() const { return m_bEnableSourceControl && m_bAutoCheckOut; }
	BOOL GetCheckoutOnCheckin() const { return m_bEnableSourceControl && m_bCheckoutOnCheckin; }
	int GetReadonlyReloadOption() const;
	int GetTimestampReloadOption() const;
	BOOL GetMultiInstance() const { return m_bMultiInstance; }
	BOOL GetCheckinOnClose() const { return m_bEnableSourceControl && m_bCheckinOnClose; }
	UINT GetRemoteFileCheckFrequency() const { return m_nRemoteFileCheckFreq; }
//	BOOL Get() const { return m_b; }

// Dialog Data
	//{{AFX_DATA(CPreferencesGenPage)
	enum { IDD = IDD_PREFGEN_PAGE };
	CComboBox	m_cbRemoteFileCheck;
	BOOL	m_bAlwaysOnTop;
	BOOL	m_bUseSysTray;
	BOOL	m_bAutoSaveOnSysTray;
	BOOL	m_bConfirmDelete;
	BOOL	m_bConfirmSaveOnExit;
	BOOL	m_bPromptReloadOnWritable;
	BOOL	m_bPromptReloadOnTimestamp;
	BOOL	m_bShowOnStartup;
	int		m_nSysTrayOption;
	BOOL	m_bToggleTrayVisibility;
	BOOL	m_bEnableSourceControl;
	BOOL	m_bSourceControlLanOnly;
	BOOL	m_bAutoCheckOut;
	BOOL	m_bCheckoutOnCheckin;
	int		m_nReadonlyReloadOption;
	int		m_nTimestampReloadOption;
	BOOL	m_bMultiInstance;
	BOOL	m_bCheckinOnClose;
	//}}AFX_DATA
	UINT	m_nRemoteFileCheckFreq;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesGenPage)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesGenPage)
	afx_msg void OnUseSystray();
	virtual BOOL OnInitDialog();
	afx_msg void OnEnablesourcecontrol();
	afx_msg void OnPromptreloadonwritable();
	afx_msg void OnPromptreloadontimestamp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESGENPAGE_H__7A8CC153_F3FB_4FBA_8EB9_B8ADF0A59982__INCLUDED_)
