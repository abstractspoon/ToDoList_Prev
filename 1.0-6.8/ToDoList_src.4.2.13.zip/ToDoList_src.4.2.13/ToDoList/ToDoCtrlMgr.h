// ToDoListDlg.h : header file
//

#if !defined(AFX_TODOCTRLMGR_H__13051D32_D372_4205_BA71_05FAC2159F1C__INCLUDED_)
#define AFX_TODOCTRLMGR_H__13051D32_D372_4205_BA71_05FAC2159F1C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "todoctrl.h"

#include "..\shared\filemisc.h"
#include "..\shared\driveinfo.h"

/////////////////////////////////////////////////////////////////////////////
// CToDoCtrlMgr dialog
 
enum { TDCM_UNDEF = -1, TDCM_REMOVABLE, TDCM_FIXED, TDCM_REMOTE }; // drive types

class CToDoCtrlMgr
{
	// Construction
public:
	CToDoCtrlMgr(CTabCtrl& tabCtrl); // standard constructor
	~CToDoCtrlMgr();

	inline int GetCount() const { return m_aToDoCtrls.GetSize(); }
	inline int GetSelToDoCtrl() const { return m_tabCtrl.GetCurSel(); }

	CToDoCtrl& GetToDoCtrl(int nIndex);
	const CToDoCtrl& GetToDoCtrl(int nIndex) const;
	void RemoveToDoCtrl(int nIndex);
	int AddToDoCtrl(CToDoCtrl* pCtrl, BOOL bReOrder = FALSE);

	CString GetFilePath(int nIndex) const;
	void ClearFilePath(int nIndex);
	BOOL IsFilePathEmpty(int nIndex) const;
	BOOL GetFilePathType(int nIndex) const;
	int RefreshPathType(int nIndex); 

	BOOL RefreshLastModified(int nIndex); // true if changed
	time_t GetLastModified(int nIndex);
	void SetModifiedStatus(int nIndex, BOOL bMod);
	BOOL GetModifiedStatus(int nIndex);

	int GetReadOnlyStatus(int nIndex);
	BOOL RefreshReadOnlyStatus(int nIndex); // true if changed
	void SetDueItemStatus(int nIndex, BOOL bDueItems);
	BOOL GetDueItemStatus(int nIndex);
	int GetLastCheckoutStatus(int nIndex);
	void SetLastCheckoutStatus(int nIndex, BOOL bStatus);

	void MoveToDoCtrl(int nIndex, int nNumPlaces);
	BOOL CanMoveToDoCtrl(int nIndex, int nNumPlaces);

	int SortToDoCtrlsByName();
	BOOL PathSupportsSourceControl(int nIndex) const;
	BOOL PathSupportsSourceControl(LPCTSTR szPath) const;
	BOOL IsSourceControlled(int nIndex);

	CString UpdateTabItemText(int nIndex);

	int ArchiveDoneTasks(int nIndex, TDC_ARCHIVE nRemove);
	CString GetArchivePath(LPCTSTR szFilePath);

	void SetNeedsPreferenceUpdate(int nIndex, BOOL bNeed);
	BOOL GetNeedsPreferenceUpdate(int nIndex);
	void SetAllNeedPreferenceUpdate(BOOL bNeed);

	// Implementation
protected:
	struct TDCITEM
	{
		TDCITEM() 
		{ 
			pTDC = NULL; 
			bModified = FALSE; 
			bLastStatusReadOnly = -1; 
			tLastMod = 0; 
			bLastCheckoutSuccess = -1;
            nPathType = TDCM_UNDEF;
			bDueItems = FALSE;
			bNeedPrefUpdate = TRUE;
		}
		
		TDCITEM(CToDoCtrl* pCtrl) 
		{ 
			pTDC = pCtrl; 
			
			bModified = FALSE; 
			bLastStatusReadOnly = -1;
			tLastMod = 0;
			bLastCheckoutSuccess = -1;
			bDueItems = FALSE;
			bNeedPrefUpdate = TRUE;
			
			CString sFilePath = pCtrl->GetFilePath();
			
			if (!sFilePath.IsEmpty())
			{
				bLastStatusReadOnly = CDriveInfo::IsReadonlyPath(sFilePath);
				tLastMod = ::GetLastModified(sFilePath);
			}
			
            RefreshPathType();
		}
		
		CToDoCtrl* pTDC;
		BOOL bModified;
		BOOL bLastStatusReadOnly;
		time_t tLastMod;
		BOOL bLastCheckoutSuccess;
        int nPathType;
		BOOL bDueItems;
		BOOL bNeedPrefUpdate;
		
		inline int GetPathType() const { return nPathType; }
        
        void RefreshPathType() 
        { 
			LPCTSTR szFilePath = pTDC->GetFilePath();
			
            switch (CDriveInfo::GetPathType(szFilePath))
            {
            case DRIVE_REMOTE:
                nPathType = TDCM_REMOTE;
                break;
				
            case DRIVE_REMOVABLE:
            case DRIVE_CDROM:
                nPathType = TDCM_REMOVABLE;
                break;
				
            case DRIVE_FIXED:
                nPathType = TDCM_FIXED;
                break;
				
            default:
                nPathType = TDCM_UNDEF;
                break;
            }
        }
	};
	
	CArray<TDCITEM, TDCITEM&> m_aToDoCtrls;
	CTabCtrl& m_tabCtrl;

protected:
	TDCITEM& GetTDCItem(int nIndex);

	// sort function
	static int SortProc(const void* v1, const void* v2);
	BOOL AreToDoCtrlsSorted();

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TODOCTRLMGR_H__13051D32_D372_4205_BA71_05FAC2159F1C__INCLUDED_)
