#if !defined(AFX_PREFERENCESTASKDEFPAGE_H__852964E3_4ABD_4B66_88BA_F553177616F2__INCLUDED_)
#define AFX_PREFERENCESTASKDEFPAGE_H__852964E3_4ABD_4B66_88BA_F553177616F2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesTaskDefPage.h : header file
//

#include <afxtempl.h>
#include "..\shared\colorbutton.h"
#include "..\shared\timeedit.h"
#include "..\shared\EditPrompt.h"

/////////////////////////////////////////////////////////////////////////////
// CPreferencesTaskDefPage dialog

enum PTP_ATTRIB
{
	PTPA_PRIORITY,
	PTPA_COLOR,
	PTPA_ALLOCTO,
	PTPA_ALLOCBY,
	PTPA_STATUS,
	PTPA_CATEGORY,
	PTPA_TIMEEST,
};

class CPreferencesTaskDefPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPreferencesTaskDefPage)

// Construction
public:
	CPreferencesTaskDefPage();
	~CPreferencesTaskDefPage();

	int GetDefaultPriority() const { return m_nDefPriority; }
	CString GetDefaultAllocTo() const { return m_sDefAllocTo; }
	CString GetDefaultAllocBy() const { return m_sDefAllocBy; }
	CString GetDefaultStatus() const { return m_sDefStatus; }
	CString GetDefaultCategory() const { return m_sDefCategory; }
	double GetDefaultTimeEst(int& nUnits) const;
	COLORREF GetDefaultColor() const { return m_crDef; }
	BOOL GetAutoDefaultStartDate() const { return m_bUseCreationForDefStartDate; }
	BOOL GetUseParentAttrib(PTP_ATTRIB nAttrib) const;

protected:
// Dialog Data
	//{{AFX_DATA(CPreferencesTaskDefPage)
	enum { IDD = IDD_PREFTASKDEF_PAGE };
	CTimeEdit	m_eTimeEst;
	//}}AFX_DATA
	CCheckListBox	m_lbAttribUse;
	int		m_nDefPriority;
	double		m_dDefTimeEst;
	CString	m_sDefAllocTo;
	CString	m_sDefAllocBy;
	CString	m_sDefStatus;
	CString	m_sDefCategory;
	CColorButton	m_btDefColor;
	COLORREF m_crDef;
	BOOL	m_bUseParentAttributes;
	int		m_nSelAttribUse;
	BOOL	m_bUseCreationForDefStartDate;
	CEditPromptManager m_mgrPrompts;

	struct ATTRIBPREF
	{
		ATTRIBPREF() {}
		ATTRIBPREF(LPCTSTR name, PTP_ATTRIB attrib, BOOL use) { szName = name; nAttrib = attrib; bUse = use; }

		LPCTSTR szName;
		PTP_ATTRIB nAttrib;
		BOOL bUse;
	};
	CArray<ATTRIBPREF, ATTRIBPREF&> m_aAttribPrefs;


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesTaskDefPage)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesTaskDefPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnSetdefaultcolor();
	afx_msg void OnUseparentattrib();
	//}}AFX_MSG
	afx_msg void OnAttribUseChange();
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESTASKDEFPAGE_H__852964E3_4ABD_4B66_88BA_F553177616F2__INCLUDED_)
