// TreeSelectionHelper.cpp: implementation of the CTreeSelectionHelper class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TreeSelectionHelper.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTreeSelectionHelper::CTreeSelectionHelper(CTreeCtrl& tree) : m_tree(tree), m_nCurSelection(0)
{

}

CTreeSelectionHelper::~CTreeSelectionHelper()
{

}

BOOL CTreeSelectionHelper::SetItem(HTREEITEM hti, int nState, BOOL bRedraw)
{
	if (!hti)
		return FALSE;

	POSITION pos = m_lstSelection.Find(hti);

	switch (nState)
	{
	case 1: // add
		if (!pos)
		{
			m_lstSelection.AddTail(hti);

			if (bRedraw)
				InvalidateItem(hti);

			return TRUE;
		}
		break;

	case 0: // remove
		if (pos)
		{
			m_lstSelection.RemoveAt(pos);

			if (bRedraw)
				InvalidateItem(hti);

			return TRUE;
		}
		break;

	case -1: // toggle
		if (!pos)
			m_lstSelection.AddTail(hti);
		else
			m_lstSelection.RemoveAt(pos);

		if (bRedraw)
			InvalidateItem(hti);

		return TRUE;
	}

	return FALSE;
}

void CTreeSelectionHelper::InvalidateItem(HTREEITEM hti)
{
	CRect rItem;

	if (m_tree.GetItemRect(hti, rItem, FALSE))
		m_tree.InvalidateRect(rItem, FALSE);	
}

BOOL CTreeSelectionHelper::SetItems(HTREEITEM htiFrom, HTREEITEM htiTo, int nState, BOOL bRedraw)
{
	if (!htiFrom || !htiTo)
		return FALSE;

	int nDirection = FindItem(htiTo, htiFrom);

	// if (htiFrom != htiTo) and nDirection is zero then htiTo could not be found
	if (htiFrom != htiTo && !nDirection)
		return FALSE;

	// if htiTo is above htiFrom then switch items so we can use a single loop
	if (nDirection == -1)
	{
		HTREEITEM htiTemp = htiFrom;
		htiFrom = htiTo;
		htiTo = htiTemp;
	}

	BOOL bRes = FALSE;
	HTREEITEM htiNext = htiFrom;

	while (htiNext) 
	{
		bRes |= SetItem(htiNext, nState, bRedraw);

		if (htiNext != htiTo)
			htiNext = GetNextItem(htiNext, TRUE);
		else
			break;
	}

	return bRes;
}

BOOL CTreeSelectionHelper::AddItems(HTREEITEM htiFrom, HTREEITEM htiTo, BOOL bRedraw)
{
	return SetItems(htiFrom, htiTo, 1, bRedraw);
}

BOOL CTreeSelectionHelper::ToggleItems(HTREEITEM htiFrom, HTREEITEM htiTo, BOOL bRedraw)
{
	return SetItems(htiFrom, htiTo, -1, bRedraw);
}

BOOL CTreeSelectionHelper::RemoveAll(BOOL bRedraw) 
{ 
	if (GetCount())
	{
		// flush the history stack
		if (m_nCurSelection < m_aHistory.GetSize())
			m_aHistory.RemoveAt(m_nCurSelection + 1, m_aHistory.GetSize() - m_nCurSelection - 1);

		else // add the current selection to the history
			m_aHistory.Add(m_lstSelection);

		// update the current selection
		m_nCurSelection++;
		
		if (bRedraw)
			InvalidateAll(FALSE);

		m_lstSelection.RemoveAll(); 
		return TRUE;
	}

	return FALSE;
}

void CTreeSelectionHelper::InvalidateAll(BOOL bErase)
{
	POSITION pos = GetFirstItemPos();
	CRect rItem;

	while (pos)
	{
		HTREEITEM hti = GetNextItem(pos);

		m_tree.GetItemRect(hti, rItem, FALSE);
		m_tree.InvalidateRect(rItem, bErase);
	}
}

BOOL CTreeSelectionHelper::AnyItemsHaveChildren() const
{
	POSITION pos = GetFirstItemPos();

	while (pos)
	{
		if (m_tree.ItemHasChildren(GetNextItem(pos)))
			return TRUE;
	}

	return FALSE;
}

HTREEITEM CTreeSelectionHelper::GetNextPageItem(HTREEITEM hti) const
{
	// if we're the last visible item then its just the page count
	// figure out how many items to step
	HTREEITEM htiNext = m_tree.GetNextVisibleItem(hti);

	if (!htiNext || !IsFullyVisible(htiNext))
	{
		int nCount = m_tree.GetVisibleCount();

		// keep going until we get NULL and then return
		// the previous item
		while (hti && nCount--)
		{
			if (hti = GetNextItem(hti))
				htiNext = hti;
		}
	}
	else // we keep going until we're the last visible item
	{
		// keep going until we get NULL and then return
		// the previous item
		while (hti)
		{
			hti = m_tree.GetNextVisibleItem(hti);
			
			if (hti && IsFullyVisible(hti))
				htiNext = hti;
			else
				hti = NULL;
		}
	}

	return htiNext;
}

HTREEITEM CTreeSelectionHelper::GetPrevPageItem(HTREEITEM hti) const
{
	// if we're the first visible item then its just the page count
	// figure out how many items to step
	HTREEITEM htiPrev = m_tree.GetPrevVisibleItem(hti);

	if (!htiPrev || !IsFullyVisible(htiPrev))
	{
		int nCount = m_tree.GetVisibleCount();

		// keep going until we get NULL and then return
		// the previous item
		while (hti && nCount--)
		{
			if (hti = GetPrevItem(hti))
				htiPrev = hti;
		}
	}
	else // we keep going until we're the first visible item
	{
		// keep going until we get NULL and then return
		// the previous item
		while (hti)
		{
			hti = m_tree.GetPrevVisibleItem(hti);
			
			if (hti && IsFullyVisible(hti))
				htiPrev = hti;
			else
				hti = NULL;
		}
	}

	return htiPrev;
}

HTREEITEM CTreeSelectionHelper::GetNextItem(HTREEITEM hti, BOOL bAllowChildren) const
{
	HTREEITEM htiNext = NULL;
	
	// try our first child if we're expanded
	if (bAllowChildren && m_tree.ItemHasChildren(hti) && IsItemExpanded(hti))
		htiNext = m_tree.GetChildItem(hti);
	else
	{
		// try next sibling
		htiNext = m_tree.GetNextItem(hti, TVGN_NEXT);
		
		// finally try next parent
		if (!htiNext)
		{
			HTREEITEM htiParent = m_tree.GetParentItem(hti);
			
			if (htiParent)
				htiNext = m_tree.GetNextItem(htiParent, TVGN_NEXT);
		}
	}

	return htiNext == TVI_ROOT ? NULL : htiNext;
}

HTREEITEM CTreeSelectionHelper::GetPrevItem(HTREEITEM hti, BOOL bAllowChildren) const
{
	// try our prior sibling
	HTREEITEM htiPrev = m_tree.GetNextItem(hti, TVGN_PREVIOUS);
	
	// if we have one then first try its last child
	if (htiPrev)
	{
		if (bAllowChildren && m_tree.ItemHasChildren(htiPrev) && IsItemExpanded(htiPrev))
		{
			HTREEITEM htiChild = m_tree.GetChildItem(htiPrev);
			
			while (htiChild)
			{
				htiPrev = htiChild;
				htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
			}
		}
		// else we settle for htiPrev as-is
	}
	else // get parent
		htiPrev = m_tree.GetParentItem(hti);

	return htiPrev == TVI_ROOT ? NULL : htiPrev;
}

void CTreeSelectionHelper::RemoveChildDuplicates()
{
	POSITION pos = GetFirstItemPos();

	while (pos)
	{
		HTREEITEM hti = GetNextItem(pos);
		HTREEITEM htiParent = m_tree.GetParentItem(hti);

		while (htiParent)
		{
			if (HasItem(htiParent))
				break;

			// else
			htiParent = m_tree.GetParentItem(htiParent);
		}

		// if htiParent is not NULL then it was also selected
		if (htiParent)
			RemoveItem(hti);
	}
}

int CTreeSelectionHelper::FindItem(HTREEITEM htiFind, HTREEITEM htiStart)
{
	// try same first
	if (htiFind == htiStart)
		return 0;

	// then try up
	HTREEITEM htiPrev = GetPrevItem(htiStart);

	while (htiPrev)
	{
		if (htiPrev == htiFind)
			return -1;

		htiPrev = GetPrevItem(htiPrev);
	}

	// else try down
	HTREEITEM htiNext = GetNextItem(htiStart);

	while (htiNext)
	{
		if (htiNext == htiFind)
			return 1;

		htiNext = GetNextItem(htiNext);
	}

	// else
	return 0;
}

BOOL CTreeSelectionHelper::IsFullyVisible(HTREEITEM hti) const
{
	CRect rClient, rItem, rIntersect;

	m_tree.GetClientRect(rClient);
	m_tree.GetItemRect(hti, rItem, FALSE);

	return (rIntersect.IntersectRect(rItem, rClient) && rIntersect == rItem);
}

BOOL CTreeSelectionHelper::HasNextSelection() const
{
	return (m_nCurSelection < m_aHistory.GetSize() - 1);
}

BOOL CTreeSelectionHelper::NextSelection()
{
	if (HasNextSelection())
	{
		int nSizeHistory = m_aHistory.GetSize();

		// invalidate current selection
		InvalidateAll(FALSE);

		// save current selection in history
		m_aHistory[m_nCurSelection] = m_lstSelection;

		// copy next selection
		m_nCurSelection++;
		m_lstSelection = m_aHistory[m_nCurSelection];

		// invalidate new selection
		InvalidateAll(FALSE);

		return TRUE;
	}

	return FALSE;
}

BOOL CTreeSelectionHelper::HasPrevSelection() const
{
	return m_nCurSelection && m_aHistory.GetSize();
}

BOOL CTreeSelectionHelper::PrevSelection()
{
	if (HasPrevSelection())
	{
		int nSizeHistory = m_aHistory.GetSize();

		// invalidate current selection
		InvalidateAll(FALSE);

		// save current selection in history
		if (m_nCurSelection < nSizeHistory)
			m_aHistory[m_nCurSelection] = m_lstSelection;
		else
			m_aHistory.Add(m_lstSelection);

		m_nCurSelection--;
		m_lstSelection = m_aHistory[m_nCurSelection];

		// invalidate new selection
		InvalidateAll(FALSE);

		return TRUE;
	}

	return FALSE;
}
