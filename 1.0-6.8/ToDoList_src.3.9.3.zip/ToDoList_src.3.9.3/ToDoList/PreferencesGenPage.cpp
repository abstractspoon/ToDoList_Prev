// PreferencesGenPage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesGenPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesGenPage property page

IMPLEMENT_DYNCREATE(CPreferencesGenPage, CPropertyPage)

CPreferencesGenPage::CPreferencesGenPage() : CPropertyPage(CPreferencesGenPage::IDD)
{
	//{{AFX_DATA_INIT(CPreferencesGenPage)
	//}}AFX_DATA_INIT

	// load settings
	m_bAlwaysOnTop = AfxGetApp()->GetProfileInt("Preferences", "AlwaysOnTop", FALSE);
	m_bUseSysTray = AfxGetApp()->GetProfileInt("Preferences", "UseSysTray", FALSE);
	m_bAutoSaveOnSysTray = AfxGetApp()->GetProfileInt("Preferences", "AutoSave", TRUE);
	m_bConfirmDelete = AfxGetApp()->GetProfileInt("Preferences", "ConfirmDelete", TRUE);
	m_bConfirmSaveOnExit = AfxGetApp()->GetProfileInt("Preferences", "ConfirmSaveOnExit", TRUE);
	m_bPromptReloadOnWritable = AfxGetApp()->GetProfileInt("Preferences", "PromptReloadOnWritable", TRUE);
	m_bPromptReloadOnTimestamp = AfxGetApp()->GetProfileInt("Preferences", "PromptReloadOnTimestamp", TRUE);
	m_bShowOnStartup = AfxGetApp()->GetProfileInt("Preferences", "ShowOnStartup", TRUE);
	m_nSysTrayOption = AfxGetApp()->GetProfileInt("Preferences", "SysTrayOption", STO_ONCLOSE);
	m_bToggleTrayVisibility = AfxGetApp()->GetProfileInt("Preferences", "ToggleTrayVisibility", FALSE);
	m_bEnableSourceControl = AfxGetApp()->GetProfileInt("Preferences", "EnableSourceControl", FALSE);
	m_bSourceControlLanOnly = AfxGetApp()->GetProfileInt("Preferences", "SourceControlLanOnly", TRUE);
	m_bAutoCheckOut = AfxGetApp()->GetProfileInt("Preferences", "AutoCheckOut", FALSE);
	m_bCheckoutOnCheckin = AfxGetApp()->GetProfileInt("Preferences", "CheckoutOnCheckin", FALSE);
	m_nReadonlyReloadOption = AfxGetApp()->GetProfileInt("Preferences", "ReadonlyReloadOption", RO_ASK) - 1;
	m_nTimestampReloadOption = AfxGetApp()->GetProfileInt("Preferences", "TimestampReloadOption", RO_ASK) - 1;
	m_bMultiInstance = AfxGetApp()->GetProfileInt("Preferences", "MultiInstance", FALSE);
	m_bCheckinOnClose = AfxGetApp()->GetProfileInt("Preferences", "CheckinOnClose", TRUE);
//	m_b = AfxGetApp()->GetProfileInt("Preferences", "", TRUE);
}

CPreferencesGenPage::~CPreferencesGenPage()
{
}

void CPreferencesGenPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesGenPage)
	DDX_Check(pDX, IDC_PROMPTRELOADONWRITABLE, m_bPromptReloadOnWritable);
	DDX_Check(pDX, IDC_PROMPTRELOADONCHANGE, m_bPromptReloadOnTimestamp);
	DDX_Check(pDX, IDC_SHOWONSTARTUP, m_bShowOnStartup);
	DDX_CBIndex(pDX, IDC_SYSTRAYOPTION, m_nSysTrayOption);
	DDX_Check(pDX, IDC_TOGGLETRAYVISIBILITY, m_bToggleTrayVisibility);
	DDX_Check(pDX, IDC_ENABLESOURCECONTROL, m_bEnableSourceControl);
	DDX_Check(pDX, IDC_SOURCECONTROLLANONLY, m_bSourceControlLanOnly);
	DDX_Check(pDX, IDC_AUTOCHECKOUT, m_bAutoCheckOut);
	DDX_Check(pDX, IDC_CHECKOUTONCHECKIN, m_bCheckoutOnCheckin);
	DDX_CBIndex(pDX, IDC_READONLYRELOADOPTION, m_nReadonlyReloadOption);
	DDX_CBIndex(pDX, IDC_TIMESTAMPRELOADOPTION, m_nTimestampReloadOption);
	DDX_Check(pDX, IDC_MULTIINSTANCE, m_bMultiInstance);
	DDX_Check(pDX, IDC_CHECKINONCLOSE, m_bCheckinOnClose);
	//}}AFX_DATA_MAP
	DDX_Check(pDX, IDC_ALWAYSONTOP, m_bAlwaysOnTop);
	DDX_Check(pDX, IDC_USESYSTRAY, m_bUseSysTray);
	DDX_Check(pDX, IDC_AUTOSAVEONSYSTRAY, m_bAutoSaveOnSysTray);
	DDX_Check(pDX, IDC_CONFIRMDELETE, m_bConfirmDelete);
	DDX_Check(pDX, IDC_CONFIRMSAVEONEXIT, m_bConfirmSaveOnExit);
}


BEGIN_MESSAGE_MAP(CPreferencesGenPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPreferencesGenPage)
	ON_BN_CLICKED(IDC_ENABLESOURCECONTROL, OnEnablesourcecontrol)
	ON_BN_CLICKED(IDC_PROMPTRELOADONWRITABLE, OnPromptreloadonwritable)
	ON_BN_CLICKED(IDC_PROMPTRELOADONCHANGE, OnPromptreloadontimestamp)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_USESYSTRAY, OnUseSystray)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesGenPage message handlers

BOOL CPreferencesGenPage::OnInitDialog() 
{
	CDialog::OnInitDialog();

	GetDlgItem(IDC_AUTOSAVEONSYSTRAY)->EnableWindow(m_bUseSysTray);
	GetDlgItem(IDC_SHOWONSTARTUP)->EnableWindow(m_bUseSysTray);
	GetDlgItem(IDC_SYSTRAYOPTION)->EnableWindow(m_bUseSysTray);
	GetDlgItem(IDC_TOGGLETRAYVISIBILITY)->EnableWindow(m_bUseSysTray);
	GetDlgItem(IDC_CONFIRMSAVEONEXIT)->EnableWindow(!m_bUseSysTray);

	GetDlgItem(IDC_SOURCECONTROLLANONLY)->EnableWindow(m_bEnableSourceControl);
	GetDlgItem(IDC_AUTOCHECKOUT)->EnableWindow(m_bEnableSourceControl);
	GetDlgItem(IDC_CHECKOUTONCHECKIN)->EnableWindow(m_bEnableSourceControl);
	GetDlgItem(IDC_CHECKINONCLOSE)->EnableWindow(m_bEnableSourceControl);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreferencesGenPage::OnUseSystray() 
{
	UpdateData();

	GetDlgItem(IDC_AUTOSAVEONSYSTRAY)->EnableWindow(m_bUseSysTray);
	GetDlgItem(IDC_SHOWONSTARTUP)->EnableWindow(m_bUseSysTray);
	GetDlgItem(IDC_SYSTRAYOPTION)->EnableWindow(m_bUseSysTray);
	GetDlgItem(IDC_TOGGLETRAYVISIBILITY)->EnableWindow(m_bUseSysTray);

	GetDlgItem(IDC_CONFIRMSAVEONEXIT)->EnableWindow(!m_bUseSysTray); // mutually exclusive
}

void CPreferencesGenPage::OnOK() 
{
	CPropertyPage::OnOK();
	
	// save settings
	AfxGetApp()->WriteProfileInt("Preferences", "AlwaysOnTop", m_bAlwaysOnTop);
	AfxGetApp()->WriteProfileInt("Preferences", "UseSysTray", m_bUseSysTray);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoSave", m_bAutoSaveOnSysTray);
	AfxGetApp()->WriteProfileInt("Preferences", "ConfirmDelete", m_bConfirmDelete);
	AfxGetApp()->WriteProfileInt("Preferences", "ConfirmSaveOnExit", m_bConfirmSaveOnExit);
	AfxGetApp()->WriteProfileInt("Preferences", "PromptReloadOnWritable", m_bPromptReloadOnWritable);
	AfxGetApp()->WriteProfileInt("Preferences", "PromptReloadOnTimestamp", m_bPromptReloadOnTimestamp);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowOnStartup", m_bShowOnStartup);
	AfxGetApp()->WriteProfileInt("Preferences", "SysTrayOption", m_nSysTrayOption);
	AfxGetApp()->WriteProfileInt("Preferences", "ToggleTrayVisibility", m_bToggleTrayVisibility);
	AfxGetApp()->WriteProfileInt("Preferences", "EnableSourceControl", m_bEnableSourceControl);
	AfxGetApp()->WriteProfileInt("Preferences", "SourceControlLanOnly", m_bSourceControlLanOnly);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoCheckOut", m_bAutoCheckOut);
	AfxGetApp()->WriteProfileInt("Preferences", "CheckoutOnCheckin", m_bCheckoutOnCheckin);
	AfxGetApp()->WriteProfileInt("Preferences", "ReadonlyReloadOption", m_nReadonlyReloadOption + 1);
	AfxGetApp()->WriteProfileInt("Preferences", "TimestampReloadOption", m_nTimestampReloadOption + 1);
	AfxGetApp()->WriteProfileInt("Preferences", "MultiInstance", m_bMultiInstance);
	AfxGetApp()->WriteProfileInt("Preferences", "CheckinOnClose", m_bCheckinOnClose);
//	AfxGetApp()->WriteProfileInt("Preferences", "", m_b);
}

void CPreferencesGenPage::OnEnablesourcecontrol() 
{
	UpdateData();

	GetDlgItem(IDC_SOURCECONTROLLANONLY)->EnableWindow(m_bEnableSourceControl);
	GetDlgItem(IDC_AUTOCHECKOUT)->EnableWindow(m_bEnableSourceControl);
	GetDlgItem(IDC_CHECKOUTONCHECKIN)->EnableWindow(m_bEnableSourceControl);
	GetDlgItem(IDC_CHECKINONCLOSE)->EnableWindow(m_bEnableSourceControl);
}

BOOL CPreferencesGenPage::GetReadonlyReloadOption() const
{ 
	if (!m_bPromptReloadOnWritable)
		return RO_NO;
	else
		return m_nReadonlyReloadOption + 1; 
}

BOOL CPreferencesGenPage::GetTimestampReloadOption() const 
{ 
	if (!m_bPromptReloadOnTimestamp)
		return RO_NO;
	else
		return m_nTimestampReloadOption + 1; 
}

void CPreferencesGenPage::OnPromptreloadonwritable() 
{
	// TODO: Add your control notification handler code here
	
}

void CPreferencesGenPage::OnPromptreloadontimestamp() 
{
	// TODO: Add your control notification handler code here
	
}
