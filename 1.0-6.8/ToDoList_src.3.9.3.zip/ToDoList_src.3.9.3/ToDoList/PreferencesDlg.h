#if !defined(AFX_PREFERENCESDLG_H__C3FCC72A_6C69_49A6_930D_D5C94EC31298__INCLUDED_)
#define AFX_PREFERENCESDLG_H__C3FCC72A_6C69_49A6_930D_D5C94EC31298__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesDlg.h : header file
//

#include "preferencesgenpage.h"
#include "preferencestaskpage.h"
#include "preferencestaskdefpage.h"
#include "preferencestoolpage.h"
#include "preferencesuipage.h"
#include "preferencesuitasklistpage.h"
#include "preferencesshortcutspage.h"
#include "preferencesfilepage.h"

#include "..\shared\propertypagehost.h"

/////////////////////////////////////////////////////////////////////////////
// CPreferencesDlg dialog

class CPreferencesDlg : public CDialog
{
// Construction
public:
	CPreferencesDlg(CShortcutManager* pMgr = NULL, UINT nMenuID = 0, CWnd* pParent = NULL);   // standard constructor
	virtual ~CPreferencesDlg();

	BOOL GetAlwaysOnTop() const { return m_pageGen.GetAlwaysOnTop(); }
	BOOL GetUseSysTray() const { return m_pageGen.GetUseSysTray(); }
	BOOL GetAutoSaveOnSysTray() const { return m_pageGen.GetAutoSaveOnSysTray(); }
	BOOL GetConfirmDelete() const { return m_pageGen.GetConfirmDelete(); }
	BOOL GetConfirmSaveOnExit() const { return m_pageGen.GetConfirmSaveOnExit(); }
	int GetReadonlyReloadOption() const { return m_pageGen.GetReadonlyReloadOption(); }
	int GetTimestampReloadOption() const { return m_pageGen.GetTimestampReloadOption(); }
	BOOL GetShowOnStartup() const { return m_pageGen.GetShowOnStartup(); }
	int GetSysTrayOption() const { return m_pageGen.GetSysTrayOption(); }
	BOOL GetToggleTrayVisibility() const { return m_pageGen.GetToggleTrayVisibility(); }
	BOOL GetEnableSourceControl() const { return m_pageGen.GetEnableSourceControl(); }
	BOOL GetSourceControlLanOnly() const { return m_pageGen.GetSourceControlLanOnly(); }
	BOOL GetAutoCheckOut() const { return m_pageGen.GetAutoCheckOut(); }
	BOOL GetCheckoutOnCheckin() const { return m_pageGen.GetCheckoutOnCheckin(); }
	BOOL GetMultiInstance() const { return m_pageGen.GetMultiInstance(); }
	BOOL GetCheckinOnClose() const { return m_pageGen.GetCheckinOnClose(); }

	BOOL GetNotifyDue() const { return m_pageFile.GetNotifyDue(); }
	int GetNotifyDueBy() const { return m_pageFile.GetNotifyDueBy(); }
	BOOL GetAutoArchive() const { return m_pageFile.GetAutoArchive(); }
	BOOL GetNotifyReadOnly() const { return m_pageFile.GetNotifyReadOnly(); }
	CString GetHtmlFont() const { return m_pageFile.GetHtmlFont(); }
	int GetHtmlFontSize() const { return m_pageFile.GetHtmlFontSize(); }
	BOOL GetPreviewExport() const { return m_pageFile.GetPreviewExport(); }
	int GetTextIndent() const { return m_pageFile.GetTextIndent(); }
	BOOL GetRemoveArchivedTasks() const { return m_pageFile.GetRemoveArchivedTasks(); }
	BOOL GetRemoveOnlyOnAbsoluteCompletion() const { return m_pageFile.GetRemoveOnlyOnAbsoluteCompletion(); }
	BOOL GetAutoHtmlExport() const { return m_pageFile.GetAutoHtmlExport(); }
	BOOL GetExportVisibleOnly() const { return m_pageFile.GetExportVisibleOnly(); }
	int GetAutoSaveFrequency() const { return m_pageFile.GetAutoSaveFrequency(); }
	CString GetAutoExportFolderPath() const { return m_pageFile.GetAutoExportFolderPath(); }
	BOOL GetExportParentTitleCommentsOnly() const { return m_pageFile.GetExportParentTitleCommentsOnly(); }
	BOOL GetExportSpaceForNotes() const { return m_pageFile.GetExportSpaceForNotes(); }

	int GetDefaultPriority() const { return m_pageTaskDef.GetDefaultPriority(); }
	CString GetDefaultAllocTo() const { return m_pageTaskDef.GetDefaultAllocTo(); }
	CString GetDefaultAllocBy() const { return m_pageTaskDef.GetDefaultAllocBy(); }
	CString GetDefaultStatus() const { return m_pageTaskDef.GetDefaultStatus(); }
	CString GetDefaultCategory() const { return m_pageTaskDef.GetDefaultCategory(); }
	double GetDefaultTimeEst(int& nUnits) const { return m_pageTaskDef.GetDefaultTimeEst(nUnits); }
	COLORREF GetDefaultColor() const { return m_pageTaskDef.GetDefaultColor(); }
	COleDateTime GetDefaultStartDate() const { return m_pageTaskDef.GetDefaultStartDate(); }
	BOOL GetUseParentAttrib(PTP_ATTRIB nAttrib) const { return m_pageTaskDef.GetUseParentAttrib(nAttrib); }
	
	BOOL GetAutoReSort() const { return m_pageTask.GetAutoReSort(); }
	BOOL GetAveragePercentSubCompletion() const { return m_pageTask.GetAveragePercentSubCompletion(); }
	BOOL GetIncludeDoneInAverageCalc() const { return m_pageTask.GetIncludeDoneInAverageCalc(); }
	BOOL GetUseEarliestDueDate() const { return m_pageTask.GetUseEarliestDueDate(); }
	BOOL GetUsePercentDoneInTimeEst() const { return m_pageTask.GetUsePercentDoneInTimeEst(); }
	BOOL GetTreatSubCompletedAsDone() const { return m_pageTask.GetTreatSubCompletedAsDone(); }
	BOOL GetHidePercentForDoneTasks() const { return m_pageTask.GetHidePercentForDoneTasks(); }
	BOOL GetHideZeroTimeEst() const { return m_pageTask.GetHideZeroTimeEst(); }
	BOOL GetHideStartDueForDoneTasks() const { return m_pageTask.GetHideStartDueForDoneTasks(); }
	BOOL GetShowPercentAsProgressbar() const { return m_pageTask.GetShowPercentAsProgressbar(); }
	BOOL GetQueryApplyChangestoSubtasks() const { return m_pageTask.GetQueryApplyChangestoSubtasks(); }
	BOOL GetSortVisibleOnly() const { return m_pageTask.GetSortVisibleOnly(); }
	BOOL GetUseHighestPriority() const { return m_pageTask.GetUseHighestPriority(); }
	BOOL GetAutoCalcTimeEstimates() const { return m_pageTask.GetAutoCalcTimeEstimates(); }
	BOOL GetRoundTimeFractions() const { return m_pageTask.GetRoundTimeFractions(); }
	BOOL GetShowNonFilesAsText() const { return m_pageTask.GetShowNonFilesAsText(); }
	BOOL GetIncludeDoneInPriorityCalc() const { return m_pageTask.GetIncludeDoneInPriorityCalc(); }
	BOOL GetWeightPercentCompletionByTimeEst() const { return m_pageTask.GetWeightPercentCompletionByTimeEst(); }
	BOOL GetWeightPercentCompletionByPriority() const { return m_pageTask.GetWeightPercentCompletionByPriority(); }

	BOOL GetShowCtrlsAsColumns() const { return m_pageUI.GetShowCtrlsAsColumns(); }
	BOOL GetShowCommentsAlways() const { return m_pageUI.GetShowCommentsAlways(); }
	BOOL GetAutoReposCtrls() const { return m_pageUI.GetAutoReposCtrls(); }
	CString GetToolbarImagePath() const { return m_pageUI.GetToolbarImagePath(); }
	BOOL GetSharedCommentsHeight() const { return m_pageUI.GetSharedCommentsHeight(); }
	BOOL GetAutoHideTabbar() const { return m_pageUI.GetAutoHideTabbar(); }
	BOOL GetStackTabbarItems() const { return m_pageUI.GetStackTabbarItems(); }
	BOOL GetRightAlignLabels() const { return m_pageUI.GetRightAlignLabels(); }

	BOOL GetColorTextByPriority() const { return m_pageUITasklist.GetColorTextByPriority(); }
	BOOL GetShowButtonsInTree() const { return m_pageUITasklist.GetShowButtonsInTree(); }
	BOOL GetShowInfoTips() const { return m_pageUITasklist.GetShowInfoTips(); }
	BOOL GetShowComments() const { return m_pageUITasklist.GetShowComments(); }
	BOOL GetShowColumn(PTP_COLUMN nColumn) const { return m_pageUITasklist.GetShowColumn(nColumn); }
	BOOL GetColorPriority() const { return m_pageUITasklist.GetColorPriority(); }
	int GetPriorityColors(CDWordArray& aColors) const { return m_pageUITasklist.GetPriorityColors(aColors); }
	BOOL GetTreeFont(CString& sFaceName, int& nPointSize) const { return m_pageUITasklist.GetTreeFont(sFaceName, nPointSize); }
	COLORREF GetGridlineColor() const { return m_pageUITasklist.GetGridlineColor(); }
	COLORREF GetTaskDoneColor() const { return m_pageUITasklist.GetTaskDoneColor(); }
	BOOL GetShowPathInHeader() const { return m_pageUITasklist.GetShowPathInHeader(); }
	BOOL GetStrikethroughDone() const { return m_pageUITasklist.GetStrikethroughDone(); }
	BOOL GetFullRowSelection() const { return m_pageUITasklist.GetFullRowSelection(); }
	BOOL GetTreeCheckboxes() const { return m_pageUITasklist.GetTreeCheckboxes(); }
	BOOL GetEnableHeaderSorting() const { return m_pageUITasklist.GetEnableHeaderSorting(); }
	CString GetCheckboxImagePath() const { return m_pageUITasklist.GetCheckboxImagePath(); }
	COLORREF GetCheckboxMaskColor() const { return m_pageUITasklist.GetCheckboxMaskColor(); }
	BOOL GetColorTaskBackground() const { return m_pageUITasklist.GetColorTaskBackground(); }
	BOOL GetCommentsUseTreeFont() const { return m_pageUITasklist.GetCommentsUseTreeFont(); }
	BOOL GetDisplayDatesInISO() const { return m_pageUITasklist.GetDisplayDatesInISO(); }
	BOOL GetShowWeekdayInDates() const { return m_pageUITasklist.GetShowWeekdayInDates(); }

	int GetUserTools(CUserToolArray& aTools) const { return m_pageTool.GetUserTools(aTools); }

//	BOOL Get() const { return m_b; }

protected:
// Dialog Data
	//{{AFX_DATA(CPreferencesDlg)
	CTreeCtrl m_tcPages;
	//}}AFX_DATA

	CPropertyPageHost m_pphost;
	CPreferencesGenPage m_pageGen;
	CPreferencesFilePage m_pageFile;
	CPreferencesUIPage m_pageUI;
	CPreferencesUITasklistPage m_pageUITasklist;
	CPreferencesTaskPage m_pageTask;
	CPreferencesTaskDefPage m_pageTaskDef;
	CPreferencesToolPage m_pageTool;
	CPreferencesShortcutsPage m_pageShortcuts;
	CMapPtrToPtr m_mapPP2HTI;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	virtual void OnOK();

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnHelp();
	afx_msg void OnSelchangedPages(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	void AddPage(CPropertyPage* pPage, LPCTSTR szPath);
	void SetActivePage(int nPage);
	CString GetItemPath(HTREEITEM hti);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESDLG_H__C3FCC72A_6C69_49A6_930D_D5C94EC31298__INCLUDED_)
