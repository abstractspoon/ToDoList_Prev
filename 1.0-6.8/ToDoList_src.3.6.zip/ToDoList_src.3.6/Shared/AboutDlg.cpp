// AboutDlg.cpp : implementation file
//

#include "stdafx.h"
#include "AboutDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog

enum // ctrl IDs
{
	IDC_APPICON = 100,
	IDC_APPNAME, // 101
	IDC_DIVIDER, // 102
	IDC_APPDESCRIPTION, // 103
	IDC_COPYRIGHT // 104
};

const LPCTSTR RCCONTROLS = "\
    ICON            0,100,5,5,20,20 \
    LTEXT           \"\",101,36,7,167,8,SS_NOPREFIX \
    DEFPUSHBUTTON   \"OK\",1,79,80,50,14,WS_GROUP \
    CONTROL         \"\",102,\"Static\",SS_ETCHEDHORZ,7,72,196,1 \
    LTEXT           \"\", 103,36,21,167,26,SS_NOPREFIX \
    LTEXT           \"\", 104,36,50,167,16,SS_NOPREFIX \
";

CAboutDlg::CAboutDlg(UINT nAppIconID, LPCTSTR szAppName, LPCTSTR szAppDescription, LPCTSTR szCopyright) 
		: CRuntimeDlg(), m_sAppName(szAppName), m_sAppDescription(szAppDescription), m_sCopyright(szCopyright)
{
	SetBordersDLU(5);

	AddRCControl("ICON", "", "", SS_ICON, 0, 5,5,20,20, IDC_APPICON);
	AddRCControl("LTEXT", "", "", SS_NOPREFIX, 0, 36,7,167,8, IDC_APPNAME);
	AddRCControl("CONTROL", "static", "", SS_ETCHEDHORZ, 0, 7,72,196,1, IDC_DIVIDER);
	AddRCControl("LTEXT", "", "", SS_NOPREFIX, 0, 36,21,167,26, IDC_APPDESCRIPTION);
	AddRCControl("EDITTEXT", "", "", WS_TABSTOP | ES_READONLY | ES_MULTILINE | WS_VSCROLL | ES_NOHIDESEL, 0, 36,50,167,18, IDC_COPYRIGHT);
	AddRCControl("DEFPUSHBUTTON", "", "OK", WS_GROUP, 0, 79,80,50,14, IDOK);

	m_hIcon = AfxGetApp()->LoadIcon(nAppIconID);
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CRuntimeDlg::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_APPICON, m_stIcon);
	DDX_Text(pDX, IDC_APPNAME, m_sAppName);
	DDX_Text(pDX, IDC_APPDESCRIPTION, m_sAppDescription);
	DDX_Text(pDX, IDC_COPYRIGHT, m_sCopyright);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CRuntimeDlg)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg message handlers

int CAboutDlg::DoModal()
{
	return CRuntimeDlg::DoModal("About...", WS_VISIBLE | WS_POPUP | WS_BORDER | WS_CAPTION | DS_CENTER);
}

BOOL CAboutDlg::OnInitDialog() 
{
	CRuntimeDlg::OnInitDialog();
	
	if (m_hIcon)
		((CStatic*)GetDlgItem(IDC_APPICON))->SetIcon(m_hIcon);

	CWnd* pCopyright = GetDlgItem(IDC_COPYRIGHT);

	if (pCopyright)
	{
		pCopyright->ModifyStyle(WS_BORDER, 0);
		pCopyright->ModifyStyleEx(WS_EX_CLIENTEDGE, 0);
		pCopyright->SetWindowPos(NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
	}

	GetDlgItem(IDOK)->SetFocus();
	
	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
