// DateHelper.cpp: implementation of the CDateHelper class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DateHelper.h"

#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

int CDateHelper::CalcDaysFromTo(const COleDateTime& dateFrom, const COleDateTime& dateTo, BOOL bInclusive)
{
	int nDiff = (int)dateTo.m_dt - (int)dateFrom.m_dt;

	return nDiff + (bInclusive ? 1 : 0);
}

int CDateHelper::CalcDaysFromTo(const COleDateTime& dateFrom, DH_DATE nTo, BOOL bInclusive)
{
	return CalcDaysFromTo(dateFrom, GetDate(nTo), bInclusive);
}

int CDateHelper::CalcDaysFromTo(DH_DATE nFrom, DH_DATE nTo, BOOL bInclusive)
{
	ASSERT (nFrom <= nTo);

	if (nFrom > nTo)
		return 0;
	
	else if (nFrom == nTo)
		return bInclusive ? 1 : 0;

	// else
	return CalcDaysFromTo(GetDate(nFrom), GetDate(nTo), bInclusive);
}

double CDateHelper::GetDate(DH_DATE nDate)
{
	COleDateTime date;

	switch (nDate)
	{
	case DHD_TODAY:
		date = COleDateTime::GetCurrentTime();
		break;

	case DHD_TOMORROW:
		date = GetDate(DHD_TODAY) + 1;
		break;

	case DHD_ENDTHISWEEK:
		{
			// we must get the locale info to find out when this 
			// user's week starts
			date = COleDateTime::GetCurrentTime();
			date -= date.GetDayOfWeek() - FirstDayOfWeek(); // start of week
			date += 6;
		}
		break;

	case DHD_ENDNEXTWEEK:
		return GetDate(DHD_ENDTHISWEEK) + 7;

	case DHD_ENDTHISMONTH:
		{
			date = COleDateTime::GetCurrentTime();
			int nThisMonth = date.GetMonth();

			while (date.GetMonth() == nThisMonth)
				date += 20; // much quicker than doing it one day at a time

			date -= date.GetDay(); // because we went into next month
		}
		break;

	case DHD_ENDNEXTMONTH:
		{
			date = GetDate(DHD_ENDTHISMONTH) + 1; // first day of next month
			int nNextMonth = date.GetMonth();

			while (date.GetMonth() == nNextMonth)
				date += 20; // much quicker than doing it one day at a time

			date -= date.GetDay(); // because we went into next month + 1
		}
		break;

	case DHD_ENDTHISYEAR:
		date = COleDateTime::GetCurrentTime(); // for current year
		date = COleDateTime(date.GetYear(), 12, 31, 0, 0, 0);
		break;

	case DHD_ENDNEXTYEAR:
		date = COleDateTime::GetCurrentTime(); // for current year
		date = COleDateTime(date.GetYear() + 1, 12, 31, 0, 0, 0);
		break;

	default:
		ASSERT (0);
		date.m_dt = 0;
		break;
	}

	return (double)(int)date;
}

int CDateHelper::CalcWeekdaysFromTo(const COleDateTime& dateFrom, const COleDateTime& dateTo, BOOL bInclusive)
{
	int nWeekdays = 0;
	int nDiff = (int)(double)dateTo - (int)(double)dateFrom;

	if (nDiff > 0)
	{
		COleDateTime dFrom(floor(dateFrom.m_dt));
		COleDateTime dTo(floor(dateTo.m_dt));

		if (bInclusive)
			dTo += 1;

		while (dFrom < dTo)
		{
			int nDOW = dFrom.GetDayOfWeek();

			if (nDOW != 1 && nDOW != 7)
				nWeekdays++;

			dFrom += 1;
		}
	}

	return nWeekdays;
}

int CDateHelper::FirstDayOfWeek()
{
	char szFDW[3]; // 2 + NULL

	::GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_IFIRSTDAYOFWEEK, szFDW, 2);

	return atoi(szFDW) + 1;
}

CString CDateHelper::FormatDate(const COleDateTime& date, BOOL bISOFormat, BOOL bWantDOW)
{
	CString sDate;

	if (bISOFormat)
	{
		if (bWantDOW)
			sDate.Format("%s %s", GetShortWeekday(date.GetDayOfWeek()), date.Format("%Y-%m-%d"));
		else
			sDate = date.Format("%Y-%m-%d");
	}
	else
	{
		if (bWantDOW)
			sDate.Format("%s %s", GetShortWeekday(date.GetDayOfWeek()), date.Format(VAR_DATEVALUEONLY));
		else
			sDate = date.Format(VAR_DATEVALUEONLY);
	}

	return sDate;
}

CString CDateHelper::FormatCurrentDate(BOOL bISOFormat, BOOL bWantDOW)
{
	return FormatDate(COleDateTime::GetCurrentTime(), bISOFormat, bWantDOW);
}

CString CDateHelper::GetShortWeekday(int nWeekday)
{
	LCTYPE lct = LOCALE_SABBREVDAYNAME1;
	CString sWeekday;

	// data check
	if (nWeekday < 1 || nWeekday> 7)
		return "";

	switch (nWeekday)
	{
		case 1: // sun
			lct = LOCALE_SABBREVDAYNAME7;
			break;
		case 2: // mon
			lct = LOCALE_SABBREVDAYNAME1;
			break;
		case 3: // tue
			lct = LOCALE_SABBREVDAYNAME2;
			break;
		case 4: // wed
			lct = LOCALE_SABBREVDAYNAME3;
			break;
		case 5: // thu
			lct = LOCALE_SABBREVDAYNAME4;
			break;
		case 6: // fri
			lct = LOCALE_SABBREVDAYNAME5;
			break;
		case 7: // sat
			lct = LOCALE_SABBREVDAYNAME6;
			break;
	}

	GetLocaleInfo(LOCALE_USER_DEFAULT, lct, sWeekday.GetBuffer(30),	29);
	sWeekday.ReleaseBuffer();

	return sWeekday;
}

void CDateHelper::OffsetDate(COleDateTime& date, int nAmount, DH_UNITS nUnits)
{
	if (date.m_dt > 0)
	{
		switch (nUnits)
		{
		case DHU_DAYS:
			date += (double)nAmount;
			break;

		case DHU_WEEKS:
			date += nAmount * 7.0;
			break;

		case DHU_MONTHS:
			{
				SYSTEMTIME st;
				date.GetAsSystemTime(st);

				// convert amount to years and months
				int nYear = (int)st.wYear + (nAmount / 12);
				int nMonth = (int)st.wMonth + (nAmount % 12);

				// handle overflow
				if (nMonth > 12)
				{
					nYear++;
					nMonth -= 12;
				}
				else if (nMonth < 1)
				{
					nYear--;
					nMonth += 12;
				}

				// update time
				date.SetDateTime(nYear, nMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
			}
			break;
		}
	}
}

