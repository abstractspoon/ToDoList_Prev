// FilteredToDoCtrl.h: interface for the CFilteredToDoCtrl class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILTEREDTODOCTRL_H__356A6EB9_C7EC_4395_8716_623AFF4A269B__INCLUDED_)
#define AFX_FILTEREDTODOCTRL_H__356A6EB9_C7EC_4395_8716_623AFF4A269B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ToDoCtrl.h"
#include "..\shared\misc.h"

enum FILTER_TYPE
{
	FT_ALL,
	FT_NOTDONE,
	FT_DONE, 
	FT_DUETODAY,
	FT_DUETOMORROW,
	FT_DUEENDTHISWEEK, 
	FT_DUEENDNEXTWEEK, 
	FT_DUEENDTHISMONTH,
	FT_DUEENDNEXTMONTH,
	FT_DUEENDTHISYEAR,
	FT_DUEENDNEXTYEAR,
};

enum
{
	FT_ANYCATEGORY	= 0x01,
};

struct FTDCFILTER
{
	FTDCFILTER() : nFilter(FT_ALL), nPriority(-1), nRisk(-1), dwFlags(0) {}

	void operator=(const FTDCFILTER& filter)
	{
		nFilter = filter.nFilter;
		nPriority = filter.nPriority;
		nRisk = filter.nRisk;
		sAllocTo = filter.sAllocTo;
		sStatus = filter.sStatus;
		sAllocBy = filter.sAllocBy;
		aCategories.Copy(filter.aCategories);
		dwFlags = filter.dwFlags;
	}

	BOOL operator==(const FTDCFILTER& filter) const
	{
		return (filter.nFilter == nFilter && filter.nPriority == nPriority &&
				filter.nRisk == nRisk && filter.sAllocTo == sAllocTo &&
				filter.sStatus == sStatus && filter.sAllocBy == sAllocBy &&
				Misc::ArraysMatch(aCategories, filter.aCategories) &&
				dwFlags == filter.dwFlags);
	}

	BOOL operator!=(const FTDCFILTER& filter) const
	{
		return !(*this == filter);
	}
	
	BOOL IsSet() const
	{
		return (nFilter != FT_ALL || nPriority >= 0 || nRisk >= 0 ||
			aCategories.GetSize() || !sAllocTo.IsEmpty() ||
			!sStatus.IsEmpty() || !sAllocBy.IsEmpty()) ? 1 : 0;
	}

	BOOL HasFlag(DWORD dwFlag) const
	{
		return ((dwFlags & dwFlag) == dwFlag);
	}

	void SetFlag(DWORD dwFlag, BOOL bOn = TRUE)
	{
		if (bOn)
			dwFlags |= dwFlag;
		else
			dwFlags &= ~dwFlags;
	}

	BOOL MatchCategories(const CStringArray& aCats) const
	{
		if (HasFlag(FT_ANYCATEGORY))
			return Misc::MatchAny(aCategories, aCats);
		else
			return Misc::ArraysMatch(aCategories, aCats);
	}

	void Reset()
	{
		*this = FTDCFILTER(); // empty filter
	}
	
	FILTER_TYPE nFilter;
	int nPriority, nRisk;
	CStringArray aCategories;
	CString sStatus;
	CString sAllocTo, sAllocBy;
	DWORD dwFlags;
};

enum FTMATCHRESULT
{
	FTDC_MATCH,
	FTDC_NOMATCHSTATE,
	FTDC_NOMATCHCATEGORY,
	FTDC_NOMATCHALLOCTO,
	FTDC_NOMATCHPRIORITY,
	FTDC_NOMATCHALLOCBY,
	FTDC_NOMATCHSTATUS,
	FTDC_NOMATCHRISK,
};

class CFilteredToDoCtrl : public CToDoCtrl  
{
public:
	CFilteredToDoCtrl(CContentMgr& mgr, int nDefaultContent = 0);
	virtual ~CFilteredToDoCtrl();

	void SetFilter(const FTDCFILTER& filter);
	FILTER_TYPE GetFilter(FTDCFILTER& filter) const;
	void RefreshFilter();
	void ClearFilter();
	BOOL HasFilter() const { return m_filter.IsSet(); }

	UINT GetTaskCount(UINT* pVisible = 0) const;
	BOOL DeleteSelectedTask() { return CToDoCtrl::DeleteSelectedTask(); }

protected:
	CTaskFile m_tasksHidden;
	FTDCFILTER m_filter;
	COleDateTime m_dateDue;
	UINT m_nHiddenCount;
	
protected:
	virtual int GetAllTasks(CTaskFile& tasks) const;
	virtual HTREEITEM SetAllTasks(const CTaskFile& tasks);

	void FilterTasks(CTaskFile& tasksHide, HTASKITEM htHide, CTaskFile& tasksShow, HTASKITEM htShow);
	FTMATCHRESULT MatchFilter(const CTaskFile& tasks, HTASKITEM ht) const;
	BOOL MatchCategory(const CTaskFile& tasks, HTASKITEM ht) const;
	BOOL MatchStatus(const CTaskFile& tasks, HTASKITEM ht) const;
	BOOL MatchAllocTo(const CTaskFile& tasks, HTASKITEM ht) const;
	BOOL MatchAllocBy(const CTaskFile& tasks, HTASKITEM ht) const;
	BOOL MatchPriority(const CTaskFile& tasks, HTASKITEM ht) const;
	BOOL MatchRisk(const CTaskFile& tasks, HTASKITEM ht) const;
	BOOL MatchDueDate(const CTaskFile& tasks, HTASKITEM ht) const;
	void InitDueDate();

	BOOL IsTaskDone(const CTaskFile& tasks, HTASKITEM ht, BOOL bCheckParents = TRUE) const; // checks parents
	virtual BOOL DeleteSelectedTask(BOOL bWarnUser, BOOL bResetSel = FALSE);
	virtual BOOL SelectedTasksHaveChildren() const;
};

#endif // !defined(AFX_FILTEREDTODOCTRL_H__356A6EB9_C7EC_4395_8716_623AFF4A269B__INCLUDED_)
