#if !defined(AFX_TDCSTRUCT_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_)
#define AFX_TDCSTRUCT_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// tdlutil.h : header file
//

#include "tdcenum.h"
#include "taskfile.h"
#include "..\shared\TreeSelectionHelper.h"
#include "..\shared\TreeCtrlHelper.h"

typedef CMap<TDC_STYLE, TDC_STYLE, BOOL, BOOL&> CTDCStyles;
typedef CMap<CString, LPCTSTR, COLORREF, COLORREF&> CTDCColorMap;

struct TDCFILTER
{
	TDCFILTER() : 
			nFilter(TDCF_ALL), dwFlags(TDCGT_ISODATES) {}

	TDCFILTER(TDC_FILTER filter, DWORD flags, double dueBy = 0) :
			nFilter(filter), dwFlags(flags), dateDueBy(dueBy) {}

	TDC_FILTER nFilter;
	COleDateTime dateDueBy;
	DWORD dwFlags;
	CString sAllocTo;
};

struct TDLSELECTION
{
	TDLSELECTION(CTreeCtrl& tree) : selection(tree), htiLastHandledLBtnDown(NULL), 
									tch(tree), nLBtnDownFlags(0), nNcLBtnDownColID(-1) {}

	CTreeSelectionHelper selection;
	CTreeCtrlHelper tch;
	HTREEITEM htiLastHandledLBtnDown;
	UINT nLBtnDownFlags;
	int nNcLBtnDownColID;

	BOOL HasIncompleteSubtasks()
	{
		POSITION pos = selection.GetFirstItemPos();

		while (pos)
		{
			HTREEITEM hti = selection.GetNextItem(pos);

			if (ItemHasIncompleteSubtasks(hti))
				return TRUE;
		}

		return FALSE;
	}
	
	BOOL ItemHasIncompleteSubtasks(HTREEITEM hti)
	{
		const CTreeCtrl& tree = selection.TreeCtrl();
		HTREEITEM htiChild = tree.GetChildItem(hti);

		while (htiChild)
		{
			if (tch.GetItemCheckState(htiChild) != TCHC_CHECKED || 
            ItemHasIncompleteSubtasks(htiChild))
				return TRUE;

			htiChild = tree.GetNextItem(htiChild, TVGN_NEXT);
		}

		return FALSE;
	}
};

struct TDLCLIPBOARD
{
	TDLCLIPBOARD() : hwndToDoCtrl(NULL) {}
	
	CTaskFile tasks;
	HWND hwndToDoCtrl;
};

struct TDCCONTROL
{
	LPCTSTR szClass;
	UINT nIDCaption;
	DWORD dwStyle;
	DWORD dwExStyle; 
	int nX;
	int nY;
	int nCx;
	int nCy;
	UINT nID;
};

struct TDCCOLUMN
{
	TDC_COLUMN nColID;
	UINT nIDName;
	TDC_SORTBY nSortBy;
	UINT nAlignment;
	BOOL bClickable;
	LPCTSTR szFont;
	BOOL bSymbolFont;
	BOOL bSortAscending;
};

struct CTRLITEM
{
	UINT nCtrlID;
	UINT nLabelID;
	TDC_COLUMN nCol;
};

struct SEARCHPARAMS
{
	SEARCHPARAMS() : nFindWhat(0), dwFlags(0), nFrom(0), nTo(0), dFrom(0), dTo(0) {}
	int nFindWhat;
	DWORD dwFlags; // see above
	
	CString sText;
	COleDateTime dateFrom, dateTo;
	int nFrom, nTo;
	double dFrom, dTo;
};

struct SEARCHRESULT
{
	SEARCHRESULT() : dwID(0), hti(NULL), nMatch(0), dMatch(0), bDone(0) {}
	DWORD dwID;
	HTREEITEM hti;
	CString sMatch;
	COleDateTime dateMatch;
	int nMatch;
	double dMatch;
	BOOL bDone;
};

typedef CArray<SEARCHRESULT, SEARCHRESULT&> CResultArray;


#endif // AFX_TDCSTRUCT_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_
