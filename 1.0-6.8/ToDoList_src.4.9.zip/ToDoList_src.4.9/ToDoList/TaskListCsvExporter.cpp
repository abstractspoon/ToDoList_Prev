// TaskListCsvExporter.cpp: implementation of the CTaskListCsvExporter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TaskListCsvExporter.h"
#include "tdlschemadef.h"
#include "resource.h"

#include <locale.h>

#include "..\shared\timehelper.h"
#include "..\shared\enstring.h"
#include "..\shared\misc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const LPCTSTR SPACE = " ";
const LPCTSTR ENDL = "\n";
const LPCTSTR ONEDBLQUOTE = "\"";
const LPCTSTR TWODBLQUOTE = "\"\"";

CTaskListCsvExporter::CTaskListCsvExporter()
{

}

CTaskListCsvExporter::~CTaskListCsvExporter()
{

}

bool CTaskListCsvExporter::Export(const ITaskList* pSrcTaskFile, const char* szDestFilePath)
{
	const ITaskList4* pTasks = NULL;
	
	if ((const_cast<ITaskList*>(pSrcTaskFile))->QueryInterface(IID_TASKLIST4, (void**)&pTasks))
		return false;

	DELIM = Misc::GetListSeparator();
	
	// what follows is definitely a hack!
	// but that's the joy of programming :)
	ROUNDTIMEFRACTIONS = AfxGetApp()->GetProfileInt("Preferences", "RoundTimeFractions", FALSE);

	CStdioFile fileOut;

	if (fileOut.Open(szDestFilePath, CFile::modeCreate | CFile::modeWrite))
	{
		CString sOutput;

		if (!ExportTask(pTasks, NULL, 0, 0, "", sOutput).IsEmpty())
		{
			fileOut.WriteString(ColumnHeadings());
			fileOut.WriteString(sOutput);
			return true;
		}
	}

	return false;
}

CString CTaskListCsvExporter::ColumnHeadings() const
{
	CString sHeadings;

	sHeadings += CEnString(IDS_PTUIP_POS) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_ID) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_TITLE) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_PERCENT) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_PRIORITY) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_TIMEEST) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_TIMESPENT) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_CREATEDATE) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_CREATEDBY) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_STARTDATE) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_DUEDATE) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_DONEDATE) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_ALLOCTO) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_ALLOCBY) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_CATEGORY) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_STATUS) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_RISK) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_EXTERNALID) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_MODIFYDATE) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_COST) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_FILEREF) + DELIM;
	sHeadings += CEnString(IDS_PTUIP_COMMENTS) + DELIM;

	return sHeadings;
}

CString& CTaskListCsvExporter::ExportTask(const ITaskList4* pTasks, HTASKITEM hTask, int nDepth, 
										  int nPos, const CString& sParentPos, CString& sOutput) const
{
	CString sPos; // becomes parent pos for sub-tasks

	// handle locale specific decimal separator
	setlocale(LC_NUMERIC, "");

	// if depth == 0 then we're at the root so just add sub-tasks
	// else insert pItem first
	if (nDepth > 0)
	{
		// if there is a POS child item then this replaces nPos
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKPOS))
			nPos = pTasks->GetTaskPosition(hTask);

		if (nDepth == 1) // top level tasks
			sPos.Format("%d", nPos);
		else
			sPos.Format("%s.%d", sParentPos, nPos);

		AppendAttribute(sPos, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKID, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKTITLE, sOutput);

		// %, priority
		AppendAttribute(pTasks->GetTaskPercentDone(hTask, TRUE), "%d%%", sOutput);
		AppendAttribute(pTasks->GetTaskPriority(hTask, TRUE), "%d", sOutput);

		// times
		char cUnits;
		int nTimePlaces = ROUNDTIMEFRACTIONS ? 0 : 2;

		double dTimeEst = pTasks->GetTaskTimeEstimate(hTask, cUnits, TRUE);
		dTimeEst = CTimeHelper::GetTime(dTimeEst, cUnits, THU_HOURS);
		AppendAttribute(CTimeHelper::FormatTime(dTimeEst, nTimePlaces), sOutput);

		double dTimeSpent = pTasks->GetTaskTimeSpent(hTask, cUnits, TRUE);
		dTimeSpent = CTimeHelper::GetTime(dTimeSpent, cUnits, THU_HOURS);
		AppendAttribute(CTimeHelper::FormatTime(dTimeSpent, nTimePlaces), sOutput);

		// the rest
		AppendAttribute(pTasks, hTask, TDL_TASKCREATIONDATESTRING, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKCREATEDBY, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKSTARTDATESTRING, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKDUEDATESTRING, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKDONEDATESTRING, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKALLOCTO, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKALLOCBY, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKCATEGORY, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKSTATUS, sOutput);
		AppendAttribute(pTasks->GetTaskRisk(hTask, TRUE), "%d", sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKEXTERNALID, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKLASTMODSTRING, sOutput);
		AppendAttribute(pTasks->GetTaskCost(hTask, TRUE), "%.2f", sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKFILEREFPATH, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKCOMMENTS, sOutput);
	}

	// add sub-tasks
	hTask = pTasks->GetFirstTask(hTask);

	if (hTask) // at least one sub-task
	{
		int nChildPos = 1;

		while (hTask)
		{
			CString sTask;
			sOutput += ENDL;
			sOutput += ExportTask(pTasks, hTask, nDepth + 1, nChildPos++, sPos, sTask);

			hTask = pTasks->GetNextTask(hTask);
		}
	}

	// extra line between top level items
	if (nDepth == 1)
		sOutput += ENDL;

	// restore decimal separator to '.'
	setlocale(LC_NUMERIC, "English");

	return sOutput;
}

void CTaskListCsvExporter::AppendAttribute(const ITaskList* pTasks, HTASKITEM hTask, 
										   LPCTSTR szAttribName, CString& sOutput) const
{
	if (pTasks->TaskHasAttribute(hTask, szAttribName))
		AppendAttribute(pTasks->GetTaskAttribute(hTask, szAttribName), sOutput);
	else
		sOutput += DELIM;
}

void CTaskListCsvExporter::AppendAttribute(LPCTSTR szAttrib, CString& sOutput) const
	{
	BOOL bNeedQuoting = FALSE;
	CString sAttrib(szAttrib);
	
	// double up quotes
	if (sAttrib.Find(ONEDBLQUOTE) != -1)
	{
		sAttrib.Replace(ONEDBLQUOTE, TWODBLQUOTE);
		bNeedQuoting = TRUE;
	}

	if (sAttrib.Find(DELIM) != -1)
		bNeedQuoting = TRUE;
	
	if (bNeedQuoting)
		sAttrib = ONEDBLQUOTE + sAttrib + ONEDBLQUOTE;
	
	// replace carriage returns
	sAttrib.Replace(ENDL, SPACE);
	
	sAttrib += DELIM;
	sOutput += sAttrib;
}

void CTaskListCsvExporter::AppendAttribute(double dAttrib, LPCTSTR szFormat, CString& sOutput) const
{
	CString sAttrib;

	sAttrib.Format(szFormat, dAttrib);
	AppendAttribute(sAttrib, sOutput);
}

void CTaskListCsvExporter::AppendAttribute(int nAttrib, LPCTSTR szFormat, CString& sOutput) const
{
	CString sAttrib;

	sAttrib.Format(szFormat, nAttrib);
	AppendAttribute(sAttrib, sOutput);
}
