// PreferencesToolPage.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "PreferencesToolPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesToolPage property page

LPCTSTR PLACEHOLDERS[] = 
{
	// must match the order of commands in resource.h
	"\"$(pathname)\"", // ID_TOOLS_PATHNAME      
	"$(filetitle)", // ID_TOOLS_FILETITLE     
	"$(folder)", // ID_TOOLS_FOLDER        
	"$(filename)", // ID_TOOLS_FILENAME      
	"$(userdate, date1, Date)", // ID_TOOLS_USERDATE      
	"\"$(userfile, file1, Filepath)\"", // ID_TOOLS_USERFILEPATH  
	"$(userfolder, folder1, Folder)", // ID_TOOLS_USERFOLDER    
	"$(usertext, text1, Text)", // ID_TOOLS_USERTEXT      
	"$(todaysdate)" // ID_TOOLS_TODAYSDATE    
};

const int NUMPLACEHOLDERS = sizeof(PLACEHOLDERS) / sizeof(LPCTSTR);

IMPLEMENT_DYNCREATE(CPreferencesToolPage, CPropertyPage)

CPreferencesToolPage::CPreferencesToolPage() : CPropertyPage(CPreferencesToolPage::IDD)
{
	m_psp.dwFlags &= ~PSP_HASHELP;

	//{{AFX_DATA_INIT(CPreferencesToolPage)
	m_sToolPath = _T("");
	m_sCommandLine = _T("");
	//}}AFX_DATA_INIT

	// load tools
	int nToolCount = AfxGetApp()->GetProfileInt("Tools", "ToolCount", 0);

	for (int nTool = 1; nTool <= nToolCount; nTool++)
	{
		CString sKey;
		sKey.Format("Tools\\Tool%d", nTool);

		USERTOOL ut;
		ut.sToolName = AfxGetApp()->GetProfileString(sKey, "Name", "");
		ut.sToolPath = AfxGetApp()->GetProfileString(sKey, "Path", "");
		ut.sCmdline = AfxGetApp()->GetProfileString(sKey, "CmdLine", "0xffffffff"); // deliberately odd default to test for existence

		if (ut.sCmdline == "0xffffffff")
		{
			// backward compatibility
			BOOL nIncludeCmdlinePath = AfxGetApp()->GetProfileInt(sKey, "IncludeCmdlinePath", -1);

			if (nIncludeCmdlinePath) // 1 or -1
				ut.sCmdline = PLACEHOLDERS[0];
			else
				ut.sCmdline.Empty();
		}

		m_aTools.Add(ut);
	}
}

CPreferencesToolPage::~CPreferencesToolPage()
{
}

void CPreferencesToolPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesToolPage)
	DDX_Control(pDX, IDC_DISPLAYPLACEHOLDERS, m_btPlaceholders);
	DDX_Control(pDX, IDC_CMDLINE, m_eCmdLine);
	DDX_Control(pDX, IDC_TOOLPATH, m_eToolPath);
	DDX_Control(pDX, IDC_TOOLLIST, m_lcTools);
	DDX_Text(pDX, IDC_TOOLPATH, m_sToolPath);
	DDX_Text(pDX, IDC_CMDLINE, m_sCommandLine);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPreferencesToolPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPreferencesToolPage)
	ON_BN_CLICKED(IDC_NEWTOOL, OnNewtool)
	ON_BN_CLICKED(IDC_DELETETOOL, OnDeletetool)
	ON_NOTIFY(LVN_ENDLABELEDIT, IDC_TOOLLIST, OnEndlabeleditToollist)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_TOOLLIST, OnItemchangedToollist)
	ON_EN_CHANGE(IDC_TOOLPATH, OnChangeToolpath)
	ON_NOTIFY(LVN_KEYDOWN, IDC_TOOLLIST, OnKeydownToollist)
	ON_EN_CHANGE(IDC_CMDLINE, OnChangeCmdline)
	ON_BN_CLICKED(IDC_DISPLAYPLACEHOLDERS, OnDisplayPlaceholders)
	ON_COMMAND_RANGE(ID_TOOLS_PATHNAME, ID_TOOLS_TODAYSDATE, OnInsertPlaceholder)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesToolPage message handlers

void CPreferencesToolPage::OnNewtool() 
{
	int nIndex = m_lcTools.InsertItem(m_lcTools.GetItemCount(), "New Tool", -1);
	m_lcTools.SetItemText(nIndex, 2, PLACEHOLDERS[0]);

	m_lcTools.SetItemState(nIndex, LVIS_SELECTED, LVIS_SELECTED);
	m_lcTools.SetFocus();
	m_lcTools.EditLabel(nIndex);
}

void CPreferencesToolPage::OnDeletetool() 
{
	int nSel = GetCurSel();

	if (nSel >= 0)
	{
		m_lcTools.DeleteItem(nSel);
		m_sToolPath.Empty();

		EnableControls();
		UpdateData(FALSE);
	}
}

void CPreferencesToolPage::OnEndlabeleditToollist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;
	
	if (pDispInfo->item.pszText)
	{
		int nSel = GetCurSel();

		if (nSel >= 0)
		{
			m_lcTools.SetItemText(nSel, 0, pDispInfo->item.pszText);

			GetDlgItem(IDC_TOOLPATH)->SetFocus();
		}
	}
	
	*pResult = 0;
}

void CPreferencesToolPage::OnItemchangedToollist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	EnableControls();
	int nSel = GetCurSel();

	if (nSel >= 0)
	{
		m_sToolPath = m_lcTools.GetItemText(pNMListView->iItem, 1);
		m_sCommandLine = m_lcTools.GetItemText(pNMListView->iItem, 2);
	}
	else
	{
		m_sToolPath.Empty();
		m_sCommandLine.Empty();
	}

	UpdateData(FALSE);

	*pResult = 0;
}

BOOL CPreferencesToolPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	m_ilSys.Initialize();
	m_lcTools.SetImageList(m_ilSys.GetImageList(), LVSIL_SMALL);

	m_lcTools.InsertColumn(0, "Tool Name", LVCFMT_LEFT, 150);
	m_lcTools.InsertColumn(1, "File Path", LVCFMT_LEFT, 250);
	m_lcTools.InsertColumn(2, "Command Line", LVCFMT_LEFT, 150);

	m_lcTools.SetExtendedStyle(m_lcTools.GetExtendedStyle() | LVS_EX_FULLROWSELECT);

	// add tools we loaded from the registry
	for (int nTool = 0; nTool < m_aTools.GetSize(); nTool++)
	{
		int nIndex = m_lcTools.InsertItem(nTool, m_aTools[nTool].sToolName, 
											m_ilSys.GetFileImageIndex(m_aTools[nTool].sToolPath));

		m_lcTools.SetItemText(nIndex, 1, m_aTools[nTool].sToolPath);
		m_lcTools.SetItemText(nIndex, 2, m_aTools[nTool].sCmdline);
	}

	m_lcTools.SetItemState(0, LVIS_SELECTED, LVIS_SELECTED);

	EnableControls();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreferencesToolPage::EnableControls()
{
	int nSel = GetCurSel();

	GetDlgItem(IDC_NEWTOOL)->EnableWindow(m_lcTools.GetItemCount() < 16);
	GetDlgItem(IDC_DELETETOOL)->EnableWindow(nSel >= 0);
	GetDlgItem(IDC_TOOLPATH)->EnableWindow(nSel >= 0);
	GetDlgItem(IDC_CMDLINE)->EnableWindow(nSel >= 0);
	m_btPlaceholders.EnableWindow(nSel >= 0);
}

int CPreferencesToolPage::GetCurSel()
{
	int nSel = -1;
	POSITION pos = m_lcTools.GetFirstSelectedItemPosition();

	if (pos)
		nSel = m_lcTools.GetNextSelectedItem(pos);

	return nSel;
}

void CPreferencesToolPage::OnChangeToolpath() 
{
	int nSel = GetCurSel();

	if (nSel >= 0)
	{
		UpdateData();

		m_lcTools.SetItemText(nSel, 1, m_sToolPath);

		// update the image
		LVITEM lvi;
		lvi.mask = LVIF_IMAGE;
		lvi.iItem = nSel;
		lvi.iImage = m_ilSys.GetFileImageIndex(m_sToolPath);

		m_lcTools.SetItem(&lvi);
	}
	else
		ASSERT (0);
}

int CPreferencesToolPage::GetUserTools(CUserToolArray& aTools)
{
	aTools.Copy(m_aTools);

	return aTools.GetSize();
}

void CPreferencesToolPage::OnOK() 
{
	CPropertyPage::OnOK();
	
	// save tools to registry and m_aTools
	int nToolCount = 0;

	for (int nTool = 0; nTool < m_lcTools.GetItemCount(); nTool++)
	{
		USERTOOL ut;

		ut.sToolName = m_lcTools.GetItemText(nTool, 0);
		ut.sToolPath = m_lcTools.GetItemText(nTool, 1);
		ut.sCmdline = m_lcTools.GetItemText(nTool, 2);

		CString sKey;
		sKey.Format("Tools\\Tool%d", nTool + 1);
		
		AfxGetApp()->WriteProfileString(sKey, "Name", ut.sToolName);
		AfxGetApp()->WriteProfileString(sKey, "Path", ut.sToolPath);
		AfxGetApp()->WriteProfileString(sKey, "Cmdline", ut.sCmdline);
		
		m_aTools.Add(ut);
	}

	AfxGetApp()->WriteProfileInt("Tools", "ToolCount", m_lcTools.GetItemCount());
}

void CPreferencesToolPage::OnKeydownToollist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_KEYDOWN* pLVKeyDown = (LV_KEYDOWN*)pNMHDR;
	
	switch (pLVKeyDown->wVKey)
	{
	case VK_DELETE:
		OnDeletetool();
		break;

	case VK_F2:
		{
			int nSel = GetCurSel();

			if (nSel >= 0)
				m_lcTools.EditLabel(nSel);
		}
		break;
	}
	
	*pResult = 0;
}

void CPreferencesToolPage::OnChangeCmdline() 
{
	int nSel = GetCurSel();

	if (nSel >= 0)
	{
		UpdateData();

		m_lcTools.SetItemText(nSel, 2, m_sCommandLine);
	}
}

void CPreferencesToolPage::OnDisplayPlaceholders() 
{
	// display placeholder insert menu
	CMenu menu, *pSubMenu;
	
	if (menu.LoadMenu(IDR_PLACEHOLDERS))
	{
		pSubMenu = menu.GetSubMenu(0);
		
		if (pSubMenu)
		{
			CRect rButton;
			m_btPlaceholders.GetWindowRect(rButton);
			m_btPlaceholders.SetState(TRUE);

			TPMPARAMS tpmp;
			tpmp.cbSize = sizeof(TPMPARAMS);
			tpmp.rcExclude = rButton;
			
			::TrackPopupMenuEx(*pSubMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON, 
								rButton.right, rButton.top, *this, &tpmp);
			
			m_btPlaceholders.SetState(FALSE);
		}
	}
}

void CPreferencesToolPage::OnInsertPlaceholder(UINT nCmdID) 
{
	int nItem = nCmdID - ID_TOOLS_PATHNAME;
	ASSERT (nItem >= 0 && nItem < NUMPLACEHOLDERS);

	if (nItem < 0 || nItem >= NUMPLACEHOLDERS)
		return;

	m_eCmdLine.ReplaceSel(PLACEHOLDERS[nItem], TRUE);
}
