#if !defined(AFX_PREFERENCESDLG_H__C3FCC72A_6C69_49A6_930D_D5C94EC31298__INCLUDED_)
#define AFX_PREFERENCESDLG_H__C3FCC72A_6C69_49A6_930D_D5C94EC31298__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesDlg.h : header file
//

#include "preferencesgenpage.h"
#include "preferencestaskpage.h"
#include "preferencestoolpage.h"
#include "preferencesuipage.h"

/////////////////////////////////////////////////////////////////////////////
// CPreferencesDlg dialog

class CPreferencesDlg : public CPropertySheet
{
// Construction
public:
	CPreferencesDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CPreferencesDlg();

	CString GetHtmlFont() { return m_pageGen.GetHtmlFont(); }
	BOOL GetPreviewSaveAs() { return m_pageGen.GetPreviewSaveAs(); }
	int GetTextIndent() { return m_pageGen.GetTextIndent(); }
	BOOL GetAlwaysOnTop() { return m_pageGen.GetAlwaysOnTop(); }
	BOOL GetUseSysTray() { return m_pageGen.GetUseSysTray(); }
	BOOL GetAutoSave() { return m_pageGen.GetAutoSave(); }
	BOOL GetConfirmDelete() { return m_pageGen.GetConfirmDelete(); }
	BOOL GetNotifyDue() { return m_pageGen.GetNotifyDue(); }
	BOOL GetAutoArchive() { return m_pageGen.GetAutoArchive(); }
	BOOL GetConfirmSaveOnExit() { return m_pageGen.GetConfirmSaveOnExit(); }
	BOOL GetRemoveArchivedTasks() { return m_pageGen.GetRemoveArchivedTasks(); }
	BOOL GetRemoveOnlyOnAbsoluteCompletion() { return m_pageGen.GetRemoveOnlyOnAbsoluteCompletion(); }
	BOOL GetNotifyReadOnly() { return m_pageGen.GetNotifyReadOnly(); }
	BOOL GetPromptReloadOnWritable() { return m_pageGen.GetPromptReloadOnWritable(); }
	BOOL GetAutoHtmlExport() { return m_pageGen.GetAutoHtmlExport(); }
	BOOL GetPromptReloadOnTimestamp() { return m_pageGen.GetPromptReloadOnTimestamp(); }
	BOOL GetShowMenuBar() { return m_pageGen.GetShowMenuBar(); }
	BOOL GetExportVisibleOnly() { return m_pageGen.GetExportVisibleOnly(); }
	BOOL GetShowOnStartup() { return m_pageGen.GetShowOnStartup(); }

	int GetDefaultPriority() { return m_pageTask.GetDefaultPriority(); }
	CString GetDefaultPerson() { return m_pageTask.GetDefaultPerson(); }
	int GetDefaultTimeEst() { return m_pageTask.GetDefaultTimeEst(); }
	COLORREF GetDefaultColor() { return m_pageTask.GetDefaultColor(); }
	BOOL GetUseParentColorAttrib() { return m_pageTask.GetUseParentColorAttrib(); }
	BOOL GetUseParentPersonAttrib() { return m_pageTask.GetUseParentPersonAttrib(); }
	BOOL GetUseParentPriorityAttrib() { return m_pageTask.GetUseParentPriorityAttrib(); }
	BOOL GetUseParentTimeEstAttrib() { return m_pageTask.GetUseParentTimeEstAttrib(); }
	BOOL GetAutoReSort() { return m_pageTask.GetAutoReSort(); }

	BOOL GetAveragePercentSubCompletion() { return m_pageUI.GetAveragePercentSubCompletion(); }
	BOOL GetIncludeDoneInAverageCalc() { return m_pageUI.GetIncludeDoneInAverageCalc(); }
	BOOL GetColorTextByPriority() { return m_pageUI.GetColorTextByPriority(); }
	BOOL GetVaryCommentsHeight() { return m_pageUI.GetVaryCommentsHeight(); }
	BOOL GetShowButtonsInTree() { return m_pageUI.GetShowButtonsInTree(); }
	BOOL GetGrayoutSubCompleted() { return m_pageUI.GetGrayoutSubCompleted(); }
	BOOL GetShowInfoTips() { return m_pageUI.GetShowInfoTips(); }
	BOOL GetShowComments() { return m_pageUI.GetShowComments(); }
	BOOL GetShowColumn(PTP_COLUMN nColumn) { return m_pageUI.GetShowColumn(nColumn); }
	BOOL GetHidePercentSubCompleted() { return m_pageUI.GetHidePercentSubCompleted(); }
	BOOL GetColorPriority() { return m_pageUI.GetColorPriority(); }
	int GetPriorityColors(CDWordArray& aColors) { return m_pageUI.GetPriorityColors(aColors); }
	BOOL GetTreeFont(CString& sFaceName, int& nPointSize) { return m_pageUI.GetTreeFont(sFaceName, nPointSize); }
	BOOL GetUseEarliestDueDate() { return m_pageUI.GetUseEarliestDueDate(); }
	BOOL GetUsePercentDoneInTimeEst() { return m_pageUI.GetUsePercentDoneInTimeEst(); }
	BOOL GetShowCtrlsAsColumns() { return m_pageUI.GetShowCtrlsAsColumns(); }
	BOOL GetShowCommentsAlways() { return m_pageUI.GetShowCommentsAlways(); }

	int GetUserTools(CUserToolArray& aTools) { return m_pageTool.GetUserTools(aTools); }


//	BOOL Get() { return m_b; }

protected:
	CPreferencesGenPage m_pageGen;
	CPreferencesTaskPage m_pageTask;
	CPreferencesUIPage m_pageUI;
	CPreferencesToolPage m_pageTool;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesDlg)
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESDLG_H__C3FCC72A_6C69_49A6_930D_D5C94EC31298__INCLUDED_)
