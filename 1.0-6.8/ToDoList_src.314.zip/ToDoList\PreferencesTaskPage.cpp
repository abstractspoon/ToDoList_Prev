// PreferencesTaskPage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesTaskPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesTaskPage property page

IMPLEMENT_DYNCREATE(CPreferencesTaskPage, CPropertyPage)

CPreferencesTaskPage::CPreferencesTaskPage() : CPropertyPage(CPreferencesTaskPage::IDD)
{
	m_psp.dwFlags &= ~PSP_HASHELP;

	//{{AFX_DATA_INIT(CPreferencesTaskPage)
	//}}AFX_DATA_INIT

	// load settings
	m_nDefPriority = AfxGetApp()->GetProfileInt("Preferences", "DefaultPriority", 5);
	m_sDefPerson = AfxGetApp()->GetProfileString("Preferences", "DefaultPerson", "");
	m_nDefTimeEst = AfxGetApp()->GetProfileInt("Preferences", "DefaultTimeEstimate", 0);
	m_crDef = AfxGetApp()->GetProfileInt("Preferences", "DefaultColor", 0);
	m_bUseParentAttributes = AfxGetApp()->GetProfileInt("Preferences", "UseParentAttributes", TRUE);
	m_bUseParentColorAttrib = AfxGetApp()->GetProfileInt("Preferences", "UseParentColorAttrib", TRUE);
	m_bUseParentPersonAttrib = AfxGetApp()->GetProfileInt("Preferences", "UseParentPersonAttrib", TRUE);
	m_bUseParentPriorityAttrib = AfxGetApp()->GetProfileInt("Preferences", "UseParentPriorityAttrib", TRUE);
	m_bUseParentTimeEstAttrib = AfxGetApp()->GetProfileInt("Preferences", "UseParentTimeEstAttrib", TRUE);
	m_bAutoReSort = AfxGetApp()->GetProfileInt("Preferences", "AutoReSort", FALSE);
}

CPreferencesTaskPage::~CPreferencesTaskPage()
{
}

void CPreferencesTaskPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesTaskPage)
	DDX_CBIndex(pDX, IDC_DEFAULTPRIORITY, m_nDefPriority);
	DDX_Text(pDX, IDC_DEFAULTPERSON, m_sDefPerson);
	DDX_Text(pDX, IDC_DEFAULTTIMEEST, m_nDefTimeEst);
	DDX_Check(pDX, IDC_USEPARENTATTRIB, m_bUseParentAttributes);
	DDX_Check(pDX, IDC_USEPARENTCOLORATTRIB, m_bUseParentColorAttrib);
	DDX_Check(pDX, IDC_USEPARENTPERSONATTRIB, m_bUseParentPersonAttrib);
	DDX_Check(pDX, IDC_USEPARENTPRIORITYATTRIB, m_bUseParentPriorityAttrib);
	DDX_Check(pDX, IDC_USEPARENTTIMEESTATTRIB, m_bUseParentTimeEstAttrib);
	DDX_Check(pDX, IDC_AUTORESORT, m_bAutoReSort);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_SETDEFAULTCOLOR, m_btDefColor);
}


BEGIN_MESSAGE_MAP(CPreferencesTaskPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPreferencesTaskPage)
	ON_BN_CLICKED(IDC_SETDEFAULTCOLOR, OnSetdefaultcolor)
	ON_BN_CLICKED(IDC_USEPARENTATTRIB, OnUseparentattrib)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesTaskPage message handlers

BOOL CPreferencesTaskPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	GetDlgItem(IDC_USEPARENTPERSONATTRIB)->EnableWindow(m_bUseParentAttributes);
	GetDlgItem(IDC_USEPARENTPRIORITYATTRIB)->EnableWindow(m_bUseParentAttributes);
	GetDlgItem(IDC_USEPARENTTIMEESTATTRIB)->EnableWindow(m_bUseParentAttributes);
	GetDlgItem(IDC_USEPARENTCOLORATTRIB)->EnableWindow(m_bUseParentAttributes);
	
	m_btDefColor.SetColor(m_crDef);
		
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreferencesTaskPage::OnSetdefaultcolor() 
{
	m_crDef = m_btDefColor.GetColor();
}

void CPreferencesTaskPage::OnUseparentattrib() 
{
	UpdateData();

	GetDlgItem(IDC_USEPARENTPERSONATTRIB)->EnableWindow(m_bUseParentAttributes);
	GetDlgItem(IDC_USEPARENTPRIORITYATTRIB)->EnableWindow(m_bUseParentAttributes);
	GetDlgItem(IDC_USEPARENTTIMEESTATTRIB)->EnableWindow(m_bUseParentAttributes);
	GetDlgItem(IDC_USEPARENTCOLORATTRIB)->EnableWindow(m_bUseParentAttributes);
}

void CPreferencesTaskPage::OnOK() 
{
	CPropertyPage::OnOK();
	
	// save settings
	AfxGetApp()->WriteProfileInt("Preferences", "DefaultPriority", m_nDefPriority);
	AfxGetApp()->WriteProfileString("Preferences", "DefaultPerson", m_sDefPerson);
	AfxGetApp()->WriteProfileInt("Preferences", "DefaultTimeEstimate", m_nDefTimeEst);
	AfxGetApp()->WriteProfileInt("Preferences", "DefaultColor", m_crDef);
	AfxGetApp()->WriteProfileInt("Preferences", "UseParentAttributes", m_bUseParentAttributes);
	AfxGetApp()->WriteProfileInt("Preferences", "UseParentColorAttrib", m_bUseParentColorAttrib);
	AfxGetApp()->WriteProfileInt("Preferences", "UseParentPersonAttrib", m_bUseParentPersonAttrib);
	AfxGetApp()->WriteProfileInt("Preferences", "UseParentPriorityAttrib", m_bUseParentPriorityAttrib);
	AfxGetApp()->WriteProfileInt("Preferences", "UseParentTimeEstAttrib", m_bUseParentTimeEstAttrib);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoReSort", m_bAutoReSort);
//	AfxGetApp()->WriteProfileInt("Preferences", "", m_b);
}
