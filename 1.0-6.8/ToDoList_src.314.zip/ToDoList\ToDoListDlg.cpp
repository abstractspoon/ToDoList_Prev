// ToDoListDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ToDoList.h"
#include "ToDoListDlg.h"
#include "preferencesdlg.h"
#include "ToolsCmdlineParser.h"
#include "ToolsUserInputDlg.h"

#include "..\shared\aboutdlg.h"
#include "..\shared\holdredraw.h"
#include "..\shared\driveinfo.h"
#include "..\shared\autoflag.h"
#include "..\shared\deferWndMove.h"

#define COMPILE_MULTIMON_STUBS
#include <multimon.h>
#include <afxpriv.h>        // for WM_KICKIDLE

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CToDoListDlg dialog

// popup menus
enum { SORT, NEWTASK, EDITTASK, TRAYICON, TASKCONTEXT, DELETETASK, FILEALL, TOOLS, MOVE };
enum { SAVEASXML, SAVEASHTM, SAVEASTXT };
const LPCTSTR SAVEASXMLFILTER = "Task Lists (*.xml)|*.xml||";
const LPCTSTR SAVEASHTMFILTER = "Web Pages (*.htm, *.html)|*.htm;*.html||";
const LPCTSTR SAVEASTXTFILTER = "Plain Text (*.txt)|*.txt||";
const LPCTSTR ASCOPYRIGHT = "ToDoList � AbstractSpoon";

enum 
{
	TIMER_CHECKREADONLY = 1,
	TIMER_CHECKTIMESTAMP,
};

CToDoListDlg::CToDoListDlg(BOOL bVisible, LPCTSTR szTDListPath, CWnd* pParent /*=NULL*/) : CDialog(CToDoListDlg::IDD, pParent), 
 		m_sCmdLineFilePath(szTDListPath), 
		m_bVisible(bVisible ? 1 : -1), 
		m_mruList(0, "MRU", "TaskList%d", 16),
		m_nLastSelItem(-1),
		m_bSimpleMode(FALSE),
		m_stFilePath(TRUE),
		m_bInNewTask(FALSE),
		m_bSaving(FALSE),
		m_bInTimer(FALSE)
{
	//{{AFX_DATA_INIT(CToDoListDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CToDoListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CToDoListDlg)
	DDX_Control(pDX, IDC_TABCONTROL, m_tabCtrl);
	DDX_Control(pDX, IDC_FILENAME, m_stFilePath);
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_FILENAME, m_sStatus);
}

BEGIN_MESSAGE_MAP(CToDoListDlg, CDialog)
	//{{AFX_MSG_MAP(CToDoListDlg)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_DELETETASK, OnDeleteTask)
	ON_COMMAND(ID_DELETEALLTASKS, OnDeleteAllTasks)
	ON_WM_SIZE()
	ON_WM_GETMINMAXINFO()
	ON_COMMAND(ID_SAVE_NORMAL, OnSave)
	ON_COMMAND(ID_LOAD_NORMAL, OnLoad)
	ON_WM_DESTROY()
	ON_COMMAND(ID_NEW, OnNew)
	ON_UPDATE_COMMAND_UI(ID_DELETETASK, OnUpdateDeletetask)
	ON_UPDATE_COMMAND_UI(ID_EDITTASK, OnUpdateEdittask)
	ON_UPDATE_COMMAND_UI(ID_EDIT_TASKCOLOR, OnUpdateTaskcolor)
	ON_UPDATE_COMMAND_UI(ID_EDIT_TASKDONE, OnUpdateTaskdone)
	ON_UPDATE_COMMAND_UI(ID_DELETEALLTASKS, OnUpdateDeletealltasks)
	ON_UPDATE_COMMAND_UI(ID_SAVE_NORMAL, OnUpdateSave)
	ON_UPDATE_COMMAND_UI(ID_NEW, OnUpdateNew)
	ON_WM_ERASEBKGND()
	ON_COMMAND(ID_NEWTASK_ATTOP, OnNewtaskAttop)
	ON_COMMAND(ID_NEWTASK_ATBOTTOM, OnNewtaskAtbottom)
	ON_COMMAND(ID_NEWTASK_AFTERSELECTEDTASK, OnNewtaskAfterselectedtask)
	ON_COMMAND(ID_NEWTASK_BEFORESELECTEDTASK, OnNewtaskBeforeselectedtask)
	ON_UPDATE_COMMAND_UI(ID_SORT, OnUpdateSort)
	ON_COMMAND(ID_NEWSUBTASK_ATBOTTOM, OnNewsubtaskAtbottom)
	ON_COMMAND(ID_NEWSUBTASK_ATTOP, OnNewsubtaskAttop)
	ON_COMMAND(ID_EDIT_TASKCOLOR, OnEditTaskcolor)
	ON_COMMAND(ID_EDIT_TASKDONE, OnEditTaskdone)
	ON_COMMAND(ID_EDIT_TASKTEXT, OnEditTasktext)
	ON_COMMAND(ID_MOVETASKDOWN, OnMovetaskdown)
	ON_UPDATE_COMMAND_UI(ID_MOVETASKDOWN, OnUpdateMovetaskdown)
	ON_COMMAND(ID_MOVETASKUP, OnMovetaskup)
	ON_UPDATE_COMMAND_UI(ID_MOVETASKUP, OnUpdateMovetaskup)
	ON_WM_CLOSE()
	ON_COMMAND(ID_TRAYICON_CLOSE, OnTrayiconClose)
	ON_WM_WINDOWPOSCHANGING()
	ON_UPDATE_COMMAND_UI(ID_NEWSUBTASK_ATBOTTOM, OnUpdateNewsubtaskAtBottom)
	ON_COMMAND(ID_SAVEAS, OnSaveas)
	ON_UPDATE_COMMAND_UI(ID_SAVEAS, OnUpdateSaveas)
	ON_WM_CONTEXTMENU()
	ON_WM_GETDLGCODE()
	ON_COMMAND(ID_TRAYICON_SHOW, OnTrayiconShow)
	ON_WM_QUERYENDSESSION()
	ON_UPDATE_COMMAND_UI(ID_FILE_MRU_FILE1, OnUpdateRecentFileMenu)
	ON_COMMAND(ID_ABOUT, OnAbout)
	ON_COMMAND(ID_PREFERENCES, OnPreferences)
	ON_WM_COPYDATA()
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_COMMAND(ID_EDIT_COPYASTEXT, OnEditCopyastext)
	ON_COMMAND(ID_EDIT_COPYASHTML, OnEditCopyashtml)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
	ON_UPDATE_COMMAND_UI(ID_NEWTASK_ATTOP, OnUpdateNewtaskAttop)
	ON_UPDATE_COMMAND_UI(ID_NEWTASK_ATBOTTOM, OnUpdateNewtaskAtbottom)
	ON_UPDATE_COMMAND_UI(ID_NEWTASK_AFTERSELECTEDTASK, OnUpdateNewtaskAfterselectedtask)
	ON_UPDATE_COMMAND_UI(ID_NEWTASK_BEFORESELECTEDTASK, OnUpdateNewtaskBeforeselectedtask)
	ON_UPDATE_COMMAND_UI(ID_NEWSUBTASK_ATTOP, OnUpdateNewsubtaskAttop)
	ON_COMMAND(ID_SIMPLEMODE, OnSimplemode)
	ON_UPDATE_COMMAND_UI(ID_SIMPLEMODE, OnUpdateSimplemode)
	ON_COMMAND(ID_OPEN_RELOAD, OnReload)
	ON_UPDATE_COMMAND_UI(ID_OPEN_RELOAD, OnUpdateReload)
	ON_UPDATE_COMMAND_UI(ID_DELETE, OnUpdateDelete)
	ON_COMMAND(ID_ARCHIVE_COMPLETEDTASKS, OnArchiveCompletedtasks)
	ON_UPDATE_COMMAND_UI(ID_ARCHIVE_COMPLETEDTASKS, OnUpdateArchiveCompletedtasks)
	ON_COMMAND(ID_EXPORT_TOHTML, OnExportTohtml)
	ON_UPDATE_COMMAND_UI(ID_EXPORT_TOHTML, OnUpdateExportTohtml)
	ON_COMMAND(ID_EXPORT_TOPLAINTEXT, OnExportToplaintext)
	ON_UPDATE_COMMAND_UI(ID_EXPORT_TOPLAINTEXT, OnUpdateExportToplaintext)
	ON_COMMAND(ID_PRINT, OnPrint)
	ON_UPDATE_COMMAND_UI(ID_PRINT, OnUpdatePrint)
	ON_COMMAND(ID_MOVETASKRIGHT, OnMovetaskright)
	ON_UPDATE_COMMAND_UI(ID_MOVETASKRIGHT, OnUpdateMovetaskright)
	ON_COMMAND(ID_MOVETASKLEFT, OnMovetaskleft)
	ON_UPDATE_COMMAND_UI(ID_MOVETASKLEFT, OnUpdateMovetaskleft)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TABCONTROL, OnSelchangeTabcontrol)
	ON_NOTIFY(TCN_SELCHANGING, IDC_TABCONTROL, OnSelchangingTabcontrol)
	ON_COMMAND(ID_CLOSE, OnCloseTasklist)
	ON_COMMAND(ID_SAVEALL, OnSaveall)
	ON_UPDATE_COMMAND_UI(ID_SAVEALL, OnUpdateSaveall)
	ON_COMMAND(ID_CLOSEALL, OnCloseall)
	ON_UPDATE_COMMAND_UI(ID_CLOSEALL, OnUpdateCloseall)
	ON_COMMAND(ID_EXIT, OnExit)
	ON_UPDATE_COMMAND_UI(ID_MOVETASK, OnUpdateMovetask)
	ON_WM_TIMER()
	ON_COMMAND(ID_IMPORT_TASKLIST, OnImportTasklist)
	ON_COMMAND_RANGE(ID_SORT_BYDONEDATE, ID_SORT_BYNAME, OnSortBy)
	ON_UPDATE_COMMAND_UI_RANGE(ID_SORT_BYDONEDATE, ID_SORT_BYNAME, OnUpdateSortBy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_TASKTEXT, OnUpdateEditTasktext)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
	ON_COMMAND(ID_TRAYICON_CREATETASK, OnTrayiconCreatetask)
	ON_COMMAND_RANGE(ID_EDIT_SETPRIORITY0, ID_EDIT_SETPRIORITY10, OnSetPriority)
	ON_UPDATE_COMMAND_UI_RANGE(ID_EDIT_SETPRIORITY0, ID_EDIT_SETPRIORITY10, OnUpdateSetPriority)
	ON_COMMAND(ID_EDIT_SETFILEREF, OnEditSetfileref)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SETFILEREF, OnUpdateEditSetfileref)
	ON_COMMAND(ID_EDIT_OPENFILEREF, OnEditOpenfileref)
	ON_UPDATE_COMMAND_UI(ID_EDIT_OPENFILEREF, OnUpdateEditOpenfileref)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPYASHTML, OnUpdateEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPYASTEXT, OnUpdateEditCopy)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_USERTOOL1, OnUpdateUserTool1)
	ON_COMMAND_RANGE(ID_TOOLS_USERTOOL1, ID_TOOLS_USERTOOL16, OnUserTool)
	ON_WM_INITMENUPOPUP()
	ON_NOTIFY(NM_CLICK, IDC_TRAYICON, OnTrayIconClick)
	ON_NOTIFY(NM_DBLCLK, IDC_TRAYICON, OnTrayIconDblClk)
	ON_NOTIFY(NM_RCLICK, IDC_TRAYICON, OnTrayIconRClick)
	ON_REGISTERED_MESSAGE(WM_TDCN_SORT, OnToDoCtrlNotifySort)
	ON_REGISTERED_MESSAGE(WM_TDCN_MODIFY, OnToDoCtrlNotifyMod)
	ON_REGISTERED_MESSAGE(WM_TDCN_MINWIDTHCHANGE, OnToDoCtrlNotifyMinWidthChange)
	ON_REGISTERED_MESSAGE(WM_TDL_SHOWWINDOW , OnToDoListShowWindow)
	ON_COMMAND_EX_RANGE(ID_FILE_MRU_FILE1, ID_FILE_MRU_FILE16, OnOpenRecentFile)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CToDoListDlg message handlers
/*
BOOL CToDoListDlg::IsXP()
{
	OSVERSIONINFO vinfo;
	vinfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
		
	BOOL rslt = GetVersionEx(&vinfo);
		
	if (rslt && vinfo.dwPlatformId == VER_PLATFORM_WIN32_NT)
	{
		switch (vinfo.dwMajorVersion)
		{
		case 3: // nt351
		case 4: // nt4
			return FALSE;
			
		case 5: // >= w2k
			switch (vinfo.dwMinorVersion)
			{
			case 0: // w2k
				return FALSE;
				
			default: // >= xp
				return TRUE;
			}
			break;
			
		default: // > xp
			return TRUE;
		}
	}

	// everything else
	return FALSE;
}
*/
BOOL CToDoListDlg::PreTranslateMessage(MSG* pMsg)
{
	// only process accelerators if we are not disabled
	if (!IsWindowEnabled())
		return FALSE;

	switch (pMsg->message)
	{
	case WM_KEYDOWN:
		{
			switch (pMsg->wParam)
			{
			case VK_CONTROL:
				return FALSE;

			// don't handle return/cancel keys
			case VK_RETURN:
			case VK_CANCEL:
				return FALSE;

			// shortcut keys
			case 'o':
			case 'O':
				if (GetKeyState(VK_CONTROL) & 0x8000) // ctrl key down
				{
					if (GetKeyState(VK_SHIFT) & 0x8000) // shift key also down
						OnReload();
					else
						OnLoad();
					return TRUE;
				}
				break;

			case 's':
			case 'S':
				if (GetKeyState(VK_CONTROL) & 0x8000) // ctrl key down
				{
					OnSave();
					return TRUE;
				}
				break;

			case 'i':
			case 'I':
				if (GetKeyState(VK_CONTROL) & 0x8000) // ctrl key down
				{
					OnImportTasklist();
					return TRUE;
				}
				break;

			case 'n':
			case 'N':
				if (GetKeyState(VK_CONTROL) & 0x8000) // ctrl key down
				{
					if (GetKeyState(VK_SHIFT) & 0x8000) // and shift key down
					{
						OnNewsubtaskAttop();
						return TRUE;
					}
					else if (GetKeyState(VK_MENU) & 0x8000) // and alt key down
					{
						OnNewtaskAfterselectedtask();
						return TRUE;
					}
					else
					{
						OnNewtaskBeforeselectedtask();
						return TRUE;
					}
				}
				break;

			case 'm':
			case 'M':
				if (GetKeyState(VK_CONTROL) & 0x8000) // ctrl key down
				{
					OnSimplemode();
					return TRUE;
				}
				break;

			case 'p':
			case 'P':
				if (GetKeyState(VK_CONTROL) & 0x8000) // ctrl key down
				{
					OnPrint();
					return TRUE;
				}
				break;

			case VK_TAB:
				if (GetTDCCount())
				{
					if (GetKeyState(VK_CONTROL) & 0x8000) // ctrl key down
					{
						if (GetKeyState(VK_SHIFT) & 0x8000) // and shift key down
						{
							// previous tabctrl item
							int nPrev = GetSelToDoCtrl() - 1;

							if (nPrev < 0)
								nPrev = GetTDCCount() - 1;

							SelectToDoCtrl(nPrev);
							return TRUE;
						}
						else
						{
							// next tabctrl item
							int nNext = GetSelToDoCtrl() + 1;

							if (nNext >= GetTDCCount())
								nNext = 0;

							SelectToDoCtrl(nNext);
							return TRUE;
						}
					}
				}
				break;

			case 'C':
			case 'c':
				// tree must have the focus
				if (GetKeyState(VK_CONTROL) & 0x8000) // ctrl key down
				{
					if (GetToDoCtrl().TreeHasFocus())
					{
						GetToDoCtrl().CopySelectedItem();
						return TRUE;
					}
					else
						GetToDoCtrl().ClearCopiedItem();
				}
				break;

			case 'V':
			case 'v':
				// tree must have the focus
				if (GetToDoCtrl().TreeHasFocus() && GetKeyState(VK_CONTROL) & 0x8000) // ctrl key down
				{
					GetToDoCtrl().PasteOnSelectedItem();
					return TRUE;
				}
				break;

			}
		}
		break;

		case WM_SYSKEYDOWN: // usually <alt> + ...
		{
			switch (pMsg->wParam)
			{
			case VK_F4:
				if (GetKeyState(VK_MENU) & 0x8000) // alt key down
				{
					OnExit();
					return TRUE;
				}
				break;

			case 'c':
			case 'C':
				if (GetKeyState(VK_MENU) & 0x8000) // alt key down
				{
					OnCloseTasklist();
					return TRUE;
				}
				break;
			}
		}
		break;
	}

	if (m_tbHelper.PreTranslateMessage(pMsg))
		return TRUE;

	return FALSE;//CDialog::PreTranslateMessage(pMsg);
}

BOOL CToDoListDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// trayicon
	// we always create the trayicon (for simplicity) but we only
	// show it if required
	BOOL bUseSysTray = CPreferencesDlg().GetUseSysTray();

	m_ti.Create(WS_CHILD | (bUseSysTray ? WS_VISIBLE : 0), this, IDC_TRAYICON, IDR_MAINFRAME, "ToDoList � AbstractSpoon 2003");

	// toolbar
	CRect rToolbar;
	GetDlgItem(IDC_TB_FRAME)->GetWindowRect(rToolbar);
	ScreenToClient(rToolbar);

	VERIFY (m_toolbar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE)
			&& m_toolbar.LoadToolBar(IDR_TOOLBAR));

	m_toolbar.MoveWindow(rToolbar);

	// very important - turn OFF all the auto positioning and sizing
	// by default have no borders
	UINT nStyle = m_toolbar.GetBarStyle();
	nStyle &= ~(CCS_NORESIZE | CCS_NOPARENTALIGN | CBRS_BORDER_ANY);
	nStyle |= (CBRS_SIZE_FIXED | CBRS_TOOLTIPS | CBRS_FLYBY);
	m_toolbar.SetBarStyle(nStyle);

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// set up drop menus
	m_tbHelper.Initialize(&m_toolbar, this);
	m_tbHelper.EnableMultilineText();

	m_tbHelper.SetDropButton(ID_SORT, IDR_POPUPS, SORT, 0, 'S');
	m_tbHelper.SetDropButton(ID_NEWTASK, IDR_POPUPS, NEWTASK, ID_NEWTASK_BEFORESELECTEDTASK, 'N');
	m_tbHelper.SetDropButton(ID_EDITTASK, IDR_POPUPS, EDITTASK, ID_EDIT_TASKTEXT, 'E');
	m_tbHelper.SetDropButton(ID_FILE, IDR_POPUPS, FILEALL, ID_LOAD_NORMAL, 'F');
	m_tbHelper.SetDropButton(ID_DELETE, IDR_POPUPS, DELETETASK, ID_DELETETASK, 'D');
	m_tbHelper.SetDropButton(ID_TOOLS, IDR_POPUPS, TOOLS, ID_PREFERENCES, 'T');
	m_tbHelper.SetDropButton(ID_MOVETASK, IDR_POPUPS, MOVE, 0, 'M');

	// add a tooltip telling people how to keybrd navigate the tabctrl
	CToolTipCtrl* pTT = m_tabCtrl.GetToolTips();

	if (pTT)
		pTT->AddTool(&m_tabCtrl, "Use <Ctrl>+<Tab> to switch tasklists");

	// open cmdline tasklist
	if (!m_sCmdLineFilePath.IsEmpty() && ::GetFileAttributes(m_sCmdLineFilePath) != 0xffffffff)
		OpenTaskList(m_sCmdLineFilePath);

	m_sCmdLineFilePath.IsEmpty();

	LoadSettings();

	GetToDoCtrl().SetFocus();

	return FALSE;  // return TRUE  unless you set the focus to a control
}

void CToDoListDlg::OnDeleteTask() 
{
	if (GetToDoCtrl().GetSelectedItem())
		GetToDoCtrl().DeleteSelectedTask();
}

void CToDoListDlg::OnDeleteAllTasks() 
{
	if (GetToDoCtrl().DeleteAllTasks())
	{
		GetTDCItem().sFilePath.Empty(); // this will ensure that the user must explicitly overwrite the original file
		UpdateStatusbar();
	}
}

void CToDoListDlg::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);
	
	if (nType != SIZE_MINIMIZED)
		ResizeDlg(cx, cy, nType == SIZE_MAXIMIZED);

	m_stFilePath.EnableGripper(nType != SIZE_MAXIMIZED);
}

void CToDoListDlg::ResizeDlg(int cx, int cy, BOOL bMaximized)
{
	if (GetTDCCount() && GetToDoCtrl().GetSafeHwnd())
	{
		if (!cx && !cy)
		{
			CRect rClient;
			GetClientRect(rClient);

			cx = rClient.right;
			cy = rClient.bottom;
			bMaximized = IsZoomed();
		}

		// resize in one go
		CDeferWndMove dwm(5);
		CRect rTaskList(0, 0, cx, cy);

		// resize toolbar regardless
		CRect rToolbar = OffsetCtrl(AFX_IDW_TOOLBAR);
		rToolbar.right = cx;

		dwm.MoveWindow(&m_toolbar, rToolbar);

		if (!CPreferencesDlg().GetShowMenuBar()) // showing toolbar
			rTaskList.top = rToolbar.bottom;

		// resize and pos divider
		CRect rDivider(0, rTaskList.top, cx, rTaskList.top + 2);
		rTaskList.top = rDivider.bottom;

		dwm.MoveWindow(GetDlgItem(IDC_HORZDIVIDER), rDivider);

		// resize tabctrl
		CRect rTabs = OffsetCtrl(IDC_TABCONTROL); // not actually a move
		rTabs.right = cx + 1;
		rTabs.OffsetRect(0, rTaskList.top - rTabs.top);

		dwm.MoveWindow(&m_tabCtrl, rTabs);

		// hide and disable tabctrl if not needed
		BOOL bNeedTabCtrl = (GetTDCCount() > 1);

		m_tabCtrl.ShowWindow(bNeedTabCtrl ? SW_SHOW : SW_HIDE);
		m_tabCtrl.EnableWindow(bNeedTabCtrl);

		if (bNeedTabCtrl)
			rTaskList.top = rTabs.bottom + 1; // bottom of tab control

		// resize filepath static
		CRect rFilePath = OffsetCtrl(IDC_FILENAME);
		rFilePath.OffsetRect(0, cy - rFilePath.bottom);
		rFilePath.right = cx;

		dwm.MoveWindow(&m_stFilePath, rFilePath);

		// finally the active todoctrl
		rTaskList.bottom = rFilePath.top - 1;

		dwm.MoveWindow(&GetToDoCtrl(), rTaskList);
	}
}

CRect CToDoListDlg::OffsetCtrl(UINT uCtrlID, int cx, int cy)
{
	CWnd* pCtrl = GetDlgItem(uCtrlID);

	if (pCtrl)
	{
		CRect rChild;
		pCtrl->GetWindowRect(rChild);
		pCtrl->GetParent()->ScreenToClient(rChild);

		rChild.OffsetRect(cx, cy);
		pCtrl->MoveWindow(rChild);

		return rChild;
	}

	return CRect(0, 0, 0, 0);
}

void CToDoListDlg::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	CDialog::OnGetMinMaxInfo(lpMMI);

	int nMinWidth = 384;
	
	if (GetTDCCount()) // ie there is at least CToDoCtrl
	{
		CRect rClient, rWindow;

		GetClientRect(rClient);
		GetWindowRect(rWindow);

		nMinWidth = max(nMinWidth, GetToDoCtrl().GetMinWidth() + (rWindow.Width() - rClient.Width()));
	}

	lpMMI->ptMinTrackSize.x = nMinWidth; // so caption and toolbar is fully visible
	lpMMI->ptMinTrackSize.y = 420; // arbitrary
}

void CToDoListDlg::OnSave() 
{
	if (!SaveTaskList(GetSelToDoCtrl(), FALSE))
	{
		// check readonly status and notify user
		// TODO
	}
	else
	{
		UpdateCaption();
		UpdateTabItemText();
	}
}

BOOL CToDoListDlg::SaveTaskList(int nIndex, BOOL bForce)
{
	ASSERT (nIndex >= 0);
	ASSERT (nIndex < GetTDCCount());

	CAutoFlag af(m_bSaving, TRUE);

	TDCITEM& tdci = GetTDCItem(nIndex);
	CString sFilePath = tdci.sFilePath;

	if ((bForce && !sFilePath.IsEmpty()) || tdci.pTDC->IsModified())
	{
		if (sFilePath.IsEmpty())
		{
			CFileDialog dialog(FALSE, "xml", sFilePath, 0, "Task Lists (*.xml)|*.xml||", this);

			dialog.m_ofn.lpstrTitle = "Save Task List - ToDoList � AbstractSpoon";

			if (dialog.DoModal() != IDOK)
				return FALSE; // user elected not to proceed

			sFilePath = dialog.GetPathName();
		}

		CWaitCursor cursor;

		if (tdci.pTDC->Save(sFilePath))
		{
			tdci.bModified = FALSE;
			tdci.sFilePath = sFilePath;
			tdci.tLastMod = GetLastModified(sFilePath);

			m_mruList.Add(sFilePath);
			UpdateStatusbar();

			// export to html?
			if (CPreferencesDlg().GetAutoHtmlExport())
			{
				sFilePath.Replace(".xml", ".html");
				Export2Html(sFilePath, FALSE);
			}
		}
		else
			return FALSE;
	}

	return TRUE;
}

void CToDoListDlg::UpdateStatusbar()
{
	TDCITEM& tdci = GetTDCItem();

	if (!tdci.sFilePath.IsEmpty())
		m_sStatus.Format("%s (version %d)", tdci.sFilePath, tdci.pTDC->GetFileVersion());
	else
		m_sStatus.Empty();

	UpdateData(FALSE);
}

void CToDoListDlg::UpdateDefaultSortItem()
{
	TDCITEM& tdci = GetTDCItem();
	TDC_SORTBY nSortBy = tdci.pTDC->GetSortBy();

	if (nSortBy >= 0)
		m_tbHelper.SetDefaultMenuID(ID_SORT, GetSortID(nSortBy));
}

void CToDoListDlg::OnLoad() 
{
	CFileDialog dialog(TRUE, "xml", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "Task Lists (*.xml)|*.xml||", this);
	
	dialog.m_ofn.lpstrTitle = "Open Task List";

	if (dialog.DoModal() == IDOK)
	{
		if (!OpenTaskList(dialog.GetPathName()))
		{
			MessageBox("The selected file does not appear to be a valid task list.", ASCOPYRIGHT, MB_OK);
		}
	}
}

void CToDoListDlg::OnDestroy() 
{
	SaveSettings();

	// delete tasklists
	int nCtrl = GetTDCCount();

	while (nCtrl--)
		CloseToDoCtrl(nCtrl, TRUE);

	CDialog::OnDestroy();
}

void CToDoListDlg::SaveSettings()
{
	// pos
	WINDOWPLACEMENT wp;
	GetWindowPlacement(&wp);

	AfxGetApp()->WriteProfileInt("Pos", "TopLeft", MAKELPARAM(wp.rcNormalPosition.left, wp.rcNormalPosition.top));
	AfxGetApp()->WriteProfileInt("Pos", "BottomRight", MAKELPARAM(wp.rcNormalPosition.right, wp.rcNormalPosition.bottom));
	AfxGetApp()->WriteProfileInt("Pos", "Hidden", !m_bVisible);

	// last open files
	int nTDC = GetTDCCount();

	if (nTDC) // but don't overwrite files saved in OnQueryEndSession() or OnClose()
	{
		AfxGetApp()->WriteProfileInt("Settings", "NumLastFiles", nTDC);

		while (nTDC--)
		{
			CString sKey;
			sKey.Format("LastFile%d", nTDC);
			AfxGetApp()->WriteProfileString("Settings", sKey, GetTDCItem(nTDC).sFilePath);
		}
	}

	// settings
	AfxGetApp()->WriteProfileInt("Settings", "SimpleMode", m_bSimpleMode);

	m_mruList.WriteList();
}

void CToDoListDlg::LoadSettings()
{
	CPreferencesDlg pref;

	// MRU
	m_mruList.ReadList();

	// settings
	m_bSimpleMode = AfxGetApp()->GetProfileInt("Settings", "SimpleMode", m_bSimpleMode);

	// load last file only if an existing file is not loaded
	if (!GetTDCCount())
	{
		int nTDCCount = AfxGetApp()->GetProfileInt("Settings", "NumLastFiles", 0);

		for (int nTDC = 0; nTDC < nTDCCount; nTDC++)
		{
			CString sKey;
			sKey.Format("LastFile%d", nTDC);
			CString sLastFile = AfxGetApp()->GetProfileString("Settings", sKey);

			if (!sLastFile.IsEmpty())
				OpenTaskList(sLastFile);
		}

		// select the first one
		if (GetTDCCount())
			SelectToDoCtrl(0);
	}

	// open a 'dummy' todolist if none
	if (GetTDCCount() == 0)
		OnNew();

	// pos
	WINDOWPLACEMENT wp;
	GetWindowPlacement(&wp);
	
	DWORD dwTopLeft = (DWORD)AfxGetApp()->GetProfileInt("Pos", "TopLeft", -1);
	DWORD dwBottomRight = (DWORD)AfxGetApp()->GetProfileInt("Pos", "BottomRight", -1);

	if (m_bVisible == -1) // not yet set
	{
		m_bVisible = (!pref.GetUseSysTray() || pref.GetShowOnStartup() || 
					!AfxGetApp()->GetProfileInt("Pos", "Hidden", FALSE));
	}

	// get min size before we resize
	MINMAXINFO mmi;
	SendMessage(WM_GETMINMAXINFO, 0, (LPARAM)&mmi);

	if (dwTopLeft != -1 && dwBottomRight != -1)
	{
		CRect rect(LOWORD(dwTopLeft), HIWORD(dwTopLeft), LOWORD(dwBottomRight), HIWORD(dwBottomRight));

		rect.right = max(rect.right, rect.left + max(384, mmi.ptMinTrackSize.x));
		rect.bottom = max(rect.bottom, rect.top + mmi.ptMinTrackSize.y);
		
		// ensure this intersects with the desktop
		if (NULL != MonitorFromRect(rect, MONITOR_DEFAULTTONULL))
		{
			wp.rcNormalPosition = rect;
			SetWindowPlacement(&wp);
		}
	}
	else
	{
		CRect rect(0, 0, max(384, mmi.ptMinTrackSize.x), mmi.ptMinTrackSize.y);

		MoveWindow(rect);
		CenterWindow();
	}

	// preferences
	if (pref.GetAlwaysOnTop())
		SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);

	if (pref.GetShowMenuBar())
		ShowMenuBar(TRUE);
}

void CToDoListDlg::OnNew() 
{
	CToDoCtrl* pNew = NewToDoCtrl();

	if (pNew)
		AddToDoCtrl(pNew);

	UpdateCaption();
	UpdateStatusbar();
}

void CToDoListDlg::OnUpdateDeletetask(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetSelectedItem() != NULL);	
}

void CToDoListDlg::OnUpdateEdittask(CCmdUI* pCmdUI) 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	pCmdUI->Enable(tdc.GetSelectedItem() || tdc.CanPaste());	
}

void CToDoListDlg::OnUpdateEditTasktext(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetSelectedItem() != NULL);	
}

void CToDoListDlg::OnUpdateTaskcolor(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetSelectedItem() != NULL && !CPreferencesDlg().GetColorTextByPriority());	
}

void CToDoListDlg::OnUpdateTaskdone(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(GetToDoCtrl().IsSelectedTaskDone() ? 1 : 0);
	pCmdUI->Enable(GetToDoCtrl().GetSelectedItem() != NULL);	
}

void CToDoListDlg::OnUpdateDeletealltasks(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetCount() != 0);	
}

void CToDoListDlg::OnUpdateSave(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetTDCCount() && GetToDoCtrl().IsModified());	
}

void CToDoListDlg::OnUpdateNew(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(TRUE);	
}

BOOL CToDoListDlg::OnEraseBkgnd(CDC* pDC) 
{
	return CDialog::OnEraseBkgnd(pDC);
}

void CToDoListDlg::OnSortBy(UINT nCmdID)
{
	TDC_SORTBY nSortBy = GetSortBy(nCmdID);

	if (nSortBy != (TDC_SORTBY)-1)
	{
		m_tbHelper.SetDefaultMenuID(ID_SORT, nCmdID);

		GetToDoCtrl().Sort(nSortBy);
	}
}

void CToDoListDlg::OnUpdateSortBy(CCmdUI* pCmdUI)
{
	// we only need to handle this if the menubar is visible
	// because otherwise CToolbarHelper handles it
	if (!IsToolbarShowing())
	{
		TDC_SORTBY nSortBy = GetToDoCtrl().GetSortBy();
		UINT nCmdID = GetSortID(nSortBy);

		pCmdUI->SetCheck(nCmdID == pCmdUI->m_nID ? 1 : 0);
	}
}

TDC_SORTBY CToDoListDlg::GetSortBy(UINT nSortID)
{
	switch (nSortID)
	{
	case ID_SORT_BYNAME:
		return TDC_SORTBYNAME;

	case ID_SORT_BYID:
		return TDC_SORTBYID;

	case ID_SORT_BYPERSON:
		return TDC_SORTBYPERSON;

	case ID_SORT_BYPERCENT:
		return TDC_SORTBYPERCENT;

	case ID_SORT_BYCOLOR:
		return TDC_SORTBYCOLOR;

	case ID_SORT_BYTIMEEST:
		return TDC_SORTBYTIMEEST;

	case ID_SORT_BYSTARTDATE:
		return TDC_SORTBYSTART;

	case ID_SORT_BYDUEDATE:
		return TDC_SORTBYDUE;

	case ID_SORT_BYDONEDATE:
		return TDC_SORTBYDONE;

	case ID_SORT_BYPRIORITY:
		return TDC_SORTBYPRIORITY;
	}

	ASSERT (0);
	return (TDC_SORTBY)-1;
}

UINT CToDoListDlg::GetSortID(TDC_SORTBY nSortBy)
{
	switch (nSortBy)
	{
	case TDC_SORTBYNAME:
		return ID_SORT_BYNAME;

	case TDC_SORTBYID:
		return ID_SORT_BYID;

	case TDC_SORTBYPERSON:
		return ID_SORT_BYPERSON;

	case TDC_SORTBYPERCENT:
		return ID_SORT_BYPERCENT;

	case TDC_SORTBYCOLOR:
		return ID_SORT_BYCOLOR;

	case TDC_SORTBYTIMEEST:
		return ID_SORT_BYTIMEEST;

	case TDC_SORTBYSTART:
		return ID_SORT_BYSTARTDATE;

	case TDC_SORTBYDUE:
		return ID_SORT_BYDUEDATE;

	case TDC_SORTBYDONE:
		return ID_SORT_BYDONEDATE;

	case TDC_SORTBYPRIORITY:
		return ID_SORT_BYPRIORITY;
	}

	ASSERT (0);
	return 0;
}

void CToDoListDlg::OnNewtaskAttop() 
{
	VERIFY (NewTask("Task", TDC_INSERTATTOPOFSELTASKPARENT));
}

void CToDoListDlg::OnNewtaskAtbottom() 
{
	VERIFY (NewTask("Task", TDC_INSERTATBOTTOMOFSELTASKPARENT));
}

void CToDoListDlg::OnNewtaskAfterselectedtask() 
{
	VERIFY (NewTask("Task", TDC_INSERTAFTERSELTASK));
}

void CToDoListDlg::OnNewtaskBeforeselectedtask() 
{
	VERIFY (NewTask("Task", TDC_INSERTBEFORESELTASK));
}

void CToDoListDlg::OnNewsubtaskAtbottom() 
{
	VERIFY (NewTask("Task", TDC_INSERTATBOTTOMOFSELTASK));
}

void CToDoListDlg::OnNewsubtaskAttop() 
{
	VERIFY (NewTask("Task", TDC_INSERTATTOPOFSELTASK));
}

BOOL CToDoListDlg::NewTask(LPCTSTR szTitle, TDC_INSERTWHERE nInsertWhere)
{
	CToDoCtrl& tdc = GetToDoCtrl();

	if (!tdc.NewTask(szTitle, nInsertWhere))
		return FALSE;

	// else init attributes
	CAutoFlag af(m_bInNewTask, TRUE);
	CPreferencesDlg pref;

	CString sPerson = pref.GetDefaultPerson();
	int nPriority = pref.GetDefaultPriority();
	double dTimeEst = pref.GetDefaultTimeEst();
	COLORREF color = pref.GetDefaultColor();

	if (pref.GetUseParentPersonAttrib())
		tdc.GetSelectedTaskParentPerson(sPerson);

	if (pref.GetUseParentTimeEstAttrib())
		tdc.GetSelectedTaskParentEstimate(dTimeEst);

	if (pref.GetUseParentPriorityAttrib())
		tdc.GetSelectedTaskParentPriority(nPriority);

	if (pref.GetUseParentColorAttrib())
		tdc.GetSelectedTaskParentColor(color);

	tdc.SetSelectedTaskColor(color);
	tdc.SetSelectedTaskEstimate(dTimeEst);
	tdc.SetSelectedTaskPerson(sPerson);
	tdc.SetSelectedTaskPriority(nPriority);

	return TRUE;
}

void CToDoListDlg::OnUpdateSort(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetTDCCount() && GetToDoCtrl().GetCount() != 0);	
}

void CToDoListDlg::OnEditTaskcolor() 
{
	if (GetToDoCtrl().GetSelectedItem())
	{
		CColorDialog dialog;

		dialog.m_cc.Flags |= CC_FULLOPEN | CC_RGBINIT;
		dialog.m_cc.rgbResult = GetToDoCtrl().GetSelectedTaskColor();
		
		if (dialog.DoModal())
			GetToDoCtrl().SetSelectedTaskColor(dialog.GetColor());
	}
}

void CToDoListDlg::OnEditTaskdone() 
{
	GetToDoCtrl().SetSelectedTaskDone(!GetToDoCtrl().IsSelectedTaskDone());
}

void CToDoListDlg::OnEditTasktext() 
{
	GetToDoCtrl().EditSelectedTask();
}

void CToDoListDlg::OnTrayIconClick(NMHDR* pNMHDR, LRESULT* pResult)
{
	OnTrayiconShow();

	*pResult = 0;
}

LRESULT CToDoListDlg::OnToDoListShowWindow(WPARAM wp, LPARAM lp)
{
	OnTrayiconShow();
	return 0;
}

void CToDoListDlg::OnTrayIconDblClk(NMHDR* pNMHDR, LRESULT* pResult)
{
	OnTrayiconShow();

	*pResult = 0;
}

void CToDoListDlg::OnTrayiconCreatetask() 
{
	OnTrayiconShow();

	// create a task at the top of the tree
	GetToDoCtrl().NewTask("Task", TDC_INSERTATTOP);
}

void CToDoListDlg::OnTrayIconRClick(NMHDR* pNMHDR, LRESULT* pResult)
{
	SetForegroundWindow();

	// show context menu
	CMenu menu;

	if (menu.LoadMenu(IDR_POPUPS))
	{
		CMenu* pSubMenu = menu.GetSubMenu(TRAYICON);
		pSubMenu->SetDefaultItem(ID_TRAYICON_SHOW);

		NM_TRAYICON* pNMTI = (NM_TRAYICON*)pNMHDR;

		if (pSubMenu)
		{
			pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON, pNMTI->ptAction.x, pNMTI->ptAction.y, this);
			PostMessage(WM_NULL);
		}
	}
}

void CToDoListDlg::OnClose() 
{
	CPreferencesDlg pref;

	if (pref.GetUseSysTray())
	{
		if (pref.GetAutoSave())
		{
			// save all
			int nCtrl = GetTDCCount();

			while (nCtrl--)
			{
				if (!SaveTaskList(nCtrl, FALSE))
					return; // user cancelled
				else
					UpdateTabItemText(nCtrl);
			}

			UpdateCaption();
		}
		
		ShowWindow(SW_HIDE);
		m_bVisible = FALSE;
	}
	else // shutdown but user can cancel
		OnExit();
}

void CToDoListDlg::OnTrayiconClose() 
{
	OnExit();
}

LRESULT CToDoListDlg::OnToDoCtrlNotifySort(WPARAM wp, LPARAM lp)
{
	UpdateDefaultSortItem();

	return 0;
}

LRESULT CToDoListDlg::OnToDoCtrlNotifyMinWidthChange(WPARAM wp, LPARAM lp)
{
	CheckMinWidth();

	return 0;
}

LRESULT CToDoListDlg::OnToDoCtrlNotifyMod(WPARAM wp, LPARAM lp)
{
	TDCITEM& tdci = GetTDCItem();

	BOOL bWasMod = tdci.bModified;
	tdci.bModified = TRUE;

	// update the caption only if the control is not currently modified
	// or the project name changed
	if (!bWasMod || lp == TDCA_PROJNAME)
		UpdateCaption();

	// decide whether to resort or not
	if (!m_bInNewTask && lp != TDCA_PROJNAME && lp != TDCA_NONE && CPreferencesDlg().GetAutoReSort())
	{
		// we only sort if the thing that changed is the current sort key
		TDC_SORTBY nSortBy = tdci.pTDC->GetSortBy();

		switch (lp)
		{
		case TDCA_TASKNAME:
			if (TDC_SORTBYNAME != nSortBy)
				return 0;
			break;

		case TDCA_DONEDATE:
			// also check percent and priority
			if (TDC_SORTBYPERCENT != nSortBy && 
				TDC_SORTBYDONE != nSortBy &&
				TDC_SORTBYPRIORITY != nSortBy)
				return 0;
			break;

		case TDCA_DUEDATE:
			// also check priority
			if (TDC_SORTBYDUE != nSortBy &&	TDC_SORTBYPRIORITY != nSortBy)
				return 0;
			break;

		case TDCA_STARTDATE:
			if (TDC_SORTBYSTART != nSortBy)
				return 0;
			break;

		case TDCA_PRIORITY:
			if (TDC_SORTBYPRIORITY != nSortBy)
				return 0;
			break;

		case TDCA_COLOR:
			if (TDC_SORTBYCOLOR != nSortBy)
				return 0;
			break;

		case TDCA_PERSON:
			if (TDC_SORTBYPERSON != nSortBy)
				return 0;
			break;

		case TDCA_PERCENT:
			if (TDC_SORTBYPERCENT != nSortBy)
				return 0;
			break;

		case TDCA_TIMEEST:
			if (TDC_SORTBYTIMEEST != nSortBy)
				return 0;
			break;
		}

		GetToDoCtrl().Sort(nSortBy);
	}

	return 0L;
}

void CToDoListDlg::UpdateCaption()
{
	CString sProjectName = UpdateTabItemText();

	CString sCaption;
	sCaption.Format("%s - %s 2004", UpdateTabItemText(), ASCOPYRIGHT);
	SetWindowText(sCaption);
}

CString CToDoListDlg::UpdateTabItemText(int nIndex)
{
	if (nIndex < 0)
	{
		nIndex = GetSelToDoCtrl();

		if (nIndex < 0)
			return "";
	}

	TDCITEM& tdci = GetTDCItem(nIndex);

	CString sProjectName = tdci.pTDC->GetProjectName();
	CString sFilePath = tdci.sFilePath;

	if (sProjectName.IsEmpty())
	{
		if (!sFilePath.IsEmpty())
		{
			char szFilename[_MAX_FNAME], szExt[_MAX_EXT];
			_splitpath(sFilePath, NULL, NULL, szFilename, szExt);

			sProjectName.Format("%s%s", szFilename, szExt);
		}
		else
			sProjectName = "(untitled)";
	}

	if (tdci.pTDC->IsModified())
		sProjectName += "*";

	TCITEM tci;
	tci.mask = TCIF_TEXT;
	tci.pszText = (LPTSTR)(LPCTSTR)sProjectName;

	m_tabCtrl.SetItem(nIndex, &tci);

	return sProjectName;
}

void CToDoListDlg::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos) 
{
	CDialog::OnWindowPosChanging(lpwndpos);
	
	if (!m_bVisible && (lpwndpos->flags & SWP_SHOWWINDOW))
		lpwndpos->flags &= ~SWP_SHOWWINDOW;
}

void CToDoListDlg::OnUpdateNewsubtaskAtBottom(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetSelectedItem() && GetToDoCtrl().ItemHasChildren(GetToDoCtrl().GetSelectedItem()));
}

BOOL CToDoListDlg::Export2Html(LPCTSTR szFilePath, BOOL bPreview) 
{
	CPreferencesDlg pref;
	CString sOutput;
	TDC_FILTER nFilter = pref.GetExportVisibleOnly() ? TDCF_VISIBLE : TDCF_ALL;

	GetToDoCtrl().Export2Html(sOutput, TRUE, pref.GetHtmlFont(), nFilter);
	
	if (!sOutput.IsEmpty())
	{
		CStdioFile file;
		
		if (file.Open(szFilePath, CFile::shareExclusive | CFile::modeWrite | CFile::modeCreate | CFile::typeText))
		{
			// add header
			sOutput = "<html>\n<head></head>\n<body>\n" + sOutput;
			
			// and footer
			sOutput += "</body>\n</html>\n";
			
			// save to file 
			file.WriteString(sOutput);
			file.Close();
			
			// and preview
			if (bPreview)
				ShellExecute(*this, NULL, szFilePath, NULL, NULL, SW_SHOWNORMAL);

			return TRUE;
		}
	}

	return FALSE;
}

BOOL CToDoListDlg::Export2Text(LPCTSTR szFilePath, BOOL bPreview) 
{
	CPreferencesDlg pref;
	CString sOutput;
	TDC_FILTER nFilter = pref.GetExportVisibleOnly() ? TDCF_VISIBLE : TDCF_ALL;

	GetToDoCtrl().Export2Text(sOutput, TRUE, pref.GetTextIndent(), nFilter);

	if (!sOutput.IsEmpty())
	{
		CStdioFile file;
		
		if (file.Open(szFilePath, CFile::shareExclusive | CFile::modeWrite | CFile::modeCreate | CFile::typeText))
		{
			// save to file 
			file.WriteString(sOutput);
			file.Close();
			
			// and preview
			if (bPreview)
				ShellExecute(*this, NULL, szFilePath, NULL, NULL, SW_SHOWNORMAL);

			return TRUE;
		}
	}

	return FALSE;
}

void CToDoListDlg::OnSaveas() 
{
	DoSaveAs(SAVEASXML);
}

BOOL CToDoListDlg::DoSaveAs(int nType)
{
	// remove extension from filename and get the dialog to add it back in
	CString sFilePath = GetTDCItem().sFilePath;
	char szDrive[_MAX_DRIVE], szPath[MAX_PATH], szFName[_MAX_FNAME];

	_splitpath(sFilePath, szDrive, szPath, szFName, NULL);
	_makepath(sFilePath.GetBuffer(MAX_PATH + 1), szDrive, szPath, szFName, NULL);
	sFilePath.ReleaseBuffer();

	CFileDialog dialog(FALSE, NULL, sFilePath, 0, NULL, this);

	dialog.m_ofn.lpstrTitle = "Save Task List As";

	CString sFilter;
	
	switch (nType)
	{
	case SAVEASXML:
		dialog.m_ofn.lpstrDefExt = "xml";
		sFilter = SAVEASXMLFILTER;
		break;
		
	case SAVEASHTM:
		dialog.m_ofn.lpstrDefExt = "html";
		sFilter = SAVEASHTMFILTER;
		break;
		
	case SAVEASTXT:
		dialog.m_ofn.lpstrDefExt = "txt";
		sFilter = SAVEASTXTFILTER;
		break;

	default:
		return FALSE;
	}

	// convert '|' in filters to '\0' like MFC does
	LPTSTR pch = sFilter.GetBuffer(0); // modify the buffer in place

	while ((pch = _tcschr(pch, '|')) != NULL)
		*pch++ = '\0';

	dialog.m_ofn.lpstrFilter = sFilter;

	// display the dialog
	int nRes = dialog.DoModal();

	// release filter buffer
	sFilter.ReleaseBuffer();
	
	if (nRes == IDOK)
	{
		switch (nType)
		{
		case SAVEASXML:
			GetTDCItem().sFilePath = dialog.GetPathName();
			SaveTaskList(GetSelToDoCtrl(), TRUE);
			break;
			
		case SAVEASHTM:
			Export2Html(dialog.GetPathName(), CPreferencesDlg().GetPreviewSaveAs());
			break;
			
		case SAVEASTXT:
			Export2Text(dialog.GetPathName(), CPreferencesDlg().GetPreviewSaveAs());
			break;
		}
	

		return TRUE;
	}
	
	return FALSE;
}

void CToDoListDlg::OnUpdateSaveas(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetCount());
}

void CToDoListDlg::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	if (pWnd == &tdc)
	{
		HTREEITEM hti = tdc.GetSelectedItem();

		if (hti || tdc.CanPaste())
		{
			CMenu menu;

			if (menu.LoadMenu(IDR_POPUPS))
			{
				CMenu* pPopup = menu.GetSubMenu(TASKCONTEXT);

				if (pPopup)
				{
					CToolbarHelper::PrepareMenuItems(pPopup, this);

					pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON, point.x, point.y, this);
				}
			}
		}
	}
}

UINT CToDoListDlg::OnGetDlgCode() 
{
	return (CDialog::OnGetDlgCode());
}

void CToDoListDlg::OnTrayiconShow() 
{
	m_bVisible = TRUE;
	ShowWindow(IsIconic() ? SW_RESTORE : SW_SHOW);
	SetForegroundWindow();
}

BOOL CToDoListDlg::OnQueryEndSession() 
{
	if (!CDialog::OnQueryEndSession())
		return FALSE;
	
	SaveSettings();

	int nCtrl = GetTDCCount();

	while (nCtrl--)
		CloseToDoCtrl(nCtrl, TRUE);

	DestroyWindow(); // because otherwise we would get left in an undefined state

	return TRUE;
}

void CToDoListDlg::OnUpdateRecentFileMenu(CCmdUI* pCmdUI) 
{
	m_mruList.UpdateMenu(pCmdUI);	
}

BOOL CToDoListDlg::OnOpenRecentFile(UINT nID)
{
	ASSERT(nID >= ID_FILE_MRU_FILE1);
	ASSERT(nID < ID_FILE_MRU_FILE1 + (UINT)m_mruList.GetSize());

	int nIndex = nID - ID_FILE_MRU_FILE1;
	CString sPathName = m_mruList[nIndex];

	if (!OpenTaskList(sPathName))
	{
		MessageBox("The selected task list could not be opened.\n\nPlease check that it has not been moved or deleted.", ASCOPYRIGHT, MB_OK);
		m_mruList.Remove(nIndex);
	}

	return TRUE;
}

int CToDoListDlg::OpenTaskList(LPCTSTR szFilePath, BOOL bCheckExisting)
{
	// see if the tasklist is already open
	if (bCheckExisting && SelectToDoCtrl(szFilePath))
		return TRUE;

	// init archive params?
	CPreferencesDlg pref;

	CString sArchivePath;
	TDC_ARCHIVE nRemove = TDC_REMOVENONE;

	if (pref.GetAutoArchive())
	{
		if (pref.GetRemoveArchivedTasks())
		{
			if (pref.GetRemoveOnlyOnAbsoluteCompletion())
				nRemove = TDC_REMOVEIFSIBLINGSANDSUBTASKSCOMPLETE;
			else
				nRemove = TDC_REMOVEALL;
		}

		sArchivePath = GetArchivePath(szFilePath);
	}

	CToDoCtrl* pCtrl = NewToDoCtrl();

	if (pCtrl->Load(szFilePath, sArchivePath, nRemove))
	{
		AddToDoCtrl(pCtrl, szFilePath);

		m_mruList.Add(szFilePath);

		UpdateCaption();
		UpdateStatusbar();
		UpdateDefaultSortItem();

		// notify user of due tasks if req
		if (pref.GetNotifyDue())
		{
			CString sDueTasks;

			GetToDoCtrl().Export2Text(sDueTasks, FALSE, 2, TDCF_DUE);
			sDueTasks.TrimRight();

			if (!sDueTasks.IsEmpty())
			{
				CString sMessage;
				sMessage.Format("The following tasks are due today:\n\n%s", sDueTasks);

				MessageBox(sMessage, ASCOPYRIGHT);
			}
		}

		// notify user if readonly
		if (pref.GetNotifyReadOnly() && (GetFileAttributes(szFilePath) & FILE_ATTRIBUTE_READONLY))
		{
			CString sMessage;
			sMessage.Format("The file '%s' is currently readonly, \nwhich means that any changes you make will not be saved.", szFilePath);

			MessageBox(sMessage, ASCOPYRIGHT);
		}

		return TRUE;
	}
	else if (GetTDCCount() >= 1) // only delete if there's another ctrl existing
	{
		pCtrl->DestroyWindow();
		delete pCtrl;
	}
	else // re-add
	{
		AddToDoCtrl(pCtrl);
	}

	return FALSE;
}

CString CToDoListDlg::GetArchivePath(LPCTSTR szFilePath)
{
	CString sArchivePath, sFilePath(szFilePath);
	sFilePath.MakeLower();
	
	if (!sFilePath.IsEmpty() && sFilePath.Find(".done.") == -1) // don't archive archives!
	{
		char szDrive[_MAX_DRIVE], szPath[MAX_PATH], szFName[_MAX_FNAME];
		_splitpath(szFilePath, szDrive, szPath, szFName, NULL);
		
		sArchivePath.Format("%s%s%s.done.xml", szDrive, szPath, szFName);
	}

	return sArchivePath;
}

void CToDoListDlg::OnAbout() 
{
	CAboutDlg dialog(IDR_MAINFRAME, 
					"ToDoList 3.1.4", 
					"A simple yet effective way to keep track of your current programming tasks\n(Freeware)",
					"AbstractSpoon Software � 2003/2004\n(search for 'AbstractSpoon' on Google)");
	
	dialog.DoModal();
}

void CToDoListDlg::OnPreferences() 
{
	CPreferencesDlg dialog;

	if (dialog.DoModal() == IDOK)
	{
		ShowMenuBar(dialog.GetShowMenuBar()); // first

		// active tasklist prefs
		UpdateToDoCtrlPreferences(&dialog);

		// topmost
		SetWindowPos(dialog.GetAlwaysOnTop() ? &wndTopMost : &wndNoTopMost,
					0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);

		// tray icon
		m_ti.ShowTrayIcon(dialog.GetUseSysTray());
	}
}

void CToDoListDlg::CheckMinWidth()
{
	if (GetTDCCount())
	{
		CRect rTDC;
		GetToDoCtrl().GetClientRect(rTDC);
		int nMinWidth = GetToDoCtrl().GetMinWidth();
		
		if (rTDC.Width() < nMinWidth)
		{
			CRect rWindow;
			GetWindowRect(rWindow);
			
			SetWindowPos(NULL, 0, 0, rWindow.Width() - 1, rWindow.Height(), SWP_NOZORDER | SWP_NOMOVE);
		}
	}
}

void CToDoListDlg::ShowMenuBar(BOOL bShow)
{
	// don't change if no change
	BOOL bToolbarShowing = IsToolbarShowing();

	if ((bShow && !bToolbarShowing) || (!bShow && bToolbarShowing))
		return;

	if (bShow) // showing menubar
	{
		CMenu menu;

		if (!menu.LoadMenu(IDR_MAINFRAME))
			return;

		if (!SetMenu(&menu))
			return;

		DrawMenuBar();
		menu.Detach();

		// hide toolbar
		m_toolbar.ShowWindow(SW_HIDE);
		m_toolbar.EnableWindow(FALSE);
	}
	else // showing toolbar
	{
		// destroy existing menu
		CMenu* pMenu = GetMenu();

		if (pMenu)
			pMenu->DestroyMenu();

		// and hide
		SetMenu(NULL);

		// show toolbar
		m_toolbar.ShowWindow(SW_SHOW);
		m_toolbar.EnableWindow(TRUE);
	}

	// resize active todoctrl
	ResizeDlg();
}

BOOL CToDoListDlg::OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct) 
{
	switch (pCopyDataStruct->dwData)
	{
	case OPENTASKLIST:
		{
			LPCTSTR szFilePath = (LPCTSTR)pCopyDataStruct->lpData;
			OpenTaskList(szFilePath);
		}
		break;
	}
	
	return CDialog::OnCopyData(pWnd, pCopyDataStruct);
}

void CToDoListDlg::OnEditCopy() 
{
	GetToDoCtrl().CopySelectedItem();
}

void CToDoListDlg::OnEditPaste() 
{
	GetToDoCtrl().PasteOnSelectedItem();
}

void CToDoListDlg::OnEditCopyastext() 
{
	GetToDoCtrl().CopySelectedItemToClipboardAsText(CPreferencesDlg().GetTextIndent());
}

void CToDoListDlg::OnEditCopyashtml() 
{
	GetToDoCtrl().CopySelectedItemToClipboardAsHtml(CPreferencesDlg().GetHtmlFont());
}

void CToDoListDlg::OnUpdateEditPaste(CCmdUI* pCmdUI) 
{
	// modify the text appropriately if the tasklist is empty
	if (NULL == GetToDoCtrl().GetSelectedItem())
		pCmdUI->SetText("Paste as a Top-level Task\tCtrl+V");

	pCmdUI->Enable(GetToDoCtrl().CanPaste());	
}

void CToDoListDlg::OnUpdateEditCopy(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(NULL != GetToDoCtrl().GetSelectedItem());
}

void CToDoListDlg::OnUpdateNewtaskAttop(CCmdUI* pCmdUI) 
{
	if (NULL == GetToDoCtrl().GetSelectedItem())
		pCmdUI->SetText("New Task at &Top\tCtrl+N");
}

void CToDoListDlg::OnUpdateNewtaskAtbottom(CCmdUI* pCmdUI) 
{
	if (NULL == GetToDoCtrl().GetSelectedItem())
		pCmdUI->SetText("New Task at &Bottom");
}

void CToDoListDlg::OnUpdateNewtaskAfterselectedtask(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(NULL != GetToDoCtrl().GetSelectedItem());
}

void CToDoListDlg::OnUpdateNewtaskBeforeselectedtask(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(NULL != GetToDoCtrl().GetSelectedItem());
}

void CToDoListDlg::OnUpdateNewsubtaskAttop(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(NULL != GetToDoCtrl().GetSelectedItem());
}

void CToDoListDlg::OnSimplemode() 
{
	m_bSimpleMode = !m_bSimpleMode;

	GetToDoCtrl().SetStyle(TDCS_SIMPLEMODE, m_bSimpleMode);	
}

void CToDoListDlg::OnUpdateSimplemode(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bSimpleMode ? 1 : 0);
}

void CToDoListDlg::OnReload() 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	if (tdc.IsModified())
	{ 
		if (IDNO == MessageBox("If you reload the tasklist you will lose your current \nchanges.\n\nAre you sure you want to continue?",
								ASCOPYRIGHT, MB_YESNO | MB_DEFBUTTON2))
			return;
	}

	// cache 
	int nPrev = GetSelToDoCtrl();

	// stop the existing file getting saved
	tdc.SetModified(FALSE);

	// try reopening first
	if (OpenTaskList(GetTDCItem(nPrev).sFilePath, FALSE))
	{
		// if that succeeds then close the previous version
		CloseToDoCtrl(nPrev, FALSE);
	}
}

void CToDoListDlg::OnUpdateReload(CCmdUI* pCmdUI) 
{
	TDCITEM& tdci = GetTDCItem();

	pCmdUI->Enable(tdci.bModified || !tdci.sFilePath.IsEmpty());
}

void CToDoListDlg::OnUpdateDelete(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetSelectedItem() || GetToDoCtrl().GetCount());
}

void CToDoListDlg::OnArchiveCompletedtasks() 
{
	CPreferencesDlg pref;
	TDC_ARCHIVE nRemove = TDC_REMOVENONE;

	if (pref.GetRemoveArchivedTasks())
	{
		if (pref.GetRemoveOnlyOnAbsoluteCompletion())
			nRemove = TDC_REMOVEIFSIBLINGSANDSUBTASKSCOMPLETE;
		else
			nRemove = TDC_REMOVEALL;
	}

	if (GetToDoCtrl().ArchiveDoneTasks(GetArchivePath(GetTDCItem().sFilePath), nRemove) > 0)
	{
		UpdateCaption();
	}
}

void CToDoListDlg::OnUpdateArchiveCompletedtasks(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!GetArchivePath(GetTDCItem().sFilePath).IsEmpty());
}

void CToDoListDlg::OnExportTohtml() 
{
	DoSaveAs(SAVEASHTM);
}

void CToDoListDlg::OnUpdateExportTohtml(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetCount());
}

void CToDoListDlg::OnExportToplaintext() 
{
	DoSaveAs(SAVEASTXT);
}

void CToDoListDlg::OnUpdateExportToplaintext(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetCount());
}

void CToDoListDlg::OnPrint() 
{
	// export to html and then print in IE
	char szTempFile[MAX_PATH], szTempPath[MAX_PATH];

	if (!::GetTempPath(MAX_PATH, szTempPath))
		return;

	// always use the same file
	_makepath(szTempFile, NULL, szTempPath, "ToDoList.print", "html");

	if (!Export2Html(szTempFile, FALSE))
		return;

	// print from browser
	ShellExecute(*this, "print", szTempFile, NULL, NULL, SW_HIDE);
}

void CToDoListDlg::OnUpdatePrint(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetCount());
}

void CToDoListDlg::OnMovetaskdown() 
{
	m_tbHelper.SetDefaultMenuID(ID_MOVETASK, ID_MOVETASKDOWN);

	GetToDoCtrl().MoveSelectedTaskDown();	
}

void CToDoListDlg::OnUpdateMovetaskdown(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanMoveSelectedTaskDown());	
}

void CToDoListDlg::OnMovetaskup() 
{
	m_tbHelper.SetDefaultMenuID(ID_MOVETASK, ID_MOVETASKUP);

	GetToDoCtrl().MoveSelectedTaskUp();	
}

void CToDoListDlg::OnUpdateMovetaskup(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanMoveSelectedTaskUp());	
}

void CToDoListDlg::OnMovetaskright() 
{
	m_tbHelper.SetDefaultMenuID(ID_MOVETASK, ID_MOVETASKRIGHT);

	GetToDoCtrl().MoveSelectedTaskRight();	
}

void CToDoListDlg::OnUpdateMovetaskright(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanMoveSelectedTaskRight());	
}

void CToDoListDlg::OnMovetaskleft() 
{
	m_tbHelper.SetDefaultMenuID(ID_MOVETASK, ID_MOVETASKLEFT);

	GetToDoCtrl().MoveSelectedTaskLeft();	
}

void CToDoListDlg::OnUpdateMovetaskleft(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().CanMoveSelectedTaskLeft());	
}

CToDoCtrl& CToDoListDlg::GetToDoCtrl()
{
	return GetToDoCtrl(GetSelToDoCtrl());
}

CToDoCtrl& CToDoListDlg::GetToDoCtrl(int nIndex)
{
	ASSERT (nIndex >= 0);
	ASSERT (nIndex < GetTDCCount());

	return *(m_aToDoCtrls[nIndex].pTDC);
}

CToDoListDlg::TDCITEM& CToDoListDlg::GetTDCItem()
{
	return GetTDCItem(GetSelToDoCtrl());
}

CToDoListDlg::TDCITEM& CToDoListDlg::GetTDCItem(int nIndex)
{
	ASSERT (nIndex >= 0);
	ASSERT (nIndex < GetTDCCount());

	return m_aToDoCtrls[nIndex];
}

CToDoCtrl* CToDoListDlg::NewToDoCtrl()
{
	// if the active tasklist is untitled and unmodified then reuse it
	CToDoCtrl* pCtrl = NULL;
	BOOL bReuse = FALSE;
	
	if (GetTDCCount())
	{
		TDCITEM& tdci = GetTDCItem();

		if (tdci.sFilePath.IsEmpty() && !tdci.bModified)
		{
			pCtrl = tdci.pTDC;

			m_aToDoCtrls.RemoveAt(GetSelToDoCtrl());
			m_tabCtrl.DeleteItem(GetSelToDoCtrl());

			return pCtrl;
		}
	}

	// else
	pCtrl = new CToDoCtrl;

	if (pCtrl && CreateToDoCtrl(pCtrl))
	{
#ifdef _DEBUG
//		pCtrl->SetTreeFont("lucida console", 8);
#endif
		return pCtrl;
	}

	// else
	delete pCtrl;
	return NULL;
}

BOOL CToDoListDlg::CreateToDoCtrl(CToDoCtrl* pCtrl)
{
	CRect rToDo;
	GetDlgItem(IDC_TODOFRAME)->GetWindowRect(rToDo);
	ScreenToClient(rToDo);
	
	if (pCtrl->Create(rToDo, this, IDC_TODOLIST, FALSE))
	{
		if (m_ilToDo.GetSafeHandle() || m_ilToDo.Create(IDB_TODO, 16, 1, 0))
			pCtrl->SetImageList(&m_ilToDo, TVSIL_NORMAL);

		return TRUE;
	}

	return FALSE;
}

int CToDoListDlg::AddToDoCtrl(CToDoCtrl* pCtrl, LPCTSTR szFilePath)
{
	int nSel = m_aToDoCtrls.Add(TDCITEM(pCtrl, szFilePath));

	m_tabCtrl.InsertItem(nSel, "");
	SelectToDoCtrl(nSel);

	// make sure size is right
	ResizeDlg();

	return nSel;
}

void CToDoListDlg::OnSelchangeTabcontrol(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// show the incoming selection
	int nCurSel = GetSelToDoCtrl();

	if (nCurSel != -1)
	{
		UpdateToDoCtrlPreferences();
		UpdateDefaultSortItem();

		TDCITEM& tdci = GetTDCItem(nCurSel);
		tdci.pTDC->SetFocus();
		tdci.pTDC->ShowWindow(SW_SHOW);
	
		// make sure size is right
		ResizeDlg();

		// update status bar
		UpdateStatusbar();
		UpdateCaption();
	}
	
	// hide the outgoing selection
	if (m_nLastSelItem != -1)
	{
		GetToDoCtrl(m_nLastSelItem).ShowWindow(SW_HIDE);
		m_nLastSelItem = -1; // reset
	}

	*pResult = 0;
}

void CToDoListDlg::OnSelchangingTabcontrol(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// cache the outgoing selection
	m_nLastSelItem = GetSelToDoCtrl();

	*pResult = 0;
}

BOOL CToDoListDlg::CloseToDoCtrl(int nIndex, BOOL bClosing)
{
	ASSERT (nIndex >= 0);
	ASSERT (nIndex < GetTDCCount());

	CToDoCtrl* pCtrl = &GetToDoCtrl(nIndex);
	int nSel = GetSelToDoCtrl(); // cache this

	// save changes
	if (pCtrl->IsModified())
	{
		TDCITEM tdci = GetTDCItem(nIndex);

		if (tdci.sFilePath.IsEmpty() || CPreferencesDlg().GetConfirmSaveOnExit())
		{
			CString sMessage("Would you like to save your changes before closing?");

			if (!pCtrl->GetProjectName().IsEmpty())
				sMessage.Format("Would you like to save the changes to '%s' \nbefore closing?", pCtrl->GetProjectName());
			
			else if (!tdci.sFilePath.IsEmpty())
				sMessage.Format("Would you like to save the changes to\n'%s'\nbefore closing?", tdci.sFilePath);

			// don't allow user to cancel if closing down
			int nRet = MessageBox(sMessage, ASCOPYRIGHT, bClosing ? MB_YESNO : MB_YESNOCANCEL);
			
			if (nRet == IDYES)
				SaveTaskList(nIndex, FALSE);
			
			else if (!bClosing && nRet == IDCANCEL)
				return FALSE;
		}
		else
			SaveTaskList(nIndex, FALSE); 
	}
	
	m_aToDoCtrls.RemoveAt(nIndex);
	m_tabCtrl.DeleteItem(nIndex);

	pCtrl->DestroyWindow();
	delete pCtrl;

	// make sure we reset the selection to a valid index
	if (nIndex == nSel && GetTDCCount())
	{
		// try leaving the selection as-is
		if (nSel >= GetTDCCount())
			nSel--; // try the preceding item

		SelectToDoCtrl(nSel);
	}

	if (!bClosing)
		ResizeDlg();

	return TRUE;
}

void CToDoListDlg::OnCloseTasklist() 
{
	// if there is only one list and its not been modified or saved
	// hten leave as is
	if (GetTDCCount() == 1)
	{
		TDCITEM& tdci = GetTDCItem();

		if (!tdci.bModified && tdci.sFilePath.IsEmpty())
			return;
	}

	// close
	CloseToDoCtrl(GetSelToDoCtrl(), FALSE);
	
	// if empty then create a new dummy item		
	if (!GetTDCCount())
		OnNew();
	else
		ResizeDlg();

}

BOOL CToDoListDlg::SelectToDoCtrl(LPCTSTR szFilePath)
{
	int nCtrl = GetTDCCount();

	while (nCtrl--)
	{
		if (GetTDCItem(nCtrl).sFilePath.CompareNoCase(szFilePath) == 0)
		{
			SelectToDoCtrl(nCtrl);
			return TRUE;
		}
	}

	return FALSE;
}

void CToDoListDlg::SelectToDoCtrl(int nIndex)
{
	ASSERT (nIndex >= 0);
	ASSERT (nIndex < GetTDCCount());

	int nCurSel = GetSelToDoCtrl();

	m_tabCtrl.SetCurSel(nIndex); // this changes the selected CToDoCtrl

	// make sure size is right
	ResizeDlg();

	// show the chosen item
	UpdateToDoCtrlPreferences();
	UpdateDefaultSortItem();

	GetToDoCtrl().SetFocus();
	GetToDoCtrl().ShowWindow(SW_SHOW);

	// before hiding the previous selection
	if (nCurSel != -1 && nCurSel != nIndex)
		GetToDoCtrl(nCurSel).ShowWindow(SW_HIDE);

	UpdateCaption();
	UpdateStatusbar();
}

void CToDoListDlg::UpdateToDoCtrlPreferences(CPreferencesDlg* pPref)
{
	CToDoCtrl& tdc = GetToDoCtrl();
	CPreferencesDlg pref;

	if (!pPref)
		pPref = &pref;
	
	tdc.SetStyle(TDCS_COLORTEXTBYPRIORITY, pPref->GetColorTextByPriority());
	tdc.SetStyle(TDCS_SHOWINFOTIPS, pPref->GetShowInfoTips());
	tdc.SetStyle(TDCS_SHOWCOMMENTSINLIST, pPref->GetShowComments());
	tdc.SetStyle(TDCS_COLORPRIORITY, pPref->GetColorPriority());
	tdc.SetStyle(TDCS_GRAYOUTSUBCOMPLETEDTASKS, pPref->GetGrayoutSubCompleted());
	tdc.SetStyle(TDCS_HIDEPERCENTSUBCOMPLETEDTASKS, pPref->GetHidePercentSubCompleted());
	tdc.SetStyle(TDCS_CONFIRMDELETE, pPref->GetConfirmDelete());
	tdc.SetStyle(TDCS_AVERAGEPERCENTSUBCOMPLETION, pPref->GetAveragePercentSubCompletion());
	tdc.SetStyle(TDCS_INCLUDEDONEINAVERAGECALC, pPref->GetIncludeDoneInAverageCalc());
	tdc.SetStyle(TDCS_FIXEDCOMMENTHEIGHT, !pPref->GetVaryCommentsHeight());
	tdc.SetStyle(TDCS_SHOWBUTTONSINTREE, pPref->GetShowButtonsInTree());
	tdc.SetStyle(TDCS_USEEARLIESTDUEDATE, pPref->GetUseEarliestDueDate());
	tdc.SetStyle(TDCS_USEPERCENTDONEINTIMEEST, pPref->GetUsePercentDoneInTimeEst());
	tdc.SetStyle(TDCS_SHOWCTRLSASCOLUMNS, pPref->GetShowCtrlsAsColumns());
	tdc.SetStyle(TDCS_SHOWCOMMENTSALWAYS, pPref->GetShowCommentsAlways());

	tdc.ShowColumn(TDCC_POSITION, pPref->GetShowColumn(PTPC_POSITION));
	tdc.ShowColumn(TDCC_ID, pPref->GetShowColumn(PTPC_ID));
	tdc.ShowColumn(TDCC_PERCENT, pPref->GetShowColumn(PTPC_PERCENT));
	tdc.ShowColumn(TDCC_PRIORITY, pPref->GetShowColumn(PTPC_PRIORITY));
	tdc.ShowColumn(TDCC_TIMEEST, pPref->GetShowColumn(PTPC_TIMEEST));
	tdc.ShowColumn(TDCC_STARTDATE, pPref->GetShowColumn(PTPC_STARTDATE));
	tdc.ShowColumn(TDCC_DUEDATE, pPref->GetShowColumn(PTPC_DUEDATE));
	tdc.ShowColumn(TDCC_DONEDATE, pPref->GetShowColumn(PTPC_DONEDATE));
	tdc.ShowColumn(TDCC_PERSON, pPref->GetShowColumn(PTPC_PERSON));
	tdc.ShowColumn(TDCC_FILEREF, pPref->GetShowColumn(PTPC_FILEREF));

	CheckMinWidth();

	CString sTreeFont;
	int nFontSize;

	if (pref.GetTreeFont(sTreeFont, nFontSize))
		tdc.SetTreeFont(sTreeFont, nFontSize);
	else
		tdc.SetTreeFont(NULL);
	
	CDWordArray aColors;
	pPref->GetPriorityColors(aColors);
	tdc.SetPriorityColors(aColors);

	tdc.SetStyle(TDCS_SIMPLEMODE, m_bSimpleMode);

	// finally set or terminate the various status check timers
	SetTimer(TIMER_CHECKREADONLY, pref.GetPromptReloadOnWritable(), 1000);
	SetTimer(TIMER_CHECKTIMESTAMP, pref.GetPromptReloadOnTimestamp(), 10000);
}

void CToDoListDlg::SetTimer(UINT nTimerID, BOOL bOn, UINT nPeriod)
{
	if (bOn)
	{
		UINT nID = CDialog::SetTimer(nTimerID, nPeriod, NULL);
		ASSERT (nID);
	}
	else
		KillTimer(nTimerID);
}

void CToDoListDlg::OnSaveall() 
{
	int nCtrl = GetTDCCount();

	while (nCtrl--)
	{
		if (!SaveTaskList(nCtrl, FALSE))
			break; // user cancelled
		else
			UpdateTabItemText(nCtrl);
	}
}

void CToDoListDlg::OnUpdateSaveall(CCmdUI* pCmdUI) 
{
	int nCtrl = GetTDCCount();

	while (nCtrl--)
	{
		if (GetTDCItem(nCtrl).pTDC->IsModified())
		{
			pCmdUI->Enable();
			return;
		}
	}

	// else nothing modified
	pCmdUI->Enable(FALSE);
}

void CToDoListDlg::OnCloseall() 
{
	// quick check to see if anything needs doing
	if (GetTDCCount() == 1)
	{
		TDCITEM& tdci = GetTDCItem(0);

		if (!tdci.pTDC->IsModified() && tdci.sFilePath.IsEmpty())
			return;
	}

	// delete tasklists
	int nCtrl = GetTDCCount();

	while (nCtrl--)
		CloseToDoCtrl(nCtrl, FALSE);

	// if empty then create a new dummy item		
	if (!GetTDCCount())
		OnNew();
	else
		ResizeDlg();
}

void CToDoListDlg::OnUpdateCloseall(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetTDCCount());
}

void CToDoListDlg::OnExit() 
{
	SaveSettings(); // before we close the tasklists
	
	// delete tasklists
	int nCtrl = GetTDCCount();

	while (nCtrl--)
		CloseToDoCtrl(nCtrl, FALSE);
	
	// if there are any still open then the user must have cancelled else destroy the window
	if (!GetTDCCount())
		DestroyWindow();	
}

void CToDoListDlg::OnUpdateMovetask(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetTDCCount() && GetToDoCtrl().GetSelectedItem());	
}

void CToDoListDlg::OnTimer(UINT nIDEvent) 
{
	CDialog::OnTimer(nIDEvent);

	// if no controls are active kill the timers
	if (!GetTDCCount())
	{
		SetTimer(TIMER_CHECKREADONLY, FALSE);
		SetTimer(TIMER_CHECKTIMESTAMP, FALSE);
		return;
	}

	// don't check whilst in the middle of saving and prevent reentrancy
	if (m_bSaving || m_bInTimer)
		return;

	CAutoFlag af(m_bInTimer, TRUE);

	switch (nIDEvent)
	{
	case TIMER_CHECKREADONLY:
		{
			int nCtrl = GetTDCCount();

			while (nCtrl--)
			{
				TDCITEM& tdci = GetTDCItem(nCtrl);
				BOOL bLastStatusReadOnly = tdci.bLastStatusReadOnly;

				// we only check if its a remote file
				if (CDriveInfo::IsRemotePath(tdci.sFilePath))
				{
					DWORD dwAttrib = GetFileAttributes(tdci.sFilePath);

					if (dwAttrib != 0xffffffff)
					{
						BOOL bReadOnly = (dwAttrib & FILE_ATTRIBUTE_READONLY) ? 1 : 0;
						tdci.bLastStatusReadOnly = bReadOnly;

						if (bLastStatusReadOnly != -1 && bLastStatusReadOnly != bReadOnly)
						{
							CString sMessage;
							sMessage.Format("The status of the file '%s' has changed \nfrom '%s' to '%s'.", 
											tdci.sFilePath, bReadOnly ? "writable" : "read-only", 
											bReadOnly ? "read-only" : "writable");

							if (!bReadOnly)
								sMessage += "\n\nWould you like to reload the it?";

							if (MessageBox(sMessage, ASCOPYRIGHT, !bReadOnly ? MB_YESNO : MB_OK) == IDYES)
							{
								// stop the existing file getting saved
								tdci.pTDC->SetModified(FALSE);

								// try reopening first
								if (OpenTaskList(tdci.sFilePath, FALSE))
								{
									// if that succeeds then close the previous version
									CloseToDoCtrl(nCtrl, FALSE);
								}
							}
						}
					}
				}
			}
		}
		break;

	case TIMER_CHECKTIMESTAMP:
		{
			int nCtrl = GetTDCCount();

			while (nCtrl--)
			{
				TDCITEM& tdci = GetTDCItem(nCtrl);

				time_t tLastMod = tdci.tLastMod;
				time_t tCurMod = GetLastModified(tdci.sFilePath); // can be 0 if file is no longer accessible
				tdci.tLastMod = tCurMod;
				
				if (tLastMod != 0 && tCurMod != 0 && tLastMod != tCurMod)
				{
					CString sMessage;
					sMessage.Format("The file '%s' has been modified outside of ToDoList.\n\nWould you like to reload it?", 
									tdci.sFilePath);
					
					if (MessageBox(sMessage, ASCOPYRIGHT, MB_YESNO) == IDYES)
					{
						// stop the existing file getting saved
						tdci.pTDC->SetModified(FALSE);
						
						// try reopening first
						if (OpenTaskList(tdci.sFilePath, FALSE))
						{
							// if that succeeds then close the previous version
							CloseToDoCtrl(nCtrl, FALSE);
						}
					}
				}
			}
		}
		break;
	}
}

void CToDoListDlg::OnImportTasklist() 
{
	CFileDialog dialog(TRUE, "xml", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "Task Lists (*.xml)|*.xml||", this);
	
	dialog.m_ofn.lpstrTitle = "Import Task List";

	if (dialog.DoModal() == IDOK)
	{
		if (GetToDoCtrl().Import(dialog.GetPathName()))
		{
			UpdateCaption();
		}
		else
			MessageBox("The selected file does not appear to be a valid task list.", ASCOPYRIGHT, MB_OK);
	}
}


void CToDoListDlg::OnSetPriority(UINT nCmdID) 
{
	if (GetToDoCtrl().GetSelectedItem())
		GetToDoCtrl().SetSelectedTaskPriority(nCmdID - ID_EDIT_SETPRIORITY0);
}

void CToDoListDlg::OnUpdateSetPriority(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck((int)(pCmdUI->m_nID - ID_EDIT_SETPRIORITY0) == GetToDoCtrl().GetSelectedTaskPriority());
}

void CToDoListDlg::OnEditSetfileref() 
{
	CToDoCtrl& tdc = GetToDoCtrl();

	if (tdc.GetSelectedItem())
	{
		CString sFileRef = tdc.GetSelectedTaskFileRef();

		CFileDialog dialog(TRUE, NULL, sFileRef, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "All Files (*.*)|*.*||");
		dialog.m_ofn.lpstrTitle = "Select File to which Task Refers";

		if (dialog.DoModal() == IDOK)
			tdc.SetSelectedTaskFileRef(dialog.GetPathName());
	}
}

void CToDoListDlg::OnUpdateEditSetfileref(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetToDoCtrl().GetSelectedItem() != NULL);
}

void CToDoListDlg::OnEditOpenfileref() 
{
	CString sFileRef = GetToDoCtrl().GetSelectedTaskFileRef();

	if (!sFileRef.IsEmpty())
		ShellExecute(*this, NULL, sFileRef, NULL, NULL, SW_SHOWNORMAL); 
}

void CToDoListDlg::OnUpdateEditOpenfileref(CCmdUI* pCmdUI) 
{
	CString sFileRef = GetToDoCtrl().GetSelectedTaskFileRef();

	if (sFileRef.IsEmpty())
		pCmdUI->Enable(FALSE);
	else
	{
		pCmdUI->Enable(TRUE);
		pCmdUI->SetText(sFileRef);
	}
}

void CToDoListDlg::OnUpdateUserTool1(CCmdUI* pCmdUI) 
{
	if (pCmdUI->m_pMenu)
	{
		// delete existing tool entries first
		for (int nTool = 0; nTool < 16; nTool++)
			pCmdUI->m_pMenu->DeleteMenu(pCmdUI->m_nID + nTool, MF_BYCOMMAND);
		
		// if we have any tools to add we do it here
		CUserToolArray aTools;

		if (CPreferencesDlg().GetUserTools(aTools))
		{
			// add valid tools only by first removing invalid items
			nTool = aTools.GetSize();

			while (nTool--)
			{
				if (aTools[nTool].sToolName.IsEmpty() || aTools[nTool].sToolPath.IsEmpty())
					aTools.RemoveAt(nTool);
			}

			if (aTools.GetSize())
			{
				int nPos = 0;

				for (nTool = 0; nTool < aTools.GetSize(); nTool++)
				{
					CString sMenuItem;
					
					if (nPos < 9)
						sMenuItem.Format("&%d %s", nPos + 1, aTools[nTool].sToolName);
					else
						sMenuItem = aTools[nTool].sToolName;
					
					pCmdUI->m_pMenu->InsertMenu(pCmdUI->m_nIndex++, MF_BYPOSITION | MF_STRING, 
												ID_TOOLS_USERTOOL1 + nTool, sMenuItem);
					
					nPos++;
				}


				// update end menu count
				pCmdUI->m_nIndex--; // point to last menu added
				pCmdUI->m_nIndexMax = pCmdUI->m_pMenu->GetMenuItemCount();

				pCmdUI->m_bEnableChanged = TRUE;    // all the added items are enabled
			}
		}
		
		// if nothing to add just re-add placeholder
		if (!aTools.GetSize())
		{
			CString sDefault;
			sDefault.LoadString(ID_TOOLS_USERTOOL1);
			
			pCmdUI->m_pMenu->InsertMenu(pCmdUI->m_nIndex, MF_BYPOSITION | MF_STRING | MF_GRAYED, 
				ID_TOOLS_USERTOOL1, sDefault);
		}
	}
}

void CToDoListDlg::OnUserTool(UINT nCmdID) 
{
	CUserToolArray aTools;
	
	if (CPreferencesDlg().GetUserTools(aTools))
	{
		int nTool = nCmdID - ID_TOOLS_USERTOOL1;
		
		if (nTool >= 0 && nTool < 16)
		{
			CString sCmdLine = aTools[nTool].sCmdline;
			CToolsCmdlineParser tcp(sCmdLine);

			// do necessary substitutions
			CString sFullPath = GetTDCItem().sFilePath;
			char szDrive[_MAX_DRIVE], szPath[_MAX_PATH], szFileTitle[_MAX_FNAME], szExt[_MAX_EXT];

			_splitpath(sFullPath, szDrive, szPath, szFileTitle, szExt);

			tcp.ReplaceArgument(CLAT_PATHNAME, sFullPath);
			tcp.ReplaceArgument(CLAT_FOLDER, CString(szDrive) + szPath);
			tcp.ReplaceArgument(CLAT_FILENAME, CString(szFileTitle) + szExt);
			tcp.ReplaceArgument(CLAT_FILETITLE, szFileTitle);

			if (tcp.IsUserInputRequired())
			{
				CToolsUserInputDlg dialog(tcp);

				if (dialog.DoModal() != IDOK)
					return;

				// process the results
				CCLArgArray aArgs;
				int nArg = tcp.GetUserArguments(aArgs);
				
				while (nArg--)
				{
					CString sResult(dialog.GetResult(aArgs[nArg].sName));
					tcp.ReplaceArgument(aArgs[nArg].sName, sResult);
				}
			}

			ShellExecute(*this, NULL, aTools[nTool].sToolPath, tcp.GetCmdLine(), NULL, SW_SHOWNORMAL);
		}
	}
}

// "D:\_AbstractSpoon\to-html.xsl" "D:\_AbstractSpoon\other\test.xml" "D:\_AbstractSpoon\to-html.xsl" -o D:\_AbstractSpoon\other\test.htm"}
void CToDoListDlg::OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu) 
{
	CDialog::OnInitMenuPopup(pPopupMenu, nIndex, bSysMenu);
	
	// we only need handle this for the main menu if the toolbar is not visible
	if (!IsToolbarShowing() || !bSysMenu)
		CToolbarHelper::PrepareMenuItems(pPopupMenu, this);	
}
