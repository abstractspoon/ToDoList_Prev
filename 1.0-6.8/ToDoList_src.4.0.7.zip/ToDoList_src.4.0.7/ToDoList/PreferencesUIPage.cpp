// PreferencesUIPage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesUIPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUIPage property page

IMPLEMENT_DYNCREATE(CPreferencesUIPage, CPropertyPage)

CPreferencesUIPage::CPreferencesUIPage() : 
	CPropertyPage(CPreferencesUIPage::IDD) 
{
	//{{AFX_DATA_INIT(CPreferencesUIPage)
	//}}AFX_DATA_INIT

	// load settings
	m_bShowCtrlsAsColumns = AfxGetApp()->GetProfileInt("Preferences", "ShowCtrlsAsColumns", FALSE);
	m_bShowCommentsAlways = AfxGetApp()->GetProfileInt("Preferences", "ShowCommentsAlways", FALSE);
	m_bAutoReposCtrls = AfxGetApp()->GetProfileInt("Preferences", "AutoReposCtrls", TRUE);
	m_bSpecifyToolbarImage = AfxGetApp()->GetProfileInt("Preferences", "SpecifyToolbarImage", FALSE);
	m_bSharedCommentsHeight = AfxGetApp()->GetProfileInt("Preferences", "SharedCommentsHeight", TRUE);
	m_bAutoHideTabbar = AfxGetApp()->GetProfileInt("Preferences", "AutoHideTabbar", TRUE);
	m_bStackTabbarItems = AfxGetApp()->GetProfileInt("Preferences", "StackTabbarItems", FALSE);
	m_bRightAlignLabels = AfxGetApp()->GetProfileInt("Preferences", "RightAlignLabels", FALSE);
	m_bFocusTreeOnEnter = AfxGetApp()->GetProfileInt("Preferences", "FocusTreeOnEnter", FALSE);
	m_bLargeToolbarIcons = AfxGetApp()->GetProfileInt("Preferences", "LargeToolbarIcons", TRUE);
}

CPreferencesUIPage::~CPreferencesUIPage()
{
}

void CPreferencesUIPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesUIPage)
	DDX_Check(pDX, IDC_SHOWCTRLSASCOLUMNS, m_bShowCtrlsAsColumns);
	DDX_Check(pDX, IDC_SHOWCOMMENTSALWAYS, m_bShowCommentsAlways);
	DDX_Check(pDX, IDC_AUTOREPOSCTRLS, m_bAutoReposCtrls);
	DDX_Check(pDX, IDC_SHAREDCOMMENTSHEIGHT, m_bSharedCommentsHeight);
	DDX_Check(pDX, IDC_AUTOHIDETABBAR, m_bAutoHideTabbar);
	DDX_Check(pDX, IDC_STACKTABBARITEMS, m_bStackTabbarItems);
	DDX_Check(pDX, IDC_RIGHTALIGNLABELS, m_bRightAlignLabels);
	DDX_Check(pDX, IDC_FOCUSTREEONENTER, m_bFocusTreeOnEnter);
	DDX_Check(pDX, IDC_LARGETOOLBARICONS, m_bLargeToolbarIcons);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPreferencesUIPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPreferencesUIPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUIPage message handlers

BOOL CPreferencesUIPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreferencesUIPage::OnOK() 
{
	CPropertyPage::OnOK();
	
	// save settings
	AfxGetApp()->WriteProfileInt("Preferences", "ShowCtrlsAsColumns", m_bShowCtrlsAsColumns);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowCommentsAlways", m_bShowCommentsAlways);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoReposCtrls", m_bAutoReposCtrls);
	AfxGetApp()->WriteProfileInt("Preferences", "SpecifyToolbarImage", m_bSpecifyToolbarImage);
	AfxGetApp()->WriteProfileInt("Preferences", "SharedCommentsHeight", m_bSharedCommentsHeight);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoHideTabbar", m_bAutoHideTabbar);
	AfxGetApp()->WriteProfileInt("Preferences", "StackTabbarItems", m_bStackTabbarItems);
	AfxGetApp()->WriteProfileInt("Preferences", "RightAlignLabels", m_bRightAlignLabels);
	AfxGetApp()->WriteProfileInt("Preferences", "FocusTreeOnEnter", m_bFocusTreeOnEnter);
	AfxGetApp()->WriteProfileInt("Preferences", "LargeToolbarIcons", m_bLargeToolbarIcons);
//	AfxGetApp()->WriteProfileInt("Preferences", "", m_b);
}
