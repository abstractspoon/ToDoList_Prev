// PlainTextImporter.cpp: implementation of the CPlainTextImporter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PlainTextImporter.h"
#include <time.h>
#include <unknwn.h>
#include "..\SHARED\iTasklist.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPlainTextImporter::CPlainTextImporter()
{

}

CPlainTextImporter::~CPlainTextImporter()
{

}

bool CPlainTextImporter::Import(const char* szSrcFilePath, ITaskList* pDestTaskFile)
{
	ITaskList2* pTL2 = 0;
	pDestTaskFile->QueryInterface(IID_TASKLIST2, reinterpret_cast<void**>(&pTL2));

	CStdioFile file;

	if (!file.Open(szSrcFilePath, CFile::modeRead))
		return false;

	CString sLine;
	
	while (file.ReadString(sLine)) 
	{
		if (!sLine.IsEmpty())
		{
			HTASKITEM hNew;
			int nDelim = sLine.Find("|");
			
			if (nDelim != -1)
			{
				hNew = pDestTaskFile->NewTask(sLine.Left(nDelim));
				pDestTaskFile->SetTaskComments(hNew, sLine.Mid(nDelim + 1));
			}
			else
				hNew = pDestTaskFile->NewTask(sLine);
		}
	}
	return true;
}
