// PlainTextImport.h : main header file for the PLAINTEXTIMPORT DLL
//

#if !defined(AFX_PLAINTEXTIMPORT_H__D83CC0C3_14D1_4FDD_BA66_B7FC4709C200__INCLUDED_)
#define AFX_PLAINTEXTIMPORT_H__D83CC0C3_14D1_4FDD_BA66_B7FC4709C200__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CPlainTextImportApp
// See PlainTextImport.cpp for the implementation of this class
//

class CPlainTextImportApp : public CWinApp
{
public:
	CPlainTextImportApp();
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PLAINTEXTIMPORT_H__D83CC0C3_14D1_4FDD_BA66_B7FC4709C200__INCLUDED_)
