// PlainTextImporter.h: interface for the CPlainTextImporter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PLAINTEXTIMPORTER_H__E1C1DB38_D45E_481E_8D91_7D8455C5155E__INCLUDED_)
#define AFX_PLAINTEXTIMPORTER_H__E1C1DB38_D45E_481E_8D91_7D8455C5155E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\SHARED\IImportExport.h"

class CPlainTextImporter : public IImportTasklist  
{
public:
	CPlainTextImporter();
	virtual ~CPlainTextImporter();

   void Release() { delete this; }
   const char* GetMenuText() { return "Plain Text"; }
	const char* GetFileFilter() { return "Text Files (*.txt)|*.txt||"; }
	const char* GetFileExtension() { return "txt"; }

	bool Import(const char* szSrcFilePath, ITaskList* pDestTaskFile);

};

#endif // !defined(AFX_PLAINTEXTIMPORTER_H__E1C1DB38_D45E_481E_8D91_7D8455C5155E__INCLUDED_)
