// ToDoCtrlData.h: interface for the CToDoCtrlData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TODOCTRLDATA_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_)
#define AFX_TODOCTRLDATA_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>

enum TDC_ATTRIBUTE
{
	TDCA_NONE,
	TDCA_TASKNAME,
	TDCA_DONEDATE,
	TDCA_DUEDATE,
	TDCA_STARTDATE,
	TDCA_PRIORITY,
	TDCA_COLOR,
	TDCA_ALLOCTO,
	TDCA_ALLOCBY,
	TDCA_STATUS,
	TDCA_CATEGORY,
	TDCA_PERCENT,
	TDCA_TIMEEST,
	TDCA_TIMESPENT,
	TDCA_FILEREF,
	TDCA_COMMENTS,
	TDCA_PROJNAME,
};

enum // find flags
{
	FIND_TITLECOMMENTS	= 0,
	FIND_PRIORITY,
	FIND_PERCENTDONE,
	FIND_TIMEEST,
	FIND_TIMESPENT,
	FIND_STARTDATE,
	FIND_DUEDATE,
	FIND_DONEDATE,
	FIND_ALLOCTO,
	FIND_ALLOCBY,
	FIND_STATUS,
	FIND_CATEGORY,
	FIND_TASKID,

	FIND_INCLUDEDONE	= 0x0100,
	FIND_MATCHCASE		= 0x0200,
	FIND_MATCHWHOLEWORD	= 0x0400,
};

struct SEARCHPARAMS
{
	int nFindWhat;
	DWORD dwFlags;

	CString sText;
	COleDateTime dateFrom, dateTo;
	int nFrom, nTo;
	double dFrom, dTo;
};

struct SEARCHRESULT
{
	DWORD dwID;
	CString sMatch;
	COleDateTime dateMatch;
	int nMatch;
	double dMatch;
};

typedef CArray<SEARCHRESULT, SEARCHRESULT&> CResultArray;

enum 
{
	TDCTU_HOURS  = 'H',
	TDCTU_DAYS   = 'D',
	TDCTU_WEEKS  = 'W',
	TDCTU_MONTHS = 'M',
	TDCTU_YEARS  = 'Y',
};

struct TODOITEM
{
	TODOITEM(LPCTSTR szTitle, LPCTSTR szComments = NULL) 
	{ 
		sTitle = szTitle; 
		sComments = szComments; 
		color = 0; 
		dateStart.m_dt = dateDone.m_dt = dateDue.m_dt = 0;
		nPriority = 5;
		nPercentDone = 0;
		dTimeEstimate = dTimeSpent = 0;
		nTimeEstUnits = nTimeSpentUnits = TDCTU_HOURS;

		nCalcPriority = nCalcPercent = -1;
		dCalcTimeEstimate = dCalcTimeSpent = -1;
		dateEarliestDue.m_dt = -1;
		
		SetModified();
	}
	
	TODOITEM() 
	{ 
		color = 0; 
		dateStart.m_dt = dateDone.m_dt = dateDue.m_dt = 0;
		nPriority = 5;
		nPercentDone = 0;
		dTimeEstimate = dTimeSpent = 0;
		nTimeEstUnits = nTimeSpentUnits = TDCTU_HOURS;

		nCalcPriority = nCalcPercent = -1;
		dCalcTimeEstimate = dCalcTimeSpent = -1;
		dateEarliestDue.m_dt = -1;
		
		SetModified();
	}
	
	TODOITEM(const TODOITEM& tdi) 
	{ 
		sTitle = tdi.sTitle; 
		sComments = tdi.sComments; 
		color = tdi.color; 
		dateStart = tdi.dateStart;
		dateDone = tdi.dateDone;
		dateDue = tdi.dateDue;
		nPriority = tdi.nPriority;
		nPercentDone = tdi.nPercentDone;
		sFileRefPath = tdi.sFileRefPath;
		dTimeEstimate = tdi.dTimeEstimate;
		dTimeSpent = tdi.dTimeSpent;
		nTimeEstUnits = tdi.nTimeEstUnits;
		nTimeSpentUnits = tdi.nTimeSpentUnits;
		sAllocTo = tdi.sAllocTo;
		sAllocBy = tdi.sAllocBy;
		sCategory = tdi.sCategory;
		sStatus = tdi.sStatus;

		nCalcPriority = tdi.nCalcPriority;
		nCalcPercent = tdi.nCalcPercent;
		dCalcTimeEstimate = tdi.dCalcTimeEstimate;
		dCalcTimeSpent = tdi.dCalcTimeSpent;
		dateEarliestDue = tdi.dateEarliestDue;
		
		SetModified();
	}
	
	inline BOOL HasStart() const { return (dateStart.m_dt > 0) ? TRUE : FALSE; }
	inline BOOL HasDue() const { return (dateDue.m_dt > 0) ? TRUE : FALSE;; }
	inline BOOL IsDone() const { return (dateDone.m_dt > 0) ? TRUE : FALSE; }

	inline void ClearStart() { dateStart.m_dt = 0; }
	inline void ClearDue() { dateDue.m_dt = 0; }
	inline void ClearDone() { dateDone.m_dt = 0; }
	
	BOOL IsDue() const
	{ 
		return IsDue(COleDateTime::GetCurrentTime());
	}
	
	BOOL IsDue(const COleDateTime& dateDueBy) const
	{ 
		if (IsDone() || !HasDue())
			return FALSE;
		
		return ((double)(int)dateDue.m_dt <= (double)(int)dateDueBy.m_dt); 
	}
	
	void SetModified() { tLastMod = COleDateTime::GetCurrentTime(); }

	void ResetCalcs() 
	{
		nCalcPriority = nCalcPercent = -1;
		dCalcTimeEstimate = dCalcTimeSpent = -1;
		dateEarliestDue.m_dt = -1;
	}
	
	CString sTitle;
	CString sComments;
	COLORREF color;
	COleDateTime dateStart, dateDue, dateDone;
	int nPriority;
	CString sAllocTo, sAllocBy;
	CString sStatus, sCategory;
	int nPercentDone;
	CString sFileRefPath;
	double dTimeEstimate, dTimeSpent;
	int nTimeEstUnits, nTimeSpentUnits;
	COleDateTime tLastMod;
	
	// cached calculations for drawing optimization
	int nCalcPriority;
	int nCalcPercent;
	double dCalcTimeEstimate, dCalcTimeSpent;
	COleDateTime dateEarliestDue;
};

typedef CMap<DWORD, DWORD, TODOITEM, TODOITEM&> CTDIMap;

// sort helper structure
class CToDoCtrlData;

enum TDC_SORTBY
{
	TDC_SORTBYNONE,
	TDC_SORTBYNAME,
	TDC_SORTBYDONEDATE,
	TDC_SORTBYDUEDATE,
	TDC_SORTBYSTARTDATE,
	TDC_SORTBYPRIORITY,
	TDC_SORTBYCOLOR,
	TDC_SORTBYALLOCTO,
	TDC_SORTBYALLOCBY,
	TDC_SORTBYSTATUS,
	TDC_SORTBYCATEGORY,
	TDC_SORTBYPERCENT,
	TDC_SORTBYTIMEEST,
	TDC_SORTBYTIMESPENT,
	TDC_SORTBYID,
	TDC_SORTBYDONE,
};

typedef CMap<DWORD, DWORD, HTREEITEM, HTREEITEM&> CHTIMap;

struct TDSORTSTRUCT
{
	CToDoCtrlData* pData;
	const CHTIMap* pMapHTItems;
	TDC_SORTBY nSortBy;
	BOOL bAscending;
};

enum 
{
	TDCCHECKPARENT = 0x1,
	TDCCHECKCHILDREN = 0x2,
	TDCCHECKALL = 0x3,
};

enum 
{ 
	SET_NOCHANGE = -1, 
	SET_FAILED = 0, 
	SET_CHANGE = 1 
};

class CXmlItem;

class CToDoCtrlData  
{
	friend class CToDoCtrl;
	
protected:
	CToDoCtrlData(CTreeCtrl& tree, const CWordArray& aStyles);
	virtual ~CToDoCtrlData();

	inline BOOL GetTask(DWORD dwID, TODOITEM& tdi) const { return dwID ? m_mapTDItems.Lookup(dwID, tdi) : FALSE; }
	inline BOOL GetTask(HTREEITEM hti, TODOITEM& tdi) const { return GetTask(m_tree.GetItemData(hti), tdi); }
	inline void UpdateTask(DWORD dwID, TODOITEM& tdi) { tdi.SetModified(); m_mapTDItems[dwID] = tdi; }
	inline void AddTask(DWORD dwID, TODOITEM& tdi) { m_mapTDItems.SetAt(dwID, tdi); }
	inline void DeleteTask(DWORD dwID) { m_mapTDItems.RemoveKey(dwID); }
	inline void DeleteAllTasks() { m_mapTDItems.RemoveAll(); }
	inline UINT GetTaskCount() const { return m_mapTDItems.GetCount(); }
	inline DWORD GetTaskID(HTREEITEM hti) const { return hti ? m_tree.GetItemData(hti) : 0; }
	inline HTREEITEM GetItem(DWORD dwID) { return FindItem(dwID, NULL); }

	void Sort(TDC_SORTBY nBy, BOOL bAscending);

	// Gets
	CString GetTaskTitle(DWORD dwID) const;
	COleDateTime GetTaskDoneDate(DWORD dwID) const;
	COleDateTime GetTaskDueDate(DWORD dwID) const;
	COleDateTime GetTaskStartDate(DWORD dwID) const;
	BOOL IsTaskDone(DWORD dwID) const;
	BOOL IsTaskDue(DWORD dwID) const;
	COLORREF GetTaskColor(DWORD dwID) const; // -1 on no item selected
	CString GetTaskComments(DWORD dwID) const;
	int GetTaskPercent(DWORD dwID, BOOL bCheckIfDone) const;
	double GetTaskTimeEstimate(DWORD dwID) const; // in hours
	double GetTaskTimeSpent(DWORD dwID) const; // in hours
	double GetTaskTimeEstimate(DWORD dwID, int& nUnits) const;
	double GetTaskTimeSpent(DWORD dwID, int& nUnits) const;
	CString GetTaskAllocTo(DWORD dwID) const;
	CString GetTaskAllocBy(DWORD dwID) const;
	CString GetTaskStatus(DWORD dwID) const;
	CString GetTaskCategory(DWORD dwID) const;
	CString GetTaskFileRef(DWORD dwID) const;
	int GetTaskPriority(DWORD dwID) const;

	COLORREF GetTaskColor(const HTREEITEM hti) const;
	double GetTaskTimeEstimate(const HTREEITEM hti) const;
	double GetTaskTimeSpent(const HTREEITEM hti) const;
	CString GetTaskAllocTo(const HTREEITEM hti) const;
	CString GetTaskAllocBy(const HTREEITEM hti) const;
	CString GetTaskStatus(const HTREEITEM hti) const;
	CString GetTaskCategory(const HTREEITEM hti) const;
	int GetTaskPriority(const HTREEITEM hti) const;
	BOOL IsTaskDue(HTREEITEM hti) const;
	BOOL DeleteTask(HTREEITEM hti);
	int GetItemPos(HTREEITEM hti, HTREEITEM htiSearch) const; // returns 0 if not found
	BOOL IsParentTaskDone(HTREEITEM hti) const; // this is recursive
	int AreChildTasksDone(HTREEITEM hti) const; // 1=yes, 0=no, -1=no children
	HTREEITEM GetTopLevelTask(HTREEITEM htiSubtask) const;

	double GetEarliestDueDate(HTREEITEM hti) const;
	int GetHighestPriority(HTREEITEM hti) const;
	int CalcPercentDone(const HTREEITEM hti) const;
	double CalcTimeEstimate(const HTREEITEM hti, int nUnits) const;
	double CalcTimeSpent(const HTREEITEM hti, int nUnits) const;

	// Sets. 0 = failed, 1 = success, -1 = success (no change)
	int SetTaskStartDate(DWORD dwID, const COleDateTime& date);
	int SetTaskDoneDate(DWORD dwID, const COleDateTime& date);
	int SetTaskDueDate(DWORD dwID, const COleDateTime& date);
	int SetTaskDone(DWORD dwID, BOOL bDone, int& nPrevPercent);
	int SetTaskColor(DWORD dwID, COLORREF color);
	int SetTaskComments(DWORD dwID, LPCTSTR szComments);
	int SetTaskPercent(DWORD dwID, int nPercent);
	int SetTaskTimeEstimate(DWORD dwID, const double& dTime, int nUnits = TDCTU_HOURS);
	int SetTaskTimeSpent(DWORD dwID, const double& dTime, int nUnits = TDCTU_HOURS);
	int SetTaskAllocTo(DWORD dwID, LPCTSTR szAllocTo);
	int SetTaskAllocBy(DWORD dwID, LPCTSTR szAllocBy);
	int SetTaskStatus(DWORD dwID, LPCTSTR szStatus);
	int SetTaskCategory(DWORD dwID, LPCTSTR szCategory);
	int SetTaskFileRef(DWORD dwID, LPCTSTR szFilePath);
	int SetTaskPriority(DWORD dwID, int nPriority); // 0-10 (10 is highest)
	int SetTaskTitle(DWORD dwID, LPCTSTR szTitle);
	int SetTaskAttributeAsParent(HTREEITEM hti, TDC_ATTRIBUTE nAttrib);

	int FindTasks(const SEARCHPARAMS& params, CResultArray& aResults) const;
	DWORD FindFirstTask(const SEARCHPARAMS& params, SEARCHRESULT& result) const;

	void BuildHTIMap(CHTIMap& mapHTI);
	void UpdateHTIMapEntry(CHTIMap& mapHTI, HTREEITEM hti);
	BOOL IsTaskFullyDone(const HTREEITEM hti, const TODOITEM& tdi, BOOL bCheckSiblings) const;
	
	double GetEarliestDueDate(HTREEITEM hti, const TODOITEM& tdi) const;
	int GetHighestPriority(HTREEITEM hti, const TODOITEM& tdi) const;
	double CalcTimeEstimate(const HTREEITEM hti, const TODOITEM& tdi, int nUnits) const;
	double CalcTimeSpent(const HTREEITEM hti, const TODOITEM& tdi, int nUnits) const;
	int CalcPercentDone(const HTREEITEM hti, const TODOITEM& tdi) const;
	int CalcPercentFromTime(const HTREEITEM hti, const TODOITEM& tdi) const; // spent / estimate

	// internal use only
	void SumPercentDone(const HTREEITEM hti, const TODOITEM& tdi,
						double& dTotalPercent, double& dTotalWeighting) const;

	void ResetCachedCalculations();

	BOOL IsTaskTimeTrackable(HTREEITEM hti);
	BOOL IsTaskDone(HTREEITEM hti, DWORD dwExtraCheck = 0) const;
	void ApplyLastChangeToSubtasks(const HTREEITEM hti, const TODOITEM& tdi, TDC_ATTRIBUTE nAttrib);

	static int MapTimeUnits(const CString& sUnits);
	static CString MapTimeUnits(int nUnits);

protected:
	CTDIMap m_mapTDItems; // the real data
	CTreeCtrl& m_tree; // CToDoCtrl tree
	const CWordArray& m_aStyles; // CToDoCtrl styles

protected:
	static int ParseSearchString(LPCTSTR szLookFor, CStringArray& aWords);
	static BOOL FindWord(LPCTSTR szWord, LPCTSTR szText, BOOL bMatchCase, BOOL bMatchWholeWord);
	
	DWORD FindFirstTask(HTREEITEM hti, const SEARCHPARAMS& params, SEARCHRESULT& result) const;
	int FindTasks(HTREEITEM hti, const SEARCHPARAMS& params, CResultArray& aResults) const;
	BOOL TaskMatches(HTREEITEM tdi, const SEARCHPARAMS& params, SEARCHRESULT& result) const;
	static BOOL TaskMatches(const COleDateTime& date, const SEARCHPARAMS& params);
	static BOOL TaskMatches(const CString& sText, const SEARCHPARAMS& params);
	static BOOL TaskMatches(const double& dValue, const SEARCHPARAMS& params);
	static BOOL TaskMatches(int nValue, const SEARCHPARAMS& params);

	HTREEITEM FindItem(DWORD dwID, HTREEITEM htiStart);

	// for sorting
	void Sort(HTREEITEM hti, const TDSORTSTRUCT& ss);
	static int CALLBACK CompareFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort); 
	static int Compare(const COleDateTime& date1, const COleDateTime& date2, BOOL bAscending);
	static int Compare(const CString& sText1, const CString& sText2, BOOL bAscending);
	static int Compare(int nNum1, int nNum2, BOOL bAscending);
	static int Compare(const double& dNum1, const double& dNum2, BOOL bAscending);

	inline BOOL HasStyle(int nStyle) const { return m_aStyles[nStyle] ? TRUE : FALSE; }
};

#endif // !defined(AFX_TODOCTRLDATA_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_)
