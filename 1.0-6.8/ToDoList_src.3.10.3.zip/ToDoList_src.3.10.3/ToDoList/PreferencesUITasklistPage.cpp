// PreferencesUITasklistPage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesUITasklistPage.h"

#include "..\shared\colordef.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUITasklistPage property page

IMPLEMENT_DYNCREATE(CPreferencesUITasklistPage, CPropertyPage)

CPreferencesUITasklistPage::CPreferencesUITasklistPage() : 
	CPropertyPage(CPreferencesUITasklistPage::IDD)
{
	//{{AFX_DATA_INIT(CPreferencesUITasklistPage)
	m_bShowParentsAsFolders = FALSE;
	//}}AFX_DATA_INIT
	// column visibility
	m_aColPrefs.Add(COLUMNPREF("Position", PTPC_POSITION, TRUE)); 
	m_aColPrefs.Add(COLUMNPREF("ID", PTPC_ID, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF("Priority", PTPC_PRIORITY, TRUE)); 
	m_aColPrefs.Add(COLUMNPREF("Percent Complete", PTPC_PERCENT, TRUE)); 
	m_aColPrefs.Add(COLUMNPREF("Time Estimate", PTPC_TIMEEST, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF("Time Spent", PTPC_TIMESPENT, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF("Track Time", PTPC_TRACKTIME, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF("Start Date", PTPC_STARTDATE, FALSE));
	m_aColPrefs.Add(COLUMNPREF("Due Date", PTPC_DUEDATE, TRUE)); 
	m_aColPrefs.Add(COLUMNPREF("Completed Date", PTPC_DONEDATE, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF("Allocated To", PTPC_ALLOCTO, TRUE)); 
	m_aColPrefs.Add(COLUMNPREF("Allocated By", PTPC_ALLOCBY, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF("Status", PTPC_STATUS, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF("Category", PTPC_CATEGORY, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF("File Reference", PTPC_FILEREF, FALSE)); 
	m_aColPrefs.Add(COLUMNPREF("Completed", PTPC_DONE, FALSE)); 

	int nIndex = m_aColPrefs.GetSize();
	
	while (nIndex--)
	{
		COLUMNPREF& col = m_aColPrefs[nIndex];

		CString sKey;
		sKey.Format("Col%d", col.nCol);
		
		col.bVisible = AfxGetApp()->GetProfileInt("Preferences\\ColumnVisibility", sKey, col.bVisible);
	}

	// prefs
	m_bShowInfoTips = AfxGetApp()->GetProfileInt("Preferences", "ShowInfoTips", TRUE);
	m_bShowComments = AfxGetApp()->GetProfileInt("Preferences", "ShowComments", TRUE);
	m_bShowButtonsInTree = AfxGetApp()->GetProfileInt("Preferences", "ShowButtonsInTree", TRUE);
	m_bStrikethroughDone = AfxGetApp()->GetProfileInt("Preferences", "StrikethroughDone", TRUE);
	m_bShowPathInHeader = AfxGetApp()->GetProfileInt("Preferences", "ShowPathInHeader", TRUE);
	m_bFullRowSelection = AfxGetApp()->GetProfileInt("Preferences", "FullRowSelection", FALSE);
	m_bTreeCheckboxes = AfxGetApp()->GetProfileInt("Preferences", "TreeCheckboxes", FALSE);
	m_bEnableHeaderSorting = AfxGetApp()->GetProfileInt("Preferences", "EnableHeaderSorting", TRUE);
	m_bUseISOForDates = AfxGetApp()->GetProfileInt("Preferences", "DisplayDatesInISO", FALSE);
	m_bShowWeekdayInDates = AfxGetApp()->GetProfileInt("Preferences", "ShowWeekdayInDates", FALSE);
	m_bShowParentsAsFolders = AfxGetApp()->GetProfileInt("Preferences", "ShowParentsAsFolders", FALSE);
}

CPreferencesUITasklistPage::~CPreferencesUITasklistPage()
{
}

void CPreferencesUITasklistPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesUITasklistPage)
	DDX_Check(pDX, IDC_USEISODATEFORMAT, m_bUseISOForDates);
	DDX_Check(pDX, IDC_SHOWWEEKDAYINDATES, m_bShowWeekdayInDates);
	DDX_Check(pDX, IDC_SHOWPARENTSASFOLDERS, m_bShowParentsAsFolders);
	//}}AFX_DATA_MAP
	DDX_Check(pDX, IDC_DISPLAYPATHINHEADER, m_bShowPathInHeader);
	DDX_Check(pDX, IDC_STRIKETHROUGHDONE, m_bStrikethroughDone);
	DDX_Check(pDX, IDC_FULLROWSELECTION, m_bFullRowSelection);
	DDX_Check(pDX, IDC_TREECHECKBOXES, m_bTreeCheckboxes);
	DDX_Check(pDX, IDC_ENABLEHEADERSORTING, m_bEnableHeaderSorting);
	DDX_Control(pDX, IDC_COLUMNVISIBILITY, m_lbColumnVisibility);
	DDX_Check(pDX, IDC_SHOWINFOTIPS, m_bShowInfoTips);
	DDX_Check(pDX, IDC_SHOWCOMMENTS, m_bShowComments);
	DDX_Check(pDX, IDC_SHOWBUTTONSINTREE, m_bShowButtonsInTree);
	DDX_LBIndex(pDX, IDC_COLUMNVISIBILITY, m_nSelColumnVisibility);
}


BEGIN_MESSAGE_MAP(CPreferencesUITasklistPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPreferencesUITasklistPage)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
	ON_CLBN_CHKCHANGE(IDC_COLUMNVISIBILITY, OnColVisibilityChange)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUITasklistPage message handlers

BOOL CPreferencesUITasklistPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	int nIndex = (int)m_aColPrefs.GetSize();
	
	while (nIndex--)
	{
		int nPos = m_lbColumnVisibility.InsertString(0, m_aColPrefs[nIndex].szName);
		m_lbColumnVisibility.SetCheck(nPos, m_aColPrefs[nIndex].bVisible ? 1 : 0);

		// note: we can't use SetItemData because CCheckListBox uses it
	}
		
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CPreferencesUITasklistPage::GetShowColumn(PTP_COLUMN nColumn) const
{ 
	int nIndex = (int)m_aColPrefs.GetSize();
	
	while (nIndex--)
	{
		if (m_aColPrefs[nIndex].nCol == nColumn)
			return m_aColPrefs[nIndex].bVisible; 
	}

	// else
	return FALSE;
}


void CPreferencesUITasklistPage::OnColVisibilityChange()
{
	UpdateData();

	ASSERT (m_nSelColumnVisibility >= 0);
	
	if (m_nSelColumnVisibility >= 0)
		m_aColPrefs[m_nSelColumnVisibility].bVisible = m_lbColumnVisibility.GetCheck(m_nSelColumnVisibility);
}


void CPreferencesUITasklistPage::OnOK() 
{
	CPropertyPage::OnOK();
	
	// save settings
	// column visibility
	int nIndex = m_aColPrefs.GetSize();

	while (nIndex--)
	{
		CString sKey;
		sKey.Format("Col%d", m_aColPrefs[nIndex].nCol);

		AfxGetApp()->WriteProfileInt("Preferences\\ColumnVisibility", sKey, m_aColPrefs[nIndex].bVisible);
	}

	// save settings
	AfxGetApp()->WriteProfileInt("Preferences", "ShowInfoTips", m_bShowInfoTips);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowComments", m_bShowComments);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowPercentColumn", m_bShowPercentColumn);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowPriorityColumn", m_bShowPriorityColumn);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowButtonsInTree", m_bShowButtonsInTree);
	AfxGetApp()->WriteProfileInt("Preferences", "StrikethroughDone", m_bStrikethroughDone);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowPathInHeader", m_bShowPathInHeader);
	AfxGetApp()->WriteProfileInt("Preferences", "FullRowSelection", m_bFullRowSelection);
	AfxGetApp()->WriteProfileInt("Preferences", "TreeCheckboxes", m_bTreeCheckboxes);
	AfxGetApp()->WriteProfileInt("Preferences", "EnableHeaderSorting", m_bEnableHeaderSorting);
	AfxGetApp()->WriteProfileInt("Preferences", "DisplayDatesInISO", m_bUseISOForDates);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowWeekdayInDates", m_bShowWeekdayInDates);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowParentsAsFolders", m_bShowParentsAsFolders);
}

