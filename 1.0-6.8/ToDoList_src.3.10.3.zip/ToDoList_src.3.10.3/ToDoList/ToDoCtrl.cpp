// ToDoCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "ToDoCtrl.h"
#include "ExportToDoList.h"
#include "tdlschemadef.h"
#include "MergeToDoList.h"

#include "..\shared\xmlfileEx.h"
#include "..\shared\holdredraw.h"
#include "..\shared\deferWndMove.h"
#include "..\shared\dlgunits.h"
#include "..\shared\themed.h"
#include "..\shared\datehelper.h"
#include "..\shared\driveinfo.h"
#include "..\shared\toolbarhelper.h"
#include "..\shared\colordef.h"
#include "..\shared\spellcheckdlg.h"
#include "..\shared\passworddialog.h"
#include "..\shared\winclasses.h"
#include "..\shared\wclassdefines.h"

#include <Windowsx.h>
#include <float.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#ifndef SPI_GETSCREENSAVERRUNNING
#  define SPI_GETSCREENSAVERRUNNING 114
#endif

/////////////////////////////////////////////////////////////////////////////
// CToDoCtrl dialog

// control ids
enum 
{
	IDC_FIRST			= 100,

	IDC_TASKLIST,		
	IDC_PROJECTLABEL,	
	IDC_PROJECTNAME,	
	IDC_ALLOCTOLABEL,	
	IDC_ALLOCTO,		
	IDC_ALLOCBYLABEL,	
	IDC_ALLOCBY,		
	IDC_STATUSLABEL,	
	IDC_STATUS,		
	IDC_CATEGORYLABEL,	
	IDC_CATEGORY,		
	IDC_PRIORITYLABEL,	
	IDC_PRIORITY,		
	IDC_STARTLABEL,		
	IDC_STARTDATE,		
	IDC_DUELABEL,		
	IDC_DUEDATE,		
	IDC_PERCENTLABEL,	
	IDC_PERCENT,		
	IDC_PERCENTSPIN,	
	IDC_DONELABEL,		
	IDC_DONEDATE,		
	IDC_FILEPATHLABEL,	
	IDC_FILEPATH,		
	IDC_TIMEESTLABEL,	
	IDC_TIMEEST,		
	IDC_TIMESPENTLABEL,	
	IDC_TIMESPENT,		
	IDC_COMMENTSLABEL,	
	IDC_SPLITTER,		
	IDC_COMMENTS,		

	IDC_LAST,
};

struct TDCCOLUMN
{
	TDC_COLUMN nColID;
	LPCTSTR szName;
	TDC_SORTBY nSortBy;
	UINT nAlignment;
	BOOL bClickable;
	LPCTSTR szFont;
	BOOL bSymbolFont;
};

static TDCCOLUMN COLUMNS[] = 
{
	{ TDCC_ID, "ID", TDC_SORTBYID, DT_LEFT, TRUE, NULL, FALSE },
	{ TDCC_PRIORITY, "!", TDC_SORTBYPRIORITY, DT_CENTER, TRUE, NULL, TRUE },
	{ TDCC_PERCENT, "%", TDC_SORTBYPERCENT, DT_CENTER, TRUE, NULL, FALSE },
	{ TDCC_TIMEEST, "Est.", TDC_SORTBYTIMEEST, DT_RIGHT, TRUE, NULL, FALSE },
	{ TDCC_TIMESPENT, "Spent", TDC_SORTBYTIMESPENT, DT_RIGHT, TRUE, NULL, FALSE },
	{ TDCC_TRACKTIME, "�", (TDC_SORTBY)-1, DT_CENTER, FALSE, "Wingdings", TRUE },
	{ TDCC_STARTDATE, "Start", TDC_SORTBYSTARTDATE, DT_RIGHT, TRUE, NULL, FALSE },
	{ TDCC_DUEDATE, "Due", TDC_SORTBYDUEDATE, DT_RIGHT, TRUE, NULL, FALSE },
	{ TDCC_DONEDATE, "Completed", TDC_SORTBYDONEDATE, DT_RIGHT, TRUE, NULL, FALSE },
	{ TDCC_ALLOCTO, "To", TDC_SORTBYALLOCTO, DT_LEFT, TRUE, NULL, FALSE },
	{ TDCC_ALLOCBY, "By", TDC_SORTBYALLOCBY, DT_LEFT, TRUE, NULL, FALSE },
	{ TDCC_STATUS, "Status", TDC_SORTBYSTATUS, DT_LEFT, TRUE, NULL, FALSE },
	{ TDCC_CATEGORY, "Cat.", TDC_SORTBYCATEGORY, DT_LEFT, TRUE, NULL, FALSE },
	{ TDCC_FILEREF, "<", (TDC_SORTBY)-1, DT_LEFT, FALSE, "Wingdings", TRUE },
	{ TDCC_DONE, "a", TDC_SORTBYDONE, DT_CENTER, TRUE, "Marlett", TRUE },

	// special client column
	{ (TDC_COLUMN)NCG_CLIENTCOLUMNID, "Task", TDC_SORTBYNAME, DT_LEFT, TRUE, NULL, FALSE },
};

int NUM_COLUMNS = sizeof(COLUMNS) / sizeof(TDCCOLUMN);

LPCTSTR PRIORITIES[] = 
{
	"0 (Lowest)",
	"1 (Low)",
	"2 (Low)",
	"3 (Low)",
	"4 (Medium)",
	"5 (Medium)",
	"6 (Medium)",
	"7 (High)",
	"8 (High)",
	"9 (High)",
	"10 (Highest)"
};

struct CTRLITEM
{
	UINT nCtrlID;
	UINT nLabelID;
	TDC_COLUMN nCol;
};

static CTRLITEM CTRLITEMS[] = 
{
	{ IDC_PRIORITY,		IDC_PRIORITYLABEL,	TDCC_PRIORITY },
	{ IDC_PERCENT,		IDC_PERCENTLABEL,	TDCC_PERCENT },
	{ IDC_TIMEEST,		IDC_TIMEESTLABEL,	TDCC_TIMEEST },
	{ IDC_TIMESPENT,	IDC_TIMESPENTLABEL,	TDCC_TIMESPENT },
	{ IDC_STARTDATE,	IDC_STARTLABEL,		TDCC_STARTDATE },
	{ IDC_DUEDATE,		IDC_DUELABEL,		TDCC_DUEDATE },
	{ IDC_DONEDATE,		IDC_DONELABEL,		TDCC_DONEDATE },
	{ IDC_ALLOCTO,		IDC_ALLOCTOLABEL,	TDCC_ALLOCTO },
	{ IDC_ALLOCBY,		IDC_ALLOCBYLABEL,	TDCC_ALLOCBY },
	{ IDC_STATUS,		IDC_STATUSLABEL,	TDCC_STATUS },
	{ IDC_CATEGORY,		IDC_CATEGORYLABEL,	TDCC_CATEGORY },
	{ IDC_FILEPATH,		IDC_FILEPATHLABEL,	TDCC_FILEREF },
};

const int NUM_CTRLITEMS = sizeof(CTRLITEMS) / sizeof(CTRLITEM);
const int CTRLHEIGHT = 14; // dlu
const int CTRLVSPACING = 5; // dlu
const int CTRLHSPACING = 4; // dlu
const int CTRLSTARTOFFSET = 45; // dlu
const int CTRLENDOFFSET = 110; // dlu

// comments edit context menu
enum
{
	ID_COMMENTS_FIRST	= 0x8000,
	ID_COMMENTS_CUT	,
	ID_COMMENTS_COPY,
	ID_COMMENTS_PASTE,
	ID_COMMENTS_PASTEASREF,
	ID_COMMENTS_SELECTALL,
	ID_COMMENTS_OPENURL,
	ID_COMMENTS_FILEBROWSE,
	ID_COMMENTS_DATESTAMP_UTC,
	ID_COMMENTS_DATESTAMP_LOCAL,
	ID_COMMENTS_SPELLCHECK,
//	ID_COMMENTS_,

	ID_COMMENTS_LAST
};

// check states
#define TDC_UNCHECKED INDEXTOSTATEIMAGEMASK(1)
#define TDC_CHECKED INDEXTOSTATEIMAGEMASK(2)


// private class to help optimize xml parsing
class CXmlParseController : public IXmlParse
{
public:
	CXmlParseController(LPCTSTR szItem) : m_sItem(szItem) {}

	virtual BOOL Continue(LPCTSTR szItem, LPCTSTR szValue) const
	{
		return (m_sItem.CompareNoCase(szItem) != 0);
	}

protected:
	CString m_sItem;
};

// TRACE helper for tagging the start/end of functions
class TDTRACER
{
public:
	TDTRACER(LPCTSTR szFnName) : m_sFnName(szFnName) { TRACE("%s(start)\n", szFnName); }
	~TDTRACER() { TRACE("%s(end)\n", m_sFnName); }

protected:
	CString m_sFnName;
};

//////////////////////////////////////////////////////////////////////////////

const unsigned short FILEFORMAT = 6; // increment this when format changes
const unsigned short SPLITHEIGHT = 16; 
const unsigned short MINCOMMENTHEIGHT = 0;
const unsigned short DEFCOMMENTHEIGHT = 50;
const unsigned short MINNONCOMMENTHEIGHT = 250; // what's above the comment section
const COLORREF BLACK = RGB(0, 0, 0);
const COLORREF WHITE = RGB(240, 240, 240);
const UINT TIMER_TRACK = 1;
const double TIMEINCREMENT = 10 / 3600.0; // 10 secs in hours
const UINT ID_TIMEEDITBTN = 0xffff;
const LPCTSTR TDL_PROTOCOL = "tdl://";
const UINT WM_TDC_RESTOREFOCUSEDITEM = (WM_USER + 1);

#ifdef _DEBUG
const int TIMETRACKPERIOD = 100; // .1 secs in millesecs
#else
const int TIMETRACKPERIOD = 10000; // 10 secs in millesecs
#endif

const COLORREF DEFPRIORITYCOLORS[] = 
{
	WHITE,				// 0
	RGB(216, 216, 216),	// 1
	RGB(192, 192, 192),	// 2
	RGB(168, 168, 168),	// 3
	RGB(144, 144, 144),	// 4
	RGB(120, 120, 120),	// 5
	RGB(96, 96, 96),	// 6
	RGB(72, 72, 72),	// 7
	RGB(48, 48, 48),	// 8
	RGB(24, 24, 24),	// 9
	BLACK,				// 10
};

// static variables
CToDoCtrl::TDLCLIPBOARD CToDoCtrl::s_clipboard;
int CToDoCtrl::s_nCommentsHeight = 0;
TODOITEM CToDoCtrl::s_tdDefault;

CToDoCtrl::CToDoCtrl() : m_bModified(FALSE), 
						 m_dwNextUniqueID(1), 
						 m_nPriority(-1), 
						 m_nSortBy(TDC_SORTBYPRIORITY),
						 m_bSortAscending(-1),
						 m_nFileVersion(0),
						 m_bArchive(FALSE),
						 m_dTimeEstimate(0),
						 m_dTimeSpent(0),
						 m_eFileRef(FES_COMBOSTYLEBTN | FES_GOBUTTON),
						 m_nFileFormat(FILEFORMAT),
						 m_bModSinceLastSort(FALSE),
						 m_dwVisibleColumns(0),
						 m_nFontSize(-1),
						 m_crGridlines(OTC_GRIDCOLOR),
						 m_crTaskDone(RGB(192, 192, 192)),
						 m_bCheckedOut(FALSE),
						 m_hHandCursor(NULL),
						 m_nCommentsHeight(DEFCOMMENTHEIGHT),
						 m_bSplitting(FALSE),
						 m_data(m_tree, m_aStyles),
						 m_selection(m_tree),
						 m_wKeyPress(FALSE),
						 m_dwTimeTrackTaskID(0),
						 m_treeDragDrop(Selection(), m_tree),
						 m_htiLastAdded(NULL)
{
	SetBordersDLU(0);

	// note: do not use 'c' as a shortcut letter
	AddRCControl("LTEXT", "", "&Body", WS_NOTVISIBLE, 0, 0,0,0,0, IDC_STATIC);
	AddRCControl("CONTROL", "SysTreeView32", "", TVS_EDITLABELS | WS_TABSTOP | TVS_SHOWSELALWAYS | TVS_HASLINES/* | TVS_FULLROWSELECT*/, 0, 0,16,190,108, IDC_TASKLIST);
	AddRCControl("LTEXT", "", "Priorit&y", SS_CENTERIMAGE, 0, 119,131,22,8, IDC_PRIORITYLABEL);
	AddRCControl("COMBOBOX", "", "", CBS_DROPDOWNLIST | WS_VSCROLL | WS_TABSTOP | CBS_OWNERDRAWFIXED | CBS_HASSTRINGS, 0, 159,128,65,300, IDC_PRIORITY);
	AddRCControl("LTEXT", "", "% &Complete", SS_CENTERIMAGE, 0, 119,148,37,8, IDC_PERCENTLABEL);
	AddRCControl("EDITTEXT", "", "", WS_TABSTOP, 0, 159,146,65,13, IDC_PERCENT);
	AddRCControl("CONTROL", "msctls_updown32", "", UDS_SETBUDDYINT | UDS_ALIGNRIGHT | UDS_AUTOBUDDY | UDS_ARROWKEYS, 0, 97,180,13,14, IDC_PERCENTSPIN);
	AddRCControl("LTEXT", "", "T&ime Est.", SS_CENTERIMAGE, 0, 1,148,40,8, IDC_TIMEESTLABEL);
	AddRCControl("EDITTEXT", "", "", WS_TABSTOP, 0, 45,146,65,13, IDC_TIMEEST);
	AddRCControl("LTEXT", "", "T&ime Spent", SS_CENTERIMAGE, 0, 1,148,40,8, IDC_TIMESPENTLABEL);
	AddRCControl("EDITTEXT", "", "", WS_TABSTOP, 0, 45,146,65,13, IDC_TIMESPENT);
	AddRCControl("LTEXT", "", "St&art Date", SS_CENTERIMAGE, 0, 1,166,33,8, IDC_STARTLABEL);
	AddRCControl("CONTROL", "SysDateTimePick32", "", DTS_RIGHTALIGN | DTS_SHOWNONE | WS_TABSTOP, 0, 45,164,65,13, IDC_STARTDATE);
	AddRCControl("LTEXT", "", "D&ue Date", SS_CENTERIMAGE, 0, 119,166,32,8, IDC_DUELABEL);
	AddRCControl("CONTROL", "SysDateTimePick32", "", DTS_RIGHTALIGN | DTS_SHOWNONE | WS_TABSTOP, 0, 159,164,65,13, IDC_DUEDATE);
	AddRCControl("LTEXT", "", "Com&pleted", SS_CENTERIMAGE, 0, 1,184,34,8, IDC_DONELABEL);
	AddRCControl("CONTROL", "SysDateTimePick32", "", DTS_RIGHTALIGN | DTS_SHOWNONE | WS_TABSTOP, 0, 45,182,65,13, IDC_DONEDATE);
	AddRCControl("LTEXT", "", "A&llocated To", SS_CENTERIMAGE, 0, 1,131,38,8, IDC_ALLOCTOLABEL);
	AddRCControl("COMBOBOX", "", "", CBS_SORT | CBS_DROPDOWN | CBS_AUTOHSCROLL | WS_TABSTOP, 0, 45,128,65,200, IDC_ALLOCTO);
	AddRCControl("LTEXT", "", "A&llocated By", SS_CENTERIMAGE, 0, 1,131,38,8, IDC_ALLOCBYLABEL);
	AddRCControl("COMBOBOX", "", "", CBS_SORT | CBS_DROPDOWN | CBS_AUTOHSCROLL | WS_TABSTOP, 0, 45,128,65,200, IDC_ALLOCBY);
	AddRCControl("LTEXT", "", "Status", SS_CENTERIMAGE, 0, 1,131,38,8, IDC_STATUSLABEL);
	AddRCControl("COMBOBOX", "", "", CBS_SORT | CBS_DROPDOWN | CBS_AUTOHSCROLL | WS_TABSTOP, 0, 45,128,65,200, IDC_STATUS);
	AddRCControl("LTEXT", "", "Category", SS_CENTERIMAGE, 0, 1,131,38,8, IDC_CATEGORYLABEL);
	AddRCControl("COMBOBOX", "", "", CBS_SORT | CBS_DROPDOWN | CBS_AUTOHSCROLL | WS_TABSTOP, 0, 45,128,65,200, IDC_CATEGORY);
	AddRCControl("LTEXT", "", "File &Ref.", SS_CENTERIMAGE, 0, 119,184,37,8, IDC_FILEPATHLABEL);
	AddRCControl("EDITTEXT", "", "", ES_AUTOHSCROLL | ES_LEFT | WS_TABSTOP, 0, 159,182,65,13, IDC_FILEPATH);
	AddRCControl("LTEXT", "", "C&omments", 0, 0, 1,201,34,8, IDC_COMMENTSLABEL);
	AddRCControl("CONTROL", "RichEdit", "", ES_MULTILINE | ES_WANTRETURN | WS_VSCROLL | WS_TABSTOP, 0, 0,211,171,27, IDC_COMMENTS);
	AddRCControl("CONTROL", "static", "", SS_ETCHEDHORZ, WS_EX_TRANSPARENT, 35, 208, 187, 2, IDC_SPLITTER);
	AddRCControl("LTEXT", "", "Pro&ject", 0, 0, 1,3,28,8, IDC_PROJECTLABEL);
	AddRCControl("EDITTEXT", "", "", ES_AUTOHSCROLL | WS_TABSTOP, 0, 29,1,142,13, IDC_PROJECTNAME);

	// machine name
	DWORD LEN = MAX_COMPUTERNAME_LENGTH + 1;

	::GetComputerName(m_sMachineName.GetBuffer(LEN), &LEN);
	m_sMachineName.ReleaseBuffer();

    // init styles array
    // MFC sets all elements to zero
    m_aStyles.SetSize(TDCS_LAST);
	m_aStyles.SetAt(TDCS_RIGHTALIGNLABELS, 1);

	// set up number masks
	m_ePercentDone.SetMask("0123456789");

	// add chess clock button to 'time spent'
	m_eTimeSpent.InsertButton(0, ID_TIMEEDITBTN, "�", "Start/Stop Clock", 
								DEF_BTNWIDTH + 4, "Wingdings", TRUE);

	// add custom protocol to comments field for linking to task IDs
	m_reComments.AddProtocol(TDL_PROTOCOL, TRUE);
}

CToDoCtrl::~CToDoCtrl()
{
	if (m_hHandCursor)
		::DestroyCursor(m_hHandCursor);
}

void CToDoCtrl::DoDataExchange(CDataExchange* pDX)
{
	CRuntimeDlg::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_TASKLIST, m_tree);
	DDX_Text(pDX, IDC_PROJECTNAME, m_sProjectName);
	DDX_AutoCBString(pDX, IDC_ALLOCTO, m_sAllocTo);
	DDX_Control(pDX, IDC_ALLOCTO, m_cbAllocTo);
	DDX_AutoCBString(pDX, IDC_ALLOCBY, m_sAllocBy);
	DDX_Control(pDX, IDC_ALLOCBY, m_cbAllocBy);
	DDX_AutoCBString(pDX, IDC_STATUS, m_sStatus);
	DDX_Control(pDX, IDC_STATUS, m_cbStatus);
	DDX_AutoCBString(pDX, IDC_CATEGORY, m_sCategory);
	DDX_Control(pDX, IDC_CATEGORY, m_cbCategory);
	DDX_Text(pDX, IDC_TIMEEST, m_dTimeEstimate);
	DDX_Text(pDX, IDC_TIMESPENT, m_dTimeSpent);
	DDX_Control(pDX, IDC_TIMEEST, m_eTimeEstimate);
	DDX_Control(pDX, IDC_TIMESPENT, m_eTimeSpent);
	DDX_Control(pDX, IDC_DUEDATE, m_dateDue);
	DDX_Control(pDX, IDC_DONEDATE, m_dateDone);
	DDX_Control(pDX, IDC_STARTDATE, m_dateStart);
	DDX_Control(pDX, IDC_PRIORITY, m_cbPriority);
	DDX_Control(pDX, IDC_PERCENT, m_ePercentDone);
	DDX_Control(pDX, IDC_PERCENTSPIN, m_spinPercent);
	DDX_Control(pDX, IDC_FILEPATH, m_eFileRef);
	DDX_Text(pDX, IDC_FILEPATH, m_sFileRefPath);
	DDX_Control(pDX, IDC_COMMENTS, m_reComments);

	// custom
	if (pDX->m_bSaveAndValidate)
	{
		CString sPercent;
		GetDlgItem(IDC_PERCENT)->GetWindowText(sPercent);

		m_nPercentDone = max(0, atoi(sPercent));
		m_nPercentDone = min(100, m_nPercentDone);
		m_nPriority = m_cbPriority.GetCurSel();

		DDX_Text(pDX, IDC_COMMENTS, m_sComments);

		m_nTimeEstUnits = m_eTimeEstimate.GetUnits();
		m_nTimeSpentUnits = m_eTimeSpent.GetUnits();
	}
	else
	{
		m_spinPercent.SetPos(m_nPercentDone);
		m_cbPriority.SetCurSel(m_nPriority);

		// attempt to fix XP comments bug
		if (m_reComments.GetSafeHwnd())
			m_reComments.SendMessage(WM_SETTEXT, 0, (LPARAM)(LPCTSTR)m_sComments);

		m_eTimeEstimate.SetUnits(m_nTimeEstUnits);
		m_eTimeSpent.SetUnits(m_nTimeSpentUnits);
	}
}

BEGIN_MESSAGE_MAP(CToDoCtrl, CRuntimeDlg)
	//{{AFX_MSG_MAP(CToDoCtrl)
	//}}AFX_MSG_MAP
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_DESTROY()
	ON_WM_CONTEXTMENU()
	ON_WM_SETFOCUS()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_SETCURSOR()
	ON_WM_CAPTURECHANGED()
	ON_WM_SHOWWINDOW()
	ON_WM_TIMER()
	ON_NOTIFY(NM_SETFOCUS, IDC_TASKLIST, OnTreeChangeFocus)
	ON_NOTIFY(NM_KILLFOCUS, IDC_TASKLIST, OnTreeChangeFocus)
	ON_NOTIFY(NM_CLICK, IDC_TASKLIST, OnTreeClick)
	ON_NOTIFY(NM_DBLCLK, IDC_TASKLIST, OnTreeDblClk)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_TASKLIST, OnTreeCustomDraw)
	ON_NOTIFY(TVN_GETDISPINFO, IDC_TASKLIST, OnTreeGetDispInfo)
	ON_NOTIFY(TVN_KEYDOWN, IDC_TASKLIST, OnTreeKeyDown)
	ON_NOTIFY(TVN_ENDLABELEDIT, IDC_TASKLIST, OnTreeEndlabeledit)
	ON_NOTIFY(TVN_BEGINLABELEDIT, IDC_TASKLIST, OnTreeBeginlabeledit)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TASKLIST, OnTreeSelChanged)
	ON_NOTIFY(TVN_GETINFOTIP, IDC_TASKLIST, OnTreeGetInfoTip)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_DONEDATE, OnTaskDatechange)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_DUEDATE, OnTaskDatechange)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_STARTDATE, OnTaskDatechange)
	ON_CBN_SELCHANGE(IDC_PRIORITY, OnChangePriority)
	ON_EN_CHANGE(IDC_TIMEEST, OnChangeTimeEstimate)
	ON_EN_CHANGE(IDC_TIMESPENT, OnChangeTimeSpent)
	ON_EN_CHANGE(IDC_COMMENTS, OnChangeComments)
	ON_EN_CHANGE(IDC_PROJECTNAME, OnChangeProjectName)
	ON_REGISTERED_MESSAGE(WM_NCG_WANTREDRAW, OnGutterWantRedraw)
	ON_REGISTERED_MESSAGE(WM_NCG_DRAWITEM, OnGutterDrawItem)
	ON_REGISTERED_MESSAGE(WM_NCG_RECALCCOLWIDTH, OnGutterRecalcColWidth)
	ON_REGISTERED_MESSAGE(WM_NCG_NOTIFYHEADERCLICK, OnGutterNotifyHeaderClick)
	ON_REGISTERED_MESSAGE(WM_NCG_WIDTHCHANGE, OnGutterWidthChange)
	ON_REGISTERED_MESSAGE(WM_NCG_GETCURSOR, OnGutterGetCursor)
	ON_REGISTERED_MESSAGE(WM_NCG_NOTIFYITEMCLICK, OnGutterNotifyItemClick)
	ON_REGISTERED_MESSAGE(WM_NCG_ISITEMSELECTED, OnGutterIsItemSelected)
	ON_REGISTERED_MESSAGE(WM_NCG_GETSELECTEDCOUNT, OnGutterGetSelectedCount)
	ON_REGISTERED_MESSAGE(WM_EE_BTNCLICK, OnEEBtnClick)
	ON_CBN_EDITCHANGE(IDC_ALLOCTO, OnEditChangeAllocTo)
	ON_CBN_SELENDOK(IDC_ALLOCTO, OnSelChangeAllocTo)
	ON_CBN_EDITCHANGE(IDC_ALLOCBY, OnEditChangeAllocBy)
	ON_CBN_SELENDOK(IDC_ALLOCBY, OnSelChangeAllocBy)
	ON_CBN_EDITCHANGE(IDC_STATUS, OnEditChangeStatus)
	ON_CBN_SELENDOK(IDC_STATUS, OnSelChangeStatus)
	ON_CBN_EDITCHANGE(IDC_CATEGORY, OnEditChangeCategory)
	ON_CBN_SELENDOK(IDC_CATEGORY, OnSelChangeCategory)
	ON_EN_CHANGE(IDC_PERCENT, OnChangePercent)
	ON_EN_KILLFOCUS(IDC_PERCENT, OnKillFocusPercent)
	ON_EN_CHANGE(IDC_FILEPATH, OnChangeFileRefPath)
	ON_REGISTERED_MESSAGE(WM_FE_GETFILEICON, OnFileEditWantIcon)
	ON_REGISTERED_MESSAGE(WM_FE_DISPLAYFILE, OnFileEditDisplayFile)
	ON_REGISTERED_MESSAGE(WM_TLDT_DROPFILE, OnDropFileRef)
	ON_REGISTERED_MESSAGE(WM_TEN_UNITSCHANGE, OnTimeUnitsChange)
	ON_REGISTERED_MESSAGE(WM_UREN_CUSTOMURL, OnCustomUrl)
	ON_REGISTERED_MESSAGE(WM_DD_DRAGABORT, OnTreeDragDrop)
	ON_REGISTERED_MESSAGE(WM_DD_DRAGDROP, OnTreeDragDrop)
	ON_REGISTERED_MESSAGE(WM_DD_DRAGENTER, OnTreeDragDrop)
	ON_REGISTERED_MESSAGE(WM_DD_DRAGOVER, OnTreeDragDrop)
	ON_REGISTERED_MESSAGE(WM_DD_PREDRAGMOVE, OnTreeDragDrop)
	ON_COMMAND_RANGE(ID_COMMENTS_FIRST + 1, ID_COMMENTS_LAST - 1, OnCommentsMenuCmd)
	ON_UPDATE_COMMAND_UI_RANGE(ID_COMMENTS_FIRST + 1, ID_COMMENTS_LAST - 1, OnUpdateCommentsMenuCmd)
	ON_MESSAGE(WM_TDC_RESTOREFOCUSEDITEM, OnTreeRestoreFocusedItem)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CToDoCtrl message handlers

TDC_FILEFMT CToDoCtrl::CompareFileFormat()
{
    if (m_nFileFormat == FILEFORMAT)
        return TDCFF_SAME;

    else if (m_nFileFormat > FILEFORMAT)
        return TDCFF_NEWER;

    else
        return TDCFF_OLDER;
}

void CToDoCtrl::EnableEncryption(BOOL bEnable)
{
	if (!bEnable && !m_sPassword.IsEmpty())
	{
		m_sPassword.Empty();
		SetModified(TRUE, TDCA_NONE);
	}
	else if (bEnable && m_sPassword.IsEmpty())
	{
		if (CPasswordDialog::RetrievePassword(TRUE, m_sPassword))
			SetModified(TRUE, TDCA_NONE);
	}
}

BOOL CToDoCtrl::CanEncrypt()
{
	return CXmlFileEx::CanEncrypt();
}

BOOL CToDoCtrl::Create(const RECT& rect, CWnd* pParentWnd, UINT nID, BOOL bVisible)
{
	DWORD dwStyle = WS_CHILD | (bVisible ? WS_VISIBLE : 0);

	return CRuntimeDlg::Create(NULL, dwStyle, 0, rect, pParentWnd, nID);
}

BOOL CToDoCtrl::OnInitDialog() 
{
	CRuntimeDlg::OnInitDialog();

	// init priority combo
	BuildPriorityCombo();

	m_spinPercent.SetRange(0, 100);
	m_spinPercent.SetBuddy(GetDlgItem(IDC_PERCENT));

	UDACCEL uda = { 0, 5 };
	m_spinPercent.SetAccel(1, &uda);

	// extra gutter columns
	for (int nCol = 0; nCol < NUM_COLUMNS; nCol++)
	{
		TDCCOLUMN& tdcc = COLUMNS[nCol];

		if (tdcc.nColID != NCG_CLIENTCOLUMNID)
		{
			m_tree.AddGutterColumn(tdcc.nColID, tdcc.szName, 0, tdcc.nAlignment);

			if (tdcc.szFont)
				m_tree.SetGutterColumnHeaderTitle(tdcc.nColID, tdcc.szName, 
												  tdcc.szFont, tdcc.bSymbolFont);
		}
		else
			m_tree.SetGutterColumnHeaderTitle(tdcc.nColID, tdcc.szName);
	}

	UpdateColumnHeaderClicking();

	// init dates
	m_dateStart.SendMessage(DTM_SETSYSTEMTIME, GDT_NONE, 0);
	m_dateDue.SendMessage(DTM_SETSYSTEMTIME, GDT_NONE, 0);
	m_dateDone.SendMessage(DTM_SETSYSTEMTIME, GDT_NONE, 0);

	m_dtTree.Register(&m_tree, this);
	m_dtFileRef.Register(&m_eFileRef, this); 

	// custom font
	if (m_fontTree.GetSafeHandle())
	{
		m_tree.SetFont(&m_fontTree);
	
		if (HasStyle(TDCS_COMMENTSUSETREEFONT))
            m_reComments.SetFont(&m_fontTree);
	}

	// tree drag drop
	m_treeDragDrop.Initialize(this);

	EnableToolTips();

	// enabled states
	UpdateControls();
	SetLabelAlignment(HasStyle(TDCS_RIGHTALIGNLABELS) ? SS_RIGHT : SS_LEFT);
	m_tree.SetFocus();

	InitHandCursor();

	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CToDoCtrl::SetGridlineColor(COLORREF color)
{
	if (color != m_crGridlines)
	{
		m_crGridlines = color;
		m_tree.SetGridlineColor(color);
	}
}

void CToDoCtrl::SetTaskCompletedColor(COLORREF color)
{
	if (color != m_crTaskDone)
	{
		m_crTaskDone = color;

		if (m_tree.GetSafeHwnd())
			m_tree.Invalidate(FALSE);
	}
}

BOOL CToDoCtrl::SetTreeFont(LPCTSTR szFaceName, int nPoint)
{
	nPoint = min(24, max(6, nPoint));

	if (m_sFontName.CompareNoCase(szFaceName ? szFaceName : "") == 0)
	{
		if (m_sFontName.IsEmpty()) // both empty
			return TRUE; // no change

		else if (m_nFontSize == nPoint)
			return TRUE; // no change
	}

	m_fontDone.DeleteObject();
	m_fontTree.DeleteObject();

	CFont* pFont = CFont::FromHandle((HFONT)GetStockObject(DEFAULT_GUI_FONT));
						
	LOGFONT lf;
	pFont->GetLogFont(&lf);

	if (szFaceName && lstrlen(szFaceName))
	{
		// set the charset
		if (!lf.lfCharSet)
			lf.lfCharSet = DEFAULT_CHARSET;

		lstrcpy(lf.lfFaceName, szFaceName);

		HDC hDC = ::GetDC(NULL);
		lf.lfHeight = -MulDiv(abs(nPoint), GetDeviceCaps(hDC, LOGPIXELSY), 72);
		::ReleaseDC(NULL, hDC);

		lf.lfWidth = 0;

		m_fontTree.CreateFontIndirect(&lf); // check for failure later
	}
	
	lf.lfStrikeOut = TRUE;
		
	m_fontDone.CreateFontIndirect(&lf);

	if (m_fontTree.GetSafeHandle())
	{
		m_sFontName = szFaceName;
		m_nFontSize = nPoint;
		
		if (m_tree.GetSafeHwnd())
		{
			m_tree.SetFont(&m_fontTree);
			
			if (HasStyle(TDCS_COMMENTSUSETREEFONT))
				m_reComments.SetFont(&m_fontTree);
		}
	}
	else
	{
		m_sFontName.Empty();
		m_nFontSize = -1;
		
		if (m_tree.GetSafeHwnd())
		{
			m_tree.SendMessage(WM_SETFONT, NULL, TRUE);
			
			if (HasStyle(TDCS_COMMENTSUSETREEFONT))
				m_reComments.SetFont(GetFont());
		}
	}
	
	return TRUE;
}

TDCCOLUMN* CToDoCtrl::GetColumn(UINT nColID)
{
	int nCol = NUM_COLUMNS;

	while (nCol--)
	{
		if (COLUMNS[nCol].nColID == (TDC_COLUMN)nColID)
			return &COLUMNS[nCol];
	}

	// else
	return NULL;
}

TDCCOLUMN* CToDoCtrl::GetColumn(TDC_SORTBY nSortBy)
{
	int nCol = NUM_COLUMNS;

	while (nCol--)
	{
		if (COLUMNS[nCol].nSortBy == nSortBy)
			return &COLUMNS[nCol];
	}

	// else
	return NULL;
}

void CToDoCtrl::OnSize(UINT nType, int cx, int cy) 
{
	CRuntimeDlg::OnSize(nType, cx, cy);

	EndLabelEdit(TRUE);
	Resize(cx, cy);
}

void CToDoCtrl::Resize(int cx, int cy)
{
	if (m_tree.GetSafeHwnd())
	{
		if (!cx && !cy)
		{
			CRect rClient;
			GetClientRect(rClient);

			cx = rClient.right;
			cy = rClient.bottom;

			// check again 
			if (!cx && !cy)
				return;
		}

		// written to use DeferWindowPos()
		{
			CDeferWndMove dwm(30);
			
			CRect rTree = OffsetCtrl(IDC_TASKLIST); // just a get
			CRect rComments = OffsetCtrl(IDC_COMMENTS); // just a 'get'
			
			// validate comments height but don't change it
			int nCommentHeight = HasStyle(TDCS_SHAREDCOMMENTSHEIGHT) ? s_nCommentsHeight : m_nCommentsHeight;
			nCommentHeight = min(m_nCommentsHeight, cy - MINNONCOMMENTHEIGHT);
			
			// and determine 'general' Y offset
			int nXOffset = cx - rComments.right;
			int nYOffset = cy - rComments.top - nCommentHeight;
			
			rComments.top = cy - nCommentHeight;
			rComments.right = cx;
			rComments.bottom = cy;

			CRect rSplitter(rComments); // save this
			
			dwm.MoveWindow(GetDlgItem(IDC_COMMENTS), rComments);
			rComments = dwm.OffsetCtrl(this, IDC_COMMENTSLABEL, 0, nYOffset);

			// comments splitter
			rSplitter.left = rComments.right + 3;
			rSplitter.bottom = rSplitter.top + 2;
			rSplitter.right = cx;
			rSplitter.OffsetRect(0, -(SPLITHEIGHT + 2) / 2);
			dwm.MoveWindow(GetDlgItem(IDC_SPLITTER), rSplitter);
			
			// the edit controls are handled dynamically to reflect the
			// corresponding column visibility
			
			// first count up the visible controls
			// so we can allocate the correct amount of space
			BOOL bAllVisible = !HasStyle(TDCS_SHOWCTRLSASCOLUMNS);
			int nVisibleCtrls = VisibleCtrlCount();
			
			// for converting dlus to pixels
			CDlgUnits dlu(*this);
			
			int nCols = 2; // default
			
			if (HasStyle(TDCS_AUTOREPOSCTRLS))
			{
				int nCtrlWidth = dlu.ToPixelsX(CTRLENDOFFSET + CTRLHSPACING);
				nCols = max(2, (cx - dlu.ToPixelsX(1)) / nCtrlWidth);
			}
			int nRows = (nVisibleCtrls / nCols) + ((nVisibleCtrls % nCols) ? 1 : 0);
			
			CRect rItem(0, rComments.top - nRows * dlu.ToPixelsY(CTRLHEIGHT + CTRLVSPACING), 0, 0);
			rItem.bottom = rItem.top + dlu.ToPixelsY(CTRLHEIGHT);
			
			// resize tree now that we can calculate where its bottom is
			if (HasStyle(TDCS_SIMPLEMODE))
			{
				if (HasStyle(TDCS_SHOWCOMMENTSALWAYS))
					rTree.bottom = rComments.top - dlu.ToPixelsY(CTRLVSPACING);
				else
					rTree.bottom = cy;
			}
			else
				rTree.bottom = (rItem.top - dlu.ToPixelsY(CTRLVSPACING));

			rTree.right = cx;
			
			dwm.MoveWindow(GetDlgItem(IDC_TASKLIST), rTree);
			dwm.ResizeCtrl(this, IDC_PROJECTNAME, nXOffset, 0);
			
			// now iterate the visible controls settings their positions dynamically
			int nRow = 0, nCol = 0;
			
			for (int nCtrl = 0; nCtrl < NUM_CTRLITEMS; nCtrl++)
			{
				if (!bAllVisible && !IsColumnShowing(CTRLITEMS[nCtrl].nCol))
					continue;
				
				if (nCol >= nCols)
				{
					nCol = 0;
					rItem.OffsetRect(0, dlu.ToPixelsY(CTRLHEIGHT + CTRLVSPACING));
				}
				
				ReposControl(nCtrl, &dwm, &dlu, nCol, rItem.top, rItem.bottom, cx);
				
				nCol++;
			}
		}

		UpdateWindow();
	}
}

void CToDoCtrl::ReposControl(int nCtrl, CDeferWndMove* pDWM, const CDlgUnits* pDLU, int nCol, 
							 int nTop, int nBottom, int nClientRight)
{
	CRect rItem(0, nTop, 0, nBottom);

	rItem.left = pDLU->ToPixelsX(1 + nCol * (CTRLENDOFFSET + CTRLHSPACING));
	rItem.right = rItem.left + pDLU->ToPixelsX(CTRLENDOFFSET);
				
	// move label
	CRect rLabel(rItem);
	rLabel.right = rLabel.left + pDLU->ToPixelsX(CTRLSTARTOFFSET - CTRLHSPACING);
				
	pDWM->MoveWindow(GetDlgItem(CTRLITEMS[nCtrl].nLabelID), rLabel);
				
	// move control
	CRect rCtrl(rItem);
	rCtrl.left += pDLU->ToPixelsX(CTRLSTARTOFFSET);
				
	// some special cases
	switch (CTRLITEMS[nCtrl].nCtrlID)
	{
	case IDC_PERCENT:
		{
			CRect rSpin = pDWM->OffsetCtrl(this, IDC_PERCENTSPIN); // gets current pos
			rSpin.OffsetRect(rCtrl.right - rSpin.right, rCtrl.bottom - rSpin.bottom);
			rSpin.bottom = rSpin.top + pDLU->ToPixelsY(CTRLHEIGHT);
			pDWM->MoveWindow(&m_spinPercent, rSpin);
			
			rCtrl.right = rSpin.left + 2;
		}
		break;
		
	case IDC_FILEPATH:
		{
			// file path control can take as much space as is left
			rCtrl.right = nClientRight - pDLU->ToPixelsX(CTRLHSPACING);
		}
		break;
					
	case IDC_ALLOCTO:
	case IDC_ALLOCBY:
	case IDC_STATUS:
	case IDC_CATEGORY:
	case IDC_PRIORITY:
		rCtrl.bottom += 200; // combo box drop height
		break;
	}
				
	pDWM->MoveWindow(GetDlgItem(CTRLITEMS[nCtrl].nCtrlID), rCtrl);
}

int CToDoCtrl::VisibleCtrlCount()
{
	if (!HasStyle(TDCS_SHOWCTRLSASCOLUMNS))
		return NUM_CTRLITEMS;
	
	// else
	int nVisibleCtrls = 0;
			
	for (int nCtrl = 0; nCtrl < NUM_CTRLITEMS; nCtrl++)
	{
		if (IsColumnShowing(CTRLITEMS[nCtrl].nCol))
			nVisibleCtrls++;
	}

	return nVisibleCtrls;
}

int CToDoCtrl::GetMinWidth()
{
	int nMinWidth = CDlgUnits(*this).ToPixelsX(2 * (CTRLENDOFFSET + CTRLHSPACING));	

	if (m_tree.GetSafeHwnd())
	{
		int nWidth = m_tree.GetGutterWidth() + 20;
		nMinWidth = max(nWidth, nMinWidth);
	}

	return nMinWidth;
}

// wrapper for CTreeCtrl
BOOL CToDoCtrl::SetCheckImageList(CImageList* pImageList)
{
	m_hilDone = *pImageList;

	if (HasStyle(TDCS_TREECHECKBOXES))
		TreeView_SetImageList(m_tree, m_hilDone, TVSIL_STATE);

	return TRUE;
}

void CToDoCtrl::OnTreeSelChanged(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMTREEVIEW pNMTV = (LPNMTREEVIEW)pNMHDR;
	HTREEITEM hti = pNMTV->itemNew.hItem;
	HTREEITEM htiPrev = pNMTV->itemOld.hItem;

	BOOL bCtrl = (GetKeyState(VK_CONTROL) & 0x8000);
	BOOL bShift = (GetKeyState(VK_SHIFT) & 0x8000);
	
	// cursor handled here
	// <shift>+cursor handled here
	// <ctrl>+cursor handled in PreTranslateMessage
	// <ctrl>+<shift>+cursor handled in PreTranslateMessage
	if (m_wKeyPress)
	{
		switch (m_wKeyPress)
		{
		case VK_NEXT:  
		case VK_DOWN:
		case VK_UP:
		case VK_PRIOR: 
		case VK_RIGHT:
		case VK_LEFT:
		case VK_HOME:
		case VK_END:
			if (bShift && !bCtrl)
				Selection().AddItems(htiPrev, hti);
			
			else if (!bCtrl)
			{
				Selection().RemoveAll();
				Selection().AddItem(hti);
			}

			// cache the last singly selected item
			if (GetSelectedCount() == 1)
				m_selection.htiLastSingleSelection = hti;
			else
				m_selection.htiLastSingleSelection = NULL;

			break;
		}

		m_wKeyPress = 0;
	}

	UpdateControls(); // load newly selected item
	UpdateSelectedTaskPath();

	*pResult = 0;
}

void CToDoCtrl::UpdateSelectedTaskPath()
{
	// add the item path to the header
	if (HasStyle(TDCS_SHOWPATHINHEADER))
	{
		CString sHeader("Task");

		if (GetSelectedCount() == 1)
		{
			CString sPath = GetItemPath(GetSelectedItem(), 20);

			if (!sPath.IsEmpty())
				sHeader.Format("Task (%s)", sPath);
		}
		
		m_tree.SetGutterColumnHeaderTitle(NCG_CLIENTCOLUMNID, sHeader);
	}
}

void CToDoCtrl::UpdateControls()
{
	HTREEITEM hti = GetSelectedItem();
	int nSelCount = GetSelectedCount();

	BOOL bSimpleMode = HasStyle(TDCS_SIMPLEMODE);
	BOOL bEnable = (hti && !bSimpleMode);
	BOOL bIsParent = (hti && m_tree.ItemHasChildren(hti));
	BOOL bAveSubTaskCompletion = HasStyle(TDCS_AVERAGEPERCENTSUBCOMPLETION) && bIsParent;

	BOOL bShowCtrlsAsCols = HasStyle(TDCS_SHOWCTRLSASCOLUMNS);
	BOOL bReadOnly = IsReadOnly();

	BOOL bEditTime = (nSelCount > 1 || !bIsParent);
	BOOL bEditDue = (nSelCount > 1 || !(HasStyle(TDCS_USEEARLIESTDUEDATE) && bIsParent));
	BOOL bEditPriority = (nSelCount > 1 || !(HasStyle(TDCS_USEHIGHESTPRIORITY) && bIsParent));
	BOOL bIsClocking = m_data.IsTaskTimeTrackable(hti) && (GetSelectedTaskID() == m_dwTimeTrackTaskID);
	BOOL bEditPercent = !HasStyle(TDCS_AUTOCALCPERCENTDONE) && (nSelCount > 1 || !bAveSubTaskCompletion);

	if (hti)
	{
		m_sComments = GetSelectedTaskComments();
		m_nPriority = (int)GetSelectedTaskPriority();
		m_sAllocTo = GetSelectedTaskAllocTo();
		m_sAllocBy = GetSelectedTaskAllocBy();
		m_sStatus = GetSelectedTaskStatus();
		m_sCategory = GetSelectedTaskCategory();
		m_sFileRefPath = GetSelectedTaskFileRef();

		// special cases
		if (bEditTime)
		{
			m_dTimeEstimate = GetSelectedTaskTimeEstimate(m_nTimeEstUnits);
			m_dTimeSpent = GetSelectedTaskTimeSpent(m_nTimeSpentUnits);
		}
		else
		{
			m_nTimeEstUnits = m_nTimeSpentUnits = s_tdDefault.nTimeEstUnits;
			m_dTimeEstimate = m_data.CalcTimeEstimate(hti, m_nTimeEstUnits);
			m_dTimeSpent = m_data.CalcTimeSpent(hti, m_nTimeEstUnits);
		}

		// chess clock for time spent
		DWORD dwSelTaskID = GetSelectedTaskID();

		if (dwSelTaskID == m_dwTimeTrackTaskID)
		{
			SetTimer(TIMER_TRACK, TIMETRACKPERIOD, NULL);
			m_eTimeSpent.CheckButton(ID_TIMEEDITBTN, TRUE);
		}
		else if (HasStyle(TDCS_TRACKSELECTEDTASKONLY))
		{
			KillTimer(TIMER_TRACK);
			m_eTimeSpent.CheckButton(ID_TIMEEDITBTN, FALSE);
		}
		else
			m_eTimeSpent.CheckButton(ID_TIMEEDITBTN, FALSE);

		m_eTimeSpent.EnableButton(ID_TIMEEDITBTN, bEditTime && bEnable && !bReadOnly && 
												  m_data.IsTaskTimeTrackable(hti));
		// percent done
		if (IsSelectedTaskDone())
			m_nPercentDone = 100;

		else if (bEditPercent)
			m_nPercentDone = GetSelectedTaskPercent(FALSE);
		else
			m_nPercentDone = m_data.CalcPercentDone(hti);		

		// date controls need special handling too
		COleDateTime date = GetSelectedTaskDoneDate();

		if (date.m_dt)
			m_dateDone.SetTime(date);
		else
			m_dateDone.SendMessage(DTM_SETSYSTEMTIME, GDT_NONE, 0);

		if (bEditDue)
			date = GetSelectedTaskDueDate();
		else
			date = m_data.GetEarliestDueDate(hti);

		if (date.m_dt)
			m_dateDue.SetTime(date);
		else
			m_dateDue.SendMessage(DTM_SETSYSTEMTIME, GDT_NONE, 0);

		date = GetSelectedTaskStartDate();

		if (date.m_dt)
			m_dateStart.SetTime(date);
		else
			m_dateStart.SendMessage(DTM_SETSYSTEMTIME, GDT_NONE, 0);

		UpdateData(FALSE);
	}

	// now enable/disable appropriate controls
	for (int nCtrl = 0; nCtrl < NUM_CTRLITEMS; nCtrl++)
	{
		CWnd* pCtrl = GetDlgItem(CTRLITEMS[nCtrl].nCtrlID);
		CWnd* pLabel = GetDlgItem(CTRLITEMS[nCtrl].nLabelID);

		if (!pCtrl || !pLabel)
			continue;
		
		BOOL bCtrlShowing = !bSimpleMode && (!bShowCtrlsAsCols || IsColumnShowing(CTRLITEMS[nCtrl].nCol));
		int nShowCtrl = bCtrlShowing ? SW_SHOW : SW_HIDE;

		// control state
		RT_CTRLSTATE nState = (!bEnable || !bCtrlShowing) ? RTCS_DISABLED : 
								(bReadOnly ? RTCS_READONLY : RTCS_ENABLED);
		
		// some additions and modifications
		switch (CTRLITEMS[nCtrl].nCtrlID)
		{
		case IDC_PERCENT:
			if (!bEditPercent && bEnable)
				nState = RTCS_READONLY;

			m_spinPercent.ShowWindow(nShowCtrl);
			SetControlState(m_spinPercent, nState);
			break;
			
		case IDC_TIMEEST:
			if (!bEditTime && bEnable)
				nState = RTCS_READONLY;
			break;

		case IDC_TIMESPENT:
			if ((!bEditTime || bIsClocking) && bEnable)
				nState = RTCS_READONLY;
			break;

		case IDC_DUEDATE:
			if (!bEditDue && bEnable)
				nState = RTCS_READONLY;
			break;
		}
		
		pCtrl->ShowWindow(nShowCtrl);
		pLabel->ShowWindow(nShowCtrl);
		
		SetControlState(*pLabel, nState);
		SetControlState(*pCtrl, nState);
	}
	
	// comments
	BOOL bCommentsAlways = HasStyle(TDCS_SHOWCOMMENTSALWAYS);
	RT_CTRLSTATE nState = ((!bCommentsAlways && bSimpleMode) || !hti) ? RTCS_DISABLED : 
							(bReadOnly ? RTCS_READONLY : RTCS_ENABLED);
	
	SetControlState(this, IDC_COMMENTSLABEL, nState);
	SetControlState(this, IDC_COMMENTS, nState);
	ShowControls(IDC_COMMENTSLABEL, IDC_COMMENTS, (bCommentsAlways || !bSimpleMode));
	
	// project name
	nState = bReadOnly ? RTCS_READONLY : RTCS_ENABLED;
	SetControlState(this, IDC_PROJECTLABEL, nState);
	SetControlState(this, IDC_PROJECTNAME, nState);

	// tree
	m_tree.ModifyStyle(bReadOnly ? TVS_EDITLABELS : 0, bReadOnly ? 0 : TVS_EDITLABELS);
	m_treeDragDrop.EnableDragDrop(!bReadOnly);
}

void CToDoCtrl::SetLabelAlignment(int nStyle)
{
	// now enable/disable appropriate controls
	for (int nCtrl = 0; nCtrl < NUM_CTRLITEMS; nCtrl++)
	{
		CWnd* pLabel = GetDlgItem(CTRLITEMS[nCtrl].nLabelID);

		if (!pLabel)
			continue;
		
		pLabel->ModifyStyle(SS_TYPEMASK, nStyle);
	}
}

void CToDoCtrl::UpdateTask(TDC_ATTRIBUTE nAttrib)
{
	if (!m_tree.GetSafeHwnd())
		return;

	HTREEITEM hti = GetSelectedItem();

	if (!hti)
		return;

	// else
	UpdateData();

	switch (nAttrib)
	{
//	case TDCA_TASKNAME:
//		break;

	case TDCA_DONEDATE:
		{
			COleDateTime date;
			m_dateDone.GetTime(date);

			SetSelectedTaskDoneDate(date);

			// check if we need to modify percent done also
			if (!IsSelectedTaskDone())
			{
				int nPercentDone = GetSelectedTaskPercent(FALSE);

				if (nPercentDone == 100)
					nPercentDone = 0;

				SetSelectedTaskPercentDone(nPercentDone);
				m_nPercentDone = nPercentDone;

				UpdateData(FALSE);
			}
			else if (m_nPercentDone != 100) // make the percent field look right
			{
				m_nPercentDone = 100;
				UpdateData(FALSE);
			}
		}
		break;

	case TDCA_STARTDATE:
		{
			COleDateTime date;
			m_dateStart.GetTime(date);
	
			SetSelectedTaskStartDate(date);
			RecalcSelectedTimeEstimate();
		}
		break;

	case TDCA_DUEDATE:
		{
			COleDateTime date;
			m_dateDue.GetTime(date);
		
			SetSelectedTaskDueDate(date);
			RecalcSelectedTimeEstimate();
		}
		break;

	case TDCA_PRIORITY:
		SetSelectedTaskPriority(m_nPriority);
		break;

//	case TDCA_COLOR:
//		break;

	case TDCA_ALLOCTO:
		SetSelectedTaskAllocTo(m_sAllocTo);
		break;

	case TDCA_ALLOCBY:
		SetSelectedTaskAllocBy(m_sAllocBy);
		break;

	case TDCA_STATUS:
		SetSelectedTaskStatus(m_sStatus);
		break;

	case TDCA_CATEGORY:
		SetSelectedTaskCategory(m_sCategory);
		break;

	case TDCA_PERCENT:
		{
			// note: we need to take account of 'done' state too because
			// we maintain the task percent at its pre-done state even
			// if the UI says its '100%'
			BOOL bWasDone = IsSelectedTaskDone();
			int nPrevPercent = GetSelectedTaskPercent(FALSE);
			SetSelectedTaskPercentDone(m_nPercentDone);

			// check if we need to update 'done' state
			BOOL bDoneChange = (bWasDone && m_nPercentDone < 100) || (!bWasDone && m_nPercentDone == 100);

			if (bDoneChange)
			{
				SetSelectedTaskDone(m_nPercentDone == 100, FALSE);
				nAttrib = TDCA_DONEDATE;
			}
		}
		break;

	case TDCA_TIMEEST:
		SetSelectedTaskTimeEstimate(m_dTimeEstimate, m_nTimeEstUnits);
		break;

	case TDCA_TIMESPENT:
		SetSelectedTaskTimeSpent(m_dTimeSpent, m_nTimeSpentUnits);
		break;

	case TDCA_FILEREF:
		SetSelectedTaskFileRef(m_sFileRefPath);
		break;

	case TDCA_COMMENTS:
		SetSelectedTaskComments(m_sComments);
		break;

	default:
		return;
	}

	// query apply to subtasks?
/*	if (HasStyle(TDCS_QUERYAPPLYCHANGESTOSUBTASKS) && m_tree.ItemHasChildren(hti) && nAttrib != TDCA_COMMENTS)
	{
		if (MessageBox("Would you like to apply this attribute change to subtasks too?", 
						"Apply to Subtasks", MB_YESNO | MB_DEFBUTTON2) == IDYES)
		{
			TODOITEM tdi;

			if (GetTask(GetTaskID(hti), tdi))
			{
				ApplyLastChangeToSubtasks(hti, tdi, nAttrib);

				m_tree.Invalidate(FALSE);
				m_tree.RedrawGutter();
			}
		}
	}
*/
}

void CToDoCtrl::RecalcSelectedTimeEstimate()
{
	if (HasStyle(TDCS_AUTOCALCTIMEESTIMATES))
	{
		TODOITEM tdi;
		VERIFY(GetSelectedTask(tdi));
		
		double dStart = tdi.dateStart, dDue = tdi.dateDue;
		
		if (dStart > 0 && dDue > dStart) // exists
		{
			int nWeekdays = CDateHelper::CalcWeekdaysFromTo(dStart, dDue, TRUE);
			SetSelectedTaskTimeEstimate((double)nWeekdays, TDCTU_DAYS);
		}
		else
			SetSelectedTaskTimeEstimate(0);
	}
}

void CToDoCtrl::OnChangePriority()
{
	UpdateTask(TDCA_PRIORITY);
}

void CToDoCtrl::OnTaskDatechange(NMHDR* pNMHDR, LRESULT* pResult)
{
	switch (pNMHDR->idFrom)
	{
	case IDC_DONEDATE:	UpdateTask(TDCA_DONEDATE);	break;
	case IDC_STARTDATE:	UpdateTask(TDCA_STARTDATE); break;
	case IDC_DUEDATE:	UpdateTask(TDCA_DUEDATE); 	break;
	}

	*pResult = 0;
}

BOOL CToDoCtrl::OnEraseBkgnd(CDC* pDC) 
{
	int nDC = pDC->SaveDC();

	// clip out all the child controls to reduce flicker
	if (!(GetStyle() & WS_CLIPCHILDREN))
	{
		if (m_tree.GetSafeHwnd())
			ExcludeControls(pDC, IDC_FIRST + 1, IDC_LAST - 1);
	}

	BOOL bRes = CRuntimeDlg::OnEraseBkgnd(pDC);

	pDC->RestoreDC(nDC);

	return bRes;
}

void CToDoCtrl::NewList()
{
	BOOL bConfirmDelete = HasStyle(TDCS_CONFIRMDELETE);

	if (bConfirmDelete)
		SetStyle(TDCS_CONFIRMDELETE, FALSE);

	DeleteAllTasks();

	if (bConfirmDelete)
		SetStyle(TDCS_CONFIRMDELETE, TRUE);

	m_sProjectName.Empty();
	m_nFileVersion = 0;
	m_bModified = FALSE;
	m_sPassword.Empty();

	UpdateData(FALSE);
}

BOOL CToDoCtrl::SetSelectedTaskColor(COLORREF color)
{
	if (IsReadOnly())
		return FALSE;

	POSITION pos = Selection().GetFirstItemPos();
	int nRes = SET_NOCHANGE;

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);
		int nItemRes = m_data.SetTaskColor(GetTaskID(hti), color);

		if (nItemRes == SET_CHANGE)
			nRes = SET_CHANGE;
	}

	if (nRes == SET_CHANGE)
	{
		InvalidateSelectedItem();

		UpdateTask(TDCA_COLOR);
		SetModified(TRUE, TDCA_COLOR);
	}

	return (nRes != SET_FAILED);
}

BOOL CToDoCtrl::SetSelectedTaskComments(LPCTSTR szComments)
{
	if (IsReadOnly())
		return FALSE;

	POSITION pos = Selection().GetFirstItemPos();
	int nRes = SET_NOCHANGE;

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);
		int nItemRes = m_data.SetTaskComments(GetTaskID(hti), szComments);

		if (nItemRes == SET_CHANGE)
			nRes = SET_CHANGE;
	}

	if (nRes == SET_CHANGE)
		Selection().InvalidateAll();

	return SetTextChange(nRes, m_sComments, szComments, TDCA_COMMENTS, IDC_COMMENTS);
}

BOOL CToDoCtrl::SetSelectedTaskTitle(LPCTSTR szTitle)
{
	if (IsReadOnly() || GetSelectedCount() != 1)
		return FALSE;

	int nRes = m_data.SetTaskTitle(GetSelectedTaskID(), szTitle);

	if (nRes == SET_CHANGE)
	{
		m_tree.SetItemText(GetSelectedItem(), szTitle);

		InvalidateSelectedItem();
		SetModified(TRUE, TDCA_TASKNAME);
	}

	return (nRes != SET_FAILED);
}

CString CToDoCtrl::GetSelectedTaskComments() const
{
	if (GetSelectedCount() == 1)
		return m_data.GetTaskComments(GetSelectedTaskID());

	// else
	return "";
}

HTREEITEM CToDoCtrl::GetSelectedItem() const 
{ 
	if (m_tree.GetSafeHwnd())
		return Selection().GetFirstItem();
	
	// else
	return NULL;
}

CString CToDoCtrl::GetSelectedTaskTitle() const
{
	if (GetSelectedCount() == 1)
		return GetItemText(GetSelectedItem());

	// else
	return "";
}

int CToDoCtrl::GetSelectedTaskPriority() const
{
	if (GetSelectedCount() == 1)
		return m_data.GetTaskPriority(GetSelectedTaskID());
	
	// else
	return s_tdDefault.nPriority;
}

double CToDoCtrl::GetSelectedTaskTimeEstimate(int& nUnits) const
{
	if (GetSelectedCount() == 1)
		return m_data.GetTaskTimeEstimate(GetSelectedTaskID(), nUnits);

	// else
	nUnits = s_tdDefault.nTimeEstUnits;
	return 0;
}

double CToDoCtrl::GetSelectedTaskTimeSpent(int& nUnits) const
{
	if (GetSelectedCount() == 1)
		return m_data.GetTaskTimeSpent(GetSelectedTaskID(), nUnits);

	// else
	return 0;
}

BOOL CToDoCtrl::SetSelectedTaskPriority(int nPriority)
{
	if (IsReadOnly())
		return FALSE;

	POSITION pos = Selection().GetFirstItemPos();
	int nRes = SET_FAILED;

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);
		int nItemRes = m_data.SetTaskPriority(GetTaskID(hti), nPriority);

		if (nItemRes == SET_CHANGE)
			nRes = SET_CHANGE;
	}
	
	if (nRes == SET_CHANGE)
	{
		if (m_nPriority != nPriority)
		{
			m_nPriority = nPriority;
			UpdateDataEx(this, IDC_PRIORITY, m_nPriority, FALSE);
		}
		
		SetModified(TRUE, TDCA_PRIORITY);
	}

	return (nRes != SET_FAILED);
}

COleDateTime CToDoCtrl::GetSelectedTaskDueDate() const
{
	if (GetSelectedCount() == 1)
		return m_data.GetTaskDueDate(GetSelectedTaskID());

	// else
	return 0.0;
}

COleDateTime CToDoCtrl::GetSelectedTaskStartDate() const
{
	if (GetSelectedCount() == 1)
		return m_data.GetTaskStartDate(GetSelectedTaskID());

	// else
	return 0.0;
}

COleDateTime CToDoCtrl::GetSelectedTaskDoneDate() const
{
	if (GetSelectedCount() == 1)
		return m_data.GetTaskDoneDate(GetSelectedTaskID());

	// else
	return 0.0;
}

BOOL CToDoCtrl::SetSelectedTaskStartDate(const COleDateTime& date)
{
	if (IsReadOnly())
		return FALSE;

	POSITION pos = Selection().GetFirstItemPos();
	int nRes = SET_NOCHANGE;
	BOOL bSomeDue = FALSE;

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);
		int nItemRes = m_data.SetTaskStartDate(GetTaskID(hti), date);

		if (nItemRes == SET_CHANGE)
			nRes = SET_CHANGE;
	}

	if (nRes == SET_CHANGE)
		SetModified(TRUE, TDCA_STARTDATE);

	return (nRes != SET_FAILED);
}

BOOL CToDoCtrl::SetSelectedTaskDoneDate(const COleDateTime& date)
{
	if (IsReadOnly())
		return FALSE;

	POSITION pos = Selection().GetFirstItemPos();
	int nRes = SET_NOCHANGE;
	BOOL bSomeDue = FALSE;

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);
		int nItemRes = m_data.SetTaskDoneDate(GetTaskID(hti), date);

		if (nItemRes == SET_CHANGE)
		{
			SetItemChecked(hti, (date.m_dt > 0));
			nRes = SET_CHANGE;
		}
	}

	if (nRes == SET_CHANGE)
		SetModified(TRUE, TDCA_DONEDATE);

	return (nRes != SET_FAILED);
}

BOOL CToDoCtrl::SetSelectedTaskDueDate(const COleDateTime& date)
{
	if (IsReadOnly())
		return FALSE;

	POSITION pos = Selection().GetFirstItemPos();
	int nRes = SET_NOCHANGE;
	BOOL bSomeDue = FALSE;

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);
		int nItemRes = m_data.SetTaskDueDate(GetTaskID(hti), date);

		bSomeDue |= m_data.IsTaskDue(GetSelectedItem());

		if (nItemRes == SET_CHANGE)
			nRes = SET_CHANGE;
	}

	if (nRes == SET_CHANGE)
	{
		if (bSomeDue)
			m_tree.RedrawGutter();

		SetModified(TRUE, TDCA_DUEDATE);
	}

	return (nRes != SET_FAILED);
}

BOOL CToDoCtrl::SetSelectedTaskAttributeAsParent(TDC_ATTRIBUTE nAttrib)
{
	return m_data.SetTaskAttributeAsParent(GetSelectedItem(), nAttrib);
}

COLORREF CToDoCtrl::GetSelectedTaskColor() const
{
	return m_data.GetTaskColor(GetSelectedItem());
}

BOOL CToDoCtrl::SetSelectedTaskDone(BOOL bDone)
{
	return SetSelectedTaskDone(bDone, TRUE);
}

BOOL CToDoCtrl::SetSelectedTaskDone(BOOL bDone, BOOL bUpdatePercent)
{
	if (IsReadOnly())
		return FALSE;

	int nPrevPercent = 0;

	POSITION pos = Selection().GetFirstItemPos();
	int nRes = SET_NOCHANGE;

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);
		int nItemRes = m_data.SetTaskDone(GetTaskID(hti), bDone, nPrevPercent);

		SetItemChecked(hti, bDone);

		if (nItemRes == SET_CHANGE)
			nRes = SET_CHANGE;
	}

	if (nRes == SET_CHANGE)
	{
		if (bUpdatePercent)
		{
			if (GetSelectedCount() == 1)
			{
				if (!bDone)
				{
					// restore last known percentage unless is 100%
					if (nPrevPercent == 100)
						nPrevPercent = 0;

					m_nPercentDone = nPrevPercent;
					UpdateDataEx(this, IDC_PERCENT, m_nPercentDone, FALSE);
				}
				else if (m_nPercentDone != 100) // make it look right
				{
					m_nPercentDone = 100;
					UpdateDataEx(this, IDC_PERCENT, m_nPercentDone, FALSE);
				}
			}
			else
			{
				m_nPercentDone = bDone ? 100 : 0;
				UpdateDataEx(this, IDC_PERCENT, m_nPercentDone, FALSE);
			}
		}

		UpdateControls();
		m_tree.UpdateWindow();

		SetModified(TRUE, TDCA_DONEDATE);
	}

	return (nRes != SET_FAILED);
}

BOOL CToDoCtrl::IsSelectedTaskDone() const
{
	return IsTaskDone(GetSelectedItem());
}

BOOL CToDoCtrl::IsTaskDone(HTREEITEM hti, DWORD dwExtraCheck) const
{
	return m_data.IsTaskDone(hti, dwExtraCheck);
}

BOOL CToDoCtrl::IsSelectedTaskDue() const
{
	return m_data.IsTaskDue(GetSelectedItem());
}

BOOL CToDoCtrl::SetSelectedTaskPercentDone(int nPercent)
{
	if (IsReadOnly())
		return FALSE;

	POSITION pos = Selection().GetFirstItemPos();
	int nRes = SET_NOCHANGE;

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);
		int nItemRes = m_data.SetTaskPercent(GetTaskID(hti), nPercent);

		if (nItemRes == SET_CHANGE)
			nRes = SET_CHANGE;
	}

	if (nRes == SET_CHANGE)
	{
		if (m_nPercentDone != nPercent)
		{
			m_nPercentDone = nPercent;
			UpdateDataEx(this, IDC_PERCENT, m_nPercentDone, FALSE);
		}

		SetModified(TRUE, TDCA_PERCENT);
	}

	return (nRes != SET_FAILED);
}

BOOL CToDoCtrl::SetSelectedTaskTimeEstimate(const double& dHours, int nUnits)
{
	if (IsReadOnly())
		return FALSE;

	POSITION pos = Selection().GetFirstItemPos();
	int nRes = SET_NOCHANGE;

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);
		int nItemRes = m_data.SetTaskTimeEstimate(GetTaskID(hti), dHours, nUnits);

		if (nItemRes == SET_CHANGE)
			nRes = SET_CHANGE;
	}

	if (nRes == SET_CHANGE)
	{
		if (m_dTimeEstimate != dHours || m_nTimeEstUnits != nUnits)
		{
			m_dTimeEstimate = dHours;
			m_nTimeEstUnits = nUnits;

			UpdateDataEx(this, IDC_TIMEEST, m_dTimeEstimate, FALSE);
			m_eTimeEstimate.SetUnits(m_nTimeEstUnits);
		}
		
		// update % complete?
		if (HasStyle(TDCS_AUTOCALCPERCENTDONE) && GetSelectedCount() == 1)
		{
			m_nPercentDone = m_data.CalcPercentDone(GetSelectedItem());		
			UpdateDataEx(this, IDC_PERCENT, m_nPercentDone, FALSE);
		}
		
		SetModified(TRUE, TDCA_TIMEEST);
	}

	return (nRes != SET_FAILED);
}

BOOL CToDoCtrl::SetSelectedTaskTimeSpent(const double& dHours, int nUnits)
{
	if (IsReadOnly())
		return FALSE;

	POSITION pos = Selection().GetFirstItemPos();
	int nRes = SET_NOCHANGE;

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);
		int nItemRes = m_data.SetTaskTimeSpent(GetTaskID(hti), dHours, nUnits);

		if (nItemRes == SET_CHANGE)
			nRes = SET_CHANGE;
	}
	
	if (nRes == SET_CHANGE)
	{
		if (m_dTimeSpent != dHours || m_nTimeSpentUnits != nUnits)
		{
			m_dTimeSpent = dHours;
			m_nTimeSpentUnits = nUnits;

			UpdateDataEx(this, IDC_TIMESPENT, m_dTimeSpent, FALSE);
			m_eTimeSpent.SetUnits(m_nTimeSpentUnits);
		}
		
		// update % complete?
		if (HasStyle(TDCS_AUTOCALCPERCENTDONE) && GetSelectedCount() == 1)
		{
			m_nPercentDone = m_data.CalcPercentDone(GetSelectedItem());		
			UpdateDataEx(this, IDC_PERCENT, m_nPercentDone, FALSE);
		}
		
		SetModified(TRUE, TDCA_TIMESPENT);
	}

	return (nRes != SET_FAILED);
}

int CToDoCtrl::GetSelectedTaskPercentDone() const
{
	if (GetSelectedCount() == 1)
		return GetSelectedTaskPercent(TRUE);

	// else
	return 0;
}

int CToDoCtrl::GetSelectedTaskPercent(BOOL bCheckIfDone) const
{
	if (GetSelectedCount() == 1)
		return m_data.GetTaskPercent(GetSelectedTaskID(), bCheckIfDone);

	// else
	return 0;
}

BOOL CToDoCtrl::SetTextChange(int nChange, CString& sItem, LPCTSTR szNewItem, TDC_ATTRIBUTE nAttrib, UINT nIDC)
{
	ASSERT(!IsReadOnly());

	if (nChange == SET_CHANGE)
	{
		if (sItem != szNewItem)
		{
			sItem = szNewItem;
			UpdateDataEx(this, nIDC, sItem, FALSE);
		}
		
		SetModified(TRUE, nAttrib);
	}

	return (nChange != SET_FAILED);
}

BOOL CToDoCtrl::SetSelectedTaskAllocTo(LPCTSTR szAllocTo)
{
	if (IsReadOnly())
		return FALSE;

	POSITION pos = Selection().GetFirstItemPos();
	int nRes = SET_NOCHANGE;

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);
		int nItemRes = m_data.SetTaskAllocTo(GetTaskID(hti), szAllocTo);

		if (nItemRes == SET_CHANGE)
			nRes = SET_CHANGE;
	}

	return SetTextChange(nRes, m_sAllocTo, szAllocTo, TDCA_ALLOCTO, IDC_ALLOCTO);
}

BOOL CToDoCtrl::SetSelectedTaskAllocBy(LPCTSTR szAllocBy)
{
	if (IsReadOnly())
		return FALSE;

	POSITION pos = Selection().GetFirstItemPos();
	int nRes = SET_NOCHANGE;

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);
		int nItemRes = m_data.SetTaskAllocBy(GetTaskID(hti), szAllocBy);

		if (nItemRes == SET_CHANGE)
			nRes = SET_CHANGE;
	}

	return SetTextChange(nRes, m_sAllocBy, szAllocBy, TDCA_ALLOCBY, IDC_ALLOCBY);
}

BOOL CToDoCtrl::SetSelectedTaskStatus(LPCTSTR szStatus)
{
	if (IsReadOnly())
		return FALSE;

	POSITION pos = Selection().GetFirstItemPos();
	int nRes = SET_NOCHANGE;

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);
		int nItemRes = m_data.SetTaskStatus(GetTaskID(hti), szStatus);

		if (nItemRes == SET_CHANGE)
			nRes = SET_CHANGE;
	}

	return SetTextChange(nRes, m_sStatus, szStatus, TDCA_STATUS, IDC_STATUS);
}

BOOL CToDoCtrl::SetSelectedTaskCategory(LPCTSTR szCategory)
{
	if (IsReadOnly())
		return FALSE;

	POSITION pos = Selection().GetFirstItemPos();
	int nRes = SET_NOCHANGE;

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);
		int nItemRes = m_data.SetTaskCategory(GetTaskID(hti), szCategory);

		if (nItemRes == SET_CHANGE)
			nRes = SET_CHANGE;
	}

	return SetTextChange(nRes, m_sCategory, szCategory, TDCA_CATEGORY, IDC_CATEGORY);
}

BOOL CToDoCtrl::TimeTrackSelectedTask(BOOL bBegin)
{
	if (!CanTimeTrackSelectedTask())
		return FALSE;

	DWORD dwSelTaskID = GetSelectedTaskID();

	if (bBegin)
	{
		m_dwTimeTrackTaskID = dwSelTaskID;
		UpdateControls();
		return TRUE;
	}
	else if (m_dwTimeTrackTaskID = dwSelTaskID)
	{
		m_dwTimeTrackTaskID = 0;
		UpdateControls();
		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::CanTimeTrackSelectedTask()
{
	if (IsReadOnly() || GetSelectedCount() != 1)
		return FALSE;

	return (m_data.IsTaskTimeTrackable(GetSelectedItem()));
}

BOOL CToDoCtrl::IsSelectedTaskBeingTimeTracked()
{
	HTREEITEM hti = GetSelectedItem();

	return (m_data.IsTaskTimeTrackable(hti) && m_dwTimeTrackTaskID == GetTaskID(hti));
}

CString CToDoCtrl::GetSelectedTaskAllocTo() const
{
	if (GetSelectedCount() == 1)
		return m_data.GetTaskAllocTo(GetSelectedItem());

	// else
	return "";
}

CString CToDoCtrl::GetSelectedTaskAllocBy() const
{
	if (GetSelectedCount() == 1)
		return m_data.GetTaskAllocBy(GetSelectedItem());

	// else
	return "";
}

CString CToDoCtrl::GetSelectedTaskStatus() const
{
	if (GetSelectedCount() == 1)
		return m_data.GetTaskStatus(GetSelectedItem());

	// else
	return "";
}

CString CToDoCtrl::GetSelectedTaskCategory() const
{
	if (GetSelectedCount() == 1)
		return m_data.GetTaskCategory(GetSelectedItem());

	// else
	return "";
}

BOOL CToDoCtrl::SetSelectedTaskFileRef(LPCTSTR szFilePath)
{
	if (IsReadOnly())
		return FALSE;

	POSITION pos = Selection().GetFirstItemPos();
	int nRes = SET_NOCHANGE;

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);
		int nItemRes =	m_data.SetTaskFileRef(GetTaskID(hti), szFilePath);

		if (nItemRes == SET_CHANGE)
			nRes = SET_CHANGE;
	}

	return SetTextChange(nRes, m_sFileRefPath, szFilePath, TDCA_FILEREF, IDC_FILEPATH);
}

CString CToDoCtrl::GetSelectedTaskFileRef() const
{
	if (GetSelectedCount() == 1)
		return m_data.GetTaskFileRef(GetSelectedTaskID());

	// else
	return "";
}

BOOL CToDoCtrl::GotoSelectedTaskFileRef()
{
	return GotoFile(GetSelectedTaskFileRef(), TRUE);
}

HTREEITEM CToDoCtrl::NewTask(LPCTSTR szText, TDC_INSERTWHERE nWhere, BOOL bSelect, BOOL bEditText)
{
	if (IsReadOnly())
		return NULL;

	if (!szText || !lstrlen(szText))
		return NULL;

	HTREEITEM htiSel = GetSelectedItem(), htiParent = NULL, htiAfter = NULL;

	// handle no selected item
	if (!htiSel)
	{
		switch (nWhere)
		{
		case TDC_INSERTATTOP:
		case TDC_INSERTATTOPOFSELTASKPARENT:
		case TDC_INSERTATTOPOFSELTASK:
		case TDC_INSERTBEFORESELTASK:
			htiParent = TVI_ROOT;
			htiAfter = TVI_FIRST;
			break;

		case TDC_INSERTATBOTTOM:
		case TDC_INSERTATBOTTOMOFSELTASKPARENT:
		case TDC_INSERTATBOTTOMOFSELTASK:
		case TDC_INSERTAFTERSELTASK:
			htiParent = TVI_ROOT;
			htiAfter = TVI_LAST; 
			break;
		}
	}
	else // detrmine the actual pos to insert
	{
		switch (nWhere)
		{
		case TDC_INSERTATTOP:
			htiParent = TVI_ROOT;
			htiAfter = TVI_FIRST;
			break;

		case TDC_INSERTATBOTTOM:
			htiParent = TVI_ROOT;
			htiAfter = TVI_LAST; 
			break;

		case TDC_INSERTATTOPOFSELTASKPARENT:
			htiParent = m_tree.GetParentItem(htiSel);
			htiAfter = TVI_FIRST;
			break;

		case TDC_INSERTATBOTTOMOFSELTASKPARENT:
			htiParent = m_tree.GetParentItem(htiSel);
			htiAfter = TVI_LAST;
			break;

		case TDC_INSERTAFTERSELTASK:
			htiParent = m_tree.GetParentItem(htiSel);
			htiAfter = htiSel;

			if (!htiAfter)
				htiAfter = TVI_LAST;
			break;

		case TDC_INSERTBEFORESELTASK:
			htiParent = m_tree.GetParentItem(htiSel);
			htiAfter = htiSel;

			if (!(htiAfter = m_tree.GetNextItem(htiAfter, TVGN_PREVIOUS)))
				htiAfter = TVI_FIRST;
			break;

		case TDC_INSERTATTOPOFSELTASK: // subtask
			htiParent = htiSel;
			htiAfter = TVI_FIRST;
			break;

		case TDC_INSERTATBOTTOMOFSELTASK: // subtask
			htiParent = htiSel;
			htiAfter = TVI_LAST; 
			break;
		}
	}


	return InsertItem(szText, htiParent, htiAfter, bSelect, bEditText);
}

HTREEITEM CToDoCtrl::InsertItem(LPCTSTR szText, HTREEITEM htiParent, HTREEITEM htiAfter, 
								BOOL bSelect, BOOL bEdit)
{
	m_htiLastAdded = NULL;
	
	if (IsReadOnly())
		return NULL;

	if (!szText || !lstrlen(szText))
		return NULL;

	// must create the new task item first
	TODOITEM tdiNew(s_tdDefault);

	// and initialize
	if (szText)
		tdiNew.sTitle = szText;

	// and map it
	m_data.AddTask(m_dwNextUniqueID, tdiNew);

	// bold state
    BOOL bRootParent = (!htiParent || htiParent == TVI_ROOT);
	BOOL bBold = bRootParent;

	UINT nState = (bBold ? TVIS_BOLD : 0) | TDC_UNCHECKED;
	UINT nStateMask = TVIS_BOLD | TVIS_STATEIMAGEMASK;

	HTREEITEM htiNew = m_tree.InsertItem(TVIF_TEXT | TVIF_PARAM | TVIF_STATE | 
											TVIF_IMAGE | TVIF_SELECTEDIMAGE,
											szText, 
											I_IMAGECALLBACK, 
											I_IMAGECALLBACK, 
											nState,
											nStateMask, // state mask
											m_dwNextUniqueID, // lParam
											htiParent, 
											htiAfter);
	
	if (htiNew)
	{
		// if the parent was being clocked then stop it now
		// since having children makes a task unclockable
		if (!bRootParent && m_dwTimeTrackTaskID && m_dwTimeTrackTaskID == GetTaskID(htiParent))
			m_dwTimeTrackTaskID = 0;

		m_tree.SelectItem(htiNew);
		m_tree.Invalidate(FALSE);
		m_tree.UpdateWindow();

		m_dwNextUniqueID++;
		SetModified(TRUE, TDCA_NONE);
		UpdateControls();
		
		if (bSelect)
		{
			SelectItem(htiNew);
			
			if (bEdit)
			{
				m_htiLastAdded = htiNew;
				CEdit* pEdit = m_tree.EditLabel(htiNew);
				
				// workaround because if the user presses <enter> without
				// editing the treectrl reports this as a non-edit and
				// the new items gets deleted!
				if (pEdit)
				{
					pEdit->SetWindowText(szText);
					pEdit->SetSel(0, -1);
				}
			}
			else
				m_tree.SetFocus();
		}
	}
	else // cleanup
		m_data.DeleteTask(m_dwNextUniqueID);
	
	return htiNew;
}

BOOL CToDoCtrl::CanSplitSelectedTask()
{
	int nSelCount = GetSelectedCount();

	return (!IsReadOnly() && (nSelCount > 1 || (nSelCount == 1 && !IsSelectedTaskDone() && 
								!ItemHasChildren(GetSelectedItem()))));
}

BOOL CToDoCtrl::SplitSelectedTask(int nNumSubtasks)
{
	if (nNumSubtasks < 2)
		return FALSE;

	if (!GetSelectedCount())
		return FALSE;

	CHoldRedraw hr(m_tree);

	POSITION pos = Selection().GetFirstItemPos();
	int nRes = SET_NOCHANGE;

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);
		TODOITEM tdi;

		if (ItemHasChildren(hti))
			continue;

		VERIFY(GetTask(GetTaskID(hti), tdi));

		if (tdi.IsDone())
			continue;

		// calculate how much time to allocate to each
		double dSubTime = 0, dSubEst = tdi.dTimeEstimate / nNumSubtasks;

		if (tdi.HasStart() && tdi.dateDue > tdi.dateStart)
			dSubTime = (tdi.dateDue - tdi.dateStart) / nNumSubtasks;

		for (int nSubtask = 0; nSubtask < nNumSubtasks; nSubtask++)
		{
			TODOITEM tdiSub(tdi); // copy parent

			// allocate time slice and dates
			tdiSub.dTimeEstimate = dSubEst;

			if (dSubTime)
			{
				tdiSub.dateStart += (nSubtask * dSubTime);
				tdiSub.dateDue = tdiSub.dateStart + COleDateTime(dSubTime);
			}
			else if (nSubtask) // not the first
			{
				tdiSub.ClearStart();
				tdiSub.ClearDue();
			}

			// map it
			DWORD dwTaskID = m_dwNextUniqueID++;
			m_data.AddTask(dwTaskID, tdiSub);
			
			// create tree item
			HTREEITEM htiSub = m_tree.InsertItem(tdi.sTitle, I_IMAGECALLBACK, I_IMAGECALLBACK, hti);

			m_tree.SetItemData(htiSub, dwTaskID);
			SetItemChecked(htiSub, FALSE);
		}

		m_tree.Expand(hti, TVE_EXPAND);
	}

	SetModified(TRUE, TDCA_NONE);

	return TRUE;
}

BOOL CToDoCtrl::DeleteSelectedTask(BOOL bWarnUser)
{
	if (IsReadOnly())
		return FALSE;

	int nSelCount = GetSelectedCount();

	if (!nSelCount)
		return FALSE;

	// if need confirmation then make sure the user knows that child items will get removed too
	if (bWarnUser && HasStyle(TDCS_CONFIRMDELETE))
	{
		CString sMessage;
		UINT nFlags = MB_ICONEXCLAMATION | MB_YESNO;
		
		if (nSelCount > 1)
			sMessage = "Are you sure you want to delete the selected tasks?";
		else
			sMessage = "Are you sure you want to delete the selected task?";

		if (Selection().AnyItemsHaveChildren())
		{
			if (nSelCount > 1)
				sMessage += "\n\n(ATTENTION: One or more of these tasks has subtasks "
							"which will also be deleted)";
			else
				sMessage += "\n\n(ATTENTION: This task has subtasks which will also be deleted)";

			nFlags |= MB_DEFBUTTON2;
		}
		else
			nFlags |= MB_DEFBUTTON1;

		if (MessageBox(sMessage, "Confirm Delete", nFlags) != IDYES)
			return FALSE;
	}

	// snapshot selection against changes
	CHTIList selection;
	Selection().CopySelection(selection);

	// reset anchor if we're going to delete it
	if (Selection().AnchorHasSelectedParent())
		Selection().SetAnchor(NULL);

	// remove real tree selection first if its going to be deleted
	// but before we do, lets figure out where the selection is
	// going to go _after_ the deletion, but only for single items.
	HTREEITEM hti = Selection().GetFirstItem(), htiNextSel = NULL;

	if (nSelCount == 1)
	{
		htiNextSel = Selection().GetNextItem(hti, FALSE);

		// don't include items we're about to delete!
		while (htiNextSel && Selection().HasItem(htiNextSel))
			htiNextSel = Selection().GetNextItem(htiNextSel);

		// else try previous item
		if (!htiNextSel)
		{
			htiNextSel = Selection().GetPrevItem(hti, FALSE);

			// don't include items we're about to delete!
			while (htiNextSel && Selection().HasItem(htiNextSel))
				htiNextSel = Selection().GetPrevItem(htiNextSel);
		}
	}

	if (Selection().HasItem(m_tree.GetSelectedItem()))
		m_tree.SelectItem(NULL);

	// because of the free-form nature of the selection list
	// it can contain children and their parents in the same list
	// which can be a problem if we delete the parent first.
	// so we first remove all items from the list if their
	// parent is in the list because they'll be deleted anyhow
	Selection().RemoveChildDuplicates(selection, m_tree);

	// do it
	CHoldRedraw hr(m_tree);

	// now we can delete with impunity
	POSITION pos = selection.GetHeadPosition();

	while (pos)
		m_data.DeleteTask(selection.GetNext(pos));
	
	// clear selection
	Selection().RemoveAll();

	SetModified(TRUE, TDCA_NONE);
	UpdateControls();

	// set next selection
	if (htiNextSel)
		SelectItem(htiNextSel);

	return TRUE;
}

BOOL CToDoCtrl::DeleteSelectedTask()
{
	return DeleteSelectedTask(TRUE);
}

BOOL CToDoCtrl::EditSelectedTask()
{
	if (IsReadOnly() || GetSelectedCount() != 1)
		return FALSE;

	HTREEITEM htiSel = GetSelectedItem();
	ASSERT (htiSel);

	return (NULL != m_tree.EditLabel(htiSel));
}

void CToDoCtrl::OnTreeEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;

	if (pTVDispInfo->item.pszText) // not cancelled
	{
		TODOITEM tdi;
		DWORD dwID = GetTaskID(pTVDispInfo->item.hItem);

		if (GetTask(dwID, tdi))
		{
			if (tdi.sTitle != pTVDispInfo->item.pszText)
			{
				tdi.sTitle = pTVDispInfo->item.pszText;
				UpdateTask(dwID, tdi);

				SetModified(TRUE, TDCA_TASKNAME);
			}
		}
	}
	// if the item was just added and cancelled then delete it
	else if (pTVDispInfo->item.hItem == m_htiLastAdded)
	{
		// make sure this item is not selected
		Selection().RemoveItem(m_htiLastAdded);
		m_data.DeleteTask(m_htiLastAdded);
		
		// reselect what the tree control thinks is selected
		if (!Selection().GetCount())
			SelectItem(m_tree.GetSelectedItem());
		
		UpdateControls();
	}

	m_htiLastAdded = NULL; // reset
	*pResult = (pTVDispInfo->item.pszText != NULL); // accept text
}

void CToDoCtrl::OnTreeBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;

	// can't edit multiple items. return TRUE to stop
	*pResult = (IsReadOnly() || GetSelectedCount() != 1);
}

BOOL CToDoCtrl::DeleteAllTasks()
{
	if (IsReadOnly())
		return FALSE;

	if (!HasStyle(TDCS_CONFIRMDELETE) || 
		MessageBox("Are you sure you want to delete all the tasks in this task list?",
					"Confirm Delete", MB_YESNO | MB_DEFBUTTON2) == IDYES)
	{
		CHoldRedraw hr(this);

		if (GetTaskCount())
		{
			Selection().RemoveAll(); // must do this first
			m_tree.DeleteAllItems();
			m_data.DeleteAllTasks();

			SetModified(TRUE, TDCA_NONE);
			UpdateControls();

			return TRUE;
		}
	}

	return FALSE;
}

void CToDoCtrl::SetStyle(TDC_STYLE nStyle, BOOL bOn)
{
	ASSERT (GetSafeHwnd());

	bOn = bOn ? TRUE : FALSE; // normalize

	if (bOn != HasStyle(nStyle))
	{
        m_aStyles[(int)nStyle] = bOn;

		switch (nStyle)
		{
		case TDCS_SHOWDATESINISO:
			m_tree.RecalcGutter();
			break;

		case TDCS_SHOWINFOTIPS:
			m_tree.ModifyStyle(bOn ? 0 : TVS_INFOTIP, bOn ? TVS_INFOTIP : 0);
			break;

		case TDCS_SHOWBUTTONSINTREE:
			m_tree.ModifyStyle(bOn ? 0 : TVS_LINESATROOT | TVS_HASBUTTONS, bOn ? TVS_LINESATROOT | TVS_HASBUTTONS : 0);
			break;

		case TDCS_COLORTEXTBYPRIORITY:
		case TDCS_SHOWCOMMENTSINLIST:
		case TDCS_USEEARLIESTDUEDATE:
		case TDCS_STRIKETHOUGHDONETASKS:
		case TDCS_TASKCOLORISBACKGROUND:
			Invalidate(FALSE);
			break;

		case TDCS_TREATSUBCOMPLETEDASDONE:
			Invalidate(FALSE);
			m_tree.RecalcGutter();
			break;

		case TDCS_COLORPRIORITY:
		case TDCS_USEHIGHESTPRIORITY:
		case TDCS_INCLUDEDONEINPRIORITYCALC:
			if (IsColumnShowing(TDCC_PRIORITY))
				m_tree.RedrawGutter();
			break;

		case TDCS_SHOWNONFILEREFSASTEXT:
			if (IsColumnShowing(TDCC_FILEREF))
				m_tree.RecalcGutter();
			break;

		case TDCS_USEPERCENTDONEINTIMEEST:
			if (IsColumnShowing(TDCC_TIMEEST))
				m_tree.RecalcGutter();
			break;

		case TDCS_HIDEZEROTIMEEST:
		case TDCS_ROUNDTIMEFRACTIONS:
			if (IsColumnShowing(TDCC_TIMEEST) || IsColumnShowing(TDCC_TIMESPENT))
				m_tree.RecalcGutter();
			break;

		case TDCS_HIDEPERCENTFORDONETASKS:
		case TDCS_INCLUDEDONEINAVERAGECALC:
		case TDCS_WEIGHTPERCENTCALCBYTIMEEST:
		case TDCS_WEIGHTPERCENTCALCBYPRIORITY:
		case TDCS_SHOWPERCENTASPROGRESSBAR:
			if (IsColumnShowing(TDCC_PERCENT))
				m_tree.RedrawGutter();
			break;

		case TDCS_AVERAGEPERCENTSUBCOMPLETION:
		case TDCS_AUTOCALCPERCENTDONE:
			UpdateControls(); // disable/enable some controls

			if (IsColumnShowing(TDCC_PERCENT))
				m_tree.RecalcGutter();
			else
				m_tree.RedrawGutter();
			break;

		case TDCS_HIDESTARTDUEFORDONETASKS:
			if (IsColumnShowing(TDCC_STARTDATE) || IsColumnShowing(TDCC_DUEDATE))
				m_tree.RedrawGutter();
			break;

		case TDCS_SHOWWEEKDAYINDATES:
			if (IsColumnShowing(TDCC_STARTDATE) || IsColumnShowing(TDCC_DUEDATE) ||
				IsColumnShowing(TDCC_DONEDATE))
				m_tree.RecalcGutter();
			break;

		case TDCS_SIMPLEMODE:
			// ensure focus is ok
			if (bOn)
				m_tree.SetFocus();

			Resize();
			break;

		case TDCS_SHOWCTRLSASCOLUMNS:
		case TDCS_SHOWCOMMENTSALWAYS:
		case TDCS_AUTOREPOSCTRLS:
			Resize();
			break;

		case TDCS_SHAREDCOMMENTSHEIGHT:
			if (bOn && !s_nCommentsHeight && !m_sLastSavePath.IsEmpty())
				s_nCommentsHeight = m_nCommentsHeight;

			Resize();
			break;

		case TDCS_READONLY:
		case TDCS_CONFIRMDELETE:
		case TDCS_CHECKOUTONLOAD:
		case TDCS_ENABLESOURCECONTROL:
		case TDCS_QUERYAPPLYCHANGESTOSUBTASKS:
		case TDCS_SORTVISIBLETASKSONLY:
		case TDCS_AUTOCALCTIMEESTIMATES:
		case TDCS_FOCUSTREEONENTER:
			break;

		case TDCS_SHOWPATHINHEADER:
			if (!bOn)
				m_tree.SetGutterColumnHeaderTitle(NCG_CLIENTCOLUMNID, TDL_TASK);
			else
				UpdateSelectedTaskPath();
			break;

		case TDCS_FULLROWSELECTION:
			if (bOn)
				m_tree.ModifyStyle(TVS_HASLINES, TVS_FULLROWSELECT);
			else
				m_tree.ModifyStyle(TVS_FULLROWSELECT, TVS_HASLINES);
			break;

		case TDCS_TREECHECKBOXES:
			if (bOn)
				TreeView_SetImageList(m_tree, m_hilDone, TVSIL_STATE);
			else
				TreeView_SetImageList(m_tree, NULL, TVSIL_STATE);

			if (IsColumnShowing(TDCC_DONE))
				m_tree.RecalcGutter(); // to hide/display the 'done' column
			break;

		case TDCS_COLUMNHEADERCLICKING:
			UpdateColumnHeaderClicking();
			break;

		case TDCS_COMMENTSUSETREEFONT:
			if (bOn && m_fontTree.GetSafeHandle())
				m_reComments.SetFont(&m_fontTree);
			else
				m_reComments.SetFont(GetFont());
			break;

		case TDCS_RIGHTALIGNLABELS:
			SetLabelAlignment(bOn ? SS_RIGHT : SS_LEFT);
			break;

		case TDCS_SHOWPARENTSASFOLDERS:
			if (bOn)
				TreeView_SetImageList(m_tree, m_ilFileRef.GetHImageList(), TVSIL_NORMAL);
			else
				TreeView_SetImageList(m_tree, NULL, TVSIL_NORMAL);
			break;

		case TDCS_TRACKSELECTEDTASKONLY:
			break;

		default:
			ASSERT(0); // just to help catch forgotten styles
			break;
		}

		m_data.ResetCachedCalculations();

		UpdateControls();
	}
}

void CToDoCtrl::SetStyles(const CTDCStyles& styles)
{
	// first evaluate whether there any changes or not
	// without changing anything
	BOOL bChange = FALSE;

	for (int nStyle = TDCS_FIRST; nStyle < TDCS_LAST && !bChange; nStyle++)
	{
		BOOL bWantOn = -1, bIsOn = HasStyle((TDC_STYLE)nStyle); // undefined

		if (styles.Lookup((TDC_STYLE)nStyle, bWantOn))
		{
			bWantOn = bWantOn ? 1 : 0; // normalize
			bChange = (bWantOn != bIsOn);
		}
	}

	if (!bChange)
		return;

	CHoldRedraw hr(this);

	for (nStyle = TDCS_FIRST; nStyle < TDCS_LAST; nStyle++)
	{
		BOOL bOn = -1; // undefined

		if (styles.Lookup((TDC_STYLE)nStyle, bOn))
			SetStyle((TDC_STYLE)nStyle, bOn);
	}

	m_tree.RecalcGutter();
}

BOOL CToDoCtrl::HasStyle(TDC_STYLE nStyle) const 
{ 
	// some special handling for dependent styles
	if (nStyle == TDCS_CHECKOUTONLOAD)
	{
		if (!HasStyle(TDCS_ENABLESOURCECONTROL))
            return FALSE;
	}

	return m_aStyles[nStyle] ? TRUE : FALSE; 
}

void CToDoCtrl::ShowColumn(TDC_COLUMN nColumn, BOOL bShow)
{
	// special case
	if (nColumn == TDCC_POSITION)
		m_tree.ShowGutterPosColumn(bShow);
	else
	{
		DWORD dwPrevColumns = m_dwVisibleColumns;
		DWORD dwColumn = (2 << (int)nColumn);

		if (bShow)
			m_dwVisibleColumns |= dwColumn;
		else
			m_dwVisibleColumns &= ~dwColumn;

		if (m_dwVisibleColumns != dwPrevColumns)
		{
			m_tree.RecalcGutter();

			// hide/show controls which may have been affected
			if (HasStyle(TDCS_SHOWCTRLSASCOLUMNS))
			{
				UpdateControls();

				// and resize to allow for control realignment
				Resize();
			}
		}
	}
}

BOOL CToDoCtrl::IsColumnShowing(TDC_COLUMN nColumn) const
{
	DWORD dwColumn = (2 << (int)nColumn);

	return ((m_dwVisibleColumns & dwColumn) == dwColumn);
}

BOOL CToDoCtrl::Save(LPCTSTR szFilePath, BOOL bCheckforLaterChanges)
{
	ASSERT (GetSafeHwnd());

	if (!GetSafeHwnd())
		return FALSE;

	// can't save if not checked-out
	// unless we're saving to another filename or this is our first save
	BOOL bFirstSave = (m_sLastSavePath.IsEmpty() || m_sLastSavePath.CompareNoCase(szFilePath) != 0);

	if (HasStyle(TDCS_ENABLESOURCECONTROL) && !m_bCheckedOut && !bFirstSave)
		return FALSE;

	if (!szFilePath)
	{
		if (m_sLastSavePath.IsEmpty())
			return FALSE;
		else
			szFilePath = m_sLastSavePath;
	}

	UpdateData();

	// check for later changes (multi-user usage)
	if (bCheckforLaterChanges && m_nFileVersion > 0) // else its newly created
	{
		if (GetFileAttributes(szFilePath) != 0xffffffff) // file exists (sanity check)
		{
			// i was going to use filetimes but these are too unreliable
			// instead we open the xml file and look at its internal version
			CXmlFileEx temp(TDL_ROOT);

			if (temp.Load(szFilePath, NULL, NULL, FALSE)) // FALSE => don't decrypt
			{
				if (temp.GetItemValueI("FILEVERSION") > m_nFileVersion)
				{
					CString sMessage;
					sMessage.Format("The tasklist '%s' has been modified \nsince you opened it or last saved your changes.\n\nIf you continue you will overwrite those changes.\n\nAre you sure you want to proceed?", szFilePath);

					if (MessageBox(sMessage, "Confirm Overwrite", MB_ICONWARNING | MB_YESNO) == IDNO)
						return FALSE;
				}
			}
		}
	}

	CXmlFileEx file(TDL_ROOT);
	TDCFILTER filter(TDCF_ALL, FALSE);

	AddChildren(NULL, file.Root(), filter, TRUE);

	file.SortItemsI(TDL_TASK, TDL_TASKID);

	// file header info
	if (IsModified())
		m_nFileVersion++;

	file.SetHeader(m_sXmlHeader);
	file.AddItem("LASTMODIFIED", CDateHelper::FormatCurrentDate(TRUE));
	file.AddItem("PROJECTNAME", m_sProjectName);

	// and next unique ID
	file.AddItem("NEXTUNIQUEID", (int)m_dwNextUniqueID);

	if (m_bArchive)
		file.AddItem("ARCHIVE", 1);

	// encrypt prior to setting checkout status and file info (so these are visible without decryption)
	// this simply fails if password is empty
	file.Encrypt(m_sPassword);
	
	file.AddItem("FILEFORMAT", FILEFORMAT);
	file.AddItem("FILEVERSION", m_nFileVersion);

	// checkout status
	// if this is a first time save and source control is enabled
	// then check it out
	if (HasStyle(TDCS_ENABLESOURCECONTROL) && (m_bCheckedOut || bFirstSave))
		file.AddItem(TDL_CHECKEDOUTTO, m_sMachineName);

	if (file.Save(szFilePath))
	{
		m_sLastSavePath = szFilePath;
		m_bModified = FALSE;
		m_bCheckedOut = (file.GetItem(TDL_CHECKEDOUTTO) != NULL);

		// update fileref with the todolist's folder
		char szDrive[_MAX_DRIVE], szPath[MAX_PATH];
		_splitpath(szFilePath, szDrive, szPath, NULL, NULL);

		m_eFileRef.SetCurrentFolder(CString(szDrive) + CString(szPath));

		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::WantExportColumn(TDC_COLUMN nColumn, BOOL bVisibleColsOnly) const
{
	return (!bVisibleColsOnly || IsColumnShowing(nColumn));
}

TDC_OPEN CToDoCtrl::Load(LPCTSTR szFilePath, LPCTSTR szArchivePath, TDC_ARCHIVE nRemove)
{
	ASSERT (GetSafeHwnd());

	if (!GetSafeHwnd())
		return TDCO_UNKNOWN;

	if (GetFileAttributes(szFilePath) == 0xffffffff)
		return TDCO_NOTEXIST;

	CXmlFileEx file(TDL_ROOT, m_sPassword);

	// check readonly flag before trying to open
	BOOL bReadOnly = CDriveInfo::IsReadonlyPath(szFilePath);

	// if not readonly then open read-write
	if (!bReadOnly && !file.Open(szFilePath, XF_READWRITE))
		return TDCO_UNKNOWN;

	// if readonly then don't
	if (bReadOnly && !file.Open(szFilePath, XF_READ))
		return TDCO_UNKNOWN;

	if (file.LoadEx())
	{
		// save off password
		m_sPassword = file.GetPassword();

		// check out?
		if (!bReadOnly && HasStyle(TDCS_ENABLESOURCECONTROL))
		{
			if (HasStyle(TDCS_CHECKOUTONLOAD))
			{
				CString sTemp;
				CheckOut(&file, sTemp);
			}
			else
				m_bCheckedOut = IsCheckedOut(&file);
		}
		
		Load(&file, szArchivePath, nRemove);
		LoadSplitPos();

		// init fileref with the todolists folder
		char szDrive[_MAX_DRIVE], szPath[MAX_PATH];
		_splitpath(szFilePath, szDrive, szPath, NULL, NULL);

		m_eFileRef.SetCurrentFolder(CString(szDrive) + CString(szPath));
		
		return TDCO_SUCCESS;
	}

	// else
	switch (file.GetLastLoadError())
	{
	case XFL_CANCELLED:
		return TDCO_CANCELLED;

	case XFL_MISSINGROOT:
		return TDCO_NOTTASKLIST;
	}

	// all else
	return TDCO_UNKNOWN;
}

BOOL CToDoCtrl::Load(CXmlFileEx* pFile, LPCTSTR szArchivePath, TDC_ARCHIVE nRemove)
{
	ASSERT (GetSafeHwnd() && pFile);

	if (!GetSafeHwnd() || !pFile)
		return FALSE;

	SaveExpandedState();

	// file header info
	m_sXmlHeader = pFile->GetHeader();
	m_nFileFormat = pFile->GetItemValueI("FILEFORMAT");
	m_nFileVersion = pFile->GetItemValueI("FILEVERSION");
	m_sProjectName = pFile->GetItemValue("PROJECTNAME");
	m_bArchive = pFile->GetItemValueI("ARCHIVE");

	// next unique ID
	m_dwNextUniqueID = pFile->GetItemValueI("NEXTUNIQUEID");
	
	// backwards compatibility
	if (!m_dwNextUniqueID)
		m_dwNextUniqueID = 1;
	
	CHoldRedraw hr(&m_tree);

	Selection().RemoveAll(FALSE);
	m_tree.DeleteAllItems();

	// sort items by POS to reverse the sort by ID when we saved the file
	pFile->SortItemsI(TDL_TASK, TDL_TASKPOS);
	
	HTREEITEM htiFirst = AddItem(pFile->Root(), NULL);
	
	if (szArchivePath && lstrlen(szArchivePath) && ArchiveDoneTasks(szArchivePath, nRemove, FALSE))
		m_bModified = TRUE;
	else
		m_bModified = FALSE;
	
	m_sLastSavePath = pFile->GetFilePath();
	
	// sorting
	if (pFile->GetItem("LASTSORTBY")) // backwards compatibility
	{
		m_nSortBy = (TDC_SORTBY)pFile->GetItemValueI("LASTSORTBY");
		m_bSortAscending = pFile->GetItemValueI("LASTSORTDIR");
	}
	else
		LoadSortState(pFile->GetFilePath());

	// redo last sort
	if (m_nSortBy != TDC_SORTBYNONE)
	{
		TDCCOLUMN* pTDCC = GetColumn(m_nSortBy);
		ASSERT (pTDCC);

		m_tree.SetGutterColumnSort(pTDCC->nColID, m_bSortAscending ? NCGSORT_UP : NCGSORT_DOWN);

		m_data.Sort(m_nSortBy, m_bSortAscending);
		m_bModSinceLastSort = FALSE;
	}
	m_tree.PressGutterColumnHeader(-1);
	
	// restore last expanded state
	HTREEITEM htiSel = LoadExpandedState(FALSE);

	if (!htiSel)
		htiSel = htiFirst;
	
	SelectItem(htiSel);
	m_tree.EnsureVisible(htiSel);
	m_tree.SetFocus();

	UpdateData(FALSE);
	
	return TRUE;
}

int CToDoCtrl::ArchiveDoneTasks(LPCTSTR szFilePath, TDC_ARCHIVE nRemove, BOOL bFlickerFree)
{
	// can't archive archives
	if (m_bArchive)
		return 0;

	if (!GetTaskCount() || !szFilePath || !lstrlen(szFilePath))
		return 0;

	// 1. first see if there's anything to archive
	CXmlFile xiDone(TDL_ROOT);
	TDCFILTER filter(TDCF_DONE, FALSE);

	int nNumAdded = AddChildren(NULL, xiDone.Root(), filter, TRUE);

	if (!nNumAdded)
		return 0;

	SaveExpandedState();

	// 2. load existing archive if present
	CXmlFileEx file(TDL_ROOT, m_sPassword);

	if (file.Load(szFilePath))
	{
		VERIFY(file.GetItemValue("ARCHIVE"));

		CXmlItem* pXI = file.GetItem("FILEVERSION");

		if (pXI)
			pXI->SetValue(pXI->GetValueI() + 1);
		else
			file.AddItem("FILEVERSION", 1);
	}
	else // or initialize first time
	{
		file.AddItem("ARCHIVE", 1);
		file.AddItem("FILEFORMAT", FILEFORMAT);
		file.AddItem("FILEVERSION", 1);
		file.AddItem("LASTMODIFIED", CDateHelper::FormatCurrentDate(TRUE));
		file.AddItem("PROJECTNAME", m_sProjectName + " (archive)");
		file.AddItem("NEXTUNIQUEID", 1);
	}

	// 3. merge in new done items
	CMergeToDoList mtdl(TDLM_BYID, TDLM_MOVE);
	
	mtdl.Merge(xiDone.Root(), file.Root());

	// 4. save archive
	file.Save(szFilePath);

	// 5. remove archived tasks from current list
	if (!IsReadOnly() && nRemove != TDC_REMOVENONE)
	{
		file.Reset();

		if (bFlickerFree)
			m_tree.SetRedraw(FALSE);

		// filter
		filter.nFilter = TDCF_ALL;

		switch (nRemove)
		{
		case TDC_REMOVEALL:
			filter.nFilter = TDCF_NOTDONE;
			break;

		case TDC_REMOVEIFSIBLINGSANDSUBTASKSCOMPLETE:
			filter.nFilter = TDCF_NOTFULLYDONE;
			break;

		default:
			ASSERT (0);
		}

		// clear selection
		Selection().RemoveAll();

		if (AddChildren(NULL, file.Root(), filter, TRUE))
		{
			m_tree.DeleteAllItems();
			AddItem(file.Root(), NULL);
		}
		else
			m_tree.DeleteAllItems();

		// we only need to this if we've rebuilt the tree
		LoadExpandedState();

		if (bFlickerFree)
			m_tree.SetRedraw(TRUE);
	}

	return (nRemove == TDC_REMOVEALL) ? nNumAdded : 0;
}

int CToDoCtrl::ArchiveDoneTasks(LPCTSTR szFilePath, TDC_ARCHIVE nRemove)
{
	// this is only called externally so we need to specify flicker free
	int nRes = ArchiveDoneTasks(szFilePath, nRemove, TRUE);

	if (nRes)
		SetModified(TRUE, TDCA_NONE);

	return nRes;
}

BOOL CToDoCtrl::Import(LPCTSTR szFilePath)
{
	if (IsReadOnly())
		return FALSE;

	CXmlFileEx fileSrc(TDL_ROOT, m_sPassword), fileDest(TDL_ROOT);

	if (!fileSrc.Load(szFilePath))
		return FALSE;

	Flush();
	SaveExpandedState();

	// build the current tasklist into a CXmlFileEx object
	TDCFILTER filter(TDCF_ALL, FALSE);
	AddChildren(NULL, fileDest.Root(), filter, TRUE);

	// and specify the next unique ID
	fileDest.AddItem("NEXTUNIQUEID", (int)m_dwNextUniqueID);

	// merge source tasks into dest
	CMergeToDoList mtdl(TDLM_BYTITLE, TDLM_MOVE);

	if (!mtdl.Merge(fileSrc.Root(), fileDest.Root()))
		return TRUE; // just means no items were updated

	CHoldRedraw hr2(&m_tree);
	CHoldRedraw hr1(this);
	m_tree.DeleteAllItems();
	
	HTREEITEM htiFirst = AddItem(fileDest.Root(), NULL);
	HTREEITEM htiSel = LoadExpandedState(FALSE);
	
	SelectItem(htiSel ? htiSel : htiFirst);
	m_tree.SetFocus();
	
	m_bModified = TRUE;
	UpdateData(FALSE);
	
	return TRUE;
}

HTREEITEM CToDoCtrl::AddItem(const CXmlItem* pXI, HTREEITEM htiParent, HTREEITEM htiAfter, BOOL bResetID)
{
	HTREEITEM hti = TVI_ROOT; // default for root item

	if (htiParent)
	{
		// add new task to map
		TODOITEM tdi;

		tdi.tLastMod = pXI->GetItemValueF(TDL_TASKLASTMOD);
		tdi.sTitle = pXI->GetItemValue(TDL_TASKTITLE);
		tdi.sComments = pXI->GetItemValue(TDL_TASKCOMMENTS);
		tdi.sAllocTo = pXI->GetItemValue(TDL_TASKALLOCTO);
		tdi.sAllocBy = pXI->GetItemValue(TDL_TASKALLOCBY);
		tdi.sStatus = pXI->GetItemValue(TDL_TASKSTATUS);
		tdi.sCategory = pXI->GetItemValue(TDL_TASKCATEGORY);
		tdi.color = pXI->GetItemValueI(TDL_TASKCOLOR);
		tdi.nPercentDone = pXI->GetItemValueI(TDL_TASKPERCENTDONE);
		tdi.sFileRefPath = pXI->GetItemValue(TDL_TASKFILEREFPATH);
		tdi.dTimeEstimate = pXI->GetItemValueF(TDL_TASKTIMEESTIMATE);
		tdi.dTimeSpent = pXI->GetItemValueF(TDL_TASKTIMESPENT);
		tdi.nTimeEstUnits = m_data.MapTimeUnits(pXI->GetItemValue(TDL_TASKTIMEESTUNITS));
		tdi.nTimeSpentUnits = m_data.MapTimeUnits(pXI->GetItemValue(TDL_TASKTIMESPENTUNITS));

		// if file fmt == 0 then massage the priority field
		tdi.nPriority = pXI->GetItemValueI(TDL_TASKPRIORITY);

		if (m_nFileFormat == 0)
			tdi.nPriority = (tdi.nPriority == 1 ? 5 : (tdi.nPriority == 2 ? 10 : 0));

		tdi.dateDue = (double)pXI->GetItemValueI(TDL_TASKDUEDATE);
		tdi.dateStart = (double)pXI->GetItemValueI(TDL_TASKSTARTDATE);
		tdi.dateDone = (double)pXI->GetItemValueI(TDL_TASKDONEDATE);

		// add items to map
		DWORD dwUniqueID = pXI->GetItemValueI(TDL_TASKID);

		// make sure that m_dwUniqueID exceeds this ID
		if (dwUniqueID && !bResetID)
			m_dwNextUniqueID = max(m_dwNextUniqueID, dwUniqueID + 1);

		else // provide a new unique ID
			dwUniqueID = m_dwNextUniqueID++;
		
		m_data.AddTask(dwUniqueID, tdi);

		// add this item to tree
		hti = m_tree.InsertItem(tdi.sTitle, 
								I_IMAGECALLBACK, 
								I_IMAGECALLBACK, 
								htiParent, 
								htiAfter);

		// top level item == bold
		m_tree.SetItemData(hti, dwUniqueID);
		m_tree.SetItemState(hti, (htiParent == TVI_ROOT) ? TVIS_BOLD : 0, TVIS_BOLD);

		// check state
		SetItemChecked(hti, (tdi.dateDone > 0));

		// add unique items to comboboxes
		m_cbAllocTo.AddUniqueItem(tdi.sAllocTo);
		m_cbAllocBy.AddUniqueItem(tdi.sAllocBy);
		m_cbStatus.AddUniqueItem(tdi.sStatus);
		m_cbCategory.AddUniqueItem(tdi.sCategory);
	}

	// then children
	const CXmlItem* pXIChild = pXI->GetItem(TDL_TASK);
	HTREEITEM htiFirstItem = (hti == TVI_ROOT) ? NULL : hti;

	while (pXIChild)
	{
		HTREEITEM htiChild = AddItem(pXIChild, hti, TVI_LAST, bResetID);

		if (!htiFirstItem)
			htiFirstItem = htiChild;

		pXIChild = pXIChild->GetSibling(); // next
	}

	return htiFirstItem;
}

void CToDoCtrl::SetItemChecked(HTREEITEM hti, BOOL bChecked)
{
	int nCheckState = bChecked ? TDC_CHECKED : TDC_UNCHECKED;
	m_tree.SetItemState(hti, nCheckState, TVIS_STATEIMAGEMASK);
}

void CToDoCtrl::OnTreeGetDispInfo(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMTVDISPINFO lptvdi = (LPNMTVDISPINFO)pNMHDR;
	
	if (lptvdi->item.mask & (TVIF_SELECTEDIMAGE | TVIF_IMAGE))
	{
		BOOL bHasChildren = m_tree.ItemHasChildren(lptvdi->item.hItem);
		int nImage = (bHasChildren ? m_ilFileRef.GetFolderImageIndex() : -1);

		lptvdi->item.iImage = lptvdi->item.iSelectedImage = nImage;
	}
}

void CToDoCtrl::OnTreeCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMCUSTOMDRAW* pNMCD = (NMCUSTOMDRAW*)pNMHDR;

	if (pNMCD->dwDrawStage == CDDS_PREPAINT)
		*pResult |= CDRF_NOTIFYITEMDRAW | CDRF_NOTIFYPOSTPAINT;	
		
	else if (pNMCD->dwDrawStage == CDDS_ITEMPREPAINT)
	{
		NMTVCUSTOMDRAW* pTVCD = (NMTVCUSTOMDRAW*)pNMCD;
		TODOITEM tdi;

		DWORD dwItemID = (DWORD)pTVCD->nmcd.lItemlParam;
		
		// set fonts and colors
		if (GetTask(dwItemID, tdi))
		{
			HTREEITEM hti = (HTREEITEM)pTVCD->nmcd.dwItemSpec;

			TDI_STATE nState = GetItemState(hti);
			BOOL bDone = IsTaskDone(hti);
			BOOL bGoodAsDone = IsTaskDone(hti, TDCCHECKPARENT | TDCCHECKCHILDREN);
			
			switch (nState)
			{
			case TDIS_DROPHILITED:
			case TDIS_SELECTEDNOTFOCUSED:
				pTVCD->clrText = GetSysColor(COLOR_WINDOWTEXT);
				pTVCD->clrTextBk = GetSysColor(COLOR_3DFACE);

				*pResult |= CDRF_NEWFONT;
				break;

			case TDIS_SELECTED:
				pTVCD->clrText = GetSysColor(COLOR_HIGHLIGHTTEXT);
				pTVCD->clrTextBk = GetSysColor(COLOR_HIGHLIGHT);

				*pResult |= CDRF_NEWFONT;
				break;

				case TDIS_NONE:
				default:
				{
					pTVCD->clrTextBk = GetSysColor(COLOR_WINDOW);
					pTVCD->clrText = GetSysColor(COLOR_WINDOWTEXT);

					COLORREF color = pTVCD->clrText;
					BOOL bColorChange = TRUE;

					if (bDone || bGoodAsDone)
						color = m_crTaskDone; // parent and/or item is done

					else if (tdi.IsDue())
					{
						if (HasStyle(TDCS_COLORTEXTBYPRIORITY))
							color = GetPriorityColor(10);
						else
							color = 255;
					}
					else if (HasStyle(TDCS_COLORTEXTBYPRIORITY))
					{
						int nPriority = tdi.nPriority;

						if (HasStyle(TDCS_USEHIGHESTPRIORITY))
							nPriority = m_data.GetHighestPriority(hti, tdi);

						color = GetPriorityColor(nPriority); 
					}
					else if (tdi.color)
						color = tdi.color; 
					else
						bColorChange = FALSE;

					if (bColorChange)
					{
						if (HasStyle(TDCS_TASKCOLORISBACKGROUND) && !(bDone || bGoodAsDone))
						{
							pTVCD->clrTextBk = color;

							// base text color on luminance
							pTVCD->clrText = (RGBX(color).Luminance() < 128) ? RGB(255, 255, 255) : 0;
						}
						else
							pTVCD->clrText = color;

						*pResult |= CDRF_NEWFONT;
					}
				}
				break;
			}

			// also
			if (bDone && HasStyle(TDCS_STRIKETHOUGHDONETASKS))
			{
				::SelectObject(pNMCD->hdc, m_fontDone);
				*pResult |= CDRF_NEWFONT;
			}
		}
	}
	else if (pNMCD->dwDrawStage == CDDS_ITEMPOSTPAINT)
	{
		NMTVCUSTOMDRAW* pTVCD = (NMTVCUSTOMDRAW*)pNMCD;
		TODOITEM tdi;

		// render comment text
		if (GetTask((DWORD)pTVCD->nmcd.lItemlParam, tdi) && !tdi.sComments.IsEmpty())
		{
			tdi.sComments.Replace("\r\n", " ");
			tdi.sComments.Replace('\n', ' ');
			tdi.sComments.Replace('\r', ' ');
			
			CDC* pDC = CDC::FromHandle(pNMCD->hdc);
			int nDC = pDC->SaveDC();
			
			HTREEITEM hti = (HTREEITEM)pTVCD->nmcd.dwItemSpec;
			BOOL bSelected = (pNMCD->uItemState & CDIS_SELECTED);
			BOOL bFullRowSelected = (bSelected && (m_tree.GetStyle() & TVS_FULLROWSELECT));
			
			if (!bFullRowSelected)
			{
				BOOL bGoodAsDone = IsTaskDone(hti, TDCCHECKPARENT | TDCCHECKCHILDREN);
				pDC->SetTextColor(bGoodAsDone ? m_crTaskDone : RGB(98, 98, 98));
			}
			else
			{
				if (pNMCD->uItemState & CDIS_FOCUS)
					pDC->SetTextColor(GetSysColor(COLOR_HIGHLIGHTTEXT));
				else
					pDC->SetTextColor(GetSysColor(COLOR_WINDOWTEXT));
			}
			
			BOOL bDone = IsTaskDone(hti);
				
			if (bDone && HasStyle(TDCS_STRIKETHOUGHDONETASKS))
				pDC->SelectObject(m_fontDone);
			
			CString sTemp("[see comments]");
			
			if (HasStyle(TDCS_SHOWCOMMENTSINLIST))
				sTemp.Format("[%s]", tdi.sComments);
			
			CRect rClient, rText;
			m_tree.GetItemRect((HTREEITEM)pTVCD->nmcd.dwItemSpec, rText, TRUE);
			
			rText.top++;
			rText.left = rText.right + 4;
			rText.right = pTVCD->nmcd.rc.right;
			
			pDC->SetBkMode(TRANSPARENT);
			pDC->ExtTextOut(rText.left, rText.top, ETO_CLIPPED, &rText, sTemp, NULL);
			
			pDC->RestoreDC(nDC);
		}
	}
}

CToDoCtrl::TDI_STATE CToDoCtrl::GetItemState(HTREEITEM hti)
{
	if (m_treeDragDrop.IsDragging() && 
		m_tree.GetItemState(hti, TVIS_DROPHILITED) & TVIS_DROPHILITED)
		return TDIS_DROPHILITED;

	else if (IsItemSelected(hti))
		return (m_tree.HasFocus() ? TDIS_SELECTED : TDIS_SELECTEDNOTFOCUSED);

	return TDIS_NONE;
}

void CToDoCtrl::OnTreeChangeFocus(NMHDR* pNMHDR, LRESULT* pResult) 
{
	Selection().InvalidateAll(FALSE);
}

void CToDoCtrl::OnTreeClick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	*pResult = 0;
}

void CToDoCtrl::OnTreeDblClk(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CPoint point(::GetMessagePos());
	m_tree.ScreenToClient(&point);

	UINT nHitFlags = 0;
	HTREEITEM htiHit = m_tree.HitTest(point, &nHitFlags);

	if (!IsReadOnly() && htiHit && (nHitFlags & TVHT_ONITEMLABEL) && !m_tree.ItemHasChildren(htiHit))
	{
		// we have to post this for reasons i haven't been able to figure.
		// if we send it, the edit finishes immediately
		// (later) i now think that this may be related to the lbuttonup which follows this
		m_tree.PostMessage(TVM_EDITLABEL, 0, (LPARAM)htiHit);
	}

	*pResult = 0;
}

void CToDoCtrl::OnTreeKeyDown(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMTVKEYDOWN pTVKey = (LPNMTVKEYDOWN)pNMHDR;

	// cursor handled in OnTreeSelChanged
	// <shift>+cursor handled in OnTreeSelChanged
	// <ctrl>+cursor handled in PreTranslateMessage
	// <ctrl>+<shift>+cursor handled in PreTranslateMessage

	// all we do is get a copy of the key pressed for reference
	switch (pTVKey->wVKey)
	{
	case VK_NEXT:  
	case VK_DOWN:
	case VK_UP:
	case VK_PRIOR: 
	case VK_RIGHT:
	case VK_LEFT:
	case VK_HOME:
	case VK_END:
		m_wKeyPress = pTVKey->wVKey;
		break;

	default:
		m_wKeyPress = 0;
	}
}

void CToDoCtrl::PreSubclassWindow() 
{
	if (!m_fontDone.GetSafeHandle()) // create first time
	{
		CFont* pFont = GetFont();

		if (!pFont)
			pFont = CFont::FromHandle((HFONT)GetStockObject(DEFAULT_GUI_FONT));
					
		LOGFONT lf;
		pFont->GetLogFont(&lf);
					
		lf.lfStrikeOut = TRUE;
					
		m_fontDone.CreateFontIndirect(&lf);
	}
	
	CRuntimeDlg::PreSubclassWindow();
}

void CToDoCtrl::OnDestroy() 
{
	// save state
	SaveExpandedState();
	SaveSplitPos();
	SaveSortState();

	// reset copied item if its us
	if (s_clipboard.hwndToDoCtrl == GetSafeHwnd())
	{
		s_clipboard.hwndToDoCtrl = NULL;
		s_clipboard.bCut = FALSE; // ensures that IDs get remade when pasting
	}

	CRuntimeDlg::OnDestroy();
	
	m_fontDone.DeleteObject();	
	m_fontTree.DeleteObject();
}

void CToDoCtrl::SetModified(BOOL bMod)
{
	if (!IsReadOnly())
	{
		m_bModified = bMod;
		m_bModSinceLastSort = TRUE; // always
	}
}

// internal version
void CToDoCtrl::SetModified(BOOL bMod, TDC_ATTRIBUTE nAttrib)
{
	if (IsReadOnly())
		return;

	SetModified(bMod);

	if (bMod)
	{
		// redraw the gutter if the associated column is visible
		BOOL bRedraw = FALSE;
		UINT nRecalcColID = 0;

		switch (nAttrib)
		{
		case TDCA_DONEDATE:
			bRedraw = IsColumnShowing(TDCC_DONEDATE);
			Invalidate(); // text color can be affected

			if (IsColumnShowing(TDCC_TIMEEST) && HasStyle(TDCS_USEPERCENTDONEINTIMEEST))
				nRecalcColID = TDCC_TIMEEST;
			break;

		case TDCA_DUEDATE:
			bRedraw = IsColumnShowing(TDCC_DUEDATE);
			Invalidate(); // text color can be affected 
			break;

		case TDCA_STARTDATE:
			bRedraw = IsColumnShowing(TDCC_STARTDATE);
			break;

		case TDCA_PRIORITY:
			bRedraw = IsColumnShowing(TDCC_PRIORITY);

			// text color can be affected 
			if (HasStyle(TDCS_COLORTEXTBYPRIORITY))
				Invalidate(); 
			break;

		case TDCA_COLOR:
			// text color can be affected 
			if (!HasStyle(TDCS_COLORTEXTBYPRIORITY))
				Invalidate(); 
			break;

		case TDCA_ALLOCTO:
			if (IsColumnShowing(TDCC_ALLOCTO))
				nRecalcColID = TDCC_ALLOCTO;
			break;

		case TDCA_ALLOCBY:
			if (IsColumnShowing(TDCC_ALLOCBY))
				nRecalcColID = TDCC_ALLOCBY;
			break;

		case TDCA_STATUS:
			if (IsColumnShowing(TDCC_STATUS))
				nRecalcColID = TDCC_STATUS;
			break;

		case TDCA_CATEGORY:
			if (IsColumnShowing(TDCC_CATEGORY))
				nRecalcColID = TDCC_CATEGORY;
			break;

		case TDCA_PERCENT:
			bRedraw = IsColumnShowing(TDCC_PERCENT);
			Invalidate(); // text color can be affected 
			break;

		case TDCA_TIMEEST:
			if (IsColumnShowing(TDCC_TIMEEST))
				nRecalcColID = TDCC_TIMEEST;
			break;

		case TDCA_TIMESPENT:
			if (IsColumnShowing(TDCC_TIMESPENT))
				nRecalcColID = TDCC_TIMESPENT;
			break;

		case TDCA_FILEREF:
			bRedraw = IsColumnShowing(TDCC_FILEREF);
			break;
		}

		m_data.ResetCachedCalculations();

		if (nRecalcColID)
		{
			if (!m_tree.RecalcGutterColumn(nRecalcColID))
				m_tree.RedrawGutter();
		}
		else if (bRedraw)
			m_tree.RedrawGutter();

		UpdateWindow();
		GetParent()->SendMessage(WM_TDCN_MODIFY, GetDlgCtrlID(), (LPARAM)nAttrib);
	}
}

void CToDoCtrl::OnChangeComments()
{
	UpdateTask(TDCA_COMMENTS);
}

void CToDoCtrl::OnChangeFileRefPath()
{
	UpdateTask(TDCA_FILEREF);
}

void CToDoCtrl::OnChangeProjectName()
{
	UpdateData();
	SetModified(TRUE, TDCA_PROJNAME);
}

void CToDoCtrl::InvalidateSelectedItem()
{
	InvalidateItem(GetSelectedItem());
}

void CToDoCtrl::InvalidateItem(HTREEITEM hti)
{
	CRect rItem;
	
	if (m_tree.GetItemRect(hti, rItem, FALSE))
		m_tree.InvalidateRect(rItem, FALSE);
}

void CToDoCtrl::Sort(TDC_SORTBY nBy)
{
	if (nBy == TDC_SORTBYNONE)
		return;

	TRACE ("CToDoCtrl::Sort().begin\n");

	CHoldRedraw hr(&m_tree);

	if (m_bSortAscending == -1 || nBy != m_nSortBy)
		m_bSortAscending = TRUE;

	// if there's been a mod since last sorting then its reasonable to assume
	// that the user is not toggling direction but wants to simply resort
	// in the same direction.
	else if (!m_bModSinceLastSort)
		m_bSortAscending = !m_bSortAscending;

	// update the column header
	TDCCOLUMN* pTDCC = GetColumn(nBy);
	ASSERT (pTDCC);

	if (pTDCC)
	{
		m_tree.SetGutterColumnSort(pTDCC->nColID, m_bSortAscending ? NCGSORT_UP : NCGSORT_DOWN);
		m_data.Sort(nBy, m_bSortAscending);

		m_nSortBy = nBy;
		m_bModSinceLastSort = FALSE;
	}

	TRACE ("CToDoCtrl::Sort().end\n");
}

LRESULT CToDoCtrl::OnTreeDragDrop(WPARAM wParam, LPARAM lParam)
{
	const MSG* pMsg = GetCurrentMessage();

	if (m_treeDragDrop.ProcessMessage(pMsg))
	{
		// handle WM_DD_DRAGDROP
		if (pMsg->message == WM_DD_DRAGDROP)
		{
			HTREEITEM htiDrop, htiAfter;

			if (m_treeDragDrop.GetDropTarget(htiDrop, htiAfter))
			{
				// copy selection as xml
				CXmlItem xiSelection;

				if (CopyCurrentSelection(xiSelection))
				{
					BOOL bCopy = (GetKeyState(VK_CONTROL) & 0x8000);

					if (!bCopy)
						DeleteSelectedTask(FALSE);

					AddToItem(xiSelection, htiDrop, htiAfter, bCopy);
					m_tree.Invalidate();
				}
			}
		}

		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::PreTranslateMessage(MSG* pMsg) 
{
	if (m_treeDragDrop.ProcessMessage(pMsg))
		return TRUE;

	switch (pMsg->message)
	{
	case WM_KEYDOWN:
		{
			// handle <return> and <escape> for tree label editing
			if (pMsg->hwnd == (HWND)m_tree.SendMessage(TVM_GETEDITCONTROL))
			{
				switch (pMsg->wParam)
				{
				case VK_ESCAPE:
					m_tree.SendMessage(TVM_ENDEDITLABELNOW, TRUE);
					return TRUE;
					
				case VK_RETURN:
					m_tree.SendMessage(TVM_ENDEDITLABELNOW, FALSE);
					return TRUE;
				}
			}
			// handle <ctrl>/Shift>+cursor for tree.
			// we have to handle these here before the tree gets hold of them
			// because its default behaviour does not suit our multiple
			// selection implementation
			else if (pMsg->hwnd == (HWND)m_tree)
			{
				// cursor handled in OnTreeSelChanged
				// <shift>+cursor handled in OnTreeSelChanged
				// <ctrl>+cursor handled here
				// <ctrl>+<shift>+cursor here
				BOOL bCtrl = (GetKeyState(VK_CONTROL) & 0x8000);
				BOOL bShift = (GetKeyState(VK_SHIFT) & 0x8000);

				// get the real currently selected item
				HTREEITEM hti = m_tree.GetSelectedItem();
				
				switch (pMsg->wParam)
				{
				case VK_NEXT:  
				case VK_DOWN:
					if (bCtrl)
					{
						HTREEITEM htiNext = NULL;
						
						if (pMsg->wParam == VK_NEXT)
							Selection().GetNextPageItem(hti);
						else
							Selection().GetNextItem(hti);

						if (htiNext)
						{
							m_tree.SelectItem(htiNext);

							// toggle items if shift is also down, but not the one 
							// we're just moving on to
							if (bShift)
							{
								HTREEITEM htiPrev = Selection().GetPrevItem(htiNext, FALSE);
								MultiSelectItems(htiPrev, hti, -1);
							}
						}

						return TRUE;
					}
					break;

				case VK_UP:
				case VK_PRIOR: 
					if (bCtrl)
					{
						HTREEITEM htiPrev = NULL;
						
						if (pMsg->wParam == VK_PRIOR)
							Selection().GetPrevPageItem(hti);
						else
							Selection().GetPrevItem(hti);

						if (htiPrev)
						{
							m_tree.SelectItem(htiPrev);

							// toggle items if shift is also down, but not the one 
							// we're just moving on to
							if (bShift)
							{
								HTREEITEM htiNext = Selection().GetNextItem(htiPrev, FALSE);
								MultiSelectItems(htiNext, hti, -1);
							}
						}

						return TRUE;
					}
					break;
					
				case VK_SPACE:
					if (bCtrl)
					{
						// toggle real selected item state
						MultiSelectItem(hti, -1);
						return TRUE;
					}
					break;
				}

				// see if the tree wants it
				if (((CWnd*)&m_tree)->PreTranslateMessage(pMsg))
					return TRUE;
			}
			// handle <enter> and TDCS_FOCUSTREEONENTER
			else if (HasStyle(TDCS_FOCUSTREEONENTER) && pMsg->wParam == VK_RETURN)
			{
				// have to be careful here because dropped-down comboboxes should
				// take precedence. so we have to check explicitly for them
				// and make sure they're not in a dropped state
				CWnd* pFocus = GetFocus();

				if (pFocus && IsChild(pFocus))
				{
					CString sClass = CWinClasses::GetClass(*pFocus);

					if (CWinClasses::IsClass(sClass, WC_COMBOBOX))
					{
						if (pFocus->SendMessage(CB_GETDROPPEDSTATE))
							return FALSE;
					}
					// also check for combo's edit box and edits with ES_WANTRETURN
					else if (CWinClasses::IsClass(sClass, WC_EDIT))
					{
						if (pFocus->GetStyle() & ES_WANTRETURN)
							return FALSE;

						CWnd* pParent = pFocus->GetParent();
						ASSERT (pParent);

						if (CWinClasses::IsClass(*pParent, WC_COMBOBOX) && 
							pParent->SendMessage(CB_GETDROPPEDSTATE))
							return FALSE;
					}
					// and also richedit with ES_WANTRETURN
					else if (CWinClasses::IsClass(sClass, WC_RICHEDIT))
					{
						if (pFocus->GetStyle() & ES_WANTRETURN)
							return FALSE;
					}

					// else move focus to tree
					m_tree.SetFocus();
					return TRUE;
				}
			}
		}
		break;
	}
	
	return CRuntimeDlg::PreTranslateMessage(pMsg);
}

BOOL CToDoCtrl::MoveSelectedTask(TDDH_MOVE nDirection)
{
	if (!CanMoveSelectedTask(nDirection))
		return FALSE;

	CHoldRedraw hr(*this);
	CHoldRedraw hr2(m_tree);
	
	HTREEITEM hti = GetSelectedItem();

	// remove selected item temporarily in case it changes
	Selection().RemoveItem(hti);
	
	hti = m_treeDragDrop.MoveItem(hti, nDirection);

	if (!hti) // can be NULL if it fails
		return FALSE;

	SelectItem(hti);
	SetModified(TRUE, TDCA_NONE);

	return TRUE;
}

BOOL CToDoCtrl::CanMoveSelectedTask(TDDH_MOVE nDirection) const
{
	return (!IsReadOnly() && GetSelectedCount() == 1 &&
			m_treeDragDrop.CanMoveItem(GetSelectedItem(), nDirection));
}

void CToDoCtrl::GotoTopLevelTask(TDC_GOTO nDirection)
{
	HTREEITEM htiParent = m_data.GetTopLevelTask(GetSelectedItem());

	if (htiParent)
	{
		HTREEITEM htiGoto = NULL;

		switch (nDirection)
		{
		case TDCG_NEXT:
			htiGoto = m_tree.GetNextItem(htiParent, TVGN_NEXT);
			break;

		case TDCG_PREV:
			// if the currently selected item is not htiParent then jump to it first
			if (GetSelectedItem() != htiParent)
				htiGoto = htiParent;
			else
				htiGoto = m_tree.GetNextItem(htiParent, TVGN_PREVIOUS);
			break;
		}

		if (htiGoto && htiGoto != GetSelectedItem())
			SelectItem(htiGoto);
	}
}

BOOL CToDoCtrl::CanGotoTopLevelTask(TDC_GOTO nDirection) const
{
	HTREEITEM htiParent = m_data.GetTopLevelTask(GetSelectedItem());

	if (htiParent)
	{
		HTREEITEM htiGoto = NULL;
		
		switch (nDirection)
		{
		case TDCG_NEXT:
			htiGoto = m_tree.GetNextItem(htiParent, TVGN_NEXT);
			break;

		case TDCG_PREV:
			// if the currently selected item is not htiParent then jump to it first
			if (GetSelectedItem() != htiParent)
				htiGoto = htiParent;
			else
				htiGoto = m_tree.GetNextItem(htiParent, TVGN_PREVIOUS);
			break;
		}

		return (htiGoto && htiGoto != GetSelectedItem());
	}

	return FALSE;
}

LRESULT CToDoCtrl::OnGutterDrawItem(WPARAM wParam, LPARAM lParam)
{
	NCGDRAWITEM* pNCGDI = (NCGDRAWITEM*)lParam;

	// convert index to TDC_COLUMN
	TDCCOLUMN* pTDCC = GetColumn(pNCGDI->nColID);

	if (!pTDCC) // not one of ours
		return FALSE;

	// is it visible
	if (!CRect().IntersectRect(pNCGDI->rItem, pNCGDI->rWindow))
		return TRUE;

	if (!IsColumnShowing(pTDCC->nColID))
		return TRUE;

	TODOITEM tdi;
	HTREEITEM hti = (HTREEITEM)pNCGDI->dwItem;
	DWORD dwUniqueID = GetTaskID(hti);
	
	if (GetTask(dwUniqueID, tdi))
	{
		CRect rItem(pNCGDI->rItem);
		
		TDI_STATE nState = GetItemState(hti);

		// colors and vertical divider
		COLORREF crTextColor = GetSysColor(COLOR_WINDOWTEXT); // default

		switch (nState)
		{
		case TDIS_DROPHILITED:
		case TDIS_SELECTEDNOTFOCUSED:
			pNCGDI->pDC->FillSolidRect(rItem, GetSysColor(COLOR_3DFACE));
			break;

		case TDIS_SELECTED:
			pNCGDI->pDC->FillSolidRect(rItem, GetSysColor(COLOR_HIGHLIGHT));
			crTextColor = GetSysColor(COLOR_HIGHLIGHTTEXT);
			break;

		case TDIS_NONE:
		default:
			pNCGDI->pDC->FillSolidRect(rItem.right - 1, rItem.top, 1, rItem.Height(), m_crGridlines);
			break; // no color change
		}

		switch (pTDCC->nColID)
		{
		case TDCC_PRIORITY:
			{
				// priority color
				if (!IsTaskDone(hti, TDCCHECKPARENT | TDCCHECKCHILDREN))
				{
					rItem.DeflateRect(2, 2, 3, 3);

					int nPriority = tdi.nPriority;

					if (tdi.IsDue())
						nPriority = 10;

					else if (HasStyle(TDCS_USEHIGHESTPRIORITY))
						nPriority = GetHighestPriority(hti, tdi);
				
					COLORREF color = GetPriorityColor(nPriority);
					pNCGDI->pDC->FillSolidRect(rItem, color);
				}
			}
			break;

		case TDCC_ID:
			{
				CString sID;
				sID.Format("%u", dwUniqueID);

				DrawGutterItemText(pNCGDI->pDC, sID, rItem, DT_RIGHT, crTextColor);
			}
			break;

		case TDCC_ALLOCTO:
			DrawGutterItemText(pNCGDI->pDC, tdi.sAllocTo, rItem, pNCGDI->nTextAlign, crTextColor);
			break;

		case TDCC_ALLOCBY:
			DrawGutterItemText(pNCGDI->pDC, tdi.sAllocBy, rItem, pNCGDI->nTextAlign, crTextColor);
			break;

		case TDCC_STATUS:
			DrawGutterItemText(pNCGDI->pDC, tdi.sStatus, rItem, pNCGDI->nTextAlign, crTextColor);
			break;

		case TDCC_CATEGORY:
			DrawGutterItemText(pNCGDI->pDC, tdi.sCategory, rItem, pNCGDI->nTextAlign, crTextColor);
			break;

		case TDCC_PERCENT:
			{
				if (!HasStyle(TDCS_HIDEPERCENTFORDONETASKS) ||
					!IsTaskDone(hti, TDCCHECKPARENT | TDCCHECKCHILDREN))
				{
					int nPercent = CalcPercentDone(hti, tdi);
					
					CString sPercent;
					sPercent.Format("%d%%", nPercent);

					// draw progressbar?
					if (HasStyle(TDCS_SHOWPERCENTASPROGRESSBAR))
					{
						CRect rProgress(rItem);
						rProgress.DeflateRect(2, 2, 3, 3);
						rProgress.right = rProgress.left + MulDiv(rProgress.Width(), nPercent, 100);

						// determine appropriate priority
						int nPriority = tdi.nPriority;

						if (HasStyle(TDCS_USEHIGHESTPRIORITY))
							nPriority = GetHighestPriority(hti, tdi);
 						
						pNCGDI->pDC->FillSolidRect(rProgress, GetPriorityColor(nPriority)); 
					}

					DrawGutterItemText(pNCGDI->pDC, sPercent, rItem, DT_RIGHT, crTextColor);
				}
			}
			break;

		case TDCC_TIMEEST:
		case TDCC_TIMESPENT:
			{
				BOOL bTimeEst = (pTDCC->nColID == TDCC_TIMEEST);

				int nUnits = s_tdDefault.nTimeEstUnits; // good default value

				// get actual task time units
				if (!m_tree.ItemHasChildren(hti))
					nUnits = bTimeEst ? tdi.nTimeEstUnits : tdi.nTimeSpentUnits;

				// draw time
				double dTime = bTimeEst ? CalcTimeEstimate(hti, tdi, nUnits) :
										  CalcTimeSpent(hti, tdi, nUnits);
				
				if (dTime > 0 || !HasStyle(TDCS_HIDEZEROTIMEEST))
				{
					int nDecPlaces = HasStyle(TDCS_ROUNDTIMEFRACTIONS) ? 0 : 2;
					CString sTime = CTimeEdit::FormatTime(dTime, nUnits, nDecPlaces);

					DrawGutterItemText(pNCGDI->pDC, sTime, rItem, pNCGDI->nTextAlign, crTextColor);
				}
			}
			break;

		case TDCC_TRACKTIME:
			if (m_dwTimeTrackTaskID == dwUniqueID)
			{
				// create symbol font to display clock icon
				static CFont font;

				if (!font.GetSafeHandle())
				{
					LOGFONT lf;
					HFONT hDef = (HFONT)GetStockObject(DEFAULT_GUI_FONT);

					if (GetObject(hDef, sizeof(lf), &lf))
					{
						lstrcpy(lf.lfFaceName, "Wingdings");
						lf.lfCharSet = SYMBOL_CHARSET;
					}
				
					font.CreateFontIndirect(&lf);
				}

				// show icon in red if we're currently tracking
				if (nState == TDIS_SELECTED || nState == TDIS_SELECTEDNOTFOCUSED ||
					!HasStyle(TDCS_TRACKSELECTEDTASKONLY))
					crTextColor = 255;

				if (font.GetSafeHandle())
				{
					CFont* pOldFont = pNCGDI->pDC->SelectObject(&font);
					DrawGutterItemText(pNCGDI->pDC, "�", rItem, pNCGDI->nTextAlign, crTextColor);
					pNCGDI->pDC->SelectObject(pOldFont);
				}
				else
					DrawGutterItemText(pNCGDI->pDC, "T", rItem, pNCGDI->nTextAlign, crTextColor);
			}
			break;

		case TDCC_STARTDATE:
			if (tdi.HasStart())
			{
				if (!HasStyle(TDCS_HIDESTARTDUEFORDONETASKS) ||	!IsTaskDone(hti, TDCCHECKPARENT | TDCCHECKCHILDREN))
				{
					BOOL bShowWeekday = HasStyle(TDCS_SHOWWEEKDAYINDATES);
					BOOL bISO = HasStyle(TDCS_SHOWDATESINISO);

					CString sDate = CDateHelper::FormatDate(tdi.dateStart, bISO, bShowWeekday);

					DrawGutterItemText(pNCGDI->pDC, sDate, rItem, pNCGDI->nTextAlign, crTextColor);
				}
			}
			break;

		case TDCC_DUEDATE:
			if (!HasStyle(TDCS_HIDESTARTDUEFORDONETASKS) ||	!IsTaskDone(hti, TDCCHECKPARENT | TDCCHECKCHILDREN))
			{
				COleDateTime date = tdi.dateDue;
				
				if (HasStyle(TDCS_USEEARLIESTDUEDATE))
					date = GetEarliestDueDate(hti, tdi);

				if (date.m_dt > 0) 
				{
					BOOL bShowWeekday = HasStyle(TDCS_SHOWWEEKDAYINDATES);
					BOOL bISO = HasStyle(TDCS_SHOWDATESINISO);

					CString sDate = CDateHelper::FormatDate(date, bISO, bShowWeekday);

					DrawGutterItemText(pNCGDI->pDC, sDate, rItem, pNCGDI->nTextAlign, crTextColor);
				}
			}
			break;

		case TDCC_DONEDATE:
			if (tdi.IsDone())
			{
				BOOL bShowWeekday = HasStyle(TDCS_SHOWWEEKDAYINDATES);
				BOOL bISO = HasStyle(TDCS_SHOWDATESINISO);
				
				CString sDate = CDateHelper::FormatDate(tdi.dateDone, bISO, bShowWeekday);
				
				DrawGutterItemText(pNCGDI->pDC, sDate, rItem, pNCGDI->nTextAlign, crTextColor);
			}
			break;

		case TDCC_FILEREF:
			if (!tdi.sFileRefPath.IsEmpty())
			{
				// get the associated image failing if necesary
				int nImage = m_ilFileRef.GetFileImageIndex(tdi.sFileRefPath, TRUE);

				// if it coulsn't be found then check for a tdl://
				if (nImage == -1 && tdi.sFileRefPath.Find(TDL_PROTOCOL) != -1)
				{
					HICON hIcon = (HICON)AfxGetMainWnd()->SendMessage(WM_GETICON, ICON_SMALL);

					// draw our app icon 
					if (hIcon)
					{
						rItem.DeflateRect(0, (rItem.Height() + 1 - 16) / 2);
						rItem.left += NCG_COLPADDING;
						::DrawIconEx(pNCGDI->pDC->GetSafeHdc(), rItem.left, rItem.top, hIcon,
									 16, 16, 0, NULL, DI_NORMAL);
					}
				}
				else if (nImage == -1 && HasStyle(TDCS_SHOWNONFILEREFSASTEXT))
					DrawGutterItemText(pNCGDI->pDC, tdi.sFileRefPath, rItem, DT_LEFT, crTextColor);
				else
				{
					if (nImage == -1)
						nImage = m_ilFileRef.GetFileImageIndex(tdi.sFileRefPath, FALSE);

					if (nImage >= 0)
					{
						rItem.DeflateRect(0, (rItem.Height() + 1 - 16) / 2);
						rItem.left += NCG_COLPADDING;
						m_ilFileRef.GetImageList()->Draw(pNCGDI->pDC, nImage, rItem.TopLeft(), ILD_TRANSPARENT);
					}
				}
			}
			break;

		case TDCC_DONE:
			{
				BOOL bDone = tdi.IsDone();
				rItem.DeflateRect((rItem.Width() - 16) / 2, (rItem.Height() - 16) / 2);

				if (m_hilDone)
				{
					int nImage = bDone ? 2 : 1; // first image is blank
					ImageList_Draw(m_hilDone, nImage, pNCGDI->pDC->GetSafeHdc(), 
									rItem.left, rItem.top, ILD_TRANSPARENT);
				}
				else
				{
					rItem.right--;
					rItem.bottom--;
					CThemed::DrawFrameControl(this, pNCGDI->pDC, rItem, DFC_BUTTON, 
											DFCS_BUTTONCHECK | (bDone ? DFCS_CHECKED : 0));
				}
			}
		}

		return TRUE; // we handled it
	}

	return FALSE;
}

double CToDoCtrl::GetEarliestDueDate(HTREEITEM hti, TODOITEM& tdi)
{
	if (tdi.dateEarliestDue.m_dt >= 0)
		return tdi.dateEarliestDue;

	// else update calc'ed value
	tdi.dateEarliestDue = m_data.GetEarliestDueDate(hti, tdi);

	DWORD dwUniqueID = m_tree.GetItemData(hti);
	m_data.UpdateTask(dwUniqueID, tdi);

	return tdi.dateEarliestDue;
}

int CToDoCtrl::GetHighestPriority(HTREEITEM hti, TODOITEM& tdi)
{
	// try pre-calculated value first
	if (tdi.nCalcPriority >= 0)
		return tdi.nCalcPriority;

	// else update calc'ed value
	tdi.nCalcPriority = m_data.GetHighestPriority(hti, tdi);
		
	DWORD dwUniqueID = m_tree.GetItemData(hti);
	m_data.UpdateTask(dwUniqueID, tdi);

	return tdi.nCalcPriority;
}

int CToDoCtrl::CalcPercentDone(const HTREEITEM hti, TODOITEM& tdi)
{
	// try pre-calculated value first
	if (tdi.nCalcPercent >= 0)
		return tdi.nCalcPercent;

	// else update calc'ed value
	tdi.nCalcPercent = m_data.CalcPercentDone(hti, tdi);
		
	DWORD dwUniqueID = m_tree.GetItemData(hti);
	m_data.UpdateTask(dwUniqueID, tdi);

	return tdi.nCalcPercent;
}

double CToDoCtrl::CalcTimeEstimate(const HTREEITEM hti, TODOITEM& tdi, int nUnits)
{
	double dTime = 0;
	
	// try pre-calculated value first
	if (tdi.dCalcTimeEstimate >= 0)
		return tdi.dCalcTimeEstimate;

	// else update calc'ed value
	tdi.dCalcTimeEstimate = m_data.CalcTimeEstimate(hti, tdi, nUnits);
		
	DWORD dwUniqueID = m_tree.GetItemData(hti);
	m_data.UpdateTask(dwUniqueID, tdi);

	return tdi.dCalcTimeEstimate;
}

double CToDoCtrl::CalcTimeSpent(const HTREEITEM hti, TODOITEM& tdi, int nUnits)
{
	// try pre-calculated value first
	if (tdi.dCalcTimeSpent >= 0)
		return tdi.dCalcTimeSpent;

	// else update calc'ed value
	tdi.dCalcTimeSpent = m_data.CalcTimeSpent(hti, tdi, nUnits);
		
	DWORD dwUniqueID = m_tree.GetItemData(hti);
	m_data.UpdateTask(dwUniqueID, tdi);

	return tdi.dCalcTimeSpent;
}

LRESULT CToDoCtrl::OnGutterWantRedraw(WPARAM wParam, LPARAM lParam)
{
	ASSERT (wParam == IDC_TASKLIST);
	
	BOOL bCancel = FALSE;
	const MSG* pMsg = (MSG*)lParam;

	switch (pMsg->message)
	{
	case TVM_SELECTITEM:
		// we deal with drop highlight changes ourselves
		if (pMsg->wParam == TVGN_DROPHILITE)
		{
			static HTREEITEM htiPrevDropHilite = NULL;

			// we do it ourselves
			m_tree.RedrawGutterItem((DWORD)htiPrevDropHilite);
			m_tree.RedrawGutterItem((DWORD)pMsg->lParam);

			htiPrevDropHilite = (HTREEITEM)pMsg->lParam;
			
			bCancel = TRUE;
		}
		break;
	}

	return bCancel;
}

void CToDoCtrl::DrawGutterItemText(CDC* pDC, const CString& sText, const CRect& rect, int nAlign, COLORREF crText)
{
	if (sText.IsEmpty())
		return;

	CRect rText(rect);

	switch (nAlign)
	{
	case DT_LEFT:
		rText.left += NCG_COLPADDING;
		break;

	case DT_RIGHT:
		rText.right -= NCG_COLPADDING + 1;
		break;
	}
	
	pDC->SetTextColor(crText);
	pDC->SetBkMode(TRANSPARENT);
	pDC->DrawText(sText, rText, DT_SINGLELINE | DT_VCENTER | nAlign);
}

BOOL CToDoCtrl::SetPriorityColors(const CDWordArray& aColors)
{
	ASSERT (!aColors.GetSize() || aColors.GetSize() == 11);

	m_aPriorityColors.RemoveAll();

	if (!aColors.GetSize() || aColors.GetSize() == 11)
	{
		m_aPriorityColors.Copy(aColors);

		if (GetSafeHwnd())
		{
			BuildPriorityCombo();
			CRedrawAll(this);
		}

		return TRUE;
	}
		
	// else
	return FALSE; // invalid combination
}

void CToDoCtrl::BuildPriorityCombo()
{
	ASSERT(m_cbPriority.GetSafeHwnd());

	int nSel = m_cbPriority.GetCurSel(); // so we can restore it

	m_cbPriority.ResetContent();
	bool bUseDefColors = !m_aPriorityColors.GetSize();

	for (int nLevel = 0; nLevel <= 10; nLevel++)
	{
		m_cbPriority.AddColor(bUseDefColors ? DEFPRIORITYCOLORS[nLevel] : m_aPriorityColors[nLevel],
								PRIORITIES[nLevel]);
	}

	m_cbPriority.SetCurSel(nSel);
}

COLORREF CToDoCtrl::GetPriorityColor(int nPriority) const
{
	if (nPriority < 0 || nPriority > 10)
		return GetSysColor(COLOR_WINDOW);

	if (HasStyle(TDCS_COLORPRIORITY) && m_aPriorityColors.GetSize() == 11)
		return (COLORREF)m_aPriorityColors[nPriority];

	// else default grayscale
	return DEFPRIORITYCOLORS[nPriority];
}

void CToDoCtrl::Export2Html(CString& sOutput, DWORD dwOptions, 
							LPCTSTR szFontName, int nFontSize, TDC_FILTER nFilter) const
{
	if (!GetTaskCount() || nFilter == TDCF_NONE)
		return;

	TDCFILTER filter;
	InitExportFilter(filter, nFilter, (dwOptions & TDCE_VISIBLECOLSONLY));

	CXmlItem xi;
	AddChildren(NULL, &xi, filter, HasStyle(TDCS_SHOWDATESINISO));

	ExportItem(&xi, TDCEF_HTML, sOutput, dwOptions, szFontName, nFontSize, -1);
}

void CToDoCtrl::Export2Text(CString& sOutput, DWORD dwOptions, 
							int nIndentWidth, TDC_FILTER nFilter) const
{
	if (!GetTaskCount() || nFilter == TDCF_NONE)
		return;

	TDCFILTER filter;
	InitExportFilter(filter, nFilter, (dwOptions & TDCE_VISIBLECOLSONLY));

	CXmlItem xi;
	AddChildren(NULL, &xi, filter, HasStyle(TDCS_SHOWDATESINISO));

	ExportItem(&xi, TDCEF_TEXT, sOutput, dwOptions, "", -1, nIndentWidth);
}

void CToDoCtrl::ExportSelectedTask2Html(CString& sOutput, DWORD dwOptions, 
							LPCTSTR szFontName, int nFontSize) const
{
	if(!HasSelection())
		return;

	CXmlItem xi;
	CopyCurrentSelection(xi);

	ExportItem(&xi, TDCEF_HTML, sOutput, dwOptions, szFontName, nFontSize, -1);
}

void CToDoCtrl::ExportSelectedTask2Text(CString& sOutput, DWORD dwOptions, int nIndentWidth) const
{
	if(!HasSelection())
		return;

	CXmlItem xi;
	CopyCurrentSelection(xi);

	ExportItem(&xi, TDCEF_TEXT, sOutput, dwOptions, "", -1, nIndentWidth);
}

void CToDoCtrl::ExportItem(const CXmlItem* pXI, TDC_EXPORTFMT nFormat, CString& sOutput, 
						   DWORD dwOptions, LPCTSTR szFontName, int nFontSize, int nIndentWidth) const
{
	sOutput.Empty();

	ASSERT (pXI);

	if (!pXI)
		return;

	// project name
	EXPORTPARAMS ep(m_aStyles);
	ep.sProjectName = (dwOptions & TDCE_INCLUDEPROJECTNAME) ? GetFriendlyProjectName() : "";
	ep.bSpaceForNotes = (dwOptions & TDCE_SPACEFORNOTES);
	ep.bParentTitleCommentsOnly = (dwOptions & TDCE_PARENTTITLECOMMENTSONLY);

	switch (nFormat)
	{
	case TDCEF_HTML:
		{
			CExportToDoListToHtml e2html(ep, m_aPriorityColors, 
										 m_crTaskDone, szFontName, nFontSize);
			e2html.Export(pXI, 0, 1, sOutput);
		}
		break;

	case TDCEF_TEXT:
		{
			CExportToDoListToText e2text(ep, nIndentWidth);
			e2text.Export(pXI, 0, 1, sOutput);
		}
		break;
	}

}

CString CToDoCtrl::GetFriendlyProjectName() const
{
	CString sProjectName(m_sProjectName);
	sProjectName.TrimRight();

	if (sProjectName.IsEmpty())
	{
		if (!m_sLastSavePath.IsEmpty())
		{
			char szFilename[_MAX_FNAME], szExt[_MAX_EXT];
			_splitpath(m_sLastSavePath, NULL, NULL, szFilename, szExt);

			sProjectName.Format("%s%s", szFilename, szExt);
		}
		else
			sProjectName = "(untitled)";
	}

	return sProjectName;
}

void CToDoCtrl::InitExportFilter(TDCFILTER& filter, TDC_FILTER nFilter, BOOL bVisibleColsOnly)
{
	// initialize filter:dateDueBy if necessary
	filter.nFilter = nFilter;
	filter.bVisibleColsOnly = bVisibleColsOnly;

	switch (nFilter)
	{
	case TDCF_DUE:
		filter.dateDueBy = CDateHelper::GetDate(DHD_TODAY);
		break; // done

	case TDCF_DUETOMORROW:
		filter.dateDueBy += CDateHelper::CalcDaysFromTo(filter.dateDueBy, DHD_TOMORROW, 0);
		break;

	case TDCF_DUETHISWEEK:
		filter.dateDueBy += CDateHelper::CalcDaysFromTo(filter.dateDueBy, DHD_ENDTHISWEEK, 0);
		break;

	case TDCF_DUENEXTWEEK:
		filter.dateDueBy += CDateHelper::CalcDaysFromTo(filter.dateDueBy, DHD_ENDNEXTWEEK, 0);
		break;

	case TDCF_DUETHISMONTH:
		filter.dateDueBy += CDateHelper::CalcDaysFromTo(filter.dateDueBy, DHD_ENDTHISMONTH, 0);
		break;

	case TDCF_DUENEXTMONTH:
		filter.dateDueBy += CDateHelper::CalcDaysFromTo(filter.dateDueBy, DHD_ENDNEXTMONTH, 0);
		break;
	}
}

void CToDoCtrl::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	if (pWnd == &m_tree)
	{
		// check for (-1, -1)
		if (point.x == -1 && point.y == -1)
		{
			HTREEITEM htiSel = GetSelectedItem();
			CRect rItem;
			
			if (htiSel)
			{
				m_tree.EnsureVisible(htiSel);
				m_tree.GetItemRect(htiSel, rItem, TRUE);
				point = rItem.CenterPoint();
			}
			else
				point.x = point.y = 10;

			m_tree.ClientToScreen(&point);
		}
		else
		{
			CPoint ptTree(point);
			m_tree.ScreenToClient(&ptTree);

			if (ptTree.x < 0)
				ptTree.x = 0; // because point may be in the gutter

			HTREEITEM htiHit = m_tree.HitTest(ptTree);

			if (!Selection().HasItem(htiHit))
				SelectItem(htiHit);
			else
				m_tree.SelectItem(htiHit);
		}

		// forward to our parent for handling
		GetParent()->SendMessage(WM_CONTEXTMENU, (WPARAM)GetSafeHwnd(), MAKELPARAM(point.x, point.y));
	}
	else if (pWnd == &m_reComments)
	{
		m_sCommentsContextUrl.Empty();	
		
		// check for (-1, -1)
		if (point.x == -1 && point.y == -1)
		{
			point.x = point.y = 10;
			pWnd->ClientToScreen(&point);
		}

		// build the context menu ourselves
		// note: we could use the edit menu from user32.dll but because
		// we're adding items too, the languages would appear odd
		CMenu menu;

		if (menu.CreatePopupMenu())
		{
			int nPos = 0;

			menu.InsertMenu(nPos++, MF_BYPOSITION | MF_STRING, ID_COMMENTS_CUT, "Cu&t");
			menu.InsertMenu(nPos++, MF_BYPOSITION | MF_STRING, ID_COMMENTS_COPY, "&Copy");
			menu.InsertMenu(nPos++, MF_BYPOSITION | MF_STRING, ID_COMMENTS_PASTE, "&Paste");
			menu.InsertMenu(nPos++, MF_BYPOSITION | MF_SEPARATOR);
			menu.InsertMenu(nPos++, MF_BYPOSITION | MF_STRING, ID_COMMENTS_PASTEASREF, "Past&e Tasks as References");
			menu.InsertMenu(nPos++, MF_BYPOSITION | MF_SEPARATOR);
			menu.InsertMenu(nPos++, MF_BYPOSITION | MF_STRING, ID_COMMENTS_SELECTALL, "Select &All");
			menu.InsertMenu(nPos++, MF_BYPOSITION | MF_SEPARATOR);
			menu.InsertMenu(nPos++, MF_BYPOSITION | MF_STRING, ID_COMMENTS_OPENURL, "&Open Url");
			menu.InsertMenu(nPos++, MF_BYPOSITION | MF_STRING, ID_COMMENTS_FILEBROWSE, "&Browse for File");
			menu.InsertMenu(nPos++, MF_BYPOSITION | MF_SEPARATOR);
			menu.InsertMenu(nPos++, MF_BYPOSITION | MF_STRING, ID_COMMENTS_DATESTAMP_LOCAL, "&Insert Datestamp");
//			menu.InsertMenu(nPos++, MF_BYPOSITION | MF_STRING, ID_COMMENTS_DATESTAMP_UTC, "I&nsert Datestamp (UTC)");
			menu.InsertMenu(nPos++, MF_BYPOSITION | MF_SEPARATOR);
			menu.InsertMenu(nPos++, MF_BYPOSITION | MF_STRING, ID_COMMENTS_SPELLCHECK, "&Check Spelling");

			CToolbarHelper::PrepareMenuItems(&menu, this);

			menu.TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON, point.x, point.y, this);
		}
	}
}

void CToDoCtrl::OnCommentsMenuCmd(UINT nCmdID)
{
	switch (nCmdID)
	{
	case ID_COMMENTS_CUT:
		m_reComments.Cut();
		break;

	case ID_COMMENTS_COPY:
		m_reComments.Copy();
		break;

	case ID_COMMENTS_PASTE:
		m_reComments.Paste();
		break;

	case ID_COMMENTS_PASTEASREF:
		if (!IsClipboardEmpty() && s_clipboard.hwndToDoCtrl == GetSafeHwnd())
		{
			// build single string containing each top level item as a different ref
			CString sRefs, sRef;
			CXmlItem* pXIClip = s_clipboard.xiData.GetItem(TDL_TASK);

			while (pXIClip)
			{
				sRef.Format(" %s%d", TDL_PROTOCOL, pXIClip->GetItemValueI(TDL_TASKID));
				sRefs += sRef;

				pXIClip = pXIClip->GetSibling();
			}

			sRefs += ' ';
			m_reComments.ReplaceSel(sRefs, TRUE);
		}
		break;

	case ID_COMMENTS_SELECTALL:
		m_reComments.SetSel(0, -1);
		break;

	case ID_COMMENTS_OPENURL:
		if (!m_sCommentsContextUrl.IsEmpty())
			OnCustomUrl(m_reComments.GetDlgCtrlID(), (LPARAM)(LPCTSTR)m_sCommentsContextUrl);

		// reset
		m_sCommentsContextUrl.Empty();		
		break;

	case ID_COMMENTS_FILEBROWSE:
		{
			CFileDialog dialog(TRUE, NULL, m_sCommentsContextUrl);
			dialog.m_ofn.lpstrTitle = "Select File";
				
			if (dialog.DoModal() == IDOK)
				m_reComments.PathReplaceSel(dialog.GetPathName(), TRUE);

			// reset
			m_sCommentsContextUrl.Empty();		
		}
		break;

	case ID_COMMENTS_DATESTAMP_UTC:
		break;

	case ID_COMMENTS_DATESTAMP_LOCAL:
		{
			COleDateTime date = COleDateTime::GetCurrentTime();
			m_reComments.ReplaceSel(date.Format(), TRUE);
		}
		break;

	case ID_COMMENTS_SPELLCHECK:
		if (m_reComments.GetTextLength())
		{
			CSpellCheckDlg dialog(NULL, GetSelectedTaskComments());

			if (dialog.DoModal() == IDOK)
				SetSelectedTaskComments(dialog.GetCorrectedText());
		}
		break;
	}
}

void CToDoCtrl::OnUpdateCommentsMenuCmd(CCmdUI* pCmdUI)
{
	BOOL bReadOnly = (m_reComments.GetStyle() & ES_READONLY);

	switch (pCmdUI->m_nID)
	{
	case ID_COMMENTS_CUT:
		if (!bReadOnly)
		{
			CHARRANGE crSel;
			m_reComments.GetSel(crSel);
			pCmdUI->Enable(crSel.cpMin != crSel.cpMax);
		}
		else
			pCmdUI->Enable(FALSE);
		break;

	case ID_COMMENTS_COPY:
		{
			CHARRANGE crSel;
			m_reComments.GetSel(crSel);
			pCmdUI->Enable(crSel.cpMin != crSel.cpMax);
		}
		break;

	case ID_COMMENTS_PASTE:
		pCmdUI->Enable(!bReadOnly && m_reComments.CanPaste());
		break;

	case ID_COMMENTS_PASTEASREF:
		pCmdUI->Enable(!bReadOnly && !IsClipboardEmpty() && s_clipboard.hwndToDoCtrl == GetSafeHwnd());
		break;

	case ID_COMMENTS_SELECTALL:
	case ID_COMMENTS_SPELLCHECK:
		pCmdUI->Enable(m_reComments.GetTextLength());
		break;

	case ID_COMMENTS_OPENURL:
		// there's a bit of trickiness on account of MFC.
		// MFC calls this update handler just before sending the command
		// to check that the command hasn't been disabled in the
		// meantime. however because we are using GetMessagePos
		// it fails the second time around. so we check if
		// m_sCommentsContextUrl is set and if it is we enable.
		// must make sure we clear this in the command handler though.
		if (!m_sCommentsContextUrl.IsEmpty())		
			pCmdUI->Enable(TRUE);
		else
		{
			pCmdUI->Enable(FALSE); // default

			if (m_reComments.GetUrlCount())
			{
				CPoint ptCursor(GetMessagePos());
				m_reComments.ScreenToClient(&ptCursor);

				int nUrl = m_reComments.UrlHitTest(ptCursor);

				if (nUrl >= 0)
				{
					m_sCommentsContextUrl = m_reComments.GetUrl(nUrl);
					pCmdUI->Enable(TRUE);
					pCmdUI->SetText(m_sCommentsContextUrl);
				}
			}
		}
		break;

	case ID_COMMENTS_FILEBROWSE:
		if (bReadOnly)
			pCmdUI->Enable(FALSE);
		else
		{
			pCmdUI->Enable(TRUE);

			// cache the current url
			if (m_reComments.GetUrlCount())
			{
				CPoint ptCursor(GetMessagePos());
				m_reComments.ScreenToClient(&ptCursor);

				int nUrl = m_reComments.UrlHitTest(ptCursor);

				if (nUrl >= 0)
					m_sCommentsContextUrl = m_reComments.GetUrl(nUrl, TRUE);
			}
		}
		break;

	case ID_COMMENTS_DATESTAMP_UTC:
	case ID_COMMENTS_DATESTAMP_LOCAL:
		pCmdUI->Enable(!bReadOnly);
		break;
	}
}

void CToDoCtrl::OnEditChangeAllocTo()
{
	UpdateTask(TDCA_ALLOCTO);
}

void CToDoCtrl::OnSelChangeAllocTo()
{
	// special case
	int nSel = m_cbAllocTo.GetCurSel();

	if (nSel != CB_ERR)
		m_cbAllocTo.GetLBText(nSel, m_sAllocTo);

	SetSelectedTaskAllocTo(m_sAllocTo);

	if (IsColumnShowing(TDCC_ALLOCTO))
		m_tree.RedrawGutter();
}

void CToDoCtrl::OnEditChangeAllocBy()
{
	UpdateTask(TDCA_ALLOCBY);
}

void CToDoCtrl::OnSelChangeAllocBy()
{
	// special case
	int nSel = m_cbAllocBy.GetCurSel();

	if (nSel != CB_ERR)
		m_cbAllocBy.GetLBText(nSel, m_sAllocBy);

	SetSelectedTaskAllocBy(m_sAllocBy);

	if (IsColumnShowing(TDCC_ALLOCBY))
		m_tree.RedrawGutter();
}

void CToDoCtrl::OnEditChangeStatus()
{
	UpdateTask(TDCA_STATUS);
}

void CToDoCtrl::OnSelChangeStatus()
{
	// special case
	int nSel = m_cbStatus.GetCurSel();

	if (nSel != CB_ERR)
		m_cbStatus.GetLBText(nSel, m_sStatus);

	SetSelectedTaskStatus(m_sStatus);

	if (IsColumnShowing(TDCC_STATUS))
		m_tree.RedrawGutter();
}

void CToDoCtrl::OnEditChangeCategory()
{
	UpdateTask(TDCA_CATEGORY);
}

void CToDoCtrl::OnSelChangeCategory()
{
	// special case
	int nSel = m_cbCategory.GetCurSel();

	if (nSel != CB_ERR)
		m_cbCategory.GetLBText(nSel, m_sCategory);

	SetSelectedTaskCategory(m_sCategory);

	if (IsColumnShowing(TDCC_CATEGORY))
		m_tree.RedrawGutter();
}

void CToDoCtrl::OnChangeTimeEstimate()
{
	UpdateTask(TDCA_TIMEEST); 
}

void CToDoCtrl::OnChangeTimeSpent()
{
	UpdateTask(TDCA_TIMESPENT); 
}

void CToDoCtrl::OnChangePercent()
{
	// don't handle if this was an 'auto' change
	if (!HasStyle(TDCS_AUTOCALCPERCENTDONE))
		UpdateTask(TDCA_PERCENT);
}

void CToDoCtrl::OnKillFocusPercent()
{
	UpdateTask(TDCA_PERCENT);
}

void CToDoCtrl::OnTreeGetInfoTip(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMTVGETINFOTIP* pTVGIT = (NMTVGETINFOTIP*)pNMHDR;
	TODOITEM tdi;

	if (GetTask((DWORD)pTVGIT->lParam, tdi))
	{
		strncpy(pTVGIT->pszText, FormatInfoTip(pTVGIT->hItem, tdi), pTVGIT->cchTextMax);
	}

	*pResult = 0;
}

CString CToDoCtrl::FormatInfoTip(const HTREEITEM hti, const TODOITEM& tdi) const
{
	// format text multilined
	CString sTip, sTemp;
	
	sTip.Format("Task:\t\t %s",	tdi.sTitle);
	
	if (!tdi.sComments.IsEmpty())
		sTip += "\nComments:\t " + tdi.sComments;
	
	if (IsColumnShowing(TDCC_STATUS) && !tdi.sStatus.IsEmpty())
		sTip += "\nStatus:\t " + tdi.sStatus;
	
	if (IsColumnShowing(TDCC_CATEGORY) && !tdi.sCategory.IsEmpty())
		sTip += "\nCategory:\t " + tdi.sCategory;
	
	if (IsColumnShowing(TDCC_ALLOCTO) && !tdi.sAllocTo.IsEmpty())
		sTip += "\nAssigned To:\t " + tdi.sAllocTo;
	
	if (IsColumnShowing(TDCC_ALLOCBY) && !tdi.sAllocBy.IsEmpty())
		sTip += "\nAssigned By:\t " + tdi.sAllocBy;
	
	if (tdi.IsDone())
	{
		sTip += "\nCompleted:\t " + CDateHelper::FormatDate(tdi.dateDone, HasStyle(TDCS_SHOWDATESINISO));
	}
	else
	{
		if (IsColumnShowing(TDCC_PRIORITY) && tdi.nPriority)
		{
			sTemp.Format("\nPriority:\t\t %d", tdi.nPriority);
			sTip += sTemp;
		}
		
		if (IsColumnShowing(TDCC_STARTDATE) && tdi.HasStart())
			sTip += "\nStart Date:\t " + CDateHelper::FormatDate(tdi.dateStart, HasStyle(TDCS_SHOWDATESINISO));

		if (IsColumnShowing(TDCC_DUEDATE) && tdi.HasDue())
			sTip += "\nDue Date:\t " + CDateHelper::FormatDate(tdi.dateDue, HasStyle(TDCS_SHOWDATESINISO));

		if (IsColumnShowing(TDCC_PERCENT))
		{
			sTemp.Format("\n%% Complete:\t %d", m_data.CalcPercentDone(hti, tdi));
			sTip += sTemp;
		}

		if (IsColumnShowing(TDCC_TIMEEST))
		{
			sTemp.Format("\nTime Est:\t %.2f hrs", m_data.CalcTimeEstimate(hti, tdi, TDCTU_HOURS));
			sTip += sTemp;
		}

		if (IsColumnShowing(TDCC_TIMESPENT))
		{
			sTemp.Format("\nTime Spent:\t %.2f hrs", m_data.CalcTimeSpent(hti, tdi, TDCTU_HOURS));
			sTip += sTemp;
		}
	}
	
	if (IsColumnShowing(TDCC_FILEREF) && !tdi.sFileRefPath.IsEmpty())
	{
		sTemp.Format("\nFile Ref:\t\t %s", tdi.sFileRefPath);
		sTip += sTemp;
	}

	if (tdi.tLastMod > 0)
	{
		sTemp.Format("\nLast Modified:\t %s (%s)", tdi.tLastMod.Format(VAR_DATEVALUEONLY), tdi.tLastMod.Format(VAR_TIMEVALUEONLY));
		sTip += sTemp;
	}

	return sTip;
}

BOOL CToDoCtrl::CopySelectedTaskAsHtml(CString& sOutput, BOOL bVisibleColsOnly, LPCTSTR szFontName) const
{
	if (!HasSelection())
		return FALSE;

	CXmlItem xiSelection;
	CopyCurrentSelection(xiSelection);

	TDCFILTER filter(TDCF_ALL, bVisibleColsOnly);

	CExportToDoListToHtml e2html(EXPORTPARAMS(m_aStyles), m_aPriorityColors, m_crTaskDone, szFontName);
	e2html.Export(&xiSelection, 0, 1, sOutput);

	return TRUE;
}

BOOL CToDoCtrl::CopySelectedTaskAsText(CString& sOutput, BOOL bVisibleColsOnly, int nIndent) const
{
	if (!HasSelection())
		return FALSE;

	CXmlItem xiSelection;
	CopyCurrentSelection(xiSelection);

	TDCFILTER filter(TDCF_ALL, bVisibleColsOnly);

	CExportToDoListToText e2text(EXPORTPARAMS(m_aStyles), nIndent);
	e2text.Export(&xiSelection, 0, 1, sOutput);

	return TRUE;
}

BOOL CToDoCtrl::CopySelectedTaskToClipboardAsHtml(BOOL bVisibleColsOnly, LPCTSTR szFontName) const
{
	CString sOutput;

	BOOL bRes = CopySelectedTaskAsHtml(sOutput, bVisibleColsOnly, szFontName);

	if (bRes)
		CopyTexttoclipboard(sOutput);

	return bRes;
}

BOOL CToDoCtrl::CopySelectedTaskToClipboardAsText(BOOL bVisibleColsOnly, int nIndent) const
{
	CString sOutput;

	BOOL bRes = CopySelectedTaskAsText(sOutput, bVisibleColsOnly, nIndent);

	if (bRes)
		CopyTexttoclipboard(sOutput);

	return bRes;
}

BOOL CToDoCtrl::CopyCurrentSelection(BOOL bCut) const
{
	if (!CopyCurrentSelection(s_clipboard.xiData))
		return FALSE;

	s_clipboard.hwndToDoCtrl = GetSafeHwnd();
	s_clipboard.bCut = bCut;

	// also copy selected task titles to clipboard
	CString sTitles;
	POSITION pos = Selection().GetFirstItemPos();

	while (pos)
	{
		HTREEITEM hti = Selection().GetNextItem(pos);

		sTitles += GetItemText(hti);
		sTitles += "\n";
	}

	CopyTexttoclipboard(sTitles);

	return TRUE;
}

BOOL CToDoCtrl::CopyCurrentSelection(CXmlItem& xiSelection) const
{
	if (!GetSelectedCount())
		return FALSE;

	CHTIList selection;

	ClearCopiedItem();
	Selection().CopySelection(selection);
	Selection().RemoveChildDuplicates(selection, m_tree);

	TDCFILTER filter;
	POSITION pos = selection.GetHeadPosition();

	while (pos)
	{
		HTREEITEM hti = selection.GetNext(pos);

		AddItem(hti, &xiSelection, filter, HasStyle(TDCS_SHOWDATESINISO), 0);
	}

	return (xiSelection.GetItem(TDL_TASK) != NULL);
}

BOOL CToDoCtrl::IsClipboardEmpty() const
{
	return (s_clipboard.xiData.GetItem(TDL_TASK) == NULL);
}

BOOL CToDoCtrl::CopySelectedTask() const
{
	return CopyCurrentSelection(FALSE);
}

BOOL CToDoCtrl::CutSelectedTask()
{
	if (CopyCurrentSelection(TRUE))
	{
		DeleteSelectedTask(FALSE);
		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::CanPaste() const
{
	return (!IsReadOnly() && !IsClipboardEmpty() && GetSelectedCount() <= 1);
}

void CToDoCtrl::ClearCopiedItem() const
{
	s_clipboard.hwndToDoCtrl = NULL;
	s_clipboard.xiData.Reset();
}

BOOL CToDoCtrl::PasteOnSelectedTask()
{
	if (GetSelectedCount() > 1 || !CanPaste())
		return FALSE;

	HTREEITEM htiDest = m_tree.GetSelectedItem();

	if (!htiDest)
		htiDest = TVI_ROOT;

	// we reset the clipboard task IDs either if the tasks did
	// not originate from us (might have overlapping IDs) or if 
	// it was a copy (same reason)
	BOOL bResetID = (s_clipboard.hwndToDoCtrl != GetSafeHwnd()) || !s_clipboard.bCut;

	return AddToItem(s_clipboard.xiData, htiDest, TVI_FIRST, bResetID);
}

BOOL CToDoCtrl::PasteAfterSelectedTask()
{
	if (GetSelectedCount() > 1 || !CanPaste())
		return FALSE;

	HTREEITEM htiDest = NULL, htiDestAfter = m_tree.GetSelectedItem();

	if (!htiDestAfter)
		htiDestAfter = TVI_LAST;
	else
	{
		htiDest = m_tree.GetParentItem(htiDestAfter);

		if (!htiDest)
			htiDest = TVI_ROOT;
	}

	// we reset the clipboard task IDs either if the tasks did
	// not originate from us (might have overlapping IDs) or if 
	// it was a copy (same reason)
	BOOL bResetID = (s_clipboard.hwndToDoCtrl != GetSafeHwnd()) || !s_clipboard.bCut;

	return AddToItem(s_clipboard.xiData, htiDest, htiDestAfter, bResetID);
}

BOOL CToDoCtrl::AddToItem(const CXmlItem& xiSelection, HTREEITEM htiDest, HTREEITEM htiDestAfter, BOOL bResetIDs)
{
	if (!htiDest)
		return FALSE;

	const CXmlItem* pXISel = xiSelection.GetItem(TDL_TASK);

	if (!pXISel)
		return FALSE;

	// clear current selection
	Selection().RemoveAll();

	CHoldRedraw hr(this);
	CHoldRedraw hr2(&m_tree);

	while (pXISel)
	{
		htiDestAfter = AddItem(pXISel, htiDest, htiDestAfter, bResetIDs);

		// add item to selection
		Selection().AddItem(htiDestAfter);
			
		// next task
		pXISel = pXISel->GetSibling();
	}

	m_tree.Expand(htiDest, TVE_EXPAND);
	
	if (GetSelectedCount())
		m_tree.SelectItem(Selection().GetFirstItem());

	SetModified(TRUE, TDCA_NONE);
	UpdateControls();

	return TRUE;
}

void CToDoCtrl::CopyTexttoclipboard(const CString& sText) const 
{
	if (sText.IsEmpty())
		return;
	
	if (!::OpenClipboard(GetSafeHwnd())) 
		return; 

    ::EmptyClipboard(); 
 
    // Allocate a global memory object for the text. 
	HGLOBAL hglbCopy = GlobalAlloc(GMEM_MOVEABLE, (sText.GetLength() + 1) * sizeof(TCHAR)); 

	if (!hglbCopy) 
	{ 
		CloseClipboard(); 
		return; 
	} 
	
	// Lock the handle and copy the text to the buffer. 
	LPTSTR lptstrCopy = (LPTSTR)GlobalLock(hglbCopy); 

	memcpy(lptstrCopy, (LPVOID)(LPCTSTR)sText, sText.GetLength() * sizeof(TCHAR)); 

	lptstrCopy[sText.GetLength()] = (TCHAR) 0;    // null character 
	GlobalUnlock(hglbCopy); 
	
	// Place the handle on the clipboard. 
	::SetClipboardData(CF_TEXT, hglbCopy); 

	::CloseClipboard();
}

LRESULT CToDoCtrl::OnGutterNotifyItemClick(WPARAM wParam, LPARAM lParam)
{
	NCGITEMCLICK* pNGIC = (NCGITEMCLICK*)lParam;
	HTREEITEM htiHit = (HTREEITEM)pNGIC->dwItem;
	
	if (htiHit)
	{
		CPoint point(::GetMessagePos());
		m_tree.ScreenToClient(&point);
		
		UINT nHitFlags = 0;
		m_tree.HitTest(point, &nHitFlags);
		
		switch (pNGIC->nMsgID)
		{
		case WM_LBUTTONDOWN:
			{
				// see if the click was on the 'done' checkbox
				if (!IsReadOnly() && (nHitFlags & TVHT_ONITEMSTATEICON))
				{
					// if the hit item is not selected then 
					// select it first
					if (!IsItemSelected(htiHit))
						SelectItem(htiHit);
					
					SetSelectedTaskDone(!m_data.IsTaskDone(htiHit));
					
					// save item handle so we don't rehandle in LButtonUp handler
					m_selection.htiLastHandledLBtnDown = htiHit;
				}
				// else if _NOT_ on expand button
				else if (!(nHitFlags & TVHT_ONITEMBUTTON))
				{
					ProcessItemLButtonDown(htiHit, nHitFlags);
				}
			}
			break;
			
		case WM_NCLBUTTONDOWN:
			{
				// if control is down and we're clicking on the file ref
				// then always display the file ref if its got one
				BOOL bCtrl = (GetKeyState(VK_CONTROL) & 0x8000);
				
				if (bCtrl && pNGIC->nColID == TDCC_FILEREF)
				{
					CString sFile = m_data.GetTaskFileRef(GetTaskID(htiHit));
					
					if (!sFile.IsEmpty())
					{
						GotoFile(sFile, TRUE);
						
						// save item handle so we don't rehandle in LButtonUp handler
						m_selection.htiLastHandledLBtnDown = htiHit;
					}
				}
				// if we're not readonly and we're clicking on the 
				// done checkbox then change all items to be the 
				// inverse of which ever the hit task's state was
				else if (!IsReadOnly() && pNGIC->nColID == TDCC_DONE)
				{
					// if the hit item is not selected then 
					// select it first
					if (!IsItemSelected(htiHit))
						SelectItem(htiHit);
					
					// check it falls on the checkbox
					CRect rItem;
					m_tree.GetItemRect(htiHit, rItem, FALSE);
					
					m_tree.ClientToScreen(rItem);
					rItem.DeflateRect(0, (rItem.Height() - 16) / 2);
					
					if (pNGIC->ptClick.y >= rItem.top && pNGIC->ptClick.y < rItem.bottom)
					{
						SetSelectedTaskDone(!m_data.IsTaskDone(htiHit));
						
						// save item handle so we don't rehandle in LButtonUp handler
						m_selection.htiLastHandledLBtnDown = htiHit;
					}
				}
				else if (!IsReadOnly() && pNGIC->nColID == TDCC_TRACKTIME)
				{
					// if the hit item is not selected then 
					// select it first
					if (!IsItemSelected(htiHit))
						SelectItem(htiHit);

					if (GetSelectedCount() == 1)
					{
						// check it falls on the clock icon
						CRect rItem;
						m_tree.GetItemRect(htiHit, rItem, FALSE);
						
						m_tree.ClientToScreen(rItem);
						rItem.DeflateRect(0, (rItem.Height() - 16) / 2);
						
						if (pNGIC->ptClick.y >= rItem.top && pNGIC->ptClick.y < rItem.bottom)
							TimeTrackTask(htiHit);
					}
				}
				else 
					ProcessItemLButtonDown(htiHit, nHitFlags);
			}
			break;
			
			// we handle these in the event that they weren't handled in the 
			// DOWN message handlers above
		case WM_NCLBUTTONUP:
		case WM_LBUTTONUP:
			ProcessItemLButtonUp(htiHit, (HTREEITEM)pNGIC->dwPrevItem, nHitFlags);
			break;

		case WM_RBUTTONDOWN:
		case WM_NCRBUTTONDOWN:
			// if the hit item is not selected then 
			// select it first
			if (!IsItemSelected(htiHit))
				SelectItem(htiHit);
			break;
		}
	}
	// if nowt clicked then clear selection
	else if (Selection().RemoveAll()) // !hti
	{
		m_tree.SelectItem(NULL);
		m_tree.RedrawGutter();
	}

	m_treeDragDrop.EnableDragDrop(GetSelectedCount());

	return 1L; // we handled it
}

void CToDoCtrl::TimeTrackTask(HTREEITEM hti)
{
	ASSERT (GetSelectedCount() == 1); // sanity check

	DWORD dwTaskID = GetTaskID(hti);

	if (dwTaskID == m_dwTimeTrackTaskID)
		m_dwTimeTrackTaskID = 0; // toggle off
	
	else if (m_data.IsTaskTimeTrackable(hti))
	{
		m_dwTimeTrackTaskID = dwTaskID;

		// if the task's start date has not been set then set it now
		TODOITEM tdi;
		VERIFY(GetTask(dwTaskID, tdi));

		if (tdi.dateStart == 0)
		{
			tdi.dateStart = COleDateTime::GetCurrentTime();
			UpdateTask(dwTaskID, tdi);
		}
	}
	
	if (hti == GetSelectedItem())
		UpdateControls();

	if (IsColumnShowing(TDCC_TRACKTIME))
		m_tree.RedrawGutterItem((DWORD)hti);
}

void CToDoCtrl::ProcessItemLButtonDown(HTREEITEM htiHit, int nHitFlags)
{
	BOOL bCtrl = (GetKeyState(VK_CONTROL) & 0x8000); // ctrl key down
	BOOL bShift = (GetKeyState(VK_SHIFT) & 0x8000); // shift key down

	HTREEITEM htiAnchor = Selection().GetAnchor();
	
	if (!htiAnchor && bShift)
		htiAnchor = htiHit;
	
	if (bCtrl)
	{
		if (bShift)
			MultiSelectItems(htiAnchor, htiHit, 1);
		else
			MultiSelectItem(htiHit, -1);

		// save item handle so we don't rehandle in LButtonUp handler
		m_selection.htiLastHandledLBtnDown = htiHit;
	}
	else if (bShift) 
	{
		Selection().RemoveAll();
		MultiSelectItems(htiAnchor, htiHit, 1);

		// save item handle so we don't rehandle in LButtonUp handler
		m_selection.htiLastHandledLBtnDown = htiHit;
	}
	else if (!Selection().HasItem(htiHit))
	{
		// if the user clicked on the tree item itself then
		// don't call SelectItem here else in combination with the 
		// tree's own handling of this message it can trigger a label edit
		if (nHitFlags & TVHT_ONITEM)
		{
			Selection().RemoveAll();
			Selection().AddItem(htiHit);
		}
		else
			SelectItem(htiHit);

		// and because we don't call SelectItem we must do some
		// housekeeping
		m_selection.htiLastSingleSelection = htiHit;

		// save item handle so we don't rehandle in LButtonUp handler
		m_selection.htiLastHandledLBtnDown = htiHit;
	}
	
	// update anchor
	if (!bShift)
		Selection().SetAnchor(htiHit);
}

void CToDoCtrl::ProcessItemLButtonUp(HTREEITEM htiHit, HTREEITEM htiPrev, int nHitFlags)
{
	if (!htiHit || htiHit == m_selection.htiLastHandledLBtnDown)
	{
		m_selection.htiLastHandledLBtnDown = NULL;
		return; // handled in button down
	}

	BOOL bCtrl = (GetKeyState(VK_CONTROL) & 0x8000); // ctrl key down
	BOOL bShift = (GetKeyState(VK_SHIFT) & 0x8000); // shift key down

	// if ctrl or shift are not pressed and we've 
	// only got one item selected and its the same 
	// as htiHit and htiPrev then we've nothing to do
	// else clear all and select the hit item
	if (!bCtrl && !bShift && htiHit == htiPrev)
	{
		ASSERT (GetSelectedCount());

		if (GetSelectedCount() > 1 || GetSelectedItem() != htiHit)
		{
			// if the user clicked on the tree item itself then
			// don't call SelectItem here else in combination with the 
			// tree's own handling of this message it can trigger a label edit
			if (nHitFlags & TVHT_ONITEM)
			{
				Selection().RemoveAll();
				Selection().AddItem(htiHit);
			}
			else
				SelectItem(htiHit);
		}
		// if we're clicking on the label of a previously 
		// singly-selected item then start an edit 
		else if (htiHit == m_selection.htiLastSingleSelection &&
				((nHitFlags & TVHT_ONITEMLABEL) == TVHT_ONITEMLABEL))
		{
			// begin label edit
			m_tree.PostMessage(TVM_EDITLABEL, 0, (LPARAM)htiHit);
		}

		m_selection.htiLastSingleSelection = htiHit;

		// update anchor
		Selection().SetAnchor(htiHit);
	}
	// else if we were dragging but we're not anymore and
	// the items are different then shift the focus back to the prev item
	else if (htiHit != htiPrev && !m_treeDragDrop.IsDragging())
	{
		// post this message so that the tree's finished its stuff first
		PostMessage(WM_TDC_RESTOREFOCUSEDITEM, m_tree.GetDlgCtrlID(), (LPARAM)htiPrev);

		// update anchor
		Selection().SetAnchor(htiPrev);
	}
}

LRESULT CToDoCtrl::OnTreeRestoreFocusedItem(WPARAM wParam, LPARAM lParam)
{
	if (wParam == IDC_TASKLIST)
		m_tree.SelectItem((HTREEITEM)lParam);

	return 0L;
}

BOOL CToDoCtrl::MultiSelectItem(HTREEITEM hti, int nState, BOOL bRedraw) 
{ 
	if (Selection().SetItem(hti, nState, bRedraw))
	{
		if (bRedraw)
			m_tree.RedrawGutter();

		UpdateControls(); // load newly selected item
		UpdateSelectedTaskPath();

		m_selection.htiLastSingleSelection = NULL;

		// re-enable dragdrop
		m_treeDragDrop.EnableDragDrop(GetSelectedCount());

		return TRUE;
	}

	return FALSE;
}

BOOL CToDoCtrl::MultiSelectItems(HTREEITEM htiFrom, HTREEITEM htiTo, int nState, BOOL bRedraw)
{
	if (Selection().SetItems(htiFrom, htiTo, nState, bRedraw))
	{
		if (bRedraw)
			m_tree.RedrawGutter();

		UpdateControls(); // load newly selected items
		UpdateSelectedTaskPath();

		m_selection.htiLastSingleSelection = NULL;

		// re-enable dragdrop
		m_treeDragDrop.EnableDragDrop(GetSelectedCount());

		return TRUE;
	}

	return FALSE;
}

void CToDoCtrl::SelectItem(HTREEITEM hti) 
{ 
	if (m_tree.GetSafeHwnd()) 
	{
		if (Selection().RemoveAll() && !hti)
			m_tree.RedrawGutter();

		if (hti)
		{
			Selection().AddItem(hti);
			Selection().SetAnchor(hti);

			m_tree.SelectItem(hti); // will cause a sel change to update the controls 
			m_tree.EnsureVisible(hti);

			m_selection.htiLastSingleSelection = hti;
		}

		m_treeDragDrop.EnableDragDrop(TRUE);
	}
}

void CToDoCtrl::DeselectAll() 
{ 
	if (Selection().RemoveAll())
	{
		m_tree.RedrawGutter();

		UpdateControls(); // load newly selected item
		UpdateSelectedTaskPath();
	}

	// re-enable dragdrop
	m_treeDragDrop.EnableDragDrop(FALSE);
}

LRESULT CToDoCtrl::OnGutterIsItemSelected(WPARAM wParam, LPARAM lParam)
{
	NCGITEMSELECTION* pNCGIS = (NCGITEMSELECTION*)lParam;
	pNCGIS->bSelected = IsItemSelected((HTREEITEM)pNCGIS->dwItem);
	
	return TRUE;
}

LRESULT CToDoCtrl::OnGutterGetSelectedCount(WPARAM wParam, LPARAM lParam)
{
	int* pCount = (int*)lParam;
	*pCount = Selection().GetCount();

	return TRUE;
}

LRESULT CToDoCtrl::OnGutterNotifyHeaderClick(WPARAM wParam, LPARAM lParam)
{
	NCGHDRCLICK* pNGHC = (NCGHDRCLICK*)lParam;

	if (pNGHC->nMsgID != WM_NCLBUTTONUP)
	{
		pNGHC->bPressed = FALSE;
		return TRUE;
	}

	TDC_SORTBY nSortBy = (TDC_SORTBY)-1;

	// convert index to TDC_COLUMN
	TDCCOLUMN* pTDCC = GetColumn(pNGHC->nColID);
	
	if (!pTDCC) // not one of ours so preserve existing sort selection
		return TRUE; // we handled it
	
	if (!IsColumnShowing(pTDCC->nColID))
		return TRUE; // we handled it
	
	switch (pTDCC->nColID)
	{
	case NCG_CLIENTCOLUMNID:nSortBy = TDC_SORTBYNAME;		break;
	case TDCC_PRIORITY:		nSortBy = TDC_SORTBYPRIORITY;	break;
	case TDCC_ID:			nSortBy = TDC_SORTBYID;			break;
	case TDCC_ALLOCTO:		nSortBy = TDC_SORTBYALLOCTO;	break;
	case TDCC_ALLOCBY:		nSortBy = TDC_SORTBYALLOCBY;	break;
	case TDCC_STATUS:		nSortBy = TDC_SORTBYSTATUS;		break;
	case TDCC_CATEGORY:		nSortBy = TDC_SORTBYCATEGORY;	break;
	case TDCC_TIMEEST:		nSortBy = TDC_SORTBYTIMEEST;	break;
	case TDCC_TIMESPENT:	nSortBy = TDC_SORTBYTIMESPENT;	break;
	case TDCC_PERCENT:		nSortBy = TDC_SORTBYPERCENT;	break;
	case TDCC_STARTDATE:	nSortBy = TDC_SORTBYSTARTDATE;	break;
	case TDCC_DUEDATE:		nSortBy = TDC_SORTBYDUEDATE;	break;
	case TDCC_DONEDATE:		nSortBy = TDC_SORTBYDONEDATE;	break;
	case TDCC_DONE:			nSortBy = TDC_SORTBYDONE;		break;
		
	default: break;
	}

	if (nSortBy != (TDC_SORTBY)-1)
	{
		Sort(nSortBy);
		pNGHC->bPressed = FALSE;

		// notify parent
		GetParent()->SendMessage(WM_TDCN_SORT);

		return TRUE; // we handled it
	}

	return 0;
}

LRESULT CToDoCtrl::OnGutterRecalcColWidth(WPARAM wParam, LPARAM lParam)
{
	NCGRECALCCOLUMN* pNCRC = (NCGRECALCCOLUMN*)lParam;

	// convert colpos to TDC_COLUMN
	TDCCOLUMN* pTDCC = GetColumn(pNCRC->nColID);

	if (!pTDCC)
		return FALSE;
	
	if (!IsColumnShowing(pTDCC->nColID))
	{
		pNCRC->nWidth = 0;
		return TRUE;
	}

	switch (pTDCC->nColID)
	{
	case TDCC_ID:
		{
			CString sMaxID;
			sMaxID.Format("%u", m_dwNextUniqueID - 1);
			pNCRC->nWidth = pNCRC->pDC->GetTextExtent(sMaxID).cx;
		}
		break; 

	case TDCC_PRIORITY:
		pNCRC->nWidth = 10;
		break; 
		
	case TDCC_FILEREF:
		pNCRC->nWidth = HasStyle(TDCS_SHOWNONFILEREFSASTEXT) ? 60 : 16; 
		break; 
		
	case TDCC_ALLOCTO:
		pNCRC->nWidth = m_cbAllocTo.CalcMaxTextWidth(pNCRC->pDC, 20);
		break;
		
	case TDCC_ALLOCBY:
		pNCRC->nWidth = m_cbAllocBy.CalcMaxTextWidth(pNCRC->pDC, 20);
		break;
		
	case TDCC_STATUS:
		pNCRC->nWidth = m_cbStatus.CalcMaxTextWidth(pNCRC->pDC, 20);
		break;
		
	case TDCC_CATEGORY:
		pNCRC->nWidth = m_cbCategory.CalcMaxTextWidth(pNCRC->pDC, 20);
		break;
		
	case TDCC_TIMEEST:
		{
			int nWidth = 1;

			// else calc the greatest cumulative time estimate of the top level items
			HTREEITEM hti = m_tree.GetNextItem(NULL, TVGN_CHILD);
			double dMaxTime = 0;
			
			while (hti)
			{
				TODOITEM tdi;
				
				if (GetTask(GetTaskID(hti), tdi))
				{
					double dTime = m_data.CalcTimeEstimate(hti, tdi, TDCTU_HOURS);
					dMaxTime = max(dMaxTime, dTime);
				}
				
				hti = m_tree.GetNextItem(hti, TVGN_NEXT);
			}

			if (dMaxTime > 0 || !HasStyle(TDCS_HIDEZEROTIMEEST))
			{
				int nDecPlaces = HasStyle(TDCS_ROUNDTIMEFRACTIONS) ? 0 : 2;
				
				CString sTime = CTimeEdit::FormatTime(dMaxTime, TEU_HOURS, nDecPlaces);
				nWidth = pNCRC->pDC->GetTextExtent(sTime).cx;
			}

			pNCRC->nWidth = nWidth;
		}
		break;
		
	case TDCC_TIMESPENT:
		{
			int nWidth = 1;

			// else calc the greatest cumulative time spent of the top level items
			HTREEITEM hti = m_tree.GetNextItem(NULL, TVGN_CHILD);
			double dMaxTime = 0;
			
			while (hti)
			{
				TODOITEM tdi;
				
				if (GetTask(GetTaskID(hti), tdi))
				{
					double dTime = m_data.CalcTimeSpent(hti, tdi, TDCTU_HOURS);
					dMaxTime = max(dMaxTime, dTime);
				}
				
				hti = m_tree.GetNextItem(hti, TVGN_NEXT);
			}
			
			if (dMaxTime > 0 || !HasStyle(TDCS_HIDEZEROTIMEEST))
			{
				int nDecPlaces = HasStyle(TDCS_ROUNDTIMEFRACTIONS) ? 0 : 2;
				
				CString sTime = CTimeEdit::FormatTime(dMaxTime, TEU_HOURS, 2);
				nWidth = pNCRC->pDC->GetTextExtent(sTime).cx;
			}
				
			pNCRC->nWidth = nWidth;
		}
		break;

	case TDCC_TRACKTIME:
		pNCRC->nWidth = 16;
		break;
		
	case TDCC_PERCENT:
		pNCRC->nWidth = pNCRC->pDC->GetTextExtent("100%").cx;
		break;

	case TDCC_STARTDATE:
	case TDCC_DUEDATE:
	case TDCC_DONEDATE:
		{
			BOOL bShowWeekday = HasStyle(TDCS_SHOWWEEKDAYINDATES);
			BOOL bISO = HasStyle(TDCS_SHOWDATESINISO);

			CString sDate = CDateHelper::FormatDate(COleDateTime(2000, 12, 30,0, 0, 0), bISO);
			int nWidth = pNCRC->pDC->GetTextExtent(sDate).cx;

			if (HasStyle(TDCS_SHOWWEEKDAYINDATES))
			{
				int nLongestWD = 0;

				for (int nWD = 1; nWD <= 7; nWD++)
				{
					int nWDWidth = pNCRC->pDC->GetTextExtent(CDateHelper::GetShortWeekday(nWD)).cx;
					nLongestWD = max(nLongestWD, nWDWidth);
				}

				nWidth += nLongestWD + 4;
			}

			pNCRC->nWidth = nWidth;
		}
		break;

	case TDCC_DONE:
		// hide this when the done checkbox is displayed in the tree
		if (HasStyle(TDCS_TREECHECKBOXES))
			pNCRC->nWidth = 0;
		else
			pNCRC->nWidth = (18 -  2 * NCG_COLPADDING);
		break;

	default:
		ASSERT (0);
		break;
	}

	return TRUE;
}

int CToDoCtrl::AddChildren(HTREEITEM hti, CXmlItem* pXI, const TDCFILTER& filter, BOOL bISODates) const
{
	// if hti == NULL it means the root
	HTREEITEM htiChild = hti ? m_tree.GetChildItem(hti) : m_tree.GetNextItem(NULL, TVGN_CHILD);
	int nChildren = 0;
	int nPos = 1; // positions are 1-based

	while (htiChild)
	{
		if (AddItem(htiChild, pXI, filter, nPos, bISODates))
			nChildren++;

		// next
		nPos++;
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}

	return nChildren;
}

BOOL CToDoCtrl::AddItem(HTREEITEM hti, CXmlItem* pXI, const TDCFILTER& filter, int nPos, BOOL bISODates) const
{
	// attributes
	TODOITEM tdi;
	DWORD dwID = GetTaskID(hti);

	if (GetTask(dwID, tdi))
	{
		// special optimization check for TDC_FULLYDONE and TDC_NOTFULLYDONE
		if (filter.nFilter == TDCF_FULLYDONE || filter.nFilter == TDCF_NOTFULLYDONE)
		{
			BOOL bDone = m_data.IsTaskFullyDone(hti, tdi, TRUE);

			if (filter.nFilter == TDCF_FULLYDONE && !bDone)
				return FALSE;

			else if (filter.nFilter == TDCF_NOTFULLYDONE && bDone)
				return FALSE;

			// else continue
		}

		CXmlItem* pXIItem = pXI->AddItem(TDL_TASK);

		// unique ID
		if (WantExportColumn(TDCC_ID, filter.bVisibleColsOnly))
			pXIItem->AddItem(TDL_TASKID, (int)dwID);

		// last mod
		pXIItem->AddItem(TDL_TASKLASTMOD, tdi.tLastMod);
	
		// attributes
		pXIItem->AddItem(TDL_TASKTITLE, tdi.sTitle);
		
		AddAttributeToItem(pXIItem, TDL_TASKCOMMENTS, tdi.sComments);
		AddAttributeToItem(pXIItem, TDL_TASKALLOCTO, tdi.sAllocTo, TDCC_ALLOCTO, filter);
		AddAttributeToItem(pXIItem, TDL_TASKALLOCBY, tdi.sAllocBy, TDCC_ALLOCBY, filter);
		AddAttributeToItem(pXIItem, TDL_TASKSTATUS, tdi.sStatus, TDCC_STATUS, filter);
		AddAttributeToItem(pXIItem, TDL_TASKCATEGORY, tdi.sCategory, TDCC_CATEGORY, filter);
		AddAttributeToItem(pXIItem, TDL_TASKFILEREFPATH, tdi.sFileRefPath, TDCC_FILEREF, filter);
		
		if (tdi.color)
		{
			pXIItem->AddItem(TDL_TASKCOLOR, (int)tdi.color);
			
			// this is to help display the date in a web page
			CString sWebColor;
			sWebColor.Format("#%02X%02X%02X", GetRValue(tdi.color), GetGValue(tdi.color), GetBValue(tdi.color));
			pXIItem->AddItem(TDL_TASKWEBCOLOR, sWebColor);
		}
		
		AddAttributeToItem(pXIItem, TDL_TASKPRIORITY, tdi.nPriority, TDCC_PRIORITY, filter);

		// percent done
		if (tdi.IsDone())
			AddAttributeToItem(pXIItem, TDL_TASKPERCENTDONE, 100, TDCC_PERCENT, filter);

		else if (tdi.nPercentDone)
			AddAttributeToItem(pXIItem, TDL_TASKPERCENTDONE, tdi.nPercentDone, TDCC_PERCENT, filter);

		// time estimate
		if (tdi.dTimeEstimate > 0)
			AddAttributeToItem(pXIItem, TDL_TASKTIMEESTIMATE, tdi.dTimeEstimate, TDCC_TIMEEST, filter);

		AddAttributeToItem(pXIItem, TDL_TASKTIMEESTUNITS, m_data.MapTimeUnits(tdi.nTimeEstUnits), 
								TDCC_TIMEEST, filter);
		
		// time spent
		if (tdi.dTimeSpent > 0)
			AddAttributeToItem(pXIItem, TDL_TASKTIMESPENT, tdi.dTimeSpent, TDCC_TIMESPENT, filter);

		AddAttributeToItem(pXIItem, TDL_TASKTIMESPENTUNITS, m_data.MapTimeUnits(tdi.nTimeSpentUnits), 
								TDCC_TIMESPENT, filter);
		
		// done date
		if (tdi.IsDone())
		{
			AddAttributeToItem(pXIItem, TDL_TASKDONEDATE, tdi.dateDone, TDCC_DONEDATE, filter);
			AddAttributeToItem(pXIItem, TDL_TASKDONEDATESTRING, CDateHelper::FormatDate(tdi.dateDone, bISODates), 
								TDCC_DONEDATE, filter);
		}
		
		// add due date if we're filtering by due date
		if (tdi.HasDue() && (filter.dateDueBy > 0 || WantExportColumn(TDCC_DUEDATE, filter.bVisibleColsOnly)))
		{
			pXIItem->AddItem(TDL_TASKDUEDATE, tdi.dateDue);
			
			// this is to help display the date in a web page
			pXIItem->AddItem(TDL_TASKDUEDATESTRING, CDateHelper::FormatDate(tdi.dateDue, bISODates));		
		}
		
		// start date
		if (tdi.HasStart())
		{
			AddAttributeToItem(pXIItem, TDL_TASKSTARTDATE, tdi.dateStart, TDCC_DONEDATE, filter);
			AddAttributeToItem(pXIItem, TDL_TASKSTARTDATESTRING, CDateHelper::FormatDate(tdi.dateStart, bISODates), 
								TDCC_DONEDATE, filter);
		}

		// items position
		AddAttributeToItem(pXIItem, TDL_TASKPOS, nPos, TDCC_POSITION, filter);

		// children
		int nChildren = AddChildren(hti, pXIItem, filter, bISODates);

		// we return TRUE if we match the filter or we have any matching children
		BOOL bMatch = nChildren;

		switch (filter.nFilter)
		{
		case TDCF_ALL:
		case TDCF_FULLYDONE: // we did a check at the start
		case TDCF_NOTFULLYDONE: // we did a check at the start
			bMatch = TRUE; // always
			break;
			
		case TDCF_DUE:
		case TDCF_DUETOMORROW:
		case TDCF_DUETHISWEEK:
		case TDCF_DUENEXTWEEK:
		case TDCF_DUETHISMONTH:
		case TDCF_DUENEXTMONTH:
			bMatch |= tdi.IsDue(filter.dateDueBy);
			break;
			
		case TDCF_DONE:
			bMatch |= tdi.IsDone();
			break;
			
		case TDCF_NOTDONE:
			bMatch |= !tdi.IsDone();
			break;

		default:
			bMatch = FALSE;
		}
		
		// if we don't match, we remove the item
		if (!bMatch)
			pXI->DeleteItem(pXIItem);

		return bMatch;
	}

	return FALSE;
}

void CToDoCtrl::AddAttributeToItem(CXmlItem* pXI, LPCTSTR szKey, const CString& sAttrib, TDC_COLUMN nCol,
								   const TDCFILTER& filter) const
{
	if (!sAttrib.IsEmpty() && WantExportColumn(nCol, filter.bVisibleColsOnly))
		pXI->AddItem(szKey, sAttrib);
}

void CToDoCtrl::AddAttributeToItem(CXmlItem* pXI, LPCTSTR szKey, int nAttrib, TDC_COLUMN nCol,
								   const TDCFILTER& filter) const
{
	if (WantExportColumn(nCol, filter.bVisibleColsOnly))
		pXI->AddItem(szKey, nAttrib);
}

void CToDoCtrl::AddAttributeToItem(CXmlItem* pXI, LPCTSTR szKey, const double& dAttrib, TDC_COLUMN nCol,
								   const TDCFILTER& filter) const
{
	if (WantExportColumn(nCol, filter.bVisibleColsOnly))
		pXI->AddItem(szKey, dAttrib);
}

void CToDoCtrl::AddAttributeToItem(CXmlItem* pXI, LPCTSTR szKey, const CString& sAttrib) const
{
	if (!sAttrib.IsEmpty())
		pXI->AddItem(szKey, sAttrib);
}

void CToDoCtrl::OnGotoFileRef()
{
	if (!m_sFileRefPath.IsEmpty())
	{
		if (m_sFileRefPath.Find(TDL_PROTOCOL) != -1)
			OnCustomUrl(m_reComments.GetDlgCtrlID(), (LPARAM)(LPCTSTR)m_sFileRefPath);
		else
			ShellExecute(*this, NULL, m_sFileRefPath, NULL, NULL, SW_SHOWNORMAL); 
	}
}

void CToDoCtrl::OnSetFocus(CWnd* pOldWnd) 
{
	CRuntimeDlg::OnSetFocus(pOldWnd);
	
	// ensure the selected tree item is visible
	m_tree.EnsureVisible(m_tree.GetSelectedItem());

	// and focused
	m_tree.SetFocus();
}

LRESULT CToDoCtrl::OnDropFileRef(WPARAM wParam, LPARAM lParam)
{
	if (IsReadOnly())
		return 0;

	HTREEITEM hti = (HTREEITEM)wParam;

	if (hti)
	{
		SelectItem(hti);
		SetSelectedTaskFileRef((LPCTSTR)lParam);
	}
	else // its the file ref edit field
	{
		m_eFileRef.SetWindowText((LPCTSTR)lParam);
	}

	return 0;
}

void CToDoCtrl::SaveSortState()
{
	// create a new key using the filepath
	ASSERT (GetSafeHwnd());

	if (!m_sLastSavePath.IsEmpty())
	{
		CString sKey, sFilePath(m_sLastSavePath);
		sFilePath.Replace('\\', '_');
		sKey.Format("SortState\\%s", sFilePath);

		AfxGetApp()->WriteProfileInt(sKey, "Column", m_nSortBy);
		AfxGetApp()->WriteProfileInt(sKey, "Ascending", m_bSortAscending);
	}
}

void CToDoCtrl::LoadSortState(LPCTSTR szFilePath)
{
	CString sFilePath(szFilePath);

	if (sFilePath.IsEmpty())
		sFilePath = m_sLastSavePath;

	if (!sFilePath.IsEmpty())
	{
		sFilePath.Replace('\\', '_');

		CString sKey;
		sKey.Format("SortState\\%s", sFilePath);

		m_nSortBy = (TDC_SORTBY)AfxGetApp()->GetProfileInt(sKey, "Column", TDC_SORTBYPRIORITY);
		m_bSortAscending = AfxGetApp()->GetProfileInt(sKey, "Ascending", TRUE);
	}
}

void CToDoCtrl::SaveSplitPos()
{
	ASSERT (GetSafeHwnd());

	if (!m_sLastSavePath.IsEmpty())
	{
		int nCommentHeight = HasStyle(TDCS_SHAREDCOMMENTSHEIGHT) ? s_nCommentsHeight : m_nCommentsHeight;
		AfxGetApp()->WriteProfileInt("SplitPos", m_sLastSavePath, nCommentHeight);
	}
}

void CToDoCtrl::LoadSplitPos()
{
	if (!m_sLastSavePath.IsEmpty())
		m_nCommentsHeight = AfxGetApp()->GetProfileInt("SplitPos", m_sLastSavePath, DEFCOMMENTHEIGHT);

	if (!s_nCommentsHeight)
		s_nCommentsHeight = m_nCommentsHeight;
}

void CToDoCtrl::SaveExpandedState()
{
	// create a new key using the filepath and simply save the ID 
	// of every expanded item
	ASSERT (GetSafeHwnd());

	if (!m_sLastSavePath.IsEmpty())
	{
		CString sKey, sFilePath(m_sLastSavePath);
		sFilePath.Replace('\\', '_');
		sKey.Format("ExpandedState\\%s", sFilePath);

		int nCount = SaveExpandedState(sKey);

		// save expanded count
		AfxGetApp()->WriteProfileInt(sKey, "Count", nCount);

		// and selected item
		AfxGetApp()->WriteProfileInt(sKey, "SelItem", GetSelectedTaskID());
	}
}

int CToDoCtrl::SaveExpandedState(LPCTSTR szRegKey, HTREEITEM hti, int nStart)
{
	HTREEITEM htiChild = hti ? m_tree.GetChildItem(hti) : m_tree.GetNextItem(NULL, TVGN_CHILD);
	int nCount = nStart;

	while (htiChild)
	{
		if (m_tree.IsItemExpanded(htiChild))
		{
			CString sItem;
			sItem.Format("Item%d", nCount);

			AfxGetApp()->WriteProfileInt(szRegKey, sItem, (int)GetTaskID(htiChild));
			nCount++;

			// now its children
			nCount += SaveExpandedState(szRegKey, htiChild, nCount);
		}

		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}	
	
	return (nCount - nStart);
}

HTREEITEM CToDoCtrl::LoadExpandedState(BOOL bResetSel)
{
	ASSERT (GetSafeHwnd());
	
	CString sKey, sFilePath(m_sLastSavePath);
	sFilePath.Replace('\\', '_');
	sKey.Format("ExpandedState\\%s", sFilePath);
	
	LoadExpandedState(sKey);

	// restore prev selected item
	UINT uID = AfxGetApp()->GetProfileInt(sKey, "SelItem", 0);

	if (uID)
	{
		// find the corresponding tree item
		HTREEITEM hti = NULL;

		CHTIMap htiMap;
		m_data.BuildHTIMap(htiMap);

		if (htiMap.Lookup(uID, hti) && hti)
		{
			if (bResetSel)
				SelectItem(hti);

			return hti;
		}
	}

	return NULL;
}

void CToDoCtrl::LoadExpandedState(LPCTSTR szRegKey)
{
	int nCount = AfxGetApp()->GetProfileInt(szRegKey, "Count", 0);
	CString sItem;

	CHTIMap map;
	m_data.BuildHTIMap(map);

	while (nCount--)
	{
		sItem.Format("Item%d", nCount);

		DWORD dwID = (DWORD)AfxGetApp()->GetProfileInt(szRegKey, sItem, 0);
		HTREEITEM hti = NULL;

		if (dwID && map.Lookup(dwID, hti) && hti)
			m_tree.Expand(hti, TVE_EXPAND);
	}
}

LRESULT CToDoCtrl::OnGutterWidthChange(WPARAM wParam, LPARAM lParam)
{
	// let parent know if min width has changed
	int nPrevWidth = LOWORD(lParam);
	int nNewWidth = HIWORD(lParam);

	if (nNewWidth < nPrevWidth || (!nPrevWidth && nNewWidth))
		GetParent()->SendMessage(WM_TDCN_MINWIDTHCHANGE);

	return 0;
}

LRESULT CToDoCtrl::OnGutterGetCursor(WPARAM wParam, LPARAM lParam)
{
	NCGGETCURSOR* pNCGGC = (NCGGETCURSOR*)lParam;

	// we handle the file ref column if the ctrl key is down
	if ((GetKeyState(VK_CONTROL) & 0x8000) && pNCGGC->nColID == TDCC_FILEREF && pNCGGC->dwItem)
	{
		TODOITEM tdi;
		HTREEITEM hti = (HTREEITEM)pNCGGC->dwItem;
		DWORD dwUniqueID = GetTaskID(hti);
		
		if (GetTask(dwUniqueID, tdi) && !tdi.sFileRefPath.IsEmpty())
			return (LRESULT)m_hHandCursor;
	}

	return 0L;
}

void CToDoCtrl::Flush() // called to end current editing actions
{
	EndLabelEdit();
}

BOOL CToDoCtrl::CheckIn()
{
	if (!HasStyle(TDCS_ENABLESOURCECONTROL))
		return FALSE;

	if (m_sLastSavePath.IsEmpty())
		return TRUE;

	CXmlFileEx file(TDL_ROOT);

	// load the file in its encrypted state because we're not interested 
	// in changing that bit of it
	if (file.Open(m_sLastSavePath, XF_READWRITE, FALSE) && file.LoadEx())
	{
		CXmlItem* pItem = file.GetItem(TDL_CHECKEDOUTTO);

		if (pItem)
		{
			CString sCheckedOutTo = pItem->GetValue();

			if (sCheckedOutTo.IsEmpty() || sCheckedOutTo == m_sMachineName) // its us
			{
				pItem->SetValue(""); // retain the item

				// and rewrite the file but keeping the same timestamp
				FILETIME ftMod;
				::GetFileTime((HANDLE)file.GetFileHandle(), NULL, NULL, &ftMod);

				m_bCheckedOut = !file.SaveEx(); // ie if successfully saved then m_bCheckedOut == 0

				::SetFileTime((HANDLE)file.GetFileHandle(), NULL, NULL, &ftMod);

				return !m_bCheckedOut;
			}
		}
	}

	// else someone else or invalid file
	return FALSE;
}

BOOL CToDoCtrl::CheckOut()
{
	return CheckOut(CString()); // dummy CString reference
}

BOOL CToDoCtrl::CheckOut(CString& sCheckedOutTo)
{
	if (!HasStyle(TDCS_ENABLESOURCECONTROL))
		return FALSE;

	CXmlFileEx file(TDL_ROOT);

	if (file.Open(m_sLastSavePath, XF_READWRITE))
	{
		if (file.LoadEx() && CheckOut(&file, sCheckedOutTo))
		{
			Load(&file); // reload file
			return TRUE;
		}
	}

	return FALSE;
}

BOOL CToDoCtrl::IsCheckedOut(const CXmlFileEx* pFile) const
{
	CString sCheckedOutTo = pFile->GetItemValue(TDL_CHECKEDOUTTO);
	return (sCheckedOutTo == m_sMachineName);
}

BOOL CToDoCtrl::CheckOut(CXmlFileEx* pFile, CString& sCheckedOutTo)
{
	if (!HasStyle(TDCS_ENABLESOURCECONTROL))
		return FALSE;

	// make sure its got a filepath attached
	if (pFile->GetFilePath().IsEmpty())
		return (m_bCheckedOut = FALSE);

	CXmlItem* pItem = pFile->GetItem(TDL_CHECKEDOUTTO);

	if (pItem)
	{
		sCheckedOutTo = pItem->GetValue();

		if (sCheckedOutTo == m_sMachineName) // its us
			return (m_bCheckedOut = TRUE);

		else if (!sCheckedOutTo.IsEmpty()) // someone else
			return (m_bCheckedOut = FALSE);

		// else check it out
		pItem->SetValue(m_sMachineName);
	}
	else // check it out
		pFile->AddItem(TDL_CHECKEDOUTTO, m_sMachineName);

	// and rewrite the file but keeping the same timestamp
	FILETIME ftMod;
	::GetFileTime((HANDLE)pFile->GetFileHandle(), NULL, NULL, &ftMod);

	m_bCheckedOut = pFile->SaveEx();

	::SetFileTime((HANDLE)pFile->GetFileHandle(), NULL, NULL, &ftMod);

	return m_bCheckedOut;
}

BOOL CToDoCtrl::IsUnderSourceControl(LPCTSTR szFilePath)
{
	CXmlFileEx file(TDL_ROOT);
	CXmlParseController xmlpc(TDL_TASK);

	if (file.Load(szFilePath, NULL, &xmlpc, FALSE))
		return (NULL != file.GetItem(TDL_CHECKEDOUTTO));

	return FALSE;
}

void CToDoCtrl::InitHandCursor()
{
#ifndef IDC_HAND
#	define IDC_HAND  MAKEINTRESOURCE(32649) // from winuser.h
#endif

	if (!m_hHandCursor)
	{
		m_hHandCursor = ::LoadCursor(NULL, IDC_HAND);

		// fallback hack for win9x
		if (!m_hHandCursor)
		{
			CString sWinHlp32;

			GetWindowsDirectory(sWinHlp32.GetBuffer(MAX_PATH), MAX_PATH);
			sWinHlp32.ReleaseBuffer();
			sWinHlp32 += _T("\\winhlp32.exe");

			HMODULE hMod = LoadLibrary(sWinHlp32);

			if (hMod)
				m_hHandCursor = ::LoadCursor(hMod, MAKEINTRESOURCE(106));
		}
	}
}

int CToDoCtrl::FindTasks(SEARCHPARAMS& params, CDWordArray& aResults)
{
	// first build a mapping from uniqueID -> HTREEITEM
	CHTIMap mapHTI;
	m_data.BuildHTIMap(mapHTI);

	int nFound = m_data.FindTasks(params, aResults);
	int nResult = nFound;

	while (nResult--)
	{
		HTREEITEM hti = NULL;

		if (mapHTI.Lookup(aResults[nResult], hti) && hti)
			aResults[nResult] = (DWORD)hti;
	}

	return nFound;
}

DWORD CToDoCtrl::FindFirstTask(SEARCHPARAMS& params)
{
	return m_data.FindFirstTask(params);
}

CString CToDoCtrl::GetItemPath(HTREEITEM hti, int nMaxElementLen) const
{ 
	CString sPath;

	HTREEITEM htiParent = m_tree.GetParentItem(hti);
		
	while (htiParent)
	{
		CString sParent = m_tree.GetItemText(htiParent);

		if (nMaxElementLen != -1 && sParent.GetLength() > nMaxElementLen)
			sParent = sParent.Left(nMaxElementLen) + "...";

		sParent.TrimLeft();
		sParent.TrimRight();

		sPath = sParent + " / "+ sPath;
		htiParent = m_tree.GetParentItem(htiParent);
	}

	return sPath;
}

void CToDoCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// is it over the comments splitter
	ASSERT (!m_bSplitting);

	if (GetSplitterRect().PtInRect(point))
	{
		m_bSplitting = TRUE;
		SetCapture();
	}

	CRuntimeDlg::OnLButtonDown(nFlags, point);
}

void CToDoCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if (!HasStyle(TDCS_SIMPLEMODE) && m_bSplitting)
	{
		ReleaseCapture();
		m_bSplitting = FALSE;
	}

	CRuntimeDlg::OnLButtonUp(nFlags, point);
}

void CToDoCtrl::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (m_bSplitting)
	{
		CRect rComments, rClient;

		GetClientRect(rClient);
		int MAXCOMMENTHEIGHT = rClient.Height() - MINNONCOMMENTHEIGHT;

		GetDlgItem(IDC_COMMENTS/*LABEL*/)->GetWindowRect(rComments);
		ScreenToClient(rComments);

		int nNewHeight = min(max(rComments.bottom - point.y, MINCOMMENTHEIGHT), MAXCOMMENTHEIGHT);

		if (nNewHeight != m_nCommentsHeight)
		{
			m_nCommentsHeight = nNewHeight;
			Resize();
			UpdateWindow();
		}
	}
	
	CRuntimeDlg::OnMouseMove(nFlags, point);
}

CRect CToDoCtrl::GetSplitterRect()
{
	CRect rSplitter;

	GetDlgItem(IDC_COMMENTS)->GetWindowRect(rSplitter);
	ScreenToClient(rSplitter);

	rSplitter.bottom = rSplitter.top;
	rSplitter.top -= SPLITHEIGHT;

	return rSplitter;
}

BOOL CToDoCtrl::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	if (!HasStyle(TDCS_SIMPLEMODE))
	{
		CPoint point(::GetMessagePos());
		ScreenToClient(&point);

		if (GetSplitterRect().PtInRect(point))
		{
			SetCursor(AfxGetApp()->LoadStandardCursor(IDC_SIZENS));
			return TRUE;
		}
	}
	
	// else
	return CRuntimeDlg::OnSetCursor(pWnd, nHitTest, message);
}

void CToDoCtrl::OnCaptureChanged(CWnd *pWnd) 
{
	if (m_bSplitting)
	{
		// save latest split pos
		s_nCommentsHeight = m_nCommentsHeight;
		m_bSplitting = FALSE;
	}
	
	CRuntimeDlg::OnCaptureChanged(pWnd);
}

void CToDoCtrl::UpdateColumnHeaderClicking()
{
	BOOL bEnable = HasStyle(TDCS_COLUMNHEADERCLICKING);

	// extra gutter columns
	for (int nCol = 0; nCol < NUM_COLUMNS; nCol++)
	{
		TDCCOLUMN& tdcc = COLUMNS[nCol];

		m_tree.EnableGutterColumnHeaderClicking(tdcc.nColID, tdcc.bClickable && bEnable);
	}
}

void CToDoCtrl::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CRuntimeDlg::OnShowWindow(bShow, nStatus);
	
	// resize if we have shared splitter pos and its different
	if (bShow && HasStyle(TDCS_SHAREDCOMMENTSHEIGHT) && (m_nCommentsHeight != s_nCommentsHeight))
	{
		m_nCommentsHeight = s_nCommentsHeight;
		Resize();
	}
}

void CToDoCtrl::EndLabelEdit(BOOL bCancel)
{
	if (m_tree.GetSafeHwnd() && m_tree.GetEditControl())
		m_tree.SendMessage(TVM_ENDEDITLABELNOW, bCancel, 0);
}

int CToDoCtrl::OnToolHitTest(CPoint pt, TOOLINFO* pTI) const
{
	int nRet = CWnd::OnToolHitTest(pt, pTI);
	
	if (nRet >= 0)
	{
		// we're only interested (at present) with the comments field
		UINT nID = pTI->uId;

		if (pTI->uFlags & TTF_IDISHWND)
			nID = ::GetDlgCtrlID((HWND)nID);

		switch (nID)
		{
		case IDC_COMMENTS:
			if (m_reComments.GetUrlCount())
			{
				ClientToScreen(&pt);
				m_reComments.ScreenToClient(&pt);

				if (m_reComments.UrlHitTest(pt) != -1)
				{
					pTI->lpszText = _strdup("<Ctrl>+<click> to open urls");
					pTI->uFlags &= ~TTF_CENTERTIP; 
					return TRUE;
				}
			}
			break;
		}
	}

	return -1; // everything else
}

LRESULT CToDoCtrl::OnTimeUnitsChange(WPARAM wParam, LPARAM lParam)
{
	HWND hCtrl = (HWND)wParam;

	if (hCtrl == m_eTimeEstimate)
		UpdateTask(TDCA_TIMEEST); 

	else if (hCtrl == m_eTimeSpent)
		UpdateTask(TDCA_TIMESPENT); 

	return 0;
}

void CToDoCtrl::SpellcheckSelectedTask(BOOL bTitle) 
{
	// one off spell check
	CSpellCheckDlg dialog(NULL, NULL);

	SpellcheckItem(GetSelectedItem(), &dialog, bTitle, TRUE);
}

void CToDoCtrl::Spellcheck()
{
	// top level items
	CSpellCheckDlg dialog(NULL, NULL);

	HTREEITEM hti = m_tree.GetNextItem(NULL, TVGN_CHILD);

	while (hti)
	{
		if (!SpellcheckItem(hti, &dialog))
			return;

		hti = m_tree.GetNextItem(hti, TVGN_NEXT);
	}
}

BOOL CToDoCtrl::SpellcheckItem(HTREEITEM hti, CSpellCheckDlg* pSpellChecker, BOOL bTitle, BOOL bNotifyNoErrors)
{
	ASSERT(pSpellChecker);
	
	if (!pSpellChecker)
		return FALSE;

	TODOITEM tdi;
	DWORD dwID = GetTaskID(hti);

	if (dwID && m_data.GetTask(dwID, tdi))
	{
		CString sText = bTitle ? m_data.GetTaskTitle(dwID) : m_data.GetTaskComments(dwID);
		
		if (!sText.IsEmpty())
		{
			SelectItem(hti);
			pSpellChecker->SetText(sText);
			
			int nRet = pSpellChecker->DoModal(TRUE);

			if (nRet == IDOK && !IsReadOnly())
			{
				int nChange = SET_NOCHANGE;
				sText = pSpellChecker->GetCorrectedText();
				
				if (bTitle)
				{
					nChange = m_data.SetTaskTitle(dwID, sText);

					if (nChange == SET_CHANGE)
						m_tree.SetItemText(hti, sText);
				}
				else
					nChange = m_data.SetTaskComments(dwID, sText);

				if (nChange == SET_CHANGE)
					SetModified(TRUE, TDCA_TASKNAME);
			}
			else if (nRet == IDNOERRORS && bNotifyNoErrors)
			{
				CString sMessage;
				sMessage.Format("The selected task's %s had no spelling errors", bTitle ? "title" : "comments");
				AfxMessageBox(sMessage);
			}
			else if (nRet == IDCANCEL)
				return FALSE;
		}

		return TRUE;
	}

	// else
	ASSERT(0);
	return FALSE;
}

BOOL CToDoCtrl::SpellcheckItem(HTREEITEM hti, CSpellCheckDlg* pSpellChecker)
{
	if (!SpellcheckItem(hti, pSpellChecker, TRUE, FALSE) || 
		!SpellcheckItem(hti, pSpellChecker, FALSE, FALSE))
		return FALSE;

	// subtasks
	HTREEITEM htiSub = m_tree.GetNextItem(hti, TVGN_CHILD);
	
	while (htiSub)
	{
		if (!SpellcheckItem(htiSub, pSpellChecker))
			return FALSE;
		
		htiSub = m_tree.GetNextItem(htiSub, TVGN_NEXT);
	}

	return TRUE;
}

void CToDoCtrl::SetDefaultTaskAttributes(LPCTSTR szTitle, LPCTSTR szComments, COLORREF color,
										const double& dTimeEst, int nTimeEstUnits, LPCTSTR szAllocTo,
										LPCTSTR szAllocBy, LPCTSTR szStatus, LPCTSTR szCategory,
										int nPriority, const COleDateTime& dateStart)
{
	s_tdDefault.sTitle = szTitle;
	s_tdDefault.sComments = szComments;
	s_tdDefault.color = color;
	s_tdDefault.dateStart = dateStart;
	s_tdDefault.nPriority = nPriority;
	s_tdDefault.sAllocTo = szAllocTo;
	s_tdDefault.sAllocBy = szAllocBy;
	s_tdDefault.sStatus = szStatus;
	s_tdDefault.sCategory = szCategory;
	s_tdDefault.dTimeEstimate = dTimeEst;
	s_tdDefault.nTimeEstUnits = nTimeEstUnits;
	s_tdDefault.nTimeSpentUnits = nTimeEstUnits; // to match

	UpdateControls();
}

LRESULT CToDoCtrl::OnEEBtnClick(WPARAM wParam, LPARAM lParam)
{
	switch (wParam)
	{
	case IDC_TIMESPENT:
		if (lParam == ID_TIMEEDITBTN && GetSelectedCount() == 1)
			TimeTrackTask(GetSelectedItem());
		break;
	}

	return 0L;
}

void CToDoCtrl::OnTimer(UINT nIDEvent) 
{
	if (nIDEvent == TIMER_TRACK)
	{
		// make sure everything is above board
		// there's a number of things we check such as our
		// enabled state, whether the task permits clocking
		// and so forth
		HTREEITEM htiTrack = NULL;
		DWORD dwSelTaskID = GetSelectedTaskID();
		BOOL bTrackingSelTask = (m_dwTimeTrackTaskID && dwSelTaskID == m_dwTimeTrackTaskID);

		// is it selected or has the user turned off this style
		BOOL bTrackable = bTrackingSelTask || (m_dwTimeTrackTaskID && !HasStyle(TDCS_TRACKSELECTEDTASKONLY));
	
		// are the relevant windows enabled
		bTrackable &= IsWindowEnabled() && m_eTimeSpent.IsWindowEnabled();

		// does it permit tracking
		if (bTrackable)
		{
			htiTrack = bTrackingSelTask ? GetSelectedItem() : m_data.GetItem(m_dwTimeTrackTaskID);
			bTrackable = m_data.IsTaskTimeTrackable(htiTrack);
		}

		// now act
		if (bTrackable)
		{
			// not a reason to spit but don't increment time if 
			// screensaver is active or top level parent is disabled
			BOOL bIsRunning = FALSE;
            ::SystemParametersInfo(SPI_GETSCREENSAVERRUNNING, 0, &bIsRunning, 0);

			if (!bIsRunning && GetTopLevelParent()->IsWindowEnabled())
			{
				int nUnits;
				double dTime = m_data.GetTaskTimeSpent(m_dwTimeTrackTaskID, nUnits);
				
				dTime = CTimeEdit::GetTime(dTime, nUnits, TEU_HOURS);
				dTime += TIMEINCREMENT;
				dTime = CTimeEdit::GetTime(dTime, TEU_HOURS, nUnits);
				
				if (bTrackingSelTask)
					SetSelectedTaskTimeSpent(dTime, nUnits);
				else
				{
					m_data.SetTaskTimeSpent(m_dwTimeTrackTaskID, dTime, nUnits);
					SetModified(TRUE, TDCA_TIMESPENT);
				}
			}
		}
		else // woops invalid task for a number of reasons so stop tracking
		{
			KillTimer(TIMER_TRACK);
		}
	}
	
	CRuntimeDlg::OnTimer(nIDEvent);
}

LRESULT CToDoCtrl::OnCustomUrl(WPARAM wParam, LPARAM lParam)
{
	ASSERT(wParam == (WPARAM)m_reComments.GetDlgCtrlID());
	GotoFile((LPCTSTR)lParam, FALSE);

	return 0;
}

void CToDoCtrl::SelectNextTasksInHistory() 
{ 
	if (Selection().NextSelection())
	{
		HTREEITEM hti = m_tree.GetSelectedItem();

		if (!Selection().HasItem(hti) && Selection().GetCount())
			m_tree.SelectItem(Selection().GetFirstItem());
	}
}

void CToDoCtrl::SelectPrevTasksInHistory() 
{ 
	if (Selection().PrevSelection())
	{
		HTREEITEM hti = m_tree.GetSelectedItem();

		if (!Selection().HasItem(hti) && Selection().GetCount())
			m_tree.SelectItem(Selection().GetFirstItem());
	}
}

LRESULT CToDoCtrl::OnFileEditWantIcon(WPARAM wParam, LPARAM lParam)
{
	if (wParam == IDC_FILEPATH)
	{
		const CString& sUrl = (LPCTSTR)lParam;

		if (sUrl.Find(TDL_PROTOCOL) != -1)
			return (LRESULT)AfxGetMainWnd()->SendMessage(WM_GETICON, ICON_SMALL, 0);
	}

	return 0;
}

LRESULT CToDoCtrl::OnFileEditDisplayFile(WPARAM wParam, LPARAM lParam)
{
	if (wParam == IDC_FILEPATH && GotoFile((LPCTSTR)lParam, FALSE))
		return TRUE;

	return 0;
}

BOOL CToDoCtrl::GotoFile(const CString& sUrl, BOOL bShellExecute)
{
	if (sUrl.IsEmpty())
		return FALSE;

	// see if its a 'tdl://'
	int nFind = sUrl.Find(TDL_PROTOCOL);

	if (nFind >= 0)
	{
		DWORD dwTaskID = atoi(((const char*)sUrl) + strlen(TDL_PROTOCOL));

		// check its valid and we've got it
		if (dwTaskID)
		{
			HTREEITEM hti;
			CHTIMap mapHTI;

			m_data.BuildHTIMap(mapHTI);

			if (mapHTI.Lookup(dwTaskID, hti))
			{
				SelectItem(hti);
				m_tree.SelectItem(hti);
				m_tree.SetFocus();
			}
			else
			{
				CString sMessage;
				sMessage.Format("A task with an ID of '%d' could not be found in the active tasklist", dwTaskID);
				MessageBox(sMessage, "Task Not Found");
			}
		}
		else
			MessageBox("0 (zero) is not a valid task ID", "Invalid Task ID");

		return TRUE;
	}
	else if (bShellExecute)
	{
		int nRes = (int)ShellExecute(*this, NULL, sUrl, NULL, NULL, SW_SHOWNORMAL); 
		
		if (nRes < 32)
		{
			CString sMessage;
			
			switch (nRes)
			{
			case SE_ERR_NOASSOC:
				sMessage.Format("The application associated with '%s'\ncould not be launched.\n\nPlease check the file associations in Explorer before trying again.", sUrl);
				break;
				
			default:
				sMessage.Format("'%s' could not be opened (%d).\n\nPlease check that the file exists and that you have the appropriate access rights before trying again.", sUrl, nRes);
				break;
			}
			
			AfxMessageBox(sMessage, MB_OK);

		}

		return TRUE;
	}

	return FALSE;
}

