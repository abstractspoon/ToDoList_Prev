// ExportToDoList.h: interface for the CExportToDoListToHtml class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EXPORTTODOLIST_H__A7CB4601_1F93_11D8_B2D5_E7C8A4F0ED33__INCLUDED_)
#define AFX_EXPORTTODOLIST_H__A7CB4601_1F93_11D8_B2D5_E7C8A4F0ED33__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\SHARED\XmlFile.h"

struct EXPORTPARAMS
{
	EXPORTPARAMS(const CWordArray& aPref) : aUserPref(aPref) 
	{ 
		bParentTitleCommentsOnly = FALSE;
		bSpaceForNotes = FALSE;
	}

	CString sProjectName;
	const CWordArray& aUserPref;
	BOOL bParentTitleCommentsOnly;
	BOOL bSpaceForNotes;
};

class CExportToDoList : public IXmlExporter  
{
public:
	CExportToDoList(const EXPORTPARAMS& ep);
	virtual ~CExportToDoList();

protected:
	int CalcPercentDone(const CXmlItem* pItem) const;
	double CalcTimeEstimateInHours(const CXmlItem* pItem) const;
	double CalcTimeSpentInHours(const CXmlItem* pItem) const;
	BOOL HasPref(DWORD dwPref) const { return m_ep.aUserPref[dwPref]; } 
	int GetTimeUnits(const CXmlItem* pItem, LPCTSTR szType) const;
	BOOL WantTitleCommentsOnly(const CXmlItem* pItem) const;
	BOOL WantSpaceForNotes(const CXmlItem* pItem) const;

protected:
	const EXPORTPARAMS& m_ep; 
};

class CExportToDoListToHtml : public CExportToDoList  
{
public:
	CExportToDoListToHtml(const EXPORTPARAMS& ep, 
							const CDWordArray& aPriorityColors, 
							COLORREF crDone, LPCTSTR szFontName = NULL, int nFontSize = 10);
	virtual ~CExportToDoListToHtml();

	virtual CString& Export(const CXmlItem* pItem, int nDepth, int nPos, CString& sOutput) const;

protected:
	CString m_sFontName;
	int m_nFontSize;
	CDWordArray m_aPriorityColors;
	COLORREF m_crDone;

	COLORREF GetPriorityColor(int nPriority) const;
	COLORREF CalcItemColor(const CXmlItem* pItem) const;
	BOOL IsItemDone(const CXmlItem* pItem, BOOL bCheckParent) const;
	BOOL IsItemDue(const CXmlItem* pItem) const;
};

class CExportToDoListToText : public CExportToDoList  
{
public:
	CExportToDoListToText(const EXPORTPARAMS& ep, int nIndentWidth = 2);
	virtual ~CExportToDoListToText();

	virtual CString& Export(const CXmlItem* pItem, int nDepth, int nPos, CString& sOutput) const;

protected:
	const CString INDENT;
};


#endif // !defined(AFX_EXPORTTODOLIST_H__A7CB4601_1F93_11D8_B2D5_E7C8A4F0ED33__INCLUDED_)
