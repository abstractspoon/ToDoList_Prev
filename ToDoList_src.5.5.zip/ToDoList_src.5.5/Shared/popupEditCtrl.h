//_ **********************************************************
//_ 
//_ Name: InputListCtrlEdit.h 
//_ Purpose: 
//_ Created: 15 September 1998 
//_ Author: D.R.Godson
//_ Modified By: 
//_ 
//_ Copyright (c) 1998 Brilliant Digital Entertainment Inc. 
//_ 
//_ **********************************************************

#if !defined(AFX_POPUPEDITCTRL_H__2E5810B2_D7DF_11D1_AB19_0000E8425C3E__INCLUDED_)
#define AFX_POPUPEDITCTRL_H__2E5810B2_D7DF_11D1_AB19_0000E8425C3E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// InputListCtrlEdit.h : header file
//

#include "maskedit.h"

/////////////////////////////////////////////////////////////////////////////
// CPopupEditCtrl window

class CPopupEditCtrl : public CMaskEdit
{
// Construction
public:
	CPopupEditCtrl();
	void Reset() { m_bEditEnded = FALSE; }
	void Show(CRect rPos = CRect(0, 0, 0, 0)); // screen or client depending on original creation mode
	void Hide();
	void AutoHide(BOOL bEnable = TRUE) { m_bAutoHide = bEnable; }

// Attributes
protected:
	BOOL m_bEditEnded;
	UINT m_nID;
	CWnd* m_pParent;
	BOOL m_bAutoHide;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPopupEditCtrl)
	public:
	virtual BOOL Create(CWnd* pParentWnd, UINT nID, BOOL bChild = TRUE);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPopupEditCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CPopupEditCtrl)
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg UINT OnGetDlgCode();
	//}}AFX_MSG
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INPUTLISTCTRLEDIT_H__2E5810B2_D7DF_11D1_AB19_0000E8425C3E__INCLUDED_)
