// CalendarExtApp.h: interface for the CCalendarExtApp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CALENDAREXTAPP_H__8FDB207D_40DB_405D_8D76_A9898B6DAE21__INCLUDED_)
#define AFX_CALENDAREXTAPP_H__8FDB207D_40DB_405D_8D76_A9898B6DAE21__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\SHARED\IUIExtension.h"

class CCalendarExtApp : public IUIExtension  
{
public:
	CCalendarExtApp();
	virtual ~CCalendarExtApp();

    virtual void Release(); // releases the interface

	virtual const char* GetMenuText();
	virtual HICON GetIcon();

	virtual IUIExtensionWindow* CreateExtensionWindow(HWND hParent, BOOL bShow = TRUE, LPSIZE pSize = NULL);

protected:
	HICON m_hIcon;
};

#endif // !defined(AFX_CALENDAREXTAPP_H__8FDB207D_40DB_405D_8D76_A9898B6DAE21__INCLUDED_)
