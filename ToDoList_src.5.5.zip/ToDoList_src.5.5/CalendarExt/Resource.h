//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CalendarExt.rc
//
#define IDR_CALENDAR                    1000
#define IDC_STATUSBAR                   1001
#define IDD_COMPLETED_TASKS             1010
#define IDC_STATIC_SAMPLE_TEXT          1011
#define IDC_CHK_COMPLETED_TASKS_GREY    1012
#define IDC_CHK_COMPLETED_TASKS_STRIKETHRU 1013
#define IDC_CHK_COMPLETED_TASKS_HIDDEN  1014
#define ID_SB_STARTDATE                 2001
#define ID_SB_STARTDATE_TIP             2002
#define ID_SB_DUEDATE                   2003
#define ID_SB_DUEDATE_TIP               2004
#define ID_SB_DONEDATE                  2005
#define ID_SB_DONEDATE_TIP              2006
#define ID_SB_TIMEESTIMATE              2007
#define ID_SB_TIMEESTIMATE_TIP          2008
#define ID_SB_TIMESPENT                 2009
#define ID_SB_TIMESPENT_TIP             2010
#define ID_BUTTON32771                  32771
#define ID_VIEW_MINICALENDAR            32772
#define ID_VIEW_STATUSBAR               32773
#define ID_VIEW_WEEKENDS                32774
#define ID_VIEW_COMPLETEDTASKS          32775
#define ID_VIEW_NUMWEEKS_1              32781
#define ID_VIEW_NUMWEEKS_2              32782
#define ID_VIEW_NUMWEEKS_3              32783
#define ID_VIEW_NUMWEEKS_4              32784
#define ID_VIEW_NUMWEEKS_5              32785
#define ID_VIEW_NUMWEEKS_6              32786
#define ID_VIEW_NUMWEEKS_7              32787
#define ID_VIEW_NUMWEEKS_8              32788
#define ID_VIEW_NUMWEEKS_9              32789
#define ID_GOTOTODAY                    32795

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1002
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
