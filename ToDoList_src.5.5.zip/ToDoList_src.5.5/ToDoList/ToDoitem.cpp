// ToDoCtrlData.cpp: implementation of the CToDoCtrlData class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ToDoitem.h"
#include "tdcenum.h"

#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////

IMPLEMENT_FIXED_ALLOC(TODOITEM, 1024);

TODOITEM::TODOITEM(LPCTSTR szTitle, LPCTSTR szComments) :
	sTitle(szTitle), 
	sComments(szComments),
	color(0), 
	nPriority(5),
	nRisk(0),
	nPercentDone(0),
	dTimeEstimate(0),
	dTimeSpent(0),
	nTimeEstUnits(TDITU_HOURS),
	nTimeSpentUnits(TDITU_HOURS),
	dCost(0),
	bFlagged(FALSE),
	dateCreated(COleDateTime::GetCurrentTime())
{ 
	SetModified();
	ResetCalcs();
}

TODOITEM::TODOITEM() :
	color(0), 
	nPriority(5),
	nRisk(0),
	nPercentDone(0),
	dTimeEstimate(0),
	dTimeSpent(0),
	nTimeEstUnits(TDITU_HOURS),
	nTimeSpentUnits(TDITU_HOURS),
	dCost(0),
	bFlagged(FALSE),
	dateCreated(COleDateTime::GetCurrentTime())
{ 
	SetModified();
	ResetCalcs();
}

TODOITEM::TODOITEM(const TODOITEM& tdi)
{ 
	*this = tdi;

    if (dateCreated.m_dt == 0.0)
		dateCreated = COleDateTime::GetCurrentTime();

	SetModified();
}

TODOITEM::TODOITEM(const TODOITEM* pTDI)
{
	if (pTDI)
	{
		*this = *pTDI;

		if (dateCreated.m_dt == 0.0)
			dateCreated = COleDateTime::GetCurrentTime();

		SetModified();
	}
}

const TODOITEM& TODOITEM::operator=(const TODOITEM& tdi) 
{
	sTitle = tdi.sTitle;
	sComments = tdi.sComments;
	sCustomComments = tdi.sCustomComments;
	sCommentsTypeID = tdi.sCommentsTypeID;
	color = tdi.color; 
	sFileRefPath = tdi.sFileRefPath;
	sAllocBy = tdi.sAllocBy;
	sStatus = tdi.sStatus;
	nPriority = tdi.nPriority;
	nPercentDone = tdi.nPercentDone;
	dTimeEstimate = tdi.dTimeEstimate;
	dTimeSpent = tdi.dTimeSpent;
	nTimeEstUnits = tdi.nTimeEstUnits;
	nTimeSpentUnits = tdi.nTimeSpentUnits;
	dCost = tdi.dCost;
	dateStart = tdi.dateStart;
	dateDue = tdi.dateDue;
	dateDone = tdi.dateDone;
	dateCreated = tdi.dateCreated;
	bFlagged = tdi.bFlagged;
	sCreatedBy = tdi.sCreatedBy;
	nRisk = tdi.nRisk;
	sExternalID = tdi.sExternalID;
	trRecurrence = tdi.trRecurrence;
	tLastMod = tdi.tLastMod;
	sVersion = tdi.sVersion;

	aCategories.Copy(tdi.aCategories);
	aAllocTo.Copy(tdi.aAllocTo);
	aDependencies.Copy(tdi.aDependencies);

	ResetCalcs();

	return *this;
}

BOOL TODOITEM::HasCreation() const 
{ 
	return (dateCreated.m_dt > 0.0) ? TRUE : FALSE; 
}

BOOL TODOITEM::HasLastMod() const 
{ 
	return (tLastMod.m_dt > 0.0) ? TRUE : FALSE; 
}

BOOL TODOITEM::HasStart() const 
{ 
	return (dateStart.m_dt > 0.0) ? TRUE : FALSE; 
}

BOOL TODOITEM::HasDue() const 
{ 
	return (dateDue.m_dt > 0.0) ? TRUE : FALSE; 
}

BOOL TODOITEM::HasDueTime() const 
{ 
	return (CDateHelper::GetTimeOnly(dateDue.m_dt) > 0.0) ? TRUE : FALSE; 
}

BOOL TODOITEM::IsDone() const 
{ 
	return (dateDone.m_dt > 0) ? TRUE : FALSE; 
}

void TODOITEM::ClearStart() 
{ 
	dateStart.m_dt = 0; 
}

void TODOITEM::ClearDue() 
{ 
	dateDue.m_dt = 0; 
}

void TODOITEM::ClearDone() 
{ 
	dateDone.m_dt = 0; 
}

BOOL TODOITEM::IsDue() const
{ 
	return IsDue(COleDateTime::GetCurrentTime());
}

BOOL TODOITEM::IsDue(const COleDateTime& dateDueBy) const
{ 
	if (IsDone() || !HasDue())
		return FALSE;
	
	return (floor(dateDue.m_dt) <= floor(dateDueBy.m_dt)); 
}

void TODOITEM::SetModified() 
{ 
	tLastMod = COleDateTime::GetCurrentTime(); 
}

void TODOITEM::ResetCalcs() const 
{
	nCalcPriority = nCalcPriorityIncDue = nCalcPercent = nCalcRisk = -1;
	dCalcTimeEstimate = dCalcTimeSpent = dCalcCost = -1;
	dateEarliestDue.m_dt = -1;
	bGoodAsDone = bDue = -1;
    nSubtasksCount = nSubtasksDone = -1;
}

CString TODOITEM::GetFirstCategory() const
{
	return aCategories.GetSize() ? aCategories[0] : "";
}

CString TODOITEM::GetFirstAllocTo() const
{
	return aAllocTo.GetSize() ? aAllocTo[0] : "";
}

CString TODOITEM::GetFirstDependency() const
{
	return aDependencies.GetSize() ? aDependencies[0] : "";
}

BOOL TODOITEM::GetNextOccurence(COleDateTime& dtNext) const
{
	if (trRecurrence.bRecalcFromDue && HasDue())
		return trRecurrence.GetNextOccurence(dateDue, dtNext);

	// else use completed date but with the current due time
	if (trRecurrence.GetNextOccurence(COleDateTime::GetCurrentTime(), dtNext))
	{
		// restore the due time to be whatever 
		double dDueTime = HasDue() ? CDateHelper::GetTimeOnly(dateDue) : 0.0;
		dtNext = CDateHelper::GetDateOnly(dtNext) + dDueTime;

		return TRUE;
	}

	// else
	return FALSE;
}

