// TDLImportDialog.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "TDLImportDialog.h"

#include "../shared/enstring.h"
#include "../shared/misc.h"
#include "../shared/preferences.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTDLImportDialog dialog


CTDLImportDialog::CTDLImportDialog(const CImportExportMgr& mgr, CWnd* pParent /*=NULL*/)
	: CDialog(CTDLImportDialog::IDD, pParent),
	  m_mgrImportExport(mgr)
{
	//{{AFX_DATA_INIT(CTDLImportDialog)
	//}}AFX_DATA_INIT
	CPreferences prefs;

	m_bFromClipboard = prefs.GetProfileInt("Importing", "ImportOption", FALSE);
	m_sFromFilePath = prefs.GetProfileString("Importing", "ImportFilePath");
	m_nImportTo = prefs.GetProfileInt("Importing", "ImportToWhere", TDIT_SELECTEDTASK);
	m_nFormatOption = prefs.GetProfileInt("Importing", "ImportFormat", 0);

	m_nFormatOption = min(m_nFormatOption, mgr.GetNumImporters());
}


void CTDLImportDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTDLImportDialog)
	DDX_Control(pDX, IDC_FROMFILEPATH, m_eFilePath);
	DDX_Control(pDX, IDC_FORMATOPTIONS, m_cbFormat);
	DDX_Radio(pDX, IDC_FROMFILE, m_bFromClipboard);
	DDX_Text(pDX, IDC_FROMFILEPATH, m_sFromFilePath);
	DDX_Radio(pDX, IDC_TONEWTASKLIST, m_nImportTo);
	DDX_CBIndex(pDX, IDC_FORMATOPTIONS, m_nFormatOption);
	DDX_Text(pDX, IDC_FROMCLIPBOARDTEXT, m_sClipboardText);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTDLImportDialog, CDialog)
	//{{AFX_MSG_MAP(CTDLImportDialog)
	ON_BN_CLICKED(IDC_FROMCLIPBOARD, OnChangeImportFrom)
	ON_BN_CLICKED(IDC_FROMFILE, OnChangeImportFrom)
	ON_CBN_SELCHANGE(IDC_FORMATOPTIONS, OnSelchangeFormatoptions)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTDLImportDialog message handlers

void CTDLImportDialog::OnChangeImportFrom() 
{
	UpdateData();

	GetDlgItem(IDC_FROMFILEPATH)->EnableWindow(!m_bFromClipboard);
	GetDlgItem(IDC_FROMCLIPBOARDTEXT)->EnableWindow(m_bFromClipboard);
}

BOOL CTDLImportDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// build the format comboxbox
	for (int nImp = 0; nImp < m_mgrImportExport.GetNumImporters(); nImp++)
		m_cbFormat.AddString(m_mgrImportExport.GetImporterMenuText(nImp));

	// append standard tasklist to the end
	m_cbFormat.AddString(CEnString(AFX_IDS_APP_TITLE));
	m_cbFormat.SetCurSel(m_nFormatOption);

	// init file edit
	if (ImportTasklist())
		m_eFilePath.SetFilter(CEnString(IDS_TDLFILEFILTER));
	else
		m_eFilePath.SetFilter(m_mgrImportExport.GetImporterFileFilter(m_nFormatOption));
	
	GetDlgItem(IDC_FROMFILEPATH)->EnableWindow(!m_bFromClipboard);
	GetDlgItem(IDC_FROMCLIPBOARDTEXT)->EnableWindow(m_bFromClipboard);

	m_sClipboardText = Misc::GetClipboardText(*this);
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTDLImportDialog::OnOK()
{
	CDialog::OnOK();

	CPreferences prefs;

	prefs.WriteProfileInt("Importing", "ImportOption", m_bFromClipboard);
	prefs.WriteProfileString("Importing", "ImportFilePath", m_sFromFilePath);
	prefs.WriteProfileInt("Importing", "ImportToWhere", m_nImportTo);
	prefs.WriteProfileInt("Importing", "ImportFormat", m_nFormatOption);
}

BOOL CTDLImportDialog::ImportTasklist() const
{
	return (m_nFormatOption == m_mgrImportExport.GetNumImporters());
}

int CTDLImportDialog::GetImporterIndex() const
{
	if (ImportTasklist())
		return -1;

	// else
	return m_nFormatOption;
}

TDLID_IMPORTTO CTDLImportDialog::GetImportTo() const
{
	return (TDLID_IMPORTTO)m_nImportTo;
}

BOOL CTDLImportDialog::GetImportFromClipboard() const
{
	return (m_bFromClipboard);
}

CString CTDLImportDialog::GetImportFilePath() const
{
	return m_bFromClipboard ? "" : m_sFromFilePath;
}

CString CTDLImportDialog::GetImportClipboardText() const
{
	return m_bFromClipboard ? m_sClipboardText : "";
}

void CTDLImportDialog::OnSelchangeFormatoptions() 
{
	UpdateData(TRUE);

	// change the filter on the CFileEdit and clear the filepath
	if (ImportTasklist())
		m_eFilePath.SetFilter(CEnString(IDS_TDLFILEFILTER));
	else
		m_eFilePath.SetFilter(m_mgrImportExport.GetImporterFileFilter(m_nFormatOption));

	m_sFromFilePath.Empty();
	UpdateData(FALSE);
}
