// PreferencesTaskPage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesTaskPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesTaskPage property page

IMPLEMENT_DYNCREATE(CPreferencesTaskPage, CPropertyPage)

CPreferencesTaskPage::CPreferencesTaskPage() : CPropertyPage(CPreferencesTaskPage::IDD)
{
	//{{AFX_DATA_INIT(CPreferencesTaskPage)
	m_bAutoCalcPercentDone = FALSE;
	m_bTrackSelectedTaskOnly = FALSE;
	m_bPauseTimeTrackingOnScrnSaver = FALSE;
	//}}AFX_DATA_INIT

	// load settings
	m_bAutoReSort = AfxGetApp()->GetProfileInt("Preferences", "AutoReSort", FALSE);
	m_bTreatSubCompletedAsDone = AfxGetApp()->GetProfileInt("Preferences", "TreatSubCompletedAsDone", TRUE);
	m_bHidePercentForDoneTasks = AfxGetApp()->GetProfileInt("Preferences", "HidePercentForDoneTasks", TRUE);
	m_bHideStartDueForDoneTasks = AfxGetApp()->GetProfileInt("Preferences", "HideStartDueForDoneTasks", TRUE);
	m_bAveragePercentSubCompletion = AfxGetApp()->GetProfileInt("Preferences", "AveragePercentSubCompletion", FALSE);
	m_bIncludeDoneInAverageCalc = AfxGetApp()->GetProfileInt("Preferences", "IncludeDoneInAverageCalc", TRUE);
	m_bUseEarliestDueDate = AfxGetApp()->GetProfileInt("Preferences", "UseEarliestDueDate", FALSE);
	m_bUsePercentDoneInTimeEst = AfxGetApp()->GetProfileInt("Preferences", "UsePercentDoneInTimeEst", TRUE);
	m_bHideZeroTimeEst = AfxGetApp()->GetProfileInt("Preferences", "HideZeroTimeEst", TRUE);
	m_bShowPercentAsProgressbar = AfxGetApp()->GetProfileInt("Preferences", "ShowPercentAsProgressbar", FALSE);
	m_bQueryApplyChangestoSubtasks = FALSE;//AfxGetApp()->GetProfileInt("Preferences", "QueryApplyChangestoSubtasks", FALSE);
	m_bSortVisibleOnly = AfxGetApp()->GetProfileInt("Preferences", "SortVisibleOnly", FALSE);
	m_bUseHighestPriority = AfxGetApp()->GetProfileInt("Preferences", "UseHighestPriority", FALSE);
	m_bAutoCalcTimeEst = AfxGetApp()->GetProfileInt("Preferences", "AutoCalcTimeEst", FALSE);
	m_bRoundTimeFractions = AfxGetApp()->GetProfileInt("Preferences", "RoundTimeFractions", FALSE);
	m_bShowNonFilesAsText = AfxGetApp()->GetProfileInt("Preferences", "ShowNonFilesAsText", FALSE);
	m_bIncludeDoneInPriorityCalc = AfxGetApp()->GetProfileInt("Preferences", "IncludeDoneInPriorityCalc", TRUE);
	m_bWeightPercentCompletionByTimeEst = AfxGetApp()->GetProfileInt("Preferences", "WeightPercentCompletionByTimeEst", FALSE);
	m_bWeightPercentCompletionByPriority = AfxGetApp()->GetProfileInt("Preferences", "WeightPercentCompletionByPriority", FALSE);
	m_bAutoCalcPercentDone = AfxGetApp()->GetProfileInt("Preferences", "AutoCalcPercentDone", FALSE);
	m_bTrackSelectedTaskOnly = AfxGetApp()->GetProfileInt("Preferences", "TrackSelectedTaskOnly", TRUE);
	m_bPauseTimeTrackingOnScrnSaver = AfxGetApp()->GetProfileInt("Preferences", "PauseTimeTrackingOnScrnSaver", TRUE);
//	m_b = AfxGetApp()->GetProfileInt("Preferences", "", FALSE);
}

CPreferencesTaskPage::~CPreferencesTaskPage()
{
}

void CPreferencesTaskPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesTaskPage)
	DDX_Check(pDX, IDC_AUTORESORT, m_bAutoReSort);
	DDX_Check(pDX, IDC_HIDEUNDEFINEDTIMEST, m_bHideZeroTimeEst);
	DDX_Check(pDX, IDC_TREATSUBCOMPLETEDASDONE, m_bTreatSubCompletedAsDone);
	DDX_Check(pDX, IDC_HIDESTARTDUEFORDONETASKS, m_bHideStartDueForDoneTasks);
	DDX_Check(pDX, IDC_QUERYAPPLYCHANGESTOSUBTASKS, m_bQueryApplyChangestoSubtasks);
	DDX_Check(pDX, IDC_SORTVISIBLEONLY, m_bSortVisibleOnly);
	DDX_Check(pDX, IDC_USEHIGHESTPRIORITY, m_bUseHighestPriority);
	DDX_Check(pDX, IDC_AUTOCALCTIMEEST, m_bAutoCalcTimeEst);
	DDX_Check(pDX, IDC_ROUNDTIMEFRACTIONS, m_bRoundTimeFractions);
	DDX_Check(pDX, IDC_SHOWNONFILEREFSASTEXT, m_bShowNonFilesAsText);
	DDX_Check(pDX, IDC_INCLUDEDONEINPRIORITYCALC, m_bIncludeDoneInPriorityCalc);
	DDX_Check(pDX, IDC_WEIGHTPERCENTCALCBYTIMEEST, m_bWeightPercentCompletionByTimeEst);
	DDX_Check(pDX, IDC_WEIGHTPERCENTCALCBYPRIORITY, m_bWeightPercentCompletionByPriority);
	DDX_Check(pDX, IDC_AUTOCALCPERCENTDONE, m_bAutoCalcPercentDone);
	DDX_Check(pDX, IDC_TRACKSELECTEDTASKONLY, m_bTrackSelectedTaskOnly);
	DDX_Check(pDX, IDC_PAUSETIMETRACKINGONSCRNSAVER, m_bPauseTimeTrackingOnScrnSaver);
	//}}AFX_DATA_MAP
	DDX_Check(pDX, IDC_SHOWPERCENTPROGRESSBAR, m_bShowPercentAsProgressbar);
	DDX_Check(pDX, IDC_USEEARLIESTDUEDATE, m_bUseEarliestDueDate);
	DDX_Check(pDX, IDC_USEPERCENTDONEINTIMEEST, m_bUsePercentDoneInTimeEst);
	DDX_Check(pDX, IDC_HIDEPERCENTFORDONETASKS, m_bHidePercentForDoneTasks);
	DDX_Check(pDX, IDC_AVERAGEPERCENTSUBCOMPLETION, m_bAveragePercentSubCompletion);
	DDX_Check(pDX, IDC_INCLUDEDONEINAVERAGECALC, m_bIncludeDoneInAverageCalc);
}


BEGIN_MESSAGE_MAP(CPreferencesTaskPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPreferencesTaskPage)
	ON_BN_CLICKED(IDC_USEHIGHESTPRIORITY, OnUsehighestpriority)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_AVERAGEPERCENTSUBCOMPLETION, OnAveragepercentChange)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesTaskPage message handlers

BOOL CPreferencesTaskPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	GetDlgItem(IDC_INCLUDEDONEINAVERAGECALC)->EnableWindow(m_bAveragePercentSubCompletion);
	GetDlgItem(IDC_WEIGHTPERCENTCALCBYTIMEEST)->EnableWindow(m_bAveragePercentSubCompletion);
	GetDlgItem(IDC_WEIGHTPERCENTCALCBYPRIORITY)->EnableWindow(m_bAveragePercentSubCompletion);
	GetDlgItem(IDC_INCLUDEDONEINPRIORITYCALC)->EnableWindow(m_bUseHighestPriority);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreferencesTaskPage::OnOK() 
{
	CPropertyPage::OnOK();
	
	// save settings
	AfxGetApp()->WriteProfileInt("Preferences", "AutoReSort", m_bAutoReSort);
	AfxGetApp()->WriteProfileInt("Preferences", "TreatSubCompletedAsDone", m_bTreatSubCompletedAsDone);
	AfxGetApp()->WriteProfileInt("Preferences", "HidePercentForDoneTasks", m_bHidePercentForDoneTasks);
	AfxGetApp()->WriteProfileInt("Preferences", "HideStartDueForDoneTasks", m_bHideStartDueForDoneTasks);
	AfxGetApp()->WriteProfileInt("Preferences", "AveragePercentSubCompletion", m_bAveragePercentSubCompletion);
	AfxGetApp()->WriteProfileInt("Preferences", "IncludeDoneInAverageCalc", m_bIncludeDoneInAverageCalc);
	AfxGetApp()->WriteProfileInt("Preferences", "UseEarliestDueDate", m_bUseEarliestDueDate);
	AfxGetApp()->WriteProfileInt("Preferences", "UsePercentDoneInTimeEst", m_bUsePercentDoneInTimeEst);
	AfxGetApp()->WriteProfileInt("Preferences", "HideZeroTimeEst", m_bHideZeroTimeEst);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowPercentAsProgressbar", m_bShowPercentAsProgressbar);
	AfxGetApp()->WriteProfileInt("Preferences", "QueryApplyChangestoSubtasks", m_bQueryApplyChangestoSubtasks);
	AfxGetApp()->WriteProfileInt("Preferences", "SortVisibleOnly", m_bSortVisibleOnly);
	AfxGetApp()->WriteProfileInt("Preferences", "UseHighestPriority", m_bUseHighestPriority);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoCalcTimeEst", m_bAutoCalcTimeEst);
	AfxGetApp()->WriteProfileInt("Preferences", "RoundTimeFractions", m_bRoundTimeFractions);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowNonFilesAsText", m_bShowNonFilesAsText);
	AfxGetApp()->WriteProfileInt("Preferences", "IncludeDoneInPriorityCalc", m_bIncludeDoneInPriorityCalc);
	AfxGetApp()->WriteProfileInt("Preferences", "WeightPercentCompletionByTimeEst", m_bWeightPercentCompletionByTimeEst);
	AfxGetApp()->WriteProfileInt("Preferences", "WeightPercentCompletionByPriority", m_bWeightPercentCompletionByPriority);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoCalcPercentDone", m_bAutoCalcPercentDone);
	AfxGetApp()->WriteProfileInt("Preferences", "TrackSelectedTaskOnly", m_bTrackSelectedTaskOnly);
	AfxGetApp()->WriteProfileInt("Preferences", "PauseTimeTrackingOnScrnSaver", m_bPauseTimeTrackingOnScrnSaver);
//	AfxGetApp()->WriteProfileInt("Preferences", "", m_b);
}

void CPreferencesTaskPage::OnAveragepercentChange() 
{
	UpdateData();

	GetDlgItem(IDC_INCLUDEDONEINAVERAGECALC)->EnableWindow(m_bAveragePercentSubCompletion);
	GetDlgItem(IDC_WEIGHTPERCENTCALCBYTIMEEST)->EnableWindow(m_bAveragePercentSubCompletion);
	GetDlgItem(IDC_WEIGHTPERCENTCALCBYPRIORITY)->EnableWindow(m_bAveragePercentSubCompletion);
}


void CPreferencesTaskPage::OnUsehighestpriority() 
{
	UpdateData();

	GetDlgItem(IDC_INCLUDEDONEINPRIORITYCALC)->EnableWindow(m_bUseHighestPriority);
}
