// TDLTaskIconDlg.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "TDLTaskIconDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTDLTaskIconDlg dialog


CTDLTaskIconDlg::CTDLTaskIconDlg(const CImageList& ilIcons, int nSelIndex, CWnd* pParent /*=NULL*/)
	: CDialog(CTDLTaskIconDlg::IDD, pParent), m_ilIcons(ilIcons), m_nIconIndex(nSelIndex)
{
	//{{AFX_DATA_INIT(CTDLTaskIconDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTDLTaskIconDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTDLTaskIconDlg)
	DDX_Control(pDX, IDC_ICONLIST, m_lcIcons);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTDLTaskIconDlg, CDialog)
	//{{AFX_MSG_MAP(CTDLTaskIconDlg)
	ON_NOTIFY(NM_DBLCLK, IDC_ICONLIST, OnDblclkIconlist)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_ICONLIST, OnItemchangedIconlist)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTDLTaskIconDlg message handlers

BOOL CTDLTaskIconDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	ListView_SetImageList(m_lcIcons, m_ilIcons, LVSIL_SMALL);
	
	for (int nImage = 0; nImage < m_ilIcons.GetImageCount(); nImage++)
	{
		CString sImage;
		sImage.Format("%d", nImage + 1);
		
		m_lcIcons.InsertItem(nImage, sImage, nImage);
	}

	if (m_nIconIndex >= 0)
		m_lcIcons.SetItemState(m_nIconIndex, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);

	// disable OK button if nothing selected
	GetDlgItem(IDOK)->EnableWindow(m_nIconIndex >= 0);
	m_lcIcons.SetFocus();
	
	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTDLTaskIconDlg::OnDblclkIconlist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NMITEMACTIVATE* pNMListView = ( NMITEMACTIVATE*)pNMHDR;
	
	m_nIconIndex = pNMListView->iItem;

	// disable OK button if nothing selected
	GetDlgItem(IDOK)->EnableWindow(m_nIconIndex >= 0);
	
	if (m_nIconIndex >= 0)
		EndDialog(IDOK);

	*pResult = 0;
}

void CTDLTaskIconDlg::OnItemchangedIconlist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	m_nIconIndex = pNMListView->iItem;

	// disable OK button if nothing selected
	GetDlgItem(IDOK)->EnableWindow(m_nIconIndex >= 0);
		
	*pResult = 0;
}
