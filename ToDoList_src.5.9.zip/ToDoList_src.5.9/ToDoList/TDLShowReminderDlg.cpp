// TDLShowReminderDlg.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "TDLShowReminderDlg.h"
#include "filteredtodoctrl.h"

#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTDLShowReminderDlg dialog


CTDLShowReminderDlg::CTDLShowReminderDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTDLShowReminderDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTDLShowReminderDlg)
	m_sWhen = _T("");
	m_sTaskTitle = _T("");
	m_nSnoozeIndex = 0;
	//}}AFX_DATA_INIT
}


void CTDLShowReminderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTDLShowReminderDlg)
	DDX_Text(pDX, IDC_WHENTEXT, m_sWhen);
	DDX_Text(pDX, IDC_TASKTITLE, m_sTaskTitle);
	DDX_CBIndex(pDX, IDC_SNOOZE, m_nSnoozeIndex);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTDLShowReminderDlg, CDialog)
	//{{AFX_MSG_MAP(CTDLShowReminderDlg)
	ON_BN_CLICKED(IDSNOOZE, OnSnooze)
	ON_BN_CLICKED(IDGOTOTASK, OnGototask)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTDLShowReminderDlg message handlers

int CTDLShowReminderDlg::DoModal(const TDCREMINDER& rem)
{
	CString sFormat;
	double dWhen = 0;
	COleDateTime date;

	if (rem.nFromWhen == TDCR_DUEDATE)
	{
		date = rem.pTDC->GetTaskDate(rem.dwTaskID, TDCD_DUE);
		dWhen = date - COleDateTime::GetCurrentTime();

		if (fabs(dWhen) < 1.0)
		{
			dWhen *= 24 * 60; // convert to minutes
			sFormat.LoadString(IDS_DUEWHENREMINDERMINS);
		}
		else
		{
			dWhen *= 24; // convert to hours
			sFormat.LoadString(IDS_DUEWHENREMINDERHOURS);
		}
	}
	else
	{
		date = rem.pTDC->GetTaskDate(rem.dwTaskID, TDCD_START);
		dWhen = date - COleDateTime::GetCurrentTime();

		if (fabs(dWhen) < 1.0)
		{
			dWhen *= 24 * 60; // convert to minutes
			sFormat.LoadString(IDS_BEGINWHENREMINDERMINS);
		}
		else
		{
			dWhen *= 24; // convert to hours
			sFormat.LoadString(IDS_BEGINWHENREMINDERHOURS);
		}
	}

	CString sDateTime = CDateHelper::FormatDate(date, DHFD_DOW | DHFD_NOSEC | DHFD_TIME);

	m_sWhen.Format(sFormat, dWhen, sDateTime);
	m_sTaskTitle = rem.pTDC->GetTaskTitle(rem.dwTaskID);

	return CDialog::DoModal();
}

void CTDLShowReminderDlg::OnSnooze() 
{
	UpdateData();
	EndDialog(IDSNOOZE);	
}

int CTDLShowReminderDlg::GetSnoozeMinutes() const
{
	const UINT SNOOZE[] = { 5, 10, 15, 20, 30, 45, 60 };
	const UINT SIZESNOOZE = sizeof (SNOOZE) / sizeof (UINT);

	ASSERT (m_nSnoozeIndex < SIZESNOOZE);

	if (m_nSnoozeIndex >= SIZESNOOZE)
		return 60;
	else
		return SNOOZE[m_nSnoozeIndex];
}

void CTDLShowReminderDlg::OnGototask() 
{
	EndDialog(IDGOTOTASK);	
}
