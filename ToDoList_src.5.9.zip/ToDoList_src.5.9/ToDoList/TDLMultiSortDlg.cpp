// TDLMultiSortDlg.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "TDLMultiSortDlg.h"
#include "tdcstatic.h"

#include "..\shared\enstring.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTDLMultiSortDlg dialog


CTDLMultiSortDlg::CTDLMultiSortDlg(const TDSORTCOLUMNS& sort, CWnd* pParent /*=NULL*/)
	: CDialog(CTDLMultiSortDlg::IDD, pParent), 
		m_nSortBy1(sort.nBy1), m_nSortBy2(sort.nBy2), m_nSortBy3(sort.nBy3), 
		m_bAscending1(sort.bAscending1), m_bAscending2(sort.bAscending2), m_bAscending3(sort.bAscending3)

{
	//{{AFX_DATA_INIT(CTDLMultiSortDlg)
	//}}AFX_DATA_INIT
}


void CTDLMultiSortDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTDLMultiSortDlg)
	DDX_Control(pDX, IDC_SORTBY3, m_cbSortBy3);
	DDX_Control(pDX, IDC_SORTBY2, m_cbSortBy2);
	DDX_Control(pDX, IDC_SORTBY1, m_cbSortBy1);
	DDX_Check(pDX, IDC_ASCENDING1, m_bAscending1);
	DDX_Check(pDX, IDC_ASCENDING2, m_bAscending2);
	DDX_Check(pDX, IDC_ASCENDING3, m_bAscending3);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTDLMultiSortDlg, CDialog)
	//{{AFX_MSG_MAP(CTDLMultiSortDlg)
	ON_CBN_SELCHANGE(IDC_SORTBY1, OnSelchangeSortby1)
	ON_CBN_SELCHANGE(IDC_SORTBY2, OnSelchangeSortby2)
	ON_CBN_SELCHANGE(IDC_SORTBY3, OnSelchangeSortby3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTDLMultiSortDlg message handlers

BOOL CTDLMultiSortDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	BuildCombos();

	// disable 3rd combo if 2nd combo not set
	m_cbSortBy3.EnableWindow(m_nSortBy2 != TDC_UNSORTED);
	
	GetDlgItem(IDC_ASCENDING3)->EnableWindow(m_nSortBy2 != TDC_UNSORTED && m_nSortBy3 != TDC_UNSORTED);
	GetDlgItem(IDC_ASCENDING2)->EnableWindow(m_nSortBy2 != TDC_UNSORTED);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTDLMultiSortDlg::BuildCombos()
{
	for (int nCol = 0; nCol < NUM_COLUMNS; nCol++)
	{
		TDCCOLUMN& col = COLUMNS[nCol];

		if (col.nSortBy != TDC_UNSORTED)
		{
			int nIndex = m_cbSortBy1.AddString(CEnString(col.nIDLongName));
			m_cbSortBy1.SetItemData(nIndex, col.nSortBy);

			if (m_nSortBy1 == col.nSortBy)
				m_cbSortBy1.SetCurSel(nIndex);

			nIndex = m_cbSortBy2.AddString(CEnString(col.nIDLongName));
			m_cbSortBy2.SetItemData(nIndex, col.nSortBy);

			if (m_nSortBy2 == col.nSortBy)
				m_cbSortBy2.SetCurSel(nIndex);

			nIndex = m_cbSortBy3.AddString(CEnString(col.nIDLongName));
			m_cbSortBy3.SetItemData(nIndex, col.nSortBy);

			if (m_nSortBy3 == col.nSortBy)
				m_cbSortBy3.SetCurSel(nIndex);
		}
	}

	// add blank item at top of 2nd and 3rd combo
	int nIndex = m_cbSortBy2.InsertString(0, "");
	m_cbSortBy2.SetItemData(nIndex, TDC_UNSORTED);
	
	if (m_nSortBy2 == TDC_UNSORTED)
		m_cbSortBy2.SetCurSel(nIndex);
	
	nIndex = m_cbSortBy3.InsertString(0, "");
	m_cbSortBy3.SetItemData(nIndex, TDC_UNSORTED);
	
	if (m_nSortBy3 == TDC_UNSORTED)
		m_cbSortBy3.SetCurSel(nIndex);

	// set selection to first item if first combo selection is not set
	if (m_cbSortBy1.GetCurSel() == -1)
	{
		m_cbSortBy1.SetCurSel(0);
		m_nSortBy1 = (TDC_SORTBY)m_cbSortBy1.GetItemData(0);
	}
}

void CTDLMultiSortDlg::OnSelchangeSortby1() 
{
	UpdateData();
	
	int nSel = m_cbSortBy1.GetCurSel();
	m_nSortBy1 = (TDC_SORTBY)m_cbSortBy1.GetItemData(nSel);
}

void CTDLMultiSortDlg::OnSelchangeSortby2() 
{
	UpdateData();
		
	int nSel = m_cbSortBy2.GetCurSel();
	m_nSortBy2 = (TDC_SORTBY)m_cbSortBy2.GetItemData(nSel);

	GetDlgItem(IDC_ASCENDING2)->EnableWindow(m_nSortBy2 != TDC_UNSORTED);

	// disable 3rd combo if 2nd combo not set
	m_cbSortBy3.EnableWindow(m_nSortBy2 != TDC_UNSORTED);
	GetDlgItem(IDC_ASCENDING3)->EnableWindow(m_nSortBy2 != TDC_UNSORTED && m_nSortBy3 != TDC_UNSORTED);
}

void CTDLMultiSortDlg::OnSelchangeSortby3() 
{
	UpdateData();
		
	int nSel = m_cbSortBy3.GetCurSel();
	m_nSortBy3 = (TDC_SORTBY)m_cbSortBy3.GetItemData(nSel);

	GetDlgItem(IDC_ASCENDING3)->EnableWindow(m_nSortBy2 != TDC_UNSORTED && m_nSortBy3 != TDC_UNSORTED);
}

void CTDLMultiSortDlg::GetSortBy(TDSORTCOLUMNS& sort) const
{
	sort.nBy1 = m_nSortBy1;
	sort.bAscending1 = m_bAscending1;

	sort.nBy2 = m_nSortBy2;

	// if nBy2 is not set then make sure nBy3 isn't set
	if (sort.nBy2 != TDC_UNSORTED)
	{
		sort.bAscending2 = m_bAscending2;
		sort.nBy3 = m_nSortBy3;
		sort.bAscending3 = m_bAscending3;
	}
	else
		sort.nBy3 = TDC_UNSORTED;
}

