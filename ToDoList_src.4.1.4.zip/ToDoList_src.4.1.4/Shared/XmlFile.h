// XmlFile.h: interface for the CXmlFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_XMLFILE_H__54045703_1A98_41AB_B1A1_0B165C350AA0__INCLUDED_)
#define AFX_XMLFILE_H__54045703_1A98_41AB_B1A1_0B165C350AA0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>

// global fns for translating text to/from xml representations eg '&lt;' becomes '<' and vice versa
CString& XML2TXT(CString& xml);
CString& TXT2XML(CString& txt);
CString& TXT2HTML(CString& txt);

const LPCTSTR CDATA = "![CDATA[";

class CXmlItem
{
public:
	CXmlItem();
	CXmlItem(CXmlItem* pParent, LPCTSTR szName, LPCTSTR szValue = NULL);
	CXmlItem(const CXmlItem& xi, CXmlItem* pParent = NULL);
	virtual ~CXmlItem();

	void Reset();

	const CXmlItem* GetItem(LPCTSTR szItemName, LPCTSTR szSubItemName = NULL) const;
	CXmlItem* GetItem(LPCTSTR szItemName, LPCTSTR szSubItemName = NULL);

	const CXmlItem* FindItem(LPCTSTR szItemName, LPCTSTR szItemValue, BOOL bSearchChildren = TRUE) const;
	CXmlItem* FindItem(LPCTSTR szItemName, LPCTSTR szItemValue, BOOL bSearchChildren = TRUE);

	inline LPCTSTR GetName() const { return m_sName; }
	inline LPCTSTR GetValue() const { return m_sValue; }
	inline int GetNameLen() const { return m_sName.GetLength(); }
	inline int GetValueLen() const { return m_sValue.GetLength(); }

	LPCTSTR GetItemValue(LPCTSTR szItemName, LPCTSTR szSubItemName = NULL) const;
	inline int GetItemCount() const { return m_mapItems.GetCount(); }

	inline int GetValueI() const { return atoi(m_sValue); }
	int GetItemValueI(LPCTSTR szItemName, LPCTSTR szSubItemName = NULL) const { return atoi(GetItemValue(szItemName, szSubItemName)); }

	inline double GetValueF() const { return (double)atof(m_sValue); }
	double GetItemValueF(LPCTSTR szItemName, LPCTSTR szSubItemName = NULL) const { return (double)atof(GetItemValue(szItemName, szSubItemName)); }

	CXmlItem* AddItem(LPCTSTR szName, LPCTSTR sValue = NULL);
	CXmlItem* AddItem(LPCTSTR szName, int nValue);
	CXmlItem* AddItem(LPCTSTR szName, const double& fValue);
	CXmlItem* AddItem(const CXmlItem& xi); // item and all attributes are copied
	CXmlItem* AddItem(CXmlItem* pXI); 

	BOOL SetName(LPCTSTR sName); // can't have any siblings
	void SetValue(LPCTSTR sValue);
	void SetValue(int nValue);
	void SetValue(const double& fValue);

	BOOL RemoveItem(CXmlItem* pXIChild); // must be a direct child (does not destroy item)
	BOOL DeleteItem(CXmlItem* pXIChild); // must be a direct child
	void DeleteAllItems() { Reset(); }

	inline const CXmlItem* GetParent() const { return m_pParent; }
	inline const CXmlItem* GetSibling() const { return m_pSibling; }
	inline CXmlItem* GetParent() { return m_pParent; }
	inline CXmlItem* GetSibling() { return m_pSibling; }

	inline BOOL IsAttribute(int nMaxAttribLen = 8192) const 
	{ 
		return (GetValueLen() <= nMaxAttribLen && !m_mapItems.GetCount() && !IsCDATA()); 
	}

	BOOL IsCDATA() const;

	POSITION GetFirstItemPos() const;
	const CXmlItem* GetNextItem(POSITION& pos) const;
	CXmlItem* GetNextItem(POSITION& pos);

	// matching helpers
	BOOL NameMatches(LPCTSTR szName) const;
	BOOL NameMatches(const CXmlItem* pXITest) const;
	BOOL ValueMatches(LPCTSTR szValue, BOOL bIgnoreCase = TRUE) const;
	BOOL ValueMatches(const CXmlItem* pXITest, BOOL bIgnoreCase = TRUE) const;
	BOOL ItemValueMatches(const CXmlItem* pXITest, LPCTSTR szItemName, BOOL bIgnoreCase = TRUE) const;
	
	// sorting
	void SortItems(LPCTSTR szItemName, LPCTSTR szKeyName, BOOL bAscending = TRUE); // sort by string value
	void SortItemsI(LPCTSTR szItemName, LPCTSTR szKeyName, BOOL bAscending = TRUE); // sort by int value
	void SortItemsF(LPCTSTR szItemName, LPCTSTR szKeyName, BOOL bAscending = TRUE); // sort by float value

	static void StrTrim(CString& sText, BOOL bLeft, BOOL bRight);
protected:
	CString m_sName;
	CString m_sValue;

	CXmlItem* m_pParent;
	CXmlItem* m_pSibling;

	CMap<CString, LPCTSTR, CXmlItem*, CXmlItem*&> m_mapItems; // children

protected:
	BOOL AddSibling(CXmlItem* pXI); // must share the same name and parent
	const CXmlItem* GetItemEx(LPCTSTR szItemName, LPCTSTR szSubItemName = NULL) const;
	const CXmlItem* FindItemEx(LPCTSTR szItemName, LPCTSTR szItemValue, BOOL bSearchChildren = TRUE) const;

	enum XI_SORTKEY { XISK_STRING, XISK_INT, XISK_FLOAT };
	void SortItems(LPCTSTR szItemName, LPCTSTR szKeyName, XI_SORTKEY nKey, BOOL bAscending);
	static int CompareItems(const CXmlItem* pXIItem1, const CXmlItem* pXIItem2, LPCTSTR szKeyName, XI_SORTKEY nKey);
};

class IXmlParse
{
public:
	// return TRUE to continue parsing
	virtual BOOL Continue(LPCTSTR szItem, LPCTSTR szValue) const = 0;
};

enum XF_OPEN 
{
	XF_READ,
	XF_WRITE,
	XF_READWRITE,
};

enum // load errors
{
	XFL_NONE,
	XFL_CANCELLED,
	XFL_MISSINGROOT,
	XFL_BADFILE,
};

class CXmlFile : protected CStdioFile  
{
public:
	CXmlFile(LPCTSTR szRootItemName = NULL);
	virtual ~CXmlFile();

	BOOL Load(LPCTSTR szFilePath, LPCTSTR szRootItemName = NULL, IXmlParse* pCallback = NULL);
	BOOL Save(LPCTSTR szFilePath, int nMaxAttribLen = 8192);

	inline void Reset() { m_xiRoot.Reset(); }

	// extended interface
	BOOL Open(LPCTSTR szFilePath, XF_OPEN nOpenFlags);
	virtual BOOL SaveEx(int nMaxAttribLen = 8192);
	virtual BOOL LoadEx(LPCTSTR szRootItemName = NULL, IXmlParse* pCallback = NULL);
	void Close() { CStdioFile::Close(); }
	int GetLastLoadError() { return m_nLoadError; }
	
	BOOL Export(CString& sOutput, int nMaxAttribLen = 8192) const;

	inline const CXmlItem* Root() const { return &m_xiRoot; }
	inline CXmlItem* Root() { return &m_xiRoot; }

	inline const CXmlItem* GetItem(LPCTSTR szItemName) const { return m_xiRoot.GetItem(szItemName); } 
	inline CXmlItem* GetItem(LPCTSTR szItemName) { return m_xiRoot.GetItem(szItemName); }

	inline const CXmlItem* FindItem(LPCTSTR szItemName, LPCTSTR szItemValue, BOOL bSearchChildren = TRUE) const
		{ return m_xiRoot.FindItem(szItemName, szItemValue, bSearchChildren); }

	inline CXmlItem* FindItem(LPCTSTR szItemName, LPCTSTR szItemValue, BOOL bSearchChildren = TRUE)
		{ return m_xiRoot.FindItem(szItemName, szItemValue, bSearchChildren); }

	inline CXmlItem* AddItem(LPCTSTR szName, LPCTSTR szValue = "") { return m_xiRoot.AddItem(szName, szValue); }
	inline CXmlItem* AddItem(LPCTSTR szName, int nValue) { return m_xiRoot.AddItem(szName, nValue); }
	inline CXmlItem* AddItem(LPCTSTR szName, const double& fValue) { return m_xiRoot.AddItem(szName, fValue); }

	inline BOOL DeleteItem(CXmlItem* pXI) { return m_xiRoot.DeleteItem(pXI); }

	inline LPCTSTR GetItemValue(LPCTSTR szItemName, LPCTSTR szSubItemName = NULL) const { return m_xiRoot.GetItemValue(szItemName, szSubItemName); }
	inline int GetItemValueI(LPCTSTR szItemName, LPCTSTR szSubItemName = NULL) const { return m_xiRoot.GetItemValueI(szItemName, szSubItemName); }
	inline double GetItemValueF(LPCTSTR szItemName, LPCTSTR szSubItemName = NULL) const { return m_xiRoot.GetItemValueF(szItemName, szSubItemName); }

	inline CString GetFilePath() const { return CStdioFile::GetFilePath(); }
	inline const HANDLE GetFileHandle() const { return (HANDLE)CStdioFile::m_hFile; }

	inline LPCTSTR GetHeader() const { return m_sHeader; }
	inline void SetHeader(LPCTSTR szHeader) { m_sHeader = szHeader; m_sHeader.MakeLower(); }

	void Trace() const;

	// sorting
	inline void SortItems(LPCTSTR szItemName, LPCTSTR szKeyName, BOOL bAscending = TRUE)
		{ m_xiRoot.SortItems(szItemName, szKeyName, bAscending); }
	inline void SortItemsI(LPCTSTR szItemName, LPCTSTR szKeyName, BOOL bAscending = TRUE)
		{ m_xiRoot.SortItemsI(szItemName, szKeyName, bAscending); }
	inline void SortItemsF(LPCTSTR szItemName, LPCTSTR szKeyName, BOOL bAscending = TRUE)
		{ m_xiRoot.SortItemsF(szItemName, szKeyName, bAscending); }

protected:
	CXmlItem m_xiRoot;
	CString m_sHeader;
	IXmlParse* m_pCallback;
	int m_nLoadError;
	
protected:
	BOOL ParseItem(CXmlItem& xi, LPCTSTR& sFile); // returns false if the callback stopped it
	BOOL ParseRootItem(LPCTSTR szRootItemName, LPCTSTR& sFile);
	virtual void GetNextItem(LPCTSTR& sFile, CString& sItem);
	virtual void GetNextValue(LPCTSTR& sFile, int nItemType, CString& sValue);
	void PreProcessItem(CString& sItem, CString& sAttributes, BOOL& bHasEndTag);
	void PreProcessCDATA(CString& sItem, CString& sData);
	void PreProcessComment(CString& sItem, CString& sComment);
	BOOL ProcessAttributes(CXmlItem& xi, CString& sItem); // returns false if the callback stopped it
	inline ContinueParsing(LPCTSTR szItem, LPCTSTR szValue) 
		{ return (!m_pCallback || m_pCallback->Continue(szItem, szValue)); }
	int GetItemType(const CString& sItem);

	static int StrCopy(CString& sDest, LPCTSTR szSrc, int nCount = -1);
	static int StrAppend(LPTSTR& szDest, LPCTSTR szSrc, int nCount = -1);

	int Export(const CXmlItem* pItem, int nDepth, int nMaxAttribLen, LPTSTR& szOutput) const;
	int GetExportLengthEstimate(const CXmlItem* pItem, int nDepth, int nMaxAttribLen) const;
	int ExportAsAttribute(const CXmlItem* pItem, int nMaxAttribLen, LPTSTR& szOutput) const;
	int GetExportValueLength(const CXmlItem* pItem) const;
};

#endif // !defined(AFX_XMLFILE_H__54045703_1A98_41AB_B1A1_0B165C350AA0__INCLUDED_)
