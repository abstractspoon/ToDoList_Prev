// GanttChartWnd.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "GanttChartExt.h"
#include "GanttChartWnd.h"

#include "..\shared\misc.h"
#include "..\shared\themed.h"
#include "..\shared\graphicsmisc.h"
#include "..\shared\dialoghelper.h"
#include "..\shared\ipreferences.h"
#include "..\shared\datehelper.h"
#include "..\shared\localizer.h"

#include "..\todolist\tdcenum.h"
#include "..\todolist\tdcmsg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const COLORREF DEF_ALTLINECOLOR		= RGB(230, 230, 255);
const COLORREF DEF_GRIDLINECOLOR	= RGB(192, 192, 192);
const COLORREF DEF_DONECOLOR		= RGB(128, 128, 128);

#ifndef LVS_EX_DOUBLEBUFFER
#define LVS_EX_DOUBLEBUFFER 0x00010000
#endif

/////////////////////////////////////////////////////////////////////////////
// CGanttChartWnd

CGanttChartWnd::CGanttChartWnd(CWnd* pParent /*=NULL*/)
	: 
	CDialog(IDD_GANTTTREE_DIALOG, pParent), 
	m_hIcon(NULL),
	m_nDisplay(GTLC_DISPLAY_MONTHS_LONG)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_GANTTCHART);
}

CGanttChartWnd::~CGanttChartWnd()
{
}

void CGanttChartWnd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGanttChartWnd)
	DDX_Control(pDX, IDC_SNAPMODES, m_cbSnapModes);
	DDX_Control(pDX, IDC_DIVIDER, m_stDivider);
	DDX_Control(pDX, IDC_GANTTLIST, m_list);
	DDX_Control(pDX, IDC_GANTTTREE, m_tree);
	DDX_CBIndex(pDX, IDC_DISPLAY, (int&)m_nDisplay);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_DISPLAY, m_cbDisplayOptions);
	DDX_Text(pDX, IDC_SELECTEDTASKDATES, m_sSelectedTaskDates);
}

BEGIN_MESSAGE_MAP(CGanttChartWnd, CDialog)
	//{{AFX_MSG_MAP(CGanttChartWnd)
	ON_BN_CLICKED(IDC_GOTOTODAY, OnGototoday)
	ON_WM_SIZE()
	ON_WM_CTLCOLOR()
	ON_NOTIFY(TVN_KEYUP, IDC_GANTTTREE, OnKeyUpGantt)
	ON_CBN_SELCHANGE(IDC_DISPLAY, OnSelchangeDisplay)
	ON_NOTIFY(NM_CLICK, IDC_GANTTLIST, OnClickGanttList)
	ON_NOTIFY(TVN_SELCHANGED, IDC_GANTTTREE, OnSelchangedGanttTree)
	ON_WM_SETFOCUS()
	ON_BN_CLICKED(IDC_PREFERENCES, OnPreferences)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_GANTTCTRL_NOTIFY_ZOOM, OnNotifyZoomChange)
	ON_WM_ERASEBKGND()
	ON_REGISTERED_MESSAGE(WM_GANTT_DATECHANGE, OnGanttNotifyDateChange)
	ON_REGISTERED_MESSAGE(WM_GANTT_DRAGCHANGE, OnGanttNotifyDragChange)
	ON_CBN_SELCHANGE(IDC_SNAPMODES, OnSelchangeSnapMode)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CGanttChartWnd message handlers

BOOL CGanttChartWnd::Create(DWORD dwStyle, const RECT &rect, CWnd* pParentWnd, UINT nID)
{
	if (CDialog::Create(IDD_GANTTTREE_DIALOG, pParentWnd))
	{
		SetWindowLong(*this, GWL_STYLE, dwStyle);
		SetDlgCtrlID(nID);

		return TRUE;
	}

	return FALSE;
}

void CGanttChartWnd::SavePreferences(IPreferences* pPrefs, LPCTSTR szKey) const 
{
	CString sKey;
	sKey.Format(_T("%s\\%s"), szKey, GetTypeID());

	pPrefs->WriteProfileInt(sKey, _T("MonthDisplay"), m_nDisplay);

	// snap modes
	CString sSnapKey = sKey + _T("\\Snap");

	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_YEARS, _T("Year"));
	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_QUARTERS_SHORT, _T("QuarterShort"));
	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_QUARTERS_MID, _T("QuarterMid"));
	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_QUARTERS_LONG, _T("QuarterLong"));
	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_MONTHS_SHORT, _T("MonthShort"));
	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_MONTHS_MID, _T("MonthMid"));
	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_MONTHS_LONG, _T("MonthLong"));
	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_WEEKS_SHORT, _T("WeekShort"));
	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_WEEKS_MID, _T("WeekMid"));
	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_WEEKS_LONG, _T("WeekLong"));
	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_DAYS_SHORT, _T("DayShort"));
	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_DAYS_MID, _T("DayMid"));
	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_DAYS_LONG, _T("DayLong"));

	m_dlgPrefs.SavePreferences(pPrefs, sKey);
}

void CGanttChartWnd::LoadPreferences(const IPreferences* pPrefs, LPCTSTR szKey, BOOL bAppOnly) 
{
	CString sKey;
	sKey.Format(_T("%s\\%s"), szKey, GetTypeID());

	// application preferences

	// Completion color and strikethru
	BOOL bStrikeThru = pPrefs->GetProfileInt(_T("Preferences"), _T("StrikethroughDone"), TRUE);

	if (pPrefs->GetProfileInt(_T("Preferences"), _T("SpecifyDoneColor"), TRUE))
	{
		COLORREF crDone = pPrefs->GetProfileInt(_T("Preferences\\Colors"), _T("TaskDone"), DEF_DONECOLOR);
		m_ctrlGantt.SetDoneTaskAttributes(crDone, bStrikeThru);
	}
	else
		m_ctrlGantt.SetDoneTaskAttributes(CLR_NONE, bStrikeThru);

	// get alternate line color from app prefs
	if (pPrefs->GetProfileInt(_T("Preferences"), _T("AlternateLineColor"), TRUE))
	{
		COLORREF crAltLine = pPrefs->GetProfileInt(_T("Preferences\\Colors"), _T("AlternateLines"), DEF_ALTLINECOLOR);
		m_ctrlGantt.SetAlternateLineColor(crAltLine);
	}
	else
		m_ctrlGantt.SetAlternateLineColor(CLR_NONE);

	// get grid line color from app prefs
	if (pPrefs->GetProfileInt(_T("Preferences"), _T("SpecifyGridColor"), TRUE))
	{
		COLORREF crGridLine = pPrefs->GetProfileInt(_T("Preferences\\Colors"), _T("GridLines"), DEF_GRIDLINECOLOR);
		m_ctrlGantt.SetGridLineColor(crGridLine);
	}
	else
		m_ctrlGantt.SetGridLineColor(CLR_NONE);

	// full row selection
	BOOL bFullRowSel = pPrefs->GetProfileInt(_T("Preferences"), _T("FullRowSelection"), FALSE);

	if (bFullRowSel)
		m_tree.ModifyStyle(TVS_HASLINES, TVS_FULLROWSELECT);
	else
		m_tree.ModifyStyle(TVS_FULLROWSELECT, TVS_HASLINES);

	DWORD dwWeekends = pPrefs->GetProfileInt(_T("Preferences"), _T("Weekends"), (DHW_SATURDAY | DHW_SUNDAY));
	CDateHelper::SetWeekendDays(dwWeekends);

	// gantt specific options
	if (!bAppOnly)
	{
		// snap modes
		CString sSnapKey = sKey + _T("\\Snap");

		LoadSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_YEARS, _T("Year"), GTLCSM_NEARESTMONTH);
		LoadSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_QUARTERS_SHORT, _T("QuarterShort"), GTLCSM_NEARESTMONTH);
		LoadSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_QUARTERS_MID, _T("QuarterMid"), GTLCSM_NEARESTMONTH);
		LoadSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_QUARTERS_LONG, _T("QuarterLong"), GTLCSM_NEARESTMONTH);
		LoadSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_MONTHS_SHORT, _T("MonthShort"), GTLCSM_NEARESTDAY);
		LoadSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_MONTHS_MID, _T("MonthMid"), GTLCSM_NEARESTDAY);
		LoadSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_MONTHS_LONG, _T("MonthLong"), GTLCSM_NEARESTDAY);
		LoadSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_WEEKS_SHORT, _T("WeekShort"), GTLCSM_NEARESTDAY);
		LoadSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_WEEKS_MID, _T("WeekMid"), GTLCSM_NEARESTDAY);
		LoadSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_WEEKS_LONG, _T("WeekLong"), GTLCSM_NEARESTDAY);
		LoadSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_DAYS_SHORT, _T("DayShort"), GTLCSM_NEARESTHOUR);
		LoadSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_DAYS_MID, _T("DayMid"), GTLCSM_NEARESTHOUR);
		LoadSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_DAYS_LONG, _T("DayLong"), GTLCSM_NEARESTHOUR);

		// last display
		m_nDisplay = (GTLC_MONTH_DISPLAY)pPrefs->GetProfileInt(sKey, _T("MonthDisplay"), GTLC_DISPLAY_MONTHS_LONG);
		UpdateMonthDisplay();

		m_dlgPrefs.LoadPreferences(pPrefs, sKey);
		UpdateGanttCtrlPreferences();

		if (GetSafeHwnd())
			UpdateData(FALSE);
	}
}

void CGanttChartWnd::LoadSnapModePreference(const IPreferences* pPrefs, LPCTSTR szSnapKey, GTLC_MONTH_DISPLAY nDisplay, LPCTSTR szDisplay, GTLC_SNAPMODE nDefaultSnap) 
{
	m_mapDisplaySnapModes[nDisplay]	= (GTLC_SNAPMODE)pPrefs->GetProfileInt(szSnapKey, szDisplay, nDefaultSnap);
}

void CGanttChartWnd::SaveSnapModePreference(IPreferences* pPrefs, LPCTSTR szSnapKey, GTLC_MONTH_DISPLAY nDisplay, LPCTSTR szDisplay) const
{
	GTLC_SNAPMODE nSnap = GTLCSM_FREE;

	VERIFY (m_mapDisplaySnapModes.Lookup(nDisplay, nSnap));
	pPrefs->WriteProfileInt(szSnapKey, szDisplay, nSnap);
}

void CGanttChartWnd::SetUITheme(const UITHEME* pTheme)
{
	GraphicsMisc::VerifyDeleteObject(m_brBack);

	if (CThemed::IsThemeActive() && pTheme)
	{
		m_theme = *pTheme;
		m_brBack.CreateSolidBrush(pTheme->crAppBackLight);
	}
}

bool CGanttChartWnd::ProcessMessage(MSG* pMsg) 
{
	if (!IsWindowEnabled())
		return false;

	// process editing shortcuts
	// TODO

	return false;
}

bool CGanttChartWnd::PrepareNewTask(ITaskList* pTask) const
{
	return m_ctrlGantt.PrepareNewTask(pTask);
}

bool CGanttChartWnd::GetLabelEditRect(LPRECT pEdit)
{
	HTREEITEM htiSel = m_tree.GetSelectedItem();

	// scroll into view first
	m_tree.EnsureVisible(htiSel);

	if (m_tree.GetItemRect(htiSel, pEdit, TRUE))
	{
		// convert from tree to 'our' coords
		m_tree.ClientToScreen(pEdit);
		return true;
	}

	return false;
}

IUI_HITTEST CGanttChartWnd::HitTest(const POINT& ptScreen) const
{
	// try tree header
	if (m_ctrlGantt.PtInHeader(ptScreen))
		return IUI_COLUMNHEADER;

	// then specific task
	if (m_ctrlGantt.HitTest(ptScreen))
		return IUI_TASK;

	// else check else where in tree or list client
	CRect rGantt;
	
	m_tree.GetClientRect(rGantt);
	m_tree.ClientToScreen(rGantt);

	if (rGantt.PtInRect(ptScreen))
		return IUI_TASKLIST;

	m_list.GetClientRect(rGantt);
	m_list.ClientToScreen(rGantt);

	if (rGantt.PtInRect(ptScreen))
		return IUI_TASKLIST;

	// else 
	return IUI_NOWHERE;
}


bool CGanttChartWnd::SelectTask(DWORD dwTaskID)
{
	return (m_ctrlGantt.SelectTask(dwTaskID) != FALSE);
}

bool CGanttChartWnd::SelectTasks(DWORD* pdwTaskIDs, int nTaskCount)
{
	return false; // only support single selection
}

bool CGanttChartWnd::WantUpdate(int nAttribute) const
{
	switch (nAttribute)
	{
	case TDCA_TASKNAME:
	case TDCA_DONEDATE:
	case TDCA_DUEDATE:
	case TDCA_STARTDATE:
	case TDCA_ALLOCTO:
	case TDCA_COLOR:
	case TDCA_TAGS:
 	case TDCA_PERCENT:
// 	case TDCA_TIMEEST:
// 	case TDCA_TIMESPENT:
		return true;
	}

	// all else 
	return false;
}

void CGanttChartWnd::UpdateTasks(const ITaskList* pTasks, IUI_UPDATETYPE nUpdate, int nEditAttribute)
{
	m_ctrlGantt.UpdateTasks(pTasks, nUpdate, nEditAttribute);

	UpdateSelectedTaskDates();
}

void CGanttChartWnd::Release()
{
	if (GetSafeHwnd())
		DestroyWindow();
	
	delete this;
}

void CGanttChartWnd::DoAppCommand(IUI_APPCOMMAND nCmd) 
{ 
	switch (nCmd)
	{
	case IUI_EXPANDALL:
		m_ctrlGantt.ExpandAll(TRUE);
		break;

	case IUI_COLLAPSEALL:
		m_ctrlGantt.ExpandAll(FALSE);
		break;

	case IUI_EXPANDSELECTED:
		{
			HTREEITEM htiSel = m_ctrlGantt.GetSelectedItem();
			m_ctrlGantt.ExpandItem(htiSel, TRUE, TRUE);
		}
		break;

	case IUI_COLLAPSESELECTED:
		{
			HTREEITEM htiSel = m_ctrlGantt.GetSelectedItem();
			m_ctrlGantt.ExpandItem(htiSel, FALSE);
		}
		break;

	case IUI_TOGGLESORT:
		m_ctrlGantt.Resort(TRUE);
		break;
				
	case IUI_RESORT:
		m_ctrlGantt.Resort(FALSE);
		break;

	case IUI_SETFOCUS:
		m_ctrlGantt.SetFocus();
		break;
	}
}

bool CGanttChartWnd::CanDoAppCommand(IUI_APPCOMMAND nCmd) const 
{ 
	switch (nCmd)
	{
	case IUI_EXPANDALL:
	case IUI_COLLAPSEALL:
		return true;

	case IUI_EXPANDSELECTED:
		{
			HTREEITEM htiSel = m_ctrlGantt.GetSelectedItem();
			return (m_ctrlGantt.CanExpandItem(htiSel, TRUE) != FALSE);
		}
		break;
	case IUI_COLLAPSESELECTED:
		{
			HTREEITEM htiSel = m_ctrlGantt.GetSelectedItem();
			return (m_ctrlGantt.CanExpandItem(htiSel, FALSE) != FALSE);
		}
		break;

	case IUI_TOGGLESORT:
	case IUI_RESORT:
		return (m_ctrlGantt.IsSorted() != FALSE);

	case IUI_SETFOCUS:
		return (m_ctrlGantt.HasFocus() != FALSE);
	}

	// all else
	return false;
}

void CGanttChartWnd::OnGototoday() 
{
	m_ctrlGantt.ScrollToToday();

	// and set focus back to it
	m_ctrlGantt.SetFocus();
}

void CGanttChartWnd::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	Resize(cx, cy);
}

BOOL CGanttChartWnd::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// non-translatables
	CLocalizer::EnableTranslation(*GetDlgItem(IDC_SELECTEDTASKDATES), FALSE);
	
	// set extra styles on list
	DWORD dwExStyle = (m_list.GetExtendedStyle() | LVS_EX_DOUBLEBUFFER);
	m_list.SetExtendedStyle(dwExStyle);

	// init syncer
	m_ctrlGantt.Initialize(m_tree, m_list, IDC_TREEHEADER);
	m_ctrlGantt.ExpandAll();

	CRect rClient;
	GetClientRect(rClient);
	Resize(rClient.Width(), rClient.Height());

	m_ctrlGantt.ScrollToToday();

	m_nDisplay = m_ctrlGantt.GetMonthDisplay();
	UpdateData(FALSE);
	BuildSnapCombo();

	m_ctrlGantt.SetFocus();
	
	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CGanttChartWnd::Resize(int cx, int cy)
{
	if (m_tree.GetSafeHwnd())
	{
		m_stDivider.MoveWindow(CRect(0, 0, cx, 1));

		CRect rDisplay;
		m_cbDisplayOptions.GetWindowRect(rDisplay);
		ScreenToClient(rDisplay);

		CRect rGantt(0, rDisplay.bottom + 9, cx, cy);
		m_ctrlGantt.Resize(rGantt);

		// selected task dates takes available space
		int nOffset = cx - CDialogHelper::GetCtrlRect(this, IDC_SELECTEDTASKDATES).right;
		CDialogHelper::ResizeCtrl(this, IDC_SELECTEDTASKDATES, nOffset, 0);

		// always redraw the selected task dates
		GetDlgItem(IDC_SELECTEDTASKDATES)->Invalidate(FALSE);
	}
}


HBRUSH CGanttChartWnd::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	if (nCtlColor == CTLCOLOR_STATIC && m_brBack.GetSafeHandle())
	{
		pDC->SetTextColor(m_theme.crAppText);
		pDC->SetBkMode(TRANSPARENT);
		hbr = m_brBack;
	}

	return hbr;
}

BOOL CGanttChartWnd::OnEraseBkgnd(CDC* pDC) 
{
	// let the gantt do its thing
	m_ctrlGantt.HandleEraseBkgnd(pDC);

	// then our background
	if (m_brBack.GetSafeHandle())
	{
		CRect rClient;
		GetClientRect(rClient);

		pDC->FillSolidRect(rClient, m_theme.crAppBackLight);
		return TRUE;
	}
	
	// else
	return CDialog::OnEraseBkgnd(pDC);
}

void CGanttChartWnd::OnKeyUpGantt(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NMTVKEYDOWN* pTVKD = (NMTVKEYDOWN*)pNMHDR;
	
	switch (pTVKD->wVKey)
	{
	case VK_UP:
	case VK_DOWN:
	case VK_PRIOR:
	case VK_NEXT:
		UpdateSelectedTaskDates();
		SendParentSelectionUpdate();
		break;
	}
	
	*pResult = 0;
}

void CGanttChartWnd::SendParentSelectionUpdate()
{
	DWORD dwTaskID = m_ctrlGantt.GetSelectedTaskID();
	GetParent()->SendMessage(WM_IUI_SELECTTASK, 0, dwTaskID);
}

void CGanttChartWnd::OnClickGanttList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	UpdateSelectedTaskDates();
	SendParentSelectionUpdate();

	*pResult = 0;
}

void CGanttChartWnd::UpdateMonthDisplay()
{
	BuildSnapCombo();

	m_ctrlGantt.SetMonthDisplay((GTLC_MONTH_DISPLAY)m_nDisplay);

	// get previous snap mode for this display
	GTLC_SNAPMODE nSnap = GTLCSM_FREE;
	VERIFY(m_mapDisplaySnapModes.Lookup(m_nDisplay, nSnap));

	m_ctrlGantt.SetSnapMode(nSnap);
	CDialogHelper::SelectItemByData(m_cbSnapModes, nSnap);
}

void CGanttChartWnd::OnSelchangeDisplay() 
{
	UpdateData();
	UpdateMonthDisplay();
}

void CGanttChartWnd::OnSelchangeSnapMode() 
{
	// save snap mode as we go
	GTLC_SNAPMODE nSnap = (GTLC_SNAPMODE)CDialogHelper::GetSelectedItemData(m_cbSnapModes);
	m_mapDisplaySnapModes[m_nDisplay] = nSnap;

	m_ctrlGantt.SetSnapMode(nSnap);
}

LRESULT CGanttChartWnd::OnNotifyZoomChange(WPARAM /*wp*/, LPARAM lp)
{
	m_nDisplay = (GTLC_MONTH_DISPLAY)lp;
	m_cbDisplayOptions.SetCurSel(m_nDisplay);

	return 0L;
}

void CGanttChartWnd::OnSelchangedGanttTree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

	// we're only interested in non-keyboard changes
	// because keyboard gets handled explicitly above
	if (pNMTreeView->action != TVC_BYKEYBOARD)
	{
		UpdateSelectedTaskDates();
		SendParentSelectionUpdate();
	}
	
	*pResult = 0;
}

void CGanttChartWnd::OnSetFocus(CWnd* pOldWnd) 
{
	CDialog::OnSetFocus(pOldWnd);
	
	m_tree.SetFocus();
}

void CGanttChartWnd::OnPreferences() 
{
	if (m_dlgPrefs.DoModal() == IDOK)
	{
		// update gantt control
		UpdateGanttCtrlPreferences();

		// and set focus back to it
		m_ctrlGantt.SetFocus();
	}
}

void CGanttChartWnd::UpdateGanttCtrlPreferences()
{
	m_ctrlGantt.SetOption(GTLCF_DISPLAYALLOCTOCOLUMN, m_dlgPrefs.GetDisplayAllocToColumn());
	m_ctrlGantt.SetOption(GTLCF_DISPLAYALLOCTOAFTERITEM, m_dlgPrefs.GetDisplayAllocTo());
	m_ctrlGantt.SetOption(GTLCF_AUTOSCROLLTOTASK, m_dlgPrefs.GetAutoScrollSelection());
	m_ctrlGantt.SetOption(GTLCF_CALCPARENTDATES, m_dlgPrefs.GetAutoCalcParentDates());
	m_ctrlGantt.SetOption(GTLCF_CALCMISSINGSTARTDATES, m_dlgPrefs.GetCalculateMissingStartDates());
	m_ctrlGantt.SetOption(GTLCF_CALCMISSINGDUEDATES, m_dlgPrefs.GetCalculateMissingDueDates());
	m_ctrlGantt.SetOption(GTLCF_DISPLAYPROGRESSINBAR, m_dlgPrefs.GetDisplayProgressInBar());

	m_ctrlGantt.SetTodayColor(m_dlgPrefs.GetTodayColor());
	m_ctrlGantt.SetWeekendColor(m_dlgPrefs.GetWeekendColor());
	m_ctrlGantt.SetMilestoneTag(m_dlgPrefs.GetMilestoneTag());

	COLORREF crParent;
	GTLC_PARENTCOLORING nOption = (GTLC_PARENTCOLORING)m_dlgPrefs.GetParentColoring(crParent);

	m_ctrlGantt.SetParentColoring(nOption, crParent);
}

LRESULT CGanttChartWnd::OnGanttNotifyDateChange(WPARAM wp, LPARAM lp)
{
	COleDateTime dtStart, dtDue;

	if (m_ctrlGantt.GetSelectedTaskDates(dtStart, dtDue))
	{
		switch (wp)
		{
		case GTLCHT_BEGIN:
			GetParent()->SendMessage(WM_IUI_MODIFYSELECTEDTASK, TDCA_STARTDATE, (LPARAM)&(dtStart.m_dt));
			break;
			
		case GTLCHT_MIDDLE:
			GetParent()->SendMessage(WM_IUI_MODIFYSELECTEDTASK, TDCA_STARTDATE, (LPARAM)&(dtStart.m_dt));
			GetParent()->SendMessage(WM_IUI_MODIFYSELECTEDTASK, TDCA_DUEDATE, (LPARAM)&(dtDue.m_dt));
			break;

		case GTLCHT_END:
			GetParent()->SendMessage(WM_IUI_MODIFYSELECTEDTASK, TDCA_DUEDATE, (LPARAM)&(dtDue.m_dt));
			break;
		}
	}

	return 0L;
}

void CGanttChartWnd::UpdateSelectedTaskDates()
{
	COleDateTime dtStart, dtDue;
	
	if (m_ctrlGantt.GetSelectedTaskDates(dtStart, dtDue))
	{
		CString sStart, sDue;

		if (CDateHelper::DateHasTime(dtStart))
			sStart = CDateHelper::FormatDate(dtStart, DHFD_TIME | DHFD_NOSEC);
		else
			sStart = CDateHelper::FormatDate(dtStart);

		if (CDateHelper::DateHasTime(dtDue))
			sDue = CDateHelper::FormatDate(dtDue, DHFD_TIME | DHFD_NOSEC);
		else
			sDue = CDateHelper::FormatDate(dtDue);

		m_sSelectedTaskDates.Format(_T("%s - %s"), sStart, sDue);
	}
	else
	{
		m_sSelectedTaskDates.Empty();
	}

	UpdateData(FALSE);
}

LRESULT CGanttChartWnd::OnGanttNotifyDragChange(WPARAM wp, LPARAM /*lp*/)
{
	// save snap changes as we go
	GTLC_SNAPMODE nSnap = (GTLC_SNAPMODE)wp;
	m_mapDisplaySnapModes[m_nDisplay] = nSnap;

	CDialogHelper::SelectItemByData(m_cbSnapModes, nSnap);
	UpdateSelectedTaskDates();

	return 0L;
}

void CGanttChartWnd::BuildSnapCombo()
{
	m_cbSnapModes.ResetContent();

	switch (m_nDisplay)
	{
	case GTLC_DISPLAY_YEARS:
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_NEARESTHALFYEAR, GTLCSM_NEARESTHALFYEAR);
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_NEARESTMONTH, GTLCSM_NEARESTMONTH);
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_NEARESTYEAR, GTLCSM_NEARESTYEAR);
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_FREE, GTLCSM_FREE);
		break;
		
	case GTLC_DISPLAY_QUARTERS_SHORT:
	case GTLC_DISPLAY_QUARTERS_MID:
	case GTLC_DISPLAY_QUARTERS_LONG:
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_NEARESTMONTH, GTLCSM_NEARESTMONTH);
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_NEARESTQUARTER, GTLCSM_NEARESTQUARTER);
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_FREE, GTLCSM_FREE);
		break;
		
	case GTLC_DISPLAY_MONTHS_SHORT:
	case GTLC_DISPLAY_MONTHS_MID:
	case GTLC_DISPLAY_MONTHS_LONG:
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_NEARESTDAY, GTLCSM_NEARESTDAY);
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_NEARESTMONTH, GTLCSM_NEARESTMONTH);
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_FREE, GTLCSM_FREE);
		break;
		
	case GTLC_DISPLAY_WEEKS_SHORT:
	case GTLC_DISPLAY_WEEKS_MID:
	case GTLC_DISPLAY_WEEKS_LONG:
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_NEARESTDAY, GTLCSM_NEARESTDAY);
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_NEARESTWEEK, GTLCSM_NEARESTWEEK);
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_FREE, GTLCSM_FREE);
		break;
		
	case GTLC_DISPLAY_DAYS_SHORT:
	case GTLC_DISPLAY_DAYS_MID:
	case GTLC_DISPLAY_DAYS_LONG:
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_NEARESTHALFDAY, GTLCSM_NEARESTHALFDAY);
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_NEARESTHOUR, GTLCSM_NEARESTHOUR);
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_NEARESTDAY, GTLCSM_NEARESTDAY);
		CDialogHelper::AddString(m_cbSnapModes, IDS_SNAP_FREE, GTLCSM_FREE);
		break;
	}

	CDialogHelper::SelectItemByData(m_cbSnapModes, m_ctrlGantt.GetSnapMode());
}
