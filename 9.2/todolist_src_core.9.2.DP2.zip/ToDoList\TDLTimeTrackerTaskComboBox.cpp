// TDLTimeTrackerTaskComboBox.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "TDLTimeTrackerTaskComboBox.h"
#include "FilteredToDoCtrl.h"

#include "..\shared\DialogHelper.h"
#include "..\shared\HoldRedraw.h"
#include "..\shared\Misc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTDLTimeTrackerTaskComboBox

CTDLTimeTrackerTaskComboBox::CTDLTimeTrackerTaskComboBox() : m_pTDC(NULL)
{
}

CTDLTimeTrackerTaskComboBox::~CTDLTimeTrackerTaskComboBox()
{
}

BEGIN_MESSAGE_MAP(CTDLTimeTrackerTaskComboBox, CTDLTaskComboBox)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTDLTimeTrackerTaskComboBox message handlers

void CTDLTimeTrackerTaskComboBox::ResetContent()
{
	CTDLTaskComboBox::ResetContent();

	m_pTDC = NULL;
	m_pIlTasks = NULL; // from base class
}

int CTDLTimeTrackerTaskComboBox::Rebuild(const TRACKTASKLIST* pTTL)
{
	ASSERT(!HasStyle(CBS_SORT));

	if (!pTTL)
	{
		ASSERT(pTTL);
		return 0;
	}

	BOOL bTasklistChange = (pTTL->pTDC != m_pTDC);
	DWORD dwSelTaskID = 0;
	
	if (pTTL->IsTracking())
	{
		dwSelTaskID = pTTL->GetTrackedTaskID();
	}
	else if (!bTasklistChange)
	{
		dwSelTaskID = GetSelectedTaskID(FALSE);
	}
		
	ResetContent();

	CHoldRedraw hr(*this);

	m_pTDC = pTTL->pTDC;
	m_pIlTasks = &m_pTDC->GetTaskIconImageList();

	int nNumTasks = pTTL->aTasks.GetSize();

	for (int nTask = 0; nTask < nNumTasks; nTask++)
	{
		const TRACKITEM& ti = Misc::GetItemT<TRACKITEM>(pTTL->aTasks, nTask);
		int nImage = m_pIlTasks->GetImageIndex(ti.sImage);

		InsertTask(nTask, 
				   ti.sTask, 
				   ti.dwTaskID, 
				   ti.nLevel, 
				   nImage,
				   ti.bParent ? TCBA_PARENT : 0);
	}

	UpdateRecentlyTrackedTasks(pTTL, dwSelTaskID);

	CDialogHelper::RefreshMaxDropWidth(*this);

	return GetCount();
}

int CTDLTimeTrackerTaskComboBox::Update(const TRACKTASKLIST* pTTL, const CDWordArray& aModTaskIDs)
{
	ASSERT(pTTL && aModTaskIDs.GetSize());

	CMapTaskIndex mapTTItems;
	pTTL->aTasks.BuildTaskMap(mapTTItems);

	// Update 'All Tasks'
	CMapTaskIndex mapCBItems;
	VERIFY(BuildItemMap(mapCBItems) || !GetCount()); // excludes recently tracked

	int nNumUpdated = Update(pTTL, aModTaskIDs, mapTTItems, mapCBItems);
	
	// Update 'Recently Tracked'
	if (BuildRecentlyTrackedItemMap(mapCBItems))
	{
		nNumUpdated += Update(pTTL, aModTaskIDs, mapTTItems, mapCBItems);
	}

	return nNumUpdated;
}

int CTDLTimeTrackerTaskComboBox::Update(const TRACKTASKLIST* pTTL, const CDWordArray& aModTaskIDs,
										const CMapTaskIndex& mapTTItems, const CMapTaskIndex& mapCBItems)
{
	if (GetCount() == 0)
	{
		ASSERT(mapCBItems.IsEmpty());
		return 0;
	}

	if (!m_pIlTasks)
		m_pIlTasks = &pTTL->pTDC->GetTaskIconImageList();
	else
		ASSERT(m_pIlTasks == &pTTL->pTDC->GetTaskIconImageList());

	int nNumUpdated = 0, nID = aModTaskIDs.GetSize();

	while (nID--)
	{
		int nTTItem = -1, nCBItem = -1;
		DWORD dwTaskID = aModTaskIDs[nID];
		
		if (mapCBItems.Lookup(dwTaskID, nCBItem) &&
			mapTTItems.Lookup(dwTaskID, nTTItem))
		{
			const TRACKITEM& ti = Misc::GetItemT<TRACKITEM>(pTTL->aTasks, nTTItem);
			int nNewImage = m_pIlTasks->GetImageIndex(ti.sImage);

			if (ModifyItem(nCBItem, ti.sTask, nNewImage))
				nNumUpdated++;
		}
	}

	return nNumUpdated;
}

void CTDLTimeTrackerTaskComboBox::UpdateRecentlyTrackedTasks(const TRACKTASKLIST* pTTL)
{
	DWORD dwSelTaskID = (pTTL->IsTracking() ? pTTL->GetTrackedTaskID() : GetSelectedTaskID(FALSE));

	UpdateRecentlyTrackedTasks(pTTL, dwSelTaskID);
}

void CTDLTimeTrackerTaskComboBox::UpdateRecentlyTrackedTasks(const TRACKTASKLIST* pTTL, DWORD dwSelTaskID)
{
	ASSERT(pTTL);
	ASSERT(pTTL->pTDC == m_pTDC);
	ASSERT(pTTL->aRecentlyTrackedIDs.GetSize() <= 10);

	if (!pTTL || (GetCount() == 0))
		return;

	// Get the current recently tracked items to see if anything has changed
	CDWordArray aCurRecentlyTrackedIDs;
	GetRecentlyTrackedTaskIDs(aCurRecentlyTrackedIDs);

	if (!Misc::MatchAll(pTTL->aRecentlyTrackedIDs, aCurRecentlyTrackedIDs, TRUE))
	{
		// Remove previous recently tracked items and headings
		if (aCurRecentlyTrackedIDs.GetSize())
		{
			ASSERT(IsHeadingItem(0));

			int nItem = aCurRecentlyTrackedIDs.GetSize() + 2; // +2 for headings
			ASSERT(IsHeadingItem(nItem - 1));

			while (nItem--)
				DeleteString(0);
		}

		// Reinsert new recently tracked tasks and headings
		if (pTTL->aRecentlyTrackedIDs.GetSize())
		{
			// Insert 'All tasks' header
			int nHeading = CDialogHelper::InsertStringT(*this, 0, IDS_TIMETRACKER_ALLITEMS, 0);
			SetHeadingItem(nHeading);

			// Insert new recently tracked tasks at head of combo
			CMapTaskIndex mapCBItems;
			BuildItemMap(mapCBItems);

			CMapTaskIndex mapTasks;
			pTTL->aTasks.BuildTaskMap(mapTasks);

			int nID = pTTL->aRecentlyTrackedIDs.GetSize(), nNumAdded = 0;

			while (nID--)
			{
				DWORD dwTaskID = pTTL->aRecentlyTrackedIDs[nID];
				int nItem = CB_ERR, nTask = CB_ERR;

				if (!mapCBItems.Lookup(dwTaskID, nItem) || !mapTasks.Lookup(dwTaskID, nTask))
					continue;

				nItem += nNumAdded;
				ASSERT(nItem == CDialogHelper::FindItemByDataT(*this, dwTaskID));

				VERIFY(InsertTask(0, 
								  pTTL->aTasks[nTask].sTask, 
								  dwTaskID, 
								  0, 
								  GetItemImage(nItem)));
				nNumAdded++;
			}

			// Insert 'Recently tracked' header
			nHeading = CDialogHelper::InsertStringT(*this, 0, IDS_TIMETRACKER_RECENTITEMS, 0);
			SetHeadingItem(nHeading);
		}
	}

	SelectTask(dwSelTaskID);
}

int CTDLTimeTrackerTaskComboBox::GetRecentlyTrackedTaskIDs(CDWordArray& aRecentlyTrackedIDs) const
{
	aRecentlyTrackedIDs.RemoveAll();

	if (IsHeadingItem(0))
	{
		int nItem = 0;

		while (!IsHeadingItem(++nItem))
			aRecentlyTrackedIDs.Add(GetItemData(nItem));

		ASSERT(aRecentlyTrackedIDs.GetSize());
	}

	return aRecentlyTrackedIDs.GetSize();
}

int CTDLTimeTrackerTaskComboBox::BuildItemMap(CMapTaskIndex& mapItems) const
{
	mapItems.RemoveAll();

	int nItem = GetCount();

	while (nItem--)
	{
		// Don't include headings or recently tracked items
		if (IsHeadingItem(nItem))
			break;

		mapItems.SetAt(GetItemData(nItem), nItem);
	}

	return mapItems.GetCount();
}

int CTDLTimeTrackerTaskComboBox::BuildRecentlyTrackedItemMap(CMapTaskIndex& mapItems) const
{
	mapItems.RemoveAll();

	CDWordArray aRecentlyTrackedIDs;
	int nID = GetRecentlyTrackedTaskIDs(aRecentlyTrackedIDs);

	while (nID--)
	{
		DWORD dwTaskID = aRecentlyTrackedIDs[nID];
		mapItems[dwTaskID] = (nID + 1);
	}
	ASSERT(mapItems.GetCount() == aRecentlyTrackedIDs.GetSize());

	return mapItems.GetCount();
}

BOOL CTDLTimeTrackerTaskComboBox::SelectTask(DWORD dwTaskID)
{
	int nItem = CDialogHelper::FindItemByDataT(*this, dwTaskID);
	
	return (SetCurSel(nItem) != CB_ERR);
}

BOOL CTDLTimeTrackerTaskComboBox::SelectTask(const TRACKTASKLIST* pTTL)
{
	if (!pTTL)
	{
		ASSERT(0);
		return FALSE;
	}

	DWORD dwTaskID = pTTL->GetTrackedTaskID();

	if (!dwTaskID)
		dwTaskID = pTTL->pTDC->GetSelectedTaskID();

	return SelectTask(dwTaskID);
}
