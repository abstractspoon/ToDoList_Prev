#if !defined(AFX_TDLPRIORITYCOMBOBOX_H__94985E3D_C2CA_44C0_B3AD_E55C110AEE45__INCLUDED_)
#define AFX_TDLPRIORITYCOMBOBOX_H__94985E3D_C2CA_44C0_B3AD_E55C110AEE45__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TDLPriorityComboBox.h : header file
//

#include "..\shared\colorcombobox.h"

/////////////////////////////////////////////////////////////////////////////
// CTDLPriorityComboBox window

class CTDLPriorityComboBox : public CColorComboBox
{
public:
	CTDLPriorityComboBox(BOOL bIncludeAny, BOOL bIncludeNone = TRUE);
	virtual ~CTDLPriorityComboBox();

	BOOL SetColors(const CDWordArray& aColors);
	void SetNumLevels(int nLevels);
	int GetNumLevels() const { return m_nNumLevels; }

	int IncrementPriority(int nAmount);
	int GetSelectedPriority() const;
	void SetSelectedPriority(int nPriority);

	void DDX(CDataExchange* pDX, int& nPriority);

protected:
	CDWordArray m_aColors;
	BOOL m_bIncludeAny, m_bIncludeNone;
	int m_nNumLevels;

protected:
	DECLARE_MESSAGE_MAP()

protected:
	virtual void BuildCombo();
	virtual void DrawItemText(CDC& dc, const CRect& rect, int nItem, UINT nItemState, 
							 DWORD dwItemData, const CString& sItem, BOOL bList, COLORREF crText);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TDLPRIORITYCOMBOBOX_H__94985E3D_C2CA_44C0_B3AD_E55C110AEE45__INCLUDED_)
