// MenuEx.h: interface for the CTDCMainMenu class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TDCMAINMENU_H__5AB11CC8_CCF5_4D52_ADC7_27FDC151F3FE__INCLUDED_)
#define AFX_TDCMAINMENU_H__5AB11CC8_CCF5_4D52_ADC7_27FDC151F3FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//////////////////////////////////////////////////////////////////////

#include "tdcenum.h"

#include "..\Shared\EnMenu.h"
#include "..\Shared\EnBitmap.h"

#include "..\Interfaces\UITheme.h"

//////////////////////////////////////////////////////////////////////

class CRecentFileList;
class CToDoCtrlMgr;
class CFilteredToDoCtrl;
class CPreferencesDlg;
class CTDLFilterBar;
class CTDLTasklistStorageMgr;
class CUIExtensionMgr;
class CMenuIconMgr;

//////////////////////////////////////////////////////////////////////

class CTDCMainMenu : public CEnMenu  
{
public:
	CTDCMainMenu();
	virtual ~CTDCMainMenu();

	BOOL LoadMenu();
	BOOL LoadMenu(const CPreferencesDlg& prefs);

	BOOL HandlePostTranslateMenu(HMENU hMenu) const;
	BOOL HandleInitMenuPopup(CMenu* pPopupMenu, 
							 const CFilteredToDoCtrl& tdc, 
							 const CPreferencesDlg& prefs,
							 const CTDLFilterBar& filterBar,
							 const CTDLTasklistStorageMgr& mgrStorage,
							 const CUIExtensionMgr& mgrUIExt,
							 CMenuIconMgr& mgrMenuIcons) const;

	CString GetDynamicItemTooltip(UINT nMenuID,
								  const CRecentFileList& mru,
								  const CToDoCtrlMgr& mgrToDoCtrl,
								  const CPreferencesDlg& prefs,
								  const CTDLFilterBar& filterBar,
								  const CTDLTasklistStorageMgr& mgrStorage,
								  const CUIExtensionMgr& mgrUIExt) const;

	static void PrepareTaskContextMenu(CMenu* pMenu,
									   const CFilteredToDoCtrl& tdc,
									   const CPreferencesDlg& prefs);

	static void PrepareTabCtrlContextMenu(CMenu* pMenu,
										  const CFilteredToDoCtrl& tdc,
										  const CPreferencesDlg& prefs);

	static BOOL GetFilterToActivate(UINT nMenuID,
									const CTDLFilterBar& filterBar,
									const CPreferencesDlg& prefs,
									FILTER_SHOW& nFilter,
									CString& sAdvFilter);

	static UINT GetSelectedFilterMenuID(const CTDLFilterBar& filterBar);

	static BOOL IsDynamicItem(UINT nMenuID);

protected:
	UITHEME m_theme;
	CEnBitmap m_bmUILang, m_bmTabClose;

protected:
	void LoadMenuCommon();
	void TranslateDynamicMenuItems();
	void AddLanguageButton();
	void AddTabCloseButton(const CPreferencesDlg& prefs);

	static void PrepareFileMenu(CMenu* pMenu, const CPreferencesDlg& prefs);
	static void PrepareEditMenu(CMenu* pMenu, const CFilteredToDoCtrl& tdc, const CPreferencesDlg& prefs);
	static void PrepareSortMenu(CMenu* pMenu, const CFilteredToDoCtrl& tdc, const CPreferencesDlg& prefs);
	static void PrepareToolsMenu(CMenu* pMenu, const CPreferencesDlg& prefs, CMenuIconMgr& mgrMenuIcons);

	static void PrepareFiltersActivationMenu(CMenu* pMenu, const CTDLFilterBar& filterBar, const CPreferencesDlg& prefs);
	static void PrepareUserStorageMenu(CMenu* pMenu, const CTDLTasklistStorageMgr& mgrStorage, CMenuIconMgr& mgrMenuIcons);
	static void PrepareTaskViewVisibilityMenu(CMenu* pMenu, const CFilteredToDoCtrl& tdc, const CUIExtensionMgr& mgrUIExt);
	static void PrepareTaskViewActivationMenu(CMenu* pMenu, const CFilteredToDoCtrl& tdc, const CUIExtensionMgr& mgrUIExt);

	static void AddFiltersToMenu(CMenu* pMenu, UINT nStart, UINT nEnd, const CStringArray& aFilters, UINT nPlaceholderStrID);
	static BOOL IsInRange(UINT nItem, UINT nStart, UINT nEnd);
};

#endif // !defined(AFX_TDCMAINMENU_H__5AB11CC8_CCF5_4D52_ADC7_27FDC151F3FE__INCLUDED_)
