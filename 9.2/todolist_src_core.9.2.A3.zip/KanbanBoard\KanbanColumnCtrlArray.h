#if !defined(AFX_KANBANCOLUMNCTRLARRAY_H__059495EC_3D8D_4607_A4CF_20C142F8A294__INCLUDED_)
#define AFX_KANBANCOLUMNCTRLARRAY_H__059495EC_3D8D_4607_A4CF_20C142F8A294__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// KanbanListCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////

class CKanbanColumnCtrl;
class CDeferWndMove;

/////////////////////////////////////////////////////////////////////////////

class CKanbanColumnCtrlArray : public CArray<CKanbanColumnCtrl*, CKanbanColumnCtrl*&>
{
public:
	CKanbanColumnCtrlArray() {}
	virtual ~CKanbanColumnCtrlArray();
	
	void RemoveAll();
	BOOL RemoveAt(int nList);

	int Find(DWORD dwTaskID) const;
	int Find(DWORD dwTaskID, HTREEITEM& hti) const;
	int Find(HWND hWnd) const;
	int Find(const CString& sAttribValue) const;
	int Find(const CKanbanColumnCtrl* pList) const;
	int Find(const CDWordArray& aTaskIDs) const;

	CKanbanColumnCtrl* Get(DWORD dwTaskID) const;
	CKanbanColumnCtrl* Get(DWORD dwTaskID, HTREEITEM& hti) const;
	CKanbanColumnCtrl* Get(HWND hWnd) const;
	CKanbanColumnCtrl* Get(const CString& sAttribValue) const;
	CKanbanColumnCtrl* GetFirstNonEmpty() const;
	CKanbanColumnCtrl* GetLastNonEmpty() const;
	CKanbanColumnCtrl* GetBacklog() const;

	void SetRedraw(BOOL bRedraw = TRUE);
	void SetOptions(DWORD dwOptions);
	void SetReadOnly(BOOL bReadOnly);
	int GetVisibleTaskCount() const;
	float GetAverageCharWidth();
	DWORD HitTestTask(const CPoint& ptScreen) const;
	void SetAttributeLabelVisibility(KBC_ATTRIBLABELS nLabelVis);
	void FilterToolTipMessage(MSG* pMsg);
	void SetFullColumnColor(COLORREF crFull);
	void Offset(CDeferWndMove& dwm, int nAmount);

	CSize CalcRequiredColumnSizeForImage() const;
	BOOL CanSaveToImage() const;
	BOOL SaveToImage(CBitmap& bmImage);

	CKanbanColumnCtrl* GetNext(const CKanbanColumnCtrl* pList, BOOL bNext, BOOL bExcludeEmpty, BOOL bFixedColumns, BOOL bWrap) const;
	CKanbanColumnCtrl* HitTest(const CPoint& ptScreen, HTREEITEM* pHit = NULL, UINT* pHitFlags = NULL) const;

	void OnDisplayAttributeChanged();

	void Sort();
	void Sort(TDC_ATTRIBUTE nBy, BOOL bAscending);
	BOOL GroupBy(TDC_ATTRIBUTE nAttribID);
	void SetGroupHeaderBackgroundColor(COLORREF color);

	void SetSelectedColumn(const CKanbanColumnCtrl* pSelList);
	void SetDropTarget(const CKanbanColumnCtrl* pTarget);
	BOOL DeleteTaskFromOthers(DWORD dwTaskID, const CKanbanColumnCtrl* pIgnore);

	void Exclude(CDC* pDC);
	void Redraw(BOOL bErase, BOOL bUpdate = FALSE);
	int RemoveDeletedTasks(const CDWordSet& mapCurIDs);
	void RefreshItemLineHeights();
	void SetFont(HFONT hFont);

protected:
	DWORD HitTestTask(const CPoint& ptScreen, CKanbanColumnCtrl*& pCol) const;

	static int SortProc(const void* pV1, const void* pV2);

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_KANBANCOLUMNCTRLARRAY_H__059495EC_3D8D_4607_A4CF_20C142F8A294__INCLUDED_)
