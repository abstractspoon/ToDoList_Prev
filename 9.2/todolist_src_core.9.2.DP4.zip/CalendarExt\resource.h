//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CalendarExt.rc
//
#define IDR_CUSTOMDATE_POPUP            1
#define IDB_TOOLBAR_STD                 245
#define IDI_HELP_BUTTON                 293
#define IDR_CALENDAR                    1000
#define IDC_STATUSBAR                   1001
#define IDS_SNAP_NEARESTHOUR            1004
#define IDD_CALENDAR_DIALOG             1006
#define IDS_SNAP_NEARESTDAY             1007
#define IDS_SNAP_NEARESTHALFDAY         1008
#define IDC_NUMWEEKS                    1015
#define IDC_CALENDAR_FRAME              1016
#define IDC_DIVIDER                     1017
#define IDC_GOTOTODAY                   1029
#define IDC_PREFERENCES                 1030
#define IDC_SELECTEDTASKDATES           1032
#define IDC_SELECTEDTASKDATESLABEL      1033
#define IDC_DRAGMODE                    1033
#define IDC_SNAPMODES                   1034
#define IDC_HEATMAPPALETTE              1035
#define IDC_SHOWCALCSTARTDATES          1038
#define IDC_SHOWCALCDUEDATES            1039
#define IDC_DYNAMICTASKHEIGHT           1040
#define IDC_SHOWOVERDUEASDUETODAY       1041
#define IDC_HIDEPARENTTASKS             1042
#define IDC_ENABLEHEATMAP               1043
#define IDC_HEATMAPATTRIBUTE            1044
#define IDC_SHOWFUTUREITEMS             1045
#define IDC_HIDEPARENTTASKSBYTAG        1046
#define IDC_HIDEPARENTTAG               1047
#define IDC_SHOWDATEINEVERYCELL         1048
#define IDC_SHOWWEEKNUMINCELL           1049
#define IDC_SETWEEKENDCOLOR             1072
#define IDC_SHOWMINICALENDAR            2001
#define IDC_SHOWTASKSDISCONTINUOUS      2002
#define IDC_SHOWSTARTDATES              2003
#define IDC_SHOWDUEDATES                2004
#define IDC_USECREATIONFORSTART         2005
#define IDC_USEDUEFORSTART              2006
#define IDC_USEDUEORTODAYFORSTART       2007
#define IDC_USESTARTFORDUE              2008
#define IDC_USESTARTORTODAYFORDUE       2009
#define IDC_SHOWDONEDATES               2010
#define IDC_SHOWACTIVETODAY             2011
#define IDC_WEEKENDCOLOR                16004
#define IDR_TOOLBAR                     16006
#define IDC_COLORSGROUP                 16008
#define IDC_TB_PLACEHOLDER              16024
#define IDC_ATTRIBUTES_LABEL            16043
#define IDD_PREFERENCES_DIALOG          17002
#define IDD_PREFERENCES_PAGE            17003
#define IDC_PPHOST                      17019
#define ID_CAL_GOTOTODAY                32774
#define ID_CAL_PREFS                    32775
#define IDS_SNAP_FREE                   32790
#define ID_GOTOTODAY                    32795
#define ID_CAL_CLEARCUSTOMDATE          32799
#define ID_CANCEL                       32800
#define IDS_NOHEATMAP                   57671
#define IDS_MINICAL_TOOLTIP             57672
#define IDS_HEATMAP_NUMDONE             57673
#define IDS_HEATMAP_NUMDUE              57674
#define IDS_HEATMAP_NUMSTARTED          57675
#define IDS_SELTASKDATES_LABEL          57676
#define IDS_OVERFLOWBTN_TIP             57677
#define IDS_DISPLAYDONETASKS            57678
#define IDS_DISPLAYTASKDONEDATES        57679
#define IDS_CUSTOMDATE_TOOLTIP          57680
#define IDS_FUTUREOCCURRENCE_TOOLTIP    57681
#define IDS_LONGWEEK                    57682
#define IDS_SHORTWEEK                   57683

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2
#define _APS_NEXT_COMMAND_VALUE         32801
#define _APS_NEXT_CONTROL_VALUE         1048
#define _APS_NEXT_SYMED_VALUE           32893
#endif
#endif
