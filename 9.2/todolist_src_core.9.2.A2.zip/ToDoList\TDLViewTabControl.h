#if !defined(AFX_TODOCTRLVIEWTABCONTROL_H__4829AF79_C5C1_4D5F_8AB1_A6D0FFD5793E__INCLUDED_)
#define AFX_TODOCTRLVIEWTABCONTROL_H__4829AF79_C5C1_4D5F_8AB1_A6D0FFD5793E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ToDoCtrlViewTabControl.h : header file
//

#include <afxtempl.h>

#include "tdcenum.h"

#include "..\shared\tabctrlex.h"
#include "..\shared\enstring.h"

/////////////////////////////////////////////////////////////////////////////

class CDeferWndMove;
class CPreferences;

typedef CArray<FTC_VIEW, FTC_VIEW> CTDCViewArray;

/////////////////////////////////////////////////////////////////////////////

struct IVIEWTABDATA
{
	virtual ~IVIEWTABDATA() {}
};

/////////////////////////////////////////////////////////////////////////////
// CTDCViewTabControl window

class CTDLViewTabControl : public CTabCtrlEx
{
public:
	CTDLViewTabControl();
	virtual ~CTDLViewTabControl();

	BOOL AttachView(HWND hWnd, FTC_VIEW nView, LPCTSTR szLabel, HICON hIcon, IVIEWTABDATA* pData = NULL, int nVertOffset = 0);
	BOOL DetachView(HWND hWnd);
	BOOL DetachView(FTC_VIEW nView);

	void Resize(const CRect& rect, CDeferWndMove* pDWM = NULL);
	void ShowTabControl(BOOL bShow = TRUE);

	BOOL SetActiveView(CWnd* pWnd, BOOL bNotify = FALSE);
	BOOL SetActiveView(FTC_VIEW nView, BOOL bNotify = FALSE);
	CWnd* GetActiveWnd() const;
	FTC_VIEW GetActiveView() const;
	void ActivateNextView(BOOL bNext = TRUE);
	
	HWND GetViewHwnd(FTC_VIEW nView) const;
	BOOL SetViewHwnd(FTC_VIEW nView, HWND hWnd);
	CString GetViewName(FTC_VIEW nView) const;
	IVIEWTABDATA* GetViewData(FTC_VIEW nView) const;
	BOOL ShowViewTab(FTC_VIEW nView, BOOL bShow = TRUE);
	BOOL IsViewTabShowing(FTC_VIEW nView) const;

	int GetVisibleViews(CTDCViewArray& aVisible) const;
	void SetVisibleViews(const CTDCViewArray& aVisible);

	int GetViewOrder(CTDCViewArray& aViewOrder) const;
	void SetViewOrder(const CTDCViewArray& aViewOrder);

	BOOL CanMoveActiveTaskViewTab(BOOL bLeft) const;
	BOOL MoveActiveTaskViewTab(BOOL bLeft);

protected:
	struct TDCVIEW
	{
		TDCVIEW(HWND hWnd = NULL, FTC_VIEW view = FTCV_UNSET, LPCTSTR szLabel = NULL, HICON icon = NULL, IVIEWTABDATA* data = NULL, int vertOffset = 0) 
			: 
			hwndView(hWnd), 
			nView(view), 
			sViewLabel(szLabel), 
			pVData(data),
			hIcon(NULL),
			nVertOffset(vertOffset)
		{
			// add space for close button
			sViewLabel += "   ";

			if (icon)
				hIcon = ::CopyIcon(icon);
		}

		HWND hwndView;
		FTC_VIEW nView;
		CString sViewLabel;
		HICON hIcon;
		IVIEWTABDATA* pVData;
		int nVertOffset;
	};
	CArray<TDCVIEW, TDCVIEW&> m_aViews; // Master list of all views

	int m_nSelTab;
	BOOL m_bShowingTabs;
	CRect m_rOverall; // tabs plus views

protected:
	virtual void PreSubclassWindow();

protected:
	afx_msg void OnSelChange(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCloseTab(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEndDrag(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);

	DECLARE_MESSAGE_MAP()

protected:
	int GetViewIndex(HWND hWnd) const;
	int GetViewIndex(FTC_VIEW nView) const;
	int GetTabIndex(FTC_VIEW nView) const;
	FTC_VIEW GetTabView(int nTab) const;
	void GetViewRect(const TDCVIEW& view, CRect& rView) const;
	BOOL SwitchToTab(int nNewIndex);
	BOOL CalcTabViewRects(const CRect& rPos, CRect& rTabs, CRect& rView) const;
	BOOL DoTabChange(int nOldTab, int nNewTab, BOOL bNotify);

	int TabToViewIndex(int nTab) const;

	// Virtual overrides
	BOOL WantTabCloseButton(int nTab) const;
};

/////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_TODOCTRLVIEWTABCONTROL_H__4829AF79_C5C1_4D5F_8AB1_A6D0FFD5793E__INCLUDED_)
