//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TDLTransEdit.rc
//
#define IDR_MANIFEST                    1
#define IDD_TDLTRANSEDIT_DIALOG         102
#define IDS_SAVECHANGES                 102
#define IDR_MAINFRAME                   128
#define IDC_DICTIONARY                  1000
#define IDC_ENGLISH                     1001
#define IDC_ENGLISHLABEL                1002
#define IDC_TRANSLABEL                  1003
#define IDC_TRANSLATION                 1004
#define IDC_FILTER                      1005
#define IDC_CLEARFILTER                 1006
#define IDC_UPDATEFILTER                1007
#define ID_FILE_OPEN_TRANSLATION        32771
#define ID_FILE_SAVE_TRANSLATION        32772
#define ID_OPTIONS_SHOWOPTIONALS        32773
#define ID_FILE_NEW_TRANSLATION         32774
#define ID_TOOLS_CLEANUP                32775
#define ID_TOOLS_CLEANUPMULTIPLE        32775
#define ID_OPTIONS_SHOWTOOLTIPS         32776
#define ID_OPTIONS_SORTUNTRANSLATEDITEMSATTOP 32777
#define ID_OPTIONS_SORTUNTRANSATTOP     32778
#define ID_TOOLS_EXPORTUNTRANSLATED     32780
#define ID_TOOLS_IMPORTTRANSLATED       32781
#define ID_FILE_CLOSE_TRANSLATION       32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
