#if !defined(AFX_TODOCTRL_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_)
#define AFX_TODOCTRL_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ToDoCtrl.h : header file
//

#include "TaskListDropTarget.h"
#include "todoctrldata.h"

#include "..\shared\runtimedlg.h"
#include "..\shared\dialoghelper.h"
#include "..\shared\orderedtreectrl.h"
#include "..\shared\fileedit.h"
#include "..\shared\sysimagelist.h"
#include "..\shared\urlricheditctrl.h"
#include "..\shared\colorcombobox.h"
#include "..\shared\autocombobox.h"
#include "..\shared\maskedit.h"
#include "..\shared\timeedit.h"

/////////////////////////////////////////////////////////////////////////////
// CToDoCtrl dialog

// notification messages
const UINT WM_TDCN_MODIFY = ::RegisterWindowMessage("WM_TDCN_MODIFY"); // lParam == <TDC_ATTRIBUTE>
const UINT WM_TDCN_SORT = ::RegisterWindowMessage("WM_TDCN_SORT"); 
const UINT WM_TDCN_MINWIDTHCHANGE = ::RegisterWindowMessage("WM_TDCN_MINWIDTHCHANGE"); 

enum TDC_INSERTWHERE
{
	TDC_INSERTATTOP,
	TDC_INSERTATBOTTOM,
	TDC_INSERTATTOPOFSELTASKPARENT,
	TDC_INSERTATBOTTOMOFSELTASKPARENT,
	TDC_INSERTAFTERSELTASK,
	TDC_INSERTBEFORESELTASK,
	TDC_INSERTATTOPOFSELTASK, // subtask
	TDC_INSERTATBOTTOMOFSELTASK, // subtask
};

enum TDC_ARCHIVE
{
	TDC_REMOVENONE,
	TDC_REMOVEALL,
	TDC_REMOVEIFSIBLINGSANDSUBTASKSCOMPLETE,
};

enum TDC_STYLE
{
	TDCS_SHOWINFOTIPS,					
	TDCS_COLORTEXTBYPRIORITY,			
	TDCS_SIMPLEMODE,						
	TDCS_SHOWCOMMENTSINLIST,				
	TDCS_COLORPRIORITY,					
	TDCS_TREATSUBCOMPLETEDASDONE,		
	TDCS_HIDEPERCENTFORDONETASKS,		
	TDCS_CONFIRMDELETE,					
	TDCS_AVERAGEPERCENTSUBCOMPLETION,	
	TDCS_INCLUDEDONEINAVERAGECALC,		
	TDCS_TREECHECKBOXES,					
	TDCS_SHOWBUTTONSINTREE,				
	TDCS_USEEARLIESTDUEDATE,				
	TDCS_USEPERCENTDONEINTIMEEST,		
	TDCS_SHOWCTRLSASCOLUMNS,				
	TDCS_SHOWCOMMENTSALWAYS,				
	TDCS_AUTOREPOSCTRLS,					
	TDCS_HIDEZEROTIMEEST,				
	TDCS_HIDESTARTDUEFORDONETASKS,		
	TDCS_SHOWPERCENTASPROGRESSBAR,		
	TDCS_READONLY,						
	TDCS_ENABLESOURCECONTROL,			 
	TDCS_CHECKOUTONLOAD,					 
	TDCS_QUERYAPPLYCHANGESTOSUBTASKS,	 
	TDCS_SHOWPATHINHEADER,				
	TDCS_STRIKETHOUGHDONETASKS,			
	TDCS_FULLROWSELECTION,				
	TDCS_COLUMNHEADERCLICKING,			
	TDCS_SORTVISIBLETASKSONLY,			
	TDCS_SHAREDCOMMENTSHEIGHT,
	TDCS_TASKCOLORISBACKGROUND,			
	TDCS_COMMENTSUSETREEFONT,
	TDCS_SHOWDATESINISO,
	TDCS_USEHIGHESTPRIORITY,
	TDCS_AUTOCALCTIMEESTIMATES,
	TDCS_SHOWWEEKDAYINDATES,
	TDCS_ROUNDTIMEFRACTIONS,
	TDCS_SHOWNONFILEREFSASTEXT,
	TDCS_INCLUDEDONEINPRIORITYCALC,		
	TDCS_WEIGHTPERCENTCALCBYTIMEEST,
	TDCS_WEIGHTPERCENTCALCBYPRIORITY,

//	TDCS_	= 0x00000000,
    TDCS_LAST
};

enum TDC_COLUMN
{
	TDCC_PRIORITY,
	TDCC_PERCENT,
	TDCC_TIMEEST,
	TDCC_TIMESPENT,
	TDCC_STARTDATE,
	TDCC_DUEDATE,
	TDCC_DONEDATE,
	TDCC_ALLOCTO,
	TDCC_ALLOCBY,
	TDCC_STATUS,
	TDCC_CATEGORY,
	TDCC_FILEREF,
	TDCC_POSITION,
	TDCC_ID,
	TDCC_DONE,
}; 

enum TDC_GOTO
{
	TDCG_NEXT,
	TDCG_PREV,
};

enum TDC_FILEFMT
{
    TDCFF_OLDER,
    TDCFF_SAME,
    TDCFF_NEWER
};

enum TDC_OPEN
{
	TDCO_SUCCESS,
	TDCO_NOTEXIST,
	TDCO_NOTTASKLIST,
	TDCO_CANCELLED,
	TDCO_UNKNOWN,
};
 
// predeclarations
class CXmlItem;
class CXmlFileEx;
class CDeferWndMove;
class CDlgUnits;
struct CTRLITEM;
struct TDCCOLUMN;
class CSpellCheckDlg;

class CToDoCtrl : public CRuntimeDlg, protected CDialogHelper
{
// Construction
public:
	CToDoCtrl();
	virtual ~CToDoCtrl();

	BOOL Create(const RECT& rect, CWnd* pParentWnd, UINT nID, BOOL bVisible = TRUE);

	BOOL Save(LPCTSTR szFilePath = NULL, BOOL bCheckforLaterChanges = TRUE);
	TDC_OPEN Load(LPCTSTR szFilePath, LPCTSTR szArchivePath = NULL, TDC_ARCHIVE nRemove = TDC_REMOVEALL);
	BOOL Import(LPCTSTR szFilePath);

	int ArchiveDoneTasks(LPCTSTR szFilePath, TDC_ARCHIVE nFlags); // returns the number of tasks removed

	void EnableEncryption(BOOL bEnable = TRUE);
	BOOL IsEncrypted() { return (!m_sPassword.IsEmpty()); }
	static BOOL CanEncrypt(); // returns true only if the required encrytion capabilities are present
	CString GetPassword() { return m_sPassword; }

	BOOL CheckIn();
	BOOL CheckOut();
	BOOL CheckOut(CString& sCheckedOutTo);
	BOOL IsCheckedOut() const { return m_bCheckedOut; }
	static BOOL IsUnderSourceControl(LPCTSTR szFilePath);

	void Flush(); // called to end current editing actions
	BOOL IsModified() const { return m_bModified; }
	void SetModified(BOOL bMod = TRUE);

	inline CString GetFilePath() const { return m_sLastSavePath; }
	inline CString GetProjectName() const { return m_sProjectName; }
	CString GetFriendlyProjectName() const;

	BOOL DeleteAllTasks();
	void NewList();

	void SetReadonly(BOOL bReadOnly) { SetStyle(TDCS_READONLY, bReadOnly); }
	BOOL IsReadOnly() const { return HasStyle(TDCS_READONLY); }

	void SetStyle(TDC_STYLE nStyle, BOOL bOn = TRUE); // one style at a time only 
	BOOL HasStyle(TDC_STYLE nStyle) const; // one style at a time only 

	void ShowColumn(TDC_COLUMN nColumn, BOOL bShow);
	BOOL IsColumnShowing(TDC_COLUMN nColumn) const;

	BOOL SetPriorityColors(const CDWordArray& aColors); // must have 11 elements
	void SetGridlineColor(COLORREF color);
	void SetTaskCompletedColor(COLORREF color);

	HTREEITEM NewTask(LPCTSTR szText, TDC_INSERTWHERE nWhere = TDC_INSERTATTOPOFSELTASKPARENT, 
						BOOL bSelect = TRUE, BOOL bEditText = TRUE);

	DWORD GetSelectedTaskID() const { return m_data.GetTaskID(GetSelectedItem()); } 
	BOOL GetSelectedTask(TODOITEM& tdi) const { return m_data.GetTask(GetSelectedItem(), tdi); }

	BOOL DeleteSelectedTask();
	BOOL EditSelectedTask();
	void SpellcheckSelectedTask(BOOL bTitle); // else comments

	COleDateTime GetSelectedTaskDoneDate() const;
	COleDateTime GetSelectedTaskDueDate() const;
	COleDateTime GetSelectedTaskStartDate() const;
	BOOL SetSelectedTaskStartDate(COleDateTime& date);
	BOOL SetSelectedTaskDoneDate(COleDateTime& date);
	BOOL SetSelectedTaskDueDate(COleDateTime& date);
	BOOL SetSelectedTaskDone(BOOL bDone = TRUE);
	BOOL IsSelectedTaskDone() const;
	BOOL IsSelectedTaskDue() const;

	COLORREF GetSelectedTaskColor() const; // -1 on no item selected
	CString GetSelectedTaskComments() const;
	CString GetSelectedTaskTitle() const;
	int GetSelectedTaskPercentDone() const;
	double GetSelectedTaskTimeEstimate(int& nUnits) const;
	double GetSelectedTaskTimeSpent(int& nUnits) const;
	CString GetSelectedTaskAllocTo() const;
	CString GetSelectedTaskAllocBy() const;
	CString GetSelectedTaskStatus() const;
	CString GetSelectedTaskCategory() const;
	CString GetSelectedTaskFileRef() const;
	int GetSelectedTaskPriority() const;

	BOOL SetSelectedTaskColor(COLORREF color);
	BOOL SetSelectedTaskTitle(LPCTSTR szTitle);
	BOOL SetSelectedTaskComments(LPCTSTR szComments);
	BOOL SetSelectedTaskPercentDone(int nPercent);
	BOOL SetSelectedTaskTimeEstimate(const double& dHours, int nUnits = TDCTU_HOURS);
	BOOL SetSelectedTaskTimeSpent(const double& dHours, int nUnits = TDCTU_HOURS);
	BOOL SetSelectedTaskAllocTo(LPCTSTR szAllocTo);
	BOOL SetSelectedTaskAllocBy(LPCTSTR szAllocBy);
	BOOL SetSelectedTaskStatus(LPCTSTR szStatus);
	BOOL SetSelectedTaskCategory(LPCTSTR szCategory);
	BOOL SetSelectedTaskFileRef(LPCTSTR szFilePath);
	BOOL SetSelectedTaskPriority(int nPriority); // 0-10 (10 is highest)

	BOOL SetSelectedTaskAttributeAsParent(TDC_ATTRIBUTE nAttrib);

	void Sort(TDC_SORTBY nBy); // calling twice with the same param will toggle ascending attrib
	TDC_SORTBY GetSortBy() { return m_nSortBy; }
	void ReSort() { Sort(m_nSortBy); }

	// move functions
	BOOL MoveSelectedTask(DDTC_MOVE nDirection);
	BOOL CanMoveSelectedTask(DDTC_MOVE nDirection) const;

	void GotoTopLevelTask(TDC_GOTO nDirection); // can't be const because CTreeCtrl::SelectItem() is not const
	BOOL CanGotoTopLevelTask(TDC_GOTO nDirection) const;

	// export functions
	void Export2Html(CString& sOutput, BOOL bVisibleColsOnly, BOOL bIncludeProjectName = TRUE, 
					LPCTSTR szFontName = NULL, int nFontSize = 10, TDC_FILTER nFilter = TDCF_ALL) const;
	void Export2Text(CString& sOutput, BOOL bVisibleColsOnly, BOOL bIncludeProjectName = TRUE, 
					int nIndentWidth = 2, TDC_FILTER nFilter = TDCF_ALL) const;

	void ExportSelectedItem2Html(CString& sOutput, BOOL bVisibleColsOnly, BOOL bIncludeProjectName = TRUE, 
								LPCTSTR szFontName = NULL, int nFontSize = 10, TDC_FILTER nFilter = TDCF_ALL) const;
	void ExportSelectedItem2Text(CString& sOutput, BOOL bVisibleColsOnly, BOOL bIncludeProjectName = TRUE, 
								int nIndentWidth = 2, TDC_FILTER nFilter = TDCF_ALL) const;

	BOOL CopySelectedItemAsHtml(CString& sOutput, BOOL bVisibleColsOnly, LPCTSTR szFontName = NULL) const;
	BOOL CopySelectedItemAsText(CString& sOutput, BOOL bVisibleColsOnly, int nIndent = 2) const;
	BOOL CopySelectedItemToClipboardAsHtml(BOOL bVisibleColsOnly, LPCTSTR szFontName = NULL) const;
	BOOL CopySelectedItemToClipboardAsText(BOOL bVisibleColsOnly, int nIndent = 2) const;

	// copy/paste functions
	BOOL CopySelectedItem();
	void ClearCopiedItem();
	BOOL PasteOnSelectedItem();
	BOOL CanPaste() const;

	void ResetFileVersion(unsigned int nTo = 1) { m_nFileVersion = max(nTo, 1); }
	unsigned short GetFileVersion() const { return m_nFileVersion; }
    TDC_FILEFMT CompareFileFormat(); // older, same, newer
	
	// tree related
	inline HTREEITEM GetSelectedItem() const { return (m_tree.GetSafeHwnd() ? m_tree.GetSelectedItem() : NULL); }
	inline void SelectItem(HTREEITEM hti) { if (m_tree.GetSafeHwnd()) m_tree.SelectItem(hti); }
	inline UINT GetTaskCount() const { return m_data.GetTaskCount(); }
	inline BOOL ItemHasChildren(HTREEITEM hti) const { return m_tree.ItemHasChildren(hti); }
	inline BOOL ItemHasParent(HTREEITEM hti) const { return (NULL != m_tree.GetParentItem(hti)); }
	inline BOOL TreeHasFocus() { return m_tree.HasFocus(FALSE); }
	inline CString GetItemText(HTREEITEM hti) const { return m_data.GetTaskTitle(m_tree.GetItemData(hti)); }

	BOOL SetImageList(CImageList* pImageList); // caller responsible for deleting
	BOOL SetTreeFont(LPCTSTR szFaceName, int nPoint = 8);
	int FindTasks(SEARCHPARAMS& params, CDWordArray& aResults);
	CString GetItemPath(HTREEITEM hti, int nMaxElementLen = -1) const; // nMaxElementLen relates to each element of the path

	// misc
	int GetMinWidth();
	void Spellcheck();

protected:
	CToDoCtrlData m_data;
	COrderedTreeCtrl m_tree;
	CString	m_sComments;
	CDateTimeCtrl m_dateStart, m_dateDue, m_dateDone;
	BOOL m_bModified;
	DWORD m_dwNextUniqueID;
	CColorComboBox m_cbPriority;
	int m_nPriority;
	TDC_SORTBY m_nSortBy;
	BOOL m_bSortAscending;
	unsigned short m_nFileVersion;
	unsigned short m_nFileFormat;
	CString m_sProjectName;
	CSpinButtonCtrl m_spinPercent;
	int m_nPercentDone;
	CMaskEdit m_ePercentDone;
	CString m_sAllocTo, m_sAllocBy;
	CString m_sStatus, m_sCategory;
	CWordArray m_aStyles;
	BOOL m_bArchive;
	CFileEdit m_eFileRef;
	CString m_sFileRefPath;
	CDWordArray m_aPriorityColors;
	double m_dTimeEstimate, m_dTimeSpent;
	int m_nTimeEstUnits, m_nTimeSpentUnits;
	CTimeEdit m_eTimeEstimate, m_eTimeSpent;
	CString m_sXmlHeader;
	BOOL m_bModSinceLastSort;
	DWORD m_dwVisibleColumns;
	CSysImageList m_ilFileRef;
	CTaskListDropTarget m_dtTree, m_dtFileRef;
	CAutoComboBox m_cbAllocTo, m_cbAllocBy;
	CAutoComboBox m_cbStatus, m_cbCategory;
	CFont m_fontTree, m_fontDone;
	CString m_sLastSavePath;
	CString m_sFontName;
	int m_nFontSize; // in points
	COLORREF m_crGridlines, m_crTaskDone;
	BOOL m_bCheckedOut; // intentionally not a style
	CString m_sMachineName; // for source control
	HCURSOR m_hHandCursor;
	HIMAGELIST m_hilDone;
	CUrlRichEditCtrl m_reComments;
	BOOL m_bSplitting; // dragging comments splitter
	int m_nCommentsHeight;
	CString m_sCommentsContextUrl; 
	CString m_sPassword;

	static CToDoCtrl* s_pCopySrc;
	static DWORD s_dwCopySrc; // itemID
	static int s_nCommentsHeight; // TDCS_SHAREDCOMMENTSHEIGHT

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CToDoCtrl)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	virtual void PreSubclassWindow();
	virtual int OnToolHitTest(CPoint pt, TOOLINFO* pTI) const;
// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CToDoCtrl)
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnDestroy();
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnCaptureChanged(CWnd *pWnd);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG
	afx_msg void OnTreeEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTreeBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTreeSelChanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTaskDatechange(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTreeCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTreeClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTreeDblClk(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg LRESULT OnTreeEndDrag(WPARAM wParam, LPARAM lParam);
	afx_msg void OnTreeGetInfoTip(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnChangePriority();
	afx_msg void OnChangeComments();
	afx_msg void OnChangePercent();
	afx_msg void OnChangeTimeEstimate();
	afx_msg void OnChangeTimeSpent();
	afx_msg void OnEditChangeAllocTo();
	afx_msg void OnSelChangeAllocTo();
	afx_msg void OnEditChangeAllocBy();
	afx_msg void OnSelChangeAllocBy();
	afx_msg void OnEditChangeStatus();
	afx_msg void OnSelChangeStatus();
	afx_msg void OnEditChangeCategory();
	afx_msg void OnSelChangeCategory();
	afx_msg void OnChangeProjectName();
	afx_msg void OnChangeFileRefPath();
	afx_msg void OnKillFocusPercent();
	afx_msg LRESULT OnGutterDrawItem(WPARAM wParam, LPARAM lParam); // for drawing priority
	afx_msg LRESULT OnGutterRecalcColWidth(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterNotifyHeaderClick(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterWidthChange(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterGetCursor(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterNotifyColumnClick(WPARAM wParam, LPARAM lParam);
	afx_msg void OnGotoFile();
	afx_msg LRESULT OnTimeUnitsChange(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnDropFileRef(WPARAM wParam, LPARAM lParam);
	afx_msg void OnCommentsMenuCmd(UINT nCmdID);
	afx_msg void OnUpdateCommentsMenuCmd(CCmdUI* pCmdUI);
	DECLARE_MESSAGE_MAP()

protected:
	inline BOOL GetTask(DWORD dwUniqueID, TODOITEM& tdi) const { return m_data.GetTask(dwUniqueID, tdi); }
	inline void UpdateTask(DWORD dwUniqueID, TODOITEM& tdi) { m_data.UpdateTask(dwUniqueID, tdi); }

	void RebuildCopiedItem(HTREEITEM hti);
	CString FormatInfoTip(const HTREEITEM hti, const TODOITEM& tdi) const;
	void InvalidateSelectedItem();
	void UpdateTask(TDC_ATTRIBUTE nAttrib);
	void SetModified(BOOL bMod, TDC_ATTRIBUTE nAttrib);
	void UpdateControls();
	int GetSelectedTaskPercent(BOOL bCheckIfDone) const;
	void CopyTexttoclipboard(const CString& sText) const;
	int ArchiveDoneTasks(LPCTSTR szFilePath, TDC_ARCHIVE nRemove, BOOL bFlickerFree); // returns the number of tasks removed
	COLORREF GetPriorityColor(int nPriority) const;
	void InitHandCursor();
	void UpdateSelectedTaskPath();
	CRect GetSplitterRect();
	void UpdateColumnHeaderClicking();
	BOOL WantExportColumn(TDC_COLUMN nColumn, BOOL bVisibleColsOnly) const;
	void EndLabelEdit(BOOL bCancel = FALSE);
	void BuildPriorityCombo();

	void Resize(int cx = 0, int cy = 0);
	int VisibleCtrlCount();
	void ReposControl(int nCtrl, CDeferWndMove* pDWM, const CDlgUnits* pDLU, int nCol, 
						int nTop, int nBottom, int nClientRight);

	BOOL IsTaskDone(HTREEITEM hti, DWORD dwExtraCheck = 0) const;

	int AddChildren(HTREEITEM hti, CXmlItem* pXI, const TDCFILTER& filter, BOOL bISODates) const;
	BOOL AddItem(HTREEITEM hti, CXmlItem* pXI, const TDCFILTER& filter, BOOL bISODates, int nPos) const;
	HTREEITEM AddItem(const CXmlItem* pXI, HTREEITEM htiParent);
	void AddAttributeToItem(CXmlItem* pXI, LPCTSTR szKey, const CString& sAttrib, TDC_COLUMN nCol, const TDCFILTER& filter) const;
	void AddAttributeToItem(CXmlItem* pXI, LPCTSTR szKey, int nAttrib, TDC_COLUMN nCol, const TDCFILTER& filter) const;
	void AddAttributeToItem(CXmlItem* pXI, LPCTSTR szKey, const double& dAttrib, TDC_COLUMN nCol, const TDCFILTER& filter) const;
	void AddAttributeToItem(CXmlItem* pXI, LPCTSTR szKey, const CString& sAttrib) const;
	void Merge(const CXmlItem* pXISrc, CXmlItem* pXIDest);
	HTREEITEM CopyTree(const CToDoCtrl* pSrc, const CDragDropTreeCtrl::HTREECOPY& htcSrc, HTREEITEM hDest);
	HTREEITEM InsertItem(LPCTSTR szText, HTREEITEM htiParent, HTREEITEM htiAfter, BOOL bSelect, BOOL bEdit);

	BOOL Load(CXmlFileEx* pFile, LPCTSTR szArchivePath = NULL, TDC_ARCHIVE nRemove = TDC_REMOVEALL);
	BOOL CheckOut(CXmlFileEx* pFile, CString& sCheckedOutTo);
	BOOL IsCheckedOut(const CXmlFileEx* pFile) const;

	TDCCOLUMN* GetColumn(UINT nColID); 
	TDCCOLUMN* GetColumn(TDC_SORTBY nSortBy);

	void SaveExpandedState(); // keyed by last filepath
	HTREEITEM LoadExpandedState(BOOL bResetSel = TRUE); // returns the previously selected item if any
	int SaveExpandedState(LPCTSTR szRegKey, HTREEITEM hti = NULL, int nStart = 0); // keyed by filepath
	void LoadExpandedState(LPCTSTR szRegKey); // keyed by filepath
	void SaveSplitPos();
	void LoadSplitPos();

	BOOL SetTextChange(int nChange, CString& sItem, LPCTSTR szNewItem, TDC_ATTRIBUTE nAttrib);
	void DrawGutterItemText(CDC* pDC, const CString& sText, const CRect& rect, int nAlign, COLORREF crText);
	int CalcComboTextWidth(CDC* pDC, const CComboBox& combo);
	int CalcHeaderTextWidth(LPCTSTR szText);

	void RecalcSelectedTimeEstimate();
	BOOL SpellcheckItem(HTREEITEM hti, CSpellCheckDlg* pSpellChecker, BOOL bTitle, BOOL bNotifyNoErrors);
	BOOL SpellcheckItem(HTREEITEM hti, CSpellCheckDlg* pSpellChecker);

	void ExportItem2Html(HTREEITEM hti, CString& sOutput, BOOL bVisibleColsOnly, 
						BOOL bIncludeProjectName, LPCTSTR szFontName, int nFontSize, TDC_FILTER nFilter) const;
	void ExportItem2Text(HTREEITEM hti, CString& sOutput, BOOL bVisibleColsOnly, 
						BOOL bIncludeProjectName, int nIndentWidth, TDC_FILTER nFilter) const;

	static void InitExportFilter(TDCFILTER& filter, TDC_FILTER nFilter, BOOL bVisibleColsOnly);

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TODOCTRL_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_)
