// TimeEdit.cpp: implementation of the CTimeEdit class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TimeEdit.h"

#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const int BTNWIDTHDLU = (10 * 4); // ' Months  > '

struct TIMEUNIT
{
	int nUnits;
	LPCTSTR szLabel;
	UINT nMenuID;
};

enum
{
	ID_HOURS = 0x8000,
	ID_DAYS,
	ID_WEEKS,
	ID_MONTHS,
	ID_YEARS,
};

const TIMEUNIT TIMEUNITS[] = 
{
	{ TEU_HOURS, "Hours", ID_HOURS },
	{ TEU_DAYS, "Days", ID_DAYS },
	{ TEU_WEEKS, "Weeks", ID_WEEKS },
	{ TEU_MONTHS, "Months", ID_MONTHS },
	{ TEU_YEARS, "Years", ID_YEARS },
};

const int NUM_UNITS = sizeof(TIMEUNITS) / sizeof (TIMEUNIT);

const TIMEUNIT& GetTimeUnit(int nUnits)
{
	int nItem = NUM_UNITS;

	while (nItem--)
	{
		if (TIMEUNITS[nItem].nUnits == nUnits)
			return TIMEUNITS[nItem];
	}

	return TIMEUNITS[0]; // hours
}

const double HOURS2DAYS = 8;
const double DAYS2WEEKS = 5;
const double WEEKS2MONTHS = 4.348;
const double MONTHS2YEARS = 12;

CTimeEdit::CTimeEdit(int nUnits) : m_nUnits(nUnits)
{
	SetMask(".0123456789");

	CString sLabel;
	sLabel.Format("%s  >", GetTimeUnit(nUnits).szLabel);

	AddButton(1, sLabel, "Time Units");
}

CTimeEdit::~CTimeEdit()
{

}

BEGIN_MESSAGE_MAP(CTimeEdit, CEnEdit)
	//{{AFX_MSG_MAP(CTimeEdit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CTimeEdit::PreSubclassWindow() 
{
	CEnEdit::PreSubclassWindow();

	SetButtonWidthDLU(1, BTNWIDTHDLU);
}

double CTimeEdit::GetTime() const
{
	CString sTime;
	GetWindowText(sTime);
	return atof(sTime);
}

void CTimeEdit::SetTime(double dTime)
{
	SetTime(dTime, 2);
}

void CTimeEdit::SetTime(double dTime, int nDecPlaces)
{
	CString sTime;
	sTime.Format("%.*f", nDecPlaces, dTime);

	SetWindowText(sTime);
}

void CTimeEdit::SetTime(double dTime, int nUnits, int nDecPlaces)
{
	if (dTime != GetTime())
	{
		SetWindowText(FormatTime(dTime, nDecPlaces));
		SetUnits(nUnits);
	}
}

void CTimeEdit::SetUnits(int nUnits)
{
	if (nUnits != m_nUnits)
	{
		m_nUnits = nUnits;

		CString sLabel;
		sLabel.Format("%s  >", GetTimeUnit(nUnits).szLabel);
		SetButtonCaption(1, sLabel);
	}
}

void CTimeEdit::OnBtnClick(UINT nID)
{
	CMenu menu;
	
	if (menu.CreatePopupMenu())
	{			
		for (int nUnit = 0; nUnit < NUM_UNITS; nUnit++)
		{
			const TIMEUNIT& tu = TIMEUNITS[nUnit];

			menu.AppendMenu(MF_STRING, tu.nMenuID, tu.szLabel);

			if (tu.nUnits == m_nUnits)
				menu.CheckMenuItem(nUnit, MF_CHECKED | MF_BYPOSITION);
		}
		CRect rButton = GetButtonRect(nID);
		
		TPMPARAMS tpmp;
		tpmp.cbSize = sizeof(TPMPARAMS);
		tpmp.rcExclude = rButton;
		
		UINT nID = ::TrackPopupMenuEx(menu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RETURNCMD, 
									rButton.right, rButton.top, *this, &tpmp);

		// handle result
		for (nUnit = 0; nUnit < NUM_UNITS; nUnit++)
		{
			const TIMEUNIT& tu = TIMEUNITS[nUnit];

			if (tu.nMenuID == nID)
			{
				if (m_nUnits != tu.nUnits)
				{
					SetUnits(tu.nUnits);
					GetParent()->SendMessage(WM_TEN_UNITSCHANGE, (WPARAM)GetSafeHwnd(), 0);
				}
				break;
			}
		}
	}
}

double CTimeEdit::GetTime(int nUnits) const
{
	return GetTime(GetTime(), m_nUnits, nUnits);
}

double CTimeEdit::GetTime(double dTime, int nFromUnits, int nToUnits)
{
	if (nFromUnits == nToUnits)
		return dTime;

	else if (Compare(nFromUnits, nToUnits) > 0)
	{
		while (Compare(nFromUnits, nToUnits) > 0)
		{
			switch (nFromUnits)
			{
			case TEU_DAYS:
				dTime *= HOURS2DAYS;
				nFromUnits = TEU_HOURS;
				break;
				
			case TEU_WEEKS:
				dTime *= DAYS2WEEKS;
				nFromUnits = TEU_DAYS;
				break;
				
			case TEU_MONTHS:
				dTime *= WEEKS2MONTHS;
				nFromUnits = TEU_WEEKS;
				break;
				
			case TEU_YEARS:
				dTime *= MONTHS2YEARS;
				nFromUnits = TEU_MONTHS;
				break;
			}
		}
	}
	else // nFromUnits < nToUnits
	{
		while (Compare(nFromUnits, nToUnits) < 0)
		{
			switch (nFromUnits)
			{
			case TEU_HOURS:
				dTime /= HOURS2DAYS;
				nFromUnits = TEU_DAYS;
				break;

			case TEU_DAYS:
				dTime /= DAYS2WEEKS;
				nFromUnits = TEU_WEEKS;
				break;
				
			case TEU_WEEKS:
				dTime /= WEEKS2MONTHS;
				nFromUnits = TEU_MONTHS;
				break;
				
			case TEU_MONTHS:
				dTime /= MONTHS2YEARS;
				nFromUnits = TEU_YEARS;
				break;
			}
		}
	}

	return dTime;
}

CString CTimeEdit::FormatTime(int nDecPlaces, BOOL bUnits) const
{
	if (bUnits)
		return FormatTime(GetTime(), m_nUnits, nDecPlaces);
	else
		return FormatTime(GetTime(), nDecPlaces);
}

CString CTimeEdit::FormatTime(double dTime, int nDecPlaces)
{
	CString sTime;
	sTime.Format("%.*f", nDecPlaces, dTime);

	return sTime;
}

CString CTimeEdit::FormatTime(double dTime, int nUnits, int nDecPlaces)
{
	CString sTime;

	switch (nUnits) 
	{
	case TEU_HOURS:
		sTime.Format("%.*f h", nDecPlaces, dTime);
		break;
	
	case TEU_DAYS:
		sTime.Format("%.*f d", nDecPlaces, dTime);
		break;
	
	case TEU_WEEKS:
		sTime.Format("%.*f w", nDecPlaces, dTime);
		break;
	
	case TEU_MONTHS:
		sTime.Format("%.*f m", nDecPlaces, dTime);
		break;
	
	case TEU_YEARS:
		sTime.Format("%.*f y", nDecPlaces, dTime);
		break;
	}

	return sTime;
}

int CTimeEdit::Compare(int nFromUnits, int nToUnits)
{
	if (nFromUnits == nToUnits)
		return 0;

	switch (nFromUnits)
	{
	case TEU_HOURS:
		return -1; // less than everything else
	
	case TEU_DAYS:
		return (nToUnits == TEU_HOURS) ? 1 : -1;
	
	case TEU_WEEKS:
		return (nToUnits == TEU_HOURS || nToUnits == TEU_DAYS) ? 1 : -1;
	
	case TEU_MONTHS:
		return (nToUnits == TEU_YEARS) ? -1 : 1;
	
	case TEU_YEARS:
		return 1; // greater than everything else
	}

	// else
	return 0;
}

void CTimeEdit::OnSetReadOnly(BOOL bReadOnly)
{
	EnableButton(1, !bReadOnly && IsWindowEnabled());
}

