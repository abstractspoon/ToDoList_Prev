

//////////////////////////////////////////////////////////////////////////////

MSXML2::IXMLDOMDocument* CXmlNodeWrapper::ParentDocument()
{
	return m_xmlnode->GetownerDocument().Detach();
}

MSXML2::IXMLDOMNode* CXmlNodeWrapper::Interface()
{
	if (IsValid())
		return m_xmlnode;
	return NULL;
}

MSXML2::IXMLDOMNode* CXmlNodeWrapper::InsertBefore(MSXML2::IXMLDOMNode *refNode, LPCTSTR nodeName)
{
	MSXML2::IXMLDOMDocumentPtr xmlDocument = m_xmlnode->GetownerDocument();
	if (xmlDocument)
	{
		MSXML2::IXMLDOMNodePtr newNode = xmlDocument->createNode(_variant_t((short)MSXML2::NODE_ELEMENT),nodeName,"");
		MSXML2::IXMLDOMNode* pNode = m_xmlnode->insertBefore(newNode.Detach(),(IUnknown*)refNode);
		
		return pNode;
	}
	return NULL;
}

MSXML2::IXMLDOMNode* CXmlNodeWrapper::InsertAfter(MSXML2::IXMLDOMNode *refNode, LPCTSTR nodeName)
{
	MSXML2::IXMLDOMDocumentPtr xmlDocument = m_xmlnode->GetownerDocument();
	if (xmlDocument)
	{
		MSXML2::IXMLDOMNodePtr newNode = xmlDocument->createNode(_variant_t((short)MSXML2::NODE_ELEMENT),nodeName,"");
		MSXML2::IXMLDOMNodePtr nextNode = refNode->GetnextSibling();
		MSXML2::IXMLDOMNode* pNode = NULL;
		
		if (nextNode.GetInterfacePtr() != NULL)
			pNode = m_xmlnode->insertBefore(newNode.Detach(),(IUnknown*)nextNode);
		else
			pNode = m_xmlnode->appendChild(newNode.Detach());
		
		return pNode;
	}
	return NULL;
}

void CXmlNodeWrapper::RemoveNodes(LPCTSTR searchStr)
{
	if (!IsValid())
		return;

	MSXML2::IXMLDOMNodeListPtr nodeList = m_xmlnode->selectNodes(searchStr);
	for (int i = 0; i < nodeList->Getlength(); i++)
	{
		try
		{
			MSXML2::IXMLDOMNode* pNode = nodeList->Getitem(i).Detach();
			pNode->GetparentNode()->removeChild(pNode);
		}
		catch (_com_error er)
		{
			AfxMessageBox(er.ErrorMessage());
		}
	}
}

MSXML2::IXMLDOMNode* CXmlNodeWrapper::Parent()
{
	if (IsValid())
		return m_xmlnode->GetparentNode().Detach();

	return NULL;
}

CXmlNodeListWrapper::CXmlNodeListWrapper()
{
}
CXmlNodeListWrapper::CXmlNodeListWrapper(MSXML2::IXMLDOMNodeListPtr pList)
{
	m_xmlnodelist = pList;
}

void CXmlNodeListWrapper::operator=(MSXML2::IXMLDOMNodeListPtr pList)
{
	if (IsValid())
		m_xmlnodelist.Release();
	
	m_xmlnodelist = pList;
}

CXmlNodeListWrapper::~CXmlNodeListWrapper()
{
	
}

int CXmlNodeListWrapper::Count()
{
	if (IsValid())
		return m_xmlnodelist->Getlength();
	else
		return 0;
	
}

BOOL CXmlNodeListWrapper::IsValid()
{
	if (m_xmlnodelist == NULL)
		return FALSE;

	if (m_xmlnodelist.GetInterfacePtr() == NULL)

		return FALSE;
	return TRUE;
}

MSXML2::IXMLDOMNode* CXmlNodeListWrapper::Next()
{
	if (IsValid())
		return m_xmlnodelist->nextNode().Detach();
	else
		return NULL;
}

void CXmlNodeListWrapper::Start()
{
	if (IsValid())
		m_xmlnodelist->reset();
}

MSXML2::IXMLDOMNode* CXmlNodeListWrapper::Node(int index)
{
	if (IsValid())
		return m_xmlnodelist->Getitem(index).Detach();
	else
		return NULL;
}

MSXML2::IXMLDOMDocument* CXmlNodeListWrapper::AsDocument()
{
	if (IsValid())
	{
		CXmlDocumentWrapper doc;
		doc.LoadXML("<NodeList></NodeList>");
		
		CXmlNodeWrapper root(doc.AsNode());
		
		for (int i = 0; i < m_xmlnodelist->Getlength(); i++)
		{
			root.InsertNode(root.NumNodes(),m_xmlnodelist->Getitem(i)->cloneNode(VARIANT_TRUE));
		}
		return doc.Detach();
	}
	else 
		return NULL;
}

MSXML2::IXMLDOMNodeList* CXmlNodeWrapper::FindNodes(LPCTSTR searchStr)
{
	if(IsValid())
	{
		try
		{
			return m_xmlnode->selectNodes(searchStr).Detach();
		}
		catch (_com_error e)
		{
			CString err = e.ErrorMessage();
			return NULL;
		}
	}
	else
		return NULL;
}

CString CXmlNodeWrapper::Name()
{
	if (IsValid())
		return (LPCSTR)m_xmlnode->GetbaseName();
	return "";
}

MSXML2::IXMLDOMNode* CXmlNodeWrapper::InsertAfter(MSXML2::IXMLDOMNode *refNode, MSXML2::IXMLDOMNode *pNode)
{
	MSXML2::IXMLDOMNodePtr nextNode = refNode->GetnextSibling();
	MSXML2::IXMLDOMNodePtr newNode;
	// Valik - Change IXMLDOMNode* to IXMLDOMNodePtr to prevent an ambiguous symbol error (C2872) in VC 7.1
	MSXML2::IXMLDOMNodePtr pNewNode = NULL;

	if (nextNode.GetInterfacePtr() != NULL)
		pNewNode = m_xmlnode->insertBefore(pNode,(IUnknown*)nextNode);
	else
		pNewNode = m_xmlnode->appendChild(pNode);

	return pNewNode;
}

void CXmlNodeWrapper::SetText(LPCTSTR text)
{
	if (IsValid())
	{
		_bstr_t bstr(ConvertStringToBSTR(text), FALSE);
		m_xmlnode->Puttext(bstr);
	}
}

CString CXmlNodeWrapper::GetText()
{
	if (IsValid())
		return (LPCSTR)m_xmlnode->Gettext();
	else
		return "";
}

void CXmlNodeWrapper::ReplaceNode(MSXML2::IXMLDOMNode *pOldNode, MSXML2::IXMLDOMNode *pNewNode)
{
	if (IsValid())
	{
		m_xmlnode->replaceChild(pNewNode,pOldNode);
	}
}

int CXmlNodeWrapper::NumAttributes()
{
	if (IsValid())
	{
		MSXML2::IXMLDOMNamedNodeMapPtr attribs = m_xmlnode->Getattributes();
		
		if (attribs)
			return attribs->Getlength();
	}
	
	return 0;
}

CString CXmlNodeWrapper::GetAttribName(int index)
{
	CString sName;
	
	if (IsValid())
	{
		MSXML2::IXMLDOMNamedNodeMapPtr attribs = m_xmlnode->Getattributes();

		if (attribs)
		{
			MSXML2::IXMLDOMAttributePtr attrib = attribs->Getitem(index);

			if (attrib)
			{
				sName = (LPCSTR)attrib->Getname();
				attrib.Release();
			}
			
			attribs.Release();
		}
	}
	
	return sName;
}

CString CXmlNodeWra