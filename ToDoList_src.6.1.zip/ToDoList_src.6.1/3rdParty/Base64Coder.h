doc->appendChild(pHdr);
	}
}

MSXML2::IXMLDOMDocument* CXmlDocumentWrapper::Detach()
{
	if (!IsValid())
		return NULL;
	return m_xmldoc.Detach();
}

MSXML2::IXMLDOMDocument* CXmlDocumentWrapper::Clone()
{
	if (!IsValid())
		return NULL;
	MSXML2::IXMLDOMDocumentPtr xmldoc;
	xmldoc.CreateInstance(MSXML2::CLSID_DOMDocument);

	_variant_t v(xmldoc.GetInterfacePtr());
	m_xmldoc->save(v);

	return xmldoc.Detach();
}

BOOL CXmlDocumentWrapper::Load(LPCTSTR path, BOOL bPreserveWhiteSpace)
{
	if (!IsValid())
		return FALSE;
	
	m_xmldoc->put_preserveWhiteSpace(bPreserveWhiteSpace ? VARIANT_TRUE : VARIANT_FALSE);
	m_xmldoc->put_async(VARIANT_FALSE);
	
	_bstr_t bstr(CXmlNodeWrapper::ConvertStringToBSTR(path), FALSE);

	return (VARIANT_TRUE == m_xmldoc->load(bstr));
}

BOOL CXmlDocumentWrapper::LoadXML(LPCTSTR xml/*, BOOL bPreserveWhiteSpace*/)
{
	if (!IsValid())
		return FALSE;
	
	//m_xmldoc->put_preserveWhiteSpace(bPreserveWhiteSpace ? VARIANT_TRUE : VARIANT_FALSE);

	_bstr_t bstr(CXmlNodeWrapper::ConvertStringToBSTR(xml), FALSE); 
	
	return (VARIANT_TRUE == m_xmldoc->loadXML(bstr));
}

BOOL CXmlDocumentWrapper::Save(LPCTSTR path, BOOL bPreserveWhiteSpace)
{
	if (!IsValid())
		return FALSE;
	
	try
	{
		_bstr_t bPath(CXmlNodeWrapper::ConvertStringToBSTR(path), FALSE);
		
		if (bPath.length() == 0)
			bPath = m_xmldoc->Geturl();
		
		m_xmldoc->put_preserveWhiteSpace(bPreserveWhiteSpace ? VARIANT_TRUE : VARIANT_FALSE);
		
		return (VARIANT_TRUE == m_xmldoc->save(bPath));
	}
	catch(...)
	{
		return FALSE;
	}
}

CString CXmlDocumentWrapper::Transform(LPCTSTR pathXSL) const
{
	CXmlDocumentWrapper xsl;
	
    try
    {
        if (xsl.Load(pathXSL))
            return (LPSTR)m_xmldoc->transformNode(xsl.AsNode());
    }
    catch( const _com_error & err)
    {
        AfxMessageBox(err.ErrorMessage(), MB_OK | MB_ICONERROR);
    }

    // else
    return "";
}

MSXML2::IXMLDOMNode* CXmlDocumentWrapper::AsNode()
{
	if (!IsValid())
		return NULL;

	return m_xmldoc->GetdocumentElement().Detach();
}
