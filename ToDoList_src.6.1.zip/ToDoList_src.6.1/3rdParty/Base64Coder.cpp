// XmlNodeWrapper.cpp: implementation of the CXmlNodeWrapper class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "XmlNodeWrapper.h"
#include "comutil.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

// fix for bad typedef in <wtypes.h>
#ifdef VARIANT_TRUE
#	undef VARIANT_TRUE
#	define VARIANT_TRUE ((VARIANT_BOOL)(-1))
#endif

const LPCTSTR DEFAULT_HEADER = "version=\"1.0\" encoding=\"windows-1252\"";

CXmlNodeWrapper::CXmlNodeWrapper()
{
}

CXmlNodeWrapper::CXmlNodeWrapper(MSXML2::IXMLDOMNodePtr pNode,BOOL bAutoRelease)
{
	m_xmlnode = pNode;
	m_bAutoRelease = bAutoRelease;
}

CXmlNodeWrapper& CXmlNodeWrapper::operator=(MSXML2::IXMLDOMNodePtr pNode)
{
	if (IsValid())
		m_xmlnode.Release();

	m_xmlnode = pNode;
	return *this;
}

CXmlNodeWrapper::~CXmlNodeWrapper()
{
	if (!m_bAutoRelease)
		m_xmlnode.Detach();
}


CString CXmlNodeWrapper::GetValue(LPCTSTR valueName)
{
	if (!IsValid())
		return "";
	
	MSXML2::IXMLDOMNodePtr attribute = m_xmlnode->Getattributes()->getNamedItem(valueName);
	if (attribute)
	{
		return (LPCSTR)attribute->Gettext();
	}
	return "";
}

BOOL CXmlNodeWrapper::IsValid()
{
	if (m_xmlnode == NULL)
		return FALSE;
	if (m_xmlnode.GetInterfacePtr() == NULL)
		return FALSE;
   
	return TRUE;
}

MSXML2::IXMLDOMNode* CXmlNodeWrapper::GetPrevSibling()
{
	if (!IsValid())
		return NULL;
	return m_xmlnode->GetpreviousSibling().Detach();
}

MSXML2::IXMLDOMNode* CXmlNodeWrapper::GetNextSibling()
{
	if (!IsValid())
		return NULL;
	return m_xmlnode->GetnextSibling().Detach();
}

MSXML2::IXMLDOMNode* CXmlNodeWrapper::GetNode(LPCTSTR nodeName)
{
	if (!IsValid())
		return NULL;
	try{
		return m_xmlnode->selectSingleNode(nodeName).Detach();
	}
	catch (_com_error e)
	{
		CString err = e.ErrorMessage();
	}
	return NULL;
}

MSXML2::IXMLDOMNode* CXmlNodeWrapper::GetNode(int nodeIndex)
{
	if (!IsValid())
		return NULL;
	
	return m_xmlnode->GetchildNodes()->Getitem(nodeIndex).Detach();
}

MSXML2::IXMLDOMNode* CXmlNodeWrapper::FindNode(LPCTSTR searchString)
{
	if (!IsValid())
		return NULL;

	try
	{
		return m_xmlnode->selectSingleNode(searchString).Detach();
	}
	catch (_com_error e)
	{
		CString err = e.ErrorMessage();
	}
	return NULL;
}

MSXML2::IXMLDOMNode* CXmlNodeWrapper::Detach()
{
	if (IsValid())
		return m_xmlnode.Detach();
	else
		return NULL;
}

long CXmlNodeWrapper::NumNodes()
{
	if (IsValid())
	{
		return m_xmlnode->GetchildNodes()->Getlength();
	}
	else
		return 0;
}

void CXmlNodeWrapper::SetValue(LPCTSTR valueName,LPCTSTR value)
{
	MSXML2::IXMLDOMDocumentPtr xmlDocument = m_xmlnode->GetownerDocument();

	if (xmlDocument)
	{
		MSXML2::IXMLDOMNamedNodeMapPtr attributes = m_xmlnode->Getattributes();

		if (attributes)
		{
			MSXML2::IXMLDOMAttributePtr attribute = xmlDocument->createAttribute(valueName);
			
			if (attribute)
			{
				attribute->Puttext(value);
				attributes->setNamedItem(attribute);
			}
		}
	}
}

void CXmlNodeWrapper::SetValue(LPCTSTR valueName,int value)
{
	CString str;
	str.Format("%ld",value);
	SetValue(valueName,str);
}

void CXmlNodeWrapper::SetValue(LPCTSTR valueName,short value)
{
	CString str;
	str.Format("%hd",value);
	SetValue(valueName,str);
}

void CXmlNodeWrapper::SetValue(LPCTSTR valueName,double value)
{
	CString str;
	str.Format("%f",value);
	SetValue(valueName,str);
}

void CXmlNodeWrapper::SetValue(LPCTSTR valueName,float value)
{
	CString str;
	str.Format("%f",value);
	SetValue(valueName,str);
}

void CXmlNodeWrapper::SetValue(LPCTSTR valueName,bool value)
{
	CString str;
	if (value)
		str = "True";
	else
		str = "False";
	SetValue(valueName,str);
}

MSXML2::IXMLDOMNode* CXmlNodeWrapper::AppendChild(MSXML2::IXMLDOMNodePtr pNode)
{
	return m_xmlnode->appendChild(pNode);
}

MSXML2::IXMLDOMNode* CXmlNodeWrapper::InsertNode(int index,LPCTSTR nodeName)
{
	MSXML2::IXMLDOMDocumentPtr xmlDocument = m_xmlnode->GetownerDocument();

	if (xmlDocument)
	{
		MSXML2::IXMLDOMNodePtr newNode = xmlDocument->createNode(_variant_t((short)MSXML2::NODE_ELEMENT),nodeName,"");
		MSXML2::IXMLDOMNode* refNode = GetNode(index);
		MSXML2::IXMLDOMNode* pNewNode = NULL;
		
		if (refNode)
			pNewNode = m_xmlnode->insertBefore(newNode.Detach(),refNode);
		else
			pNewNode = m_xmlnode->appendChild(newNode.Detach());
		
		return pNewNode;
	}
	return NULL;
}

MSXML2::IXMLDOMNode* CXmlNodeWrapper::InsertNode(int index, MSXML2::IXMLDOMNodePtr pNode)
{
	MSXML2::IXMLDOMNodePtr newNode = pNode->cloneNode(VARIANT_TRUE);

	if (newNode)
	{
		MSXML2::IXMLDOMNode* refNode = GetNode(index);
		MSXML2::IXMLDOMNode* pNewNode = NULL;
		
		if (refNode)
			pNewNode = m_xmlnode->insertBefore(newNode.Detach(),refNode);
		else
			pNewNode = m_xmlnode->appendChild(newNode.Detach());
		
		return pNewNode;
	}
	else
		return NULL;
}

CString CXmlNodeWrapper::GetXML()
{
	if (IsValid())
		return (LPCSTR)m_xmlnode->Getxml();
	else
		return "";
}

MSXML2::IXMLDOMNode* CXmlNodeWrapper::RemoveNode(MSXML2::IXMLDOMNodePtr pNode)
{
	if (!IsValid())
		return NULL;
	return m_xmlnode->removeChild(pNode).Detach();
}

/* ********************************************************************************************************* */

BOOL CXmlDocumentWrapper::s_bVer3orGreater = -1;

CXmlDocumentWrapper::CXmlDocumentWrapper(LPCTSTR header, LPCTSTR szRootItem)
{
	try
	{
		m_xmldoc.CreateInstance(MSXML2::CLSID_DOMDocument);
		m_xmldoc->put_validateOnParse(VARIANT_FALSE);
		m_xmldoc->put_async(VARIANT_FALSE);
		
		if (szRootItem && *szRootItem)
		{
			CString sRoot;
			sRoot.Format("<%s/>", szRootItem);
			LoadXML(sRoot);
		}

	   // set header afterwards so it not overwritten
		if (header && *header)
			SetHeader(header);
	}
	catch (...)
	{
	}
}

CXmlDocumentWrapper::CXmlDocumentWrapper(MSXML2::IXMLDOMDocumentPtr pDoc)
{
	m_xmldoc = pDoc;
}

CXmlDocumentWrapper::~CXmlDocumentWrapper()
{
}

BOOL CXmlDocumentWrapper::IsValid() const
{
	if (m_xmldoc == NULL)
		return FALSE;

	if (m_xmldoc.GetInterfacePtr() == NULL)
		return FALSE;

	return TRUE;
}

CString CXmlDocumentWrapper::GetHeader(BOOL bAsXml) const
{
	CString sHeader;
	
	if (IsValid())
	{
		CXmlNodeWrapper nodeHdr(m_xmldoc->childNodes->item[0]);
		
		if (nodeHdr.IsValid())
		{
			if (nodeHdr.GetXML().Find("?xml") == 1) // <?xml
			{
				int nAttribs = nodeHdr.NumAttributes();
				
				for (int nAttrib = 0