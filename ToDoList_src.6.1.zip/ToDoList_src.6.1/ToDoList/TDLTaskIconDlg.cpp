i++)
	{
		_pDC->MoveTo(i*nWidth, CALENDAR_HEADER_HEIGHT);
		_pDC->LineTo(i*nWidth, rc.Height());
	}
	
	for(i=0; i<nNumWeeks; i++)
	{
		int nNewPos = (i*nHeight)+CALENDAR_HEADER_HEIGHT;
		_pDC->MoveTo(0, nNewPos);
		_pDC->LineTo(rc.Width(), nNewPos);
	}
	_pDC->SelectObject(pOldPen);
}

void CBigCalendarCtrl::DrawCells(CDC* _pDC)
{
	int nNumColumns = m_pFrameWnd->GetNumDaysToDisplay();
	int nNumWeeks = m_pFrameWnd->GetNumWeeksToDisplay();

	CRect rc;
	GetClientRect(&rc);	//rect of the BigCalendar

	CFont* pOldFont = _pDC->SelectObject(m_pFont);

	CPen blackPen(PS_SOLID, 1, COLOUR_TASKS);
	CPen* pOldPen = _pDC->SelectObject(&blackPen);

	for(int i=0; i < nNumWeeks; i++)
	{
		for(int u=0; u < nNumColumns; u++)
		{
			CRect rect;
			if(GetRectFromCell(i, u, rect))
			{
				if(u == nNumColumns-1) rect.right = rc.right;
				if(i == nNumWeeks-1) rect.bottom = rc.bottom;

				if( (m_bMonthIsOdd && !(m_dayCells[i][u].date.GetMonth()%2)) ||
					(!m_bMonthIsOdd && (m_dayCells[i][u].date.GetMonth()%2)))
				{
					CBrush br;
					br.CreateSolidBrush(CALENDAR_LIGHTGREY);
					_pDC->FillRect(&rect ,&br);
				}

				BOOL bToday = FALSE;

				COleDateTime dtToday;
				CCalendarUtils::GetToday(dtToday);

				if (dtToday == m_dayCells[i][u].date)
				{
					// Draw the frame
					CRect rcLine(rect);
					rcLine.bottom = rcLine.top+15;
					rcLine.top = rcLine.bottom-1;
					for(int c=0; c<15; c++)
					{
						_pDC->FillSolidRect(rcLine, GetFadedBlue(c*6));
						rcLine.bottom--;
						rcLine.top = rcLine.bottom-1;
					}
					bToday = TRUE;
				}

				// Draw the selection
				if (m_dateSelected == m_dayCells[i][u].date)
				{						
					CRect selRect(rect);
					CBrush br;
					br.CreateSolidBrush(GetFadedBlue(70));
					if (bToday)
					{
						selRect.top += 15;
					}
					_pDC->FillRect(&selRect, &br);
				}

				// Out of range
				if (!CCalendarUtils::IsDateValid(m_dayCells[i][u].date))	
				{
					CRect selRect(rect);
					CBrush br;
					br.CreateSolidBrush(COLOUR_INVALID_DATE);
					_pDC->FillRect(&selRect, &br);
				}

				//draw Important marker
				if (m_dayCells[i][u].arrTasks.GetSize() > 0)
				{
					CBrush br;
					br.CreateSolidBrush(COLOUR_IMPORTANTDAY_MARKER);
					CRect rcMark(rect);
					rcMark.left = rcMark.right - 15;
					rcMark.bottom = rcMark.top + 13;
					_pDC->FillRect(&rcMark, &br);
				}

				// draw inside...
				rect.DeflateRect(1,1);		

				int nDay = m_dayCells[i][u].date.GetDay();

				if(nDay == 1 || (i==0 && u==0))
				{
					//draw month name
					CRect rcMonth(rect);
					rcMonth.right -= 15;

					int nMonth = m_dayCells[i][u].date.GetMonth();
					CString csMonth = CDateHelper::GetMonth(nMonth, FALSE);
					CSize dtSize(_pDC->GetTextExtent(csMonth));
					if (dtSize.cx > rcMonth.Width())
					{
						//no room for long version, must use short version (e.g. must use "Dec" instead of "December")
						csMonth = CDateHelper::GetMonth(nMonth, TRUE);
					}

					unsigned long nOldColor = _pDC->SetTextColor(COLOUR_MONTHNAMES);
					_pDC->DrawText(csMonth, rcMonth, DT_RIGHT|DT_TOP);
					_pDC->SetTextColor(nOldColor);
				}

				if (m_dayCells[i][u].arrTasks.GetSize() > 0)
				{
					_pDC->SelectObject(m_pFontBold);
				}
				else
				{
					_pDC->SelectObject(m_pFont);
				}

				//draw day number
				CString strDay;
				strDay.Format("%d", nDay);
				unsigned long nOldColor = _pDC->SetTextColor(COLOUR_DAYNUMBERS);
				_pDC->DrawText(strDay, rect, DT_RIGHT|DT_TOP);
				_pDC->SetTextColor(nOldColor);
			}
		}
	}

	_pDC->SelectObject(pOldFont);
	_pDC->SelectObject(pOldPen);
}

void CBigCalendarCtrl::FireNotifySelectDate()
{
	EnterCell();
	SendSelectDateMessageToParent(FALSE);
}

void CBigCalendarCtrl::SendSelectDateMessageToParent(BOOL bAndSendSelectT