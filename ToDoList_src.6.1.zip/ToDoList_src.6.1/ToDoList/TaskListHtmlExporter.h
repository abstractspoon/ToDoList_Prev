<?xml version="1.0" ?>
<!-- History:
V2.0 Author Hoppfrosch@gmx.de, 20061105
  [*]  Correct formatting of RTF-Comments (based on ToDoStyler1.5 by .dan.g.)
    * See: http://www.codeproject.com/tools/todolist2.asp?df=100&forumid=25857&select=1739493#xx1739493xx
    * Works only with TDL Version newer than 5.0b7
  Known issues:
   * Problems with german umlauts in Comments (The text after the last Umlaut isn't shown in transformed output - at least at my computer)
   * See: http://www.codeproject.com/tools/ToDoList2.asp?df=100&forumid=25857&fr=26&select=1739493#xx1739493xx 
V1.3 Author Hoppfrosch@gmx.de, 20060621
 [-] Completion bars for Firefox/Opera
 [-] Priority colorisation of finished tasks is switched off
 [*] Replaced @PERCENTDONE by @CALCPERCENTDONE to simulate the visual behaviour of TDL
  Known issues:
   * Display of completion and status field is shown as completed (greyed) with completed tasks (Firefox/Opera)
   * Comments are without formatting (all browsers))
 
V1.2 Author Hoppfrosch@gmx.de, 20051123
 [+] Added Anchor (Task-ID) to element taskname, so tasks can be linked directly ....
 Known issues: see V1.1

V1.1 Author Hoppfrosch@gmx.de, 20051108
 [*] Added browser compatibility for generated HTML-Code (IExplore, Firefox, Opera) ...
 [+] Insertion of Filerefs as HTML-Links
 Known issues:
   * Generation of completion bar fails (Firefox/Opera)
   * Display of completion and status field is shown as completed (greyed) with completed tasks (Firefox/Opera)
   * Comments are without formatting (all browsers))

V1.0 ToDoListStyler 1.0 Original by Manual Reyes 
-->

<xsl:stylesheet xmlns:xsl="http://www.w3.org/199