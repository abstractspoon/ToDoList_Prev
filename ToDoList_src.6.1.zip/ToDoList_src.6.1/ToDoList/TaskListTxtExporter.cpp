 #C9DDEC;
          }
					
					.prettyPriority
					{
						width:20px;
						text-align:center;
						color: white;
					}
										
					.masterCompletedTaskTitleText
					{
						font-weight: bold;
						color: #C0C0C0;
						font-size: 12px;
						text-decoration: line-through;
					}
					
					.masterTaskTitleText
					{
						font-weight: bold;
						font-size: 12px;
						color: #000000;
					}
					
					.subCompletedTaskTitleText
					{
						font-weight: bold;
						color: #C0C0C0;
						text-decoration: line-through;
					}
					
					.subTaskTitleText
					{
						font-weight: bold;
						color: #000000;
					}
					
					.completedBaseInfoText
					{
						color: #C0C0C0;
					}
					
					.baseInfoText
					{
						color: #000000;
					}
					
					.completedDatesText
					{
						color: #C0C0C0;
					}
					
					.datesText
					{
						color: #000000;
					}
					
					.completedPeopleText
					{
						color: #C0C0C0;
					}
					
					.peopleText
					{
						color: #000000;
					}
					
					.completedFilerefpathText
					{
						color: #C0C0C0;
					}
					
					.filerefpathText
					{
						color: #000000;
					}
					
					.completedCommentsText
					{
						color: #C0C0C0;
					}
					
					.commentsText
					{
						color: #000000;
					}
					
					.priorityNumberStyle
					{
						font-weight: bold;
					}
				</xsl:element>
			</xsl:element>
			<xsl:element name="body">
				<!-- HEADER SPAN -->
				<xsl:element name="div">
					<xsl:attribute name="class">headerSpan</xsl:attribute>
					<xsl:element name="h2">Project Summary</xsl:element>
					<xsl:element name="h3"><xsl:value-of select="@PROJECTNAME" /></xsl:element>
				</xsl:element>
				
				<!-- SPACER -->
				<xsl:element name="br"/>
				<xsl:element name="br"/>
				
				<!-- TASK INFORMATION -->
				<xsl:apply-templates />
				
				<!-- FOOTER SPAN -->
				<xsl:element name="div">
					<xsl:attribute name="class">footerSpan</xsl:attribute>
					<xsl:element name="h5">Generated from TodoList - http://www.abstractspoon.com<xsl:element name="br"/>Using TodoListStyler v2.0</xsl:element>
				</xsl:element>
			</xsl:element>
		</xsl:element>
	</xsl:template>
	
	<xsl:template match="TASK">
		<xsl:choose>
			<xsl:when test="TASK">
				<xsl:choose>
					<xsl:when test="parent::TODOLIST">
						<!-- master tasks -->
						<xsl:element name="div">
							<xsl:choose>
								<xsl:when test="@DONEDATESTRING">
									<xsl:attribute name="class">completedMasterTaskSpan</xsl:attribute>
								</xsl:when>
								<xsl:otherwise>
									<xsl:attribute name="class">masterTaskSpan</xsl:attribute>
								</xsl:otherwise>
							</xsl:choose>
							<xsl:call-template name="get_Task_Details" />
							<xsl:element name="ul">
								<xsl:apply-templates>
								  <xsl:sort select="@POS"/>
								</xsl:apply-templates>
							</xsl:element>
						</xsl:element>
						<xsl:element name="br"/>
						<xsl:element name="br"/>
					</xsl:when>
					<xsl:otherwise>
						<!-- sub tasks -->
						<xsl:call-template name="get_Task_Details" />
						<xsl:element name="ul">
							<xsl:apply-templates />
						</xsl:element>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:when>
			<xsl:otherwise>
				<xsl:choose>
					<xsl:when test="parent::TODOLIST">
						<!-- master tasks that do not contain any sub tasks -->
						<xsl:element name="span">
							<xsl:choose>
								<xsl:when test="@DONEDATESTRING">
									<xsl:attribute name="class">completedMasterTaskSpan</xsl:attribute>
								</xsl:when>
								<xsl:otherwise>
									<xsl:attribute name="class">masterTaskSpan</xsl:attribute>
								</xsl:otherwise>
							</xsl:choose>
							<xsl:call-template name="get_Task_Details" />
							<xsl:element name="ul">
								<xsl:apply-templates />
							</xsl:element>
						</xsl:element>
						<xsl:element name="br"/>
						<xsl:element name="br"/>
					</xsl:when>
					<xsl:otherwise>
						<!-- sub tasks -->
						<xsl:call-template name="get_Task_Details" />
						<xsl:apply-templates />
					</xsl:otherwise>
				</xsl:choose>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	
	<!--
	Retrieves task details
	-->
	<xsl:template name="get_Task_Details">
		<li>
			<xsl:call-template name="get_Task_Title" />
			<xsl:element name="br"/>
			<xsl:call-template name="get_Task_Base_Info" />
			<xsl:element name="br"/>
			<xsl:call-template name="get_Task_Dates" />
			<xsl:element name="br"/>
			<xsl:call-template name="get_Task_People" />
			<xsl:element name="br"/>
			<xsl:call-template name="get_Task_Fileref" />
			<xsl:element name="br"/>
			<xsl:call-template name="get_Task_Comment" />
			<xsl:element name="br"/>
			<xsl:element name="br"/>
		</li>
	</xsl:template>
	
	<!--
	Get the title of the current task
	-->
	<xsl:template name="get_Task_Title">
		<xsl:choose>
			<xsl:when test="parent::TODOLIST">
				<xsl:element name="span">
					<xsl:choose>
						<xsl:when test="@DONEDATESTRING"><xsl:attribute name="class">masterCompletedTaskTitleText</xsl:attribute></xsl:when>
						<xsl:otherwise><xsl:attribute name="class">masterTaskTitleText</xsl:attribute></xsl:otherwise>
					</xsl:choose>
					<xsl:element name="a">
            <xsl:attribute name="name">
              <xsl:value-of select="@ID" />
            </xsl:attribute>
            <xsl:value-of select="@TITLE" />
					</xsl:element>
				</xsl:element>
			</xsl:when>
			<xsl:otherwise>
				<xsl:element name="span">
					<xsl:choose>
						<xsl:when test="@DONEDATESTRING"><xsl:attribute name="class">subCompletedTaskTitleText</xsl:attribute></xsl:when>
						<xsl:otherwise><xsl:attribute name="class">subTaskTitleText</xsl:attribute></xsl:otherwise>
					</xsl:choose>
				  <xsl:element name="a">
            <xsl:attribute name="name">
              <xsl:value-of select="@ID" />
            </xsl:attribute>
            <xsl:value-of select="@TITLE" />
					</xsl:element>
				</xsl:element>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	
	<!--
	Retrieves summary information for task
	-->
	<xsl:template name="get_Task_Base_Info">
		<xsl:element name="span">
			<!-- choose style to use based on completion -->
			<xsl:choose>
				<xsl:when test="@DONEDATESTRING"><xsl:attribute name="class">completedBaseInfoText</xsl:attribute></xsl:when>
				<xsl:otherwise><xsl:attribute name="class">baseInfoText</xsl:attribute></xsl:otherwise>
			</xsl:choose>

			<!-- elements that always exist -->
			<xsl:element name="a">[Task ID: <xsl:value-of select="@ID" />]</xsl:element>
			<xsl:element name="a"><xsl:call-template name="get_Pretty_Priority" /></xsl:element>
			<xsl:element name="a"><xsl:call-template name="get_Pretty_Percent_Bar" /></xsl:element>
			
			<!-- Status -->
			<xsl:choose>
				<xsl:when test="@STATUS">
					<xsl:element name="a">[Status: <xsl:value-of select="@STATUS" />]</xsl:element>
				</xsl:when>
				<xsl:otherwise>
					<xsl:element name="a">[Status: Not Set]</xsl:element>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:element>
	</xsl:template>
	
	<!--
	Gets a visual percent bar
	-->
	<xsl:template name="get_Pretty_Percent_Bar">
		<xsl:element name="span">[Completion: <xsl:value-of select="@CALCPERCENTDONE" />% ]</xsl:element>
		<!-- only add percent bar if not 100 or 0 percent -->
		<xsl:if test="@CALCPERCENTDONE&lt;100">
			<xsl:if test="@CALCPERCENTDONE&gt;0">
			  <xsl:element name="div">
			 	  <xsl:attribute name="class">progressBarBorder</xsl:attribute>
          <xsl:element name="div">
            <xsl:attribute name="class">progressBar</xsl:attribute>
            <xsl:attribute name="style">width: <xsl:value-of select="@CALCPERCENTDONE" />%</xsl:attribute>
				  </xsl:element>
				</xsl:element>
			</xsl:if>
		</xsl:if>
	</xsl:template>
	
	<xsl:template name="get_Pretty_Priority">
		<xsl:element name="span">
			<xsl:element name="span">[Priority: </xsl:element>
			<xsl:element name="span">
				<xsl:attribute name="class">prettyPriority</xsl:attribute>
				<xsl:choose>
					<xsl:when test="@PRIORITY">
						<xsl:element name="a">
							<xsl:attribute name="class">priorityNumberStyle</xsl:attribute>
							<!-- only non-finished task get coloured