ER:
					nXPos = rText.left + (rText.Width() - sizeText.cx) / 2;
					break;

				case LVCFMT_RIGHT:
					nXPos = rText.right - 4 - sizeText.cx;
					break;

				case LVCFMT_LEFT:
				default:
					nXPos = rText.left + 4;
					break;
			}

			pDC->ExtTextOut(nXPos, nYPos, ETO_CLIPPED | ETO_OPAQUE, rText, sText, NULL);

			// setup focus rect
			if (nCol == m_nCurCol && nItem == GetCurSel())
			{
				rFocus = rText;

				if (nCol == 0)
					rFocus.left += 2;
			}

			// adjust for previously removed button width
			if (bHasButton)
				rText.right += BTN_WIDTH;

			// draw vert grid if required
			if (m_bVertGrid)
			{ 
				if (nCol > 0)
					pDC->FillSolidRect(rText.left, rItem.top, 1, rItem.Height(), GetSysColor(COLOR_3DSHADOW));

				// if its the last column and we're not tight up against the client edge
				// then draw the end line
				if (!bRes && rText.right != rClient.right)
					pDC->FillSolidRect(rText.right, rItem.top, 1, rItem.Height(), GetSysColor(COLOR_3DSHADOW));
			}

			// next column
			nCol++;
		}

		// draw horz grid lines if required
		if (m_bHorzGrid)
		{
			if (!m_bVertGrid)
				pDC->FillSolidRect(rClient.left, rText.bottom - 1, rClient.Width(), 1, GetSysColor(COLOR_3DSHADOW));
			else
				pDC->FillSolidRect(rClient.left, rText.bottom - 1, rText.right, 1, GetSysColor(COLOR_3DSHADOW));
		}

		// then draw focus rect
		if (bItemFocused && bListFocused)
			pDC->DrawFocusRect(rFocus);
	}
}

BOOL CInputListCtrl::CanDeleteSelectedCell() const
{
	// if readonly or disabled then no
	if (IsReadOnly() || !IsWindowEnabled())
		return FALSE;

	if (GetCurSel() != -1)
	{
		// don't delete it if its the topleft item
		if (m_bAutoAddCols && GetCurSel() == 0 && m_bAutoAddRows && m_nCurCol == 0)
			return FALSE;

		// else can delete it if its not the row prompt
		else if (m_bAutoAddRows && m_nCurCol == 0)
		{
			if (GetCurSel() < GetItemCount() - 1)
				return TRUE;
		}
		// else can delete it if its not the col prompt
		else if (m_bAutoAddCols && GetCurSel() == 0)
		{
			if (m_nCurCol < GetColumnCount() - 1)
				return TRUE;
		}
	}

	// else can't d