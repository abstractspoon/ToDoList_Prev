or == CLR_DEFAULT)
			cf.dwEffects = CFE_AUTOBACKCOLOR;
		else
			cf.crBackColor = color;
	}

	m_rtf.SendMessage(EM_SETCHARFORMAT, SCF_SELECTION, (LPARAM) &cf);

}

LRESULT CRulerRichEditCtrl::OnSetCurrentFontName(WPARAM font, LPARAM)
/* ============================================================
	Function :		CRulerRichEditCtrl::OnSetCurrentFontName
	Description :	Handler for the registered message 
					"urm_SETCURRENTFONTNAME", called when the 
					font name is changed from the toolbar.
	Access :		Protected

	Return :		LRESULT		-	Not used
	Parameters :	WPARAM font	-	Pointer to the new font name
					LPARAM		-	Not used

	Usage :			Called from MFC

   ============================================================*/
{
	SetCurrentFontName((LPCTSTR) font);

	return 0;
}

LRESULT CRulerRichEditCtrl::OnSetCurrentFontSize(WPARAM, LPARAM size)
/* ============================================================
	Function :		CRulerRichEditCtrl::OnSetCurrentFontSize
	Description :	Handler for the registered message 
					"urm_SETCURRENTFONTSIZE", called when the 
					font size is changed from the toolbar.
	Access :		Protected

	Return :		LRESULT		-	Not used
	Parameters :	WPARAM		-	Not used
					LPARAM size	-	New font size in typographical 
									points of the selected text

	Usage :			Called from MFC

   ============================================================*/
{

	SetCurrentFontSize(size);
	return 0;
}
	
void CRulerRichEditCtrl::OnKillFocusToolbar(NMHDR* /*pNMHDR*/, LRESULT* pResult)
{
	// pretend the richedit lost focus to force an update
	SendMessage(WM_COMMAND, MAKEWPARAM(RTF_CONTROL, EN_KILLFOCUS), (LPARAM)m_rtf.GetSafeHwnd());
	*pResult = 0;
}

LRESULT CRulerRichEditCtrl::OnSetCurrentFontColor(WPARAM bForeground, LPARAM color)
/* ============================================================
	Function :		CRulerRichEditCtrl::OnSetCurrentFontColor
	Description :	Handler for the registered message 
					"urm_SETCURRENTFONTCOLOR", called when the 
					font color is changed from the toolbar.
	Access :		Protected

	Return :		LRESULT		-	Not used
	Parameters :	WPARAM		-	Not used
					LPARAM		-	New color of the selected 
									text

	Usage :			Called from MFC

   ============================================================*/
{

	SetCurrentFontColor((COLORREF) color, bForeground);

	m_rtf.SetFocus();
	return 0;
}

void CRulerRichEditCtrl::OnButtonTextColor()
{
	SetCurrentFontColor(m_toolbar.GetFontColor(TRUE), TRUE);
}

void CRulerRichEditCtrl::OnButtonBackColor()
{
	SetCurrentFontColor(m_toolbar.GetFontColor(FALSE), FALSE);
}

void CRulerRichEditCtrl::OnButtonWordwrap()
{
	SetWordWrap(!HasWordWrap());
}

void CRulerRichEditCtrl::DoColor()
/* ============================================================
	Function :		CRulerRichEditCtrl::DoColor
	Description :	Externally accessible member to set the
					color of the selected text
	Access :		Public
					
	Return :		void
	Parameters :	none
					
	Usage :			Call to set the color of the selected text.

   ============================================================*/
{

	// Get the current color
	COLORREF	clr(RGB(0, 0, 0));
	CharFormat	cf;
	m_rtf.SendMessage(EM_GETCHARFORMAT, SCF_SELECTION, (LPARAM) &cf);
	if (cf.dwMask & CFM_COLOR)
		clr = cf.crTextColor;

	// Display color selection dialog
	CColorDialog dlg(clr);
	if (dlg.DoModal() == IDOK)
	{

		// Apply new color
		cf.dwMask = CFM_COLOR;
		cf.dwEffects = 0;
		cf.crTextColor = dlg.GetColor();

		m_rtf.SendMessage(EM_SETCHARFORMAT, SCF_SELECTION, (LPARAM) &cf);

	}

	m_rtf.SetFocus();

}

void CRulerRichEditCtrl::DoBold()
/* ============================================================
	Function :		CRulerRichEditCtrl::DoBold
	Description :	Externally accessible member to set/unset
					the selected text to/from bold
	Access :		Public
					
	Return :		void
	Parameters :	none
					
	Usage :			Call to toggle the selected text to/from 
					bold.

   ============================================================*/
{
	m_toolbar.GetToolBarCtrl().CheckButton(BUTTON_BOLD, !m_toolbar.IsButtonChecked(BUTTON_BOLD));

	int effect = 0;
	if (m_toolbar.IsButtonChecked(BUTTON_BOLD))
		effect = CFE_BOLD;

	SetEffect(CFM_BOLD, effect);
}

void CRulerRichEditCtrl::DoStrikethrough()
{
	m_toolbar.GetToolBarCtrl().CheckButton(BUTTON_STRIKETHRU, !m_toolbar.IsButtonChecked(BUTTON_STRIKETHRU));

	int effect = 0;
	if (m_toolbar.IsButtonChecked(BUTTON_STRIKETHRU))
		effect = CFE_STRIKEOUT;

	SetEffect(CFM_STRIKEOUT, effect);
}

void CRulerRichEditCtrl::DoSuperscript()
{
	CharFormat	cf;
	m_rtf.SendMessage(EM_GETCHARFORMAT, SCF_SELECTION, (LPARAM) &cf);

	BOOL bSuperscript = (cf.dwEffects & CFE_SUPERSCRIPT);

	SetEffect(CFM_SUPERSCRIPT, bSuperscript ? 0 : CFE_SUPERSCRIPT);
}

void CRulerRichEditCtrl::DoSubscript()
{
	CharFormat	cf;
	m_rtf.SendMessage(EM_GETCHARFORMAT, SCF_SELECTION, (LPARAM) &cf);

	BOOL bSubscript = (cf.dwEffects & CFE_SUBSCRIPT);

	SetEffect(CFM_SUBSCRIPT, bSubscript ? 0 : CFE_SUBSCRIPT);
}

void CRulerRichEditCtrl::DoItalic()
/* ============================================================
	Function :		CRulerRichEditCtrl::DoItalic
	Description :	Externally accessible member to set/unset
					the selected text to/from italic
	Access :		Public
					
	Return :		void
	Parameters :	none
					
	Usage :			Call to toggle the selected text to/from 
					italic.

   ============================================================*/
{

	m_toolbar.GetToolBarCtrl().CheckButton(BUTTON_ITALIC, !m_toolbar.IsButtonChecked(BUTTON_ITALIC));

	int effect = 0;
	if (m_toolbar.IsButtonChecked(BUTTON_ITALIC))
		effect = CFE_ITALIC;

	SetEffect(CFM_ITALIC, effect);

}

void CRulerRichEditCtrl::DoUnderline()
/* ============================================================
	Function :		CRulerRichEditCtrl::DoUnderline
	Description :	Externally accessible member to set/unset
					the selected text to/from underline
	Access :		Public
					
	Return :		void
	Parameters :	none
					
	Usage :			Call to toggle the selected text to/from 
					underlined.

   ============================================================*/
{

	m_toolbar.CheckButton(BUTTON_UNDERLINE, !m_toolbar.IsButtonChecked(BUTTON_UNDERLINE));

	int effect = 0;
	if (m_toolbar.IsButtonChecked(BUTTON_UNDERLINE))
		effect = CFE_UNDERLINE;

	SetEffect(CFM_UNDERLINE, effect);

}

void CRulerRichEditCtrl::DoLeftAlign()
/* ============================================================
	Function :		CRulerRichEditCtrl::DoLeftAlign
	Description :	Externally accessible member to set the
					selected text to left aligned.
	Access :		Public
					
	Return :		void
	Parameters :	none
					
	Usage :			Call to left-align the selected text

   ============================================================*/
{

	if (!m_toolbar.IsButtonChecked(BUTTON_LEFTALIGN))
		SetAlignment(PFA_LEFT);

}

void CRulerRichEditCtrl::DoCenterAlign()
/* ============================================================
	Function :		CRulerRichEditCtrl::DoCenterAlign
	Description :	Externally accessible member to set the
					selected text to center aligned
	Access :		Public
					
	Return :		void
	Parameters :	none
					
	Usage :			Call to center-align the selected text

   ============================================================*/
{

	if (!m_toolbar.IsButtonChecked(BUTTON_CENTERALIGN))
		SetAlignment(PFA_CENTER);

}

void CRulerRichEditCtrl::DoRightAlign()
/* ============================================================
	Function :		CRulerRichEditCtrl::DoRightAlign
	Description :	Externally accessible member to set the
					selected text to right aligned
	Access :		Public
					
	Return :		void
	Parameters :	none
					
	Usage :			Call to right-align the selected text

   ============================================================*/
{

	if (!m_toolbar.IsButtonChecked(BUTTON_RIGHTALIGN))
		SetAlignment(PFA_RIGHT);

}

BOOL CRulerRichEditCtrl::FixupTabStops(ParaFormat& para)
{
	// returns TRUE if any changes were made to the tabstops
	int t = MAX_TAB_STOPS;
	
	// find the last non-zero tabstop
	while (t--)
	{
		if (para.rgxTabs[t] != 0)
			break;
	}

	// rebuild the tabs from the last non-zero element
	if (t < MAX_TAB_STOPS - 1)
	{
		int nTabstop = (t >= 0) ? para.rgxTabs[t] : 0;

		for (++t; t < MAX_TAB_STOPS; t++)
		{
			nTabstop += 320;
			para.rgxTabs[t] = nTabstop;
		}

		return TRUE;
	}

	// else no change
	return FALSE;
}

void CRulerRichEditCtrl::DoIndent()
/* ============================================================
	Function :		CRulerRichEditCtrl::DoIndent
	Description :	Externally accessible member to indent the
					selected text to the next tab position
	Access :		Public
					
	Return :		void
	Parameters :	none
					
	Usage :			Call to indent the selected text

   ============================================================*/
{

	// Get current indent
	ParaFormat	para(PFM_STARTINDENT | PFM_TABSTOPS);
	m_rtf.GetParaFormat(para);
	int newindent = para.dxStartIndent;

	// Find next larger tab
	for (int t = 0; t < MAX_TAB_STOPS; t++)
	{

		if (para.rgxTabs[ t ] > para.dxStartIndent)
		{
			newindent = para.rgxTabs[ t ];
			break;
		}
	}

	// handle exceeding MAX_TAB_STOPS by incrementing by default amount
	if (newindent == para.dxStartIndent)
		newindent += 320;

	// Set indent to this value
	para.dwMask = PFM_STARTINDENT | PFM_OFFSET;
	para.dxStartIndent = newindent;
//	para.dxOffset = 10;

	m_rtf.SetParaFormat(para);
	m_rtf.SetFocus();

}

void CRulerRichEditCtrl::DoOutdent()
/* ============================================================
	Function :		CRulerRichEditCtrl::DoOutdent
	Description :	Externally accessible member to outdent the
					selected text to the previous tab position
	Access :		Public
					
	Return :		void
	Parameters :	none
					
	Usage :			Call to outdent the selected text

   ============================================================*/
{

	// Get the current indent, if any
	ParaFormat	para(PFM_STARTINDENT | PFM_TABSTOPS);
	m_rtf.GetParaFormat(para);
	int newindent = 0;

	// Find closest smaller tab
	for(int t = 0 ; t < MAX_TAB_STOPS ; t++)
		if (para.rgxTabs[ t ] < para.dxStartIndent)
			newindent = para.rgxTabs[ t ];

	// Set indent to this value or 0 if none
	para.dwMask = PFM_STARTINDENT | PFM_OFFSET;
	para.dxStartIndent = newindent;
//	para.dxOffset = newindent;

	m_rtf.SetParaFormat(para);
	m_rtf.SetFocus();


}

void CRulerRichEditCtrl::DoBullet()
/* ============================================================
	Function :		CRulerRichEditCtrl::DoBullet
	Description :	Externally accessible member to set the
					selected text to bulleted
	Access :		Public
					
	Return :		void
	Parameters :	none
					
	Usage :			Call to set the selected text to bulleted.

   ============================================================*/
{
	
	m_toolbar.GetToolBarCtrl().CheckButton(BUTTON_BULLET, !m_toolbar.IsButtonChecked(BUTTON_BULLET));

	ParaFormat2	para(PFM_NUMBERING | PFM_OFFSET);

	if (m_toolbar.IsButtonChecked(BUTTON_BULLET))
	{
		para.wNumbering = PFN_BULLET;
		para.dxOffset = 300;
	}
	else
	{
		para.wNumbering = 0;
		para.dxOffset = 0;
	}

	m_rtf.SetParaFormat(para);
	m_rtf.SetFocus();

}

void CRulerRichEditCtrl::DoNumberList()
/* ============================================================
	Function :		CRulerRichEditCtrl::DoBullet
	Description :	Externally accessible member to set the
					selected text to bulleted
	Access :		Public
					
	Return :		void
	Parameters :	none
					
	Usage :			Call to set the selected text to bulleted.

   ============================================================*/
{
	
	m_toolbar.GetToolBarCtrl().CheckButton(BUTTON_NUMBER, !m_toolbar.IsButtonChecked(BUTTON_NUMBER));

	ParaFormat2	para(PFM_NUMBERING | PFM_NUMBERINGSTYLE | PFM_NUMBERINGSTART | PFM_OFFSET);

	if (m_toolbar.IsButtonChecked(BUTTON_NUMBER))
	{
		para.wNumbering = PFN_NUMBERLIST;
		para.wNumberingStart = 1;
		para.wNumberingStyle = 0x200;
		para.dxOffset = 300;
	}
	else
	{
		para.wNumbering = 0;
		para.dxOffset = 0;
	}

	m_rtf.SetParaFormat(para);
	m_rtf.SetFocus();

}

void CRulerRichEditCtrl::ShowToolbar(BOOL show)
/* ============================================================
	Function :		CRulerRichEditCtrl::ShowToolbar
	Description :	Shows or hides the toolbar
	Access :		Public
					
	Return :		void
	Parameters :	BOOL show	-	"TRUE" to show
					
	Usage :			Call to show or hide the toolbar subcontrol

   ============================================================*/
{

	m_showToolbar = show;

	if (m_hWnd)
	{
		if (show)
			m_toolbar.GetToolBarCtrl().ShowWindow(SW_SHOW);
		else
			m_toolbar.GetToolBarCtrl().ShowWindow(SW_HIDE);

		CRect rect;
		GetClientRect(rect);
		LayoutControls(rect.Width(), rect.Height());
	}

}

void CRulerRichEditCtrl::SetWordWrap(BOOL bWrap)
{
	if (bWrap != m_bWordWrap)
		m_rtf.SetTargetDevice(NULL, bWrap ? 0 : 1);

	m_bWordWrap = bWrap;
	m_toolbar.CheckButton(BUTTON_WORDWRAP, m_bWordWrap ? 1 : 0);
}

void CRulerRichEditCtrl::ShowRuler(BOOL show)
/* ============================================================
	Function :		CRulerRichEditCtrl::ShowRuler
	Description :	Shows or hides the ruler
	Access :		Public
					
	Return :		void
	Parameters :	BOOL show	-	"TRUE" to show
					
	Usage :			Call to show or hide the ruler subcontrol

   ============================================================*/
{

	m_showRuler = show;

	if (m_hWnd)
	{
		if (show)
			m_ruler.ShowWindow(SW_SHOW);
		else
			m_ruler.ShowWindow(SW_HIDE);

		CRect rect;
		GetClientRect(rect);
		LayoutControls(rect.Width(), rect.Height());
	}
}

void CRulerRichEditCtrl::LayoutControls(int width, int height)
/* ============================================================
	Function :		CRulerRichEditCtrl::LayoutControls
	Description :	Lays out the sub-controls depending on 
					visibility.
	Access :		Private
					
	Return :		void
	Parameters :	int width	-	Width of control
					int height	-	Height of control
					
	Usage :			Called internally to lay out the controls

   ============================================================*/
{
	if (!width || !height)
		return;

//	TRACE("LayoutControls(w = %d, h = %d)\n", width, height);

	int toolbarHeight = 0;

	if (m_showToolbar)
	{
		toolbarHeight = m_toolbar.Resize(width, CPoint(0, 0));
	}

	int rulerHeight = 0;

	if (m_showRuler)
		rulerHeight = RULER_HEIGHT;

	m_ruler.MoveWindow(0, toolbarHeight, width, rulerHeight);

	int top = toolbarHeight + rulerHeight;
	CRect rect(0, top, width, height);
	m_rtf.MoveWindow(rect);

}

BOOL CRulerRichEditCtrl::IsToolbarVisible() const
/* ============================================================
	Function :		CRulerRichEditCtrl::IsToolbarVisible
	Description :	Returns if the toolbar is visible or not
	Access :		Public
					
	Return :		BOOL	-	"TRUE" if visible
	Parameters :	none
					
	Usage :			Call to get the visibility of the toolbar

   ============================================================*/
{

	return m_showToolbar;

}

BOOL CRulerRichEditCtrl::IsRulerVisible() const
/* ============================================================
	Function :		CRulerRichEditCtrl::IsRulerVisible
	Description :	Returns if the ruler is visible or not
	Access :		Public
					
	Return :		BOOL	-	"TRUE" if visible
