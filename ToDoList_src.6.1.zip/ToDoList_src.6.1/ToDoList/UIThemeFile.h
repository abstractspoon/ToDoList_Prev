#if !defined(AFX_PREFERENCESSHORTCUTSPAGE_H__DA5D005D_C6CC_453A_A431_A2B85A920CE5__INCLUDED_)
#define AFX_PREFERENCESSHORTCUTSPAGE_H__DA5D005D_C6CC_453A_A431_A2B85A920CE5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PrefererencesShortcutsPage.h : header file
//

#include "..\shared\shortcutManager.h"
#include "..\shared\orderedtreectrl.h"
#include "..\shared\hotkeyctrlex.h"
#include "..\shared\preferencesbase.h"

/////////////////////////////////////////////////////////////////////////////
// CPreferencesShortcutsPage dialog

#define PSP_SHORTCUTCOLUMNID (OTC_POSCOLUMNID - 1)

class CPreferencesShortcutsPage : public CPreferencesPageBase
{
// Construction
public:
	CPreferencesShortcutsPage(CShortcutManager* pMgr, UINT nMenuID,