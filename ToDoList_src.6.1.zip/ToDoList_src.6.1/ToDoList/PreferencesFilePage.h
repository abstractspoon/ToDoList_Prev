truct) == -1)
		return -1;

	// Save screen resolution for later on.
	CClientDC dc(this);
	m_physicalInch = dc.GetDeviceCaps(LOGPIXELSX);

	// Create sub-controls
	BOOL autohscroll = TRUE;

	if (CreateRTFControl(autohscroll) && CreateToolbar() && CreateRuler())
	{
		CreateMargins();
		SetReadOnly(GetReadOnly()); 
		UpdateToolbarButtons();

		CRect rClient;
		GetClientRect(rClient);

		LayoutControls(rClient.Width(), rClient.Height());

		return 0;
	}

	return -1;
}

void CRulerRichEditCtrl::OnEnHScroll()
{
	m_ruler.Invalidate(FALSE);
	m_ruler.UpdateWindow();
}

void CRulerRichEditCtrl::OnEnSelChange(NMHDR* /*pNMHDR*/, LRESULT* pResult)
{
	// Update the toolbar
	UpdateToolbarButtons();
	
	// Update ruler
	UpdateTabStops();
	m_ruler.Invalidate(FALSE);
	m_ruler.UpdateWindow();

	*pResult = 0;
}

LRESULT CRulerRichEditCtrl::OnSetFont(WPARAM wp, LPARAM /*lp*/)
{
	// reverse engineer the hFont and use the results
	// for the rtf defaults
	CString sFace;
	int nPoint = GraphicsMisc::GetFontNameSize((HFONT)wp, sFace);

	if (nPoint && !sFace.IsEmpty())
	{
		// lets have a backup plan
		if (!m_toolbar.SetFontName(sFace))
		{
			sFace = "MS Sans Serif";
			nPoint = 9;
			m_toolbar.SetFontName(sFace);
		}

		m_toolbar.SetFontSize(nPoint);

		// update default char format
		strcpy(m_cfDefault.szFaceName, sFace);
		m_cfDefault.yHeight = nPoint * 20;
		
		m_rtf.SetDefaultCharFormat(m_cfDefault);
	}
	// else eat it

	return 0L;
}

void CRulerRichEditCtrl::OnPaint() 
/* ============================================================
	Function :		CRulerRichEditCtrl::OnPaint
	Description :	Paints the ruler.
	Access :		Protected
					
	Return :		void
	Parameters :	none

	Usage :			Called from MFC. 

   ============================================================*/
{

//	CPaintDC mainDC(this);
//	UpdateTabStops();

}

BOOL CRulerRichEditCtrl::OnEraseBkgnd(CDC* /*pDC*/) 
/* ============================================================
	Function :		CRulerRichEditCtrl::OnEraseBkgnd
	Description :	Returns "TRUE" to avoid flicker.
	Access :		Protected
					
	Return :		BOOL		-	Always "TRUE",
	Parameters :	CDC* pDC	-	Not used
					
	Usage :			Called from MFC. 

   ============================================================*/
{
	
	return TRUE;

}

BOOL CRulerRichEditCtrl::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
/* ============================================================
	Function :		CRulerRichEditCtrl::OnNotify
	Description :	Called as the RTF-control is updated or 
					the selection changes.
	Access :		Protected
					
	Return :		BOOL				-	From base class
	Parameters :	WPARAM wParam		-	Control ID
					LPARAM lParam		-	Not interested
					LRESULT* pResult	-	Not interested
					
	Usage :			Called from MFC. We must check the control 
					every time the selection changes or the 
					contents are changed, as the cursor might 
					have entered a new paragraph, with new tab 
					and/or font settings.

   ============================================================*/
{
	return CWnd::OnNotify(wParam, lParam, pResult);
}

void CRulerRichEditCtrl::OnSize(UINT nType, int cx, int cy) 
/* ============================================================
	Function :		CRulerRichEditCtrl::OnSize
	Description :	We resize the embedded RTF-control.
	Access :		Protected
					
	Return :		void
	Parameters :	UINT nType	-	Not interested
					int cx		-	New width
					int cy		-	New height
					
	Usage :			Called from MFC. 

   ============================================================*/
{

	CWnd::OnSi