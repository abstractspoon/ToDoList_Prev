	else if (!m_bAutoAddRows && bRows)
	{
		m_bAutoAddRows = TRUE;

		// ensure there is at least one column
		if (GetColumnCount() == 0)
			InsertColumn(0, "", LVCFMT_LEFT, m_nAutoColWidth);
		else if (bCols)
			SetColumnWidth(0, m_nAutoColWidth);

		int nIndex = InsertItem(GetItemCount(), m_sAutoRowPrompt, -1);
		SetItemData(nIndex, PROMPT);
	}

	// cols
	if (m_bAutoAddCols && !bCols)
	{
		m_bAutoAddCols = FALSE;
		// delete last column
	}
	else if (!m_bAutoAddCols && bCols)
	{
		m_bAutoAddCols = TRUE;

		InsertColumn(GetColumnCount(), "", LVCFMT_LEFT, m_nAutoColWidth);
		InsertItem(0, "");
		SetItemText(0, GetColumnCount() - 1, m_sAutoColPrompt);
	}

	m_nCurCol = 0;
	Invalidate();
}

void CInputListCtrl::SetAutoColumnWidth(int nWidth)
{
	// don't allow outside than min/max sizes
	m_nAutoColWidth = min(nWidth, MAXCOLWIDTH);
	m_nAutoColWidth = max(nWidth, MINCOLWIDTH);
}

void CInputListCtrl::SetAutoRowPrompt(CString sPrompt)
{
	// can't set to empty string
	if (!sPrompt.IsEmpty())
		m_sAutoRowPrompt = sPrompt;
}

void CInputListCtrl::SetAutoColPrompt(CString sPrompt)
{
	// can't set