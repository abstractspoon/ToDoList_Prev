lID(m_hWnd), (WPARAM)&NotifyArea);

	if (bAndSendSelectTaskIDMsg)
	{
		NotifyArea.code = CALENDAR_MSG_SELECTTASK;
		NotifyArea.hwndFrom = m_hWnd;
		NotifyArea.idFrom = ::GetDlgCtrlID(m_hWnd);
		GetParent()->SendMessage(WM_NOTIFY, ::GetDlgCtrlID(m_hWnd), (WPARAM)&NotifyArea);
	}
}

void CBigCalendarCtrl::ScrollDown(int _nLines)
{
	ASSERT(_nLines > 0);

	COleDateTime dtFirstCell(m_dayCells[0][0].date);	//current first-cell
	CCalendarUtils::AddDay(dtFirstCell, 7*_nLines);

	if (!CCalendarUtils::IsDateValid(dtFirstCell))
	{
		ASSERT(FALSE);
		return;
	}

	m_nVscrollPos += _nLines;
	RepopulateAllCells(dtFirstCell);

	SetScrollPos(SB_VERT, m_nVscrollPos, TRUE);
}

void CBigCalendarCtrl::ScrollUp(int _nLines)
{
	ASSERT(_nLines > 0);

	COleDateTime dtFirstCell(m_dayCells[0][0].date);	//current first-cell
	CCalendarUtils::SubtractDay(dtFirstCell, 7*_nLines);

	if (!CCalendarUtils::IsDateValid(dtFirstCell))
	{
		ASSERT(FALSE);
		return;
	}

	m_nVscrollPos -= _nLines;
	RepopulateAllCells(dtFirstCell);

	SetScrollPos(SB_VERT, m_nVscrollPos, TRUE);
}

void CBigCalendarCtrl::CreateTasks(BOOL _bRecreate/*=FALSE*/)
{
	if (_bRecreate)
	{
		for (POSITION pos = m_listCalendarTasks.GetHeadPosition(); pos; )
		{
			CBigCalendarTask* pTaskWnd = (CBigCalendarTask*)m_listCalendarTasks.GetNext(pos);
			pTaskWnd->DestroyWindow();
			delete pTaskWnd;
		}
		m_listCalendarTasks.RemoveAll();
	}

	int nNumColumns = m_pFrameWnd->GetNumDaysToDisplay();
	int nNumWeeks = m_pFrameWnd->GetNumWeeksToDisplay();
	DWORD dwStyleCompletedTasks = m_pFrameWnd->GetCompletedTasksStyle();

	int nTaskWindowID = 1234;

	for (int i = 0; i < nNumWeeks; i++)
	{
		for 