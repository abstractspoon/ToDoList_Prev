// InputListCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "InputListCtrl.h"
#include "themed.h"
#include "enstring.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInputListCtrl

#define MAXCOLWIDTH 600
#define MINCOLWIDTH 80
#define IDC_EDITBOX 101
#define WM_SHOWPOPUPMENU (WM_APP+1001)
#define BTN_WIDTH 17

static DWORD PROMPT = 0xfefefefe;

CInputListCtrl::CInputListCtrl()
{
	m_nItemLastSelected = -1;
	m_nColLastSelected = -1;
	m_nEditItem = -1;
	m_nEditCol = -1;
	m_bAutoAddRows = FALSE;
	m_bAutoAddCols = FALSE;
	m_nAutoColWidth = MINCOLWIDTH;
	m_sAutoRowPrompt = "(new row)";
	m_sAutoColPrompt = "(new col)";
	m_bAllowDuplication = TRUE;
	m_bNotifyDuplicates = FALSE;
	m_bBaseClassEdit = FALSE;
	m_nCurCol = -1;
	m_nItemHeight = 14;
}

CInputListCtrl::~CInputListCtrl()
{
}


BEGIN_MESSAGE_MAP(CInputListCtrl, CEnListCtrl)
	//{{AFX_MSG_MAP(CInputListCtrl)
	ON_WM_KEYDOWN()
	ON_WM_KILLFOCUS()
	ON_WM_SETFOCUS()
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_WM_CREATE()
	ON_WM_RBUTTONDOWN()
	ON_WM_LBUTTONUP()
	//}}AFX_MSG_MAP
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_REGISTERED_MESSAGE(WM_PENDEDIT, OnEditEnd)
	ON_REGISTERED_MESSAGE(WM_PCANCELEDIT, OnEditCancel)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInputListCtrl message handlers

const CColumnData2* CInputListCtrl::GetColumnData(int nCol) const
{
	return static_cast<const CColumnData2*>(CEnListCtrl::GetColumnData(nCol)); 
}

void CInputListCtrl::AllowDuplicates(BOOL bAllow, BOOL bNotify)
{ 
	m_bAllowDuplication = bAllow; 
	m_bNotifyDuplicates = bNotify;
}

void CInputListCtrl::OnLButtonDblClk(UINT /*nFlags*/, CPoint point) 
{
	// find out which column the user clicked on
	int nItem = HitTest(point);
	int nCol = GetColumnAtPoint(point);

	// DO NOT DO DEFAULT HANDLING 
	// because it causes flicker in combination with our owner draw
	//CEnListCtrl::OnLButtonDblClk(nFlags, point);
	if (GetCurSel() != -1)
	{
		// if we cant edit then pass on to parent but not otherwise since this would
		// cause the focus to be removed from the edit control
		if (!CanEditSelectedCell())
		{
			// dg 4/2/99
			// this produced counter-intuitive results so i'm disabling it for now
			// instead you must right-click and select 'properties'
		//	m_nmhdr.hwndFrom = m_hWnd;
		//	m_nmhdr.idFrom = GetDlgCtrlID();
		//	m_nmhdr.code = LVN_USERSELCHANGEDBLCLK;
		//	GetParent()->SendMessage(WM_NOTIFY, (WPARAM)GetDlgCtrlID(), (LPARAM)&m_nmhdr);
		}
		else if (!(IsEditing() && nItem == m_nEditItem && nCol == m_nEditCol))
		{
			// the above check deals with the situation than occurs when the user
			// double clicks on an already selected item. 
			// ie the WM_LBUTTONDOWN that preceeds WM_LBUTTONDBLCLK will already
			// have initiated an edit 
			EditCell(nItem, nCol);
		}
	}
}

void CInputListCtrl::OnLButtonDown(UINT /*nFlags*/, CPoint point) 
{
	// DO NOT DO DEFAULT HANDLING 
	// because it causes flicker in combination with our owner draw
//	CEnListCtrl::OnLButtonDown(nFlags, point);

	int nSelItem, nSelCol;
	GetCurSel(nSelItem, nSelCol);

	BOOL bHadFocus = (GetFocus() == this);
	BOOL bWasEditing = IsEditing();
	int nItem = HitTest(point);
	int nCol = GetColumnAtPoint(point);
	
	SetFocus();

	// if we're were editing the same cell we've clicked on then
	// we may be cancelling a listbox edit so don't trigger it again
	if (bWasEditing && nItem == Get