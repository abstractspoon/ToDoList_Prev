 == nNumCols - 1 && GetCurSel() != 0)
			return FALSE;

		// or if its the topleft item when auto adding rows AND cols
		if (m_bAutoAddCols && m_bAutoAddRows && GetCurSel() == 0 && m_nCurCol == 0)
			return FALSE;
	
		// of if its the bottom right item when auto adding rows AND cols
		if (m_bAutoAddCols && m_bAutoAddRows && 
			GetCurSel() == nNumRows - 1 && m_nCurCol == nNumCols - 1)
			return FALSE;
	
		// go ahead
		return TRUE;
	}

	// can't edit
	return FALSE;
}

void CInputListCtrl::EditSelectedCell()
{
	EditCell(GetCurSel(), m_nCurCol);
}

void CInputListCtrl::OnKillFocus(CWnd* pNewWnd) 
{
	// ignore if WE are pNewWnd
	if (pNewWnd == this)
		return;

	// if we're not editing then clear the current selection
	if (!IsEditing())
	{
		m_nItemLastSelected = -1;
		m_nColLastSelected = -1;
	}

	CRect rItem;
	GetItemRect(GetCurSel(), rItem, LVIR_BOUNDS);
	InvalidateRect(rItem, FALSE);

	CEnListCtrl::OnKillFocus(pNewWnd);
}

BOOL CInputListCtrl::SetCellText(int nRow, int nCol, CString sText)
{
	ASSERT (m_hWnd);
	ASSERT ((m_bAutoAddRows && nRow >=0 && nRow < GetItemCount() - 1) || 
			(!m_bAutoAddRows && nRow >=0 && nRow < GetItemCount()));
	ASSERT ((m_bAutoAddCols && nCol >=0 && nCol < GetColumnCount() - 1) ||
			(!m_bAutoAddCols && nCol >=0 && nCol < GetColumnCount()));

	// only allow text setting if within valid range and