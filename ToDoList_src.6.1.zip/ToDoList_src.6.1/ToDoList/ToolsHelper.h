#if !defined(AFX_PREFERENCESMULTIUSERPAGE_H__D7484AFF_704B_4FA9_94DA_9AB2F5364816__INCLUDED_)
#define AFX_PREFERENCESMULTIUSERPAGE_H__D7484AFF_704B_4FA9_94DA_9AB2F5364816__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesMultiUserPage.h : header file
//

#include "..\shared\preferencesbase.h"

/////////////////////////////////////////////////////////////////////////////
// CPreferencesMultiUserPage dialog

enum // source control
{
	STSS_NONE,
	STSS_LANONLY,
	STSS_ALL,
};

enum // reload
{
	RO_NO,
	RO_ASK,
	RO_AUTO,
	RO_NOTIFY,
};

class CPreferencesMultiUserPage : public CPreferencesPageBase
{
	DECLARE_DYNCREATE(CPreferencesMultiUserPage)

// Construction
public:
	CPreferencesMultiUserPage();
	~CPreferencesMultiUserPage();

	int GetReadonlyReloadOption() const;
	int GetTimestampReloadOption() const;
	BOOL GetEnableSourceControl() const { return m_bEnableSourceControl && !m_bUse3rdPartySourceControl; }
	BOOL GetSourceControlLanOnly() const { return m_bEnableSourceControl && m_bSourceControlLanOnly; }
	BOOL GetAutoCheckOut() const { return m_bEnableSourceControl && m_bAutoCheckOut; }
	BOOL GetCheckoutOnCheckin() const { return m_bEnableSourceControl && m_bCheckoutOnCheckin; }
	BOOL GetCheckinOnClose() const { return m_bEnableSourceControl && m_bCheckinOnClose; }
	UINT GetRemoteFileCheckFrequency() const { return m_nRemoteFileCheckFreq; }
	UINT GetCheckinOnNoEditTime() const { return (m_bEnableSourceControl && m_bCheckinNoChange) ? m_nCheckinNoEditTime : 0; }
	BOOL GetUsing3rdPartySourceControl() const { return m_bUse3rdPartySourceControl && !m_bEnableSourceControl; }

protected:
// Dialog Data
	//{{AFX_DATA(CPreferencesMultiUserPage)
	enum { IDD = IDD_PREFMULTIUSER_PAGE };
	CComboBox	m_cbNoEditTime;
	BO