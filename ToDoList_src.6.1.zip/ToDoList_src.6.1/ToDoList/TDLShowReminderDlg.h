;
	}
	int nCellStart = narr[dtFirstCell.GetDayOfWeek()-1];

	dtFirstCell -= nCellStart;

	if (m_pFrameWnd->IsWeekendsHidden())
	{
		int iDayOfWeek = dtFirstCell.GetDayOfWeek();
		int nDiff = abs(m_nFirstWeekDay - iDayOfWeek);
		dtFirstCell -= nDiff;

		if (dtFirstCell.GetDayOfWeek() == 1)
		{
			//sun
			dtFirstCell += 1;
		}
		else if (dtFirstCell.GetDayOfWeek() == 7)
		{
			//sat
			dtFirstCell += 2;
		}
	}

	RepopulateAllCells(dtFirstCell);
}

void CBigCalendarCtrl::Goto(const COleDateTime& _date,
							BOOL _bSelect/*=FALSE*/)
{
	if (!CCalendarUtils::IsDateValid(_date))
	{
		ASSERT(FALSE);
		return;
	}

	COleDateTime dtNew = _date;
	if (m_pFrameWnd->IsDateHidden(dtNew)) //it was a saturday or sunday
	{
		CCalendarUtils::SubtractDay(dtNew, 1);
		if (m_pFrameWnd->IsDateHidden(dtNew))	//it was a sunday
		{
			CCalendarUtils::SubtractDay(dtNew, 1);
		}
	}

	int nNumColumns = m_pFrameWnd->GetNumDaysToDisplay();
	int nNumWeeks = m_pFrameWnd->GetNumWeeksToDisplay();

	if (_bSelect)
	{
		m_dateSelected = dtNew;

		// Scrolling pos
		COleDateTime dtToday;
		CCalendarUtils::GetToday(dtToday);
		m_nVscrollPos = (m_nVscrollMax/2) + (m_dateSelected-dtToday).GetDays()/nNumColumns;
		SetScrollPos(SB_VERT, m_nVscrollPos, TRUE);
	}

	COleDateTime dtFirstCell = COleDateTime(dtNew.GetYear(), dtNew.GetMonth(), dtNew.GetDay(),0,0,0);

	BOOL bBelow = FALSE;
	if (IsDateVisible(dtNew, &bBelow))
	{
		//already visible - keep current 1st cell a