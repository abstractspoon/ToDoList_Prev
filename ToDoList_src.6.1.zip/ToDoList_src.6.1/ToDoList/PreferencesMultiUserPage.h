e
					font of the control
	Access :		Public
					
	Return :		void
	Parameters :	none
					
	Usage :			Call to set the font of the selected text.

   ============================================================*/
{

	// Get the current font
	LOGFONT	lf;
	ZeroMemory(&lf, sizeof(LOGFONT));
	CharFormat	cf;
	m_rtf.SendMessage(EM_GETCHARFORMAT, SCF_SELECTION, (LPARAM) &cf);
	int height;

	// Creating a LOGFONT from the current font settings

	// Font
	if (cf.dwMask & CFM_FACE)
		lstrcpy(lf.lfFaceName, cf.szFaceName);

	if (cf.dwMask & CFM_SIZE)
	{
		double twip = (double)m_physicalInch / 1440;
		height = cf.yHeight;
		height = -(int) ((double) height * twip +.5);
		lf.lfHeight = height;

	}

	// Effects
	if (cf.dwMask & CFM_BOLD)
	{
		if (cf.dwEffects & CFE_BOLD)
			lf.lfWeight = FW_BOLD;
		else
			lf.lfWeight = FW_NORMAL;
	}

	if ((cf.dwMask & CFM_ITALIC) && (cf.dwEffects & CFE_ITALIC))
		lf.lfItalic = TRUE;

	if ((cf.dwMask & CFM_UNDERLINE) && (cf.dwEffects & CFE_UNDERLINE))
		lf.lfUnderline = TRUE;

	if ((cf.dwMask & CFM_STRIKEOUT) && (cf.dwEffects & CFE_STRIKEOUT))
		lf.lfStrikeOut = TRUE;

	// Show font dialog
	CFontDialog	dlg(&lf);

	// color
	dlg.m_cf.rgbColors = cf.crTextColor;

	if (dlg.DoModal() == IDOK)
	{
		// Apply new font
		cf.yHeight = dlg.GetSize() * 2;
		lstrcpy(cf.szFaceName, dlg.GetFaceName());

		cf.dwMask = CFM_FACE | CFM_SIZE | CFM_COLOR | CFM_BOLD | 
					CFM_ITALIC | CFM_UNDERLINE | CFM_STRIKEOUT;
		cf.dwEffects = 0;
		cf.crTextColor = dlg.GetColor();

		if (dlg.IsBold())
			cf.dwEffects |= CFE_BOLD;

		if (dlg.IsItalic())
			cf.dwEffects |= CFE_ITALIC;

		if (dlg.IsUnderline())
			cf.dwEffects |= CFE_UNDERLINE;

		if (dlg.IsStrikeOut())
			cf.dwEffects |= CFE_STRIKEOUT;

		m_rtf.SendMessage(EM_SETCHARFORMAT, SCF_SELECTION, (LPARAM) &cf);
/*
		m_toolbar.SetFontColor(cf.crTextColor, TRUE);
*/
	}

	m_rtf.SetFocus();

}

void CRulerRichEditCtrl::SetCurrentFontName(const CString& font)
/* ============================================================
	Function :		CRulerRichEditCtrl::SetCurrentFontName
	Description :	Changes the font of the selected text in 
					the editor to "font".
	Access :		Public
					
	Return :		void
	Parameters :	const CString& font	-	Font name of font 
											to change to.

	Usage :			Call to set the font of the selected text 
					in the editor.

   ============================================================*/
{
	CharFormat	cf;
	cf.dwMask = CFM_FACE;

	lstrcpy(cf.szFaceName, font);

	m_rtf.SendMessage(EM_SETCHARFORMAT, SCF_SELECTION, (LPARAM) &cf);
}

void CRulerRichEditCtrl::SetCurrentFontSize(int size)
/* ============================================================
	Function :		CRulerRichEditCtrl::SetCurrentFontSize
	Description :	Changes the size of the selected text in 
					the editor to "size" (measured in 
					typographical points).
	Access :		Public
					
	Return :		void
	Parameters :	int size	-	New size in typographical 
									points

	Usage :			Call to change the size of the selected 
					text.

   ============================================================*/
{
	CharFormat	cf;