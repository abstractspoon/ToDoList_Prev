.hdr.idFrom = GetDlgCtrlID();
		lvd.hdr.code = LVN_ENDLABELEDIT;

		GetParent()->SendMessage(WM_NOTIFY, (WPARAM)GetDlgCtrlID(), (LPARAM)&lvd);
	}
}

void CInputListCtrl::OnCancelEdit()
{
	CString sText;

	// note: edit ctrl auto hides itself
//	GetEditControl()->ShowWindow(SW_HIDE);

	m_nCurCol = m_nEditCol;
	SetCurSel(m_nEditItem, m_nEditCol);
	m_nEditItem = m_nEditCol = -1;

	// reset redrawing
	SetRedraw(TRUE);
	Invalidate();
}

void CInputListCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CWnd* pFocus;

	// note: if we are currently editing then don't pass on
	// else the edit box loses the focus
	pFocus = GetFocus();

	if (m_editBox.m_hWnd && (pFocus == &m_editBox || m_editBox.IsWindowVisible()))
		return;

	CEnListCtrl::OnLButtonUp(nFlags, point);
}

BOOL CInputListCtrl::IsPrompt(int nItem, int nCol)
{
	return ((m_bAutoAddRows && nItem == GetItemCount() - 1 && nCol == 0) ||
			(m_bAutoAddCols && nItem == 0 && nCol == GetColumnCount() - 1));
}

COLORREF CInputListCtrl::GetItemTextColor(int nItem, int nCol, BOOL bSelected, BOOL /*bDropHighlighted*/, BOOL bWndFocus)
{
	BOOL bIsPrompt = IsPrompt(nItem, nCol);

	// setup colors
	if (bSelected && nCol == m_nCurCol && nItem == GetCurSel())
	{
		// if focused then draw item in focused colors 
		if (bWndFocus)
			return ::GetSysColor(COLOR_HIGHLIGHTTEXT);

		// else if not focused then draw selection else
		// draw in column colors as below unless we're the prompt and 
		// readonly - then draw in back color (ie hide it)
		else if (bSelected)
			return ::GetSysColor(COLOR_WINDOWTEXT);

		else if (bIsPrompt)
			return ::GetSysColor(COLOR_3DSHADOW);
