ppendAttribute(pTasks, hTask, TDL_TASKSTARTDATESTRING, NULL, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKEARLIESTDUEDATESTRING, TDL_TASKDUEDATESTRING, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKDONEDATESTRING, NULL, sOutput);
		AppendAttributeList(pTasks, hTask, TDL_TASKNUMALLOCTO, TDL_TASKALLOCTO, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKALLOCBY, NULL, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKVERSION, NULL, sOutput);
		AppendAttribute(pTasks, hTask, TDL_TASKRECURRENCE, NULL, sOutput);
		AppendAttributeList(pTasks, hTask, TDL_TASKNUMCATEGORY, TDL_TASKCATEGORY, sOutput);
		AppendAttribute(p