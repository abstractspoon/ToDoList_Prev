T);
	}

	return nLongest;
}

void CPreferencesShortcutsPage::OnTreeCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMCUSTOMDRAW* pNMCD = (NMCUSTOMDRAW*)pNMHDR;

	if (pNMCD->dwDrawStage == CDDS_PREPAINT)
		*pResult |= CDRF_NOTIFYITEMDRAW | CDRF_NOTIFYPOSTPAINT;	
		
	else if (pNMCD->dwDrawStage == CDDS_ITEMPREPAINT)
	{
		NMTVCUSTOMDRAW* pTVCD = (NMTVCUSTOMDRAW*)pNMCD;

		// set colors
		HTREEITEM hti = (HTREEITEM)pTVCD->nmcd.dwItemSpec;

		if (m_tcCommands.ItemHasChildren(hti)) // popup menu
		{
			CRect rItem, rText;
			m_tcCommands.GetItemRect(hti, rItem, FALSE);
			m_tcCommands.GetItemRect(hti, rText, TRUE);
			rItem.left = rText.left - 2;

			CDC* pDC = CDC::FromHandle(pNMCD->hdc);
			pDC->FillSolidRect(rItem, GetSysColor(COLOR_3DSHADOW));
			pDC->SetBkMode(TRANSPARENT);

			pTVCD->clrTextBk = GetSysColor(COLOR_3DSHADOW);
			pTVCD->clrText = 0;

			*pResult |= CDRF_DODEFAULT;
		}
		else if (pNMCD->uItemState & CDIS_SELECTED)
		{
			pTVCD->clrTextBk = GetSysColor(COLOR_HIGHLIGHT);
			pTVCD->clrText = GetSysColor(COLOR_HIGHLIGHTTEXT);
		}
		else // test for reserved shortcut
		{
			DWORD dwShortcut = 0;
			m_mapID2Shortcut.Lookup(pTVCD->nmcd.lItemlParam, dwShortcut);

			if (CToDoCtrl::IsReservedShortcut(dwShortcut))
			{
				pTVCD->clrText = 255;
				*pResult |= CDRF_DODEFAULT;
			}
		}
	}
	else if (pNMCD->dwDrawStage == CDDS_ITEMPOSTPAINT)
	{
		CDC* pDC = CDC::FromHandle(pNMCD->hdc);
		NMTVCUSTOMDRAW* pTVCD = (NMTVCUSTOMDRAW*)pNMCD;

		CRect rItem(pNMCD->rc);
		rItem.top = rItem.bottom - 1;

		// if the bottom of the text coincides with the bottom of the 
		// item and we have the then take care not to draw over the focus rect
		if (pNMCD->uItemState & CDIS_FOCUS)
		{
			HTREEITEM hti = (HTREEITEM)pTVCD->nmcd.dwItemSpec;

			CRect rText;
			m_tcCommands.GetItemRect(hti, rText, TRUE);

			if (rText.bottom == rItem.bottom)
			{
				pDC->FillSolidRect(rItem.left, rItem.bottom - 1, rText.left - rItem.left, 1, OTC_GRIDCOLOR);
