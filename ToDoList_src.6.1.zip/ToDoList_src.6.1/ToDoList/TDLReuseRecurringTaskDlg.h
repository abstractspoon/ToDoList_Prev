r.bottom);
		pDC->IntersectClipRect(rClient);
	}
	
	bListFocused = (GetFocus() == this);
	bSelected = (nItem == GetCurSel());
	bSelAlways = ((uStyle & LVS_SHOWSELALWAYS) == LVS_SHOWSELALWAYS);
	bSelected = bSelected && (bListFocused || bSelAlways);
	bItemFocused = bListFocused && bSelected;

	// images 
	// DO NOT SUPPORT INDENTATION
	pImageList = GetImageList(LVSIL_SMALL);

	if (pImageList)
	{
		nImage = GetImageIndex(nItem, 0); 
		ImageList_GetIconSize(pImageList->m_hImageList, (int*)&sizeImage.cx, (int*)&sizeImage.cy);
	}

	// state
	pStateList = GetImageList(LVSIL_STATE);

	if (pStateList)
		ImageList_GetIconSize(pStateList->m_hImageList, (int*)&sizeState.cx, (int*)&sizeState.cy);

	if (lpDrawItemStruct->itemAction & (ODA_DRAWENTIRE | ODA_SELECT))
	{
		lvc.mask = LVCF_WIDTH | LVCF_FMT;
		nCol = 0;

		// draw state image if required
		bRes = GetColumn(nCol, &lvc);

		if (pStateList && bRes)
		{
			nState = (GetItemState(nItem, LVIS_STATEIMAGEMASK) & LVIS_STATEIMAGEMASK);
			nImage = nState >> 12;
			pStateList->Draw(pDC, nImage, CPoint(rText.left + 1, rText.top), ILD_TRANSPARENT); 

			if (lvc.cx > sizeState.cx)
				pStateList->Draw(pDC, nState, CPoint(rText.left + 1, rText.top), ILD_TRANSPARENT); 

			nImageWidth = sizeState.cx + 2; // 1 pixel border either side
		}

		// draw item image
		if (pImageList && bRes)
		{
			if (bSelected && (nCol == m_nCurCol/* && nItem 