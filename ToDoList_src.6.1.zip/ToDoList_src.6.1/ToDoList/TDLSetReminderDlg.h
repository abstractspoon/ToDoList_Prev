ID = -1;
							}
							plbTasks->SetCurSel(m_nSelectedTaskID);

							SendSelectDateMessageToParent(TRUE);
						}
					}

					if (m_nSelectedTaskID == -1)
					{
						//move to cell above
						if (nRow == 0)
						{
							CCalendarUtils::SubtractDay(dtNew, 7);
							if (!CCalendarUtils::IsDateValid(dtNew))
							{
								ASSERT(FALSE);
								return FALSE;
							}

							m_nVscrollPos--;
						}
						else
						{
							nRow--;	
						}
					}
				}
				else if (pMsg->wParam == VK_DOWN)
				{
					//select next task
					if (m_nSelectedTaskID != -1)
					{
						CBigCalendarTask* plbTasks = GetTaskListboxFromDate(m_dateSelected);
						if (plbTasks != NULL)
						{
							m_nSelectedTaskID++;
							if (m_nSelectedTaskID >= plbTasks->GetCount())
							{
								m_nSelectedTaskID = -1;
							}
							plbTasks->SetCurSel(m_nSelectedTaskID);

							SendSelectDateMessageToParent(TRUE);
						}
					}

					if (m_nSelectedTaskID == -1)
					{
						LeaveCell();

						//move to cell below
						if (nRow == nNumWeeks-1)
						{
							CCalendarUtils::AddDay(dtNew, 7);
							if (!CCalendarUtils::IsDateValid(dtNew))
							{
								ASSERT(FALSE);
								return FALSE;
							}

							m_nVscrollPos++;
						}
						else
						{
							nRow++;
						}
					}
				}
				else if (pMsg->wParam == VK_LEFT)
				{
					LeaveCell();

					//move to previous cell
					if (nCol > 0)
					{
						nCol--;
					}
					else
					{
						nCol = nNumColumns-1;
						if (nRow == 0)
						{
							CCalendarUtils::SubtractDay(dtNew, 7);
							if (!CCalendarUtils::IsDateValid(dtNew))
							{
								ASSERT(FALSE);
								return FALSE;
							}

							m_nVscrollPos--;
						}
						else
						{
					