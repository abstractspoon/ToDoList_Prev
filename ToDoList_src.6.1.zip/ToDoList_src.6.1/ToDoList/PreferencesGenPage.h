TF.ReleaseBuffer(nLen);
	return sRTF;
}

int CRulerRichEditCtrl::GetRTFLength()
{
	int nLen = 0;
	EDITSTREAM	es;
	es.dwCookie = (DWORD)&nLen;
	es.pfnCallback = StreamOutLen;
	m_rtf.StreamOut(SF_RTF, es);

	return nLen;
}

/* ============================================================
	Function :		CRulerRichEditCtrl::SetRTF
	Description :	Set the contents of the embedded RTF-
					control from rtf.
	Access :		Public
					
	Return :		void
	Parameters :	const CString& rtf	-	The rtf-contents to 
											set.
					
	Usage :			Call this function to set the RTF-contents 
					of the control.

   ============================================================*/
void CRulerRichEditCtrl::SetRTF(const CString& rtf)
{
	CString sRTF = rtf.IsEmpty() ? DEFAULTRTF : rtf;

	STREAMINCOOKIE cookie(sRTF);
	EDITSTREAM es = { (DWORD)&cookie, 0, StreamIn };

	m_rtf.StreamIn(SF_RTF, es);

	// reset the formatting if the new content is empty else
	// the previous formatting hangs around
	if (rtf.IsEmpty())
	{
		CHoldRedraw hr(m_rtf);
		CharFormat cf(m_cfDefault);

		m_rtf.SetSel(0, -1);
		m_rtf.SendMessage(EM_SETCHARFORMAT, SCF_SELECTION, (LPARAM) &cf);
		m_rtf.SetSel(-1, 0);
	}
	UpdateEditRect();
}

BOOL CRulerRichEditCtrl::Save(CString& filename)
/* ============================================================
	Function :		CRulerRichEditCtrl::Save
	Description :	Saves the contents to the file filename. 
					If filename is empty, a file dialog will 
					be displayed and the selected name will be 
					returned in the "CString".
	Access :		Public
					
	Return :		BOOL				-	"TRUE" if the file 
											was saved.
	Parameters :	CString& filename	-	The file name to save 
											to. Can be empty.
					
	Usage :			Call to save the contents of the embedded 
					RTF-control do a file.

   ============================================================*/
{

	BOOL result = TRUE;

	CString* str = new CString;

	EDITSTREAM	es;
	es.dwCookie = (DWORD) str;
	es.pfnCallback = StreamOut;
	m_rtf.StreamOut(SF_RTF, es);

	FileMisc::SaveFile(filename, *str, str->GetLength());

/*
	CTextFileWrite myfile(filename);
	ASSERT(myfile.IsOpen());
	myfile.Write(*str);
*/

	delete str;
	return result;

}

BOOL CRulerRichEditCtrl::Load(CString& filename)
/* ============================================================
	Function :		CRulerRichEditCtrl::Load
	Description :	Loads the embedded RTF-control with the 
					contents from the file filename. 
					If filename is empty, a file dialog will 
					be displayed and the selected name will be 
					returned in the "CString".
	Access :		Public
					
	Return :		BOOL				-	"TRUE" if the file 
											was loaded.
	Parameters :	CString& filename	-	File name to load 
											from. Can be empty.
					
	Usage :			Call to load an RTF-file to the control.

   ============================================================*/
{

	BOOL result = TRUE;

	CString* str = new CString;
	FileMisc::LoadFile(filename, *str);
/*
	CTextFileRead myfile(filename);
	ASSERT(myfile.IsOpen());
	myfile.Read(*str);
*/

	if (result)
	{
		EDITSTREAM	es;
		es.dwCookie = (DWORD) str;
		es.pfnCallback = StreamIn;
		m_rtf.StreamIn(SF_RTF, es);
	}

	delete str;
	return result;

}

void CRulerRichEditC