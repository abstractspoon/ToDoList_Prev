// ClipboardBackup.cpp: implementation of the CClipboardBackup class.
//
// Copyright 2006 (c) RegExLab.com
//
// Author: ʷ��ΰ (sswater shi)
//
// 2006/05/20 02:03:04
//

#include "stdafx.h"
#include "ClipboardBackup.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CClipboardBackup::CClipboardBackup()
{
	m_bFilled = FALSE;
}

CClipboardBackup::~CClipboardBackup()
{
	if( m_bFilled )
	{
		POSITION pos = m_lstData.GetHeadPosition();
		while( pos != NULL )
		{
			ClipboardData & data = m_lstData.GetNext( pos );

			switch( data.m_nFormat )
			{
			case CF_ENHMETAFILE:
			case CF_DSPENHMETAFILE:
				::DeleteMetaFile((HMETAFILE)data.m_hData);
				break;

			default:
				::GlobalFree( data.m_hData );
			}
		}

		m_lstData.RemoveAll();
	}
}

BOOL CClipboardBackup::Backup()
{
	if( m_bFilled )
		return FALSE;

	if( ! ::OpenClipboard(NULL) )
		return FALSE;

	UINT format = 0;
	while( (format = ::EnumClipboardFormats(format)) != 0 )
	{
		ClipboardData data;
		data.m_nFormat = format;

		// skip some formats
		if( format == CF_BITMAP || format == CF_METAFILEPICT || format == CF_PALETTE || format == CF_OWNERDISPLAY ||
			format == CF_DSPMETAFILEPICT || format == CF_DSPBITMAP ||
			( format >= CF_PRIVATEFIRST && format <= CF_PRIVATELAST ) )
		{
			continue;
		}

		// get format name
		if( format <= 14 )
			data.m_szFormatName[0] = 0;
		else if( GetClipboardFormatName(format, data.m_szFormatName, 100) == 0 )
			data.m_szFormatName[0] = 0;

		// get handle
		HANDLE hMem = ::GetClipboardData( format );
		if( hMem == NULL )
			continue;

		// copy handle
		switch( format )
		{
		case CF_ENHMETAFILE:
		case CF_DSPENHMETAFILE:
			data.m_hData = ::CopyMetaFile((HMETAFILE)hMem, NULL);
			break;

		default:
			{
				int    size = ::GlobalSize(hMem);
				LPVOID pMem = ::GlobalLock( hMem );

				data.m_hData   = ::GlobalAlloc( GMEM_MOVEABLE | GMEM_DDESHARE, size );
				LPVOID pNewMem = ::GlobalLock( data.m_hData );

				memcpy(pNewMem, pMem, size);

				::GlobalUnlock(hMem);
				::GlobalUnlock(data.m_hData);
			}
		}

		m_lstData.AddTail(data);
	}

	::CloseClipboard();

	m_bFilled = TRUE;

	return TRUE;
}

BOOL CClipboardBackup::Restore()
{
	if( ! m_bFilled )
		return FALSE;

	if( ! ::OpenClipboard(NULL) )
		return FALSE;

	::EmptyClipboard();

	POSITION pos = m_lstData.GetHeadPosition();
	while( pos != NULL )
	{
		ClipboardData & data = m_lstData.GetNext( pos );

		UINT format = data.m_nFormat;

		if( data.m_szFormatName[0] != 0 )
		{
			UINT u = RegisterClipboardFormat( data.m_szFormatName );
			if( u > 0 ) format = u;
		}

		::SetClipboardData( format, data.m_hData );
	}

	::CloseClipboard();

	m_lstData.RemoveAll();
	m_bFilled = FALSE;

	return TRUE;
}
                                                                                                                                                                                                ,164,65,13, IDC_DONETIME },
	{ WC_STATIC,	IDS_TDC_FIELD_RECURRENCE, SS_CENTERIMAGE, 0, 119,184,37,8, IDC_RECURRENCELABEL },
	{ WC_EDIT,		0, ES_AUTOHSCROLL | ES_LEFT | WS_TABSTOP, 0, 159,182,65,13, IDC_RECURRENCE },
	{ WC_STATIC,	IDS_TDC_FIELD_COLOUR, SS_CENTERIMAGE, 0, 1,131,38,8, IDC_COLOURLABEL },
	{ WC_BUTTON,	0, WS_TABSTOP, 0, 1,131,38,8, IDC_COLOUR },
	{ WC_STATIC,	IDS_TDC_FIELD_ALLOCTO, SS_CENTERIMAGE, 0, 1,131,38,8, IDC_ALLOCTOLABEL },
	{ WC_COMBOBOX,	0, CBS_SORT | CBS_DROPDOWN | WS_VSCROLL | CBS_AUTOHSCROLL | WS_TABSTOP | CBS_OWNERDRAWFIXED | CBS_HASSTRINGS, 0, 45,128,65,200, IDC_ALLOCTO },
	{ WC_STATIC,	IDS_TDC_FIELD_ALLOCBY, SS_CENTERIMAGE, 0, 1,131,38,8, IDC_ALLOCBYLABEL },
	{ WC_COMBOBOX,	0, CBS_SORT | CBS_DROPDOWN | WS_VSCROLL | CBS_AUTOHSCROLL | WS_TABSTOP, 0, 45,128,65,200, IDC_ALLOCBY },
	{ WC_STATIC,	IDS_TDC_FIELD_STATUS, SS_CENTERIMAGE, 0, 1,131,38,8, IDC_STATUSLABEL },
	{ WC_COMBOBOX,	0, CBS_SORT | CBS_DROPDOWN | WS_VSCROLL | CBS_AUTOHSCROLL | WS_TABSTOP, 0, 45,128,65,200, IDC_STA// ClipboardBackup.h: interface for the CClipboardBackup class.
//
// Copyright 2006 (c) RegExLab.com
//
// Author: ʷ��ΰ (sswater shi)
//
// 2006/05/17 01:21:10
//

#if !defined(AFX_CLIPBOARDBACKUP_H__B2363083_E96C_4F7E_8D2D_39A0C3A7046C__INCLUDED_)
#define AFX_CLIPBOARDBACKUP_H__B2363083_E96C_4F7E_8D2D_39A0C3A7046C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxTempl.h>

/*
#define CF_TEXT             1
#define CF_BITMAP           2
#define CF_METAFILEPICT     3
#define CF_SYLK             4
#define CF_DIF              5
#define CF_TIFF             6
#define CF_OEMTEXT          7
#define CF_DIB              8
#define CF_PALETTE          9
#define CF_PENDATA          10
#define CF_RIFF             11
#define CF_WAVE             12
#define CF_UNICODETEXT      13
#define CF_ENHMETAFILE      14

#if(WINVER >= 0x0400)
#define CF_HDROP            15
#define CF_LOCALE           16
#define CF_MAX              17
#endif // WINVER >= 0x0400

#define CF_OWNERDISPLAY     0x0080
#define CF_DSPTEXT          0x0081
#define CF_DSPBITMAP        0x0082
#define CF_DSPMETAFILEPICT  0x0083
#define CF_DSPENHMETAFILE   0x008E
*/

class CClipboardBackup
{
public:
	BOOL Backup ();
	BOOL Restore();

public:
	CClipboardBackup();
	~CClipboardBackup();

public:
	BOOL m_bFilled;

private:
	struct ClipboardData
	{
		UINT   m_nFormat;
		TCHAR  m_szFormatName[100];
		HANDLE m_hData;
	};

	CList <ClipboardData, ClipboardData&> m_lstData;
};

#endif // !defined(AFX_CLIPBOARDBACKUP_H__B2363083_E96C_4F7E_8D2D_39A0C3A7046C__INCLUDED_)
                                                                                                                                                                                                                                                                                                                                                                                                                            MN_ID, IDS_TDLBC_ID, TDC_SORTBYID, DT_LEFT, TRUE, NULL, FALSE, TRUE },								
	{ TDCC_PRIORITY, IDS_TDC_COLUMN_PRIORITY, IDS_TDLBC_PRIORITY,	TDC_SORTBYPRIORITY, DT_CENTER, TRUE, NULL, FALSE, FALSE },
	{ TDCC_RISK, 0x4d, IDS_TDLBC_RISK, TDC_SORTBYRISK, DT_CENTER, TRUE, "Wingdings", TRUE, TRUE },
	{ TDCC_PERCENT, IDS_TDC_COLUMN_PERCENT, IDS_TDLBC_PERCENT, TDC_SORTBYPERCENT, DT_CENTER, TRUE, NULL, FALSE, FALSE },
	{ TDCC_TIMEEST, IDS_TDC_COLUMN_TIMEEST, IDS_TDLBC_TIMEEST, TDC_SORTBYTIMEEST, DT_RIGHT, TRUE, NULL, FALSE, TRUE },
	{ TDCC_TIMESPENT, IDS_TDC_COLUMN_TIMESPENT, IDS_TDLBC_TIMESPENT, TDC_SORTBYTIMESPENT, DT_RIGHT, TRUE, NULL, FALSE, TRUE },
	{ TDCC_TRACKTIME, 0xb9, IDS_TDLBC_TRACKTIME, TDC_UNSORTED, DT_CENTER, FALSE, "Wingdings", TRUE, TRUE },
	{ TDCC_CREATIONDATE, IDS_TDC_COLUMN_CREATEDATE, IDS_TDLBC_CREATEDATE, TDC_SORTBYCREATIONDATE, DT_RIGHT, TRUE, NULL, FALSE, TRUE },
	{ TDCC_CREATEDBY, IDS_TDC_COLUMN_CREATEDBY, IDS_TDLBC_CREATEDBY, TDC_SORTBYCREATEDBY, DT_LEFT, TRUE, NULL, FALSE, TRUE },
	{ TDCC_LASTMOD, IDS_TDC_COLUMN_MODIFYDATE, IDS_TDLBC_MODIFYDATE, TDC_SORTBYLASTMOD, DT_LEFT, TRUE, NULL, FALSE, TRUE },
	{ TDCC_RECENTEDIT, IDS_TDC_COLUMN_RECENTEDIT, IDS_TDLBC_RECENTEDIT, TDC_SORTBYRECENTEDIT, DT_CENTER, TRUE, NULL, FALSE, TRUE },
	{ TDCC_STARTDATE, IDS_TDC_COLUMN_STARTDATE, IDS_TDLBC_STARTDATE, TDC_SORTBYSTARTDATE, DT_LEFT, TRUE, NULL, FALSE, TRUE },
	{ TDCC_DUEDATE, IDS_TDC_COLUMN_DUEDATE, IDS_TDLBC_DUEDATE, TDC_SORTBYDUEDATE, DT_LEFT, TRUE, NULL, FALSE, TRUE },
	{ TDCC_REMAINING, 0x36, IDS_TDLBC_REMAINING, TDC_SORTBYREMAINING, DT_LEFT, TRUE, "Wingdings", TRUE, TRUE },
	{ TDCC_DONEDATE, IDS_TDC_COLUMN_DONEDATE, IDS_TDLBC_DONEDATE, TDC_SORTBYDONEDATE, DT_LEFT, TRUE, NULL, FALSE, TRUE },
	{ TDCC_RECURRENCE, IDS_TDC_COLUMN_RECURRENCE, IDS_TDLBC_RECURRENCE, TDC_SORTBYRECURRENCE, DT_LEFT, TRUE, NULL, FALSE, TRUE },
	{ TDCC_ALLOCTO, IDS_TDC_COLUMN_ALLOCTO, IDS_TDLBC_ALLOCTO, TDC_SORTBYALLOCTO, DT_LEFT, TRUE, NULL, FALSE, TRUE },
	{ TDCC_ALLOCBY, IDS_TDC_COLUMN_ALLOCBY, IDS_TDLBC_ALLOCBY<?xml version="1.0" encoding="windows-1252" ?>
<TODOLIST>
<TASK TITLE="Project 1" ID="4" PERCENTDONE="6" STARTDATE="40644.00000000" PRIORITY="5" COMMENTS="">
<TASK TITLE="Task 1" ID="9" PERCENTDONE="30" STARTDATE="40651.00000000" DUEDATE="40653.00000000" TIMEESTIMATE="3.00000000" TIMEESTUNITS="D" PRIORITY="5" COMMENTS=""/>
<TASK TITLE="Task 2" ID="2" PERCENTDONE="5" STARTDATE="40654.00000000" DUEDATE="40657.00000000" TIMEESTIMATE="4.00000000" TIMEESTUNITS="D" PRIORITY="5" COMMENTS="" NUMDEPENDS="1" DEPENDS="9"/>
<TASK TITLE="Task 3" ID="3" PERCENTDONE="0" STARTDATE="40660.00000000" DUEDATE="40664.00000000" TIMEESTIMATE="5.00000000" TIMEESTUNITS="D" PRIORITY="5" COMMENTS="" NUMDEPENDS="1" DEPENDS="2"/>
<TASK TITLE="New task_4" ID="5" PERCENTDONE="0" STARTDATE="40644.00000000" DUEDATE="40644.00000000" TIMEESTIMATE="1.00000000" TIMEESTUNITS="D" PRIORITY="5" COMMENTS=""/>
<TASK TITLE="New task_5" ID="6" PERCENTDONE="0" STARTDATE="40644.00000000" DUEDATE="40644.00000000" TIMEESTIMATE="1.00000000" TIMEESTUNITS="D" PRIORITY="5" COMMENTS=""/>
<TASK TITLE="New task_6" ID="7" PERCENTDONE="0" STARTDATE="40644.00000000" DUEDATE="40644.00000000" TIMEESTIMATE="1.00000000" TIMEESTUNITS="D" PRIORITY="5" COMMENTS=""/>
<TASK TITLE="New task_7" ID="8" PERCENTDONE="0" STARTDATE="40644.00000000" DUEDATE="40644.00000000" TIMEESTIMATE="1.00000000" TIMEESTUNITS="D" PRIORITY="5" COMMENTS=""/>
</TASK>
</TODOLIST>
                                                                                                                 K,			IDC_RISKLABEL,		TDCC_RISK },
	{ IDC_PERCENT,		IDC_PERCENTLABEL,	TDCC_PERCENT },
	{ IDC_TIMEEST,		IDC_TIMEESTLABEL,	TDCC_TIMEEST },
	{ IDC_TIMESPENT,	IDC_TIMESPENTLABEL,	TDCC_TIMESPENT },
	{ IDC_STARTDATE,	IDC_STARTLABEL,		TDCC_STARTDATE },
	{ IDC_STARTTIME,	IDC_STARTTIMELABEL,	TDCC_STARTDATE },
	{ IDC_DUEDATE,		IDC_DUELABEL,		TDCC_DUEDATE },
	{ IDC_DUETIME,		IDC_DUETIMELABEL,	TDCC_DUEDATE },
	{ IDC_DONEDATE,		IDC_DONELABEL,		TDCC_DONEDATE },
	{ IDC_DONETIME,		IDC_DONETIMELABEL,	TDCC_DONEDATE },
	{ IDC_RECURRENCE,	IDC_RECURRENCELABEL,TDCC_RECURRENCE },
	{ IDC_COLOUR,		IDC_COLOURLABEL,	(TDC_COLUMN)-1 },
	{ IDC_ALLOCTO,		IDC_ALLOCTOLABEL,	TDCC_ALLOCTO },
	{ IDC_ALLOCBY,		IDC_ALLOCBYLABEL,	TDCC_ALLOCBY },
	{ IDC_STATUS,		IDC_STATUSLABEL,	TDCC_STATUS },
	{ IDC_CATEGORY,		IDC_CATEGORYLABEL,	TDCC_CATEGORY },
	{ IDC_EXTERNALID,	IDC_EXTERNALIDLABEL,TDCC_EXTERNALID },
	{ IDC_COST,			IDC_COSTLABEL,		TDCC_COST },
	{ IDC_DEPENDS,		IDC_DEPENDSLABEL,	TDCC_DEPENDENCY },
	{ IDC_VERSION,		IDC_VERSIONLABEL,	TDCC_VERSION },
	{ IDC_FILEPATH,		IDC_FILEPATHLABEL,	TDCC_FILEREF },
};

static int NUM_CTRLITEMS = sizeof(CTRLITEMS) / sizeof(CTRLITEM);

static UINT FILTER_OPTIONS[][2] = 
{ 
	{ IDS_FILTER_ANYCATS,		FT_ANYCATEGORY },
	{ IDS_FILTER_ANYPEOPLE,		FT_ANYALLOCTO },
	{ IDS_FILTER_HIDEPARENTS,	FT_HIDEPARENTS },
	{ IDS_FILTER_HIDEOVERDUE,	FT_HIDEOVERDUE },
	{ IDS_FILTER_HIDEDONE,		FT_HIDEDONE },
	{ IDS_FILTER_HIDECOLLAPSED,	FT_HIDECOLLAPSED }
};

static int NUM_FILTEROPT = sizeof(FILTER_OPTIONS) / (2 * sizeof(UINT));

static UINT TASK_FILTERS[][2] = 
{ 
	{ IDS_FILTER_ALL,				FT_ALL },
	{ IDS_FILTER_NOTDONE,			FT_NOTDONE },
	{ IDS_FILTER_DONE,				FT_DONE }, 
	{ IDS_FILTER_DUETODAY,			FT_DUETODAY },
	{ IDS_FILTER_DUETOMORROW,		FT_DUETOMORROW },
	{ IDS_FILTER_DUEENDTHISWEEK,	FT_DUEENDTHISWEEK }, 
	{ IDS_FILTER_DUEENDNEXTWEEK,	FT_DUEENDNEXTWEEK }, 
	{ IDS_FILTER_DUEENDTHISMONTH,	FT_DUEENDTHISMONTH },
	{ IDS_FILTER_DUEENDNEXTMONTH,	FT_DUEENDNEXTMONTH },
	{ IDS_FILTER_DUEENDTHISYEAR,	FT_DUEENDTHISYEAR },
	{ IDS_FILTER_DUEENDNEXTYEAR,	FT_DUEENDNEXTYEAR },
	{ IDS_FILTER_DUENEXTSEVENDAYS,	FT_DUENEXTSEVENDAYS },
	{ IDS_FILTER_STARTTODAY,		FT_STARTTODAY },
	{ IDS_FILTER_STARTENDTHISWEEK,	FT_STARTENDTHISWEEK }, 
	{ IDS_FILTER_STARTNEXTSEVENDAYS,FT_STARTNEXTSEVENDAYS }, 
// 	{ IDS_FILTER_ACTIVE,			FT_ACTIVE },
// 	{ IDS_FILTER_NOTSTARTED,		FT_NOTSTARTED },
	{ IDS_FILTER_FLAGGED,			FT_FLAGGED } 
};

static int NUM_TASKFILTER = sizeof(TASK_FILTERS) / (2 * sizeof(UINT));


#endif // AFX_// EditWebLinkDlg.cpp : implementation file
//

#include 