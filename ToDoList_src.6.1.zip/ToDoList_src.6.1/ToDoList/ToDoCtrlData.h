;
	return result;
}

long _NotesModule::GetClass()
{
	long result;
	InvokeHelper(0xf00a, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

LPDISPATCH _NotesModule::GetSession()
{
	LPDISPATCH result;
	InvokeHelper(0xf00b, DISPATCH_PROPERTYGET, VT_DISPATCH, (void*)&result, NULL);
	return result;
}

LPDISPATCH _NotesModule::GetParent()
{
	LPDISPATCH result;
	InvokeHelper(0xf001, DISPATCH_PROPERTYGET, VT_DISPATCH, (void*)&result, NULL);
	return result;
}

long _NotesModule::GetNavigationModuleType()
{
	long result;
	InvokeHelper(0xfbb9, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

CString _NotesModule::GetName()
{
	CString result;
	InvokeHelper(0x2102, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, NULL);
	return result;
}

long _NotesModule::GetPosition()
{
	long result;
	InvokeHelper(0xfbba, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

void _NotesModule::SetPosition(long nNewValue)
{
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0xfbba, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 nNewValue);
}

BOOL _NotesModule::GetVisible()
{
	BOOL result;
	InvokeHelper(0xfbbb, DISPATCH_PROPERTYGET, VT_BOOL, (void*)&result, NULL);
	return result;
}

void _NotesModule::SetVisible(BOOL bNewValue)
{
	static BYTE parms[] =
		VTS_BOOL;
	InvokeHelper(0xfbbb, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 bNewValue);
}

LPDISPATCH _NotesModule::GetNavigationGroups()
{
	LPDISPATCH result;
	InvokeHelper(0xfbbc, DISPATCH_PROPERTYGET, VT_DISPATCH, (void*)&result, NULL);
	return result;
}


/////////////////////////////////////////////////////////////////////////////
// NavigationPaneEvents_12 properties

/////////////////////////////////////////////////////////////////////////////
// NavigationPaneEvents_12 operations

void NavigationPaneEvents_12::ModuleSwitch(LPDISPATCH CurrentModule)
{
	static BYTE parms[] =
		VTS_DISPATCH;
	InvokeHelper(0xfbc9, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 CurrentModule);
}


/////////////////////////////////////////////////////////////////////////////
// NavigationGroupsEvents_12 properties

/////////////////////////////////////////////////////////////////////////////
// NavigationGroupsEvents_12 operations

void NavigationGroupsEvents_12::SelectedChange(LPDISPATCH NavigationFolder)
{
	static BYTE parms[] =
		VTS_DISPATCH;
	InvokeHelper(0xfbca, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 NavigationFolder);
}

void NavigationGroupsEvents_12::NavigationFolderAdd(LPDISPATCH NavigationFolder)
{
	static BYTE parms[] =
		VTS_DISPATCH;
	InvokeHelper(0xfbcb, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 NavigationFolder);
}

void NavigationGroupsEvents_12::NavigationFolderRemove()
{
	InvokeHelper(0xfbcc, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// _BusinessCardView properties

/////////////////////////////////////////////////////////////////////////////
// _BusinessCardView operations

LPDISPATCH _BusinessCardView::GetApplication()
{
	LPDISPATCH result;
	InvokeHelper(0xf000, DISPATCH_PROPERTYGET, VT_DISPATCH, (void*)&result, NULL);
	return result;
}

long _BusinessCardView::GetClass()
{
	long result;
	InvokeHelper(0xf00a, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

LPDISPATCH _BusinessCardView::GetSession()
{
	LPDISPATCH result;
	InvokeHelper(0xf00b, DISPATCH_PROPERTYGET, VT_DISPATCH, (void*)&result, NULL);
	return result;
}

LPDISPATCH _BusinessCardView::GetParent()
{
	LPDISPATCH result;
	InvokeHelper(0xf001, DISPATCH_PROPERTYGET, VT_DISPATCH, (void*)&result, NULL);
	return result;
}

void _BusinessCardView::Apply()
{
	InvokeHelper(0x197, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
}

LPDISPATCH _BusinessCardView::Copy(LPCTSTR Name, long SaveOption)
{
	LPDISPATCH result;
	static BYTE parms[] =
		VTS_BSTR VTS_I4;
	InvokeHelper(0xf032, DISPATCH_METHOD, VT_DISPATCH, (void*)&result, parms,
		Name, SaveOption);
	return result;
}

void _BusinessCardView::Delete()
{
	InvokeHelper(0xf04a, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
}

void _BusinessCardView::Reset()
{
	InvokeHelper(0xfa44, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
}

void _BusinessCardView::Save()
{
	InvokeHelper(0xf048, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
}

CString _BusinessCardView::GetLanguage()
{
	CString result;
	InvokeHelper(0xfa41, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, NULL);
	return result;
}

void _BusinessCardView::SetLanguage(LPCTSTR lpszNewValue)
{
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0xfa41, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 lpszNewValue);
}

BOOL _BusinessCardView::GetLockUserChanges()
{
	BOOL result;
	InvokeHelper(0xfa40, DISPATCH_PROPERTYGET, VT_BOOL, (void*)&result, NULL);
	return result;
}

void _BusinessCardView::SetLockUserChanges(BOOL bNewValue)
{
	static BYTE parms[] =
		VTS_BOOL;
	InvokeHelper(0xfa40, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 bNewValue);
}

CString _BusinessCardView::GetName()
{
	CString result;
	InvokeHelper(0x0, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, NULL);
	return result;
}

void _BusinessCardView::SetName(LPCTSTR lpszNewValue)
{
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0x0, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 lpszNewValue);
}

long _BusinessCardView::GetSaveOption()
{
	long result;
	InvokeHelper(0xfa3f, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

BOOL _BusinessCardView::GetStandard()
{
	BOOL result;
	InvokeHelper(0xfa3e, DISPATCH_PROPERTYGET, VT_BOOL, (void*)&result, NULL);
	return result;
}

long _BusinessCardView::GetViewType()
{
	long result;
	InvokeHelper(0x194, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

CString _BusinessCardView::GetXml()
{
	CString result;
	InvokeHelper(0xfa3c, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, NULL);
	return result;
}

void _BusinessCardView::SetXml(LPCTSTR lpszNewValue)
{
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0xfa3c, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 lpszNewValue);
}

void _BusinessCardView::GoToDate(DATE Date)
{
	static BYTE parms[] =
		VTS_DATE;
	InvokeHelper(0xfa36, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 Date);
}

CString _BusinessCardView::GetFilter()
{
	CString result;
	InvokeHelper(0x199, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, NULL);
	return result;
}

void _BusinessCardView::SetFilter(LPCTSTR lpszNewValue)
{
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0x199, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 lpszNewValue);
}

LPDISPATCH _BusinessCardView::GetHeadingsFont()
{
	LPDISPATCH result;
	InvokeHelper(0xfb79, DISPATCH_PROPERTYGET, VT_DISPATCH, (void*)&result, NULL);
	return result;
}

LPDISPATCH _BusinessCardView::GetSortFields()
{
	LPDISPATCH result;
	InvokeHelper(0xfb5a, DISPATCH_PROPERTYGET, VT_DISPATCH, (void*)&result, NULL);
	return result;
}

long _BusinessCardView::GetCardSize()
{
	long result;
	InvokeHelper(0xfbda, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

void _BusinessCardView::SetCardSize(long nNewValue)
{
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0xfbda, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 nNewValue);
}


/////////////////////////////////////////////////////////////////////////////
// _FormRegionStartup properties

/////////////////////////////////////////////////////////////////////////////
// _FormRegionStartup operations

VARIANT _FormRegionStartup::GetFormRegionStorage(LPCTSTR FormRegionName, LPDISPATCH Item, long LCID, long FormRegionMode, long FormRegionSize)
{
	VARIANT result;
	static BYTE parms[] =
		VTS_BSTR VTS_DISPATCH VTS_I4 VTS_I4 VTS_I4;
	InvokeHelper(0xfb36, DISPATCH_METHOD, VT_VARIANT, (void*)&result, parms,
		FormRegionName, Item, LCID, FormRegionMode, FormRegionSize);
	return result;
}

void _FormRegionStartup::BeforeFormRegionShow(LPDISPATCH FormRegion)
{
	static BYTE parms[] =
		VTS_DISPATCH;
	InvokeHelper(0xfb3d, DISPATCH_METHOD, VT_EMPTY, NULL, parms,
		 FormRegion);
}

VARIANT _FormRegionStartup::GetFormRegionManifest(LPCTSTR FormRegionName, long LCID)
{
	VARIANT result;
	static BYTE parms[] =
		VTS_BSTR VTS_I4;
	InvokeHelper(0xfc33, DISPATCH_METHOD, VT_VARIANT, (void*)&result, parms,
		FormRegionName, LCID);
	return result;
}

VARIANT _FormRegionStartup::GetFormRegionIcon(LPCTSTR FormRegionName, long LCID, long Icon)
{
	VARIANT result;
	static BYTE parms[] =
		VTS_BSTR VTS_I4 VTS_I4;
	InvokeHelper(0xfc34, DISPATCH_METHOD, VT_VARIANT, (void*)&result, parms,
		FormRegionName, LCID, Icon);
	return result;
}
                                                                                                                                                                                                                                                                                                                               ULT& result) const;
	BOOL TaskMatches(const CString& sText, const SEARCHPARAM& sp, SEARCHRESULT& result) const;
	BOOL TaskMatches(double dValue, const SEARCHPARAM& sp, SEARCHRESULT& result) const;
	BOOL TaskMatches(int nValue, const SEARCHPARAM& sp, SEARCHRESULT& result) const;
	BOOL TaskMatches(const CStringArray& aItems, const SEARCHPARAM& sp, SEARCHRESULT& result) const;

	void SumPercentDone(const TODOITEM* pTDI, const TODOSTRUCTURE* pTDS,
								   double& dTotalPercent, double& dTotalWeighting) const;
	

	TODOITEM* GetTask(const TODOSTRUCTURE* pTDS) const;

	BOOL ApplyLastChangeToSubtasks(const TODOITEM* pTDI, const TODOSTRUCTURE* pTDS, TDC_ATTRIBUTE nAttrib);

	BOOL Locate(DWORD dwParentID, DWORD dwPrevSiblingID, TODOSTRUCTURE*& pTDSParent, int& nPos) const;
	int MoveTask(TODOSTRUCTURE* pTDSSrcParent, int nSrcPos, DWORD dwSrcPrevSiblingID,
							 TODOSTRUCTURE* pTDSDestParent, int nDestPos);

	
	static TDC_ATTRIBUTE MapDateToAttribute(TDC_DATE nDate);

	static int Compare(const COleDateTime& date1, const COleDateTime& date2);
	static int Compare(const CString& sText1, const CString& sText2, BOOL bCheckEmpty = FALSE);
	static int Compare(int nNum1, int nNum2);
	static int Compare(double dNum1, double dNum2);
};

#endif // !defined(AFX_TODOCTRLDATA_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_)
