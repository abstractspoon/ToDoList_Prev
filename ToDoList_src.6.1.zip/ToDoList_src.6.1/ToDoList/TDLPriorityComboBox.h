		SetItemFocus(nItem, TRUE);

			// scroll cell into view
			ScrollCellIntoView(nItem, nCol);
		}

		m_nCurCol = nCol;
	}
}

void CInputListCtrl::EditCell(int nItem, int nCol)
{
	CString sText;
	CRect rEdit;
	int nLastRow, nLastCol;

	// if this is the right column, scroll item fully into view
	// begin editing and move the 
	// edit control to the correct column and fill edit control
	// with the right text
	if (nCol != -1 && nItem != -1 && !IsReadOnly())
	{
		// dont edit if editing is disabled
		if (IsColumnEditingDisabled(nCol))
			return;

		// dont edit if both autorowadding and autocoladding are enabled and we're in
		// pos (0, 0)
		if (m_bAutoAddRows && m_bAutoAddCols && nItem == 0 && nCol == 0)
			return;

		// dont edit if both autorowadding and autocoladding are enabled and we're in
		// other than col0 for row adding or row0 for col adding
		nLastRow = GetItemCount() - 1;
		nLastCol = GetColumnCount() - 1;

		if ((m_bAutoAddRows && nItem == nLastRow && nCol != 0) ||
			(m_bAutoAddCols && nCol == nLastCol && nItem != 0))
			return;

		m_nEditItem = nItem;
		m_nEditCol = nCol;
		GetEditControl()->Reset();

		// position edit box
		ScrollCellIntoView(nItem, nCol);
		GetCellEditRect(nItem, nCol, rEdit);

		// set text and show
		// if its a new row or column then clear the prompt text
		if (IsPrompt(nItem, nCol))
			sText.Empty();
		else
			sText = GetItemText(nItem, nCol);

		GetEditControl()->SetWindowText(sText);

		if (GetEditControl()->GetStyle() & WS_POPUP)
			ClientToScreen(rEdit);
		
		GetEditControl()->Show(rEdit);

		// this says that we are handling the edit
		// not a derived class.
		m_bBaseClassEdit = TRUE;
	}
}

long CInput