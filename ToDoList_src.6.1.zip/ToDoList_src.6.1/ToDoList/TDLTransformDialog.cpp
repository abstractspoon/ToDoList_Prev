
	{
		if (iFirstCellDayOfWeek == 7)	//sat
		{
			dateCurrent += 2;	//mon
		}
		else if (iFirstCellDayOfWeek == 1)	//sun
		{
			dateCurrent += 1;	//mon
		}
	}
	else
	{
		dateCurrent += (m_nFirstWeekDay - iFirstCellDayOfWeek);
	}

	DWORD dwStyleCompletedTasks = m_pFrameWnd->GetCompletedTasksStyle();

	for (int iRow = 0; iRow < CALENDAR_ROWS; iRow++)
	{
		for (int iCol = 0; iCol < CALENDAR_COLUMNS; iCol++)
		{
			// Init the cell
			m_dayCells[iRow][iCol].date = dateCurrent;
			m_dayCells[iRow][iCol].arrTasks.RemoveAll();
			m_dayCells[iRow][iCol].arrTaskIDs.RemoveAll();
			m_dayCells[iRow][iCol].arrIsStartTask.RemoveAll();
			m_dayCells[iRow][iCol].arrIsDueTask.RemoveAll();
			m_dayCells[iRow][iCol].arrIsCompleteTask.RemoveAll();

			if (m_pCalendarData->IsImportantDate(dateCurrent))
			{
				//this date is special - get the tasks for this date
				CTaskInfoList listTasks;
				m_pCalendarData->GetTasks(dateCurrent, listTasks);
				ASSERT(!listTasks.IsEmpty());

				//add the tasks in listTasks to this date's cell
				CBigCalendarCell* pCell = (CBigCalendarCell*)GetCell(dateCurrent);	//frig to de-const the cell
				if (pCell)
				{
					for (POSITION pos = listTasks.GetHeadPosition(); pos != NULL; )
					{
						CTaskInfo ti = listTasks.GetNext(pos);
						if (!(dwStyleCompletedTasks & COMPLETEDTASKS_HIDDEN) || (!ti.IsComplete()))
						{
							pCell->arrTasks.Add(ti.GetTaskTitle());
							pCell->arrTaskIDs.Add(ti.GetTaskID());
							pCell->arrIsStartTask.Add(ti.IsStart());
							pCell->arrIsDueTask.Add(ti.IsDue());
							pCell->arrIsCompleteTask.Add(ti.IsComplete());
						}
					}
				}
			}

			CCalendarUtils::AddDay(dateCurrent);
		}
	}

	ResizeTasks(TRUE);

	Invalidate();

	if (m_pFrameWnd->IsWeekendsHidden())
	{
		if (m_dateSelected.GetDayOfWeek() == 7)
		{
			//sat
			m_dateSelected -= 1;
			SelectDate(m_dateSelected);
			FireNotifySelectDate();
		}
		else if (m_dateSelected.GetDayOfWeek() == 1)
		{
			//sun
			m_dateSelected -= 2;
			SelectDate(m_dateSelected);
			FireNotifySelectDate();
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// CBigCalendarCtrl message handlers

void CBigCalendarCtrl::OnPaint() 
{
	ResizeTasks();

	CPaintDC dc(this);
	CRect rc;
	GetClientRect(&rc);

	CDC MemDC;
	MemDC.CreateCompatibleDC(&dc);
	CBitmap MemBitmap;
	MemBitmap.CreateCompatibleBitmap(&dc, rc.Width(), rc.Height());
	CBitmap *pOldBitmap = MemDC.SelectObject(&MemBitmap);

	CBrush brBkGnd;
	brBkGnd.CreateSolidBrush(COLOUR_BACKGROUND);
	MemDC.FillRect(&rc ,&brBkGnd);
	MemDC.SetBkMode(TRANSPA