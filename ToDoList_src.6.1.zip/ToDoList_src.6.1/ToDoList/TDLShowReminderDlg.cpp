eight;
			_nCol = _point.x/nWidth;	
			if((_nRow>=0) && (_nRow<nNumWeeks) && (_nCol>=0) && (_nCol<nNumColumns))
				return TRUE;
		}
	}
	return FALSE;
}

BOOL CBigCalendarCtrl::GetRectFromCell(int _nRow,
									   int _nCol,
									   CRect& _rect) const
{
	int nNumColumns = m_pFrameWnd->GetNumDaysToDisplay();
	int nNumWeeks = m_pFrameWnd->GetNumWeeksToDisplay();

	if (_nRow >=0 && _nRow<nNumWeeks && _nCol>=0 && _nCol<nNumColumns)
	{
		CRect rc;
		GetClientRect(&rc);
		int nHeight = (rc.Height()-CALENDAR_HEADER_HEIGHT)/nNumWeeks;
		int nWidth = rc.Width()/nNumColumns;
		_rect.left = nWidth*_nCol;
		_rect.right = _rect.left + nWidth;
		_rect.top = CALENDAR_HEADER_HEIGHT + _nRow*nHeight;
		_rect.bottom = _rect.top + nHeight;
		return TRUE;
	}
	return FALSE;
}

void CBigCalendarCtrl::GetLastSelectedGridCell(int& _nRow,
											   int& _nCol) const
{
	int nNumColumns = m_pFrameWnd->GetNumDaysToDisplay();
	int nNumWeeks = m_pFrameWnd->GetNumWeeksToDisplay();

	_nRow = 0;
	_nCol = 0;
	for(int i=0; i<nNumWeeks; i++)
	{
		for(int u=0; u<nNumColumns; u++)
		{
			if (m_dateSelected == m_dayCells[i][u].date)
			{
				_nRow = i;
				_nCol = u;
				return;
			}
		}
	}
}

CBigCalendarTask* CBigCalendarCtrl::GetTaskListboxFromTaskListboxID(int _nListboxID) const
{
	CBigCalendarTask* pWndTask = (CBigCalendarTask*)GetDlgItem(_nListboxID);
	return pWndTask;
}

CBigCalendarTask* CBigCalendarCtrl::GetTaskListboxFromCell(int _nRow,
														   int _nCol) const
{
	return GetTaskListboxFromTaskListboxID(m_dayCells[_nRow][_nCol].nListboxID);
}

CBigCalendarTask* CBigCalendarCtrl::GetTaskListboxFromDate(const COleDateTime& _date) const
{
	const CBigCalendarCell* pCell = GetCell(_date);
	if (pCell)
	{
		return GetTaskListboxFromTaskListboxID(pCell->nListboxID);
	}
	return NULL;
}

const CBigCalendarCell* CBigCalendarCtrl::GetCell(const COleDateTime& _date) const
{
	int nNumColumns = m_pFrameWnd->GetNumDaysToDisplay();
	int nNumWeeks = m_pFrameWnd->GetNumWeeksToDisplay();

	for(int i=0; i<nNumWeeks; i++)
		for(int u=0; u<nNumColumns; u++)
			if((m_dayCells[i][u].date) == _date)
				return &m_dayCells[i][u];
	return NULL;
}

//if date is NOT visible, and _pbAfter is NOT NULL, _pbAfter will contain TRUE if the date is AFTER _date
BOOL CBigCalendarCtrl::IsDateVisible(const COleDateTime& _date,
									 BOOL* _pbAfter/*=NULL*/) const
{
	if (GetCell(_date) == NULL)
	{
		if (_pbAfter != NULL)
		{
			*_pbAfter = FALSE;
			int nLastRow = m_pFrameWnd->GetNumWeeksToDisplay()-1;
			int nLastCol = m_pFrameWnd->GetNumDaysToDisplay()-1;
			if (_date > (m_dayCells[nLastRow][nLastCol].date))
			{
				*_pbAfter = TRUE;
			}
		}
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

COLORREF CBigCalendarCtrl::GetFadedBlue(unsigned char _percent)
{	
	int r = 180, g = 205, b = 255;
	int al = _percent*75/100;
	return RGB(	(unsigned char)(r + ((255-r)/(float)75) * al), 
				(unsigned char)(g + ((255-g)/(float)75) * al), 
				(unsigned char)(b + ((255-b)/(float)75) * al));
}

void CBigCalendarCtrl::EnterCell()
{
	//select first task in cell, if there is one
	CBigCalendarTask* plbTasks = GetTaskListboxFromDate(m_dateSelected);
	if (plbTasks != NULL)
	{
		if (plbTasks->GetCount() > 0)
		{
			SelectTask(plbTasks->GetDlgCtrlID(), 0);
			p