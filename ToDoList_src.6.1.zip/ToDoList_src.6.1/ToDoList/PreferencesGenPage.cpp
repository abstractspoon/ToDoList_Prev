 pOldWnd	-	Not used
					
	Usage :			Called from MFC. 

   ============================================================*/
{

	CWnd::OnSetFocus(pOldWnd);
	m_rtf.SetFocus();
	
}

LRESULT CRulerRichEditCtrl::OnGetScrollPos(WPARAM, LPARAM)
/* ============================================================
	Function :		CRulerRichEditCtrl::OnGetScrollPos
	Description :	The function handles the registered message 
					"urm_GETSCROLLPOS", that is sent from the 
					ruler to get the current scroll position 
					of the embedded RTF-control.
	Access :		Protected

	Return :		LRESULT		-	Current scroll pos
	Parameters :	WPARAM mode	-	Not used
					LPARAM pt	-	Not used
					
	Usage :			Called from MFC

   ============================================================*/
{

	return m_rtf.GetScrollPos(SB_HORZ);

}

LRESULT CRulerRichEditCtrl::OnTrackRuler(WPARAM mode, LPARAM pt)
/* ============================================================
	Function :		CRulerRichEditCtrl::OnTrackRuler
	Description :	The function handles the registered message 
					"urm_RULERACTION", that is sent from the 
					mouse handling mappings in the ruler control.
					The function handles dragging of tabulator 
					points in the ruler.
	Access :		Protected
					
	Return :		LRESULT		-	Not used
	Parameters :	WPARAM mode	-	The type of mouse operation, 
									"DOWN", "MOVE" or "UP"
					LPARAM pt	-	Cursor point for the cursor.
					
	Usage :			Called from MFC.

   ============================================================*/
{

	CPoint* point = (CPoint*) pt;
	int toolbarHeight = 0;
	if (m_showToolbar)
		toolbarHeight = TOOLBAR_HEIGHT;

	switch(mode)
	{
		case DOWN:
			// The left mouse button is clicked
			{
				// Check if we clicked on a tab-marker.
				int pos = m_rtf.GetScrollPos(SB_HORZ);
				m_movingtab = -1;
				CRect hitRect;
				int y = RULER_HEIGHT - 9;
				for(int t = 0 ; t < MAX_TAB_STOPS ; t++)
				{
					int x = m_tabs[ t ] + m_margin - pos;
					hitRect.SetRect(x - 2, y - 1, x + 3, y + 3);
					if (hitRect.PtInRect(*point))
					{
						// Yes, we did.
						m_movingtab = t;

						// Calc offset, as the hit area is wider than
						// the 1 pixel tab line
						m_offset = point->x - (m_tabs[ t ] + m_margin - pos);
					}
				}

				if (m_movingtab != -1)
				{

					// We did click in a tab marker.
					// Start dragging

					// Find initial ruler position
					m_rulerPosition = point->x - m_offset;
					CRect rect;
					GetClientRect(rect);

					// Draw a new ruler line
					CClientDC dc(this);
					dc.SelectObject(&m_pen);
					dc.SetROP2(R2_XORPEN);

					dc.MoveTo(m_rulerPosition, toolbarHeight + 3);
					dc.LineTo(m_rulerPosition, rect.Height());

					dc.SelectStockObject(BLACK_PEN);

				}
			}
			break;

		case MOVE:
			// The mouse is moved
				if (m_movingtab != -1)
				{
					CRect rect;
					GetClientRect(rect);
					CClientDC dc(this);

					// Erase previous line
					dc.SelectObject(&m_pen);
					dc.SetROP2(R2_XORPEN);

					dc.MoveTo(m_rulerPosition, toolbarHeight + 3);
					dc.LineTo(m_rulerPosition, rect.Height());

					// Set up new line
					// Calc min and max. We can not place this marker 
					// before the previous or after the next. Neither 
					// can we move the marker outside the ruler.
					int pos = m_rtf.GetScrollPos(SB_HORZ);
					int min = m_margin + m_offset;
					if (m_movingtab > 0)
						min = (m_tabs[ m_movingtab - 1 ] + m_margin - pos) + 3 + m_offset;

					int max = rect.Width() - 5 + m_offset;
					if (m_movingtab < m_tabs.GetUpperBound())
						max = (m_tabs[ m_movingtab + 1 ] + m_margin - pos) - 3 + m_offset;
					max = min(max, rect.Width() - 5 + m_offset);

					// Set new positions
					m_rulerPosition = max(min, point->x - m_offset);
					m_rulerPosition = min(m_rulerPosition, max);

					// Draw the new line
					dc.MoveTo(m_rulerPosition, toolbarHeight + 3);
					dc.LineTo(m_rulerPosition, rect.Height());

					dc.SelectStockObject(BLACK_PEN);

				}
			break;

		case UP:
			// The mouse button is released
				if (m_movingtab != -1)
				{
				// Erase previous line
				CRect rect;
				GetClientRect(rect);
				
				CClientDC dc(this);
				dc.SelectObject(&m_pen);
				dc.SetROP2(R2_XORPEN);
				
				dc.MoveTo(m_rulerPosition, toolbarHeight + 3);
				dc.LineTo(m_rulerPosition, rect.Height());

				// Set new value for tab position
				int pos = m_rtf.GetScrollPos(SB_HORZ);
				m_tabs[ m_movingtab ] = m_rulerPosition - m_margin + pos - m_offset;

				// Get the current tabstops, as we
				// must set all tabs in one operation
				ParaFormat para(PFM_TABSTOPS);
				para.cTabCount = MAX_TAB_STOPS;
				m_rtf.GetParaFormat(para);

				// Convert current position to twips
				double twip = (double)m_physicalInch / 1440;
				int tabpos = m_tabs[ m_movingtab ];
				tabpos = (int) ((double) tabpos / twip +.5);
				para.rgxTabs[ m_movingtab ] = tabpos; 

				// Set tabs to control
				m_rtf.SetParaFormat(para);

				// Update the ruler
				m_ruler.SetTabStops(m_tabs);

				m_movingtab = -1;
				m_rtf.SetFocus();
			}
			break;
	}

	return 0;

}

LRESULT CRulerRichEditCtrl::OnSetText(WPARAM wParam, LPARAM lParam)
/* ============================================================
	Function :		CRulerRichEditCtrl::OnSetText
	Description :	The function handles the "WM_SETTEXT" 
					message. The handler sets the text in the 
					RTF-control
	Access :		Protected
										
	Return :		LRESULT			-	From the control
	Parameters :	WPARAM wParam	-	Passed on
					LPARAM lParam	-	Passed on
					
	Usage :			Called from MFC.

   ============================================================*/
{
	
	return m_rtf.SendMessage(WM_SETTEXT, wParam, lParam);

}

LRESULT CRulerRichEditCtrl::OnGetText(WPARAM wParam, LPARAM lParam)
/* ============================================================
	Function :		CRulerRichEditCtrl::OnGetText
	Description :	The function handles the "WM_GETTEXT" 
					message. The handler gets the text from the 
					RTF-control
	Access :		Protected
										
	Return :		LRESULT			-	From the control
	Parameters :	WPARAM wParam	-	Passed on
					LPARAM lParam	-	Passed on
					
	Usage :			Called from MFC.

   ============================================================*/
{

	return m_rtf.SendMessage(WM_GETTEXT, wParam, lParam);

}

LRESULT CRulerRichEditCtrl::OnGetTextLength(WPARAM /*wParam*/, LPARAM /*lParam*/)
/* ============================================================
	Function :		CRulerRichEditCtrl::OnGetTextLength
	Description :	The function handles the "WM_GETTEXTLENGTH" 
					message. The handler gets the length of 
					the text in the RTF-control
	Access :		Protected
										
	Return :		LRESULT			-	From the control
	Parameters :	WPARAM wParam	-	Passed on
					LPARAM lParam	-	Passed on
					
	Usage :			Called from MFC.

   ============================================================*/
{

	return m_rtf.GetTextLength();

}

///////////