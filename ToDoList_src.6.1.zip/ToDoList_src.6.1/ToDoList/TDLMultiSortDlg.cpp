// ImportExportUIHelper.h: interface for the CImportExportUIHelper class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMPORTEXPORTUIHELPER_H__AC709E3B_C876_43D8_A965_CAD2D2E7AD34__INCLUDED_)
#define AFX_IMPORTEXPORTUIHELPER_H__AC709E3B_C876_43D8_A965_CAD2D2E7AD34__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CImportExportMgr;
class CMenuIconMgr;

class CImportExportUIHelper  
{
public:
	CImportExportUIHelper(const CImportExportMgr& mgrImpExp, CMenuIconMgr& mgrIcon);
	virtual ~CImportExportUIHelper();

	void UpdateExportMenu(CCmdUI* pCmdUI, int nMaxCount, BOOL bEnabled = TRUE) const;
	void UpdateImportMenu(CCmdUI* pCmdUI, int nMaxCount, BOOL bEnabled = TRUE) const;

protected:
	const CImportExportMgr& m_mgrImpExp;
	CMenuIconMgr& m_mgrIcon;

};

#endif // !defined(AFX_IMPORTEXPORTUIHELPER_H__AC709E3B_C876_43D8_A965_CAD2D2E7AD34__INCLUDED_)
                                                                SORTBY1, m_cbSortBy1);
	DDX_Check(pDX, IDC_ASCENDING1, m_bAscending1);
	DDX_Check(pDX, IDC_ASCENDING2, m_bAscending2);
	DDX_Check(pDX, IDC_ASCENDING3, m_bAscending3);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTDLMultiSortDlg, CDialog)
	//{{AFX_MSG_MAP(CTDLMultiSortDlg)
	ON_CBN_SELCHANGE(IDC_SORTBY1, OnSelchangeSortby1)
	ON_CBN_SELCHANGE(IDC_SORTBY2, OnSelchangeSortby2)
	ON_CBN_SELCHANGE(IDC_SORTBY3, OnSelchangeSortby3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTDLMultiSortDlg message handlers

BOOL CTDLMultiSortDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	BuildCombos();

	// disable 3rd combo if 2nd combo not set
	m_cbSortBy3.EnableWindow(m_nSortBy2 != TDC_UNSORTED);
	
	GetDlgItem(IDC_ASCENDING3)->EnableWindow(m_nSortBy2 != TDC_UNSORTED && m_nSortBy3 != TDC_UNSORTED);
	GetDlgItem(IDC_ASCENDING2)->EnableWindow(m_nSortBy2 != TDC_UNSORTED);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTDLMultiSortDlg::BuildCombos()
{
	for (int nCol = 0; nCol < NUM_COLUMNS; nCol++)
	{
		TDCCOLUMN& col = COLUMNS[nCol];

		if (col.nSortBy != TDC_UNSORTED)
		{
			int nIndex = m_cbSortBy1.AddString(CEnString(col.nIDLongName));
			m_cbSortBy1.SetItemData(nIndex, col.nSortBy);

			if (m_nSortBy1 == col.nSortBy)
				m_cbSortBy1.SetCurSel(nIndex);

			nIndex = m_cbSortBy2.AddString(CEnString(col.nIDLongName));
			m_cbSortBy2.SetItemData(nIndex, col.nSortBy);

			if (m_nSortBy2 == col.nSortBy)
				m_cbSortBy2.SetCurSel(nIndex);

			nIndex = m_cbSortBy3.AddString(CEnString(col.nIDLongName));
			m_cbSortBy3.SetItemData(nIndex, col.nSortBy);

			if (m_nSortBy3 == col.nSortBy)
				m_cbSortBy3.SetCurSel(nIndex);
		}
	}

	// add blank item at top of 2nd and 3rd combo
	int nIndex = m_cbSortBy2.InsertString(0, "");
	m_cbSortBy2.SetItemData(nIndex, TDC_UNSORTED);
	
	if (m_nSortBy2 == TDC_UNSORTED)
		m_cbSortBy2.SetCurSel(nIndex);
	
	nIndex = m_cbSortBy3.InsertString(0, "");
	m_cbSortBy3.SetItemData(nIndex, TDC_UNSORTED);
	
	if (m_nSortBy3 == TDC_UNSORTED)
		m_cbSortBy3.SetCurSel(nIndex);

	// set selection to first item if first combo selection is not set
	if (m_cbSortBy1.GetCurSel() == -1)
	{
		m_cbSortBy1.SetCurSel(0);
		m_nSortBy1 = (TDC_SORTBY)m_cbSortBy1.GetItemData(0);
	}
}

void CTDLMultiSortDlg::OnSelchangeSortby1() 
{
	UpdateData();
	
	int nSel = m_cbSortBy1.GetCurSel();
	m_nSortBy1 = (TDC_SORTBY)m_cbSortBy1.GetItemData(nSel);
}

void CTDLMultiSortDlg::OnSelchangeSortby2() 
{
	UpdateData();
		
	int nSel = m_cbSortBy2.GetCurSel();
	m_nSortBy2 = (TDC_SORTBY)m_cbSortBy2.GetItemData(nSel);

	GetDlgItem(IDC_ASCENDING2)->EnableWindow(m_nSortBy2 != TDC_UNSORTED);

	// disable 3rd combo if 2nd combo not set
	m_cbSortBy3.EnableWindow(m_nSortBy2 != TDC_UNSORTED);
	GetDlgItem(IDC_ASCENDING3)->EnableWindow(m_nSortBy2 != TDC_UNSORTED && m_nSortBy3 != TDC_UNSORTED);
}

void CT#if !defined(AFX_INPUTLISTCTRL_H__2E5810B0_D7DF_11D1_AB19_0000E8425C3E__INCLUDED_)
#define AFX_INPUTLISTCTRL_H__2E5810B0_D7DF_11D1_AB19_0000E8425C3E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// InputListCtrl.h : header file
//

#include "enlistctrl.h"
#include "popupeditctrl.h"
#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////
// CInputListCtrl window

enum { NOTVALID, ADDITEM, EDITITEM };
enum { TEXT, DROPLIST, BROWSE }; 

class CColumnData2 : public CColumnData
{
public:
	CColumnData2() : CColumnData(), bEditEnabled(TRUE), nType(TEXT) { }
	BOOL 