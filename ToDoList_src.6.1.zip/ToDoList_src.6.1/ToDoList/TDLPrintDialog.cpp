tTaskDueDateString(HTASKITEM hTask) const = 0;
	virtual const char* GetTaskStartDateString(HTASKITEM hTask) const = 0;

	virtual bool IsTaskDone(HTASKITEM hTask) const = 0;
	virtual bool IsTaskDue(HTASKITEM hTask) const = 0;

	virtual unsigned long GetTaskPosition(HTASKITEM hTask) const = 0;

	virtual bool TaskHasAttribute(HTASKITEM hTask, const char* szAttrib) const = 0;
	virtual const char* GetTaskAttribute(HTASKITEM hTask, const char* szAttrib) const = 0;
	virtual HTASKITEM GetTaskParent(HTASKITEM hTask) const = 0;
		
	// set methods
	virtual bool SetTaskTitle(HTASKITEM hTask, const char* szTitle) = 0;
	virtual bool SetTaskComments(HTASKITEM hTask, const char* szComments) = 0;
	virtual bool SetTaskAllocatedTo(HTASKITEM hTask, const char* szAllocTo) = 0;
	virtual bool SetTaskAllocatedBy(HTASKITEM hTask, const char* szAllocBy) = 0;
	virtual bool SetTaskCategory(HTASKITEM hTask, const char* szCategory) = 0;
	virtual bool SetTaskStatus(HTASKITEM hTask, const char* szStatus) = 0;
	virtual bool SetTaskFileReferencePath(HTASKITEM hTask, const char* szFileRefpath) = 0;

	virtual bool SetTaskColor(HTASKITEM hTask, unsigned long nColor) = 0;

	virtual bool SetTaskPriority(HTASKITEM hTask, unsigned char nPriority) = 0;
	virtual bool SetTaskPercentDone(HTASKITEM hTask, unsigned char nPercent) = 0;

	virtual bool SetTaskTimeEstimate(HTASKITEM hTask, double dTimeEst, char cUnits) = 0;
	virtual bool SetTaskTimeSpent(HTASKITEM hTask, double dTimeSpent, char cUnits) = 0;

	virtual bool SetTaskLastModified(HTASKITEM hTask, time_t tLastMod) = 0;
	virtual bool SetTaskDoneDate(HTASKITEM hTask, time_t tDoneDate) = 0;
	virtual bool SetTaskDueDate(HTASKITEM hTask, time_t tDueDate) = 0;
	virtual bool SetTaskStartDate(HTASKITEM hTask, time_t tStartDate) = 0;

	virtual bool SetTaskPosition(HTASKITEM hTask, unsigned long nPos) = 0;

	// new methods
	virtual bool SetTaskFlag(HTASKITEM hTask, bool bFlag) = 0;
	virtual bool IsTaskFlagged(HTASKITEM hTask) const = 0;

};

class ITaskList2 : public ITaskList
{
	// new methods
public:
	virtual const char* GetTaskCreatedBy(HTASKITEM hTask) const = 0;
	virtual time_t GetTaskCreationDate(HTASKITEM hTask) const = 0;
	virtual const char* GetTaskCreationDateString(HTASKITEM hTask) const = 0;
	
	virtual bool SetTaskCreatedBy(HTASKITEM hTask, const char* szCreatedBy) = 0;
	virtual bool SetTaskCreationDate(HTASKITEM hTask, time_t tCreationDate) = 0;
};

class ITaskList3 : public ITaskList2
{
	// new methods
public:
	virtual time_t GetTaskDueDate(HTASKITEM hTask, BOOL bEarliest) const = 0;
	virtual const char* GetTaskDueDateString(HTASKITEM hTask, BOOL bEarliest) const = 0;
	virtual unsigned long GetTaskTextColor(HTASKITEM hTask) const = 0;
	virtual int GetTaskRisk(HTASKITEM hTask, BOOL bHighest) const = 0;
	virtual const char* GetTaskExternalID(HTASKITEM hTask) const = 0;
	
	virtual bool SetTaskRisk(HTASKITEM hTask, unsigned char nRisk) = 0;
	virtual bool SetTaskExternalID(HTASKITEM hTask, const char* szID) = 0;
};

class ITaskList4 : public ITaskList3
{
	// new methods
public:
	virtual const char* GetAttribute(const char* szAttrib) const = 0;

	virtual const char* GetHtmlCharSet() const = 0;
	virtual const char* GetReportTitle() const = 0;
	virtual const char* GetReportDate() const = 0;
	virtual double GetTaskCost(HTASKITEM hTask, BOOL bCalc) const = 0;
	virtual unsigned char GetTaskCategoryCount(HTASKITEM hTask) const = 0;
	virtual const char* GetTaskCategory(HTASKITEM hTask, int nIndex) const = 0;
	virtual const char* GetTaskDependency(HTASKITEM hTask) const = 0;

	virtual bool SetTaskCost(HTASKITEM hTask, double dCost) = 0;
	virtual bool SetTaskDependency(HTASKITEM hTask, const char* szDepends) = 0;
};

class ITaskList5 : public ITaskList4
{
	// new methods
public:
	virtual bool AddTaskCategory(HTASKITEM hTask, const char* szCategory) = 0;
};

class ITaskList6 : public ITaskList5
{
	// new methods
public:
	virtual bool SetTaskRecurrenc