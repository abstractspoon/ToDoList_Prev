========*/
{

	if (m_rtf.m_hWnd)
	{
		m_rtf.SetReadOnly(readOnly);
		m_rtf.SetBackgroundColor(!readOnly, GetSysColor(COLOR_3DFACE));

		m_toolbar.EnableWindow(!readOnly);
		m_ruler.EnableWindow(!readOnly);

		UpdateToolbarButtons();
	}

	m_readOnly = readOnly;

}

BOOL CRulerRichEditCtrl::GetReadOnly() const
/* ============================================================
	Function :		CRulerRichEditCtrl::GetReadOnly
	Description :	Returns if the control is read only or not
	Access :		Public
					
	Return :		BOOL	-	"TRUE" if read only
	Parameters :	none
					
	Usage :			Call to get the read only-state of the 
					control

   ============================================================*/
{

	return m_readOnly;

}

void CRulerRichEditCtrl::OnEnable(BOOL bEnable) 
{
	CWnd::OnEnable(bEnable);

	// update children
	// we don't disable the rtf because this causes the scrollbar
	// to remain disabled even after re-enabling
	SetReadOnly(m_readOnly || !bEnable);
}
         	enum { IDD = IDD_PREFSHORTCUTS_PAGE };
	CHotKeyCtrlEx	m_hkCur;
	COrderedTreeCtrl	m_tcCommands;
	CHotKeyCtrlEx	m_hkNew;
	CString	m_sOtherCmdID;
	//}}AFX_DATA

	CShortcutManager* m_pShortcutMgr;
	UINT m_nMenuID;
	CMap<UINT, UINT, DWORD, DWORD&> m_mapID2Shortcut;
	CMap<DWORD, DWORD, HTREEITEM, HTREEITEM&> m_mapShortcut2HTI;
	BOOL m_bIgnoreGrayedItems;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesShortcutsPage)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	virtual void OnOK();

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesShortcutsPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangedShortcuts(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnAssignshortcut();
	//}}AFX_MSG
	afx_msg void OnChangeShortcut();
	afx_msg LRESULT OnGutterDrawItem(WPARAM wParam, LPARAM lParam); // for drawing priority
	afx_msg LRESULT OnGutterRecalcColWidth(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterGetItemColors(WPARAM wParam, LPARAM lParam);
	afx_msg void OnTreeCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	DECLARE_MESSAGE_MAP()

	HTREEITEM AddMenuItem(HTREEITEM htiParent, const CMenu* pMenu, int nPos);
	int GetLongestShortcutText(HTREEITEM hti, CDC* pDC);

   virtual void LoadPreferences(const CPreferences& prefs);
   virtual void SavePreferences(CPreferences& prefs);

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERERENCESSHORTCUTSPAGE_H__DA5D005D_C6CC_453A_A431_A2B85A920CE5__INCLUDED_)
