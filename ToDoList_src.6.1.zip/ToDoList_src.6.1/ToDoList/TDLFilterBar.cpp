
		{
			sAttrib.Replace(ONEDBLQUOTE, TWODBLQUOTE);
			bNeedQuoting = TRUE;
		}
		
		// look for commas or whatever is the list delimiter
		if (sAttrib.Find(DELIM) != -1)
			bNeedQuoting = TRUE;
		
		if (bNeedQuoting)
			sAttrib = ONEDBLQUOTE + sAttrib + ONEDBLQUOTE;
		
		// replace carriage returns
		sAttrib.Replace(ENDL, SPACE);
	}
	else if (at == AT_COST)
	{
		sAttrib = Misc::Format(atof(sAttrib));
	}
	else if (at == AT_TIME)
	{
		if (ROUNDTIMEFRACTIONS)
			sAttrib.Format("%d", atoi(sAttrib));
		else
			sAttrib = Misc::Format(atof(sAttrib));
	}
	
	sAttrib += DELIM;
	sOutput += sAttrib;
}

CString CTaskListCsvExporter::CheckGetColumnHeading(LPCTSTR szAttribName, UINT nIDHeading) const
{
	if (WantAttribute(szAttribName))
		return CEnString(nIDHeading) + DELIM;

	// else
	return "";
}

CString CTaskListCsvExporter::ColumnHeadings() const
{
	ASSERT (m_aAttribs.GetSize());

	CString sHeadings;

	sHeadings += CheckGetColumnHeading(TDL_TASKPOS, IDS_TDLBC_POS);
	sHeadings += CheckGetColumnHeading(TDL_TASKID, IDS_TDLBC_ID);
	sHeadings += CheckGetColumnHeading(TDL_TASKTITLE, IDS_TDLBC_TITLE);
	sHeadings += CheckGetColumnHeading(TDL_TASKPERCENTDONE, IDS_TDLBC_PERCENT);
	sHeadings += CheckGetColumnHeading(TDL_TASKPRIORITY, IDS_TDLBC_PRIORITY);
	sHeadings += CheckGetColumnHeading(TDL_TASKTIMEESTIMATE, IDS_TDLBC_TIMEEST);
	sHeadings += CheckGetColumnHeading(TDL_TASKTIMESPENT, IDS_TDLBC_TIMESPENT);
	sHeadings += CheckGetColumnHeading(TDL_TASKCREATIONDATESTRING, IDS_TDLBC_CREATEDATE);
	sHeadings += CheckGetColumnHeading(TDL_TASKCREATEDBY, IDS_TDLBC_CREATEDBY);
	sHeadings += CheckGetColumnHeading(TDL_TASKSTARTDATESTRING, IDS_TDLBC_STARTDATE);
	sHeadings += CheckGetColumnHeading(TDL_TASKDUEDATESTRING, IDS_TDLBC_DUEDATE);
	sHeadings += CheckGetColumnHeading(TDL_TASKDONEDATESTRING, IDS_TDLBC_DONEDATE);
	sHeadings += CheckGetColumnHeading(TDL_TASKALLOCTO, IDS_TDLBC_ALLOCTO);
	sHeadings += CheckGetColumnHeading(TDL_TASKALLOCBY, IDS_TDLBC_ALLOCBY);
	sHeadings += CheckGetColumnHeading(TDL_TASKVERSION, IDS_TDLBC_VERSION);
	sHeadings += CheckGetColumnHeading(TDL_TASKRECURRENCE, IDS_TDLBC_RECURRENCE);
	sHeadings += CheckGetColumnHeading(TDL_TASKCATEGORY, IDS_TDLBC_CATEGORY);
	sHeadings += CheckGetColumnHeading(TDL_TASKSTATUS, IDS_TDLBC_STATUS);
	sHeadings += CheckGetColumnHeading(TDL_TASKRISK, IDS_TDLBC_RISK);
	sHeadings += CheckGetColumnHeading(TDL_TASKEXTERNALID, IDS_TDLBC_EXTERNALID);
	sHeadings += CheckGetColumnHeading(TDL_TASKLASTMODSTRING, IDS_TDLBC_MODIFYDATE);
	sHeadings += CheckGetColumnHeading(TDL_TASKCOST, IDS_TDLBC_COST);
	sHeadings += CheckGetColumnHeading(TDL_TASKFILEREFPATH, IDS_TDLBC_FILEREF);
	sHeadings += CheckGetColumnHeading(TDL_TASKDEPENDENCY, IDS_TDLBC_DEPENDS);
	sHeadings += CheckGetColumnHeading(TDL_TASKCOMMENTS, IDS_TDLBC_COMMENTS);

	RemoveTrailingDelimiter(sHeadings);

	return sHeadings;
}

int CTaskListCsvExporter::BuildAttribList(const ITaskList6* pTasks, HTASKITEM hTask)
{
	if (hTask)
	{
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKPOS);					
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKID);					
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKTITLE);				
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKCOMMENTS); 			
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKALLOCTO);				
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKALLOCBY);				
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKCATEGORY); 			
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKSTATUS);				
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKFILEREFPATH);			
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKCREATEDBY);			
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKFLAG);				
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKDONEDATESTRING);		
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKDUEDATESTRING);
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKSTARTDATESTRING);		
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKCREATIONDATESTRING);	
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKTIMEESTIMATE);	
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKTIMESPENT);		
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKPERCENTDONE);		
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKPRIORITY);		
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKRISK);			
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKLASTMODSTRING);		
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKEXTERNALID);			
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKCOST);			
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKDEPENDENCY);			
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKVERSION);			
		CheckAddAttribtoList(pTasks, hTask, TDL_TASKRECURRENCE);			
	}

	// subtasks
	hTask = pTasks->GetFirstTask(hTask);

	while (hTask) // at least one sub-task
	{
		BuildAttribList(pTasks, hTask);

		// next subtask
		hTask = pTasks->GetNextTask(hTask);
	}

	return m_aAttribs.GetSize();
}

BOOL CTaskListCsvExporter::WantAttribute(LPCTSTR szAttribName) const
{
	int nAttrib = m_aAttribs.GetSize();

	while (nAttrib--)
	{
		if (m_aAttribs[nAttrib] == szAttribName)
			return TRUE;
	}

	// nope
	return FALSE;
}
            ked(m_filter.aAllocBy);

		// version
		m_cbVersionFilter.SetChecked(m_filter.aVersions);

		// options
		m_cbOptions.Initialize(m_filter, m_nView);
	}
}


BEGIN_MESSAGE_MAP(CTDLFilterBar, CDialog)
	//{{AFX_MSG_MAP(CFilterBar)
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_ALLALLOCTO, OnSelchangeFilter)
	ON_BN_CLICKED(IDC_ALLCATEGORIES, OnSelchangeFilter)
	//}}AFX_MSG_MAP
	ON_CBN_SELCHANGE(IDC_FILTERCOMBO, OnSelchangeFilter)
	ON_CBN_SELCHANGE(IDC_ALLOCTOFILTERCOMBO, OnSelchangeFilter)
	ON_CBN_SELCHANGE(IDC_VERSIONFILTERCOMBO, OnSelchangeFilter)
	ON_CBN_SELCHANGE(IDC_ALLOCBYFILTERCOMBO, OnSelchangeFilter)
	ON_CBN_SELCHANGE(IDC_STATUSFILTERCOMBO, OnSelchangeFilter)
	ON_CBN_SELCHANGE(IDC_PRIORITYFILTERCOMBO, OnSelchangeFilter)
	ON_CBN_SELCHANGE(IDC_CATEGORYFILTERCOMBO, OnSelchangeFilter)
	ON_CBN_SELCHANGE(IDC_RISKFILTERCOMBO, OnSelchangeFilter)
	ON_CBN_CLOSEUP(IDC_OPTIONFILTERCOMBO, OnSelchangeFilter)
//	ON_EN_CHANGE(IDC_TITLEFILTERTEXT, OnSelchangeFilter)
	ON_NOTIFY_EX_RANGE(TTN_NEEDTEXT, 0, 0xFFFF, OnToolTipNotify)
	ON_WM_ERASEBKGND()
	ON_REGISTERED_MESSAGE(WM_EE_BTNCLICK, OnEEBtnClick)
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFilterBar message handlers

BOOL CTDLFilterBar::Create(CWnd* pParentWnd, UINT nID, BOOL bVisible)
{
	if (CDialog::Create(IDD_FILTER_BAR, pParentWnd))
	{
		SetDlgCtrlID(nID);
		ShowWindow(bVisible ? SW_SHOW : SW_HIDE);

		GetDlgItem(IDC_TITLEFILTERTEXT)->ModifyStyle(0, ES_WANTRETURN, 0);

		return TRUE;
	}

	return FALSE;
}

void CTDLFilterBar::OnSelchangeFilter() 
{
	FTDCFILTER fPrev(m_filter);
	UpdateData(); // updates m_filter

	GetParent()->SendMessage(WM_FBN_FILTERCHNG, 0, (LPARAM)&m_filter);

	// if the main 'Show" filter has changed then we need to re-init the options
	if (m_filter.nFilter != fPrev.nFilter)
		m_cbOptions.Initialize(m_filter, m_nView);
}

LRESULT CTDLFilterBar::OnEEBtnClick(WPARAM /*wp*/, LPARAM /*lp*/)
{
	OnSelchangeFilter();
	return 0L;
}

BOOL CTDLFilterBar::PreTranslateMessage(MSG* pMsg)
{
	// handle return key in title field
	if (pMsg->message == WM_KEYDOWN && pMsg->hwnd == m_eTitleFilter &&
		pMsg->wParam == VK_RETURN)
	{
		OnSelchangeFilter();
		return TRUE;
	}

	return CDialog::PreTranslateMessage(pMsg);
}

void CTDLFilterBar::SetCustomFilter(BOOL bCustom, LPCTSTR szFilter)
{
	if (bCustom)
		m_cbTaskFilter.SetCustomFilter(szFilter);

	m_bCustomFilter = bCustom;
	m_sCustomFilter = szFilter;

	// disable controls if a custom filter.
	// just do a repos because this also handles enabled state
	ReposControls();
}

void CTDLFilterBar::RemoveCustomFilter() 
{ 
	m_cbTaskFilter.RemoveCustomFilter(); 
}

void CTDLFilterBar::RefreshFilterControls(const CFilteredToDoCtrl& tdc)
{
	// column visibility
	CTDCColumnArray aColumns;
	tdc.GetVisibleColumns(aColumns);

	SetVisibleFilters(aColumns);

	// get filter
	tdc.GetFilter(m_filter);
	m_nView = tdc.GetView();

	// get custom filter
	m_bCustomFilter = tdc./*
  Copyright (c) 2003/2004, Dominik Reichl <dominik.reichl@t-online.de>
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

  - Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer. 
  - Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.
  - Neither the name of ReichlSoft nor the names of its contributors may be
    used to endorse or promote products derived from this software without
    specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
*/

#include "StdAfx.h"
#include "NewRandom.h"
#include "MemUtil.h"

static DWORD g_dwNewRandomInstanceCounter = 0;

static unsigned long g_xorW = 0;
static unsigned long g_xorX = 0;
static unsigned long g_xorY = 0;
static unsigned long g_xorZ = 0;

CNewRandom::CNewRandom()
{
	Reset();
}

CNewRandom::~CNewRandom()
{
	Reset();
}

void CNewRandom::Reset()
{
	mem_erase(m_pPseudoRandom, INTRAND_SIZE);
	m_dwCounter = 0;
}

void CNewRandom::Initialize()
{
	DWORD inx;

	WORD ww;
	DWORD dw;
	LARGE_INTEGER li;
	SYSTEMTIME st;
	POINT pt;
	MEMORYSTATUS ms;
	SYSTEM_INFO si;
#ifndef _WIN32_WCE
	STARTUPINFO sui;
#endif

	g_dwNewRandomInstanceCounter++;

	Reset();

	inx = 0;

	dw = GetTickCount();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	QueryPerformanceCounter(&li);
	memcpy(&m_pPseudoRandom[inx], &li, sizeof(LARGE_INTEGER));
	inx += sizeof(LARGE_INTEGER);

	GetLocalTime(&st);
	memcpy(&m_pPseudoRandom[inx], &st, sizeof(SYSTEMTIME));
	inx += sizeof(SYSTEMTIME);

	GetCursorPos(&pt);
	memcpy(&m_pPseudoRandom[inx], &pt, sizeof(POINT));
	inx += sizeof(POINT);

	ww = (WORD)(rand());
	memcpy(&m_pPseudoRandom[inx], &ww, 2); inx += 2;
	ww = (WORD)(rand());
	memcpy(&m_pPseudoRandom[inx], &ww, 2); inx += 2;
	ww = (WORD)(rand());
	memcpy(&m_pPseudoRandom[inx], &ww, 2); inx += 2;

	GetCaretPos(&pt);
	memcpy(&m_pPseudoRandom[inx], &pt, sizeof(POINT));
	inx += sizeof(POINT);

	GlobalMemoryStatus(&ms);
	memcpy(&m_pPseudoRandom[inx], &ms, sizeof(MEMORYSTATUS));
	inx += sizeof(MEMORYSTATUS);

	dw = (DWORD)GetActiveWindow();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = (DWORD)GetCapture();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = (DWORD)GetClipboardOwner();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

#ifndef _WIN32_WCE
	// No support under Windows CE
	dw = (DWORD)GetClipboardViewer();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); 
#else
	// Leave the stack data - random :)
#endif
	inx += 4;

	dw = GetCurrentProcessId();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = (DWORD)GetCurrentProcess();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = (DWORD)GetActiveWindow();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = GetCurrentThreadId();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = (DWORD)GetCurrentThread();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = (DWORD)GetDesktopWindow();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = (DWORD)GetFocus();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = (DWORD)GetForegroundWindow();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

#ifndef _WIN32_WCE
	dw = (DWORD)GetInputState();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); 
#else
	// Leave the stack data - random :)
#endif
	inx += 4;

	dw = GetMessagePos();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

#ifndef _WIN32_WCE
	dw = (DWORD)GetMessageTime();
	memcpy(&m_pPseudoRandom[inx], &dw, 4);
#else
	// Leave the stack data - random :)
#endif
	inx += 4;

	dw = (DWORD)GetOpenClipboardWindow();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	dw = (DWORD)GetProcessHeap();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

	GetSystemInfo(&si);
	memcpy(&m_pPseudoRandom[inx], &si, sizeof(SYSTEM_INFO));
	inx += sizeof(SYSTEM_INFO);

	dw = (DWORD)randXorShift();
	memcpy(&m_pPseudoRandom[inx], &dw, 4); inx += 4;

#ifndef _WIN32_WCE
	GetStartupInfo(&sui);
	memcpy(&m_pPseudoRandom[inx], &sui, sizeof(STARTUPINFO));
#else
	// Leave the stack data - random :)
#endif
	inx += sizeof(STARTUPINFO);

	memcpy(&m_pPseudoRandom[inx], &g_dwNewRandomInstanceCounter, 4);
	inx += 4;

	ASSERT(inx <= INTRAND_SIZE);
}

void CNewRandom::GetRandomBuffer(BYTE *pBuf, DWORD dwSize)
{
	sha256_ctx hashctx;
	BYTE aTemp[32];
	DWORD dw;

	ASSERT(pBuf != NULL);

	while(dwSize != 0)
	{
		m_dwCounter++;
		sha256_begin(&hashctx);
		sha256_hash(m_pPseudoRandom, INTRAND_SIZE, &hashctx);
		sha256_hash((BYTE *)&m_dwCounter, 4, &hashctx);
		sha256_end(aTemp, &hashctx);

		dw = (dwSize < 32) ? dwSize : 32;
		memcpy(pBuf, aTemp, dw);
		pBuf += dw;
		dwSize -= dw;
	}
}

// Seed the xorshift random number generator
void srandXorShift(unsigned long *pSeed128)
{
	ASSERT(pSeed128 != NULL); // No NULL parameter allowed

	if((g_xorW == 0) && (g_xorX == 0) && (g_xorY == 0) && (g_xorZ == 0))
	{
		g_xorW = pSeed128[0];
		g_xorX = pSeed128[1];
		g_xorY = pSeed128[2];
		g_xorZ = pSeed128[3];

		if((g_xorW + g_xorX + g_xorY + g_xorZ) == 0) g_xorX += 0xB7E15163;
	}
}

// Fast XorShift random number generator
unsigned long randXorShift()
{
	unsigned long tmp;

	tmp = (g_xorX ^ (g_xorX << 15));
	g_xorX = g_xorY; g_xorY = g_xorZ; g_xorZ = g_xorW;
	g_xorW = (g_xorW ^ (g_xorW >> 21)) ^ (tmp ^ (tmp >> 4));

	return g_xorW;
}

void randCreateUUID(BYTE *pUUID16, CNewRandom *pRandomSource)
{
	SYSTEMTIME st;
	BYTE *p = pUUID16;
	DWORD *pdw1 = (DWORD *)pUUID16, *pdw2 = (DWORD *)&pUUID16[4],
		*pdw3 = (DWORD *)&pUUID16[8], *pdw4 = (DWORD *)&pUUID16[12];

	ASSERT(pRandomSource != NULL);

	ASSERT((sizeof(DWORD) == 4) && (sizeof(USHORT) == 2) && (pUUID16 != NULL));
	if(pUUID16 == NULL) return;

	ZeroMemory(&st, sizeof(SYSTEMTIME));
	GetSystemTime(&st);

	_PackTimeToStruct(p, st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
	p += 5; // +5 => 5 bytes filled
	*p = (BYTE)((st.wMilliseconds >> 2) & 0xFF); // Store milliseconds
	p++; // +1 => 6 bytes filled

	// Use the xorshift random number generator as pseudo-counter
	DWORD dwPseudoCounter = randXorShift();
	memcpy(p, &dwPseudoCounter, 2); // Use only 2/4 bytes
	p += 2; // +2 => 8 bytes filled

	pRandomSource->GetRandomBuffer(p, 8); // +8 => 16 bytes filled

	// Mix buffer for better read- and processability using PHTs
	*pdw1 += *pdw2; *pdw2 += *pdw1; *pdw3 += *pdw4; *pdw4 += *pdw3;
	*pdw2 += *pdw3; *pdw3 += *pdw2; *pdw1 += *pdw4; *pdw4 += *pdw1;
	*pdw1 += *pdw3; *pdw3 += *pdw1; *pdw2 += *pdw4; *pdw4 += *pdw2;
	*pdw1 += *pdw2; *pdw2 += *pdw1; *pdw3 += *pdw4; *pdw4 += *pdw3;
	*pdw2 += *pdw3; *pdw3 += *pdw2; *pdw1 += *pdw4; *pdw4 += *pdw1;
	*pdw1 += *pdw3; *pdw3 += *pdw1; *pdw2 += *pdw4; *pdw4 += *pdw2;
}
                                                                                                                                                                                                                                                                                          #include "StdAfx.h"
#include "RegUtil.h"

const static int nMaxValueNameSize = MAX_PATH;
const static int nMaxValueValueSize = 4096;
const static int nMaxClassSize = MAX_PATH;
const static int nMaxKeyNameSize = MAX_PATH;

static BOOL CopyKeys(HKEY hkFrom, HKEY hkTo) 
{
	TCHAR lpstrName[nMaxKeyNameSize];
	TCHAR lpstrClass[nMaxClassSize];

	for (int i = 0;;i++) {
		DWORD nNameSize = nMaxKeyNameSize;
		DWORD nClassSize = nMaxClassSize;
		LONG res = ::RegEnumKeyEx(hkFrom, i, lpstrName, &nNameSize, 0, lpstrClass, &nClassSize, 0);
		if (ERROR_NO_MORE_ITEMS == res) {
			break;
		}
		HKEY hkNew;
		res = ::RegCreateKeyEx(hkTo, lpstrName, 0, lpstrClass, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, 0, &hkNew, 0); ;
		if (ERROR_SUCCESS != res) {
			return FALSE;		
		}
		::RegCloseKey(hkNew);
		BOOL bRes = CopyRegistryKey(hkFrom, lpstrName, hkTo, lpstrName);
		if (! bRes) {
			return FALSE;		
		}
	}

	return TRUE;
}

static BOOL CopyValues(HKEY hkFrom, HKEY hkTo) 
{
	TCHAR lpstrName[nMaxValueNameSize];
	BYTE pValue[nMaxValueValueSize];

	for (int i = 0;;i++) {
		DWORD nType;
		DWORD nNameSize = nMaxValueNameSize;
		DWORD nValueSize = nMaxValueValueSize;
		LONG res = ::RegEnumValue(hkFrom, i, lpstrName, &nNameSize, 0, &nType, pValue, &nValueSize);
		if (ERROR_NO_MORE_ITEMS == res) {
			break;
		}
		res = ::RegSetValueEx(hkTo, lpstrName, 0, nType, pValue, nValueSize);
		if (ERROR_SUCCESS != res) {
			return FALSE;		
		}
	}

	return TRUE;
}

BOOL CopyRegistryKey(HKEY hkRootFrom, const CString& strFromPath, HKEY hkRootTo, const CString& strToPath) 
{
	HKEY hkFrom;
	LONG res = ::RegOpenKeyEx(hkRootFrom, strFromPath, 0, KEY_READ, &hkFrom);
	if (ERROR_SUCCESS != res) {
		return FALSE;	
	}
	HKEY hkTo;
	res = ::RegCreateKeyEx(hkRootTo, strToPath, 0, 0, REG_OPTION_NON_VOLATILE, KEY_WRITE, 0, &hkTo, 0);
	if (ERROR_SUCCESS != res) {
		::RegCloseKey(hkFrom);
		return FALSE;	
	}
	BOOL bRes = CopyKeys(hkFrom, hkTo) && CopyValues(hkFrom, hkTo);

	::RegCloseKey(hkFrom);
	::RegCloseKey(hkTo);

	return bRes;
}
                                                                                                                                                                                                                                                                                                                   