)
		return InsertItem(nRow, sRowText, nImage);

	// else
	return InsertItem(nRow, sRowText);
}

int CInputListCtrl::AddRow(CString sRowText, int nImage)
{
	return InsertRow(sRowText, GetItemCount(), nImage);
}

int CInputListCtrl::AddCol(CString sColText, int nWidth)
{
	int nCol;

	nCol = GetColumnCount();

	if (m_bAutoAddCols)
		nCol--; // add before prompt

	nCol = InsertColumn(nCol, sColText, LVCFMT_LEFT, nWidth == -1 ? m_nAutoColWidth : nWidth);
	SetItemText(0, nCol, sColText);

	return nCol;
}


void CInputListCtrl::OnSetFocus(CWnd* pOldWnd) 
{
//	if (m_bEditingCell)
//		m_bEditingCell = FALSE;

	CEnListCtrl::OnSetFocus(pOldWnd);

	if (GetCurSel() == -1)
	{
		if (GetItemCount())
		{
			SetCurSel(0, 0);
			SetItemFocus(0, TRUE); // set focus
		}
	}
	else
		SetItemFocus(GetCurSel(), TRUE); // reset focus
}

void CInputListCtrl::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// if we're editing then quit editing
	if (m_nEditItem != -1 || m_nEditCol != -1)
	{
		GetEditControl()->Hide();
		OnCancelEdit();
	}

	CEnListCtrl::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CInputListCtrl::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// if we're editing then quit editing
	if (m_nEditItem != -1 && m_nEditCol != -1)
	{
		GetEditControl()->Hide();
		OnCancelEdit();
	}

	CEnListCtrl::OnVScroll(nSBCode, nPos, pScrollBar);
}

CRect CInputListCtrl::ScrollCellIntoView(int nRow, int nCol)
{
	CRect rClient, rIntersect, rCell;
	CPoint ptItem;
	CSize sizeScroll;
//	int nColStart, nColEnd;

	// do nothing if invalid coords
	if (nRow == -1 || nCol == -1)
		return CRect(0, 0, 0, 0);

	// note: amount to scroll is relative to current position
	// so we need to determine whether the entire cell is visible and
	// if not, how much to scroll to bring it into view.
	GetClientRect(rClient);
	GetCellRect(nRow, nCol, rCell);

	// if the cell is completely contained within the client area
	// we don't need to scroll
	rIntersect.IntersectRect(rClient, rCell);

	if (rIntersect != rCell)
	{
		// calc how much to scroll
		if (rCell.left <= 0)
		{
			sizeScroll.cx = rCell.left;
		}
		else if (rCell.right >= rClient.right)
		{
			sizeScroll.cx = min(rCell.left, rCell.right - rClient.right);
		}
		else 
			sizeScroll.cx = 0;

		if (rCell.top < 0)
		{
			sizeScroll.cy = rCell.top;
		}
		else if (rCell.bottom > rClient.bottom)
		{
			sizeScroll.cy = rCell.bottom - rClient.bottom;
		}
		else 
			sizeScroll.cy = 0;

		// now, listctrls only scroll by whole lines so..
		if (sizeScroll.cy > 0 && sizeScroll.cy % rCell.Height() != 0)
			sizeScroll.cy += rCell.Height();

		// do the scroll
		if (sizeScroll != CSize(0, 0))
			Scroll(sizeScroll);

		// calc final cell position
		GetCellRect(nRow, nCol, rCell);
	}

	return rCell;
}

void CInputListCtrl::GetCellEditRect(int nRow, int nCol, CRect& rCell)
{
	switch (GetColumnType(nCol))
	{
	case TEXT:
	case BROWSE:
		CEnListCtrl::GetCellRect(nRow, nCol, rCell);
		
		rCell.right++;
		
		// move top edge up one pixel so that it looks right
		// but not of the first row else it gets clipped 
		// by the window border
		if (nRow > 0)
			rCell.top--;
		break;

	case DROPLIST:
		CEnListCtrl::GetCellRect(nRow, nCol, rCell);
		
		rCell.OffsetRect(1, -1);
		rCell.left--;
		break;
	}
}

void CInputListCtrl::SetView(int nView)
{
	// this control only supports LVS_REPORT view
	ASSERT (nView == LVS_REPORT);
	UNREFERENCED_PARAMETER(nView);

	CEnListCtrl::SetView(LVS_REPORT);
}

void CInputListCtrl::PreSubclassWindow()
{
	CEnListCtrl::PreSubclassWindow();

	// make sure we clip out the edit field
	ModifyStyle(0, WS_CLIPCHILDREN);
}

int CInputListCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CEnListCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	return 0;
}

CPopupEditCtrl* CInputListCtrl::GetEditControl()
{
	ASSERT (m_hWnd);

	if (!m_hWnd)
		return NULL;

	if (!m_editBox.m_hWnd)
		m_editBox.Create(this, IDC_EDITBOX, WS_CHILD | WS_BORDER);
//		m_editBox.Create(this, IDC_EDITBOX, WS_POPUP);

	return &m_editBox;
}

void CInputListCtrl::OnEndEdit(UINT /*uIDCtrl*/, int* pResult)
{
	CString sText, sMessage;
	int nLastRow, nLastCol, nIndex, nNumCols, nNumRows;
	BOOL bNotifyParent = FALSE;
	BOOL bItemDeleted = FALSE;

	nLastRow = GetItemCount() - 1;
	nLastCol = GetColumnCount()