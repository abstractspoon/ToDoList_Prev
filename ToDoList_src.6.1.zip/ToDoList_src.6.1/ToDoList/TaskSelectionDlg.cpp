<?xml version="1.0" ?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
	<xsl:strip-space elements="*" />
	
	<xsl:template match="TODOLIST">
		<xsl:element name="html">
			<xsl:element name="head">
				<xsl:element name="title">
					<xsl:value-of select="@PROJECTNAME" />
				</xsl:element>
				<xsl:element name="style">
					body
					{
						font-family: Tahoma, serif;
						margin: 5px 5px 5px 5px;
						background-color : #C0C0C0;
						font-size: 11px;
					}
					
					h5
					{
						font-size: 8px;
					}
					
					.headerSpan
					{
						background-color: #C4D7FF;
						border-left: 1px solid #006699;
						border-right: 1px solid #006699;
						border-bottom: 1px solid #006699;
						border-top: 1px solid #006699;
						padding-top: 2px; 
						padding-bottom: 2px;
						font-size: 11px;
						text-align: center;
						width :100%;
					}
					
					.footerSpan
					{
						background-color: #C4D7FF;
						border-left: 1px solid #006699;
						border-right: 1px solid #006699;
						border-bottom: 1px solid #006699;
						border-top: 1px solid #006699;
						padding-top: 2px; 
						padding-bottom: 2px;
						font-size: 11px;
						text-align: center;
						width :100%;
					}
					
					.masterTaskSpan
					{
						background-color: #FFFFFF;
						border-left: 1px solid #006699;
						border-right: 1px solid #006699;
						border-bottom: 1px solid #006699;
						border-top: 1px solid #006699;
						padding-top: 2px; 
						padding-bottom: 2px;
						padding-left: 2px; 
						padding-right: 2px;
						font-size: 11px;
						text-align: left;
						width :100%;
					}
					
					.completedMasterTaskSpan
					{
						background-color: #778899;
						border-left: 1px solid #006699;
						border-right: 1px solid #006699;
						border-bottom: 1px solid #006699;
						border-top: 1px solid #006699;
						padding-top: 2px; 
						padding-bottom: 2px;
						padding-left: 2px; 
						padding-right: 2px;
						font-size: 11px;
						text-align: left;
						width :100%;
					}
					
					.percentBarHolder
					{
						background-color: #4169E1;
						border-left: 1px solid #006699;
						border-right: 1px solid #006699;
						border-bottom: 1px solid #006699;
						border-top: 1px solid #006699;
						text-align: left;
						width :100px;
						height: 12px;
					}
					
					.percentBar
					{
						background-color: #8B0000;
					}
					
					.prettyPriority
					{
						width:20px;
						text-align:center;
						color: white;
					}
										
					.masterCompletedTaskTitleText
					{
						font-weight: bold;
						color: #C0C0C0;
						text-decoration: line-through;
					}
					
					.masterTaskTitleText
					{
						font-weight: bold;
						color: #000000;
					}
					
					.subCompletedTaskTitleText
					{
						font-weight: bold;
						color: #C0C0C0;
						text-decoration: line-through;
					}
					
					.subTaskTitleText
					{
						font-weight: bold;
						color: #000000;
					}
					
					.completedBaseInfoText
					{
						color: #C0C0C0;
					}
					
					.baseInfoText
					{
						color: #000000;
					}
					
					.completedDatesText
					{
						color: #C0C0C0;
					}
					
					.datesText
					{
						color: #000000;
					}
					
					.completedPeopleText
					{
						color: #C0C0C0;
					}
					
					.peopleText
					{
						color: #000000;
					}
					
					.completedCommentsText
					{
						color: #C0C0C0;
					}
					
					.commentsText
					{
						color: #000000;
					}
					
					.priorityNumberStyle
					{
						font-weight: bold;
					}
				</xsl:element>
			</xsl:element>
			<xsl:element name="body">
				<!-- HEADER SPAN -->
				<xsl:element name="span">
					<xsl:attribute name="class">headerSpan</xsl:attribute>
					<xsl:element name="h2">Project Summary</xsl:element>
					<xsl:choose>
						<xsl:when test="@REPORTTITLE">
							<xsl:element name="h3"><xsl:value-of select="@REPORTTITLE" /></xsl:element>
						</xsl:when>
						<xsl:otherwise>
							<xsl:element name="h3"><xsl:value-of select="@PROJECTNAME" /></xsl:element>
						</xsl:otherwise>
					</xsl:choose>
					<xsl:value-of select="@REPORTDATE" />
				</xsl:element>
				
				<!-- SPACER -->
				<xsl:element name="br"/>
				<xsl:element name="br"/>
				
				<!-- TASK INFORMATION -->
				<xsl:apply-templates />
				
				<!-- FOOTER SPAN -->
				<xsl:element name="span">
					<xsl:attribute name="class">footerSpan</xsl:attribute>
					<xsl:element name="h5">Generated from TodoList - http://www.abstractspoon.com<xsl:element name="br"/>Using TodoListStyler v1.0</xsl:element>
				</xsl:element>
			</xsl:element>
		</xsl:element>
	</xsl:template>
	
	<xsl:template match="TASK">
		<xsl:choose>
			<xsl:when test="TASK">
				<xsl:choose>
					<xsl:when test="parent::TODOLIST">
						<!-- master tasks -->
						<xsl:element name="span">
							<xsl:choose>
								<xsl:when test="@DONEDATESTRING">
									<xsl:attribute name="class">completedMasterTaskSpan</xsl:attribute>
								</xsl:when>
								<xsl:otherwise>
									<xsl:attribute name="class">masterTaskSpan</xsl:attribute>
								</xsl:otherwise>
							</xsl:choose>
							<xsl:call-template name="get_Task_Details" />
							<xsl:element name="ul">
								<xsl:apply-templates />
							</xsl:element>
						</xsl:element>
						<xsl:element name="br"/>
						<xsl:element name="br"/>
					</xsl:when>
					<xsl:otherwise>
						<!-- sub tasks -->
						<xsl:call-template name="get_Task_Details" />
						<xsl:element name="ul">
							<xsl:apply-templates />
						</xsl:element>
					</xsl:otherwise>
				</xsl:choose>
			</xsl:when>
			<xsl:otherwise>
				<xsl:choose>
					<xsl:when test="parent::TODOLIST">
						<!-- master tasks that do not contain any sub tasks -->
						<xsl:element name="span">
							<xsl:choose>
								<xsl:when test="@DONEDATESTRING">
									<xsl:attribute name="class">completedMasterTaskSpan</xsl:attribute>
								</xsl:when>
								<xsl:otherwise>
									<xsl:attribute name="class">masterTaskSpan</xsl:attribute>
								</xsl:otherwise>
							</xsl:choose>
							<xsl:call-template name="get_Task_Details" />
							<xsl:element name="ul">
								<xsl:apply-templates />
							</xsl:element>
						</xsl:element>
						<xsl:element name="br"/>
						<xsl:element name="br"/>
					</xsl:when>
					<xsl:otherwise>
						<!-- sub tasks -->
	