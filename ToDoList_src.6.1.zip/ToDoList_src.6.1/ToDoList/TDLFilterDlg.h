pTasks->GetTaskWebColor(hTask);

		if (bDone && pTasks->TaskHasAttribute(hTask, TDL_TASKDONEDATESTRING))
			sDoneDate.Format(" (completed: %s)", pTasks->GetTaskDoneDateString(hTask));

		if (pTasks->TaskHasAttribute(hTask, TDL_TASKHIGHESTPRIORITY) ||
			pTasks->TaskHasAttribute(hTask, TDL_TASKPRIORITY))
		{
			int nPriority = pTasks->GetTaskPriority(hTask, TRUE);
			
			if (nPriority >= 0)
			{
				CString sPriorityCol = pTasks->GetTaskPriorityWebColor(hTask);
				sPriority.Format("[<font color='%s'>%d</font>] ", sPriorityCol, nPriority);
			}
			else
				sPriority = "[ ]";
		}
		
		FormatAttribute(pTasks, hTask, TDL_TASKSTARTDATESTRING, " (start: %s)", sStartDate);
		FormatAttribute(pTasks, hTask, TDL_TASKDUEDATESTRING, " (due: %s)", sDueDate);
		
		if (pTasks->TaskHasAttribute(hTask, TDL_TASKPERCENTDONE))
			sPercent.Format(" (%d%%) ", nPercent);

			if (pTasks->TaskHasAttribute(hTask, TDL_TASKTIMEESTIMATE) ||
				pTasks->TaskHasAttribute(hTask, TDL_TASKCALCTIMEESTIMATE))
				sTimeEst.Format(" (time est: %.*f hrs)", nTimePlaces, pTasks->GetTaskTimeEstimate(hTask, cTemp, TRUE));

		if (pTasks->TaskHasAttribute(hTask, TDL_TASKTIMESPENT) ||
			pTasks->TaskHasAttribute(hTask, TDL_TASKCALCTIMESPENT))
			sTimeSpent.Format(" (time spent: %.*f hrs)", nTimePlaces, pTasks->GetTaskTimeSpent(hTask, cTemp, TRUE));
		
		FormatAttribute(pTasks, hTask, TDL_TASKCREATIONDATESTRING, " (created: %s)", sCreateDate);
		FormatAttribute(pTasks, hTask, TDL_TASKCREATEDBY, " (created by: %s)", sCreateBy);
		FormatAttributeList(pTasks, hTask, TDL_TASKNUMALLOCTO, TDL_TASKALLOCTO, " (allocated to: %s)", sAllocTo);
		FormatAttribute(pTasks, hTask, TDL_TASKALLOCBY, " (allocated by: %s)", sAllocBy);
		FormatAttributeList(pTasks, hTask, TDL_TASKNUMCATEGORY, TDL_TASKCATEGORY, " (category: %s)", sCategory);
		FormatAttribute(pTasks, hTask, TDL_TASKSTATUS, " (status: %s)", sStatus);
		FormatAttribute(pTasks, hTask, TDL_TASKRISK, " (risk: %s)", sRisk);
		FormatAttribute(pTasks, hTask, TDL_TASKEXTERNALID, " (ext.ID: %s)", sExtID);
		FormatAttribute(pTasks, hTask, TDL_TASKLASTMODSTRING, " (last mod: %s)", sLastMod);
		FormatAttribute(pTasks, hTask, TDL_TASKCOST, " (cost: %s)", sCost);
		FormatAttribute(pTasks, hTask, TDL_TASKVERSION, " (version: %s)", sVersion);
		FormatAttribute(pTasks, hTask, TDL_TASKRECURRENCE, " 