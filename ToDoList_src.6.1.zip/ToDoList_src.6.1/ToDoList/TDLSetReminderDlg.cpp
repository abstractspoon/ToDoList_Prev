/* PERF__FREZ/PUB
 * ====================================================
 * BigCalendarCtrl.cpp : implementation file
 * Frederic Rezeau
 * 
 * Perf'Control Personal Edition calendar 
 *
 * If you like it, feel free to use it. 
 *
 * www.performlabs.com 
 * ==================================================== 
 * Original file written by Frederic Rezeau (http://www.codeproject.com/KB/miscctrl/CCalendarCtrl.aspx)
 * Rewritten for the ToDoList (http://www.codeproject.com/KB/applications/todolist2.aspx)
 * Design and latest version - http://www.codeproject.com/KB/applications/TDL_Calendar.aspx
 * by demon.code.monkey@googlemail.com
 */

#include "stdafx.h"
#include "BigCalendarCtrl.h"
#include "BigCalendarTask.h"
#include "MemDC.h"
#include "CalendarDefines.h"
#include "CalendarUtils.h"
#include "CalendarData.h"
#include "..\..\CalendarExt\CalendarFrameWnd.h"
#include "..\..\Shared\DateHelper.h"
#include "..\..\Shared\GraphicsMisc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//fonts
#define BIGCAL_FONT_NAME			"Tahoma"
#define BIGCAL_FONT_SIZE			8

//colours
#define COLOUR_TASKS				RGB(0,0,0)
#define COLOUR_DAYNUMBERS			RGB(70,70,70)
#define COLOUR_WHITE				RGB(255,255,255)
#define COLOUR_BACKGROUND			COLOUR_WHITE
#define COLOUR_INVALID_DATE			RGB(255,225,225)
#define COLOUR_IMPORTANTDAY_MARKER	RGB(255,255,100)
#define COLOUR_GRIDLINES			RGB(125,175,255)
#define COLOUR_SELECTED_DAYNUMBER	COLOUR_DAYNUMBERS
#define COLOUR_MULTIPLE_TASK_ARROW	RGB(170,170,170)
#define COLOUR_MONTHNAMES			RGB(0,0,255)


/////////////////////////////////////////////////////////////////////////////
// CBigCalendarCtrl

CBigCalendarCtrl::CBigCalendarCtrl()
:	m_pFrameWnd(NULL),
	m_pCalendarData(NULL),
	m_pFont(NULL),
	m_pFontBold(NULL),
	m_hwndMessageRoutingWindow(NULL),
	m_bTracking(FALSE),
	m_bMonthIsOdd(FALSE),
	m_nFirstWeekDay(-1),
	m_nSelectedTaskID(-1),
	m_nVscrollMax(100),	//this is enough for a two-year range
	m_nVscrollPos(50)
{
	m_nFirstWeekDay = CDateHelper::FirstDayOfWeek();

	CCalendarUtils::GetToday(m_dateSelected);	//today's date

	m_pFont = new CFont;
	GraphicsMisc::CreateFont(*m_pFont, BIGCAL_FONT_NAME, BIGCAL_FONT_SIZE);

	m_pFontBold = new CFont;
	GraphicsMisc::CreateFont(*m_pFontBold, BIGCAL_FONT_NAME, BIGCAL_FONT_SIZE, MFS_BOLD);
}

CBigCalendarCtrl::~CBigCalendarCtrl()
{
	for (POSITION pos = m_listCalendarTasks.GetHeadPosition(); pos != NULL; )
	{
		delete (CBigCalendarTask*)(m_listCalendarTasks.GetNext(pos));
	}
	m_listCalendarTasks.RemoveAll();

	m_pFont->DeleteObject();
	m_pFontBold->DeleteObject();
	delete m_pFont;
	delete m_pFontBold;
}

void CBigCalendarCtrl::Initialize(CCalendarFrameWnd* _pFrameWnd,
								  CCalendarData* _pCalendarData,
								  HWND _hwndMessageRoutingWindow)
{
	m_pFrameWnd = _pFrameWnd;
	m_pCalendarData = _pCalendarData;
	m_hwndMessageRoutingWindow = _hwndMessageRoutingWindow;
}


BEGIN_MESSAGE_MAP(CBigCalendarCtrl, CWnd)
	//{{AFX_MSG_MAP(CBigCalendarCtrl)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_VSCROLL()
	ON_WM_MOUSEWHEEL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CBigCalendarCtrl::Create(DWORD _dwStyle,
							  const CRect& _rect,
							  CWnd* _pParent,
							  UINT _nID)
{
	BOOL bResult = CWnd::CreateEx(NULL, NULL, NULL, _dwStyle, _rect, _pParent, _nID);

	//this line seems to be needed here, to avoid problems with tooltips only appearing in one listbox
	EnableToolTips();

	SetScrollRange(SB_VERT, 0, m_nVscrollMax, FALSE);

	COleDateTime dtToday;
	CCalendarUtils::GetToday(dtToday);

	if (!CCalendarUtils::IsDateValid(dtToday))
	{
		ASSERT(FALSE);
		return bResult;
	}

	if (dtToday.GetMonth()%2) 
	{
		m_bMonthIsOdd = TRUE;
	}

	if (m_pFrameWnd->IsWeekendsHidden())
	{
		if (dtToday.GetDayOfWeek() == 1)
		{
			//sun
			dtToday -= 2;
		}
		else if (dtToday.GetDayOfWeek() == 7)
		{
			//sat
			dtToday -= 1;
		}
	}

	GotoMonth(dtToday);

	SetScrollPos(SB_VERT, m_nVscrollPos, TRUE);

	CreateTasks();

	return bResult;
}

void CBigCalendarCtrl::Repopulate()
{
	CreateTasks(TRUE);

	TasklistUpdated();

	//ensure that if number of weeks have been changed, current date may not be visible. if so, select it again
	if (!IsDateVisible(m_dateSelected))
	{
		Goto(m_dateSelected, TRUE);
	}
}

void CBigCalendarCtrl::SelectDate(const COleDateTime& _date)
{
	LeaveCell();
	Goto(_date, TRUE);
}

void CBigCalendarCtrl::TasklistUpdated()
{
	//just refresh the data in the view
	COleDateTime dtFirstCell(m_dayCells[0][0].date);	//current first-cell
	RepopulateAllCells(dtFirstCell);

	SendSelectDateMessageToParent(FALSE);
}

void CBigCalendarCtrl::ClickedOnTaskInListbox()
{
	SendSelectDateMessageToParent(TRUE);
}

void CBigCalendarCtrl::SelectTask(int _nTaskListboxID,
								  int _nTaskID)
{
	int nNumColumns = m_pFrameWnd->GetNumDaysToDisplay();
	int nNumWeeks = m_pFrameWnd->GetNumWeeksToDisplay();

	//unselect all listboxes apart from _nTaskListboxID
	for (int i = 0; i < nNumWeeks; i++)
	{
		for (int u = 0; u < nNumColumns; u++)
		{
			if (m_dayCells[i][u].nListboxID == _nTaskListboxID)
			{
				//store the date of the newly selected task
				m_dateSelected = m_dayCells[i][u].date;
			}
			else
			{
				CBigCalendarTask* pWndTask = GetTaskListboxFromCell(i, u);
				if (pWndTask)
				{
					pWndTask->SetCurSel(-1);
				}
			}
		}
	}

	//store the newly selected task ID
	m_nSelectedTaskID = _nTaskID;

	Invalidate();


	//////////////////////////////////////////////////////////////////////////////////////////
	//select the newly selected task in the active tasklist, by sending a SELECTTASK message 
	CWnd* pFocus = GetFocus();

	DWORD dwTaskID = 0;
	CBigCalendarTask* pListbox = GetTaskListboxFromTaskListboxID(_nTaskListboxID);
	if (pListbox)
	{
		dwTaskID = ((SItem*)pListbox->GetItemData(_nTaskID))->dwItemData;
	}

	if (dwTaskID != 0)
	{
		COPYDATASTRUCT cds;
		cds.dwData = 3;//SELECTTASK;	//can't use SELECTTASK because including ToDoListWnd.h would break the build
		cds.cbData = sizeof(DWORD);
		cds.lpData = &dwTaskID;
		::SendMessage(m_hwndMessageRoutingWindow, WM_COPYDATA, NULL, (LPARAM)&cds);
	}
	else
	{
		ASSERT(FALSE);	//task ID not found
	}

	//set focus to the previously focussed window (the active tasklist steals the focus when it gets the SELECTTASK message)
	pFocus->SetFocus();
}

void C