tual COLORREF GetItemTextColor(int nItem, int nCol, BOOL bSelected, BOOL bDropHighlighted, BOOL bWndFocus);
	virtual COLORREF GetItemBackColor(int nItem, BOOL bSelected, BOOL bDropHighlighted, BOOL bWndFocus);
	virtual CColumnData* GetNewColumnData() const { return new CColumnData2; }
	const CColumnData2* GetColumnData(int nCol) const;
	virtual int CompareItems(DWORD dwItemData1, DWORD dwItemData2, int nSortColumn);
	int InsertRow(CString sRowText, int nItem, int nImage = -1);
	virtual void GetCellEditRect(int nRow, int nCol, CRect& rCell);
	virtual BOOL IsEditing() const { return m_editBox.GetSafeHwnd() && m_editBox.IsWindowVisible(); }
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INPUTLISTCTRL_H__2E5810B0_D7DF_11D1_AB19_0000E8425C3E__INCLUDED_)
                                                           TDLMultiSortDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTDLMultiSortDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeSortby1();
	afx_msg void OnSelchangeSortby2();
	afx_msg void OnSelchangeSortby3();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	void BuildCombos();

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TDLMULTISORTDLG_H__95734250_E60B_48CF_B356_1394C11317DA__INCLUDED_)
