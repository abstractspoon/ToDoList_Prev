// TaskListCsvExporter.cpp: implementation of the CTaskListCsvExporter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TaskListCsvExporter.h"
#include "tdlschemadef.h"
#include "resource.h"
#include "recurringtaskedit.h"

#include <locale.h>

#include "..\shared\timehelper.h"
#include "..\shared\enstring.h"
#include "..\shared\misc.h"
#include "..\shared\Preferences.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const LPCTSTR SPACE = " ";
const LPCTSTR ENDL = "\n";
const LPCTSTR ONEDBLQUOTE = "\"";
const LPCTSTR TWODBLQUOTE = "\"\"";

CTaskListCsvExporter::CTaskListCsvExporter()
{

}

CTaskListCsvExporter::~CTaskListCsvExporter()
{

}

bool CTaskListCsvExporter::Export(const ITaskList* pSrcTaskFile, const char* szDestFilePath, BOOL /*bSilent*/)
{
	const ITaskList6* pTasks6 = GetITLInterface<ITaskList6>(pSrcTaskFile, IID_TASKLIST6);
	
	if (!pTasks6)
		return false;

	CPreferences prefs;

	DELIM = Misc::GetListSeparator();
	ROUNDTIMEFRACTIONS = prefs.GetProfileInt("Preferences", "RoundTimeFractions", FALSE);

	if (prefs.GetProfileInt("Preferences", "UseSpaceIndents", TRUE))
		INDENT = CString(' ', prefs.GetProfileInt("Preferences", "TextIndent", 2));
	else
		INDENT = "  "; // don't use tabs - excel strips them off

	CStdioFile fileOut;

	if (fileOut.Open(szDestFilePath, CFile::modeCreate | CFile::modeWrite))
	{
		// clear attrib list before rebuilding
		m_aAttribs.RemoveAll();
		BuildAttribList(pTasks6, NULL);
		
		CString sOutput;

		if (!ExportTask(pTasks6, NULL, 0, 0, "", sOutput).IsEmpty())
		{
			fileOut.WriteString(ColumnHeadings());
	