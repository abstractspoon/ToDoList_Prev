<?xml version="1.0" encoding="UTF-8"?>
<!-- edited with XMLSpy v2009 sp1 (http://www.altova.com) by steve (EMBRACE) -->
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
	<xs:element name="TODOLIST">
		<xs:complexType>
			<xs:sequence>
				<xs:element name="TASK" maxOccurs="unbounded">
					<xs:complexType >
						<xs:attribute name="ALLOCATEDBY" />
						<xs:attribute name="CALCCOST" />
						<xs:attribute name="CALCPERCENTDONE" />
						<xs:attribute name="CALCTIMEESTIMATE" />
						<xs:attribute name="CALCTIMESPENT" />
						<xs:attribute name="CATEGORY" />
						<xs:attribute name="CATEGORY1" />
						<xs:attribute name="CATEGORY2" />
						<xs:attribute name="CATEGORY3" />
						<xs:attribute name="CATEGORY4" />
						<xs:attribute name="CATEGORY5" />
						<xs:attribute name="CATEGORY6" />
						<xs:attribute name="CATEGORY7" />
						<xs:attribute name="CATEGORY8" />
						<xs:attribute name="CATEGORY9" />
						<xs:attribute name="COLOR" />
						<xs:attribute name="COMMENTS" />
						<xs:attribute name="COMMENTSTYPE" 