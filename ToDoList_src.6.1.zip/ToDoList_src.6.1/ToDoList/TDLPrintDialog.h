ific2, BOOL bRecalcFromDue, int nReuse) = 0;
	virtual bool GetTaskRecurrence(HTASKITEM hTask, int& nRegularity, DWORD& dwSpecific1, 
									DWORD& dwSpecific2, BOOL& bRecalcFromDue, int& nReuse) const = 0;

	virtual bool SetTaskVersion(HTASKITEM hTask, const char* szVersion) = 0;
	virtual const char* GetTaskVersion(HTASKITEM hTask) const = 0;
};

class ITaskList7 : public ITaskList6
{
	// new methods
public:
	virtual unsigned char GetTaskDependencyCount(HTASKITEM hTask) const = 0;
	virtual bool AddTaskDependency(HTASKITEM hTask, const char* szDepends) = 0;
	virtual const char* GetTaskDependency(HTASKITEM hTask, int nIndex) const = 0;

	virtual unsigned char GetTaskAllocatedToCount(HTASKITEM hTask) const = 0;
	virtual bool AddTaskAllocatedTo(HTASKITEM hTask, const char* szAllocTo) = 0;
	virtual const char* GetTaskAllocatedTo(HTASKITEM hTask, int nIndex) const = 0;
};

#endif // _ITASKLIST_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_                                                  	m_sTitle;
	BOOL	m_bDate;
	BOOL	m_bUseStylesheet;
	BOOL	m_bPreview;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTDLPrintDialog)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTDLPrintDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeStylesheet();
	//}}AFX_MSG
    afx_msg void OnUsestylesheet();
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TDLPRINTDIALOG_H__1A62F94F_687F_421C_97D2_300BAC4A3E7C__INCLUDED_)
