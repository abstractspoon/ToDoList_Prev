ect="@TITLE" />
				</xsl:element>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	
	<!--
	Retrieves summary information for task
	-->
	<xsl:template name="get_Task_Base_Info">
		<xsl:element name="span">
			<!-- choose style to use based on completion -->
			<xsl:choose>
				<xsl:when test="@DONEDATESTRING"><xsl:attribute name="class">completedBaseInfoText</xsl:attribute></xsl:when>
				<xsl:otherwise><xsl:attribute name="class">baseInfoText</xsl:attribute></xsl:otherwise>
			</xsl:choose>

			<!-- elements that always exist -->
			<xsl:element name="a">[Task ID: <xsl:value-of select="@ID" />]</xsl:element>
			<xsl:element name="a"><xsl:call-template name="get_Pretty_Priority" /></xsl:element>
			<xsl:element name="a"><xsl:call-template name="get_Pretty_Percent_Bar" /></xsl:element>
			
			<!-- Status -->
			<xsl:choose>
				<xsl:when test="@STATUS">
					<xsl:element name="a">[Status: <xsl:value-of select="@STATUS" />]</xsl:element>
				</xsl:when>
				<xsl:otherwise>
					<xsl:element name="a">[Status: Not Set]</xsl:element>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:element>
	</xsl:template>
	
	<!--
	Gets a visual percent bar
	-->
	<xsl:template name="get_Pretty_Percent_Bar">
		<xsl:element name="span">[Completion: <xsl:value-of select="@PERCENTDONE" />% </xsl:element>
		<!-- only add percent bar if not 100 or 0 percent -->
		<xsl:if test="@PERCENTDONE&lt;100">
			<xsl:if test="@PERCENTDONE&gt;0">
				<xsl:element name="span">
					<xsl:attribute name="class">percentBarHolder</xsl:attribute>
					<xsl:element name="span">
						<xsl:attribute name="class">percentBar</xsl:attribute>
						<xsl:attribute name="style">width: <xsl:value-of select="@PERCENTDONE" />px</xsl:attribute>
					</xsl:element>
				</xsl:element>
			</xsl:if>
		</xsl:if>
		<xsl:element name="span">]</xsl:element>
	</xsl:template>
	
	<xsl:template name="get_Pretty_Priority">
		<xsl:element name="span">
			<xsl:element name="span">[Priority: </xsl:element>
			<xsl:element name="span">
				<xsl:attribute name="class">prettyPriority</xsl:attribute>
				<xsl:choose>
					<xsl:when test="@PRIORITY">
						<xsl:attribute name="style">background-color: <xsl:value-of select="@PRIORITYWEBCOLOR" /></xsl:attribute>
						<xsl:element name="a">
							<xsl:attribute name="class">priorityNumberStyle</xsl:attribute>
							<xsl:value-of select="@PRIORITY" />
						</xsl:element>
					</xsl:when>
					<xsl:otherwise>
						<xsl:attribute name="style">background-color: <xsl:value-of select="@PRIORITYWEBCOLOR" /></xsl:attribute>
						<xsl:element name="a">
							<xsl:attribute name="class">priorityNumberStyle</xsl:attribute>
							<xsl:text>0</xsl:text>
						</xsl:element>				
					</xsl:otherwise>
				</xsl:choose>
			</xsl:element>
			<xsl:element name="span">]</xsl:element>
		</xsl:element>
	</xsl:template>
	
	<!--
	gets task dates
	-->
	<xsl:template name="get_Task_Dates">
		<xsl:element name="span">
			<!-- choose style 