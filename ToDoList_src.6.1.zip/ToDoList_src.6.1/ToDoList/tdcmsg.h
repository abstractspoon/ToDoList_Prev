pdb:none /debug
# Begin Special Build Tool
SOURCE="$(InputPath)"
PostBuild_Cmds=mkdir ..\debug	copy debug\todolistloc.dll ..\debug /y
# End Special Build Tool

!ENDIF 

# Begin Target

# Name "ToDoLOC - Win32 Release"
# Name "ToDoLOC - Win32 Debug"
# Begin Source File

SOURCE=..\RES\bitmap1.bmp
# End Source File
# Begin Source File

SOURCE=..\RES\bmp00001.bmp
# End Source File
# Begin Source File

SOURCE=..\RES\cc_somerights.bmp
# End Source File
# Begin Source File

SOURCE=..\RES\checklistbox.bmp
# End Source File
# Begin Source File

SOURCE=..\RES\close.bmp
# End Source File
# Begin Source File

SOURCE=..\RES\find.bmp
# End Source File
# Begin Source File

SOURCE=..\RES\find.ico
# End Source File
# Begin Source File

SOURCE=..\RES\findtoolbar16.bmp
# End Source File
# Begin Source File

SOURCE=..\RES\findtoolbar24.bmp
# End Source File
# Begin Source File

SOURCE=..\RES\ico00001.ico
# End Source File
# Begin Source File

SOURCE=..\RES\icon2.ico
# End Source File
# Begin Source File

SOURCE=..\RES\mainfram.ico
# End Source File
# Begin Source File

SOURCE=..\RES\mainfrm.ico
# End Source File
# Begin Source File

SOURCE=..\Resource.h
# End Source File
# Begin Source File

SOURCE=..\RES\task_icons.bmp
# End Source File
# Begin Source File

SOURCE=..\RES\todolist.exe.manifest
# End Source File
# Begin Source File

SOURCE=..\res\ToDoList.ico
# End Source File
# Begin Source File

SOURCE=..\ToDoList.rc
# End Source File
# Begin Source File

SOURCE=..\res\ToDoList.rc2
# End Source File
# Begin Source File

SOURCE=..\res\toolbar.bmp
# End Source File
# Begin Source File

SOURCE=..\RES\toolbar16.bmp
# End Source File
# Begin Source File

SOURCE=..\RES\toolbar24.bmp
# End Source File
# Begin Source File

SOURCE=..\RES\trayicon.ico
# End Source File
# Begin Source File

SOURCE=..\RES\XPcheckboxes.bmp
# End Source File
# End Target
# End Project
                                                                      K"); // wParam = taskID, lParam = taskfile

// internal TDC message
const UINT WM_TDC_RESTOREFOCUSEDITEM			= (WM_APP + 1);
const UINT WM_TDC_REFRESHPERCENTSPINVISIBILITY	= (WM_APP + 2);
const UINT WM_TDC_REFRESHFILTER					= (WM_APP + 3);
const UINT WM_TDC_RECREATERECURRINGTASK			= (WM_APP + 4);



#endif // AFX_TDCMSG_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_