st 200 but always clipped to the client rect
//			rect.right = min(rect.right, rect.left + 200);
			
			CRect rClient, rInter;
			m_list.GetClientRect(rClient);
			
			if (rInter.IntersectRect(rect, rClient))
				rect = rInter;
			
			rect.top--;

			m_list.ClientToScreen(rect);
			ScreenToClient(rect);
			
			return TRUE;
		}
		break;
	}

	return FALSE;
}

void CFilteredToDoCtrl::OnListGetInfoTip(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMLVGETINFOTIP* pLVGIT = (NMLVGETINFOTIP*)pNMHDR;
	*pResult = 0;

	int nHit = pLVGIT->iItem;

	if (nHit >= 0)
	{
		HTREEITEM hti = GetTreeItem(nHit);
		TODOITEM* pTDI = GetTask(m_list.GetItemData(nHit));

		ASSERT (pTDI);

		if (!pTDI)
			return;

		// we only display info tips when over the task title
		CRect rTitle;
		CClientDC dc(&m_list);
		CFont* pOld = NULL;
		
		if (m_tree.GetParentItem(hti) == NULL) // top level item
			pOld = (CFont*)dc.SelectObject(CFont::FromHandle(m_fontBold));
		else
			pOld = (CFont*)dc.SelectObject(m_list.GetFont());
		
		GetItemTitleRect(nHit, TDCTR_LABEL, rTitle, &dc, pTDI->sTitle);
		
		// cleanup
		dc.SelectObject(pOld);
	
		CPoint pt(::GetMessagePos());
		m_list.ScreenToClient(&pt);
		
		if (rTitle.PtInRect(pt))
		{
			//fabio_2005
#if _MSC_VER >= 1400
			strncpy_s(pLVGIT->pszText, pLVGIT->cchTextMax, FormatInfoTip(hti, pTDI), pLVGIT->cchTextMax);
#else
			strncpy(pLVGIT->pszText, FormatInfoTip(hti, pTDI), pLVGIT->cchTextMax);
#endif
		}
	}
		
}

void CFilteredToDoCtrl::UpdateSelectedTaskPath()
{
	CToDoCtrl::UpdateSelectedTaskPath();

	// redraw the client column header
	if (m_header.GetSafeHwnd())
	{
		CRect rClient;

		if (m_header.GetItemRect(GetColumnIndex(TDCC_CLIENT), rClient))
			m_header.InvalidateRect(rClient, FALSE);
	}
}

void CFilteredToDoCtrl::SaveSortState(CPreferences& prefs)
{
	// ignore this if we have no tasks
	if (GetTaskCount() == 0)
		return;

	// create a new key using the filepath
	ASSERT (GetSafeHwnd());
	
	CString sKey = GetPreferencesKey("SortState");
	
	if (!sKey.IsEmpty())
	{
		prefs.WriteProfileInt(sKey, "ListMulti", m_bListMultiSort);
		prefs.WriteProfileInt(sKey, "ListColumn", m_sortList.nBy1);
		prefs.WriteProfileInt(sKey, "ListColumn2", m_sortList.nBy2);
		prefs.WriteProfileInt(sKey, "ListColumn3", m_sortList.nBy3);
		prefs.WriteProfileInt(sKey, "ListAscending", m_sortList.bAscending1);
		prefs.WriteProfileInt(sKey, "ListAscending2", m_sortList.bAscending2);
		prefs.WriteProfileInt(sKey, "ListAscending3", m_sortList.bAscending3);
	}

	// base class
	CToDoCtrl::SaveSortState(prefs);
}

void CFilteredToDoCtrl::LoadSortState(const CPreferences& prefs, LPCTSTR szFilePath)
{
	CString sKey = GetPreferencesKey("SortState", szFilePath);
	
	if (!sKey.IsEmpty())
	{
		// is this the first time since we restored tree sorting (disabled in 5.6)
		int nListSortBy = prefs.GetProfileInt(sKey, "ListColumn", -99);

		if (nListSortBy == -99) // yes
		{ 
			// so we use whatever the tree has set
			m_sortList.nBy1 = (TDC_SORTBY)prefs.GetProfileInt(sKey, "Column", TDC_UNSORTED);
			m_sortList.bAscending1 = prefs.GetProfileInt(sKey, "Ascending", TRUE);

			// and clear the tree's state
			m_sort.nBy1 = TDC_UNSORTED;
			m_sort.bAscending1 = -1;
		}
		else // each has separate settings
		{
			m_bListMultiSort = prefs.GetProfileInt(sKey, "ListMulti", FALSE);
			m_sortList.nBy1 = (TDC_SORTBY)prefs.GetProfileInt(sKey, "ListColumn", TDC_UNSORTED);
			m_sortList.nBy2 = (TDC_SORTBY)prefs.GetProfileInt(sKey, "ListColumn2", TDC_UNSORTED);
			m_sortList.nBy3 = (TDC_SORTBY)prefs.GetProfileInt(sKey, "ListColumn3", TDC_UNSORTED);
			m_sortList.bAscending1 = prefs.GetProfileInt(sKey, "ListAscending", TRUE);
			m_sortList.bAscending2 = prefs.GetProfileInt(sKey, "ListAscending2", TRUE);
			m_sortList.bAscending3 = prefs.GetProfileInt(sKey, "ListAscending3", TRUE);

			CToDoCtrl::LoadSortState(prefs, szFilePath);
		}

		m_sortList.nBy1 = max(m_sortList.nBy1, TDC_UNSORTED); // backwards compatibility
	}
}


void CFilteredToDoCtrl::RedrawReminders() const
{ 
	if (!InListView())
		CToDoCtrl::RedrawReminders();

	else if (IsColumnShowing(TDCC_REMINDER))
	{
		CListCtrl* pList = const_cast<