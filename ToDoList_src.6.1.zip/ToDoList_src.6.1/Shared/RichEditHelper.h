ates
//---------------------------------------------------------------------------------------
BEGIN_TM_CLASS_PARTS(HEADER)
    TM_PART(1, HP, HEADERITEM)
    TM_PART(2, HP, HEADERITEMLEFT)
    TM_PART(3, HP, HEADERITEMRIGHT)
    TM_PART(4, HP, HEADERSORTARROW)
END_TM_CLASS_PARTS()

BEGIN_TM_PART_STATES(HEADERITEM)
    TM_STATE(1, HIS, NORMAL)
    TM_STATE(2, HIS, HOT)
    TM_STATE(3, HIS, PRESSED)
END_TM_PART_STATES()

BEGIN_TM_PART_STATES(HEADERITEMLEFT)
    TM_STATE(1, HILS, NORMAL)
    TM_STATE(2, HILS, HOT)
    TM_STATE(3, HILS, PRESSED)
END_TM_PART_STATES()

BEGIN_TM_PART_STATES(HEADERITEMRIGHT)
    TM_STATE(1, HIRS, NORMAL)
    TM_STATE(2, HIRS, HOT)
    TM_STATE(3, HIRS, PRESSED)
END_TM_PART_STATES()

BEGIN_TM_PART_STATES(HEADERSORTARROW)
    TM_STATE(1, HSAS, SORTEDUP)
    TM_STATE(2, HSAS, SORTEDDOWN)
END_TM_PART_STATES()
//---------------------------------------------------------------------------------------
//   "Progress" Parts & States
//---------------------------------------------------------------------------------------
BEGIN_TM_CLASS_PARTS(PROGRESS)
    TM_PART(1, PP, BAR)
    TM_PART(2, PP, BARVERT)
    TM_PART(3, PP, CHUNK)
    TM_PART(4, PP, CHUNKVERT)
END_TM_CLASS_PARTS()

//---------------------------------------------------------------------------------------
//   "Tab" Parts & States
//---------------------------------------------------------------------------------------
BEGIN_TM_CLASS_PARTS(TAB)
    TM_PART(1, TABP, TABITEM)
    TM_PART(2, TABP, TABITEMLEFTEDGE)
    TM_PART(3, TABP, TABITEMRIGHTEDGE)
    TM_PART(4, TABP, TABITEMBOTHEDGE)
    TM_PART(5, TABP, TOPTABITEM)
    TM_PART(6, TABP, TOPTABITEMLEFTEDGE)
    TM_PART(7, TABP, TOPTABITEMRIGHTEDGE)
    TM_PART(8, TABP, TOPTABITEMBOTHEDGE)
    TM_PART(9, TABP, PANE)
    TM_PART(10, TABP, BODY)
END_TM_CLASS_PARTS()

BEGIN_TM_PART_STATES(TABITEM)
    TM_STATE(1, TIS, NORMAL)
    TM_STATE(2, TIS, HOT)
    TM_STATE(3, TIS, SELECTED)
    TM_STATE(4, TIS, DISABLED)
    TM_STATE(5, TIS, FOCUSED)
END_TM_PART_STATES()

BEGIN_TM_PART_STATES(TABITEMLEFTEDGE)
    TM_STATE(1, TILES, NORMAL)
    TM_STATE(2, TILES, HOT)
    TM_STATE(3, TILES, SELECTED)
  