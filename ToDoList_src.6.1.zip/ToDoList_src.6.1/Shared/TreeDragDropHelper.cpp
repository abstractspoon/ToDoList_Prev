DONEDATE, FO_NOT_SET));
		}
		break;

	case FT_STARTNEXTSEVENDAYS:
		{
			COleDateTime date = CDateHelper::GetDate(DHD_TODAY);
			params.rules.Add(SEARCHPARAM(TDCA_STARTDATE, FO_ON_OR_AFTER, date.m_dt));
			params.rules.Add(SEARCHPARAM(TDCA_STARTDATE, FO_BEFORE, date.m_dt + 7));
			params.rules.Add(SEARCHPARAM(TDCA_DONEDATE, FO_NOT_SET));
		}
		break;

	case FT_FLAGGED:
		params.rules.Add(SEARCHPARAM(TDCA_FLAG, FO_SET));
		break;

	case FT_DUENEXTSEVENDAYS: // special case
		{
			COleDateTime date = CDateHelper::GetDate(DHD_TODAY);
			params.rules.Add(SEARCHPARAM(TDCA_DUEDATE, FO_ON_OR_AFTER, date.m_dt));
		}
		// then fall through

	case FT_DUETODAY:
	case FT_DUETOMORROW:
	case FT_DUEENDTHISWEEK:
	case FT_DUEENDNEXTWEEK: 
	case FT_DUEENDTHISMONTH:
	case FT_DUEENDNEXTMONTH:
	case FT_DUEENDTHISYEAR:
	case FT_DUEENDNEXTYEAR:
		{
			COleDateTime dateDue;
			InitFilterDueDate(dateDue);

			if (dateDue.m_dt > 0.0)
			{
				//params.rules.Add(SEARCHPARAM(TDCA_DONEDATE, FO_NOT_SET));
				params.rules.Add(SEARCHPARAM(TDCA_DUEDATE, FO_ON_OR_BEFORE, dateDue.m_dt));
			}
			
			// this flag only applies to due filters
			params.bIgnoreOverDue = m_filter.HasFlag(FT_HIDEOVERDUE);
		}
		break;

/*
	case FT_ACTIVE:
		{
			COleDateTime date = CDateHelper::GetDate(DHD_TODAY);
			params.rules.Add(SEARCHPARAM(TDCA_STARTDATE, FO_ON_OR_BEFORE, date.m_dt));
			AddNonDateFilterQueryRules(params);

			params.rules.Add(SEARCHPARAM(TDCA_DUEDATE, FO_ON_OR_BEFORE, date.m_dt, FALSE));
			// AddNonDateFilterQueryRules will be called at the end of the function
		}
		break;

	case FT_NOTSTARTED:
		break;
*/

	default:
		ASSERT(0); // to catch unimplemented filters
		break;
	}

	// handle other attributes
	AddNonDateFilterQueryRules(params);
}

void CFilteredToDoCtrl::AddNonDateFilterQueryRules(SEARCHPARAMS& params)
{
	// title text
	if (!m_filter.sTitle.IsEmpty())
		params.rules.Add(SEARCHPARAM(TDCA_TASKNAME, FO_INCLUDES, m_filter.sTitle));

	// note: these are all 'AND' 
	// category
	if (m_filter.aCategories.GetSize())
	{
		CString sMatchBy = Misc::FormatArray(m_filter.aCategories);

		if (m_filter.aCategories.GetSize() == 1 && sMatchBy.IsEmpty())
			params.rules.Add(SEARCHPARAM(TDCA_CATEGORY, FO_NOT_SET));

		else if (m_filter.dwFlags & FT_ANYCATEGORY)
			params.rules.Add(SEARCHPARAM(TDCA_CATEGORY, FO_INCLUDES, sMatchBy));
		else
			params.rules.Add(SEARCHPARAM(TDCA_CATEGORY, FO_EQUALS, sMatchBy));
	}

	// allocated to
	if (m_filter.aAllocTo.GetSize())
	{
		CString sMatchBy = Misc::FormatArray(m_filter.aAllocTo);

		if (m_filter.aAllocTo.GetSize() == 1 && sMatchBy.IsEmpty())
			params.rules.Add(SEARCHPARAM(TDCA_ALLOCTO, FO_NOT_SET));

		else if (m_filter.dwFlags & FT_ANYALLOCTO)
			params.rules.Add(SEARCHPARAM(TDCA_ALLOCTO, FO_INCLUDES, sMatchBy));
		else
			params.rules.Add(SEARCHPARAM(TDCA_ALLOCTO, FO_EQUALS, sMatchBy));
	}

	// allocated by
	if (m_filter.aAllocBy.GetSize())
	{
		CString sMatchBy = Misc::FormatArray(m_filter.aAllocBy);

		if (m_filter.aAllocBy.GetSize() == 1 && sMatchBy.IsEmpty())
			params.rules.Add(SEARCHPARAM(TDCA_ALLOCBY, FO_NOT_SET));
		else
			params.rules.Add(SEARCHPARAM(TDCA_ALLOCBY, FO_INCLUDES, sMatchBy));
	}

	// status
	if (m_filter.aStatus.GetSize())
	{
		CString sMatchBy = Misc::FormatArray(m_filter.aStatus);

		if (m_filter.aStatus.GetSize() == 1 && sMatchBy.IsEmpty())
			params.rules.Add(SEARCHPARAM(TDCA_STATUS, FO_NOT_SET));
		else
			params.rules.Add(SEARCHPARAM(TDCA_STATUS, FO_INCLUDES, sMatchBy));
	}

	// version
	if (m_filter.aVersions.GetSize())
	{
		CString sMatchBy = Misc::FormatArray(m_filter.aVersions);

		if (m_filter.aVersions.GetSize() == 1 && sMatchBy.IsEmpty())
			params.rules.Add(SEARCHPARAM(TDCA_VERSION, FO_NOT_SET));
		else
			params.rules.Add(SEARCHPARAM(TDCA_VERSION, FO_INCLUDES, sMatchBy));
	}

	// priority
	if (m_filter.nPriority != FT_ANYPRIORITY)
	{
		if (m_filter.nPriority == FT_NOPRIORITY)
			params.rules.Add(SEARCHPARAM(TDCA_PRIORITY, FO_NOT_SET));

		else if (m_filter.nPriority != FT_ANYPRIORITY)
			params.rules.Add(SEARCHPARAM(TDCA_PRIORITY, FO_GREATER_OR_EQUAL, m_filter.nPriority));
	}

	// risk
	if (m_filter.nRisk != FT_ANYRISK)
	{
		if (m_filter.nRisk == FT_NORISK)
			params.rules.Add(SEARCHPARAM(TDCA_RISK, FO_NOT_SET));
		
		else if (m_filter.nRisk != FT_ANYRISK)
			params.rules.Add(SEARCHPARAM(TDCA_RISK, FO_GREATER_OR_EQUAL, m_filter.nRisk));
	}

	// special case: no rules + ignore completed
	if ((params.bIgnoreDone) && params.rules.GetSize() == 0)
		params.rules.Add(SEARCHPARAM(TDCA_DONEDATE, FO_NOT_SET));
}

LRESULT CFilteredToDoCtrl::OnRefreshFilter(WPARAM wParam, LPARAM lParam)
{
	BOOL bUndo = lParam;
	FTC_VIEW nView = (FTC_VIEW)wParam;

	if (nView == FTCV_TASKTREE)
		RefreshFilter();

	// if undoing then we must also refresh the list filter because
	// otherwise ResyncListSelection will fail in the case where
	// we are undoing a delete because the undone item will not yet be in the list.
	if (nView == FTCV_TASKLIST || bUndo)
		RefreshListFilter();
	
   // resync selection?
   if (bUndo)
      ResyncListSelection();

	return 0L;
}

void CFilteredToDoCtrl::RefreshFilter() 
{
	RefreshTreeFilter(); // always

	if (InListView())
		RefreshListFilter();
	else // tree view
		m_bListNeedRefilter = TRUE;
}

void CFilteredToDoCtrl::RefreshTreeFilter() 
{
	if (!m_data.GetTaskCount())
		return;

	BOOL bTreeVis = !InListView();

	// save and reset current focus to work around a bug
	CWnd* pFocus = CWnd::GetFocus();
	SetFocusToTasks();
	
	CHoldRedraw hr(GetSafeHwnd());
	CHoldRedraw hr2(m_tree);
	CWaitCursor cursor;
	
	// cache current selection
	CDWordArray aTaskIDs;
	DWORD dwFocusedTaskID, dwPrevID = 0;

	GetSelectedTaskIDs(aTaskIDs, dwFocusedTaskID, FALSE);
 
	// cache previous task to selected item
	if (aTaskIDs.GetSize() == 1)
	{
		HTREEITEM htiPrev = m_tree.TCH().GetPrevVisibleItem(GetSelectedItem());
		dwPrevID = GetTaskID(htiPrev);
	}
	
	Selection().RemoveAll();
	
	// and scrolled pos
	DWORD dwFirstVis = bTreeVis ? GetTaskID(m_tree.GetFirstVisibleItem()) : 0;
	
	// and expanded selection
	CPreferences prefs;
	SaveExpandedState(prefs);
	
	// build a find query that matches the filter
	SEARCHPARAMS filter;

	if (m_bCustomFilter)
		filter = m_customFilter;
	else
		BuildFilterQuery(filter);
	
	// rebuild the tree
	RebuildTree(filter);
	
	// redo last sort
	if (bTreeVis && IsSortable())
	{
		Resort();
		m_bTreeNeedResort = FALSE;
	}
	else
		m_bTreeNeedResort = TRUE;
	
	// restore expanded state
	LoadExpandedState(prefs);
	
	// restore scrolled pos
	if (dwFirstVis)
	{
		HTREEITEM hti = m_find.GetItem(dwFirstVis);
		m_tree.SelectSetFirstVisible(hti);
		m_tree.SelectItem(NULL);
	}
	
	// restore selection
	RestoreTreeSelection(aTaskIDs, dwPrevID);

	// restore focused window
	if (pFocus)
		pFocus->SetFocus();
}

void CFilteredToDoCtrl::RestoreTreeSelection(const CDWordArray& aTaskIDs, DWORD dwDefaultID)
{
	BOOL bSel = MultiSelectItems(aTaskIDs);

	if (!bSel) // nothing restored
	{
		ASSERT(GetSelectedCount() == 0);

      HTREEITEM hti = NULL;

      if (dwDefaultID)
         hti = m_find.GetItem(dwDefaultID);

      if (!hti)
		   hti = m_tree.GetChildItem(NULL); // select first item

      SelectItem(hti); // select first item
		
		return;
	}

	// don't update controls is only one item is selected and it did not
	// change as a result of the filter
	BOOL bSelChange = !(GetSelectedCount() == 1 && aTaskIDs.GetSize() == 1 &&
						GetSelectedTaskID() == aTaskIDs[0]);
	
	if (bSelChange)
		UpdateControls();
}

void CFilteredToDoCtrl::RebuildTree(const SEARCHPARAMS& filter)
{
	m_tree.TCH().SelectItem(NULL);
	m_tree.DeleteAllItems();

	BuildTreeItem(NULL, m_data.GetStructure(), filter);
}

BOOL CFilteredToDoCtrl::BuildTreeItem(HTREEITEM hti, const TODOSTRUCTURE* pTDS, const SEARCHPARAMS& filter)
{
	// sanity checks
	if (pTDS)
	{
		if (hti == NULL || hti == TVI_ROOT)
		{
			ASSERT (pTDS->GetTaskID() == 0);

			if (pTDS->GetTaskID() != 0)
				return FALSE;
		}
		else
		{
			ASSERT (m_find.GetTaskID(hti) == pTDS->GetTaskID());
			
			if (m_find.GetTaskID(hti) != pTDS->GetTaskID())
				return FALSE;
		}
	}
	else
	{
		ASSERT(hti);
		ASSERT(!m_tree.ItemHasChildren(hti));

		DWORD dwID = m_find.GetTaskID(hti);
		pTDS = m_data.LocateTask(dwID);
	}

	// rebuild
	HTREEITEM htiAfter = TVI_FIRST;

	for (int nSubtask = 0; nSubtask < pTDS->GetSubTaskCount(); nSubtask++)
	{
		const TODOSTRUCTURE* pTDSChild = pTDS->GetSubTask(nSubtask);
		DWORD dwID = pTDSChild->GetTaskID();

		const TODOITEM* pTDIChild = GetTask(dwID);
		ASSERT(pTDIChild);

		// does this task match the filter
		BOOL bMatch = TRUE;
		BOOL bHasChildren = pTDSChild->HasSubTasks();

		if (!bHasChildren)
		{
			SEARCHRESULT result;
			bMatch = m_data.TaskMatches(pTDIChild, pTDSChild, filter, result);
		}

		if (bMatch)
		{
			// add this item to tree
			BOOL bBold = (pTDSChild->ParentIsRoot()); 
			HTREEITEM htiChild = m_tree.InsertItem(TVIF_TEXT | TVIF_PARAM | TVIF_STATE | TVIF_IMAGE | TVIF_SELECTEDIMAGE,
													LPSTR_TEXTCALLBACK,
													I_IMAGECALLBACK, 
													I_IMAGECALLBACK, 
													(bBold ? TVIS_BOLD : 0),
													TVIS_BOLD, // state mask
													dwID, // lParam
													hti, 
													htiAfter);

			ASSERT(htiChild);

			// check state
			m_tree.TCH().SetItemChecked(htiChild, pTDIChild->IsDone());

			// and its children
			if (bHasChildren)
			{
				BuildTreeItem(htiChild, pTDSChild, filter);

				// if no subtasks got added to the tree then we may need to remove the parent too
				if (!m_tree.ItemHasChildren(htiChild))
				{
					SEARCHRESULT result;
					bMatch = m_data.TaskMatches(pTDIChild, pTDSChild, filter, result);

					if (!bMatch)
					{
						m_tree.DeleteItem(htiChild);
						htiChild = NULL;
					}
				}
			}

			if (htiChild)
				htiAfter = htiChild;
		}
	}

	return TRUE;
}

void CFilteredToDoCtrl::RefreshListFilter() 
{
	m_bListNeedRefilter = FALSE;

	if (!m_data.GetTaskCount())
	{
		m_list.DeleteAllItems(); 
		return;
	}

//	ASSERT(InListView());

	// note: the call to CListCtrl::Scroll at the bottom fails if the 
	// list has redraw disabled so it must happen outside the scope of hr2
	CSize sizePos(0, 0);
	{
		CHoldRedraw hr(GetSafeHwnd());
		CHoldRedraw hr2(m_list);
		CWaitCursor cursor;

		// cache current selection
		CDWordArray aTaskIDs;
		DWORD dwFocusedTaskID;
		GetSelectedTaskIDs(aTaskIDs, dwFocusedTaskID, FALSE);

		// and scrolled pos
		if (m_list.GetItemCount())
		{
			CRect rItem;
			m_list.GetItemRect(0, rItem, LVIR_BOUNDS);

			sizePos.cy = -rItem.top + rItem.Height();
		}

		// build a find query that matches the filter
		SEARCHPARAMS filter;

		if (m_bCustomFilter)
			filter = m_customFilter;
		else 
		BuildFilterQuery(filter);

		// rebuild the list
		RebuildList(filter);

		// redo last sort
		if (IsSortable())
		{
			Resort();
			m_bListNeedResort = FALSE;
		}

		// restore selection
		SetSelectedListTasks(aTaskIDs, dwFocusedTaskID);

		// don't update controls is only one item is selected and it did not
		// change as a result of the filter
		BOOL bSelChange = !(GetSelectedCount() == 1 && aTaskIDs.GetSize() == 1 &&
							GetTaskID(GetSelectedItem()) == aTaskIDs[0]);

		if (bSelChange)
			UpdateControls();
	}
	
	// restore pos
	if (sizePos.cy != 0)
		m_list.Scroll(sizePos);

	UpdateColumnWidths();
}

void CFilteredToDoCtrl::RebuildList(const SEARCHPARAMS& filter)
{
	// remove all existing items
	m_list.DeleteAllItems();

	// since the tree will have already go the items we want 
	// we can optimize the rebuild under certain circumstances
	// which are: 
	// 1. the list is sorted
	// 2. or the tree is unsorted
	// otherwise we need the data in it's unsorted state and the 
	// tree doesn't have it
	if (IsSortable(m_sortList.nBy1) || !IsSortable(m_sort.nBy1))
	{
		// rebuild the list from the tree
		AddTreeItemToList(NULL, filter);
	}
	else // rebuild from scratch
	{
		// do the find
		CResultArray aResults;
		m_data.FindTasks(filter, aResults);

		// add tasks to list
		for (int nRes = 0; nRes < aResults.GetSize(); nRes++)
		{
			const SEARCHRESULT& res = aResults[nRes];

			// some more filtering required
			if (m_filter.HasFlag(FT_HIDEPARENTS))
			{
				TODOSTRUCTURE* pTDS = m_data.LocateTask(res.dwID);
				ASSERT(pTDS);

				if (pTDS->HasSubTasks())
					continue;
			}
			else if (m_filter.HasFlag(FT_HIDECOLLAPSED))
			{
				HTREEITEM hti = m_find.GetItem(res.dwID);
				ASSERT(hti);			

				if (m_tree.ItemHasChildren(hti) && !m_tree.TCH().IsItemExpanded(hti))
					continue;
			}

			int nItem = m_list.InsertItem(nRes, LPSTR_TEXTCALLBACK, I_IMAGECALLBACK);
			m_list.SetItemData(nItem, res.dwID);
		}
	}
}

void CFilteredToDoCtrl::AddTreeItemToList(HTREEITEM hti, const SEARCHPARAMS& filter)
{
	if (hti)
	{
		BOOL bAdd = TRUE;
		DWORD dwTaskID = GetTaskID(hti);

		// check if parent items are to be ignored
		if (m_filter.HasFlag(FT_HIDEPARENTS))
		{
			// quick test first
			if (m_tree.ItemHasChildren(hti))
				bAdd = FALSE;
			else
			{
				const TODOSTRUCTURE* pTDS = m_data.LocateTask(dwTaskID);
				ASSERT(pTDS);

				bAdd = !pTDS->HasSubTasks();
			}
		}
		// else check if it's a parent item that's only present because
		// it has matching subtasks
		else if (m_tree.ItemHasChildren(hti))
		{
			const TODOSTRUCTURE* pTDS = m_data.LocateTask(dwTaskID);
			const TODOITEM* pTDI = GetTask(dwTaskID); 
			SEARCHRESULT result;

			// ie. check that parent actually matches
			bAdd = m_data.TaskMatches(pTDI, pTDS, filter, result);
		}

		if (bAdd)
		{
			int nItem = m_list.InsertItem(m_list.GetItemCount(), LPSTR_TEXTCALLBACK, I_IMAGECALLBACK);
			m_list.SetItemData(nItem, GetTaskID(hti));
		}
	}

	// always check the children unless collapsed tasks ignored
	if (!m_filter.HasFlag(FT_HIDECOLLAPSED) || !hti || m_tree.TCH().IsItemExpanded(hti))
	{
		HTREEITEM htiChild = m_tree.GetChildItem(hti);

		while (htiChild)
		{
			// check
			AddTreeItemToList(htiChild, filter);
			htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
		}
	}
}

void CFilteredToDoCtrl::OnHeaderCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMCUSTOMDRAW* pNMCD = (NMCUSTOMDRAW*)pNMHDR;
	
	if (pNMCD->dwDrawStage == CDDS_PREPAINT)
		*pResult |= CDRF_NOTIFYITEMDRAW | CDRF_NOTIFYPOSTPAINT;	
	
	else if (pNMCD->dwDrawStage == CDDS_ITEMPREPAINT)
		*pResult |= CDRF_NOTIFYPOSTPAINT;	

	else if (pNMCD->dwDrawStage == CDDS_ITEMPOSTPAINT)
	{
		CDC* pDC = CDC::FromHandle(pNMCD->hdc);
		CFont* pOldFont = (CFont*)pDC->SelectObject(CWnd::GetFont());

		// clip column to client rect
		CRect rHeader;
		m_header.GetClientRect(rHeader);
		pNMCD->rc.right = min(pNMCD->rc.right, rHeader.right);

		DrawColumnHeaderText(pDC, pNMCD->dwItemSpec, pNMCD->rc, pNMCD->uItemState);

		pDC->SelectObject(pOldFont);
	}
}

void CFilteredToDoCtrl::OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{
	if (nIDCtl == IDC_FTC_TASKLIST)
		lpMeasureItemStruct->itemHeight = m_tree.TCH().GetItemHeight();
	else
		CToDoCtrl::OnMeasureItem(nIDCtl, lpMeasureItemStruct);
}

void CFilteredToDoCtrl::RemoveDeletedListItems()
{
	int nItem = m_list.GetItemCount();

	while (nItem--)
	{
		DWORD dwTaskID = m_list.GetItemData(nItem);

		if (!GetTask(dwTaskID))
			m_list.DeleteItem(nItem);
	}
}

CFilteredToDoCtrl::TDI_STATE CFilteredToDoCtrl::GetItemState(int nItem)
{
	if (m_list.GetItemState(nItem, LVIS_DROPHILITED) & LVIS_DROPHILITED)
		return TDIS_DROPHILITED;
	
	else if (m_list.GetItemState(nItem, LVIS_SELECTED) & LVIS_SELECTED)
//	else if (IsItemSelected(nItem))
		return (TasksHaveFocus() ? TDIS_SELECTED : TDIS_SELECTEDNOTFOCUSED);
	
	return TDIS_NONE;
}

void CFilteredToDoCtrl::GetItemColors(int nItem, NCGITEMCOLORS& colors)
{
	TDI_STATE nState = GetItemState(nItem);
	DWORD dwID = GetTaskID(nItem);

	colors.crText = GetSysColor(COLOR_WINDOWTEXT);
	colors.crBack = GetSysColor(COLOR_WINDOW);

	if (nItem % 2)
	{
		COLORREF crAlt = m_tree.GetAlternateLineColor();

		if (crAlt != NOCOLOR)
			colors.crBack = crAlt;
	}

	CToDoCtrl::GetItemColors(dwID, &colors, nSta