S(UPHORZ)
    TM_STATE(1, UPHZS, NORMAL)
    TM_STATE(2, UPHZS, HOT)
    TM_STATE(3, UPHZS, PRESSED)
    TM_STATE(4, UPHZS, DISABLED)
END_TM_PART_STATES()

BEGIN_TM_PART_STATES(DOWNHORZ)
    TM_STATE(1, DNHZS, NORMAL)
    TM_STATE(2, DNHZS, HOT)
    TM_STATE(3, DNHZS, PRESSED)
    TM_STATE(4, DNHZS, DISABLED)
END_TM_PART_STATES()

//---------------------------------------------------------------------------------------
//   "Page" Parts & States
//---------------------------------------------------------------------------------------
BEGIN_TM_CLASS_PARTS(PAGE)
    TM_PART(1, PGRP, UP)
    TM_PART(2, PGRP, DOWN)
    TM_PART(3, PGRP, UPHORZ)
    TM_PART(4, PGRP, DOWNHORZ)
END_TM_CLASS_PARTS()

//--- Pager uses same states as Spin ---

//---------------------------------------------------------------------------------------
//   "