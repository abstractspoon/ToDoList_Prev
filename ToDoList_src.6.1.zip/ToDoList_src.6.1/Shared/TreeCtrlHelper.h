t nHit = lvhti.iItem;

		// we're only interested in the client column
		if (nHit != -1 && GetColumnID(lvhti.iSubItem) == TDCC_CLIENT) // valid item
		{
			// get item rect in parent coords
			pTI->hwnd = m_list;
			pTI->lpszText = LPSTR_TEXTCALLBACK;
// 			pTI->uId = (UINT)m_list.GetSafeHwnd();
// 			pTI->uFlags |= TTF_IDISHWND;
			pTI->uId = nHit + 10;

			CRect rItem;
			GetItemTitleRect(nHit, TDCTR_LABEL, rItem);
			pTI->rect = rItem;
		}

		return 1;
	}

	return -1;
}

BOOL CFilteredToDoCtrl::OnToolTipNotify(UINT id, NMHDR* pNMHDR, LRESULT* pResult)
{
    // Get the tooltip structure.
    TOOLTIPTEXT *pTTT = (TOOLTIPTEXT *)pNMHDR;

    // Actually the idFrom holds Control's handle.
    UINT CtrlHandle = pNMHDR->idFrom;

    // Check once again that the idFrom holds handle itself.
    if (pTTT->uFlags & TTF_IDISHWND)
    {
		static CString sTooltip;
		sTooltip.Empty();

        // Get the control's ID.
        UINT nID = ::GetDlgCtrlID( HWND( CtrlHandle ));

        // Now you have the ID. depends on control,
        // set your tooltip message.
        switch( nID )
        {
        case IDC_FTC_TASKLIST:
			//
			sTooltip = "list tooltip";
            break;
        }

		if (!sTooltip.IsEmpty())
		{
			pTTT->lpszText = (LPSTR)(LPCTSTR)sTooltip;
	        return TRUE;
		}

    }

    // Not handled.
    return FALSE;
}

BOOL CFilteredToDoCtrl::OnToolTipShow( UINT id, NMHDR* pNMHDR, LRESULT* pResult )
{

    // Not handled.
    return FALSE;

}
*/

void CFilteredToDoCtrl::SelectAll()
{
	if (InListView())
	{
		int nNumItems = m_list.GetItemCount();
		BOOL bAllTasks = (CToDoCtrl::GetTaskCount() == (UINT)nNumItems);
		CDWordArray aTaskIDs;

		for (int nItem = 0; nItem < nNumItems; nItem++)
		{
			// select item
			m_list.SetItemState(nItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);

			// save ID only not showing all tasks
			if (!bAllTasks)
				aTaskIDs.Add(m_list.GetItemData(nItem));
		}

		// select items in tree
		if (bAllTasks)
			CToDoCtrl::SelectAll();
		else
			MultiSelectItems(aTaskIDs, TSHS_SELECT, FALSE);
	}
	else
		CToDoCtrl::SelectAll();
}

void CFilteredToDoCtrl::DeselectAll()
{
	CToDoCtrl::DeselectAll();
	ClearListSelection();
}

int CFilteredToDoCtrl::GetTasks(CTaskFile& tasks, const TDCGETTASKS& filter) const
{
	if (InListView())
	{
		// we return exactly what's selected in the list and in the same order
		// so we make sure the filter includes TDCGT_NOTSUBTASKS
		TDCGETTASKS tdcf(filter);
		tdcf.dwFlags |= TDCGTF_NOTSUBTASKS;

		for (int nItem = 0; nItem < m_list.GetItemCount(); nItem++)
		{
			HTREEITEM hti = GetTreeItem(nItem);
			AddTreeItemToTaskFile(hti, tasks, NULL, tdcf, 0);
		}

		if (filter.dwFlags & TDCGTF_FILENAME)
			tasks.SetFileName(m_sLastSavePath);

		return tasks.GetTaskCount();
	}
	else
		return CToDoCtrl::GetTasks(tasks, filter);
}

int CFilteredToDoCtrl::GetSelectedTasks(CTaskFile& tasks, const TDCGETTASKS& filter) const
{
	if (InListView())
	{
		// we return exactly what's selected in the list and in the same order
		// so we make sure the filter includes TDCGT_NOTSUBTASKS
		TDCGETTASKS tdcf(filter);
		tdcf.dwFlags |= TDCGTF_NOTSUBTASKS;
	
		POSITION pos = m_list.GetFirstSelectedItemPosition();

		while (pos)
		{
			int nItem = m_list.GetNextSelectedItem(pos);
			HTREEITEM hti = GetTreeItem(nItem);

			AddTreeItemToTaskFile(hti, tasks, NULL, tdcf, 0);
		}

		return tasks.GetTaskCount();
	}
	else
		return CToDoCtrl::GetSelectedTasks(tasks, filter);
}

int CFilteredToDoCtrl::GetFilteredTasks(CTaskFile& tasks, const TDCGETTASKS& filter) const
{
	// synonym for GetTasks which always returns the filtered tasks
	return GetTasks(tasks, filter);
}

FILTER_TYPE CFilteredToDoCtrl::GetFilter(FTDCFILTER& filter) const
{
	filter = m_filter;
	return m_filter.nFilter;
}

void CFilteredToDoCtrl::SetFilter(const FTDCFILTER& filter)
{
	FTDCFILTER fPrev = m_filter;
	m_filter = filter;

	if (m_bDelayLoaded)
		m_bListNeedRefilter = TRUE;
	else
	{
		BOOL bTreeNeedsFilter = m_bCustomFilter || !FiltersMatch(fPrev, fi