_pageTask.GetTrackHibernated(); }
	double GetHoursInOneDay() const { return m_pageTask.GetHoursInOneDay(); }
	double GetDaysInOneWeek() const { return m_pageTask.GetDaysInOneWeek(); }
	BOOL GetLogTimeTracking() const { return m_pageTask.GetLogTimeTracking(); }
	BOOL GetLogTaskTimeSeparately() const { return m_pageTask.GetLogTaskTimeSeparately(); }
	BOOL GetExclusiveTimeTracking() const { return m_pageTask.GetExclusiveTimeTracking(); }
	BOOL GetAllowParentTimeTracking() const { return m_pageTask.GetAllowParentTimeTracking(); }

	BOOL GetAveragePercentSubCompletion() const { return m_pageTaskCalc.GetAveragePercentSubCompletion(); }
	BOOL GetIncludeDoneInAverageCalc() const { return m_pageTaskCalc.GetIncludeDoneInAverageCalc(); }
	BOOL GetUseEarliestDueDate() const { return m_pageTaskCalc.GetUseEarliestDueDate(); }
	BOOL GetUsePercentDoneInTimeEst() const { return m_pageTaskCalc.GetUsePercentDoneInTimeEst(); }
	BOOL GetTreatSubCompletedAsDone() const { return m_pageTaskCalc.GetTreatSubCompletedAsDone(); }
	BOOL GetUseHighestPriority() const { return m_pageTaskCalc.GetUseHighestPriority(); }
	BOOL GetUseHighestRisk() const { return m_pageTaskCalc.GetUseHighestRisk(); }
	BOOL GetDueTasksHaveHighestPriority() const { return m_pageTaskCalc.GetDueTasksHaveHighestPriority(); }
	BOOL GetDoneTasksHaveLowestPriority() const { return m_pageTaskCalc.GetDoneTasksHaveLowestPriority(); }
	BOOL GetDoneTasksHaveLowestRisk() const { return m_pageTaskCalc.GetDoneTasksHaveLowestRisk(); } 
	BOOL GetAutoCalcTimeEstimates() const { return m_pageTaskCalc.GetAutoCalcTimeEstimates(); }
	BOOL GetIncludeDoneInPriorityRiskCalc() const { return m_pageTaskCalc.GetIncludeDoneInPriorityRiskCalc(); }
	BOOL GetWeightPercentCompletionByNumSubtasks() const { return m_pageTaskCalc.GetWeightPercentCompletionByNumSubtasks(); }
	BOOL GetAutoCalcPercentDone() const { return m_pageTaskCalc.GetAutoCalcPercentDone(); }
	BOOL GetAutoAdjustDependents() const { return m_pageTaskCalc.GetAutoAdjustDependents(); }
	BOOL GetNoDueDateIsDueToday() const { return m_pageTaskCalc.GetNoDueDateIsDueToday(); }
	int GetTimeRemainingCalculation() const { return m_pageTaskCalc.GetTimeRemainingCalculation(); }

	BOOL GetShowCtrlsAsColumns() const { return m_pageUI.GetShowCtrlsAsColumns(); }
	BOOL GetShowEditMenuAsColumns() const { return m_pageUI.GetShowEditMenuAsColumns(); }
	BOOL GetShowCommentsAlways() const { return m_pageUI.GetShowCommentsAlways(); }
	BOOL GetAutoReposCtrls() const { return m_pageUI.GetAutoReposCtrls(); }
	BOOL GetSharedCommentsHeigh