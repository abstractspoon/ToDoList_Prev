// Fi M_BlISlteredToDoCtrl.cpp: implementation of the CFilteredToDoCtrl class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FilteredToDoCtrl.h"
#include "todoitem.h"
#include "resource.h"
#include "tdcstatic.h"
#include "tdcmsg.h"

#include "..\shared\holdredraw.h"
#include "..\shared\datehelper.h"
#include "..\shared\enstring.h"
#include "..\shared\preferences.h"
#include "..\shared\deferwndmove.h"
#include "..\shared\autoflag.h"
#include "..\shared\holdredraw.h"
#include "..\shared\osversion.h"
#include "..\shared\graphicsmisc.h"

#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#ifndef LVS_EX_DOUBLEBUFFER
#define LVS_EX_DOUBLEBUFFER 0x00010000
#endif

#ifndef LVS_EX_LABELTIP
#define LVS_EX_LABELTIP     0x00004000
#endif

const UINT SORTWIDTH = 10;
#define NOCOLOR ((COLORREF)-1)

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFilteredToDoCtrl::CFilteredToDoCtrl(CContentMgr& mgr, const CONTENTFORMAT& cfDefault) :
	CToDoCtrl(mgr, cfDefault), 
		m_nCurView(FTCV_UNSET), 
		m_bListNeedRefilter(TRUE),
		m_bListNeedResort(FALSE),
		m_bTreeNeedResort(FALSE),
		m_bListModSinceLastSort(FALSE),
		m_tabCtrl(e_tabBottom),
		m_bLastFilterWasCustom(FALSE),
		m_bCustomFilter(FALSE),
		m_bListMultiSort(FALSE)
{
	// add extra controls
	for (int nCtrl = 0; nCtrl < NUM_FTDCCTRLS; nCtrl++)
	{
		const TDCCONTROL& ctrl = FTDCCONTROLS[nCtrl];

		AddRCControl("CONTROL", ctrl.szClass, CEnString(ctrl.nIDCaption), 
					ctrl.dwStyle, ctrl.dwExStyle,
					ctrl.nX, ctrl.nY, ctrl.nCx, ctrl.nCy, ctrl.nID);
	}
	
	m_sortList.nBy1 = TDC_UNSORTED;
	m_sortList.nBy2 = TDC_UNSORTED;
	m_sortList.nBy3 = TDC_UNSORTED;
	m_sortList.bAscending1 = -1;
	m_sortList.bAscending2 = FALSE;
	m_sortList.bAscending3 = FALSE;
}

CFilteredToDoCtrl::~CFilteredToDoCtrl()
{

}

BEGIN_MESSAGE_MAP(CFilteredToDoCtrl, CToDoCtrl)
//{{AFX_MSG_MAP(CFilteredToDoCtrl)
	ON_WM_SETCURSOR()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_NOTIFY(TCN_SELCHANGE, IDC_FTC_TABCTRL, OnSelchangeTabcontrol)
	ON_NOTIFY(NM_CUSTOMDRAW, 0, OnHeaderCustomDraw)
	ON_NOTIFY(NM_RCLICK, 0, OnRClickHeader)
	ON_NOTIFY(LVN_COLUMNCLICK, IDC_FTC_TASKLIST, OnClickHeader)
	ON_NOTIFY(NM_CLICK, IDC_FTC_TASKLIST, OnListClick)
	ON_NOTIFY(NM_DBLCLK, IDC_FTC_TASKLIST, OnListDblClick)
	ON_NOTIFY(NM_KEYDOWN, IDC_FTC_TASKLIST, OnListKeyDown)
	ON_NOTIFY(TVN_ITEMEXPANDED, IDC_TASKLIST, OnTreeExpandItem)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_FTC_TASKLIST, OnListSelChanged)
	ON_WM_MEASUREITEM()
	ON_WM_DRAWITEM()
	ON_NOTIFY(LVN_GETINFOTIP, IDC_FTC_TASKLIST, OnListGetInfoTip)
	ON_NOTIFY(LVN_GETDISPINFO, IDC_FTC_TASKLIST, OnListGetDispInfo)
	ON_REGISTERED_MESSAGE(WM_TLDT_DROPFILE, OnDropFileRef)
	ON_REGISTERED_MESSAGE(WM_PCANCELEDIT, OnEditCancel)
	ON_REGISTERED_MESSAGE(WM_NCG_WIDTHCHANGE, OnGutterWidthChange)
	ON_MESSAGE(WM_TDC_REFRESHFILTER, OnRefreshFilter)
//	ON_NOTIFY_EX_RANGE(TTN_NEEDTEXT, 0, 0xFFFF, OnToolTipNotify)
//	ON_NOTIFY_EX_RANGE(TTN_SHOW, 0, 0xFFFF, OnToolTipShow)
	ON_CBN_EDITCHANGE(IDC_DUETIME, OnEditChangeDueTime)
END_MESSAGE_MAP()

///////////////////////////////////////////////////////////////////////////

void CFilteredToDoCtrl::DoDataExchange(CDataExchange* pDX)
{
	CToDoCtrl::DoDataExchange(pDX);
	
	DDX_Control(pDX, IDC_FTC_TASKLIST, m_list);
	DDX_Control(pDX, IDC_FTC_TABCTRL, m_tabCtrl);
}

BOOL CFilteredToDoCtrl::OnInitDialog()
{
	CToDoCtrl::OnInitDialog();

	// prepare filtered view
	ListView_SetExtendedListViewStyleEx(m_list, 
										LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER, 
										LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER);
//	ListView_SetExtendedListViewStyleEx(m_list, LVS_EX_LABELTIP, LVS_EX_LABELTIP);
	m_dtList.Register(&m_list, this);
//	m_list.EnableToolTips();
//	EnableToolTips();

	// prevent the list overwriting the label edit
	m_list.ModifyStyle(0, WS_CLIPSIBLINGS);

	// and hook it
	ScHookWindow(m_list);

	// add all columns
	BuildListColumns();

	// prepare tab bar
	if (m_ilTabs.Create(16, 16, ILC_COLOR32 | ILC_MASK, 2, 1))
	{
		CBitmap bm;
		bm.LoadBitmap(IDB_TREELIST);
		m_ilTabs.Add(&bm, RGB(255, 0, 255));
		m_tabCtrl.SetImageList(&m_ilTabs);
	}
		
	m_tabCtrl.InsertItem(TCIF_TEXT | TCIF_PARAM | TCIF_IMAGE, 0, CEnString(IDS_TASKTREE), 0, (LPARAM)&m_tree);
	m_tabCtrl.InsertItem(TCIF_TEXT | TCIF_PARAM | TCIF_IMAGE, 1, CEnString(IDS_LISTVIEW), 1, (LPARAM)&m_list);

	Resize();

	return FALSE;
}

BOOL CFilteredToDoCtrl::PreTranslateMessage(MSG* pMsg) 
{
	return CToDoCtrl::PreTranslateMessage(pMsg);
}

void CFilteredToDoCtrl::SetUITheme(const UITHEME& theme)
{
	CToDoCtrl::SetUITheme(theme);

	m_tabCtrl.SetBackgroundColor(theme.crAppBackLight);
}

BOOL CFilteredToDoCtrl::LoadTasks(const CTaskFile& file)
{
	CPreferences prefs;

	BOOL bSuccess = CToDoCtrl::LoadTasks(file);

	// reload last view
	if (m_nCurView == FTCV_UNSET)
	{
		RestoreFilter(prefs, m_lastFilter, "Last");
		RestoreFilter(prefs, m_filter);

		if (IsFilterSet(FTCV_TASKTREE))
			RefreshTreeFilter(); // always

		CString sKey = GetPreferencesKey(); // no subkey
		
		if (!sKey.IsEmpty()) // first time
		{
			m_bListNeedRefilter = TRUE;

			FTC_VIEW nView = (FTC_VIEW)prefs.GetProfileInt(sKey, "View", FTCV_TASKTREE);
			SetView(nView);
		}
	}
	else
		RefreshFilter();

	return bSuccess;
}

void CFilteredToDoCtrl::RestoreFilter(const CPreferences& prefs, FTDCFILTER& filter, const CString& sSubKey)
{
	CString sKey = GetPreferencesKey("Filter");

	if (!sKey.IsEmpty())
	{
		if (!sSubKey.IsEmpty())
			sKey += "\\" + sSubKey;

		filter.nFilter = (FILTER_TYPE)prefs.GetProfileInt(sKey, "Filter", FT_ALL);
		filter.sTitle = prefs.GetProfileString(sKey, "Title");
		filter.nPriority = prefs.GetProfileInt(sKey, "Priority", FT_ANYPRIORITY);
		filter.nRisk = prefs.GetProfileInt(sKey, "Risk", FT_ANYRISK);

		// cats
		CString sCategory = prefs.GetProfileString(sKey, "Category");
		Misc::ParseIntoArray(sCategory, filter.aCategories, TRUE);

		// alloc to
		CString sAllocTo = prefs.GetProfileString(sKey, "AllocTo");
		Misc::ParseIntoArray(sAllocTo, filter.aAllocTo, TRUE);

		// alloc by
		CString sAllocBy = prefs.GetProfileString(sKey, "AllocBy");
		Misc::ParseIntoArray(sAllocBy, filter.aAllocBy, TRUE);

		// status
		CString sStatus = prefs.GetProfileString(sKey, "Status");
		Misc::ParseIntoArray(sStatus, filter.aStatus, TRUE);

		// version
		CString sVersion = prefs.GetProfileString(sKey, "Version");
		Misc::ParseIntoArray(sVersion, filter.aVersions, TRUE);

		// options
		filter.SetFlag(FT_ANYCATEGORY, prefs.GetProfileInt(sKey, "AnyCategory", FALSE));
		filter.SetFlag(FT_ANYALLOCTO, prefs.GetProfileInt(sKey, "AnyAllocTo", FALSE));
		filter.SetFlag(FT_HIDEPARENTS, prefs.GetProfileInt(sKey, "HideParents", FALSE));
		filter.SetFlag(FT_HIDEOVERDUE, prefs.GetProfileInt(sKey, "HideOverDue", FALSE));
		filter.SetFlag(FT_HIDEDONE, prefs.GetProfileInt(sKey, "HideDone", FALSE));
		filter.SetFlag(FT_HIDECOLLAPSED, prefs.GetProfileInt(sKey, "HideCollapsed", FALSE));
	}
}

void CFilteredToDoCtrl::SaveFilter(const FTDCFILTER& filter, CPreferences& prefs, const CString& sSubKey) const
{
	CString sKey = GetPreferencesKey("Filter");

	if (!sKey.IsEmpty())
	{
		if (!sSubKey.IsEmpty())
			sKey += "\\" + sSubKey;

		prefs.WriteProfileInt(sKey, "Filter", filter.nFilter);
		prefs.WriteProfileString(sKey, "Title", filter.sTitle);
		prefs.WriteProfileInt(sKey, "Priority", filter.nPriority);
		prefs.WriteProfileInt(sKey, "Risk", filter.nRisk);
		prefs.WriteProfileString(sKey, "AllocBy", Misc::FormatArray(filter.aAllocBy));
		prefs.WriteProfileString(sKey, "Status", Misc::FormatArray(filter.aStatus));
		prefs.WriteProfileString(sKey, "Version", Misc::FormatArray(filter.aVersions));
		prefs.WriteProfileString(sKey, "AllocTo", Misc::FormatArray(filter.aAllocTo));
		prefs.WriteProfileString(sKey, "Category", Misc::FormatArray(filter.aCategories));

		// options
		prefs.WriteProfileInt(sKey, "AnyAllocTo", filter.HasFlag(FT_ANYALLOCTO));
		prefs.WriteProfileInt(sKey, "AnyCategory", filter.HasFlag(FT_ANYCATEGORY));
		prefs.WriteProfileInt(sKey, "HideParents", filter.HasFlag(FT_HIDEPARENTS));
		prefs.WriteProfileInt(sKey, "HideOverDue", filter.HasFlag(FT_HIDEOVERDUE));
		prefs.WriteProfileInt(sKey, "HideDone", filter.HasFlag(FT_HIDEDONE));
		prefs.WriteProfileInt(sKey, "HideCollapsed", filter.HasFlag(FT_HIDECOLLAPSED));
	}
}


void CFilteredToDoCtrl::OnDestroy() 
{
	if (m_nCurView != FTCV_UNSET)
	{
		CPreferences prefs;
		CString sKey = GetPreferencesKey(); // no subkey
		
		// save view
		if (!sKey.IsEmpty())
			prefs.WriteProfileInt(sKey, "View", m_nCurView);

		SaveFilter(m_filter, prefs);
		SaveFilter(m_lastFilter, prefs, "Last");
	}
		
	CToDoCtrl::OnDestroy();
}

void CFilteredToDoCtrl::BuildListColumns(BOOL bResizeCols)
{
	while (m_list.DeleteColumn(0));
	
	int nCol = NUM_COLUMNS - 1; // we handle title column separately
	
	while (nCol--)
	{
		const TDCCOLUMN& col = COLUMNS[nCol];
		UINT nFmt = col.nAlignment == DT_RIGHT ? LVCFMT_RIGHT : LVCFMT_LEFT;
		
		m_list.InsertColumn(0, "", nFmt, 10);
	}

	// title column
	if (HasStyle(TDCS_RIGHTSIDECOLUMNS))
		m_list.InsertColumn(0, "", LVCFMT_LEFT, 10);
	else
		m_list.InsertColumn(NUM_COLUMNS - 1, "", LVCFMT_LEFT, 10);

	if (bResizeCols)
		UpdateColumnWidths();
}

void CFilteredToDoCtrl::OnRClickHeader(NMHDR* /*pNMHDR*/, LRESULT* pResult)
{
	// forward on to parent
	const MSG* pMsg = GetCurrentMessage();
	LPARAM lPos = MAKELPARAM(pMsg->pt.x, pMsg->pt.y);

	GetParent()->SendMessage(WM_CONTEXTMENU, (WPARAM)GetSafeHwnd(), lPos);

	*pResult = 0;
}

void CFilteredToDoCtrl::OnEditChangeDueTime()
{
	// need some special hackery to prevent a re-filter in the middle
	// of the user manually typing into the time field
	BOOL bNeedsRefilter = ModNeedsRefilter(TDCA_DUEDATE, FTCV_TASKTREE);
	
	if (bNeedsRefilter)
		SetStyle(TDCS_REFILTERONMODIFY, FALSE, FALSE);
	
	CToDoCtrl::OnSelChangeDueTime();
	
	if (bNeedsRefilter)
		SetStyle(TDCS_REFILTERONMODIFY, TRUE, FALSE);
}


void CFilteredToDoCtrl::OnClickHeader(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMLISTVIEW* pNMLV = (NMLISTVIEW*)pNMHDR;
	
	int nCol = pNMLV->iSubItem;
	TDCCOLUMN* pCol = GetColumn(nCol);

	if (pCol->nSortBy != TDC_UNSORTED)
	{
		TDC_SORTBY nPrev = m_sortList.nBy1;
		Sort(pCol->nSortBy);

		// notify parent
		if (m_sortList.nBy1 != nPrev)
			GetParent()->SendMessage(WM_TDCN_SORT, GetDlgCtrlID(), MAKELPARAM((WORD)nPrev, (WORD)m_sortList.nBy1));
	}

	*pResult = 0;
}

void CFilteredToDoCtrl::OnTreeExpandItem(NMHDR* /*pNMHDR*/, LRESULT* /*pResult*/)
{
	if (m_filter.HasFlag(FT_HIDECOLLAPSED))
	{
		if (InListView())
			RefreshListFilter();
		else
			m_bListNeedRefilter = TRUE;
	}
}

void CFilteredToDoCtrl::OnListGetDispInfo(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMLVDISPINFO* lplvdi = (NMLVDISPINFO*)pNMHDR;
	*pResult = 0;

	UINT nMask = lplvdi->item.mask;
	DWORD dwTaskID = (DWORD)lplvdi->item.lParam;

	if ((nMask & LVIF_TEXT) &&  m_dwEditingID != dwTaskID)
	{
		TODOITEM* pTDI = GetTask(dwTaskID);

		// it's possible that the task does not exist if it's just been 
		// deleted from the tree view
		if (!pTDI)
			return;

		// all else
		lplvdi->item.pszText = (LPSTR)(LPCTSTR)pTDI->sTitle;
	}

	if (nMask & LVIF_IMAGE)
	{
		if (!HasStyle(TDCS_TREETASKICONS))
			lplvdi->item.iImage = -1;
		else
		{
			TODOITEM* pTDI = NULL;
			TODOSTRUCTURE* pTDS = NULL;
			m_data.GetTask(dwTaskID, pTDI, pTDS);

			BOOL bHasChildren = pTDS->HasSubTasks();
			int nImage = -1;
			
			if (pTDI->nIconIndex >= 0)
				nImage = pTDI->nIconIndex;
			
			else if (HasStyle(TDCS_SHOWPARENTSASFOLDERS) && bHasChildren)
				nImage = 0;
			
			lplvdi->item.iImage = nImage;
		}
	}
}

void CFilteredToDoCtrl::SetVisibleColumns(const CTDCColumnArray& aColumns)
{
	CToDoCtrl::SetVisibleColumns(aColumns);

	if (InListView())
		UpdateColumnWidths();
}

void CFilteredToDoCtrl::OnSelchangeTabcontrol(NMHDR* /*pNMHDR*/, LRESULT* pResult) 
{
	SetView((FTC_VIEW)m_tabCtrl.GetCurSel());

	*pResult = 0;
}

BOOL CFilteredToDoCtrl::ArchiveDoneTasks(LPCTSTR szFilePath, TDC_ARCHIVE nFlags, BOOL bRemoveFlagged)
{
	if (CToDoCtrl::ArchiveDoneTasks(szFilePath, nFlags, bRemoveFlagged))
	{
		if (InListView())
		{
			if (IsFilterSet(FTCV_TASKLIST))
				RefreshListFilter();
		}
		else if (IsFilterSet(FTCV_TASKTREE))
			RefreshTreeFilter();

		return TRUE;
	}

	// else
	return FALSE;
}

BOOL CFilteredToDoCtrl::ArchiveSelectedTasks(LPCTSTR szFilePath, BOOL bRemove)
{
	if (CToDoCtrl::ArchiveSelectedTasks(szFilePath, bRemove))
	{
		if (InListView())
		{
			if (IsFilterSet(FTCV_TASKLIST))
				RefreshListFilter();
		}
		else if (IsFilterSet(FTCV_TASKTREE))
			RefreshTreeFilter();

		return TRUE;
	}

	// else
	return FALSE;
}

int CFilteredToDoCtrl::GetArchivableTasks(CTaskFile& tasks, BOOL bSelectedOnly) const
{
	if (bSelectedOnly || !IsFilterSet(FTCV_TASKTREE))
		return CToDoCtrl::GetArchivableTasks(tasks, bSelectedOnly);

	// else
	GetCompletedTasks(m_data.GetStructure(), tasks, NULL, FALSE);

	return tasks.GetTaskCount();
}

BOOL CFilteredToDoCtrl::RemoveArchivedTask(DWORD dwTaskID)
{
	ASSERT(GetTask(dwTaskID));
	
	// note: if the tasks does not exist in the tree then this is not a bug
	// if a filter is set
	HTREEITEM hti = m_find.GetItem(dwTaskID);
	ASSERT(hti || IsFilterSet(FTCV_TASKTREE));
	
	if (!hti && !IsFilterSet(FTCV_TASKTREE))
		return FALSE;
	
	if (hti)
		m_tree.DeleteItem(hti);

	return m_data.DeleteTask(dwTaskID);
}

void CFilteredToDoCtrl::GetCompletedTasks(const TODOSTRUCTURE* pTDS, CTaskFile& tasks, HTASKITEM hTaskParent, BOOL bSelectedOnly) const
{
	const TODOITEM* pTDI = NULL;

	if (!pTDS->IsRoot())
	{
		DWORD dwTaskID = pTDS->GetTaskID();
		pTDI = GetTask(dwTaskID);
		ASSERT(pTDI);

		// we add the task if it is completed (and optionally selected) or it has children
		if (pTDI->IsDone() || pTDS->HasSubTasks())
		{
			HTASKITEM hTask = tasks.NewTask("", hTaskParent, dwTaskID);
			ASSERT(hTask);

			// copy attributes
			TDCGETTASKS allTasks;
			SetTaskAttributes(pTDI, pTDS, tasks, hTask, allTasks, -1, FALSE);

			// this task is now the new parent
			hTaskParent = hTask;
		}
	}

	// children
	if (pTDS->HasSubTasks())
	{
		for (int nSubtask = 0; nSubtask < pTDS->GetSubTaskCount(); nSubtask++)
		{
			const TODOSTRUCTURE* pTDSChild = pTDS->GetSubTask(nSubtask);
			GetCompletedTasks(pTDSChild, tasks, hTaskParent, bSelectedOnly);
		}

		// if no subtasks were added and the parent is not completed 
		// (and optionally selected) then we remove it
		if (hTaskParent && tasks.GetFirstTask(hTaskParent) == NULL)
		{
			ASSERT(pTDI);

			if (!pTDI->IsDone())
				tasks.DeleteTask(hTaskParent);
		}
	}
}

void CFilteredToDoCtrl::SetView(FTC_VIEW nView) 
{
	if (nView == FTCV_UNSET)
	{
		ASSERT(0);
		return;
	}

	if (m_nCurView == nView)
		return;

	m_nCurView = nView;

	// show the incoming selection and hide the outgoing in that order
	BOOL bFiltered = FALSE;

	// take a note of what task is currently singly selected
	// so that we can prevent unnecessary calls to UpdateControls
	DWORD dwSelTaskID = (GetSelectedCount() == 1) ? GetTaskID(GetSelectedItem()) : 0;
	
	switch (nView)
	{
	case FTCV_TASKTREE:
		// make sure something is selected
		if (GetSelectedCount() == 0)
		{
			HTREEITEM hti = m_tree.GetSelectedItem();

			if (!hti)
				hti = m_tree.GetChildItem(NULL);

			CToDoCtrl::SelectTask(GetTaskID(hti));
		}

		// update sort
		if (m_bTreeNeedResort)
		{
			m_bTreeNeedResort = FALSE;
			Resort();
		}

		m_tree.EnsureVisible(Selection().GetFirstItem());
		m_tree.ShowWindow(SW_SHOW);

		m_list.ShowWindow(SW_HIDE);
		m_tree.SetFocus();
		break;

	case FTCV_TASKLIST:
		// processed any unhandled comments
		HandleUnsavedComments(); 		
		
		if (!m_header.GetSafeHwnd())
		{
			m_header.SubclassDlgItem(0, &m_list);
			m_header.EnableTracking(FALSE);

			// set the prompt now we know how tall the header is
			CRect rHeader;
			m_header.GetWindowRect(rHeader);
			m_list.ScreenToClient(rHeader);
			m_mgrPrompts.SetPrompt(m_list, IDS_TDC_FILTEREDTASKLISTPROMPT, LVM_GETITEMCOUNT, 0, rHeader.bottom);
		}

		// make sure row height is correct by forcing a WM_MEASUREITEM
		RemeasureList();

		// update column widths
		UpdateColumnWidths();

		// update filter
		bFiltered = m_bListNeedRefilter;

		if (m_bListNeedRefilter)
			RefreshListFilter();

		// update sort
		if (m_bListNeedResort)
		{
			m_bListNeedResort = FALSE;
			Resort();
		}

		// restore selection
		ResyncListSelection();

		m_list.EnsureVisible(GetFirstSelectedItem(), FALSE);

		m_list.ShowWindow(SW_SHOW);
		m_list.SetFocus();
		m_tree.ShowWindow(SW_HIDE);

		break;
	}
	
	// update controls only if the selection has changed and 
	// we didn't refilter (RefreshFilter will already have called UpdateControls)
	BOOL bSelChange = !(GetSelectedCount() == 1 && GetTaskID(GetSelectedItem()) == dwSelTaskID);
	
	if (bSelChange && !bFiltered)
		UpdateControls();

	m_tabCtrl.SetCurSel((int)nView);

	// notify parent
	GetParent()->PostMessage(WM_TDCN_VIEWCHANGE);
}

void CFilteredToDoCtrl::RemeasureList()
{
	CRect rList;
	m_list.GetWindowRect(rList);
	ScreenToClient(rList);

	WINDOWPOS wpos = { m_list, NULL, rList.left, rList.top, rList.Width(), rList.Height(), SWP_NOZORDER };
	m_list.SendMessage(WM_WINDOWPOSCHANGED, 0, (LPARAM)&wpos);
}

void CFilteredToDoCtrl::UpdateColumnWidths()
{
	if (!InListView())
		return;

	int nCol = NUM_COLUMNS;
	int nTotalWidth = 0;
	BOOL bFirstWidth = TRUE;
	
	for (nCol = 0; nCol < NUM_COLUMNS; nCol++)
	{
		const TDCCOLUMN* pCol = GetColumn(nCol);
		ASSERT(pCol);

		if (pCol->nColID == TDCC_CLIENT)
			continue; // we'll deal with this at the end

		int nWidth = m_tree.GetColumnWidth(pCol->nColID);

		if (nWidth && bFirstWidth)
		{
			bFirstWidth = FALSE;
			nWidth += 1;
		}

		// sort indicator 
		if (IsColumnShowing(pCol->nColID))
		{
			BOOL bTreeColWidened = !(m_bMultiSort || m_sort.nBy1 == TDC_UNSORTED) && m_sort.nBy1 == pCol->nSortBy;
			BOOL bListColWidened = !(m_bListMultiSort || m_sortList.nBy1 == TDC_UNSORTED) && m_sortList.nBy1 == pCol->nSortBy;

			if (!bTreeColWidened && bListColWidened)
				nWidth += SORTWIDTH;

			else if (bTreeColWidened && !bListColWidened)
				nWidth -= SORTWIDTH;
		}

		m_list.SetColumnWidth(nCol, nWidth);

		nTotalWidth += nWidth;
	}

	// client column is what's left
	CRect rList;
	m_list.GetClientRect(rList);

	int nColWidth = max(300, rList.Width() - nTotalWidth);
	m_list.SetColumnWidth(GetColumnIndex(TDCC_CLIENT), nColWidth);

	m_list.Invalidate(FALSE);
	m_list.UpdateWindow();
}

void CFilteredToDoCtrl::ReposTaskTree(CDeferWndMove* pDWM, const CRect& rPos)
{
	// position tab ctrl below task tree
	CRect rTabs(0, 0, rPos.Width(), 0);
	m_tabCtrl.AdjustRect(TRUE, rTabs);

	int nTabHeight = rTabs.Height();
	rTabs = rPos;
	rTabs.right += 2;
	rTabs.top = rTabs.bottom - nTabHeight + 3;

	pDWM->MoveWindow(&m_tabCtrl, rTabs);

	// adjust rect for tab ctrl
	CRect rList(rPos);
	rList.bottom = rTabs.top + 1;

	CToDoCtrl::ReposTaskTree(pDWM, rList);

	pDWM->MoveWindow(&m_list, rList);
}

void CFilteredToDoCtrl::UpdateTasklistVisibility()
{
	BOOL bTasksVis = (m_nMaxState != TDCMS_MAXCOMMENTS);

	if (InListView())
		m_list.ShowWindow(bTasksVis ? SW_SHOW : SW_HIDE);
	else
		CToDoCtrl::UpdateTasklistVisibility();
}

v