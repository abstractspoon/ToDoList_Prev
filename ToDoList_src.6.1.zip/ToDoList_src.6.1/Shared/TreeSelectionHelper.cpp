	case DT_CENTER:
		rText.right--;
	}
	
	BOOL bDown = (nState & CDIS_SELECTED);
	BOOL bSorted = (IsSortable() && m_sortList.nBy1 == pCol->nSortBy && !m_bListMultiSort);
	
	if (bDown)
		rText.OffsetRect(1, 1);
	
	if (bSorted)
		rText.right -= (SORTWIDTH + 2);

	if (pCol->szFont && *pCol->szFont)
	{
		CFont* pOldFont = NULL;

		if (CString(pCol->szFont).CompareNoCase("WingDings") == 0)
			pOldFont = pDC->SelectObject(&GraphicsMisc::WingDings());
		
		else if (CString(pCol->szFont).CompareNoCase("Marlett") == 0)
			pOldFont = pDC->SelectObject(&GraphicsMisc::Marlett());
		
		pDC->DrawText(sColumn, rText, DEFFLAGS | pCol->nAlignment);
		
		if (pOldFont)
			pDC->SelectObject(pOldFont);
	}
	else
		pDC->DrawText(sColumn, rText, DEFFLAGS | pCol->nAlignment);

	// draw sort direction if required
	if (bSorted)
	{
		// adjust for sort arrow
		if (pCol->nAlignment & DT_CENTER)
			rText.left = ((rText.left + rText.right + pDC->GetTextExtent(sColumn).cx) / 2) + 2;
			
		else if (pCol->nAlignment & DT_RIGHT)
			rText.left = rText.right + 2;
		else
			rText.left = rText.left + pDC->GetTextExtent(sColumn).cx + 2;

		BOOL bAscending = m_sortList.bAscending1 ? 1 : -1;
		int nMidY = (bDown ? 1 : 0) + (rText.top + rText.bottom) / 2;
		POINT ptArrow[3] = { 
							{ 0, 0 }, 
							{ 3, -bAscending * 3 }, 
							{ 7, bAscending } };
		
		// translate the arrow to the appropriate location
		int nPoint = 3;
		
		while (nPoint--)
		{
			ptArrow[nPoint].x += rText.left + 3 + (bDown ? 1 : 0);
			ptArrow[nPoint].y += nMidY;
		}
		pDC->Polyline(ptArrow, 3);
	}
}


TDC_COLUMN CFilteredToDoCtrl::GetColumnID(int nCol) const
{
	TDCCOLUMN* pCol = GetColumn(nCol);
	return pCol ? pCol->nColID : (TDC_COLUMN)-1;
}

TDCCOLUMN* CFilteredToDoCtrl::GetColumn(int nCol) const
{
	if (nCol < 0 || nCol >= NUM_COLUMNS)
		return NULL;

	// else
	if (HasStyle(TDCS_RIGHTSIDECOLUMNS))
	{
		if (nCol == 0)
			return &COLUMNS[NUM_COLUMNS - 1];
		else
			return &COLUMNS[nCol - 1];
	}
	
	// else
	return &COLUMNS[nCol];

}

int CFilteredToDoCtrl::GetColumnIndex(TDC_COLUMN nColID) const
{
	if (HasStyle(TDCS_RIGHTSIDECOLUMNS))
	{
		if (nColID == TDCC_CLIENT)
			return 0;

		// else it's 1 more than the COLUMNS index
		int nCol = NUM_COLUMNS - 1;

		while (nCol--)
		{
			if (COLUMNS[nCol].nColID == nColID)
				return nCol + 1;
		}
		
		ASSERT(0);
		return 0;
	}
	
	// else as COLUMNS
	int nCol = NUM_COLUMNS;
	
	while (nCol--)
	{
		if (COLUMNS[nCol].nColID == nColID)
			return nCol;
	}
	
	ASSERT(0);
	return 0;
}

BOOL CFilteredToDoCtrl::SetStyles(const CTDCStyles& styles)
{
	if (CToDoCtrl::SetStyles(styles))
	{
		// do we need to refilter?
		if (m_bListNeedRefilter)
		{
			RefreshTreeFilter(); // always

			if (InListView())
				RefreshListFilter();
		}

		return TRUE;
	}

	return FALSE;
}

BOOL CFilteredToDoCtrl::SetStyle(TDC_STYLE nStyle, BOOL bOn, BOOL bWantUpdate)
{
	// base class processing
	if (CToDoCtrl::SetStyle(nStyle, bOn, bWantUpdate))
	{
		// post-precessing
		switch (nStyle)
		{
		case TDCS_DUEHAVEHIGHESTPRIORITY:
		case TDCS_DONEHAVELOWESTPRIORITY:
			m_bListNeedRefilter = TRUE;
			break;

		case TDCS_TREATSUBCOMPLETEDASDONE:
			if (m_filter.nFilter != FT_ALL)
				m_bListNeedRefilter = TRUE;
			break;

		case TDCS_RIGHTSIDECOLUMNS:
			BuildListColumns();
			break;

		case TDCS_SHOWINFOTIPS:
			ListView_SetExtendedListViewStyleEx(m_list, LVS_EX_INFOTIP, bOn ? LVS_EX_INFOTIP : 0);
			break;

		case TDCS_TREETASKICONS:
			if (bOn && !IsColumnShowing(TDCC_ICON)) // this overrides
				ListView_SetImageList(m_list, m_ilTaskIcons, LVSIL_NORMAL);
			else
				ListView_SetImageList(m_list, NULL, LVSIL_NORMAL);
			break;
			
		}

		return TRUE;
	}

	return FALSE;
}

void CFilteredToDoCtrl::InitFilterDueDate(COleDateTime& dateDue) const
{
	switch (m_filter.nFilter)
	{
	case FT_ALL:
	case FT_DONE:
	case FT_NOTDONE:
	case FT_FLAGGED:
	case FT_STARTTODAY:
	case FT_STARTENDTHISWEEK:
		dateDue.m_dt = 0;
		break;

	case FT_DUETODAY:
		dateDue = CDateHelper::GetDate(DHD_TODAY);
		break;

	case FT_DUETOMORROW:
		dateDue = CDateHelper::GetDate(DHD_TOMORROW);
		break;

	case FT_DUEENDTHISWEEK:
		dateDue = CDateHelper::GetDate(DHD_ENDTHISWEEK);
		break;

	case FT_DUEENDNEXTWEEK: 
		dateDue = CDateHelper::GetDate(DHD_ENDNEXTWEEK);
		break;

	case FT_DUEENDTHISMONTH:
		dateDue = CDateHelper::GetDate(DHD_ENDTHISMONTH);
		break;

	case FT_DUEENDNEXTMONTH:
		dateDue = CDateHelper::GetDate(DHD_ENDNEXTMONTH);
		break;

	case FT_DUEENDTHISYEAR:
		dateDue = CDateHelper::GetDate(DHD_ENDTHISYEAR);
		break;

	case FT_DUEENDNEXTYEAR:
		dateDue = CDateHelper::GetDate(DHD_ENDNEXTYEAR);
		break;

	case FT_DUENEXTSEVENDAYS:
		dateDue = CDateHelper::GetDate(DHD_TODAY) + 6; // +6 because filter is FO_ON_OR_BEFORE
		break;

	default:
		ASSERT(0); // to help highlight missing filters
		break;
	}
}

BOOL CFilteredToDoCtrl::DeleteSelectedTask(BOOL bWarnUser, BOOL bResetSel)
{
	BOOL bDel = CToDoCtrl::DeleteSelectedTask(bWarnUser, bResetSel);

	if (bDel && InListView())
	{
		// work out what to select
		DWORD dwSelID = GetSelectedTaskID();
		int nSel = FindTask(dwSelID);

		if (nSel == -1 && m_list.GetItemCount())
			nSel = 0;

		if (nSel != -1)
			SelectTask(m_list.GetItemData(nSel));
	}

	return bDel;
}

BOOL CFilteredToDoCtrl::SelectedTasksHaveChildren() const
{
	return CToDoCtrl::SelectedTasksHaveChildren();
}

TODOITEM* CFilteredToDoCtrl::NewTask(HTREEITEM htiParent)
{
	TODOITEM* pTDI = CToDoCtrl::NewTask(htiParent);

	// fiddle with the default attributes so that the task 
	// will not be filtered out by the current filter
	if (/*InListView() &&*/ HasFilter())
	{
		if (m_filter.nRisk != FT_ANYRISK)
			pTDI->nRisk = max(pTDI->nRisk, m_filter.nRisk);

		if (m_filter.nPriority != FT_ANYPRIORITY)
			pTDI->nPriority = max(pTDI->nPriority, m_filter.nPriority);

		if (m_filter.aAllocBy.GetSize() && pTDI->sAllocBy.IsEmpty())
			pTDI->sAllocBy = m_filter.aAllocBy[0];

		if (m_filter.aVersions.GetSize() && pTDI->sVersion.IsEmpty())
			pTDI->sVersion = m_filter.aVersions[0];

		if (m_filter.aStatus.GetSize() && pTDI->sStatus.IsEmpty())
			pTDI->sStatus = m_filter.aStatus[0];

		if (!m_filter.MatchAllocTo(pTDI->aAllocTo))
		{
			// if any category will match then set it to the first
			if (m_filter.HasFlag(FT_ANYALLOCTO))
			{
				pTDI->aAllocTo.RemoveAll();

				if (m_filter.aAllocTo.GetSize())
					pTDI->aAllocTo.Add(m_filter.aAllocTo[0]);
			}
			else // set it to all the filter cats
				pTDI->aAllocTo.Copy(m_filter.aAllocTo);
		}

		if (!m_filter.MatchCategories(pTDI->aCategories))
		{
			// if any category will match then set it to the first
			if (m_filter.HasFlag(FT_ANYCATEGORY))
			{
				pTDI->aCategories.RemoveAll();

				if (m_filter.aCategories.GetSize())
					pTDI->aCategories.Add(m_filter.aCategories[0]);
			}
			else // set it to all the filter cats
				pTDI->aCategories.Copy(m_filter.aCategories);
		}

		// if the filter is FT_DONE then complete the task
		switch (m_filter.nFilter)
		{
		case FT_ALL:
		case FT_NOTDONE:
			break;
		case FT_FLAGGED:
			pTDI->bFlagged = TRUE;
			break;
			
		case FT_DONE:
			pTDI->dateDone = floor(COleDateTime::GetCurrentTime());
			break;
			
		case FT_STARTTODAY:
		case FT_STARTENDTHISWEEK:
			pTDI->dateStart = floor(COleDateTime::GetCurrentTime());
			break;
			
		case FT_DUETODAY:
		case FT_DUETOMORROW:
		case FT_DUEENDTHISWEEK:
		case FT_DUEENDNEXTWEEK: 
		case FT_DUEENDTHISMONTH:
		case FT_DUEENDNEXTMONTH:
		case FT_DUEENDTHISYEAR:
		case FT_DUEENDNEXTYEAR:
			pTDI->dateDue = floor(COleDateTime::GetCurrentTime());
			break;
			
		default:
			ASSERT(0);
			break;
		}
	}

	return pTDI;
}

HTREEITEM CFilteredToDoCtrl::NewTask(LPCTSTR szText, TDC_INSERTWHERE nWhere, 
									/*BOOL bSelect, */BOOL bEditText)
{
	BOOL bWantEditText = bEditText;

	if (InListView())
		bEditText = FALSE;

	HTREEITEM htiNew = CToDoCtrl::NewTask(szText, nWhere, /*bSelect, */bEditText);

	if (htiNew)
	{
		if (InListView())
		{
			DWORD dwTaskID = GetTaskID(htiNew);
			ASSERT(dwTaskID == m_dwNextUniqueID - 1);

			// make the new task appear
			RefreshListFilter(); 

			// select that task
			SelectTask(dwTaskID);
			
			if (bWantEditText)
			{
				m_dwLastAddedID = dwTaskID;
				EditSelectedTask(TRUE);
			}
		}
		else
			m_bListNeedRefilter = TRUE;
	}

	return htiNew;
}

BOOL CFilteredToDoCtrl::SplitSelectedTask(int nNumSubtasks)
{
   if (CToDoCtrl::SplitSelectedTask(nNumSubtasks))
   {
      if (InListView())
         RefreshListFilter();
 
      return TRUE;
   }
 
   return FALSE;
}

void CFilteredToDoCtrl::SetModified(BOOL bMod, TDC_ATTRIBUTE nAttrib)
{
	if (bMod)
	{
		m_data.ResetCachedCalculations();

		if (ModNeedsRefilter(nAttrib, FTCV_TASKTREE))
			PostMessage(WM_TDC_REFRESHFILTER, FTCV_TASKTREE, (nAttrib == TDCA_UNDO));

		else if (ModNeedsRefilter(nAttrib, FTCV_TASKLIST))
		{
			if (InListView())
				PostMessage(WM_TDC_REFRESHFILTER, FTCV_TASKLIST, (nAttrib == TDCA_UNDO));
			else
				m_bListNeedRefilter = TRUE;
		}

		if (nAttrib == TDCA_DELETE || nAttrib == TDCA_ARCHIVE)
			RemoveDeletedListItems();

		else if (InListView())
			m_list.Invalidate(FALSE);
	}
	
	CToDoCtrl::SetModified(bMod, nAttrib);
}

BOOL CFilteredToDoCtrl::ModNeedsResort(TDC_ATTRIBUTE nModType) const
{
	// need to check all three sort attributes if multisorting
	BOOL bListNeedsResort = CToDoCtrl::ModNeedsResort(nModType, m_sortList.nBy1);

	if (!bListNeedsResort && m_bListMultiSort)
	{
		bListNeedsResort |= CToDoCtrl::ModNeedsResort(nModType, m_sortList.nBy2);
		
		if (!bListNeedsResort)
			bListNeedsResort |= CToDoCtrl::ModNeedsResort(nModType, m_sortList.nBy3);
	}

	BOOL bTreeNeedsResort = CToDoCtrl::ModNeedsResort(nModType);

	if (InListView())
	{
		m_bTreeNeedResort |= bTreeNeedsResort;
		return bListNeedsResort;
	}
	else // tree view
	{
		m_bListNeedResort |= bListNeedsResort;
		return bTreeNeedsResort;
	}
}

void CFilteredToDoCtrl::ResortSelectedTaskParents() 
{ 
	// do a full sort
	Resort();
}

TDC_SORTBY CFilteredToDoCtrl::GetSortBy() const 
{ 
	return InListView() ? m_sortList.nBy1 : m_sort.nBy1; 
}

void CFilteredToDoCtrl::GetSortBy(TDSORTCOLUMNS& sort) const
{
	if (InListView())
		sort = m_sortList;
	else
		CToDoCtrl::GetSortBy(sort); 

}

BOOL CFilteredToDoCtrl::ModNeedsRefilter(TDC_ATTRIBUTE nModType, FTC_VIEW nView) const
{
	if (!HasStyle(TDCS_REFILTERONMODIFY))
		return FALSE;

	BOOL bNeedRefilter = FALSE;

	if (m_bCustomFilter)
	{
		bNeedRefilter = m_customFilter.HasAttribute(nModType); 
	}
	else if (HasFilter())
	{
	switch (nModType)
	{
		case TDCA_TASKNAME:		
			bNeedRefilter = !m_filter.sTitle.IsEmpty(); 
			break;

	case TDCA_PRIORITY:		
		bNeedRefilter = (m_filter.nPriority != -1); 
		break;

	case TDCA_FLAG:		
		bNeedRefilter = (m_filter.nFilter == FT_FLAGGED); 
		break;

	case TDCA_RISK:			
		bNeedRefilter = (m_filter.nRisk != -1);
		break;
		
	case TDCA_ALLOCBY:		
		bNeedRefilter = (m_filter.aAllocBy.GetSize() != 0);
		break;

	case TDCA_STATUS:		
		bNeedRefilter = (m_filter.aStatus.GetSize() != 0);
		break;

	case TDCA_VERSION:		
		bNeedRefilter = (m_filter.aVersions.GetSize() != 0);
		break;

	case TDCA_CATEGORY:		
		bNeedRefilter = (m_filter.aCategories.GetSize() != 0);
		break;

	case TDCA_ALLOCTO:		
		bNeedRefilter = (m_filter.aAllocTo.GetSize() != 0);
		break;

	case TDCA_PERCENT:
		bNeedRefilter = (m_filter.nFilter == FT_DONE || 
						m_filter.nFilter == FT_NOTDONE);
		break;

	case TDCA_DONEDATE:		
		bNeedRefilter = (m_filter.nFilter == FT_DONE || 
						m_filter.nFilter == FT_NOTDONE ||
						m_filter.nFilter == FT_STARTTODAY ||
						m_filter.nFilter == FT_STARTENDTHISWEEK ||
						m_filter.HasFlag(FT_HIDEDONE) ||
						m_filter.nPriority > 0);
		break;
		
	case TDCA_DUEDATE:		
		bNeedRefilter = m_filter.HasFlag(FT_HIDEOVERDUE) ||
						(m_filter.nPriority > 0) ||
						(m_filter.nFilter != FT_DONE &&
						m_filter.nFilter != FT_NOTDONE &&
						m_filter.nFilter != FT_ALL &&
						m_filter.nFilter != FT_STARTTODAY &&
						m_filter.nFilter != FT_STARTENDTHISWEEK);
		break;

	case TDCA_STARTDATE:		
		bNeedRefilter = (m_filter.nFilter == FT_STARTTODAY ||
						m_filter.nFilter == FT_STARTENDTHISWEEK);
		break;
		}
	}

	// handle attributes common to both filter types
	if (!bNeedRefilter)
	{
		switch (nModType)
		{
	case TDCA_NEWTASK:
		// if we refilter in the middle of adding a task it messes
		// up the tree items so we handle it in NewTask
		break;

	case TDCA_DELETE:
		// this is handled in SetModified
		break;

	case TDCA_COPY:
	case TDCA_UNDO:
		bNeedRefilter = TRUE;
		break;

	case TDCA_MOVE:
		bNeedRefilter = (nView == FTCV_TASKLIST && !IsSortable());
		break;
	}
	}

	return bNeedRefilter;
}

BOOL CFilteredToDoCtrl::SelectTask(DWORD dwTaskID)
{
	BOOL bRes = CToDoCtrl::SelectTask(dwTaskID);

	// check task has not been filtered out
	if (InListView())
	{
		int nItem = FindTask(dwTaskID);

		if (nItem == -1)
		{
			ASSERT(0);
			return FALSE;
		}
		
		// remove focused state from existing task
		int nFocus = m_list.GetNextItem(-1, LVNI_FOCUSED | LVNI_SELECTED);

		if (nFocus != -1)
			m_list.SetItemState(nFocus, 0, LVIS_SELECTED | LVIS_FOCUSED);

		m_list.SetItemState(nItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
		m_list.EnsureVisible(nItem, FALSE);
	}

	return bRes;
}

LRESULT CFilteredToDoCtrl::OnEditCancel(WPARAM wParam, LPARAM lParam)
{
	// check if we need to delete the just added item
	if (InListView() && GetSelectedTaskID() == m_dwLastAddedID)
	{
		int nDelItem = GetFirstSelectedItem();
		m_list.DeleteItem(nDelItem);
	}

	LRESULT lr = CToDoCtrl::OnEditCancel(wParam, lParam);

	return lr;
}

int CFilteredToDoCtrl::FindTask(DWORD dwTaskID) const
{
	LVFINDINFO lvfi;
	ZeroMemory(&lvfi, sizeof(lvfi));

    lvfi.flags = LVFI_PARAM;
    lvfi.lParam = dwTaskID;
    lvfi.vkDirection = VK_DOWN;

	return m_list.FindItem(&lvfi);
}

DWORD CFilteredToDoCtrl::GetFocusedListTaskID() const
{
	int nItem = m_list.GetNextItem(-1, LVNI_FOCUSED | LVNI_SELECTED);

	if (nItem != -1)
		return m_list.GetItemData(nItem);

	// else
	return 0;
}

void CFilteredToDoCtrl::SetSelectedListTasks(const CDWordArray& aTaskIDs, DWORD dwFocusedTaskID)
{
	int nSel = -1;

	for (int nTask = 0; nTask < aTaskIDs.GetSize(); nTask++)
	{
		DWORD dwTaskID = aTaskIDs[nTask];
		int nItem = FindTask(dwTaskID);

		if (nItem != -1)
		{
			if (dwTaskID == dwFocusedTaskID)
				m_list.SetItemState(nItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
			else
				m_list.SetItemState(nItem, LVIS_SELECTED, LVIS_SELECTED);

			if (nSel == -1)
				nSel = nItem;
		}
		else // deselect in tree
		{
			HTREEITEM hti = m_find.GetItem(dwTaskID);
			Selection().SetItem(hti, TSHS_DESELECT, FALSE);
		}
	}

	// focused item
	if (dwFocusedTaskID)
	{
		int nItem = FindTask(dwFocusedTaskID);

		if (nItem != -1)
		{
			m_list.SetItemState(nItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
			nSel = nItem;
		}
	}

	// make sure selection is visible
	if (nSel != -1)
		m_list.EnsureVisible(nSel, FALSE);
}

LRESULT CFilteredToDoCtrl::OnGutterWidthChange(WPARAM wParam, LPARAM lParam)
{
	CToDoCtrl::OnGutterWidthChange(wParam, lParam);

	// update column widths if in list view
	if (InListView())
		UpdateColumnWidths();
	
	return 0;
}

void CFilteredToDoCtrl::OnListSelChanged(NMHDR* /*pNMHDR*/, LRESULT* pResult)
{
/*
	if (!m_bResyncingSel)
		TRACE ("CFilteredToDoCtrl::OnListSelChanged\n");

	LPNMLISTVIEW lpLV = (LPNMLISTVIEW)pNMHDR;

	if (!m_bResyncingSel && (lpLV->uChanged & LVIF_STATE))
	{
		TRACE ("CFilteredToDoCtrl::OnListSelChanged\n");

		CHoldRedraw hr(GetSafeHwnd());
		CHoldRedraw hr2(m_list);

		BOOL bSelectedOnly = (lpLV->uNewState & LVIS_SELECTED);
		BOOL bWasSelected = (lpLV->uOldState & LVIS_SELECTED);

		if (bSelectedOnly != bWasSelected)
		{
			HTREEITEM hti = m_data.GetItem(lpLV->lParam);
			Selection().SetItem(hti, bSelectedOnly ? TSHS_SELECT : TSHS_DESELECT, FALSE);