d != 'only' or @FLAG)]">
					<xsl:sort 
						select="@PRIORITY" 
						data-type="number"
						order="descending"
						/>
					<xsl:sort 
						select="@ID" 
						data-type="number"
						/>
					
					<xsl:if test="not(@DONEDATESTRING)">
						<xsl:call-template name="get_Task"/>
					</xsl:if>
				</xsl:for-each>
				</xsl:if>
			</xsl:otherwise>
		</xsl:choose>
		
		</table>
		</body>
		</html>
	</xsl:template>


	<!-- 20 - header of table - titles of columns -->
	<xsl:template name="get_Header">
		<xsl:element name="tr">
			<xsl:attribute name="class">header</xsl:attribute>
			<xsl:element name="td">
				<xsl:attribute name="class">header headerid</xsl:attribute>
				<xsl:attribute name="width">15</xsl:attribute>
				<xsl:text>ID</xsl:text>
			</xsl:element>
			<xsl:element name="td">
				<xsl:attribute name="class">header headerprior</xsl:attribute>
				<xsl:attribute name="width">15</xsl:attribute>
				<xsl:text>!</xsl:text>
			</xsl:element>
			<xsl:element name="td">
				<xsl:attribute name="class">header headerprogress</xsl:attribute>
				<xsl:attribute name="width">25</xsl:attribute>
				<xsl:text>%</xsl:text>
			</xsl:element>
			<xsl:element name="td">
				<xsl:attribute name="class">header</xsl:attribute>
				<xsl:attribute name="width">80</xsl:attribute>
				<xsl:text>Due</xsl:text>
			</xsl:e