aListTaskIDs))
	{
		MultiSelectItems(aListTaskIDs, TSHS_SELECT, FALSE);

		// also set the focused item
		m_list.SetItemState(FindTask(dwFocusedID), LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
		m_list.Invalidate(FALSE);
	}
}

BOOL CFilteredToDoCtrl::IsItemSelected(int nItem) const
{
	HTREEITEM hti = GetTreeItem(nItem);
	return hti ? Selection().HasItem(hti) : FALSE;
}

HTREEITEM CFilteredToDoCtrl::GetTreeItem(int nItem) const
{
	if (nItem < 0 || nItem >= m_list.GetItemCount())
		return NULL;

	DWORD dwID = m_list.GetItemData(nItem);
	return m_find.GetItem(dwID);
}

int CFilteredToDoCtrl::GetListItem(HTREEITEM hti) const
{
	DWORD dwID = GetTaskID(hti);
	return (dwID ? FindTask(dwID) : -1);
}

BOOL CFilteredToDoCtrl::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	if (&m_list == pWnd)
	{
		CPoint pt(::GetMessagePos());
		m_list.ScreenToClient(&pt);

		LVHITTESTINFO lvhti = { { pt.x, pt.y }, 0, 0, 0 };
		m_list.SubItemHitTest(&lvhti);

		int nHit = lvhti.iItem;

		if (nHit >= 0)
		{
			TDC_COLUMN nCol	= GetColumnID(lvhti.iSubItem);
			//HTREEITEM htiHit = GetTreeItem(nHit);
			DWORD dwID = m_list.GetItemData(nHit);

			BOOL bCtrl = Misc::ModKeysArePressed(MKS_CTRL);
			BOOL bShowHand = FALSE;

			switch (nCol)
			{
			case TDCC_FILEREF:
				if (bCtrl)
				{
					CString sFile = m_data.GetTaskFileRef(dwID);
					bShowHand = (!sFile.IsEmpty());
				}
				break;
				
			case TDCC_DEPENDENCY:
				if (bCtrl)
				{
					CStringArray aDepends;
					m_data.GetTaskDependencies(dwID, aDepends);
					bShowHand = aDepends.GetSize();
				}
				break;
				
			case TDCC_TRACKTIME:
				if (!IsReadOnly())
				{
					bShowHand = ((!IsItemSelected(nHit) || GetSelectedCount() == 1) && 
								 m_data.IsTaskTimeTrackable(dwID));
				}
				break;
				
			case TDCC_FLAG:
				if (!IsReadOnly())
					bShowHand = TRUE;
			}

			if (bShowHand)
			{
				::SetCursor(GraphicsMisc::HandCursor());
				return TRUE;
			}
		}
	}
		
	return CToDoCtrl::OnSetCursor(pWnd, nHitTest, message);
}

LRESULT CFilteredToDoCtrl::OnDropFileRef(WPARAM wParam, LPARAM lParam)
{
	int nItem = wParam;
	
	if (!InListView() || nItem == -1)
		return CToDoCtrl::OnDropFileRef(wParam, lParam);

	// else
	if (!IsReadOnly())
	{
		SelectTask(m_list.GetItemData(nItem));
		SetSelectedTaskFileRef((LPCTSTR)lParam);
	}
	
	return 0;
}

BOOL CFilteredToDoCtrl::GetItemTitleRect(HTREEITEM hti, TDC_TITLERECT