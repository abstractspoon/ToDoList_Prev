,'&#13;&#10;')" />
					</xsl:with-param>
				</xsl:call-template>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="$text" />
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
	
	
	<!-- 70 - generate CSS styles -->
	<xsl:template name="style">
		<xsl:element name="style">
			<xsl:attribute name="type">text/css</xsl:attribute>
			<xsl:text>
table.finished{
	border-bottom: 1px solid Black;
	border-right: 1px solid Black;
	border-top: 2px solid Black;
	border-left: 2px solid Black;
	width: 100%;
	vertical-align: top;
}
tr.header{
	background-color: #33ccff;
	font-weight: bold;
}
tr.lead{
	font-weight: bold;
}
td.header{
	border-bottom: 2px solid Black;
	border-right: 1px solid Black;
	font-size: small;
	padding: 1px;
}
td.headerid{
	text-align:right;
}
td.headerprior{
	text-align:center;
}
td.headerprogress{
	text-align:center;
}
td.bbasic{
	border-bottom: 1px solid Black;
	border-right: 1px solid Black;
	font-size: small;
	padding-top: 1px;
	padding-bottom: 1px;
	padding-left: 2px;
	padding-right: 2px;
	vertical-align: top;
}
td.taskid{
	text-align:right;
}
td.due{
	text-align:right;
}
td.progress{
	text-align:center;
}
td.prior{
	text-align:center;
	color: white;
}
td.category{
	text-align:left;
}
td.status{
	text-align:left;
}
td.task{
	text-align:left;
}
td.to{
	text-align:left;
}
td.empty{
	color:white;
}

a.flagged{
	font-weight:bold;
}
a { color:blac