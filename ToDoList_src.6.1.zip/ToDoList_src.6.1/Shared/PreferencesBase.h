r);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreferencesFilePage::OnRemovearchiveditems() 
{
	UpdateData();

	GetDlgItem(IDC_REMOVEONLYONABSCOMPLETION)->EnableWindow(m_bRemoveArchivedTasks);
	GetDlgItem(IDC_DONTREMOVEFLAGGED)->EnableWindow(m_bRemoveArchivedTasks);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesFilePage::OnNotifyDueOnLoad() 
{
	UpdateData();
	
	GetDlgItem(IDC_NOTIFYDUEBYONLOAD)->EnableWindow(m_bNotifyDueOnLoad);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesFilePage::OnNotifyDueOnSwitch() 
{
	UpdateData();
	
	GetDlgItem(IDC_NOTIFYDUEBYONSWITCH)->EnableWindow(m_bNotifyDueOnSwitch);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesFilePage::OnDisplayduetasksinhtml() 
{
	UpdateData();
	
	GetDlgItem(IDC_USESTYLESHEETFORDUEITEMS)->EnableWindow(m_bDisplayDueTasksInHtml);
	GetDlgItem(IDC_DUETASKSTYLESHEET)->EnableWindow(m_bDisplayDueTasksInHtml && m_bUseStyleSheetForDueTasks);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesFilePage::OnUsestylesheetfordueitems() 
{
	UpdateData();
	
	GetDlgItem(IDC_DUETASKSTYLESHEET)->EnableWindow(m_bDisplayDueTasksInHtml && m_bUseStyleSheetForDueTasks);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesFilePage::OnOnlyshowduetaskforperson() 
{
	UpdateData();
	
	GetDlgItem(IDC_DUETASKPERSON)->EnableWindow(m_bOnlyShowDueTasksForPerson);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesFilePage::LoadPreferences(const CPreferences& prefs)
{
	m_bNotifyDueOnLoad = prefs.GetProfileInt("Preferences", "NotifyDue", FALSE);
	m_bNotifyDueOnSwitch = prefs.GetProfileInt("Preferences", "NotifyDueOnSwitch", FALSE);
	m_bAutoArchive = prefs.GetProfileInt("Preferences", "AutoArchive", FALSE);
	m_bNotifyReadOnly = prefs.GetProfileInt("Preferences", "NotifyReadOnly", TRUE);
	m_bRemoveArchivedTasks = prefs.GetProfileInt("Preferences", "RemoveArchivedTasks", TRUE);
	m_bRemoveOnlyOnAbsoluteCompletion = prefs.GetProfileInt("Preferences", "RemoveOnlyOnAbsoluteCompletion", TRUE);
	m_nNotifyDueByOnLoad = prefs.GetProfileInt("Preferences", "NotifyDueBy", PFP_DUETODAY);
	m_nNotifyDueByOnSwitch = prefs.GetProfileInt("Preferences", "NotifyDueByOnSwitch", PFP_DUETODAY);
	m_bDisplayDueTasksInHtml = prefs.GetProfileInt("Preferences", "DisplayDueTasksInHtml", TRUE);
	m_bRefreshFindOnLoad = prefs.GetProfileIn