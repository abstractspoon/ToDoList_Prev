<?xml version="1.0" encoding="windows-1252" ?>
<TODOLIST FILENAME="D:\_Code\ToDoList\Release\Resources\Introduction.tdl" PROJECTNAME="Sample Tasklist" FILEFORMAT="9" NEXTUNIQUEID="26" LASTMODIFIED="2009-09-20" FILEVERSION="93" EARLIESTDUEDATE="0.00000000">
<TASK TITLE="This is a Task" ID="1" ICONINDEX="-1" COMMENTS="New tasks can be created using:

1. The 'New Task' menu. This gives the greatest control over where the task will be created
2. The green 'plus' toolbar buttons
3. The context (right-click) menu for the task tree
4. The appropriate keyboard shortcuts (default: Ctrl+N, Ctrl+Shift+N)

Note: If during the creation of a new task you decide that it's not what you want (or where you want it) just hit Escape and the task creation will be cancelled." POS="1" LASTMOD="40075.77873843" LASTMODSTRING="19/09/2009 6:41 PM" PRIORITY="5" RISK="0" PERCENTDONE="0" COST="0.00000000" CALCCOST="0.00000000" TIMEESTIMATE="0.00000000" TIMEESTUNITS="I" TIMESPENT="0.00000000" TIMESPENTUNITS="M" STARTDATE="39739.00000000" STARTDATESTRING="18/10/2008" CREATIONDATE="39739.00000000" CREATIONDATESTRING="18/10/2008" COMMENTSTYPE="849cf988-79fe-418a-a40d-01fe3afcab2c" PRIORITYCOLOR="15732480" PRIORITYWEBCOLOR="#000FF0"/>
<TASK TITLE="A Task can contain..." ID="2" ICONINDEX="-1" POS="2" LASTMOD="39739.91288194" LASTMODSTRING="18/10/2008 9:54 PM" PRIORITY="5" RISK="0" PERCENTDONE="0" COST="0.00000000" CALCCOST="0.00000000" TIMEESTIMATE="0.00000000" TIMEESTUNITS="I" TIMESPENT="0.00000000" TIMESPENTUNITS="M" STARTDATE="39739.00000000" STARTDATESTRING="18/10/2008" CREATIONDATE="39739.00000000" CREATIONDATESTRING="18/10/2008" PRIORITYCOLOR="15732480" PRIORITYWEBCOLOR="#000FF0">
<TASK TITLE="Subtasks" ID="3" ICONINDEX="-1" COMMENTS="Any task can become a subtask by dragging it onto another task or by using the 'Move' menu to move it right one level.

Of course you can also directly create it as a subtask via the 'New Task' menu or the appropriate toolbar button.

Note: The behaviour of the default 'New Task/Subtask' toolbar buttons can be modified via the Preferences." POS="1" LASTMOD="39741.73358796" LASTMODSTRING="20/10/2008 5:36 PM" PRIORITY="5" RISK="0" PERCENTDONE="0" COST="0.00000000" CALCCOST="0.00000000" TIMEESTIMATE="0.00000000" TIMEESTUNITS="I" TIMESPENT="0.00000000" TIMESPENTUNITS="M" STARTDATE="39739.00000000" STARTDATESTRING="18/10/2008" CREATIONDATE="39739.00000000" CREATIONDATESTRING="18/10/2008" COMMENTSTYPE="PLAIN_TEXT" PRIORITYCOLOR="15732480" PRIORITYWEBCOLOR="#000FF0"/>
<TASK TITLE="Which in turn can contain other ..." ID="4" ICONINDEX="-1" POS="2" LASTMOD="39739.81900463" LASTMODSTRING="18/10/2008 7:39 PM" PRIORITY="5" RISK="0" PERCENTDONE="0" COST="0.00000000" CALCCOST="0.00000000" TIMEESTIMATE="0.00000000" TIMEESTUNITS="I" TIMESPENT="0.00000000" TIMESPENTUNITS="M" STARTDATE="39739.00000000" STARTDATESTRING="18/10/2008" CREATIONDATE="39739.00000000" CREATIONDATESTRING="18/10/2008" PRIORITYCOLOR="15732480" PRIORITYWEBCOLOR="#000FF0">
<TASK TITLE="Subtasks" ID="5" ICONINDEX="-1" COMMENTS="And this is the means by which complex projects can become a series of smaller more manageable tasks.

Note: If you want to split a task into subtasks at a later date you can do so via the 'New Task &gt; Split Selected Task' menu items.

Note: A task which already has subtasks cannot be split." POS="1" LASTMOD="39739.92373843" LASTMODSTRING="18/10/2008 10:10 PM" PRIORITY="5" RISK="0" PERCENTDONE="0" COST="0.00000000" CALCCOST="