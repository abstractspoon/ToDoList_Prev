he percentage completion to 100%
4. By setting the completed date.

The way that completed tasks are displayed can be controlled via the Preferences." POS="3" LASTMOD="39739.81888889" LASTMODSTRING="18/10/2008 7:39 PM" PRIORITY="5" RISK="0" PERCENTDONE="100" CALCPERCENTDONE="100" COST="0.00000000" CALCCOST="0.00000000" DONEDATE="39739.00000000" DONEDATESTRING="18/10/2008" STARTDATE="39739.00000000" STARTDATESTRING="18/10/2008" CREATIONDATE="39739.00000000" CREATIONDATESTRING="18/10/2008" COMMENTSTYPE="PLAIN_TEXT" TEXTCOLOR="8421504" TEXTWEBCOLOR="#808080" PRIORITYCOLOR="57630" PRIORITYWEBCOLOR="#1EE100">
<TASK TITLE="Subtasks" ID="10" ICONINDEX="-1" COMMENTS="whose parent tasks are complete are displayed in the same colour as completed tasks." POS="1" LASTMOD="39739.82126157" LASTMODSTRING="18/10/2008 7:42 PM" PRIORITY="5" RISK="0" PERCENTDONE="0" COST="0.00000000" CALCCOST="0.00000000" STARTDATE="39739.00000000" STARTDATESTRING="18/10/2008" CREATIONDATE="39739.00000000" CREATIONDATESTRING="18/10/2008" COMMENTSTYPE="PLAIN_TEXT" PRIORITYCOLOR="15732480" PRIORITYWEBCOLOR="#000FF0"/>
</TASK>
<TASK TITLE="Adding Comments to Tasks" ID="15" ICONINDEX="-1" COMMENTS="Comments are entered in the adjacent comments control and are displayed after the task in the task tree.

You can choose from either Simple Text comments (which contain no formatting) and Rich Text which allows you much more control over the appearance of the comments.

You can also embed images eg.   but this needs to be carefully managed to avoid the tasklist growing excessively in size.

Note: to help prevent this Rich Text comments are compressed within the tasklist." POS="4" LASTMOD="3973