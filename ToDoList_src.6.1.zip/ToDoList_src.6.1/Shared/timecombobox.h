ct="@CALCPERCENTDONE" />%</xsl:attribute>
           erledigt: <xsl:value-of select="@CALCPERCENTDONE" />%
         </xsl:if>
       </xsl:element>
    </xsl:element>
  </xsl:template>
  
  <!-- Priority -->
  <xsl:template name="get_Pretty_Priority">
    <xsl:element name="span">
      <xsl:element name="span">Priorit&#xE4;t: </xsl:element>
      <xsl:element name="span">
        <xsl:attribute name="class">prettyPriority</xsl:attribute>
        <xsl:choose>
          <xsl:when test="@PRIORITY">
            <xsl:element name="a">
              <xsl:attribute name="class">priorityNumberStyle</xsl:attribute>
              <xsl:attribute name="style">color:white; font-weight: bold; background-color: <xsl:value-of select="@PRIORITYWEBCOLOR" /></xsl:attribute>
              <xsl:value-of select="@PRIORITY" />
            </xsl:element>
          </xsl:when>
          <xsl:otherwise>
            <xsl:attribute name="style">background-color: <xsl:value-of select="@PRIORITYWEBCOLOR" /></xsl:attribute>
            <xsl:element name="a">
              <xsl:attribute name="class">priorityNumberStyle</xsl:attribute>
              <xsl:text>0</xsl:text>
            </xsl:element>        
          </xsl:otherwise>
        </xsl:choose>
      </xsl:element>
    </xsl:element>
  </xsl:template>
  
  <!--
  gets task dates
  -->
  <xsl:template name="get_Task_Dates">
    <xsl:element name="span">
      
      <xsl:attribute name="class">datesText</xsl:attribute>
      
      <xsl:if test="@DONEDATESTRING">
        <xsl:attribute name="class">completed</xsl:attribute>
      </xsl:if>
        
      <!-- Start date -->
      <xsl:element name="a">
        <xsl:text>Start am: </xsl:text>
 