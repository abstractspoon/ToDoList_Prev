ces
    TM_PROP(2413, TMT, SATURATION,        INT)    // (0-255) amt of saturation for DrawThemeIcon() part
    TM_PROP(2414, TMT, TEXTBORDERSIZE,    INT)    // size of border around text chars
    TM_PROP(2415, TMT, ALPHATHRESHOLD,    INT)    // (0-255) the min. alpha value of a pixel that is solid
    TM_PROP(2416, TMT, WIDTH,             SIZE)   // custom window prop: size of part (min. window)
    TM_PROP(2417, TMT, HEIGHT,            SIZE)   // custom window prop: size of part (min. window)
    TM_PROP(2418, TMT, GLYPHINDEX,        INT)    // for font-based glyphs, the char index into the font
    TM_PROP(2419, TMT, TRUESIZESTRETCHMARK, INT)  // stretch TrueSize image when target exceeds source by this percent
    TM_PROP(2420, TMT, MINDPI1,         INT)      // min DPI ImageFile1 was designed for
    TM_PROP(2421, TMT, MINDPI2,         INT)      // min DPI ImageFile1 was designed for
    TM_PROP(2422, TMT, MINDPI3,         INT)      // min DPI ImageFile1 was designed for
    TM_PROP(2423, TMT, MINDPI4,         INT)      // min DPI ImageFile1 was designed for
    TM_PROP(2424, TMT, MINDPI5,         INT)      // min DPI ImageFile1 was designed for

    //---- rendering FONT properties ----
    TM_PROP(2601, TMT, GLYPHFONT,         FONT)   // the font that the glyph is drawn with

    //---- rendering INTLIST properties ----
    // start with 2801
                                                // (from smallest to largest)
    //---- rendering FILENAME properties ----
    TM_PROP(3001, TMT, IMAGEFILE,         FILENAME)   // the filename of the image (or basename, for mult. images)
    TM_PROP(3002, TMT, IMAGEFILE1,        FILENAME)   // multiresolution image file
    TM_PROP(3003, TMT, IMAGEFILE2,        FILENAME)   // multiresolution image file
    TM_PROP(3004, TMT, IMAGEFILE3,        FILENAME)   // multiresolution image file
    TM_PROP(3005, TMT, IMAGEFILE4,        FILENAME)   // multiresolution image file
    TM_PROP(3006, TMT, IMAGEFILE5,        FILENAME)   // multiresolution image file
    TM_PROP(3007, TMT, STOCKIMAGEFILE,    FILENAME)   // These are the only images that you can call GetThemeBitmap on
    TM_PROP(3008, TMT, GLYPHIMAGEFILE,    FILENAME)   // the filename for the glyph image

    //---- rendering STRING properties ----
    TM_PROP(3201, TMT, TEXT,              STRING)

    //---- rendering POSITION (x and y values) properties ----
    TM_PROP(3401, TMT, OFFSET,            POSITION)   // for window part layout
    TM_PROP(3402, TMT, TEXTSHADOWOFFSET,  POSITION)   // where char shadows are drawn, relative to orig. chars
    TM_PROP(3403, TMT, MINSIZE,           POSITION)   // min dest rect than ImageFile was designed for
    TM_PROP(3404, TMT, MINSIZE1,          POSITION)   // min dest rect than ImageFile1 was designed for
    TM_PROP(3405, TMT, MINSIZE2,          POSITION)   // min dest rect than ImageFile2 was designed for
    TM_PROP(3406, TMT, MINSIZE3,          POSITION)   // min dest rect than ImageFile3 was designed for
    TM_PROP(3407, TMT, MINSIZE4,          POSITION)   // min dest rect than ImageFile4 was designed for
    TM_PROP(3408, TMT, MINSIZE5,          POSITION)   // min dest rect than ImageFile5 was designed for
    TM_PROP(3409, TMT, NORMALSIZE,        POSITION)   // size of dest rect that exactly source

    //---- rendering MARGIN properties ----
    TM_PROP(3601, TMT, SIZINGMARGINS,     MARGINS)    // margins used for 9-grid sizing
    TM_PROP(3602, TMT, CONTENTMARGINS,    MARGINS)    // margins that define where content can be placed
    TM_PROP(3603, TMT, CAPTIONMARGINS,    MARGINS)    // margins that define where caption text can be placed

    //---- rendering COLOR properties ----
    TM_PROP(3801, TMT, BORDERCOLOR,      COLOR)       // color of borders for BorderFill 
    TM_PROP(3802, TMT, FILLCOLOR,        COLOR)       // color of bg fill 
    TM_PROP(3803, TMT, TEXTCOLOR,        COLOR)       // color text is drawn in
    TM_PROP(3804, TMT, EDGELIGHTCOLOR,     COLOR)     // edge color
    TM_PROP(3805, TMT, EDGEHIGHLIGHTCOLOR, COLOR)     // edge color
    TM_PROP(3806, TMT, EDGESHADOWCOLOR,    COLOR)     // edge color
    TM_PROP(3807, TMT, EDGEDKSHADOWCOLOR,  COLOR)     // edge color
    TM_PROP(3808, TMT, EDGEFILLCOLOR,  COLOR)         // edge color
    TM_PROP(3809, TMT, TRANSPARENTCOLOR, COLOR)       // color of pixels that are treated as transparent (not drawn)
    TM_PROP(3810, TMT, GRADIENTCOLOR1,   COLOR)       // first color in gradient
    TM_PROP(3811, TMT, GRADIENTCOLOR2,   COLOR)       // second color in gradient
    TM_PROP(3812, TMT, GRADIENTCOLOR3,   COLOR)       // third color in gradient
    TM_PROP(3813, TMT, GRADIENTCOLOR4,   COLOR)       // forth color in gradient
    TM_PROP(3814, TMT, GRADIENTCOLOR5,   COLOR)       // fifth color in gradient
    TM_PROP(3815, TMT, SHADOWCOLOR,      COLOR)       // color of text shadow
    TM_PROP(3816, TMT, GLOWCOLOR,        COLOR)       // color of glow produced by DrawThemeIcon
    TM_PROP(3817, TMT, TEXTBORDERCOLOR,  COLOR)       // color of text border
    TM_PROP(3818, TMT, TEXTSHADOWCOLOR,  COLOR)       // color of text shadow
    TM_PROP(3819, TMT, GLYPHTEXTCOLOR,        COLOR)  // color that font-based glyph is drawn with
    TM_PROP(3820, TMT, GLYPHTRANSPARENTCOLOR, COLOR)  // color of transparent pixels in GlyphImageFile
    TM_PROP(3821, TMT, FILLCOLORHINT, COLOR)          // hint about fill color used (for custom controls)
    TM_PROP(3822, TMT, BORDERCOLORHINT, COLOR)        // hint about border color used (for custom controls)
    TM_PROP(3823, TMT, ACCENTCOLORHINT, COLOR)        // hint about accent color used (for custom controls)

    //---- rendering enum properties (must be declared in TM_ENUM section above) ----
    TM_PROP(4001, TMT, BGTYPE,           ENUM)        // basic drawing type for each part
    TM_PROP(4002, TMT, BORDERTYPE,       ENUM)        // type of border for BorderFill parts
    TM_PROP(4003, TMT, FILLTYPE,         ENUM)        // fill shape for BorderFill parts
    TM_P