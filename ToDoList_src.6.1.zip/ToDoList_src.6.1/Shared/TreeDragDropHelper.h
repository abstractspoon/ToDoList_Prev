
					hFontOld = (HFONT)::SelectObject(lpDrawItemStruct->hDC, m_fontDone);

				else if (bTopLevel) 
					hFontOld = (HFONT)::SelectObject(lpDrawItemStruct->hDC, m_fontBold);

				// Task title 
				GetItemTitleRect(nItem, TDCTR_LABEL, rSubItem, pDC, pTDI->sTitle);
				rSubItem.OffsetRect(-1, 0);

				// back colour
				if (!HasStyle(TDCS_FULLROWSELECTION) && colors.bBackSet)
				{
					DrawItemBackColor(pDC, rSubItem, colors.crBack);
/*
					if (m_tree.GutterHasStyle(NCGS_GRADIENTSELECTION))
					{
						COLORREF crBack2 = GraphicsMisc::Lighter(colors.crBack, 0.5);
						GraphicsMisc::DrawGradient(pDC->GetSafeHdc(), rSubItem, crBack2, colors.crBack, FALSE);
					}
					else
						pDC->FillSolidRect(rSubItem, colors.crBack);
*/
				}

				// text
				DrawGutterItemText(pDC, pTDI->sTitle, rSubItem, LVCFMT_LEFT);
				rFocus = rSubItem; // save for focus rect drawing

				// vertical divider
				if (crGrid != NOCOLOR)
					pDC->FillSolidRect(rTitleBounds.right - 1, rTitleBounds.top, 1, rTitleBounds.Height(), crGrid);

				// render comment text if not editing this task label
				if (m_dwEditingID != dwTaskID)
				{
					// deselect bold font if set
					if (bTopLevel && !bDoneAndStrikeThru)
					{
						::SelectObject(lpDrawItemStruct->hDC, hFontOld);
						hFontOld = NULL;
					}	

					rTitleBounds.top++;
					rTitleBounds.left = rSubItem.right + 4;
					DrawCommentsText(pDC, pTDI, pTDS, rTitleBounds, nState);
				}

				if (hFontOld)
					::SelectObject(lpDrawItemStruct->hDC, hFontOld);
			}
			else
			{
				// get col rect
				CRect rSubItem;
				m_list.GetSubItemRect(nItem, nCol, LVIR_LABEL, rSubItem);
				rSubItem.OffsetRect(-1, 0);

				ncgDI.pDC = pDC;
				ncgDI.dwItem = NULL;
				ncgDI.dwParentItem = NULL;
				ncgDI.nLevel = 0;
				ncgDI.nItemPos = 0;
				ncgDI.rWindow = &rSubItem;
				ncgDI.rItem = &rSubItem;
				ncgDI.nColID = pCol->nColID;
				ncgDI.nTextAlign = pCol->nAlignment;
				
				DrawItem(pTDI, pTDS, &ncgDI, nState);
			}
		}

		// base gridline
		if (crGrid != NOCOLOR)
			pDC->FillSolidRect(rItem.left, rItem.bottom - 1, rItem.Width() - 1, 1, crGrid);

		pDC->RestoreDC(nSaveDC); // so that DrawFocusRect works
		
		// focus rect
		if ((lpDrawItemStruct->itemState & ODS_FOCUS) && (nState == TDIS_SELECTED))
		{
			pDC->DrawFocusRect(rFocus);
		}

	}
	else
		CToDoCtrl::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

COLORREF CFilteredToDoCtrl::GetItemLineColor(HTREEITEM hti)
{
	if (InListView())
	{
		COLORREF crAltLines = m_tree.GetAlternateLineColor();

		if (crAltLines != NOCOLOR)
		{
			int nItem = FindTask(GetTaskID(hti));

			if (nItem != -1 && (nItem % 2))
				return crAltLines;
		}
			
		// else
		return GetSysColor(COLOR_WINDOW);
	}

	// else
	return CToDoCtrl::GetItemLineColor(hti);
}

void CFilteredToDoCtrl::DrawColumnHead