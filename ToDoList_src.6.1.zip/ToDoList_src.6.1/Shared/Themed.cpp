EBCOLOR="#FF6820" TEXTCOLOR="2124031" TEXTWEBCOLOR="#FF6820" PRIORITYCOLOR="15732480" PRIORITYWEBCOLOR="#000FF0"/>
<TASK TITLE="Categorizing Tasks" ID="14" ICONINDEX="-1" COMMENTS="To add an category to the selected task simply type an appropriate category into the Category droplist. If the category is new it will be automatically added to the droplist.

Note: If you accidently misspell the category, simply drop down the list, highlight the misspelt item and hit Ctrl+Delete to remove it.

Default categories (that you want to appear in all tasklists) can be set up in the Preferences.

Note: You can assign multiple categories to a task by ticking more than one checkbox in the droplist.

Note: This sample tasklist contains a number of example categories for you to experiment with.

Note: The droplists with checkboxes are closed by clicking the arrow button or by hitting Return." POS="6" LASTMOD="39741.79986111" LASTMODSTRING="20/10/2008 7:11 PM" PRIORITY="5" RISK="0" PERCENTDONE="0" COST="0.00000000" CALCCOST="0.00000000" STARTDATE="39739.00000000" STARTDATESTRING="18/10/2008" CREATIONDATE="39739.00000000" CREATIONDATESTRING="18/10/2008" COMMENTSTYPE="PLAIN_TEXT" PRIORITYCOLOR="15732480" PRIORITYWEBCOLOR="#000FF0"/>
<TASK TITLE="Likewise for the task's Status, Allocated to/by and Version fields" ID="16" ICONINDEX="-1" COMMENTS="Note: as with the Category field, you can assign more than one person to a task via the 'Allocate To' field.

Status, Allocated By and Version, however, can only have a single assignment.

Note: This sample tasklist contains a number of example statuses and names for you to experiment with." POS="7" LASTMOD="39739.92072917" LASTMODSTRING="18/10/2008 10:05 PM" PRIORITY="5" RISK="0" PERCENTDONE="0" COST="0.00000000" CALCCOST="0.00000000" STARTDATE="39739.00000000" STARTDATESTRING="18/10/2008" CREATIONDATE="39739.00000000" CREATIONDATESTRING="18/10/2008" COMMENTSTYPE="PLAIN_TEXT" PRIORITYCOLOR="15732480" PRIORITYWEBCOLOR="#000FF0"/>
<TASK TITLE="Associated Files with Tasks" ID="17" ICONINDEX="-1" COMMENTS="The File Link field can be used for linking to:

1. Local files or folders
2. Network files or folders
3. Internet addresses (www.)
4. Email addresses (mailto://)
5. Microsoft Outlook folders.
6. Other tasks (tdl://)

If you find you need to associate more than one file with a task then this comments field can be used to reference an unlimited number of links using standard web page style links.

eg. http://www.abstractspoon.com
eg. www.abstractspoon.com
eg. file://C:/somefolder/somefile.txt
eg. mailto://abstractspoon2@optusnet.com.au
eg. tdl://15 (where 15 is the ID of the task)

Note: If the filename has spaces in it then simple surround the full file name in &lt;&gt;

eg. &lt;file://C:/some folder/some file.txt&gt;

To insert file links in the comments field you can:

1. Type them
2. Browse to them via the context (right-click) menu
3. Drag'n'drop them from Windows Explorer

To visit any link in the comments field just hold down the Ctrl key and click the link." POS="8" LASTMOD="39739.91299769" LASTMODSTRING="18/10/2008 9:54 PM" PRIORITY="5" RISK="0" PERCENTDONE="0" COST="0.00000000" CALCCOST="0.00000000" STARTDATE="39739.00000000" STARTDATESTRING="18/10/2008" CREATIONDATE="39739.00000000" CREATIONDATESTRING="18/10/2008" COMMENTSTYPE="PLAIN_TEXT" PRIORITYCOLOR="15732480" PRIORITYWEBCOLOR="#000FF0"/>
<TASK TITLE="Navigating the Tasklist" ID="24" ICONINDEX="-1" COMMENTS="ToDoList can be navigated equally easily using the keyboard or the mouse and uses standard Windows keyboard and mouse actions for navigating.

In addition to this, ToDoList keeps track of your navigation history so that you can easily track backwards and forwards in a similar way to browsing the web.

ToDoList also supports multiple selection of tasks for editing, moving, deleting, exporting and printing.

If you select multiple items (using the Shift and/or Ctrl keys) and then modify a task attribute, tht modification is applied to all the selected tasks as if you had edited them individually.

There ia unlimited undo and redo of changes until you close the tasklist." POS="9" LASTMOD="39739.91916667" LASTMODSTRING="18/10/2008 10:03 PM" PRIORITY="5" RISK="0" PERCENTDONE="0" COST="0.00000000" CALCCOST="0.00000000" STARTDATE="39739.00000000" STARTDATESTRING="18/10/2008" CREATIONDATE="39739.00000000" CREATIONDATESTRING="18/10/2008" COMMENTSTYPE="PLAIN_TEXT" PRIORITYCOLOR="15732480" PRIORITYWEBCOLOR="#000FF0"/>
<TASK TITLE="Filtering Tasks" ID="18" ICONINDEX="-1" COMMENTS="Once you have been working for a while and have marked a number of tasks as completed you may wish to filter out these tasks so that you can concentrate on your remaining tasks.

If so, simply select 'B) Incomplete Tasks' from the 'Show' droplist on the filter bar above the task tree and the completed tasks will be removed from view.

Note: the tasks are simply hidden and will re-appear once you reset the filter to 'A) All Tasks'.

You will also a number of other filters in the list which you can experiment with.

These filters can also be combined with other options that you will see on the filter bar.

Note: The filter bar can be hidden and shown via the View menu. Hiding the filter bar does not reset the filter." POS="10" LASTMOD="39739.91314815" LASTMODSTRING="18/10/2008 9:54 PM" PRIORITY="5" RISK="0" PERCENTDONE="0" COST="0.00000000" CALCCOST="0.00000000" STARTDATE="39739.00000000" STARTDATESTRING="18/10/2008" CREATIONDATE="39739.00000000" CREATIONDATESTRING="18/10/2008" COMMENTSTYPE="PLAIN_TEXT" PRIORITYCOLOR="15732480" PRIORITYWEBCOLOR="#000FF0"/>
<TASK TITLE="Importing Tasks" ID="19" ICONINDEX="-1" COMMENTS="ToDoList is able to import tasks from a number of other free and paid-for task managment applications including:

1. Microsoft Outlook - http://www.microsoft.com/outlook/
2. GanttProject - http://ganttproject.biz/
3. Freemind - http://freemind.sourceforge.net/
4. My Life Organized - http://www.mylifeorganized.net/

You can also import tasks from a simple list of tasks where each task is on a separate line (Outline).

Importing is accessible via the Tools menu." POS="11" LASTMOD="39739.91320602" LASTMODSTRING="18/10/2008 9:55 PM" PRIORITY="5" RISK="0" PERCENTDONE="0" COST="0.00000000" CALCCOST="0.00000000" STARTDATE="39739.00000000" STARTDATESTRING="18/10/2008" CREATIONDATE="39739.00000000" CREATIONDATESTRING="18/10/2008" COMMENTSTYPE="PLAIN_TEXT" PRIORITYCOLOR="15732480" PRIORITYWEBCOLOR="#000FF0"/>
<TASK TITLE="Exporting Tasks" ID="20" ICONINDEX="-1" COMMENTS="ToDoList can export tasklists to the same applications from which it can import tasks (tdl://19) as well as a few others, including:

1. Web page (html)
1. Spreadsheet (csv)
2. iCalendar (used by Google calendars).

Exporting is accessible via the Tools menu." POS="12" LASTMOD="39739.91331019" LASTMODSTRING="18/10/2008 9:55 PM" PRIORITY="5" RISK="0" PERCENTDONE="0" COST="0.00000000" CALCCOST="0.00000000" STARTDATE="39739.00000000" STARTDATESTRING="18/10/2008" CREATIONDATE="39739.00000000" CREATIONDATESTRING="18/10/2008" COMMENTSTYPE="PLAIN_TEXT" PRIORITYCOLOR="15732480" PRIORITYWEBCOLOR="#000FF0"/>
<TASK TITLE="Sharing Tasklists" ID="21" ICONINDEX="-1" COMMENTS="If you want to collaborate on a tasklist with someone else (eg. a co-worker) then this can can be easily and safely achieved by using the built-in 'Source Control' functionality.

This 'Controls' access to the 'Source' (the tasklist) by only allowing one person to edit it at any given time. Whilst this might seem restrictive, ToDoList contains a variety of simple options to make it an efficient way to share a tasklist between up to 10 people (this is the largest team currently working in this way).

Note: if you answered 'yes' to wanting to share your tasklists during the Setup phase then these options will already be configured but read on if you would like more insight into how it works.

The key to working efficiently with team members to to ensure that no team member keeps the tasklist locked (called 'Checked-Out' in ToDoList) for longer than is absolutely necessary. To prevent this happening ToDoList has the following preferences:

1. Unlock (called 'Check-In' in ToDoList) tasklists when the application and/or the tasklist is closed
2. Check-in tasklists if there has been no editing activity for some specified period of time." POS="13" LASTMOD="39759.67053241" LASTMODSTRING="7/11/2008 4:05 PM" PRIORITY="5" RISK="0" PERCENTDONE="0" COST="0.00000000" CALCCOST="0.00000000" STARTDATE="39739.00000000" STARTDATESTRING="18/10/2008" CREATIONDATE="39739.00000000" CREATIONDATESTRING="18/10/2008" COMMENTSTYPE="PLAIN_TEXT" PRIORITYCOLOR="15732480" PRIORITYWEBCOLOR="#000FF0"/>
<TASK TITLE="Getting Help" ID="23" ICONINDEX="-1" COMMENTS="There are a number of resources that are available to help you get the most out of ToDoList:

1. Tools &gt; Preferences.

ToDoList provides a wealth of user options for configuring and controlling its behaviour. In my experience a vast number of requests are satisfied by directing people to the Preferences.

2. Some functional documentation -  http://abstractspoon.pbworks.com/OnlineDocumentation. 

This is is in the process of being updated so please be patient.

3. The AbstractSpoon Wiki - http://abstractspoon.pbwiki.com. 

This provides hints and tips, access to 3rd party accessories and translations of ToDoList.

4. CodeProject Forum - http://www.codeproject.com/KB/applications/todolist2.aspx.

This is where ToDoList was originally released and still provides the most useful place to ask questions and get answers. You are required to join to be able to post questions but it is well worth it.

5. Me (Dan) - mailto://abstractspoon2@optusnet.com.au.

Please treat this as a last resort because 9 times out of 10 the answer can be found out using the resources in 1-4." POS="14" LASTMOD="40076.71482639" LASTMODSTRING="20/09/2009 5:09 PM" PRIORITY="5" RISK="0" PERCENTDONE="0" COST="0.00000000" CALCCOST="0.00000000" STARTDATE="39739.00000000" STARTDATESTRING="18/10/2008" CREATIONDATE="39739.00000000" CREATIONDATESTRING="18/10/2008" COMMENTSTYPE="PLAIN_TEXT" PRIORITYCOLOR="15732480" PRIORITYWEBCOLOR="#000FF0"/>
<CATEGORY CATEGORY0="Home" CATEGORY1="Work" CATEGORY2="Travel" CATEGORY3="Groceries"/>
<STATUS STATUS0="Cancelled" STATUS1="Awaiting Confirmation" STATUS2="Delayed" STATUS3="Approved"/>
<PERSON PERSON0="Bob" PERSON1="Jane" PERSON2="Pete" PERSON3="Mary"/>
<ALLOCATEDBY ALLOCATEDBY0="Frank" ALLOCATEDBY1="Margaret"/>
</TODOLIST>
                                                                                                         ct)
{
	if (s_hUxTheme && m_hTheme)
	{
		PFNDRAWTHEMEBACKGROUND fnDrawThemeBackground = (PFNDRAWTHEMEBACKGROUND)GetProcAddress(s_hUxTheme, "DrawThemeBackground");
		
		if (fnDrawThemeBackground)
			return (SUCCEEDED(fnDrawThemeBackground(m_hTheme, hdc, iPartId, iStateId, pRect, pClipRect)));
	}
	
	return FALSE;
}

BOOL CThemed::DrawThemeParentBackground(HWND hWnd, HDC hdc, RECT *pRect)
{
	if (s_hUxTheme && m_hTheme)
	{
		PFNDRAWTHEMEPARENTBACKGROUND fnDrawThemeParentBackground = (PFNDRAWTHEMEPARENTBACKGROUND)GetProcAddress(s_hUxTheme, "DrawThemeParentBackground");
		
		if (fnDrawThemeParentBackground)
			return (SUCCEEDED(fnDrawThemeParentBackground(hWnd, hdc, pRect)));
	}
	
	return FALSE;
}

BOOL CThemed::DrawThemeText(HDC hdc, int iPartId, int iStateId, LPCWSTR pszText, int iCharCount, 
							DWORD dwTextFlags, DWORD dwTextFlags2, const RECT *pRect)
{
	if (s_hUxTheme && m_hTheme)
	{
		PFNDRAWTHEMETEXT fnDrawThemeText = (PFNDRAWTHEMETEXT)GetProcAddress(s_hUxTheme, "DrawThemeText");
		
		if (fnDrawThemeText)
			return (SUCCEEDED(fnDrawThemeText(m_hTheme, hdc, iPartId, iStateId, pszText, iCharCount, dwTextFlags, dwTextFlags2, pRect)));
	}
	
	return FALSE;
}

BOOL CThemed::DrawThemeEdge(HDC hdc, int iPartId, int iStateId, const RECT *pDestRect, UINT uEdge, 
							UINT uFlags, RECT *pContentRect)
{
	if (s_hUxTheme && m_hTheme)
	{
		PFNDRAWTHEMEEDGE fnDrawThemeEdge = (PFNDRAWTHEMEEDGE)GetProcAddress(s_hUxTheme, "DrawThemeEdge");
		
		if (fnDrawThemeEdge)
			return (S<?xml version="1.0"?>

<!-- 
SimpStyler v.0.2
This is a simple xsl stylesheet for TDL. 

Change Log, 4 Dec 2007:
- Better Documentation
- When EXTERNALID="NBR" (No BRacket), do not print [ ] brackets on open tasks.
-->

<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">

<xsl:strip-space elements="*" />

<xsl:template match="TODOLIST">
<html>
<head>
    <title><xsl:value-of select="@PROJECTNAME" /></title>
    
    <!-- STYLESHEET. Use stylesheet to setup font type, font size, margins, etc. -->
    <style>
    body
					{
						font-family: Tahoma, serif;
						margin: 5px 5px 5px 5px;
						background-color : #C0C0C0;
						font-size: 11px;
					}
          
    .done {
        color: #808080;
    }
    .alldone {
        color: #808080;
        text-decoration: line-through;
    }
    .comment {
        color: #606060;
    }
    body {
        font-family: Arial;
    }
    </style>
</head>
<body>
    <!-- TITLE. Too big? Too Small? Change the h2 to the size you want. -->
    <h2>Project: <xsl:value-of select="@PROJECTNAME" /></h2>
    <xsl:value-of select="@REPORTDATE" />
    <ol>
    <xsl:apply-templates />
    </ol>
</body>
</html>
</xsl:template>

<xsl:template match="TASK">
    <xsl:choose>
        <xsl:when test="TASK">
            <xsl:call-template name="do-task" />
            <ul>
            <xsl:apply-templates />
            </ul>
        </xsl:when>
        <xsl:otherwise>
            <xsl:call-template name="do-task" />
            <xsl:apply-templates />
        </xsl:otherwise>
    </xsl:choose>
</xsl:template>

<xsl:template name="do-task">
<!-- FORMAT. This is where the we put the [ ] and [x] brackets, and format. -->
    <xsl:choose>
    <!-- This automatically selects the "MASTER" Task -->
        <xsl:when test="parent::TODOLIST">
          <xsl:choose>
          <!-- Format Completed Master Task -->
            <xsl:when test="@DONEDATESTRING">
              <BR></BR>
              <span class="alldone"><b><xsl:value-of select="@TITLE" /></b></span>
              <xsl:text> (</xsl:text><xsl:value-of select="@DONEDATESTRING" /><xsl:text>)</xsl:text>
              <BR></BR>
            </xsl:when>
          <!-- Format Open Masters Task -->
            <xsl:otherwise>
              <BR></BR>
              <b><xsl:value-of select="@TITLE" /></b>
            </xsl:otherwise>

            </xsl:choose>
        </xsl:when>
   
   <!-- This automatically selects the "SUB" Tasks -->
    <xsl:otherwise>    
        <xsl:choose>
            <!-- Format Completed Sub Task -->
            <xsl:when test="@DONEDATESTRING">
                <xsl:text>[x] </xsl:text>
                <span class="alldone"><xsl:value-of select="@TITLE" /></span>
                <xsl:text> (</xsl:text><xsl:value-of select="@DONEDATESTRING" /><xsl:text>)</xsl:text>
                <BR></BR>
            </xsl:when>
            <!-- Format Completed Sub Task -->
            <xsl:otherwise>
                <xsl:choose>
                
                  <xsl:when test="@EXTERNALID='NBR'">
                  <xsl:value-of select="@TITLE" />
                  <BR></BR>
                  </xsl:when>
                  
                  <xsl:otherwise>
                  <xsl:text>[</xsl:text>&#160;&#160;<xsl:text>] </xsl:text>
                  <xsl:value-of select="@TITLE" />
                  <BR></BR>
                  </xsl:otherwise>
                  
                </xsl:choose>
            </xsl:otherwise>
        </xsl:choose>  
     </xsl:otherwise>
        
    </xsl:choose>
    
    </xsl:template>
</xsl:stylesheet>                                                                                                                                                                                                                                                                                                                                                                                <TODOLIST>
	<UITHEME STYLE = "GRADIENT">

		<COLOR NAME = "APPBACKDARK"		R = "190" G = "220" B = "255"/>
		<COLOR NAME = "APPBACKLIGHT"	R = "220" G = "235" B = "255"/>
		<COLOR NAME = "APPLINES"		R = "100" G = "170" B = "255"/>
		<COLOR NAME = "MENUBACK"		R = "220" G = "235" B = "255"/>
		<COLOR NAME = "TOOLBARDARK"		R = "190" G = "220" B = "255"/>
		<COLOR NAME = "TOOLBARLIGHT"	R = "220" G = "235" B = "255"/>
		<COLOR NAME = "STATUSBARDARK"	R = "190" G = "220" B = "255"/>
		<COLOR NAME = "STATUSBARLIGHT"	R = "220" G = "235" B = "255"/>
<!--
		<COLOR NAME = "" R = "" G = "" B = ""/>
		<COLOR NAME = "" R = "" G = "" B = ""/>
		<COLOR NAME = "" R = "" G = "" B = ""/>
-->
	</UITHEME>
</TODOLIST>

                                                           