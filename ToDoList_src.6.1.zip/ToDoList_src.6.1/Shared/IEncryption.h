_DATA_MAP
}


BEGIN_MESSAGE_MAP(CToolsUserInputDlg, CRuntimeDlg)
	//{{AFX_MSG_MAP(CToolsUserInputDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CToolsUserInputDlg message handlers

void CToolsUserInputDlg::OnOK()
{
	CRuntimeDlg::OnOK();

	// now we dynamically extract the window text of the items and map to name
	CPreferences prefs;
	int nCtrl = m_aInputItems.GetSize();

	while (nCtrl--)
	{
		TUINPUTITEM& tuii = m_aInputItems[nCtrl];

		CString sResult;
		tuii.pCtrl->GetWindowText(sResult);

		// save to registry
		AfxGetApp()->WriteProfileString("Tools\\UserInput", tuii.sLabel, sResult);

		switch (tuii.nType)
		{
		case CLAT_USERFOLDER:
			// make sure folders are terminated
			sResult.TrimRight();

			if (sResult.Right(1) != "\\")
				sResult += '\\';
			break;

		case CLAT_USERDATE:
			// make sure dates are formatted to ISO standards ie yyyy-mm-dd
			{
				SYSTEMTIME sysTime;

				if (GDT_VALID == tuii.pCtrl->SendMessage(DTM_GETSYSTEMTIME, 0, (LPARAM) &sysTime))
				{
					COleDateTime date(sysTime);
					sResult = date.Format("%Y-%m-%d");
				}
				else
					ASSERT(0);
			}
			break;
		}

		m_mapResults[tuii.sName] = sResult;
	}
}

BOOL CToolsUserInputDlg::OnInitDialog() 
{
	CRuntimeDlg::OnInitDialog();

	// userdate default values need a bit more work
	int nCtrl = m_aInputItems.GetSize();

	while (nCtrl--)
	{
		TUINPUTITEM& tuii = m_aInputItems[nCtrl];

		switch (tuii.nType)
		{
		case CLAT_USERDATE:
			if (!tuii.sDefValue.IsEmpty())
			{
				// parse the date to ISO standards ie yyyy-mm-dd
				SYSTEMTIME sysTime;
				ZeroMemory(&sysTime, sizeof(sysTime));
//fabio_2005
#if _MSC_VER >= 1400
				int nRes = sscanf_s(tuii.sDefValue, "%d-%d-%d", &sysTime.wYear, &sysTime.wMonth, &sysTime.wDay);
#else
				int nRes = sscanf(tuii.sDefValue, "%d-%d-%d", &sysTime.wYear, &sysTime.wMonth, &sysTime.wDay);
#endif

				if (nRes == 3)
					tuii.pCtrl->SendMessage(DTM_SETSYSTEMTIME, GDT_VALID, (LPARAM) &sysTime);
			}
			break;
		}
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

CString CToolsUserInputDlg::GetResult(LPCTSTR szItemName)
{
	CString sItem(szItemName);
	sItem.MakeLower();

	CString sResult;
	m_mapResults.Lookup(sItem, sResult);

	return sResult;
}
                                                                                               
    // frees a previously returned buffer and sets the ptr to NULL
    // eg for buffer allocated with 'new' use 'delete []'
    // eg for buffer allocated with 'strdup' use 'free'
    virtual void FreeBuffer(unsigned char*& pBuffer) = 0;
	
};

static void ReleaseEncryptionInterface(IEncryption*& pInterface)
{
    if (pInterface)
    {
        pInterface->Release();
        pInterface = NULL;
    }
}

#endif // !defined(AFX_IENCRYPTION_H__7741547B_BA15_4851_A41B_2B4EC1DC12D5__INCLUDED_)
