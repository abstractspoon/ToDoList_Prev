      <xsl:if test="@PERSON6">
          ; <xsl:value-of select="@PERSON6" />
        </xsl:if>

        <xsl:if test="@PERSON7">
          ; <xsl:value-of select="@PERSON7" />
        </xsl:if>

        <xsl:if test="@PERSON8">
          ; <xsl:value-of select="@PERSON8" />
        </xsl:if>

        <xsl:if test="@PERSON9">
          ; <xsl:value-of select="@PERSON9" />
        </xsl:if>

      </xsl:element>
     
      <!-- allocated by
      <xsl:if test="@ALLOCATEDBY">
        <xsl:element name="a">[Allocated by: <xsl:value-of select="@ALLOCATEDBY" />]</xsl:element>
      </xsl:if>
 -->

    </xsl:element>
  </xsl:template>
  
  
  <xsl:template name="get_Task_Fileref">
    <xsl:element name="span">

      <xsl:attribute name="class">filerefpathText</xsl:attribute>

      <xsl:if test="@DONEDATESTRING">
        <xsl:attribute name="class">completed</xsl:attribute>
      </xsl:if>
      
      <!-- Fileref -->
      <xsl:if test="@FILEREFPATH">
        Datei: 
        <xsl:element name="a">
          <!-- todo: if not :// add file:// -->
          <xsl:attribute name="href"><xsl:value-of select="@FILEREFPATH" /></xsl:attribute>
          <xsl:value-of select="@FILEREFPATH" />
        </xsl:element>
      </xsl:if>
      
  </xsl:element>
  </xsl:template>
  
  <xsl:template name="get_Task_Comment">
    <xsl:if test="not(@DONEDATESTRING)">
      <xsl:choose>
      <!--
        <xsl:when test="@HTMLCOMMENTS">
          <xsl:element name="a">
          <xsl:value-of select="@HTMLCOMMENTS" disable-output-escaping="yes"/>
        </xsl:element>
        </xsl:when>
        -->
        <xsl:when test="@COMMENTS">
          <xsl:element name="p">
            <xsl:attribute name="class">commentsText</xsl:attribute>
            <xsl:variable name="text1">
              <xsl:call-template name="replace-string">
                <xsl:with-param name="text" select="@COMMENTS" />
                <xsl:with-param name="from" select="'&#x0d;&#x0a;'"/>
                <xsl:with-param name="to" select="'!NEWLINE!'"/>
              </xsl:call-template>
            </xsl:variable>

            <xsl:variable name="text2">
              <xsl:call-template name="replace-string">
                <xsl:with-param name="text" select="$text1" />
                <xsl:with-param name="from" select="'!NEWLINE!***'"/>
                <xsl:with-param name="to" select="'!NEWLINE!==='"/>
              </xsl:call-template>
            </xsl:variable>
            
            <xsl:call-template name="print-with-newline">
              <xsl:with-param name="text" select="$text2" />
              <xsl:with-param name="from" select="'!NEWLINE!'"/>
            </xsl:call-template>
  
          </xsl:element>
        </xsl:when>
      </xsl:choose>
    </xsl:if>

  </xsl:template>

 <!-- reusable replace-string function -->
 <xsl:template name="replace-string">
    <xsl:param name="text"/>
    <xsl:param name="from"/>
    <xsl:param name="to"/>

    <xsl:choose>
      <xsl:when test="contains($text, $from)">

        <xsl:variable name="before" select="substring-before($text, $from)"/>
        <xsl:variable name="after" select="substring-after($text, $from)"/>
        <!-- <xsl:variable name="prefix" select="concat($before, $to)"/>-->

      	<xsl:value-of select="$before"/>
        <xsl:value-of select="$to"/>
        <xsl:call-template name="replace-string">
          <xsl:with-param name="text" select="$after"/>
          <xsl:with-param name="from" select="$from"/>
          <xsl:with-param name="to" select="$to"/>
        </xsl:call-template>
      </xsl:when> 
      <xsl:otherwise>
        <xsl:value-of select="$text"/>  
      </xsl:otherwise>
    </xsl:choose>            
  </xsl:template>

 <!-- reusable replace-string function -->
 <xsl:template name="print-with-newline">
    <xsl:param name="text"/>
    <xsl:param name="from"/>

    <xsl:choose>
      <xsl:when test="contains($text, $from)">

        <xsl:variable name="before" select="substring-before($text, $from)"/>
        <xsl:variable name="after" select="substring-after($text, $from)"/>
        <!-- <xsl:variable name="prefix" select="concat($before, $to)"/>-->

      	<xsl:value-of select="$before"/>
        <br/>
        <xsl:call-template name="print-with-newline">
          <xsl:with-param name="text" select="$after"/>
          <xsl:with-param name="from" select="$from"/>
        </xsl:call-template>
      </xsl:when> 
      <xsl:otherwise>
        <xsl:value-of select="$text"/>  
      </xsl:otherwise>
    </xsl:choose>            
  </xsl:template>

  
</xsl:stylesheet>
                                                                                                                                                                                                                                                                                                                                                                                                CTimeEdit::SetUnits(int nUnits, LPCTSTR szLongUnits, LPCTSTR szAbbrevUnits)
{
	for (int nUnit = 0; nUnit < NUM_UNITS; nUnit++)
	{
		TIMEUNIT& tu = TIMEUNITS[nUnit];

		if (tu.nUnits == nUnits)
		{
			if (szLongUnits && *szLongUnits)
			{
				//fabio_2005
#if _MSC_VER >= 1300
				strncpy_s(tu.szLabel, szLongUnits, LABELLEN - 1);
#else
				strncpy(tu.szLabel, szLongUnits, LABELLEN - 1);
#endif

				tu.szLabel[LABELLEN - 1] = 0;
			}

			if (szAbbrevUnits && *szAbbrevUnits)
				tu.cAbbrLabel = szAbbrevUnits[0];
		}
	}

	// abbrev units
	CTimeHelper::SetUnits(nUnits, szAbbrevUnits);
}

void CTimeEdit::RemoveTrailingZeros(CString& sTime)
{
	sTime.TrimRight();

	while (!sTime.IsEmpty())
	{
		int nLen = sTime.GetLength();

		if (sTime[nLen - 1] == '0')
			sTime = sTime.Left(nLen - 1);

		else if (sTime[nLen - 1] == '.')
		{
			sTime = sTime.Left(nLen - 1);
			break;
		}
		else
			break;
	}
}
