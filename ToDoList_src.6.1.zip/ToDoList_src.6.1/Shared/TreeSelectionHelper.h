
			if (!IsReadOnly())
				SetSelectedTaskDone(!m_data.IsTaskDone(dwClickID));
			break;
			
		case TDCC_FLAG:
			if (!IsReadOnly())
			{
				BOOL bFlagged = m_data.IsTaskFlagged(dwClickID);
				SetSelectedTaskFlag(!bFlagged);
			}
			break;
		}
	}

	m_dw2ndClickItem = 0;
	
	*pResult = 0;
}

void CFilteredToDoCtrl::OnListDblClick(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMIA = (LPNMITEMACTIVATE)pNMHDR;

	if (pNMIA->iItem != -1) // validate item
	{
		DWORD dwTaskID = GetTaskID(pNMIA->iItem);
		TDC_COLUMN nCol = GetColumnID(pNMIA->iSubItem);
		
		switch (nCol)
		{
		case TDCC_CLIENT:
			{
				// did they double click the label?
				CPoint ptHit(::GetMessagePos());
				m_list.ScreenToClient(&ptHit);
				
				CRect rLabel;
				CClientDC dc(&m_list);
				GetItemTitleRect(pNMIA->iItem, TDCTR_LABEL, rLabel, &dc, GetSelectedTaskTitle());
				
				if (rLabel.PtInRect(ptHit))
					m_list.PostMessage(LVM_EDITLABEL);
			}

		case TDCC_FILEREF:
			{
				CString sFile = m_data.GetTaskFileRef(dwTaskID);
				
				if (!sFile.IsEmpty())
					GotoFile(sFile, TRUE);
			}
			break;
			
		case TDCC_DEPENDENCY:
			{
				CStringArray aDepends;
				m_data.GetTaskDependencies(dwTaskID, aDepends);
				
				if (aDepends.GetSize())
					ShowTaskLink(0, aDepends[0]);
			}
			break;
						
		case TDCC_RECURRENCE:
			m_eRecurrence.DoEdit();
			break;
					
		case TDCC_ICON:
			EditSelectedTaskIcon();
			break;
			
		case TDCC_REMINDER:
			AfxGetMainWnd()->SendMessage(WM_TDCN_DOUBLECLKREMINDERCOL);
			break;
		}
	}
	
	*pResult = 0;
}

void CFilteredToDoCtrl::OnListKeyDown(NMHDR* /*pNMHDR*/, LRESULT* pResult)
{
	// for reasons I have not yet divined, we are not receiving this message
	// as expected. So I've added an ASSERT(0) should it ever come to life
	// and have handled the key down message in ScWindowProc
	//LPNMKEY pNMK = (LPNMKEY)pNMHDR;
	ASSERT(0);
//	TRACE ("CFilteredToDoCtrl::OnListKeyDown\n");
//	UpdateTreeSelection();

	*pResult = 0;
}

BOOL CFilteredToDoCtrl::PtInHeader(CPoint ptScreen) const
{
	if (InListView())
	{
		CRect rHeader;
		m_header.GetWindowRect(rHeader);
		
		return rHeader.PtInRect(ptScreen);
	}

	// else
	return CToDoCtrl::PtInHeader(ptScreen);
}

BOOL CFilteredToDoCtrl::IsMultiSorting() const
{
	if (InListView())
		return m_bListMultiSort;

	// else
	return CToDoCtrl::IsMultiSorting();
}

void CFilteredToDoCtrl::MultiSort(const TDSORTCOLUMNS& sort)
{
	if (!InListView())
	{
		CToDoCtrl::MultiSort(sort);
		return;
	}
	
	ASSERT (sort.nBy1 != TDC_UNSORTED);

	if (sort.nBy1 == TDC_UNSORTED)
		return;

	// do the sort using whatever we can out of CToDoCtrlData
	TDSORTPARAMS ss;
	ss.sort = sort;
	ss.pData = &m_data;
	ss.bSortChildren = FALSE;

	m_list.SortItems(CToDoCtrlData::CompareFuncMulti, (DWORD)&ss);
	
	m_bListModSinceLastSort = FALSE;
	m_bListMultiSort = TRUE;
	m_sortList = sort;
	
	// update registry
	SaveSortState(CPreferences());

	UpdateColumnWidths();
}

void CFilteredToDoCtrl::Sort(TDC_SORTBY nBy, BOOL bAllowToggle)
{
	if (!InListView())
	{
		CToDoCtrl::Sort(nBy, bAllowToggle);
		return;
	}
	
	// we rebuild the entire listview if 'unsorting'
	if (nBy == TDC_UNSORTED)
	{
		TDC_SORTBY nPrevBy = m_sortList.nBy1;
		m_sortList.nBy1 = nBy;
		m_bListMultiSort = FALSE;

		if (nPrevBy != TDC_UNSORTED)
		{
			RefreshListFilter();
			UpdateColumnWidths();
		}
		
		return;
	}
	
	// else all the rest
	TDCCOLUMN* pTDCC = CToDoCtrl::GetColumn(nBy);
	ASSERT (pTDCC);
	
	if (!pTDCC)
		return;
	
	if (m_sortList.bAscending1 == -1 || nBy != m_sortList.nBy1)
		m_sortList.bAscending1 = pTDCC->bSortAscending;
	
	// if there's been a mod since last sorting then its reasonable to assume
	// that the user is not toggling direction but wants to simply resort
	// in the same direction.
	else if (bAllowToggle && !m_bListModSinceLastSort)
		m_sortList.bAscending1 = !m_sortList.bAscending1;
	
	// do the sort using whatever we can out of CToDoCtrlData
	TDSORTPARAMS ss;
	ss.sort.nBy1 = nBy;
	ss.sort.nBy2 = TDC_UNSORTED;
	ss.sort.nBy3 = TDC_UNSORTED;
	ss.sort.bAscending1 = m_sortList.bAscending1;
	ss.sort.bAscending2 = TRUE;
	ss.sort.bAscending3 = TRUE;
	ss.pData = &m_data;
	ss.bSortChildren = FALSE;

	m_list.SortItems(CToDoCtrlData::CompareFunc, (DWORD)&ss);
	
	m_sortList.nBy1 = nBy;
	m_sortList.nBy2 = TDC_UNSORTED;
	m_sortList.nBy3 = TDC_UNSORTED;
	m_bListModSinceLastSort = FALSE;
	m_bListMultiSort = FALSE;
	
	// update registry
	SaveSortState(CPreferences());

	UpdateColumnWidths();
}

BOOL CFilteredToDoCtrl::MoveSelectedTask(TDC_MOVETASK nDirection) 
{ 
	return InListView() ? FALSE : CToDoCtrl::MoveSelectedTask(nDirection); 
}

BOOL CFilteredToDoCtrl::CanMoveSelectedTask(TDC_MOVETASK nDirection) const 
{ 
	return InListView() ? FALSE : CToDoCtrl::CanMoveSelectedTask(nDirection); 
}

BOOL CFilteredToDoCtrl::GotoNextTask(TDC_GOTO nDirection)
{
	if (InListView() && CanGotoNextTask(nDirection))
	{
		int nSel = GetFirstSelectedItem();

		if (nDirection == TDCG_NEXT)
			nSel++;
		else
			nSel--;

		return SelectTask(m_list.GetItemData(nSel));
	}
	
	// else
	return CToDoCtrl::GotoNextTask(nDirection);
}

CRect CFilteredToDoCtrl::GetSelectedItemsRect() const
{
	CRect rInvalid(0, 0, 0, 0), rItem;
	POSITION pos = m_list.GetFirstSelectedItemPosition();

	while (pos)
	{
		int nItem = m_list.GetNextSelectedItem(pos);

		if (m_list.GetItemRect(nItem, rItem, LVIR_BOUNDS))
			rInvalid |= rItem;
	}

	return rInvalid;
}

BOOL 