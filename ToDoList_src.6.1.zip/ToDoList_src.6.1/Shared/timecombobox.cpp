   color: #000000;
          }
          
          .baseInfoText
          {
            color: #000000;
          }
          
          .completedDatesText
          {
            color: #C0C0C0;
          }
          
          .datesText
          {
            color: #000000;
          }
          
          .peopleText
          {
            color: #000000;
          }
          
          .filerefpathText
          {
            color: #000000;
          }
          
          .commentsText
          {
            color: #000000;
            border: 1px solid #000000;
            padding: 3px;
          }
          
          .priorityNumberStyle
          {
            font-weight: bold;
          }
        </style>
      </xsl:element>
      
      <xsl:element name="body">
        <!-- HEADER SPAN -->
        <xsl:element name="div">
          <xsl:attribute name="class">headerSpan</xsl:attribute>

          <h2>
            Brune-Mettcker Druck- und Verlags-GmbH / IT-Abteilung
          </h2>

          <h2>
            &#xDC;bersicht Projekt "<xsl:value-of select="@PROJECTNAME" />"
          </h2>          
          <p>
            Version <xsl:value-of select="@FILEVERSION" /> vom <xsl:value-of select="@LASTMODIFIED" />
          </p>

        </xsl:element>

        <br/>
          
        <!-- TASK INFORMATION -->
        <xsl:apply-templates />
        
        <!-- FOOTER SPAN -->
        <xsl:element name="div">
          <xsl:attribute name="class">footerSpan</xsl:attribute>
          generated from TodoList - http://www.abstractspoon.com using to-html-01.xsl
        </xsl:element>
      </xsl:element>
    </xsl:element>
  </xsl:template>
  
  <xsl:template match="TASK">
    <xsl:choose>
      <xsl:when test="TASK">
        <xsl:choose>
          <xsl:when test="parent::TODOLIST">
            <!-- master tasks -->
            <xsl:element name="div">
              <xsl:attribute name="class">masterTaskSpan</xsl:attribute>
              <xsl:choose>
                <xsl:when test="@DONEDATESTRING">
                  <xsl:attribute name="class">completed</xsl:attribute>
                </xsl:when>
              </xsl:choose>
              <xsl:call-template name="get_Task_Details" />
              <xsl:element name="ul">
                <xsl:apply-templates>
                  <!-- <xsl:sort select="@POS"/>-->
                </xsl:apply-templates>
              </xsl:element>
            </xsl:element>
            <xsl:element name="br"/>
            <xsl:element name="br"/>
          </xsl:when>
          <xsl:otherwise>
            <!-- sub tasks -->
            <xsl:call-template name="get_Task_Details" />
            <xsl:element name="ul">
              <xsl:apply-templates />
            </xsl:element>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:when>
      <xsl:otherwise>
        <xsl:choose>
          <xsl:when test="parent::TODOLIST">
            <!-- master tasks that do not contain any sub tasks -->
            <xsl:element name="span">
              <xsl:attribute name="class">masterTaskSpan</xsl:attribute>
              <xsl:choose>
                <xsl:when test="@DONEDATESTRING">
                  <xsl:attribute name="class">completed</xsl:attribute>
                </xsl:when>
              </xsl:choose>
              <xsl:call-template name="get_Task_Details" />
              <xsl:element name="ul">
                <xsl:apply-templates />
              </xsl:element>
            </xsl:element>
            <xsl:element name="br"/>
            <xsl:element name="br"/>
          </xsl:when>
          <xsl:otherwise>
            <!-- sub tasks -->
            <xsl:call-template name="get_Task_Details" />
            <xsl:apply-templates />
          </xsl:otherwise>
        </xsl:choose>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>
  
  <!--
  Retrieves task details
  -->
  <xsl:template name="get_Task_Details">
    <li>
      <xsl:call-template name="get_Task_Title" />
      <br/>
      <xsl:call-template name="get_Task_Base_Info" />
      <br/>
      <xsl:call-template name="get_Task_Dates" />
      <br/>
      <xsl:call-template name="get_Task_People" />
      <br/>
      <xsl:if tes