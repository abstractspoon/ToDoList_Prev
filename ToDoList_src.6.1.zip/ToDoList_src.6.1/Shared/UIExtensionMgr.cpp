 - 1, FALSE);
		break;
	}

	if (nFind != -1)
		SelectTask(GetTaskID(nFind));

	return (nFind != -1);
}

int CFilteredToDoCtrl::FindTask(LPCTSTR szPart, int nStart, BOOL bNext)
{
	// build a search query
	SEARCHPARAMS params;
	params.rules.Add(SEARCHPARAM(TDCA_TASKNAMEORCOMMENTS, FO_INCLUDES, szPart));

	// we need to do this manually because CListCtrl::FindItem 
	// only looks at the start of the string
	SEARCHRESULT result;

	int nFrom = nStart;
	int nTo = bNext ? m_list.GetItemCount() : -1;
	int nInc = bNext ? 1 : -1;

	for (int nItem = nFrom; nItem != nTo; nItem += nInc)
	{
		DWORD dwTaskID = GetTaskID(nItem);

		if (m_data.TaskMatches(dwTaskID, params, result))
			return nItem;
	}

	return -1; // no match
}

void CFilteredToDoCtrl::SelectNextTasksInHistory()
{
	if (InListView() && CanSelectNextTasksInHistory())
	{
		// let CToDoCtrl do it's thing
		CToDoCtrl::SelectNextTasksInHistory();

		// then update our own selection
		ResyncListSelection();
	}
	else
		CToDoCtrl::SelectNextTasksInHistory();
}

BOOL CFilteredToDoCtrl::MultiSelectItems(const CDWordArray& aTasks, TSH_SELECT nState, BOOL bRedraw)
{
	BOOL bRes = CToDoCtrl::MultiSelectItems(aTasks, nState, bRedraw);

	if (InListView())
		ResyncListSelection();

	return bRes;
}

void CFilteredToDoCtrl::ResyncListSelection()
{
//	CAutoFlag af(m_bResyncingSel, TRUE);
	ClearListSelection();
		
	// then update our own selection
	CDWordArray aTreeTaskIDs;
	DWORD dwFocusedID;
	
	GetSelectedTaskIDs(aTreeTaskIDs, dwFocusedID, FALSE);
	SetSelectedListTasks(aTreeTaskIDs, dwFocusedID);
	
	// now check that the tree is synced with us!
	CDWordArray aListTaskIDs;
	GetSelectedListTaskIDs(aListTaskIDs, dwFocusedID);
	
	if (!Misc::ArraysMatch(aListTaskIDs, aTreeTaskIDs))
		CToDoCtrl::MultiSelectItems(aListTaskIDs, TSHS_SELECT, FALSE);
}


void CFilteredToDoCtrl::SelectPrevTasksInHistory()
{
	if (InListView() && CanSelectPrevTasksInHistory())
	{
		// let CToDoCtrl do it's thing
		CToDoCtrl::SelectPrevTasksInHistory();

		// then update our own selection
		ResyncListSelection();
	}
	else
		CToDoCtrl::SelectPrevTasksInHistory();
}

void CFilteredToDoCtrl::InvalidateItem(HTREEITEM hti)
{
	if (InListView())
	{
		int nItem = GetListItem(hti);
		CRect rItem;

		if (GetItemTitleRect(nItem, TDCTR_BOUNDS, rItem))
			m_list.InvalidateRect(rItem, FALSE);
	}
	else
		CToDoCtrl::InvalidateItem(hti);
}

LRESULT CFilteredToDoCtrl::ScWindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case WM_RBUTTONDOWN:
		{
			// work out what got hit and make sure it's selected
			CPoint ptHit(lp);
			LVHITTESTINFO lvhti = { { ptHit.x, ptHit.y }, 0, 0, 0 };

			int nHit = m_list.HitTest(&lvhti);

			if (!IsItemSelected(nHit))
				SelectTask(GetTaskID(nHit));
		}
		break;

	case WM_LBUTTONDOWN:
		{
			// work out what got hit
			CPoint ptHit(lp);
			LVHITTESTINFO lvhti = { { ptHit.x, ptHit.y }, 0, 0, 0 };

			m_list.SubItemHitTest(&lvhti);
			int nHit = lvhti.iItem;

			if (nHit != -1 && !IsReadOnly())
			{
				TDC_COLUMN nCol = GetColumnID(lvhti.iSubItem);
				DWORD dwTaskID = GetTaskID(nHit);
				//HTREEITEM htiHit = GetTreeItem(nHit);

				// if the user is clicking on an already multi-selected
				// item since we may need to carry out an operation on multiple items
				int nSelCount = GetSelectedCount();

				if (nSelCount > 1 && IsItemSelected(nHit))
				{
					switch (nCol)
					{
					case TDCC_DONE:
						{
							BOOL bDone = m_data.IsTaskDone(dwTaskID);
							SetSelectedTaskDone(!bDone);
							return 0; // eat it
						}
						break;

					case TDCC_CLIENT:
						{
							CRect rCheck;

							if (GetItemTitleRect(nHit, TDCTR_CHECKBOX, rCheck) && rCheck.PtInRect(ptHit))
							{
								BOOL bDone = m_data.IsTaskDone(dwTaskID);
								SetSelectedTaskDone(!bDone);
								return 0; // eat it
							}
						}
						break;
						
					case TDCC_FLAG:
						{
							BOOL bFlagged = m_data.IsTaskFlagged(dwTaskID);
							SetSelectedTaskFlag(!bFlagged);
							return 0; // eat it
						}
						break;
					}
				}
				else if (nSelCount == 1)
				{
					// if the click was on the task title of an already singly selected item
					// we record the task ID unless the control key is down in which case
					// it really means that the user has deselected the item
					if (!Misc::ModKeysArePressed(MKS_CTRL))
					{
						m_dw2ndClickItem = 0;
						
						int nSel = GetFirstSelectedItem();
						if (nHit != -1 && nHit == nSel && nCol == TDCC_CLIENT)
						{
							// unfortunately we cannot rely on the flags attribute of LVHITTESTINFO
							// to see if the user clicked on the text because LVIR_LABEL == LVIR_BOUNDS
							CRect rLabel;
							CClientDC dc(&m_list);
							CFont* pOld = NULL;

							if (m_tree.GetParentItem(GetTreeItem(nHit)) == NULL) // top level items
								pOld = (CFont*)dc.SelectObject(CFont::FromHandle(m_fontBold));
							else
								pOld = (CFont*)dc.SelectObject(m_list.GetFont());

							GetItemTitleRect(nHit, TDCTR_LABEL, rLabel, &dc, GetSelectedTaskTitle());
			
							if (rLabel.PtInRect(ptHit))
								m_dw2ndClickItem = m_list.GetItemData(nHit);

							// cleanup
							dc.SelectObject(pOld);
						}

						// note: we handle WM_LBUTTONUP in OnListClick() to 
						// decide whether to do a label edit
					}
				}
			}

			// because the visual state of the list selection is actually handled by
			// whether the tree selection is up to date we need to update the tree
			// selection here, because the list ctrl does it this way natively.
			LRESULT	lr = CSubclasser::ScWindowProc(hRealWnd, msg, wp, lp);
			UpdateTreeSelection();

			return lr;
		}
		break;

	case LVM_EDITLABEL:
		if (!IsReadOnly())
			EditSelectedTask(FALSE);
		return 0; // eat it

	case WM_KEYDOWN:
		{
			// if any of the cursor keys are used and nothing is currently selected
			// then we select the top/bottom item and ignore the default list ctrl processing
			LRESULT lr = 0;

/*
			if (GetSelectedCount() == 0 && Misc::IsCursorKey(wp))
			{
				int nNumItems = m_list.GetItemCount();

				if (nNumItems > 0)
				{
					int nSelItem = 0; // top item is default

					if (wp == VK_UP || wp == VK_PRIOR)
						nSelItem = nNumItems - 1; // bottom item

					m_list.SetItemState(nSelItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
				}
			}
			else
*/
				lr = CSubclasser::ScWindowProc(hRealWnd, msg, wp, lp);

			m_wKeyPress = (WORD)wp;

			if (Misc::IsCursorKey(wp))
				UpdateTreeSelection();

			return lr;
		}
		break;

	case WM_KEYUP:
		if (Misc::IsCursorKey(wp))
			UpdateControls();
		break;

	case WM_MOUSEWHEEL:
	case WM_VSCROLL:
	case WM_HSCROLL:
		if (InListView