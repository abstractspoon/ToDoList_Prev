<?xml version="1.0" ?>
<!-- History:
V2.0 Author Hoppfrosch@gmx.de, 20061105
  [*]  Correct formatting of RTF-Comments (based on ToDoStyler1.5 by .dan.g.)
    * See: http://www.codeproject.com/tools/todolist2.asp?df=100&forumid=25857&select=1739493#xx1739493xx
    * Works only with TDL Version newer than 5.0b7
  Known issues:
   * Problems with german umlauts in Comments (The text after the last Umlaut isn't shown in transformed output - at least at my computer)
   * See: http://www.codeproject.com/tools/ToDoList2.asp?df=100&forumid=25857&fr=26&select=1739493#xx1739493xx 
V1.3 Author Hoppfrosch@gmx.de, 20060621
 [-] Completion bars for Firefox/Opera
 [-] Priority colorisation of finished tasks is switched off
 [*] Replaced @PERCENTDONE by @CALCPERCENTDONE to simulate the visual behaviour of TDL
  Known issues:
   * Display of completion and status field is shown as completed (greyed) with completed tasks (Firefox/Opera)
   * Comments are without formatting (all browsers))
 
V1.2 Author Hoppfrosch@gmx.de, 20051123
 [+] Added Anchor (Task-ID) to element taskname, so tasks can be linked directly ....
 Known issues: see V1.1

V1.1 Author Hoppfrosch@gmx.de, 20051108
 [*] Added browser compatibility for generated HTML-Code (IExplore, Firefox, Opera) ...
 [+] Insertion of Filerefs as HTML-Links
 Known issues:
   * Generation of completion bar fails (Firefox/Opera)
   * Display of completion and status field is shown as completed (greyed) with completed tasks (Firefox/Opera)
   * Comments are without formatting (all browsers))

V1.0 ToDoListStyler 1.0 Original by Manual Reyes 
-->

<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
  <xsl:strip-space elements="*" />
  
  <xsl:template match="TODOLIST">
    <xsl:element name="html">
      <xsl:element name="head">
        <title>
          <xsl:value-of select="@PROJECTNAME" />
        </title>
        
        <style>
          body
          {
            font-family: Verdana, serif;
            margin: 5px;
            background-color : #C0C0C0;
            font-size: 12px;
            /* width: 800px; */
          }
          
          .headerSpan
          {
            background-color: #C4D7FF;
            border: 1px solid #006699;
            padding: 1px; 
            text-align: center;
            width :100%;
          }
          
          .footerSpan
          {
            background-color: #C4D7FF;
            border: 1px solid #006699;
            padding: 1px; 
            font-size: 10px;
            text-align: center;
            width :100%;
          }
          
          .masterTaskSpan
          {
            background-color: #FFFFFF;
            border: 1px solid #006699;
            padding: 1px; 
            text-align: left;
            width :100%;
          }
          
          .completed
          {
            font-weight: normal;
            background-color: #EEEEEE;
            color: #808080;
          }
          
          .progressBarBorder 
          {
            height: 15px;
            width: 400px;
            background: #fff;
            border: 1px solid silver;
            margin: 0;
            padding: 0;
          }

          .progressBar {
            height: 11px;
            margin: 2px;
            padding: 0;
            background: #C9DDEC;
          }
          
          .prettyPriority
          {
            width:20px;
            text-align:center;
            color: white;
          }

          .taskid
          {
            font-size: 8px;
          }

          .masterTaskTitleText
          {
            border-left: 2px solid blue;
            border-bottom: 3px solid blue;
            font-weight: bold;
            font-size: 12px;
            color: #000000;
          }
          
          .subTaskTitleText
          {
            border-left: 1px solid blue;
            border-bottom: 2px solid blue;
            font-w