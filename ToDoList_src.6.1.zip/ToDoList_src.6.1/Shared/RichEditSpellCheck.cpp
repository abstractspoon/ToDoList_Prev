RTS()

//---------------------------------------------------------------------------------------
//   "TaskBar" Parts & States
//---------------------------------------------------------------------------------------
BEGIN_TM_CLASS_PARTS(TASKBAR)
    TM_PART(1, TBP, BACKGROUNDBOTTOM)
    TM_PART(2, TBP, BACKGROUNDRIGHT)
    TM_PART(3, TBP, BACKGROUNDTOP)
    TM_PART(4, TBP, BACKGROUNDLEFT)
    TM_PART(5, TBP, SIZINGBARBOTTOM)
    TM_PART(6, TBP, SIZINGBARRIGHT)
    TM_PART(7, TBP, SIZINGBARTOP)
    TM_PART(8, TBP, SIZINGBARLEFT)
END_TM_CLASS_PARTS()

//---------------------------------------------------------------------------------------
//   "TaskBand" Parts & States
//---------------------------------------------------------------------------------------
BEGIN_TM_CLASS_PARTS(TASKBAND)
    TM_PART(1, TDP, GROUPCOUNT)
    TM_PART(2, TDP, FLASHBUTTON)
    TM_PART(3, TDP, FLASHBUTTONGROUPMENU)
END_TM_CLASS_PARTS()

//---------------------------------------------------------------------------------------
//   "StartPanel" Parts & States
//---------------------------------------------------------------------------------------
BEGIN_TM_CLASS_PARTS(STARTPANEL)
    TM_PART(1, SPP, USERPANE)
    TM_PART(2, SPP, MOREPROGRAMS)
    TM_PART(3, SPP, MOREPROGRAMSARROW)
    TM_PART(4, SPP, PROGLIST)
    TM_PART(5, SPP, PROGLISTSEPARATOR)
    TM_PART(6, SPP, PLACESLIST)
    TM_PART(7, SPP, PLACESLISTSEPARATOR)
    TM_PART(8, SPP, LOGOFF)
    TM_PART(9, SPP, LOGOFFBUTTONS)
    TM_PART(10, SPP, USERPICTURE)
    TM_PART(11, SPP, PREVIEW)
END_TM_CLASS_PARTS()

BEGIN_TM_PART_STATES(MOREPROGRAMSARROW)
    TM_STATE(1, SPS, NORMAL)
    TM_STATE(2, SPS, HOT)
    TM_STATE(3, SPS, PRESSED)
END_TM_PART_STATES()

BEGIN_TM_PART_STATES(LOGOFFBUTTONS)
    TM_STATE(1, SPLS, NORMAL)
    TM_STATE(2, SPLS, HOT)
    TM_STATE(3, SPLS, PRESSED)
END_TM_PART_STATES()

//---------------------------------------------------------------------------------------
//   "ExplorerBar" Parts & States
//---------------------------------------------------------------------------------------
BEGIN_TM_CLASS_PARTS(EXPLORERBAR)
    TM_PART(1, EBP, HEADERBACKGROUND)
    TM_PART(2, EBP, HEADERCLOSE)
    TM_PART(3, EBP, HEADERPIN)
    TM_PART(4, EBP, IEBARMENU)
    TM_PART(5, EBP, NORMALGROUPBACKGROUND)
    TM_PART(6, EBP, NORMALGROUPCOLLAPSE)
    TM_PART(7, EBP, NORMALGROUPEXPAND)
    TM_PART(8, EBP, NORMALGROUPHEAD)
    TM_PART(9, EBP, SPECIALGROUPBACKGROUND)
    TM_PART(10, EBP, SPECIALGROUPCOLLAPSE)
    TM_PART(11, EBP, SPECIALGROUPEXPAND)
    TM_PART(12, EBP, SPECIALGROUPHEAD)
END_TM_CLASS_PARTS()

BEGIN_TM_PART_STATES(HEADERCLOSE)
    TM_STATE(1, EBHC, NORMAL)
    TM_STATE(2, EBHC, HOT)
    TM_STATE(3, EBHC, PRESSED)
END_TM_PART_STATES()

BEGIN_TM_PART_STATES(HEADERPIN)
    TM_STATE(1, EBHP, NORMAL)
    TM_STATE(2, EBHP, HOT)
    TM_STATE(3, EBHP, PRESSED)
    TM_STATE(4, EBHP, SELECTEDNORMAL)
    TM_STATE(5, EBHP, SELECTEDHOT)
    TM_STATE(6, EBHP, SELECTEDPRESSED)
END_TM_PART_STATES()

BEGIN_TM_PART_STATES(IEBARMENU)
    TM_STATE(1, EBM, NORMAL)
    TM_STATE(2, EBM, HOT)
    TM_STATE(3, EBM, PR