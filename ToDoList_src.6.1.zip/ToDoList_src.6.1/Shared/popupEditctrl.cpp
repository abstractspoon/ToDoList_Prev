#if !defined(AFX_PREFERENCESDLG_H__C3FCC72A_6C69_49A6_930D_D5C94EC31298__INCLUDED_)
#define AFX_PREFERENCESDLG_H__C3FCC72A_6C69_49A6_930D_D5C94EC31298__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesDlg.h : header file
//

#include "..\shared\preferencesbase.h"

#include "preferencesgenpage.h"
#include "preferencestaskpage.h"
#include "preferencestaskdefpage.h"
#include "preferencestoolpage.h"
#include "preferencesuipage.h"
#include "preferencesuitasklistpage.h"
#include "preferencesuitasklistcolorspage.h"
#include "preferencesshortcutspage.h"
#include "preferencesfilepage.h"
#include "preferencesexportpage.h"
#include "preferencesmultiuserpage.h"
#include "preferencesfile2page.h"
#include "preferencestaskcalcpage.h"

//#include "..\shared\propertypagehost.h"

// matches order of pages
enum 
{ 
	PREFPAGE_GEN, 
	PREFPAGE_MULTIUSER, 
	PREFPAGE_FILE, 
	PREFPAGE_FILE2, 
	PREFPAGE_UI, 
	PREFPAGE_UITASK, 
	PREFPAGE_UIFONTCOLOR, 
	PREFPAGE_TASK, 
	PREFPAGE_TASKCALC, 
	PREFPAGE_TASKDEF, 
	PREFPAGE_IMPEXP, 
	PREFPAGE_TOOL, 
	PREFPAGE_SHORTCUT 
};

/////////////////////////////////////////////////////////////////////////////
// CPreferencesDlg dialog

class CPreferencesDlg : public CPreferencesDlgBase
{
// Construction
public:
	CPreferencesDlg(CShortcutManager* pShortcutMgr = NULL, UINT nMenuID = 0, 
					const CContentMgr* pContentMgr = NULL, const CImportExportMgr* pExportMgr = NULL, 
					CWnd* pParent = NULL);   // standard constructor
	virtual ~CPreferencesDlg();

	BOOL GetAlwaysOnTop() const { return m_pageGen.GetAlwaysOnTop(); }
	BOOL GetUseSysTray() const { return m_pageGen.GetUseSysTray(); }
	BOOL GetConfirmDelete() const { return m_pageGen.GetConfirmDelete(); }
	BOOL GetConfirmSaveOnExit() const { return m_pageGen.GetConfirmSaveOnExit(); }
	BOOL GetShowOnStartup() const { return m_pageGen.GetShowOnStartup(); }
	int GetSysTrayOption() const { return m_pageGen.GetSysTrayOption(); }
	BOOL GetToggleTrayVisibility() const { return m_pageGen.GetToggleTrayVisibility(); }
	BOOL GetMultiInstance() const { return m_pageGen.GetMultiInstance(); }
	BOOL GetGlobalHotkey() const { return m_pageGen.GetGlobalHotkey(); }
	BOOL GetAddFilesToMRU() const { return m_pageGen.GetAddFilesToMRU(); }
	BOOL GetEnableTDLExtension() const { return m_pageGen.GetEnableTDLExtension(); }
	BOOL GetEnableTDLProtocol() const { return m_pageGen.GetEnableTDLProtocol(); }
	BOOL GetAutoCheckForUpdates() const { return m_pageGen.GetAutoCheckForUpdates(); }
	BOOL GetEscapeMinimizes() const { return m_pageGen.GetEscapeMinimizes(); }
	BOOL GetEnableDelayedLoading() const { return m_pageGen.GetEnableDelayedLoading(); }

	int GetReadonlyReloadOption() const { return m_pageMultiUser.GetReadonlyReloadOption(); }
	int GetTimestampReloadOption() const { return m_pageMultiUser.GetTimestampReloadOption(); }
	BOOL GetEnableSourceControl() const { return m_pageMultiUser.GetEnableSourceControl(); }
	BOOL GetSourceControlLanOnly() const { return m_pageMultiUser.GetSourceControlLanOnly(); }
	BOOL GetAutoCheckOut() const { return m_pageMultiUser.GetAutoCheckOut(); }
	BOOL GetCheckoutOnCheckin() const { return m_pageMultiUser.GetCheckoutOnCheckin(); }
	BOOL GetCheckinOnClose() const { return m_pageMultiUser.GetCheckinOnClose(); }
	UINT GetRemoteFileCheckFrequency() const { return m_pageMultiUser.GetRemoteFileCheckFrequency(); }
	UINT GetCheckinOnNoEditTime() const { return m_pageMultiUser.GetCheckinOnNoEditTime(); }
	BOOL GetUsing3rdPartySourceControl() const { return m_pageMultiUser.GetUsing3rdPartySourceControl(); }

	int GetNotifyDueByOnLoad() const { return m_pageFile.GetNotifyDueByOnLoad(); }
	int GetNotifyDueByOnSwitch() const { return m_pageFile.GetNotifyDueByOnSwitch(); }
	BOOL GetDisplayDueTasksInHtml() const { return m_pageFile.GetDisplayDueTasksInHtml(); }
	BOOL GetAutoArchive() const { return m_pageFile.GetAutoArchive(); }
	BOOL GetNotifyReadOnly() const { return m_pageFile.GetNotifyReadOnly(); }
	BOOL GetRemoveArchivedTasks() const { return m_pageFile.GetRemoveArchivedTasks(); }
	BOOL GetRemoveOnlyOnAbsoluteCompletion() const { return m_pageFile.GetRemoveOnlyOnAbsoluteCompletion(); }
	BOOL GetRefreshFindOnLoad() const { return m_pageFile.GetRefreshFindOnLoad(); }
	BOOL GetDueTaskTitlesOnly() const { return m_pageFile.GetDueTaskTitlesOnly(); }
	CString GetDueTaskStylesheet() const { return m_pageFile.GetDueTaskStylesheet(); }
	CString GetDueTaskPerson() const { return m_pageFile.GetDueTaskPerson(); }
	BOOL GetWarnAddDeleteArchive() const { return m_pageFile.GetWarnAddDeleteArchive(); }
	BOOL GetDontRemoveFlagged() const { return m_pageFile.GetDontRemoveFlagged(); }
	BOOL GetExpandTasksOnLoad() const { return m_pageFile.GetExpandTasksOnLoad(); }

	BOOL GetBackupOnSave() const { return m_pageFile2.GetBackupOnSave(); }
	CString GetBackupLocation() const { return m_pageFile2.GetBackupLocation(); }
	int GetKeepBackupCount() const { return m_pageFile2.GetKeepBackupCount(); }
	BOOL GetAutoExport() const { return m_pageFile2.GetAutoE