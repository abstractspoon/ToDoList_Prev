ired"/>
					<xsd:attribute name="LASTMODIFIED" use="required"/>
					<xsd:attribute name="FILEVERSION" use="required"/>
					<xsd:attribute name="FILENAME" use="optional"/>
					<xsd:attribute name="FILEFORMAT" use="required"/>
					<xsd:attribute name="EARLIESTDUEDATE" use="required"/>
					<xsd:attribute name="CUSTOMCOMMENTSTYPE"/>
				</xsd:extension>
			</xsd:complexContent>
		</xsd:complexType>
	</xsd:element>
	<xsd:complexType name="taskType">
		<xsd:sequence>
			<xsd:element name="TASK" nillable="true" maxOccurs="unbounded">
				<xsd:complexType>
					<xsd:complexContent>
						<xsd:extension base="subtaskType">
							<xsd:attribute name="ALLOCATEDBY"/>
							<xsd:attribute name="CALCCOST"/>
							<xsd:attribute name="CALCPERCENTDONE"/>
							<xsd:attribute name="CALCTIMEESTIMATE"/>
							<xsd:attribute name="CALCTIMESPENT"/>
							<xsd:attribute name="CATEGORY"/>
							<xsd:attribute name="CATEGORY1"/>
							<xsd:attribute name="CATEGORY2"/>
							<xsd:attribute name="CATEGORY3"/>
							<xsd:attribute name="CATEGORY4"/>
							<xsd:attribute name="CATEGORY5"/>
							<xsd:attribute name="CATEGORY6"/>
							<xsd:attribute name="CATEGORY7"/>
							<xsd:attribute name="CATEGORY8"/>
							<xsd:attribute name="CATEGORY9"/>
							<xsd:attribute name="COLOR"/>
							<xsd:attribute name="COMMENTS"/>
							<xsd:attribute name="COMMENTSTYPE"/>
							<xsd:attribute name="COST"/>
							<xsd:attribute name="CREATIONDATE"/>
							<xsd:attribute name="CREATIONDATESTRING"/>
							<xsd:attribute name="CUSTOMCOMMENTS"/>
							<xsd:attribute name="DEPENDS"/>
							<xsd:attribute name="DEPENDS1"/>
							<xsd:attribute name="DEPENDS2"/>
							<xsd:attribute name="DEPENDS3"/>
							<xsd:attribute name="DEPENDS4"/>
							<xsd:attribute name="DEPENDS5"/>
							<xsd:attribute name="DEPENDS6"/>
							<xsd:attribute name="DEPENDS7"/>
							<xsd:attribute name="DEPENDS8"/>
							<xsd:attribute name="DEPENDS9"/>
							<xsd:attribute name="DONEDATE"/>
							<xsd:attribute name="DONEDATESTRING"/>