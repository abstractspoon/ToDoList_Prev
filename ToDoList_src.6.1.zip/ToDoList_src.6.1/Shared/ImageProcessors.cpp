// UIThemeFile.cpp: implementation of the CUIThemeFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "todolist.h"
#include "UIThemeFile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CUIThemeFile::CUIThemeFile() : CXmlFile("TODOLIST")
{

}

CUIThemeFile::~CUIThemeFile()
{

}

BOOL CUIThemeFile::LoadThemeFile(LPCTSTR szThemeFile)
{
	if (!CXmlFile::Load(szThemeFile))
		return FALSE;

	if (!GetItem("UITHEME"))
		return FALSE;

	// else
	return TRUE;
}

void CUIThemeFile::GetTheme(UITHEME& theme) const
{
	theme.nStyle = GetStyle();

	theme.crAppBackDark = GetColor("APPBACKDARK");
	theme.crAppBackLight = GetColor("APPBACKLIGHT");
	theme.crAppLines = GetColor("APPLINES");
	//theme.crAppText = GetColor("APPTEXT");
	theme.crMenuBack = GetColor("MENUBACK");
	theme.crToolbarDark = GetColor("TOOLBARDARK");
	theme.crToolbarLight = GetColor("TOOLBARLIGHT");
	theme.crStatusBarDark = GetColor("STATUSBARDARK");
	theme.crStatusBarLight = GetColor("STATUSBARLIGHT");
}

COLORREF CUIThemeFile::GetColor(LPCTSTR szName) const
{
	const CXmlItem* pXIName = FindItem("NAME", szName);

	if (!pXIName)
		return UIT_NOCOLOR;

	const CXmlItem* pXIColor = pXIName->GetParent();
	ASSERT(pXIColor);

	BYTE bRed = (BYTE)pXIColor->GetItemValueI("R");
	BYTE bGreen = (BYTE)pXIColor->GetItemValueI("G");
	BYTE bBlue = (BYTE)pXIColor->GetItemValueI("B");

	return RGB(bRed, bGreen, bBlue);
}

UI_STYLE CUIThemeFile::GetStyle() const
{
	const CXmlItem* pXITheme = GetItem("UITHEME");
	ASSERT (pXITheme);

	if (!pXITheme)
		return UIS_GRADIENT;

	CString sStyle = pXITheme->GetItemValue("STYLE");

	if (sStyle == "GLASS")
		return UIS_GLASS;

	// else
	return UIS_GRADIENT;
}
                   * dCosA / 2 - sizeSrc.cx * dSinA / 2);

	// find the max absolute values in each direction
	int nMaxY = max(abs(ptTopLeft.y), max(abs(ptTopRight.y), max(abs(ptBottomLeft.y), abs(ptBottomRight.y))));
	int nMaxX = max(abs(ptTopLeft.x), max(abs(ptTopRight.x), max(abs(ptBottomLeft.x), abs(ptBottomRight.x))));
	
	return CSize((nMaxX + 1) * 2, (nMaxY + 1) * 2);
}

BOOL CImageRotator::ProcessPixels(RGBX* pSrcPixels, CSize sizeSrc, RGBX* pDestPixels, CSize sizeDest, 
								COLORREF /*crMask*/)
{
	BOOL bRes = TRUE;

	if (!m_dRadians)
		bRes = C32BitImageProcessor::ProcessPixels(pSrcPixels, sizeSrc, pDestPixels, sizeDest);
	else
	{
		// note: we also need to translate the coords after rotating
		CSize sizeDestOffset(sizeDest.cx / 2 + sizeDest.cx % 2, sizeDest.cy / 2 + sizeDest.cy % 2);
		CSize sizeSrcOffset(sizeSrc.cx / 2 + sizeSrc.cx % 2, sizeSrc.cy / 2 + sizeSrc.cy % 2);

		CRect rSrc(0, 0, sizeSrc.cx - 1, sizeSrc.cy - 1);
		rSrc.OffsetRect(-sizeSrcOffset);

		// note: traversing the src bitmap leads to artifacts in the destination image
		// what we do is to traverse the destination bitmaps and compute the equivalent 
		// source color - credit for this observation goes to Yves Maurer (GDIRotate) 2002
		double dCosA = cos(m_dRadians);
		double dSinA = sin(m_dRadians);

		for (int nY = 0; nY < sizeDest.cy; nY++)
		{
			// calc y components of rotation
			double dCosYComponent = (nY - sizeDestOffset.cy) * dCosA;
			double dSinYComponent = (nY - sizeDestOffset.cy) * dSinA;

			double dSrcX = -sizeDestOffset.cx * dCosA + dSinYComponent;
			double dSrcY = dCosYComponent - (-sizeDestOffset.cx * dSinA);

			for (int nX = 0; nX < sizeDest.cx; nX++)
			{
				dSrcX += dCosA;
				dSrcY -= dSinA;

				CPoint ptSrc((int)dSrcX, (int)dSrcY);
				int nPixel = (nY * sizeDest.cx + nX);

				if (rSrc.PtInRect(ptSrc))
				{
					if (!m_bWeightingEnabled)
					{
						ptSrc.Offset(sizeSrcOffset);
						RGBX* pRGBSrc = &pSrcPixels[ptSrc.y * sizeSrc.cx + ptSrc.x];
						
						pDestPixe// UIThemeFile.h: interface for the CUIThemeFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UITHEMEFILE_H__A652A09A_AB3F_4B65_A3D9_B4B975A36195__INCLUDED_)
#define AFX_UITHEMEFILE_H__A652A09A_AB3F_4B65_A3D9_B4B975A36195__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\SHARED\uitheme.h"
#include "..\SHARED\XmlFile.h"

class CUIThemeFile : public CXmlFile  
{
public:
	CUIThemeFile();
	virtual ~CUIThemeFile();

	BOOL LoadThemeFile(LPCTSTR szThemeFile);
	void GetTheme(UITHEME& theme) const;

protected:
	COLORREF GetColor(LPCTSTR szName) const;
	UI_STYLE GetStyle() const;

};

#endif // !defined(AFX_UITHEMEFILE_H__A652A09A_AB3F_4B65_A3D9_B4B975A36195__INCLUDED_)
                                                                                                                                                                                                                                            0)
				dYOffset = (double)m_nVert * nX / sizeDest.cx;
				
			else if (m_nVert < 0)
				dYOffset = (double)-m_nVert * (sizeDest.cx - nX) / sizeDest.cx;

			// shears +ve (right) or -ve (left)
			for (int nY = 0; nY < sizeDest.cy; nY++)
			{
				double dXOffset = 0;

				// calc the offset to src X coord
				if (m_nHorz < 0)
					dXOffset = (double)-m_nHorz * nY / sizeDest.cy;
				
				else if (m_nHorz > 0)
					dXOffset = (double)m_nHorz * (sizeDest.cy - nY) / sizeDest.cy;

				double dSrcX = nX - dXOffset;
				double dSrcY = nY - dYOffset;

				if ((int)dSrcX >= 0 && (int)dSrcX < sizeSrc.cx && (int)dSrcY >= 0 && (int)dSrcY < sizeSrc.cy)
				{
					if (!m_bWeightingEnabled)
					{
						RGBX* pRGBSrc = &pSrcPixels[(int)dSrcY * sizeSrc.cx + (int)dSrcX];
						pDestPixels[nY * sizeDest.cx + nX] = *pRGBSrc;
					}
					else
						CalcWeightedColor(pSrcPixels, sizeSrc, dSrcX, dSrcY, 
											pDestPixels[nY * sizeDest.cx + nX]);
				}
			}
		}
	}

	return bRes;
}

///////

CImageGrayer::CImageGrayer()
	: m_dRedFactor(0), m_dGreenFactor(0), m_dBlueFactor(0), m_bDefault(TRUE)
{
}

CImageGrayer::CImageGrayer(double dRedFactor, double dGreenFactor, double dBlueFactor)
	: m_dRedFactor(dRedFactor), m_dGreenFactor(dGreenFactor), m_dBlueFactor(dBlueFactor), m_bDefault(FALSE)
{
}

CImageGrayer::~CImageGrayer()
{
}

BOOL CImageGrayer::ProcessPixels(RGBX* pSrcPixels, CSize sizeSrc, RGBX* pDestPixels, CSize sizeDest, 
								COLORREF crMask)
{
	UNREFERENCED_PARAMETER(sizeDest);
	ASSERT (sizeSrc == sizeDest);

	for (int nX = 0; nX < sizeSrc.cx; nX++)
	{
		for (int nY = 0; nY < sizeSrc.cy; nY++)
		{
			RGBX* pRGBSrc = &pSrcPixels[nY * sizeSrc.cx + nX];
			RGBX* pRGBDest = &pDestPixels[nY * sizeSrc.cx + nX];

			if (crMask == -1 || !(crMask == *pRGBSrc))
			{
				if (m_bDefault)
					pRGBDest->MakeGray(*pRGBSrc);
				else
					pRGBDest->MakeGray(*pRGBSrc, m_dRedFactor, m_dGreenFactor, m_dBlueFactor);
			}
			else
				*pRGBDest = *pRGBSrc;
		}
	}

	return TRUE;
}

///////

CImageLightener::CImageLightener(double dAmount) : m_dAmount(dAmount)
{
}

CImageLightener::~CImageLightener()
{
}

BOOL CImageLightener::ProcessPixels(RGBX* pSrcPixels, CSize sizeSrc, RGBX* pDestPixels, CSize sizeDest, 
								COLORREF crMask)
{
	ASSERT (sizeSrc == sizeDest);
	BOOL bRes = TRUE;

	if (m_dAmount == 0)
		bRes = C32BitImageProcessor::ProcessPixels(pSrcPixels, sizeSrc, pDestPixels, sizeDest);
	else
	{
		for (int nX = 0; nX < sizeSrc.cx; nX++)
		{
			for (int nY = 0; nY < sizeSrc.cy; nY++)
			{
				RGBX* pRGBSrc = &pSrcPixels[nY * sizeSrc.cx + nX];
				RGBX* pRGBDest = &pDestPixels[nY * sizeSrc.cx + nX];

				if (crMask == -1 || !(crMask == *pRGBSrc))
				{
					// convert to HLS
					HLSX hls;
					RGBX::RGB2HLS(*pRGBSrc, hls);

					// then tweak the luminosity
					hls.fLuminosity = min(max(0.0f, hls.fLuminosity + (float)m_dAmount), 1.0f);
					RGBX::HLS2RGB(hls, *pRGBDest);
				}
				else
					*pRGBDest = *pRGBSrc;
			}
		}
	}// WelcomeWizard.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "WelcomeWizard.h"
#include "..\shared\dialoghelper.h"
#include "..\shared\misc.h"
#include "..\shared\graphicsmisc.h"
#include "..\shared\filemisc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWelcomeWizard

IMPLEMENT_DYNAMIC(CTDLWelcomeWizard, CPropertySheet)

CTDLWelcomeWizard::CTDLWelcomeWizard() : CPropertySheet("", NULL, 0)
{
	InitSheet();
}

void CTDLWelcomeWizard::InitSheet()
{
	m_hFont = GraphicsMisc::CreateFont("Tahoma");

	m_page1.AttachFont(m_hFont);
	m_page2.AttachFont(m_hFont);
	m_page3.AttachFont(m_hFont);

	AddPage(&m_page1);
	AddPage(&m_page2);
	AddPage(&m_page3);
	SetWizardMode();

	m_psh.dwFlags &= ~(PSH_HASHELP);		
}

CTDLWelcomeWizard::~CTDLWelcomeWizard()
{
}


BEGIN_MESSAGE_MAP(CTDLWelcomeWizard, CPropertySheet)
	//{{AFX_MSG_MAP(CWelcomeWizard)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_WIZFINISH, OnWizFinish)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWelcomeWizard message handlers

BOOL CTDLWelcomeWizard::OnInitDialog() 
{
	CPropertySheet::OnInitDialog();

	CDialogHelper::SetFont(this, m_hFont);

	HICON hIcon = AfxGetApp()->LoadIcon(IDI_TRAYICONXP);
	SetIcon(hIcon, FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTDLWelcomeWizard::OnWizFinish()
{	
	m_page1.UpdateData();
	m_page2.UpdateData();
	m_page3.UpdateData();

	EndDialog(ID_WIZFINISH);
}

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage1 property page

IMPLEMENT_DYNCREATE(CTDLWelcomePage1, CPropertyPage)

CTDLWelcomePage1::CTDLWelcomePage1() : CPropertyPage(CTDLWelcomePage1::IDD)
{
	//{{AFX_DATA_INIT(CWelcomePage1)
	m_bShareTasklists = 0;
	m_bUseIniFile = 1;
	//}}AFX_DATA_INIT
	m_psp.dwFlags &= ~(PSP_HASHELP);		
}

CTDLWelcomePage1::~CTDLWelcomePage1()
{
}

void CTDLWelcomePage1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWelcomePage1)
	DDX_Radio(pDX, IDC_NOSHARE, m_bShareTasklists);
	DDX_Radio(pDX, IDC_REGISTRY, m_bUseIniFile);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTDLWelcomePage1, CPropertyPage)
	//{{AFX_MSG_MAP(CWelcomePage1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage1 message handlers

BOOL CTDLWelcomePage1::OnInitDialog() 
{
	CDialogHelper::SetFont(this, m_hFont);
	CPropertyPage::OnInitDialog();
		
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage2 property page

IMPLEMENT_DYNCREATE(CTDLWelcomePage2, CPropertyPage)

CTDLWelcomePage2::CTDLWelcomePage2() : CPropertyPage(CTDLWelcomePage2::IDD)
{
	//{{AFX_DATA_INIT(CWelcomePage2)
	//}}AFX_DATA_INIT
	m_psp.dwFlags &= ~(PSP_HASHELP);		
}

CTDLWelcomePage2::~CTDLWelcomePage2()
{
}

void CTDLWelcomePage2::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWelcomePage2)
	DDX_Control(pDX, IDC_COLUMNLIST, m_lbColumns);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTDLWelcomePage2, CPropertyPage)
	//{{AFX_MSG_MAP(CWelcomePage2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage2 message handlers

BOOL CTDLWelcomePage2::OnInitDialog() 
{
	CDialogHelper::SetFont(this, m_hFont);
	CPropertyPage::OnInitDialog();

	// initialize the visible columns for first time users
	m_lbColumns.SetAllColumnsVisible(FALSE);
	m_lbColumns.SetColumnVisible(TDCC_PRIORITY);
	m_lbColumns.SetColumnVisible(TDCC_PERCENT);
	m_lbColumns.SetColumnVisible(TDCC_ALLOCTO);
	m_lbColumns.SetColumnVisible(TDCC_TIMEEST);
	m_lbColumns.SetColumnVisible(TDCC_TIMESPENT);
	m_lbColumns.SetColumnVisible(TDCC_STATUS);
	m_lbColumns.SetColumnVisible(TDCC_CATEGORY);
	m_lbColumns.SetColumnVisible(TDCC_TRACKTIME);
	m_lbColumns.SetColumnVisible(TDCC_DUEDATE);
	m_lbColumns.SetColumnVisible(TDCC_FILEREF);
	m_lbColumns.SetColumnVisible(TDCC_DONE);
//	m_lbColumns.SetColumnVisible();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CTDLWelcomePage2::OnSetActive() 
{
	((CPropertySheet*)GetParent())->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
	
	return CPropertyPage::OnSetActive();
}

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage3 property page

IMPLEMENT_DYNCREATE(CTDLWelcomePage3, CPropertyPage)

CTDLWelcomePage3::CTDLWelcomePage3() : CPropertyPage(CTDLWelcomePage3::IDD)
{
	//{{AFX_DATA_INIT(CWelcomePage3)
	m_bHideAttrib = 1;
	m_bViewSample = 1;
	//}}AFX_DATA_INIT
	CString sResFolder = FileMisc::GetModuleFolder() + "Resources";
	FileMisc::MakePath(m_sSampleTaskList, NULL, sResFolder, "Introduction.tdl");

	CString sFilter;
	sFilter.LoadString(IDS_TDLFILEFILTER);
	m_eSampleTasklist.SetFilter(sFilter);

	m_psp.dwFlags &= ~(PSP_HASHELP);		
}

CTDLWelcomePage3::~CTDLWelcomePage3()
{
}

void CTDLWelcomePage3::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWelcomePage3)
	DDX_Control(pDX, IDC_SAMPLETASKLIST, m_eSampleTasklist);
	DDX_Text(pDX, IDC_SAMPLETASKLIST, m_sSampleTaskList);
	DDX_Radio(pDX, IDC_ALLOPTIONS, m_bHideAttrib);
	DDX_Radio(pDX, IDC_NOSAMPLE, m_bViewSample);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTDLWelcomePage3, CPropertyPage)
	//{{AFX_MSG_MAP(CWelcomePage3)
	ON_BN_CLICKED(IDC_NOSAMPLE, OnNosample)
	ON_BN_CLICKED(IDC_SAMPLE, OnSample)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage3 message handlers

BOOL CTDLWelcomePage3::OnInitDialog() 
{
	CDialogHelper::SetFont(this, m_hFont);
	CPropertyPage::OnInitDialog();
	
	m_eSampleTasklist.SetButtonWidthDLU(1, 14);
	m_eSampleTasklist.EnableWindow(m_bViewSample);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTDLWelcomePage3::OnNosample() 
{
	UpdateData();
	m_eSampleTasklist.EnableWindow(m_bViewSample);
}

void CTDLWelcomePage3::OnSample() 
{
	UpdateData();
	m_eSampleTasklist.EnableWindow(m_bViewSample);
}


BOOL CTDLWelcomePage3::OnSetActive() 
{
	((CPropertySheet*)GetParent())->SetWizardButtons(PSWIZB_BACK | PSWIZB_FINISH);
	
	return CPropertyPage::OnSetActive();
}


                                                                                                                                                                      d + 1);

		if (nXStart > nXEnd)
			continue;

		for (int nY = 0; nY < sizeDest.cy; nY++)
		{
			nYStart = nYEnd + 1;
			dYEnd += dFactor;
			nYEnd = min(sizeSrc.cy - 1, (int)dYEnd + 1);

			if (nYStart > nYEnd)
				continue;

			int nCount = 0, nRed = 0, nGreen = 0, nBlue = 0;

			// average the pixels over the range
			for (int nXSub = nXStart; nXSub <= nXEnd; nXSub++)
			{
				for (int nYSub = nYStart; nYSub <= nYEnd; nYSub++)
				{
					RGBX* pRGBSrc = &pSrcPixels[nYSub * sizeSrc.cx + nXSub];

					nRed += pRGBSrc->btRed;
					nGreen += pRGBSrc->btGreen;
					nBlue += pRGBSrc->btBlue;
					nCount++;
				}
			}

			RGBX* pRGBDest = &pDestPixels[nY * sizeDest.cx + nX];

			pRGBDest->btRed = (BYTE)(nRed / nCount);
			pRGBDest->btGreen = (BYTE)(nGreen / nCount);
			pRGBDest->btBlue = (BYTE)(nBlue / nCount);
		}
	}

	return TRUE;
}

//////////////////////////////////////////////////////////////////////

CImageNegator::CImageNegator()
{
}

CImageNegator::~CImageNega#if !defined(AFX_WELCOMEWIZARD_H__089919DB_8CBF_4F53_BFDF_6BB1C1C63929__INCLUDED_)
#define AFX_WELCOMEWIZARD_H__089919DB_8CBF_4F53_BFDF_6BB1C1C63929__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WelcomeWizard.h : header file
//

#include "TDLColumnListBox.h"
#include "..\shared\fileedit.h"

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage1 dialog

class CTDLWelcomePage1 : public CPropertyPage
{
	DECLARE_DYNCREATE(CTDLWelcomePage1)

// Construction
public:
	CTDLWelcomePage1();
	~CTDLWelcomePage1();

	void AttachFont(HFONT hFont) { m_hFont = hFont; }
	BOOL GetUseIniFile() const { return m_bUseIniFile; }
	BOOL GetShareTasklists() const { return m_bShareTasklists; }

protected:
// Dialog Data
	//{{AFX_DATA(CWelcomePage1)
	enum { IDD = IDD_WELCOME_PAGE1 };
	int		m_bShareTasklists;
	int		m_bUseIniFile;
	//}}AFX_DATA
	HFONT m_hFont;


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CWelcomePage1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CWelcomePage1)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage2 dialog

class CTDLWelcomePage2 : public CPropertyPage
{
	DECLARE_DYNCREATE(CTDLWelcomePage2)

// Construction
public:
	CTDLWelcomePage2();
	~CTDLWelcomePage2();

	void AttachFont(HFONT hFont) { m_hFont = hFont; }
	int GetVisibleColumns(CTDCColumnArray& aColumns) const { return m_lbColumns.GetVisibleColumns(aColumns); }

protected:
// Dialog Data
	//{{AFX_DATA(CWelcomePage2)
	enum { IDD = IDD_WELCOME_PAGE2 };
	CTDLColumnListBox	m_lbColumns;
	//}}AFX_DATA
	HFONT m_hFont;


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CWelcomePage2)
	public:
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CWelcomePage2)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage3 dialog

class CTDLWelcomePage3 : public CPropertyPage
{
	DECLARE_DYNCREATE(CTDLWelcomePage3)

// Construction
public:
	CTDLWelcomePage3();
	~CTDLWelcomePage3();

	void AttachFont(HFONT hFont) { m_hFont = hFont; }
	BOOL GetHideAttributes() const { return m_bHideAttrib; }
	CString GetSampleFilePath() const { return m_bViewSample ? m_sSampleTaskList : ""; }

protected:
// Dialog Data
	//{{AFX_DATA(CWelcomePage3)
	enum { IDD = IDD_WELCOME_PAGE3 };
	CFileEdit	m_eSampleTasklist;
	CString	m_sSampleTaskList;
	int		m_bHideAttrib;
	int		m_bViewSample;
	//}}AFX_DATA
	HFONT m_hFont;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CWelcomePage3)
	public:
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CWelcomePage3)
	virtual BOOL OnInitDialog();
	afx_msg void OnNosample();
	afx_msg void OnSample();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CWelcomeWizard

class CTDLWelcomeWizard : public CPropertySheet
{
	DECLARE_DYNAMIC(CTDLWelcomeWizard)

// Construction
public:
	CTDLWelcomeWizard();

// Operations
public:
	BOOL GetUseIniFile() const { return m_page1.GetUseIniFile(); }
	BOOL GetShareTasklists() const { return m_page1.GetShareTasklists(); }
	int GetVisibleColumns(CTDCColumnArray& aColumns) const { return m_page2.GetVisibleColumns(aColumns); }
	BOOL GetHideAttributes() const { return m_page3.GetHideAttributes(); }
	CString GetSampleFilePath() const { return m_page3.GetSampleFilePath(); }

// Attributes
protected:
	CTDLWelcomePage1 m_page1;
	CTDLWelcomePage2 m_page2;
	CTDLWelcomePage3 m_page3;
	HFONT m_hFont;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWelcomeWizard)
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTDLWelcomeWizard();

	// Generated message map functions
protected:
	//{{AFX_MSG(CWelcomeWizard)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	afx_msg void OnWizFinish();
	DECLARE_MESSAGE_MAP()

protected:
	void InitSheet();

};

/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WELCOMEWIZARD_H__089919DB_8CBF_4F53_BFDF_6BB1C1C63929__INCLUDED_)
                                                                                               OLORREF crMask)
{
	BOOL bRes = TRUE;

	if (!m_nAmount)
		bRes = C32BitImageProcessor::ProcessPixels(pSrcPixels, sizeSrc, pDestPixels, sizeDest);
	else
	{
		float fFactor = 1.0f + m_nAmount / 100.0f;

		for (int nX = 0; nX < sizeSrc.cx; nX++)
		{
			for (int nY = 0; nY < sizeSrc.cy; nY++)
			{
				RGBX* pRGBSrc = &pSrcPixels[nY * sizeSrc.cx + nX];
				RGBX* pRGBDest = &pDestPixels[nY * sizeDest.cx + nX];

				if (crMask == -1 || !(crMask == *pRGBSrc))
				{
					pRGBDest->btRed = (BYTE)max(0, min(255, (int)((pRGBSrc->btRed - 128) * fFactor) + 128));
					pRGBDest->btGreen = (BYTE)max(0, min(255, (int)((pRGBSrc->btGreen - 128) * fFactor) + 128));
					pRGBDest->btBlue = (BYTE)max(0, min(255, (int)((pRGBSrc->btBlue - 128) * fFactor) + 128));
				}
				else
					*pRGBDest = *pRGBSrc;
			}
		}
	}

	return bRes;
}

////////////////////////////////////////////////////////////////////

// color mapping
struct COLORMAPPING
{
   COLORREF color;
   UINT nSysColor;
};

static COLORMAPPING COLORMAPPINGS[] = 
{
   { 0x000000, COLOR_BTNTEXT },       // black
   { 0x808080, COLOR_BTNSHADOW },     // dark gray
   { 0xC0C0C0, COLOR_BTNFACE },       // bright gray
   { 0xFFFFFF, COLOR_BTNHIGHLIGHT }   // white
};

BOOL CImageSysColorMapper::ProcessPixels(RGBX* pSrcPixels, CSize sizeSrc, RGBX* pDestPixels, CSize sizeDest, 
								COLORREF /*crMask*/)
{
	static int NUMCOLORMAPS = sizeof(COLORMAPPINGS) / sizeof(COLORMAPPING);

	for (int nMap = 0; nMap < NUMCOLORMAPS; nMap++)
	{
		CColorReplacer cr(COLORMAPPINGS[nMap].color, GetSysColor(COLORMAPPINGS[nMap].nSysColor));

		cr.ProcessPixels(pSrcPixels, sizeSrc, pDestPixels, sizeDest);

		// switch source and dest for next iteration provided its not the last
		if (nMap < NUMCOLORMAPS - 1)
		{
			RGBX* pTemp = pSrcPixels;
			pSrcPixels = pDestPixels;
			pDestPixels = pTemp;
		}
	}
	
	return TRUE;
}

////////////////////////////////////////////////////////////////////
