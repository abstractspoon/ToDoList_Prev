tom and right)
		{	bihOut.biHeight=-szBmp.cy; 				// to mirror bitmap is eough to use negative height between Get/SetDIBits
			SetDIBits(*pDC, bmpMem.operator HBITMAP(),nStart,szBmp.cy-nLenSub,pcImg,&biOut,DIB_RGB_COLORS);
			if(bBody && bVertic)					// when it is right oriented body -> flip twice, first flip border shadows, than flip shaded inside body again
			{	nStart=2; nLenSub=4; bihOut.biHeight=szBmp.cy;
				GetDIBits(*pDC, bmpMem.operator HBITMAP(),nStart,szBmp.cy-nLenSub,pcImg,&biOut,DIB_RGB_COLORS);
				bihOut.biHeight=-szBmp.cy;			// to mirror bitmap is eough to use negative height between Get/SetDIBits
				SetDIBits(*pDC, bmpMem.operator HBITMAP(),nStart,szBmp.cy-nLenSub,pcImg,&biOut,DIB_RGB_COLORS);
	}	}	}
	// 5th if it is bottom or right oriented tab, draw after mirroring background (do GetDIBits again)
	if(!bBody && ixItem>=0)							// 
	{	if(bSel) rcMem.bottom--;
		DrawTabItem(&dcMem, ixItem, rcMem, uiFlag);
		if(bVertic)											// if it is right tab, do GetDIBits again
		{	bihOut.biHeight=-szBmp.cy;
			GetDIBits(*pDC, bmpMem.operator HBITMAP(),nStart,szBmp.cy-nLenSub,pcImg,&biOut,DIB_RGB_COLORS);
	}	}
	// 6th: do rotate now, finaly
	if(bVertic)							// force rotating bitmap as RGB -> good for any resolution
	{	SwapVars(szBmp.cx,szBmp.cy);

		int nBmpWdtPD=DWordAlign(szBmp.cx*3);
		int nPadD=nBmpWdtPD-szBmp.cx*3;
		int nSzBuffPD=((nBmpWdtPD*szBmp.cy)/8+2)*8;
		LPBYTE pcImgRotate=new BYTE[nSzBuffPD]; ASSERT(pcImgRotate);
		int nWidth,nHeight=szBmp.cy,nHeight1=nHeight-1;
		//====================================
		//------------------------------------
								// here is the example how to speed up lengthy repeatetive processing by using inline assembler
	#define __USE_MASM__		// the same processing is in C and in asm. To use C -> comment the beginning of this line
								// Do the actual whole RGB bitmap rotating in C or assembler
	#ifndef __USE_MASM__
		LPBYTE pcImgS=pcImg;
		LPBYTE pcImgD=pcImgRotate;
		int ixHeight=0;
		BOOL bLast=FALSE;
		while(ixHeight<nHeight)					// for all destination height lines
		{	nWidth=szBmp.cx;
			if(ixHeight==nHeight1) { bLast=TRUE; nWidth--; }
			
			while(nWidth--)
			{	*(PDWORD)pcImgD=*(PDWORD)pcImgS; // do all Rgb triplets read/write qicker as DWORD
				pcImgS+=nBmpWdtPS;	// increment source in padded source lines
				pcImgD+=3;			// increment destination in rgb triplets
			}
			if(bLast)				// when the last line, the last pixel - colud be a problem if bitmap DWORD alligned 
				for(int c=3;c;c--) *pcImgD++=*pcImgS++;		// (only last three bytes available->could not read/write DWORD)!!
			else
			{	ixHeight++;
				pcImgD+=nPadD;				// destination bitmap horizontal padding to DWORD
				pcImgS=pcImg+(ixHeight*3);	// reset the source to the begining of the next vertical line
		}	}
	#else	// __USE_MASM__
			nBmpWdtPS-=4;					// adjust esi increment (due to esi self-incrementing by movsd)
			nWidth=szBmp.cx;
		__asm
		{		mov		esi, pcImg			// source index
				mov		edi, pcImgRotate	// destination index
				xor		ebx, ebx			// vertical counter
			loop_height:
				mov		ecx, nWidth			// horizontal counter
				cmp		ebx, nHeight1		// check is it the last line
				jne		loop_width
				dec		ecx					// if it is decremnt for the last pixel

			loop_width:
				movsd						// copies 4 bytes and increments source and destination by 4 (we need only 3 bytes copied 'one pixel' RGB triplet)
				dec		edi					// adjust edi to 'as incremented by 3'
				add		esi,nBmpWdtPS		// adjust esi to the next source line
				loop	loop_width			// loop one hotizontal destination line 

				cmp		ebx, nHeight1		// check is it the last line
				je		do_last				// if not last, do incrementing here
											
				inc		ebx					// increment vertical counter
				add		edi, nPadD			// adjust destination index by possible padding to DWORD
				mov		esi, ebx			// reset the source index: add vertical counter * 3 
				shl		esi, 1				// (is the same as * 2 +1*)
				add		esi, ebx			// +1*
				add		esi, pcImg			// add to the beginning of the source
				jmp		loop_height			// loop whole height

			do_last:						// the last pixel is done by
				movsw						// moving first two bytes
				movsb						// and than by moving the very last byte
		}
	#endif // 	__USE_MASM__
		dcMem.SelectObject(pBmpOld); bmpMem.DeleteObject();		// recreate rotated bitmap
		bmpMem.CreateCompatibleBitmap(pDC,szBmp.cx,szBmp.cy);
		dcMem.SelectObject(&bmpMem);
		bihOut.biWidth =szBmp.cx; bihOut.biHeight=bBody?-szBmp.cy:szBmp.cy;
		SetDIBits(*pDC, bmpMem.operator HBITMAP(),0,szBmp.cy,pcImgRotate,&biOut,DIB_RGB_COLORS); // set rotated bitmap bits
		delete pcImgRotate;
	}
	if(pcImg) delete pcImg;
	// 6th blit mirrored/rotated image to the screen
	pDC->BitBlt(rcItem.left,rcItem.top,szBmp.cx,szBmp.cy,&dcMem,0,0,SRCCOPY); // 
	dcMem.SelectObject(pBmpOld);
}
//----------------------------------------------------------------------------------------------------------
// draw tab item cont