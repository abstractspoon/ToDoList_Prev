// PreferencesFilePage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesFile2Page.h"

#include "..\shared\enstring.h"
#include "..\shared\dialoghelper.h"
#include "..\shared\filemisc.h"
#include "..\shared\importexportmgr.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesFile2Page property page

IMPLEMENT_DYNCREATE(CPreferencesFile2Page, CPreferencesPageBase)

CPreferencesFile2Page::CPreferencesFile2Page(const CImportExportMgr* pExportMgr) : 
		CPreferencesPageBase(CPreferencesFile2Page::IDD),
		m_eExportFolderPath(FES_FOLDERS | FES_COMBOSTYLEBTN),
		m_eSaveExportStylesheet(FES_COMBOSTYLEBTN, CEnString(IDS_XSLFILEFILTER)),
		m_pExportMgr(pExportMgr),
		m_eBackupLocation(FES_FOLDERS | FES_COMBOSTYLEBTN)
{
//	m_psp.dwFlags &= ~PSP_HASHELP;

	//{{AFX_DATA_INIT(CPreferencesFile2Page)
	m_nKeepBackups = 50;
	m_bExportFilteredOnly = FALSE;
	//}}AFX_DATA_INIT
	m_bOtherExport = FALSE;
	m_nOtherExporter = 1;
	m_bBackupOnSave = FALSE;
	m_nKeepBackups = 0;
	m_bExportFilteredOnly = FALSE;
	m_bExportToFolder = FALSE;
	m_nAutoSaveFrequency = 5;
	m_bAutoSave = TRUE;
	m_bAutoExport = FALSE;
	m_bAutoSaveOnSwitchTasklist = FALSE;
	m_bAutoSaveOnSwitchApp = FALSE;
	m_bOtherExport = FALSE;
	m_nOtherExporter = -1;
	m_bUseStylesheetForSaveExport = FALSE;
}

CPreferencesFile2Page::~CPreferencesFile2Page()
{
}

void CPreferencesFile2Page::DoDataExchange(CDataExchange* pDX)
{
	CPreferencesPageBase::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesFile2Page)
	DDX_Control(pDX, IDC_NUMBACKUPSTOKEEP, m_cbKeepBackups);
	DDX_Control(pDX, IDC_BACKUPLOCATION, m_eBackupLocation);
	DDX_Check(pDX, IDC_BACKUPONSAVE, m_bBackupOnSave);
	DDX_Text(pDX, IDC_BACKUPLOCATION, m_sBackupLocation);
	DDX_CBIndex(pDX, IDC_NUMBACKUPSTOKEEP, m_nKeepBackups);
	DDX_Check(pDX, IDC_EXPORTFILTERED, m_bExportFilteredOnly);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_OTHEREXPORTERS, m_cbOtherExporters);
	DDX_Control(pDX, IDC_SAVEEXPORTSTYLESHEET, m_eSaveExportStylesheet);
	DDX_Control(pDX, IDC_EXPORTFOLDER, m_eExportFolderPath);
	DDX_Check(pDX, IDC_EXPORTTOFOLDER, m_bExportToFolder);
	DDX_Text(pDX, IDC_EXPORTFOLDER, m_sExportFolderPath);
	DDX_Text(pDX, IDC_SAVEEXPORTSTYLESHEET, m_sSaveExportStylesheet);
	DDX_Check(pDX, IDC_USESTYLESHEETFORSAVE, m_bUseStylesheetForSaveExport);
	DDX_Check(pDX, IDC_AUTOSAVEONSWITCHTASKLIST, m_bAutoSaveOnSwitchTasklist);
	DDX_Check(pDX, IDC_AUTOSAVEONSWITCHAPP, m_bAutoSaveOnSwitchApp);
	DDX_Radio(pDX, IDC_HTMLEXPORT, m_bOtherExport);
	DDX_