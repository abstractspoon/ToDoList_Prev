***************/
int DWordAlign(int n)
	{ const int rem=n%4; if(rem) n+=(4-rem); return n; }
//----------------------------------------------------------------------------------------------------------
BOOL IsThemeActiveEx()
{								// check theme activity always (could change during application running)
	HINSTANCE hDll=LoadLibrary(CString((LPCTSTR)IDS_UTIL_UXTHEME));							// 'UxTheme.dll'
	if(hDll==NULL) return FALSE;				// the DLL won't be available on anything except Windows XP
	UINT (PASCAL *pfnIsThemeActive)();
	(FARPROC&)pfnIsThemeActive=GetProcAddress(hDll,CString((LPCTSTR)IDS_UTIL_THEMEACT));	// 'IsThemeActive'
	UINT uiThemeActive=0;
	if(pfnIsThemeActive)
		uiThemeActive=pfnIsThemeActive();			
	FreeLibrary(hDll);
	return uiThemeActive?TRUE:FALSE;
}
//----------------------------------------------------------------------------------------------------------
#define PACKVERSION(major,minor) MAKELONG(minor,major)
DWORD GetWinVersion()
{
	static DWORD c_dwWinVers=0;	// check win version only once (will not change during application)
	if(!c_dwWinVers)
	{	OSVERSIONINFO osvi;	ZeroMemory(&osvi, sizeof(OSVERSIONINFO));	// Initialize the OSVERSIONINFO structure.
		osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
		GetVersionEx(&osvi);
		c_dwWinVers=PACKVERSION(osvi.dwMajorVersion,osvi.dwMinorVersion);
	}
	return c_dwWinVers;
}
//----------------------------------------------------------------------------------------------------------
BOOL IsWinXP()         { return GetWinVersion()>=PACKVERSION(5,1)?TRUE:FALSE; }
//----------------------------------------------------------------------------------------------------------
BOOL IsThemeActiveXP() { return (IsWinXP()  && IsThemeActiveEx())?TRUE:FALSE; }
//----------------------------------------------------------------------------------------------------------
#define WPART_NAME_SZ 128
HRESULT DrawThemesPart(HDC hDC, int iPartId, int iStateId, LPCSTR