 }
	int GetVisibleColumns(CTDCColumnArray& aColumns) const { return m_pageUITasklist.GetVisibleColumns(aColumns); }
	void SetVisibleColumns(const CTDCColumnArray& aColumns) { m_pageUITasklist.SetVisibleColumns(aColumns); }
	BOOL GetShowPathInHeader() const { return m_pageUITasklist.GetShowPathInHeader(); }
	BOOL GetStrikethroughDone() const { return m_pageUITasklist.GetStrikethroughDone(); }
	BOOL GetFullRowSelection() const { return m_pageUITasklist.GetFullRowSelection(); }
	BOOL GetTreeCheckboxes() const { return m_pageUITasklist.GetTreeCheckboxes(); }
	BOOL GetTreeTaskIcons() const { return m_pageUITasklist.GetTreeTaskIcons(); }
	BOOL GetDisplayDatesInISO() const { return m_pageUITasklist.GetDisplayDatesInISO(); }
	BOOL GetShowWeekdayInDates() const { return m_pageUITasklist.GetShowWeekdayInDates(); }
	BOOL GetShowParentsAsFolders() const { return m_pageUITasklist.GetShowParentsAsFolders(); }
	BOOL GetDisplayFirstCommentLine() const { return m_pageUITasklist.GetDisplayFirstCommentLine(); }
	int GetMaxInfoTipCommentsLength() const { return m_pageUITasklist.GetMaxInfoTipCommentsLength(); }
	int GetMaxColumnWidth() const { return m_pageUITasklist.GetMaxColumnWidth(); }
	BOOL GetHidePercentForDoneTasks() const { return m_pageUITasklist.GetHidePercentForDoneTasks(); }
	BOOL GetHideZeroTimeCost() const { return m_pageUITasklist.GetHideZeroTimeCost(); }
	BOOL GetHideStartDueForDoneTasks() const { return m_pageUITasklist.GetHideStartDueForDoneTasks(); }
	BOOL GetShowPercentAsProgressbar() const { return m_pageUITasklist.GetShowPercentAsProgressbar(); }
	BOOL GetRoundTimeFractions() const { return m_pageUITasklist.GetRoundTimeFractions(); }
	BOOL GetShowNonFilesAsText() const { return m_pageUITasklist.GetShowNonFilesAsText(); }
	BOOL GetUseHMSTimeFormat() const { return m_pageUITasklist.GetUseHMSTimeFormat(); }
	BOOL GetAutoFocusTasklist() const { return m_pageUITasklist.GetAutoFocusTasklist(); }
	BOOL GetShowSubtaskCompletion() const { return m_pageUITasklist.GetShowSubtaskCompletion(); }
	BOOL GetShowColumnsOnRight() const { return m_pageUITasklist.GetShowColumnsOnRight(); }
	BOOL GetHideDueTimeField() const { return m_pageUITasklist.GetHideDueTimeField(); }
	BOOL GetHideStartTimeField() const { return m_pageUITasklist.GetHideStartTimeField(); }
	BOOL GetHideDoneTimeField() const { return m_pageUITasklist.GetHideDoneTimeField(); }

	int GetTextColorOption() const { return m_pageUITasklistColors.GetTextColorOption(); }
	BOOL GetColorTaskBackground() const { return m_pageUITasklistColors.GetColorTaskBackground(); }
	BOOL GetCommentsUseTreeFont() const { return m_pageUITasklistColors.GetCommentsUseTreeFont(); }
	BOOL GetColorPriority() const { return m_pageUITasklistColors.GetColorPriority(); }
	int GetPriorityColors(CDWordArray& aColors) const { return m_pageUITasklistColors.GetPriorityColors(aColors); }
	void GetDueTaskColors(COLORREF& crDue, COLORREF& crDueToday) const { m_pageUITasklistColors.GetDueTaskColors(crDue, crDueToday); }
	BOOL GetTreeFont(CString& sFaceName, int& nPointSize) const { return m_pageUITasklistColors.GetTreeFont(sFaceName, nPointSize); }
	BOOL GetCommentsFont(CString& sFaceName, int& nPointSize) const { return m_pageUITasklistColors.GetCommentsFont(sFaceName, nPointSize); }
	COLORREF GetGridlineColor() const { return m_pageUITasklistColors.GetGridlineColor(); }
	COLORREF GetDoneTaskColor() const { return m_pageUITasklistColors.GetDoneTaskColor(); }
	COLORREF GetFlaggedTaskColor() const { return m_pageUITasklistColors.GetFlaggedTaskColor(); }
	COLORREF GetHidePriorityNumber() const { return m_pageUITasklistColors.GetHidePriorityNumber(); }
	COLORREF GetAlternateLineColor() const { return m_pageUITasklistColors.GetAlternateLineColor(); }
	int GetCategoryColors(CCatColorArray& aColors) const { return m_pageUITasklistColors.GetCategoryColors(aColors); }

	int GetUserTools(CUserToolArray& aTools) const { return m_pageTool.GetUserTools(aTools); }
	BOOL GetUserTool(int nTool, USERTOOL& tool) const { return m_pageTool.GetUserTool(nTool, tool); } 

//	BOOL Get() const { return m_b; }

protected:
// Dialog Data
	//{{AFX_DATA(CPreferencesDlg)
	enum { IDD = IDD_PREFERENCES };
	CTreeCtrl m_tcPages;
	//}}AFX_DATA
	CPreferencesGenPage m_pageGen;
	CPreferencesFilePage m_pageFile;
	CPreferencesFile2Page m_pageFile2;
	CPreferencesExportPage m_pageExport;
	CPreferencesUIPage m_pageUI;
	CPreferencesUITasklistPage m_pageUITasklist;
	CPreferencesUITasklistColorsPage m_pageUITasklistColors;
	CPreferencesTaskPage m_pageTask;
	CPreferencesTaskCalcPage m_pageTaskCalc;
	CPreferencesTaskDefPage m_pageTaskDef;
	CPreferencesToolPage m_pageTool;
	CPreferencesShortcutsPage m_pageShortcuts;
	CPreferencesMultiUserPage m_pageMultiUser;
	CMapPtrToPtr m_mapPP2HTI;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
//	virtual void OnOK();

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnHelp();
	afx_msg void OnSelchangedPages(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnApply();
	//}}AFX_MSG
//	afx_msg void OnDestroy();
	afx_msg LRESULT OnDefPageListChange(WPARAM wp, LPARAM lp);
	afx_msg LRESULT OnColourPageCategoryChange(WPARAM wp, LPARAM lp);
	afx_msg LRESULT OnToolPageTestTool(WPARAM wp, LPARAM lp);
	afx_msg LRESULT OnGenPageClearMRU(WPARAM wp, LPARAM lp);
	afx_msg LRESULT OnControlChange(WPARAM wp, LPARAM lp);
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	DECLARE_MESSAGE_MAP()

protected:
	void AddPage(CPreferencesPageBase* pPage, UINT nIDPath);
	BOOL SetActivePage(int nPage); // override
	CString GetItemPath(HTREEITEM hti) const;
	void SynchronizeTree();
	BOOL IsPrefTab(HWND hWnd) const;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESDLG_H__C3FCC72A_6C69_49A6_930D_D5C94EC31298__INCLUDED_)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                        tInRect(point)) // found
			{
				nHit = nNumItems;
				break;
			}
		}

		if (nHit != -1 && nHit != nCurSel)
			SetCurSel(nHit);
	}
}

CWnd* CPopupListBoxCtrl::GetParent() 
{
	if (m_pParent)
		return m_pParent;

	// else
	return CListBox::GetParent();
}

void CPopupListBoxCtrl::ValidateRect(int& nX, int& nY, int& nWidth, int& nHeight)
{
	CRect rScreen;

	// validate width and height
	ValidateWidth(nWidth);
	ValidateHeight(nHeight);

	// adjust x and y to ensure fully within screen area
	CWnd::GetDesktopWindow()->GetWindowRect(rScreen); 
	
	if (nX + nWidth > rScreen.Width())
		nX = rScreen.Width() - nWidth;

	if (nY + nHeight > rScreen.Height())
		nY = rScreen.Height() - nHeight;
}

BOOL CPopupListBoxCtrl::PreTranslateMessage(MSG* pMsg) 
{
	// handle accelerator keys
	if (pMsg->message == WM_KEYDOWN || pMsg->message == WM_SYSKEYDOWN)
	{
		// try handling it ourself
		if (m_hAccelerator && ::TranslateAccelerator(GetSafeHwnd(), m_hAccelerator, pMsg))
			return TRUE;
	}
	
	return CListBox::PreTranslateMessage(pMsg);
}
