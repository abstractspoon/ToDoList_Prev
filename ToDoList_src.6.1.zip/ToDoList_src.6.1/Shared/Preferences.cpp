LICKED(IDC_OTHEREXPORT, OnOtherexport)
	ON_BN_CLICKED(IDC_AUTOSAVE, OnAutosave)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesFile2Page message handlers

BOOL CPreferencesFile2Page::OnInitDialog() 
{
	CPreferencesPageBase::OnInitDialog();

	m_mgrGroupLines.AddGroupLine(IDC_BACKUPGROUP, *this);
	m_mgrGroupLines.AddGroupLine(IDC_SAVEGROUP, *this);
	
	m_eExportFolderPath.SetFolderPrompt(CEnString(IDS_PFP_SELECTFOLDER));

	GetDlgItem(IDC_BACKUPLOCATION)->EnableWindow(m_bBackupOnSave);
	GetDlgItem(IDC_BACKUPLOCATIONLABEL)->EnableWindow(m_bBackupOnSave);

	GetDlgItem(IDC_BACKUPCOUNTLABEL)->EnableWindow(m_bBackupOnSave);
	GetDlgItem(IDC_NUMBACKUPSTOKEEP)->EnableWindow(m_bBackupOnSave);
	GetDlgItem(IDC_BACKUPCOUNTTRAIL)->EnableWindow(m_bBackupOnSave);

	GetDlgItem(IDC_AUTOSAVEFREQUENCY)->EnableWindow(m_bAutoSave);
	GetDlgItem(IDC_EXPORTTOFOLDER)->EnableWindow(m_bAutoExport);
	GetDlgItem(IDC_EXPORTFOLDER)->EnableWindow(m_bAutoExport && m_bExportToFolder);
	GetDlgItem(IDC_USESTYLESHEETFORSAVE)->EnableWindow(m_bAutoExport && !m_bOtherExport);
	GetDlgItem(IDC_SAVEEXPORTSTYLESHEET)->EnableWindow(m_bAutoExport && m_bUseStylesheetForSaveExport);
	GetDlgItem(IDC_HTMLEXPORT)->EnableWindow(m_bAutoExport);
	GetDlgItem(IDC_OTHEREXPORT)->EnableWindow(m_bAutoExport);
	GetDlgItem(IDC_OTHEREXPORTERS)->EnableWindow(m_bAutoExport && m_bOtherExport);
	GetDlgItem(IDC_EXPORTFILTERED)->EnableWindow(m_bAutoExport);

	// build the exporter format comboxbox
	ASSERT(m_pExportMgr);

	for (int nExp = 0; nExp < m_pExportMgr->GetNumExporters(); nExp++)
		m_cbOtherExporters.AddString(m_pExportMgr->GetExporterMenuText(nExp));

	m_cbOtherExporters.SetCurSel(m_nOtherExporter);

	// init the stylesheet folder to point to the resource folder
	CString sXslFolder = FileMisc::GetModuleFolder() + "Resources";
	m_eSaveExportStylesheet.SetCurrentFolder(sXslFolder);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreferencesFile2Page::LoadPreferences(const CPreferences& prefs)
{
	m_bBackupOnSave = prefs.GetProfileInt("Preferences", "BackupOnSave", TRUE);
	m_sBackupLocation = prefs.GetProfileString("Preferences", "BackupLocation", "backup");
	m_nKeepBackups = prefs.GetProfileInt("Preferences", "KeepBackups", 10);

	// saving
	m_nAutoSaveFrequency = prefs.GetProfileInt("Preferences", "AutoSaveFrequency", 1);
	m_bAutoExport = prefs.GetProfileInt("Preferences", "AutoHtmlExport", FALSE);
	m_sExportFolderPath = prefs.GetProfileString("Preferences", "ExportFolderPath", "");
	m_sSaveExportStylesheet = prefs.GetProfileString("Preferences", "SaveExportStylesheet");
	m_bAutoSaveOnSwitchTasklist = prefs.GetProfileInt("Preferences", "AutoSaveOnSwitchTasklist", FALSE);
	m_bAutoSaveOnSwitchApp = prefs.GetProfileInt("Preferences", "AutoSaveOnSwitchApp", FALSE);
	m_bOtherExport = prefs.GetProfileInt("Preferences", "OtherExport", FALSE);
	m_nOtherExporter = prefs.GetProfileInt("Preferences", "OtherExporter", 1);
	m_bExportFilteredOnly = prefs.GetProfileInt("Preferences", "ExportFilteredOnly", FALSE);

	// these are dependent on the values they control for backward compat
	m_bUseStylesheetForSaveExport = prefs.GetProfileInt("Preferences", "UseStylesheetForSaveExport", !m_sSaveExportStylesheet.IsEmpty());
	m_bExportToFolder = prefs.GetProfileInt("Preferences", "ExportToFolder", !m_sExportFolderPath.IsEmpty());

	m_sExportFolderPath.TrimLeft();
	m_sExportFolderPath.TrimRight();

	m_bAutoSave = (m_nAutoSaveFrequency > 0);

//	m_b = prefs.GetProfileInt("Preferences", "", FALSE);
}

void CPreferencesFile2Page::SavePreferences(CPreferences& prefs)
{
	// save settings
	prefs.WriteProfileInt("Preferences", "BackupOnSave", m_bBackupOnSave);
	prefs.WriteProfileString("Preferences", "BackupLocation", m_sBackupLocation);
	prefs.WriteProfileInt("Preferences", "KeepBackups", m_nKeepBackups);

	// saving
	prefs.WriteProfileInt("Preferences", "AutoSaveFrequency", m_nAutoSaveFrequency);
	prefs.WriteProfileInt("Preferences", "AutoHtmlExport", m_bAutoExport);
	prefs.WriteProfileInt("Preferences", "ExportToFolder", m_bExportToFolder);
	prefs.WriteProfileString("Preferences", "ExportFolderPath", m_sExportFolderPath);
	prefs.WriteProfileInt("Preferences", "UseStylesheetForSaveExport", m_bUseStylesheetForSaveExport);
	prefs.WriteProfileString("Preferences", "SaveExportStylesheet", m_sSaveExportStylesheet);
	prefs.WriteProfileInt("Preferences", "AutoSaveOnSwitchTasklist", m_bAutoSaveOnSwitchTasklist);
	prefs.WriteProfileInt("Preferences", "AutoSaveOnSwitchApp", m_bAutoSaveOnSwitchApp);
	prefs.WriteProfileInt("Preferences", "OtherExport", m_bOtherExport);
	prefs.WriteProfileInt("Preferences", "OtherExporter", m_nOtherExporter);
	prefs.WriteProfileInt("Preferences", "ExportFilteredOnly", m_bExportFilteredOnly);

//	prefs.WriteProfileInt("Preferences", "", m_b);
}

void CPreferencesFile2Page::OnBackuponsave() 
{
	UpdateData();

	GetDlgItem(IDC_BACKUPLOCATION)->EnableWindow(m_bBackupOnSave);
	GetDlgItem(IDC_BACKUPLOCATIONLABEL)->EnableWindow(m_bBackupOnSave);

	GetDlgItem(IDC_BACKUPCOUNTLABEL)->EnableWindow(m_bBackupOnSave);
	GetDlgItem(IDC_NUMBACKUPSTOKEEP)->EnableWindow(m_bBackupOnSave);
	GetDlgItem(IDC_BACKUPCOUNTTRAIL)->EnableWindow(m_bBackupOnSave);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesFile2Page::OnAutosave() 
{
	UpdateData();

	GetDlgItem(IDC_AUTOSAVEFREQUENCY)->EnableWindow(m_bAutoSave);

	if (m_bAutoSave && !m_nAutoSaveFrequency)
	{
		m_nAutoSaveFrequency = 5;
		m_cbAutoSave.SetCurSel(2);
	}

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesFile2Page::OnExporttofolder() 
{
	UpdateData();

	GetDlgItem(IDC_EXPORTFOLDER)->EnableWindow(m_bAutoExport && m_bExportToFolder);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesFile2Page::OnAutoexport() 
{
	UpdateData();	

	GetDlgItem(IDC_EXPORTTOFOLDER)->EnableWindow(m_bAutoExport);
	GetDlgItem(IDC_HTMLEXPORT)->EnableWindow(m_bAutoExport);
	GetDlgItem(IDC_OTHEREXPORT)->EnableWindow(m_bAutoExport);
	GetDlgItem(IDC_EXPORTFOLDER)->EnableWindow(m_bAutoExport && m_bExportToFolder);
	GetDlgItem(IDC_USESTYLESHEETFORSAVE)->EnableWindow(m_bAutoExport && !m_bOtherExport);
	GetDlgItem(IDC_SAVEEXPORTSTYLESHEET)->EnableWindow(m_bAutoExport && !m_bOtherExport && m_bUseStylesheetForSaveExport);
	GetDlgItem(IDC_OTHEREXPORTERS)->EnableWindow(m_bAutoExport && m_bOtherExport);
	GetDlgItem(IDC_EXPORTFILTERED)->EnableWindow(m_bAutoExport);

	CPreferencesPageBase::OnControlChange();
}

CString CPreferencesFile2Page::GetAutoExportFolderPath() const 
{ 
	if (m_bAutoExport && m_bExportToFolder && !m_sExportFolderPath.IsEmpty())
		return FileMisc::GetFullPath(m_sExportFolderPath, TRUE);
	else
		return "";
}

void CPreferencesFile2Page::OnUsestylesheetforsave() 
{
	UpdateData();
	
	GetDlgItem(IDC_USESTYLESHEETFORSAVE)->EnableWindow(m_bAutoExport);
	GetDlgItem(IDC_SAVEEXPORTSTYLESHEET)->EnableWindow(m_bAutoExport && m_bUseStylesheetForSaveExport);

	CPreferencesPageBase::OnControlChange();
}

void CPreferencesFile2Page::OnHtmlexport() 
{
	UpdateData();	

	GetDlgItem(IDC_USESTYLESHEETFORSAVE)->EnableWindow(m_bAutoExport && !m_bOtherExport);
	GetDlgItem(IDC_SAVEEXPORTSTYLESHEET)->EnableWindow(m_bAutoExport && !m_bOtherExport && m_bUseStylesheetForSaveExport);
	GetDlgItem(IDC_OTHEREXPORTERS)->EnableWindow(m_bAutoExport && !m_bOtherExport && m_bUseStylesheetForSaveExport);
	GetDlgItem(IDC_OTHEREXPORTERS)->EnableWindow(m_bAutoExport && m_bOtherExport);

	CPreferencesPageBase::OnControlChange();
}

void CPreferen