// RecurrenceEdit.h: interface for the CRecurringTaskEdit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEPENDENCYEDIT_H__4EE655E3_F4B1_44EA_8AAA_39DD459AD8A8__INCLUDED_)
#define AFX_DEPENDENCYEDIT_H__4EE655E3_F4B1_44EA_8AAA_39DD459AD8A8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ToDoItem.h"
#include "TDLDialog.h"
#include "TDLTaskComboBox.h"

#include "..\shared\enedit.h"
#include "..\shared\inputlistctrl.h"
#include "..\shared\tabbedcombobox.h"

//////////////////////////////////////////////////////////////////////

class CTaskFile;
class CTDCImageList;

//////////////////////////////////////////////////////////////////////

class CTDLTaskDependencyEdit : public CEnEdit  
{
public:
	CTDLTaskDependencyEdit();
	virtual ~CTDLTaskDependencyEdit();

	int GetDependencies(CTDCDependencyArray& aDepends) const;
	void SetDependencies(const CTDCDependencyArray& aDepends);
	BOOL HasDependencies() const { return (m_aDepends.GetSize() > 0); }

	void SetDependenciesAreCircular(BOOL bCircular = TRUE, COLORREF crCircular = 255);
	CString FormatDependencies(TCHAR cSep = NULL);
	
	BOOL DoEdit(const CDWordArray& aDependentTaskIDs, const CTaskFile& tasks, const CTDCImageList& ilTasks,
				BOOL bShowParentsAsFolders, BOOL bShowLeadInTimes);
	void DDX(CDataExchange* pDX, CTDCDependencyArray& aValues);

protected:
	CTDCDependencyArray m_aDepends;
	BOOL m_bNotifyingParent;
	CBrush m_brCircular;
	COLORREF m_crCircularText;

protected:
	virtual void PreSubclassWindow();
	virtual BOOL PreTranslateMessage(MSG* pMsg);

protected:
	afx_msg BOOL OnChange();
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	afx_msg void OnKillFocus(CWnd* pNewWnd);

	DECLARE_MESSAGE_MAP()

	int Parse(CTDCDependencyArray& aDepends) const;
	BOOL UpdateDepends();
	BOOL UpdateDepends(const CTDCDependencyArray& aDepends);
};

/////////////////////////////////////////////////////////////////////////////
// CTDLTaskDependencyListCtrl control

class CTDLTaskDependencyListCtrl : public CInputListCtrl
{
public:
	CTDLTaskDependencyListCtrl(const CDWordArray& aDependentTaskIDs, const CTaskFile& tasks, 
							   const CTDCImageList& ilTasks, BOOL bShowParentsAsFolders, BOOL bShowLeadInTimes);

	void SetDependencies(const CTDCDependencyArray& aDepends);
	int GetDependencies(CTDCDependencyArray& aDepends) const;

protected:
	CTDLTaskComboBox m_cbTasks;
	CDWordArray m_aDependentTaskIDs;
	BOOL m_bShowParentTasksAsFolders, m_bShowLeadInTimes;

	const CTaskFile& m_tasks;
	const CTDCImageList& m_ilTasks;

protected:
	virtual BOOL CanEditCell(int nRow, int nCol) const;
	virtual void EditCell(int nItem, int nCol, BOOL bBtnClick);
	virtual COLORREF GetItemBackColor(int nItem, int nCol, BOOL bSelected, BOOL bDropHighlighted, BOOL bWndFocus) const;
	virtual void DrawCellText(CDC* pDC, int nItem, int nCol, const CRect& rText, const CString& sText, COLORREF crText, UINT nDrawTextFlags);
	virtual void PrepareControl(CWnd& ctrl, int nRow, int nCol);

protected:
	afx_msg void OnTaskComboCancel();
	afx_msg void OnTaskComboOK();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDestroy();

	DECLARE_MESSAGE_MAP()

protected:
	void PrepareTaskCombo(int nRow);
	void RecalcColumnWidths();
	BOOL IsLocalDepends(int nRow) const;
};

/////////////////////////////////////////////////////////////////////////////
// CTDLTaskDependencyOptionDlg dialog

class CTDLTaskDependencyEditDlg : public CTDLDialog
{
public:
	CTDLTaskDependencyEditDlg(const CDWordArray& aDependentTaskIDs, const CTaskFile& tasks, 
							  const CTDCImageList& ilTasks, const CTDCDependencyArray& aDepends, 
							  BOOL bShowParentsAsFolders, BOOL bShowLeadInTimes, CWnd* pParent = NULL);

	int GetDependencies(CTDCDependencyArray& aDepends) const;

protected:
	CTDLTaskDependencyListCtrl m_lcDependencies;
	CTDCDependencyArray m_aDepends;
	BOOL m_bShowLeadInTimes;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	virtual void OnRepositionControls(int dx, int dy);

protected:
	DECLARE_MESSAGE_MAP()
};

#endif // AFX_DEPENDENCYEDIT_H__4EE655E3_F4B1_44EA_8AAA_39DD459AD8A8__INCLUDED_
