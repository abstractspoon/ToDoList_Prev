// OffsetDatesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "TDLOffsetDatesDlg.h"
#include "TDCCustomAttributeDef.h"

#include "..\Shared\Misc.h"
#include "..\Shared\DateHelper.h"

#include "..\Interfaces\Preferences.h"

/////////////////////////////////////////////////////////////////////////////

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

enum // For backwards compatibility only
{
	STARTDATE	= 0x1,
	DUEDATE		= 0x2,
	DONEDATE	= 0x4,
	REMINDER	= 0x8,
};

enum // OFFSET_BY
{
	WEEKDAYS,
	DAYS,
	WEEKS,
	MONTHS,
	YEARS,
};

/////////////////////////////////////////////////////////////////////////////

#define SELECTDEFCOMBOITEM(entry, flag, date) \
	{ if (prefs.GetProfileInt(m_sPrefsKey, entry, (dwOffsetWhat & flag))) \
		m_mapSelDates.Add(date); }

#define ADDDEFCOMBOITEM(name, date) \
	{ int nItem = CDialogHelper::AddStringT(m_lbOffsetWhat, name, date); \
		m_lbOffsetWhat.SetCheck(nItem, m_mapSelDates.Has(date)); }

/////////////////////////////////////////////////////////////////////////////
// COffsetDatesDlg dialog

CTDLOffsetDatesDlg::CTDLOffsetDatesDlg(const CTDCCustomAttribDefinitionArray& aCustAttribDefs, CWnd* pParent)
	: 
	CTDLDialog(IDD_OFFSETDATES_DIALOG, _T("OffsetDates"), pParent),
	m_dtOffsetFrom(CDateHelper::GetDate(DHD_TODAY)), // always
	m_aCustAttribDefs(aCustAttribDefs)
{
	// restore state
	CPreferences prefs;

	DWORD dwOffsetWhat = prefs.GetProfileInt(m_sPrefsKey, _T("What"), 0); // Backwards compatibility

	SELECTDEFCOMBOITEM(_T("StartDate"),	STARTDATE,	TDCD_START);
	SELECTDEFCOMBOITEM(_T("DueDate"),	DUEDATE,	TDCD_DUE);
	SELECTDEFCOMBOITEM(_T("DoneDate"),	DONEDATE,	TDCD_DONE);
	SELECTDEFCOMBOITEM(_T("Reminder"),	REMINDER,	TDCD_REMINDER);

	m_bForward = prefs.GetProfileInt(m_sPrefsKey, _T("Forward"), TRUE);
	m_nOffsetBy = prefs.GetProfileInt(m_sPrefsKey, _T("Amount"), 1);
	m_bOffsetSubtasks = prefs.GetProfileInt(m_sPrefsKey, _T("Subtasks"), TRUE);
	m_bOffsetSubtaskRefs = prefs.GetProfileInt(m_sPrefsKey, _T("SubtaskRefs"), TRUE);
	m_nOffsetByUnits = prefs.GetProfileInt(m_sPrefsKey, _T("AmountPeriod"), WEEKDAYS);
	m_bPreserveEndOfMonth = prefs.GetProfileInt(m_sPrefsKey, _T("PreserveEndOfMonth"), TRUE);

	BOOL bFromToday = prefs.GetProfileInt(m_sPrefsKey, _T("FromToday"), FALSE); // Backwards compatibility
	m_bOffsetFromDate = prefs.GetProfileInt(m_sPrefsKey, _T("FromDate"), bFromToday);
}

void CTDLOffsetDatesDlg::DoDataExchange(CDataExchange* pDX)
{
	CTDLDialog::DoDataExchange(pDX);

	DDX_CBIndex(pDX, IDC_DIRECTION, m_bForward);
	DDX_Text(pDX, IDC_BY, m_nOffsetBy);
	DDX_CBIndex(pDX, IDC_BYUNITS, m_nOffsetByUnits);
	DDX_Check(pDX, IDC_OFFSETSUBTASKS, m_bOffsetSubtasks);
	DDX_Check(pDX, IDC_OFFSETSUBTASKREFS, m_bOffsetSubtaskRefs);
	DDX_Check(pDX, IDC_OFFSETFROMDATE, m_bOffsetFromDate);
	DDX_DateTimeCtrl(pDX, IDC_OFFSETDATE, m_dtOffsetFrom);
	DDX_Check(pDX, IDC_PRESERVEENDOFMONTH, m_bPreserveEndOfMonth);
	DDX_Control(pDX, IDC_WHATLIST, m_lbOffsetWhat);
}

BEGIN_MESSAGE_MAP(CTDLOffsetDatesDlg, CTDLDialog)
	ON_WM_CTLCOLOR()
	ON_CBN_SELCHANGE(IDC_BYUNITS, OnSelchangeUnits)
	ON_BN_CLICKED(IDC_OFFSETSUBTASKS, OnClickOffsetSubtasks)
	ON_BN_CLICKED(IDC_OFFSETFROMDATE, OnClickOffsetFromDate)
	ON_CONTROL(CLBN_CHKCHANGE, IDC_WHATLIST, OnClickWhatList)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////

BOOL CTDLOffsetDatesDlg::OnInitDialog()
{
	CTDLDialog::OnInitDialog();

	// // Add default date attributes to combo
	ADDDEFCOMBOITEM(IDS_TDLBC_STARTDATE, TDCD_START);
	ADDDEFCOMBOITEM(IDS_TDLBC_DUEDATE,   TDCD_DUE);
	ADDDEFCOMBOITEM(IDS_TDLBC_DONEDATE,  TDCD_DONE);
	ADDDEFCOMBOITEM(IDS_TDLBC_REMINDER,  TDCD_REMINDER);

	// Add custom date attributes to combo
	// Note: Custom date attributes are always initially unchecked 
	int nCust = m_aCustAttribDefs.GetSize();

	while (nCust--)
	{
		if (m_aCustAttribDefs[nCust].IsDataType(TDCCA_DATE))
		{
			CString sAttrib = CEnString().Format(IDS_CUSTOMCOLUMN, m_aCustAttribDefs[nCust].sLabel);
			CDialogHelper::AddStringT(m_lbOffsetWhat, sAttrib, (TDCD_CUSTOM + nCust));
		}
	}
	
	EnableDisableControls();
	return TRUE;
}

int CTDLOffsetDatesDlg::GetOffsetWhat(CTDCDateSet& mapDates, CStringSet& mapCustAttribIDs) const
{
	mapDates.Copy(m_mapSelDates);
	mapCustAttribIDs.Copy(m_mapSelCustAttribIDs);

	return (m_mapSelDates.GetCount() + m_mapSelCustAttribIDs.GetCount());
}

int CTDLOffsetDatesDlg::GetOffsetAmount(TDC_UNITS& nUnits) const
{
	switch (m_nOffsetByUnits)
	{
	case WEEKDAYS:	nUnits = TDCU_WEEKDAYS;	break;
	case DAYS:		nUnits = TDCU_DAYS;		break;
	case WEEKS:		nUnits = TDCU_WEEKS;	break;
	case MONTHS:	nUnits = TDCU_MONTHS;	break;
	case YEARS:		nUnits = TDCU_YEARS;	break;
		
	default:
		ASSERT(0);
		nUnits = TDCU_NULL;
	}

	return (m_bForward ? m_nOffsetBy : -m_nOffsetBy);
}

BOOL CTDLOffsetDatesDlg::GetPreserveEndOfMonth() const 
{ 
	switch (m_nOffsetByUnits)
	{
	case MONTHS:
	case YEARS:
		return m_bPreserveEndOfMonth;
	}

	// else
	return FALSE; 
}

COleDateTime CTDLOffsetDatesDlg::GetOffsetFromDate() const
{
	if (m_bOffsetFromDate)
		return CDateHelper::GetDateOnly(m_dtOffsetFrom);

	return CDateHelper::NullDate();
}

void CTDLOffsetDatesDlg::UpdateCachedDateAttributes()
{
	m_mapSelDates.RemoveAll();
	m_mapSelCustAttribIDs.RemoveAll();

	int nItem = m_lbOffsetWhat.GetCount();

	while (nItem--)
	{
		if (m_lbOffsetWhat.GetCheck(nItem))
		{
			TDC_DATE nDate = (TDC_DATE)m_lbOffsetWhat.GetItemData(nItem);

			if (nDate < TDCD_CUSTOM)
				m_mapSelDates.Add(nDate);
			else
				m_mapSelCustAttribIDs.Add(m_aCustAttribDefs[nDate - TDCD_CUSTOM].sUniqueID);
		}
	}
}

void CTDLOffsetDatesDlg::OnOK()
{
	CTDLDialog::OnOK();

	// Get selected listbox items
	UpdateCachedDateAttributes();

	// save state
	CPreferences prefs;

	prefs.WriteProfileInt(m_sPrefsKey, _T("Forward"), m_bForward);
	prefs.WriteProfileInt(m_sPrefsKey, _T("Amount"), m_nOffsetBy);
	prefs.WriteProfileInt(m_sPrefsKey, _T("AmountPeriod"), m_nOffsetByUnits);
	prefs.WriteProfileInt(m_sPrefsKey, _T("Subtasks"), m_bOffsetSubtasks);
	prefs.WriteProfileInt(m_sPrefsKey, _T("SubtaskRefs"), m_bOffsetSubtaskRefs);
	prefs.WriteProfileInt(m_sPrefsKey, _T("FromDate"), m_bOffsetFromDate);
	prefs.WriteProfileInt(m_sPrefsKey, _T("PreserveEndOfMonth"), m_bPreserveEndOfMonth);
	prefs.WriteProfileInt(m_sPrefsKey, _T("StartDate"), m_mapSelDates.Has(TDCD_START));
	prefs.WriteProfileInt(m_sPrefsKey, _T("DueDate"), m_mapSelDates.Has(TDCD_DUE));
	prefs.WriteProfileInt(m_sPrefsKey, _T("DoneDate"), m_mapSelDates.Has(TDCD_DONE));
	prefs.WriteProfileInt(m_sPrefsKey, _T("Reminder"), m_mapSelDates.Has(TDCD_REMINDER));

	// Cleanup old prefs
	prefs.DeleteProfileEntry(m_sPrefsKey, _T("What"));
	prefs.DeleteProfileEntry(m_sPrefsKey, _T("FromToday"));
}

void CTDLOffsetDatesDlg::OnSelchangeUnits() 
{
	UpdateData();
	EnableDisableControls();
}

void CTDLOffsetDatesDlg::OnClickOffsetSubtasks()
{
	UpdateData();
	EnableDisableControls();
}

void CTDLOffsetDatesDlg::OnClickWhatList()
{
	UpdateCachedDateAttributes();
	EnableDisableControls();
}

void CTDLOffsetDatesDlg::OnClickOffsetFromDate()
{
	UpdateData();
	EnableDisableControls();
}

void CTDLOffsetDatesDlg::EnableDisableControls()
{
	GetDlgItem(IDC_PRESERVEENDOFMONTH)->EnableWindow((m_nOffsetByUnits == MONTHS) || (m_nOffsetByUnits == YEARS));
	GetDlgItem(IDC_OFFSETSUBTASKREFS)->EnableWindow(m_bOffsetSubtasks);
	GetDlgItem(IDC_OFFSETDATE)->EnableWindow(m_bOffsetFromDate);

	BOOL bEnableOK = (!m_mapSelDates.IsEmpty() || !m_mapSelCustAttribIDs.IsEmpty());

	GetDlgItem(IDOK)->EnableWindow(bEnableOK);
	GetDlgItem(IDC_NOATTRIBSELECTED)->ShowWindow(bEnableOK ? SW_HIDE : SW_SHOW);
}

HBRUSH CTDLOffsetDatesDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CTDLDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	if (pWnd->GetDlgCtrlID() == IDC_NOATTRIBSELECTED)
		pDC->SetTextColor(CTDLDialog::GetErrorLabelTextColor());

	return hbr;
}
