#if !defined(AFX_EXPORTDLG_H__2F5B4FD1_E968_464E_9734_AC995DB13B35__INCLUDED_)
#define AFX_EXPORTDLG_H__2F5B4FD1_E968_464E_9734_AC995DB13B35__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ExportDlg.h : header file
//
/////////////////////////////////////////////////////////////////////////////

#include "TDLTaskSelectionPage.h"
#include "TDLPrintDialog.h"
#include "TDCImportExportMgr.h"

#include "..\shared\fileedit.h"
#include "..\shared\historycombobox.h"
#include "..\shared\tabbedpropertypagehost.h"

#include "..\Interfaces\ImportExportComboBox.h"

/////////////////////////////////////////////////////////////////////////////

class CTDLExportToPage : public CCmdNotifyPropertyPage
{
public:
	CTDLExportToPage(const CTDCImportExportMgr& mgr,
					 BOOL bSingleTaskList,
					 LPCTSTR szFilePath,
					 LPCTSTR szFolderPath,
					 LPCTSTR szPrefsKey);

	CString GetFormatTypeID() const { return m_sFormatTypeID; }
	CString GetExportPath() const { return m_sExportPath; } // can be folder or file
	TDLPD_STYLE GetHtmlStyle() const { return m_nHtmlStyle; }

	BOOL GetExportAllTasklists() const { return (!m_bSingleTaskList && m_bExportAllTasklists); }
	BOOL GetExportOneFile() const { return (m_bSingleTaskList || m_bExportOneFile || m_bExportToClipboard || !m_bExportAllTasklists); }
	BOOL GetExportToClipboard() const { return m_bExportToClipboard; }

protected:
	CTDLHtmlStyleStatic m_stHtmlOptionIcon;
	CTDLHtmlStyleComboBox m_cbHtmlOptions;
	CImportExportComboBox m_cbFormat;
	CFileEdit	m_eExportPath;

	BOOL		m_bExportAllTasklists;
	BOOL		m_bExportOneFile;
	BOOL		m_bExportToClipboard;
	CString		m_sExportPath;
	CEnString	m_sPathLabel;

	BOOL m_bSingleTaskList; 
	CString m_sFolderPath, m_sFilePath, m_sMultiFilePath;
	CString m_sFormatTypeID;
	CString m_sPrefsKey;
	TDLPD_STYLE m_nHtmlStyle;

	const CTDCImportExportMgr& m_mgrImportExport;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual void OnOK();
	virtual BOOL OnInitDialog();

protected:
	afx_msg void OnSelchangeExporterFormat();
	afx_msg void OnSelchangeTasklistoptions();
	afx_msg void OnExportonefile();
	afx_msg void OnChangeExportpath();
	afx_msg void OnExportToClipboardOrPath();
	afx_msg void OnSelChangeHtmlOption();

	DECLARE_MESSAGE_MAP()

	BOOL RemoveExporterFileExtension(CString& sPathName, LPCTSTR szFormatTypeID) const;
	void EnsureExporterFileExtension(CString& sPathName, LPCTSTR szFormatTypeID, BOOL bRemovePrevExt = TRUE) const;
	CString GetExporterFileExtension(LPCTSTR szFromTypeID) const;
	BOOL WantSaveToFolder() const;
	void PreserveExportPath();
	void RestoreExportPath();
	void RefreshCtrlStates();
};

/////////////////////////////////////////////////////////////////////////////

class CTDLExportDlg : public CTDLDialog
{
public:
	CTDLExportDlg(LPCTSTR szSingleFileTitle, 
				  LPCTSTR szMultiFileTitle,
				  const CTDCImportExportMgr& mgr,
				  BOOL bSingleTaskList, 
				  BOOL bEnableSubtaskSelection,
				  BOOL bVisibleColumnsOnly, 
				  LPCTSTR szFilePath, 
				  LPCTSTR szFolderPath, 
				  const CTDCCustomAttribDefinitionArray& aAttribDefs, 
				  CWnd* pParent = NULL);

	CString GetExportTitle() const { return m_sExportTitle; }
	COleDateTime GetExportDate() const;

	CString GetFormatTypeID() const { return m_pageTo.GetFormatTypeID(); }
	CString GetExportPath() const { return m_pageTo.GetExportPath(); }
	TDLPD_STYLE GetHtmlStyle() const { return m_pageTo.GetHtmlStyle(); }
	BOOL GetExportAllTasklists() const { return m_pageTo.GetExportAllTasklists(); }
	BOOL GetExportOneFile() const { return m_pageTo.GetExportOneFile(); }
	BOOL GetExportToClipboard() const { return m_pageTo.GetExportToClipboard(); }

	const CTDLTaskSelectionPage& GetTaskSelection() const { return m_pageTaskSel; }

protected:
	CString	m_sExportTitle;
	BOOL	m_bExportDate;
	int		m_nPrevActiveTab;
	CString m_sSingleFileTitle, m_sMultiFileTitle;

	CHistoryComboBox m_cbTitle;
	CTDLExportToPage m_pageTo;
	CTDLTaskSelectionPage m_pageTaskSel;
	CTabbedPropertyPageHost m_ppHost;
	const CImportExportMgr& m_mgrImportExport;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual void OnOK();
	virtual BOOL OnInitDialog();

protected:
	afx_msg void OnSelchangeTasklistoptions();
	afx_msg void OnExportonefile();
	afx_msg void OnChangeExportpath();
	afx_msg void OnChangeExportTitle();
	afx_msg void OnExportToClipboardOrPath();

	DECLARE_MESSAGE_MAP()

	void EnableOK();
	void UpdateTitle();

};

#endif // !defined(AFX_EXPORTDLG_H__2F5B4FD1_E968_464E_9734_AC995DB13B35__INCLUDED_)
