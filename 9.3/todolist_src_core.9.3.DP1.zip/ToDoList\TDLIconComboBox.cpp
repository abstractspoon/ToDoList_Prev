// tdliconcombobox.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "tdliconcombobox.h"
#include "tdcimagelist.h"
#include "tdcstruct.h"
#include "TDLTaskIconDlg.h"

#include "..\Shared\GraphicsMisc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

const int ICON_SIZE = GraphicsMisc::ScaleByDPIFactor(16);

/////////////////////////////////////////////////////////////////////////////
// CTDLIconComboBox

CTDLIconComboBox::CTDLIconComboBox(const CTDCImageList& ilImages, BOOL bMultiSel, BOOL bFilter)
	:
	CEnCheckComboBox(bMultiSel, (bFilter ? IDS_TDC_NONE : 0), (bFilter ? IDS_TDC_ANY : 0)),
	m_ilImages(ilImages)
{
}

CTDLIconComboBox::~CTDLIconComboBox()
{
}

IMPLEMENT_DYNAMIC(CTDLIconComboBox, CEnCheckComboBox)

BEGIN_MESSAGE_MAP(CTDLIconComboBox, CEnCheckComboBox)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTDLIconComboBox message handlers

void CTDLIconComboBox::DrawItemText(CDC& dc, const CRect& rect, int nItem, UINT nItemState,
									DWORD dwItemData, const CString& sItem, BOOL bList, COLORREF crText)
{
	CRect rImage(rect);
	CStringArray aImages;
	int nNumImage = 0;
	
	if (bList)
	{
		if (m_bMultiSel)
		{
			// draw checkbox with no text
			DrawCheckBox(dc, rect, nItem, nItemState, dwItemData, FALSE);

			// update image rect
			rImage.left += CHECKBOX_SIZE + 2;
		}

		aImages.Add(sItem);
		nNumImage = 1;
	}
	else // static text portion
	{
		if (m_bMultiSel)
		{
			nNumImage = Misc::Split(m_sText, aImages, _T(""), HasItemNone());
		}
		else if (!sItem.IsEmpty())
		{
			aImages.Add(sItem);
			nNumImage = 1;
		}
	}

	if (nNumImage > 0)
	{
		CString sListSep = Misc::GetListSeparator();
		BOOL bWantDrawName = (bList || (nNumImage == 1));

		for (int nImg = 0; nImg < nNumImage; nImg++)
		{
			CString sImage, sName;

			if (TDCCUSTOMATTRIBUTEDEFINITION::DecodeImageTag(aImages[nImg], sImage, sName))
			{
				if (GraphicsMisc::DrawCentred(&dc, 
											  m_ilImages, 
											  m_ilImages.GetImageIndex(sImage),
											  rImage, 
											  FALSE, 
											  TRUE)) // vertically centred
 				{
					rImage.left += (ICON_SIZE + 2);
				}

				// draw optional text bypassing base class checkbox drawing
				if (bWantDrawName)
				{
					if (!bList && sName.IsEmpty()) // static portion
					{
						// Search for the item in the droplist because
						// that will definitely contain the user icon names
						int nListItem = FindString(-1, TDCCUSTOMATTRIBUTEDEFINITION::EncodeImageTag(sImage, _T("")));

						if (nListItem != -1)
							TDCCUSTOMATTRIBUTEDEFINITION::DecodeImageTag(GetItemText(nListItem), sImage, sName);
					}

					if (sName.IsEmpty())
						sName = CTDLTaskIconDlg::GetUserIconName(sImage);

					if (!sName.IsEmpty())
					{
						rImage.left += 2;
						CAutoComboBox::DrawItemText(dc, rImage, nItem, nItemState, dwItemData, sName, bList, crText);
					}
				}
			}
			else if (bList)
			{
				// Draw none/any
				CEnCheckComboBox::DrawItemText(dc, rect, nItem, nItemState, dwItemData, sItem, bList, crText);
			}
			else
			{
				ASSERT(nImg == 0);
				ASSERT(HasItemNone());

				CAutoComboBox::DrawItemText(dc, rImage, nItem, nItemState, dwItemData, m_sNone, bList, crText);
				rImage.left += (dc.GetTextExtent(m_sNone).cx + 2);

				if (nNumImage > 1)
				{
					CAutoComboBox::DrawItemText(dc, rImage, nItem, nItemState, dwItemData, sListSep, bList, crText);
					rImage.left += (dc.GetTextExtent(sListSep).cx);
				}
			}
		}
	}
	else if (!bList)
	{
		CEnCheckComboBox::DrawItemText(dc, rect, nItem, nItemState, dwItemData, sItem, bList, crText);
	}
}

int CTDLIconComboBox::SelectImage(const CString& sImage)
{
	CString sPartial = TDCCUSTOMATTRIBUTEDEFINITION::EncodeImageTag(sImage, _T(""));

	return CComboBox::SelectString(-1, sPartial);
}

CString CTDLIconComboBox::GetSelectedImage() const
{
	CString sItem = GetItemText(GetCurSel());
	
	if (sItem.IsEmpty())
		GetWindowText(sItem);

	if (!sItem.IsEmpty())
	{
		CString sImage, sName;
		TDCCUSTOMATTRIBUTEDEFINITION::DecodeImageTag(sItem, sImage, sName);
		
		return sImage;
	}

	return sItem; // empty
}

int CTDLIconComboBox::GetChecked(CStringArray& aItems, CCB_CHECKSTATE nCheck) const
{
	CStringArray aTemp;
	CEnCheckComboBox::GetChecked(aTemp, nCheck);

	return DecodeImageTags(aTemp, aItems);
}

int CTDLIconComboBox::GetChecked(CStringArray& aChecked, CStringArray& aMixed) const
{
	CStringArray aTemp1, aTemp2;
	CEnCheckComboBox::GetChecked(aTemp1, aTemp2);

	DecodeImageTags(aTemp2, aMixed);

	return DecodeImageTags(aTemp1, aChecked);
}

BOOL CTDLIconComboBox::SetChecked(const CStringArray& aChecked, const CStringArray& aMixed)
{
	CStringArray aEncodedChecked, aEncodedMixed;

	EncodeImageTags(aChecked, aEncodedChecked, FALSE);
	EncodeImageTags(aMixed, aEncodedMixed, FALSE);

	return CEnCheckComboBox::SetChecked(aEncodedChecked, aEncodedMixed);
}

int CTDLIconComboBox::SetStrings(const CStringArray& aItems)
{
	CStringArray aEncodedItems;
	EncodeImageTags(aItems, aEncodedItems, TRUE);

	return CEnCheckComboBox::SetStrings(aEncodedItems);
}

int CTDLIconComboBox::EncodeImageTags(const CStringArray& aImages, CStringArray& aEncodedTags, BOOL bAdding) const
{
	int nNumItems = aImages.GetSize();
	aEncodedTags.RemoveAll();

	for (int nImg = 0; nImg < nNumItems; nImg++)
	{
		CString sImage;

		if (!aImages[nImg].IsEmpty())
		{
			sImage = TDCCUSTOMATTRIBUTEDEFINITION::EncodeImageTag(aImages[nImg], _T(""));

			if (!bAdding)
			{
				// Find the full string corresponding to this partial string
				int nFull = FindString(-1, sImage);

				if (nFull == -1)
				{
					ASSERT(0);
					continue;
				}

				CString sFullImage = GetItemText(nFull);

				if (sFullImage.Find(sImage) != 0)
				{
					ASSERT(0);
					continue;
				}

				sImage = sFullImage;
			}
		}

		aEncodedTags.Add(sImage);
	}

	ASSERT(aEncodedTags.GetSize() == aImages.GetSize());
	return aEncodedTags.GetSize();
}

int CTDLIconComboBox::DecodeImageTags(const CStringArray& aImages, CStringArray& aDecodedTags) const
{
	int nNumItems = aImages.GetSize();
	aDecodedTags.RemoveAll();

	for (int nImg = 0; nImg < nNumItems; nImg++)
	{
		CString sImage, sUnused;

		if (!aImages[nImg].IsEmpty())
			TDCCUSTOMATTRIBUTEDEFINITION::DecodeImageTag(aImages[nImg], sImage, sUnused);

		aDecodedTags.Add(sImage);
	}

	ASSERT(aDecodedTags.GetSize() == aImages.GetSize());
	return aDecodedTags.GetSize();
}

int CTDLIconComboBox::GetExtraListboxWidth() const
{
	return (CEnCheckComboBox::GetExtraListboxWidth() + ICON_SIZE + 2);
}

int CTDLIconComboBox::CalcMinItemHeight(BOOL bList) const
{
	int nMinHeight = CEnCheckComboBox::CalcMinItemHeight(bList);

	if (bList)
		nMinHeight = max(nMinHeight, ICON_SIZE);

	return nMinHeight;
}
