// TaskSelectionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "TDLTaskSelectionPage.h"
#include "ToDoCtrl.h"
#include "tdcmapping.h"

#include "..\shared\misc.h"
#include "..\shared\dialoghelper.h"

#include "..\Interfaces\Preferences.h"

/////////////////////////////////////////////////////////////////////////////

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTDLTaskSelectionPage dialog

CTDLTaskSelectionPage::CTDLTaskSelectionPage(const CTDCCustomAttribDefinitionArray& aAttribDefs,
									 LPCTSTR szRegKey, 
									 BOOL bEnableSubtaskSelection,
									 BOOL bVisibleColumnsOnly) 
	: 
	CCmdNotifyPropertyPage(IDD_TASKSELECTION_PAGE),
	m_lbAttribList(aAttribDefs),
	m_sRegKey(szRegKey), 
	m_bEnableSubtaskSelection(bEnableSubtaskSelection)
{
	CPreferences prefs;

	m_bCompletedTasks = prefs.GetProfileInt(m_sRegKey, _T("CompletedTasks"), TRUE);
	m_bIncompleteTasks = prefs.GetProfileInt(m_sRegKey, _T("IncompleteTasks"), TRUE);
	m_nWhatTasks = prefs.GetProfileInt(m_sRegKey, _T("WhatTasks"), TSDT_FILTERED);
	m_bSelectedSubtasks = (prefs.GetProfileInt(m_sRegKey, _T("SelectedSubtasks"), TRUE) && m_bEnableSubtaskSelection);
	m_bSelectedParentTask = prefs.GetProfileInt(m_sRegKey, _T("SelectedParentTask"), FALSE);
	m_bIncludeComments = prefs.GetProfileInt(m_sRegKey, _T("IncludeCommentsWithVisible"), FALSE);

	if (bVisibleColumnsOnly)
		m_nAttribOption = TSDA_VISIBLE;
	else
		m_nAttribOption = prefs.GetProfileInt(m_sRegKey, _T("AttributeOption"), TSDA_ALL);
	
	// Manual attribute selection
	CString sGroup = m_sRegKey + _T("\\AttribVisibility");

	if (prefs.HasProfileSection(sGroup))
	{
		// Default attributes
		CTDCAttributeMap mapAttrib;
		int nAtt = prefs.GetProfileInt(sGroup, _T("Count"), 0);

		while (nAtt--)
		{
			CString sKey = Misc::MakeKey(_T("att%d"), nAtt);
			TDC_ATTRIBUTE nAttribID = prefs.GetProfileEnum(sGroup, sKey, TDCA_NONE);
			ASSERT(nAttribID != TDCA_NONE);

			mapAttrib.Add(nAttribID);
		}

		// Custom attributes
		CStringSet mapCustAttribIDs;
		nAtt = prefs.GetProfileInt(sGroup, _T("CustomCount"), 0);

		while (nAtt--)
		{
			CString sKey = Misc::MakeKey(_T("custom%d"), nAtt);
			CString sCustAttribID = prefs.GetProfileString(sGroup, sKey, 0);

			mapCustAttribIDs.Add(sCustAttribID);
		}

		m_lbAttribList.SetSelectedAttributes(mapAttrib, mapCustAttribIDs);
	}
}

void CTDLTaskSelectionPage::DoDataExchange(CDataExchange* pDX)
{
	CCmdNotifyPropertyPage::DoDataExchange(pDX);

	DDX_Radio(pDX, IDC_ALLTASKS, m_nWhatTasks);
	DDX_Check(pDX, IDC_INCLUDEPARENTTASK, m_bSelectedParentTask);
	DDX_Control(pDX, IDC_CUSTOMATTRIBLIST, m_lbAttribList);
	DDX_Check(pDX, IDC_INCLUDESUBTASKS, m_bSelectedSubtasks);
	DDX_Check(pDX, IDC_INCLUDECOMMENTS, m_bIncludeComments);
	DDX_Check(pDX, IDC_INCLUDEDONE, m_bCompletedTasks);
	DDX_Check(pDX, IDC_INCLUDENOTDONE, m_bIncompleteTasks);

	// Because our radio buttons are out of sequence 
	// (for backwards compatibility) we use a custom handler
	static UINT RADIO_BTNS[] = { IDC_ALLATTRIB, IDC_VISIBLEATTRIB, IDC_CUSTOMATTRIB, IDC_TITLECOMMENTS };
	static int NUM_RADIO_BTNS = sizeof(RADIO_BTNS) / sizeof(RADIO_BTNS[0]);

	CDialogHelper::DDX_Radio(pDX, RADIO_BTNS, NUM_RADIO_BTNS, m_nAttribOption);
}


BEGIN_MESSAGE_MAP(CTDLTaskSelectionPage, CCmdNotifyPropertyPage)
	ON_WM_DESTROY()
	ON_WM_ENABLE()
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_ALLATTRIB, OnChangeAttribOption)
	ON_BN_CLICKED(IDC_CUSTOMATTRIB, OnChangeAttribOption)
	ON_BN_CLICKED(IDC_VISIBLEATTRIB, OnChangeAttribOption)
	ON_BN_CLICKED(IDC_ALLTASKS, OnChangetasksOption)
	ON_BN_CLICKED(IDC_FILTERTASKS, OnChangetasksOption)
	ON_BN_CLICKED(IDC_INCLUDEDONE, OnIncludeDone)
	ON_BN_CLICKED(IDC_SELTASK, OnChangetasksOption)
	ON_BN_CLICKED(IDC_INCLUDENOTDONE, OnIncludeNotDone)
	ON_BN_CLICKED(IDC_CLEARALLATTRIB, OnClearUserAttribSelection)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////

BOOL CTDLTaskSelectionPage::OnInitDialog() 
{
	CCmdNotifyPropertyPage::OnInitDialog();
	
	EnableDisableControls();

	return TRUE;
}

void CTDLTaskSelectionPage::OnOK() 
{
	CCmdNotifyPropertyPage::OnOK();
	
	// Save state
	CPreferences prefs;

	prefs.WriteProfileInt(m_sRegKey, _T("CompletedTasks"), m_bCompletedTasks);
	prefs.WriteProfileInt(m_sRegKey, _T("IncompleteTasks"), m_bIncompleteTasks);
	prefs.WriteProfileInt(m_sRegKey, _T("WhatTasks"), m_nWhatTasks);
	prefs.WriteProfileInt(m_sRegKey, _T("AttributeOption"), m_nAttribOption);
	prefs.WriteProfileInt(m_sRegKey, _T("SelectedSubtasks"), m_bSelectedSubtasks);
	prefs.WriteProfileInt(m_sRegKey, _T("SelectedParentTask"), m_bSelectedParentTask);
	prefs.WriteProfileInt(m_sRegKey, _T("IncludeCommentsWithVisible"), m_bIncludeComments);

	CString sGroup = m_sRegKey + _T("\\AttribVisibility");
	CTDCAttributeMap mapAttrib;
	CStringSet mapCustomAttribIDs;

	m_lbAttribList.GetSelectedAttributes(mapAttrib, mapCustomAttribIDs);

	// Default attributes
	prefs.WriteProfileInt(sGroup, _T("Count"), mapAttrib.GetCount());

	int nItem = 0;
	POSITION pos = mapAttrib.GetStartPosition();

	while (pos)
	{
		CString sKey = Misc::MakeKey(_T("att%d"), nItem++);
		prefs.WriteProfileInt(sGroup, sKey, mapAttrib.GetNext(pos));
	}

	// Custom Attributes
	prefs.WriteProfileInt(sGroup, _T("CustomCount"), mapCustomAttribIDs.GetCount());

	nItem = 0;
	pos = mapCustomAttribIDs.GetStartPosition();

	while (pos)
	{
		CString sKey = Misc::MakeKey(_T("custom%d"), nItem++);
		prefs.WriteProfileString(sGroup, sKey, mapCustomAttribIDs.GetNext(pos));
	}
}

void CTDLTaskSelectionPage::OnChangetasksOption() 
{
	UpdateData();
	
	BOOL bWantSelTasks = GetWantSelectedTasks();
	
	GetDlgItem(IDC_INCLUDEDONE)->EnableWindow(!bWantSelTasks);
	GetDlgItem(IDC_INCLUDENOTDONE)->EnableWindow(!bWantSelTasks);
	
	GetDlgItem(IDC_INCLUDESUBTASKS)->EnableWindow(bWantSelTasks);
	GetDlgItem(IDC_INCLUDEPARENTTASK)->EnableWindow(bWantSelTasks);
	
	GetParent()->SendMessage(WM_TASKSELDLG_CHANGE);
}

void CTDLTaskSelectionPage::OnIncludeDone() 
{
	UpdateData();
	
	// prevent the user unchecking both tick boxes
	if (!m_bCompletedTasks && !m_bIncompleteTasks)
	{
		m_bIncompleteTasks = TRUE;
		UpdateData(FALSE);
	}
	
	GetParent()->SendMessage(WM_TASKSELDLG_CHANGE);
}
void CTDLTaskSelectionPage::OnIncludeNotDone() 
{
	UpdateData();
	
	// prevent the user unchecking both tick boxes
	if (!m_bCompletedTasks && !m_bIncompleteTasks)
	{
		m_bCompletedTasks = TRUE;
		UpdateData(FALSE);
	}
	
	GetParent()->SendMessage(WM_TASKSELDLG_CHANGE);
}

void CTDLTaskSelectionPage::EnableDisableControls()
{
	GetDlgItem(IDC_CLEARALLATTRIB)->EnableWindow(m_nAttribOption == TSDA_USER);
	GetDlgItem(IDC_CUSTOMATTRIBLIST)->EnableWindow(m_nAttribOption == TSDA_USER);
	GetDlgItem(IDC_INCLUDECOMMENTS)->EnableWindow(m_nAttribOption == TSDA_VISIBLE);

	BOOL bWantSelTasks = GetWantSelectedTasks();
	
	GetDlgItem(IDC_INCLUDEDONE)->EnableWindow(!bWantSelTasks);
	GetDlgItem(IDC_INCLUDENOTDONE)->EnableWindow(!bWantSelTasks);
	GetDlgItem(IDC_INCLUDEPARENTTASK)->EnableWindow(bWantSelTasks);

	GetDlgItem(IDC_INCLUDESUBTASKS)->EnableWindow(bWantSelTasks && m_bEnableSubtaskSelection);
	GetDlgItem(IDC_INCLUDESUBTASKS)->ShowWindow(m_bEnableSubtaskSelection ? SW_SHOW : SW_HIDE);
}

void CTDLTaskSelectionPage::SetWantWhatTasks(TSD_TASKS nWhat)
{
	m_nWhatTasks = nWhat;

	if (GetSafeHwnd())
	{
		UpdateData(FALSE);
		EnableDisableControls();
	}
}

void CTDLTaskSelectionPage::OnChangeAttribOption() 
{
	UpdateData();
	EnableDisableControls();
}

void CTDLTaskSelectionPage::OnClearUserAttribSelection()
{
	m_lbAttribList.SetAllChecked(FALSE);
}

int CTDLTaskSelectionPage::GetSelectedAttributes(const CToDoCtrl& tdc, CTDCAttributeMap& mapAttrib) const
{
	mapAttrib.RemoveAll();

	// attributes to export
	switch (m_nAttribOption)
	{
	case TSDA_ALL:
		mapAttrib.Add(TDCA_ALL);
		break;

	case TSDA_TITLECOMMENTS:
		mapAttrib.Add(TDCA_TASKNAME);
		mapAttrib.Add(TDCA_COMMENTS);
		break;

	case TSDA_VISIBLE:
		{
			// visible columns
			TDC::MapColumnsToAttributes(tdc.GetVisibleColumns(), mapAttrib);

			mapAttrib.Add(TDCA_TASKNAME);
			mapAttrib.Add(TDCA_CUSTOMATTRIB_ALL);

			if (m_bIncludeComments)
				mapAttrib.Add(TDCA_COMMENTS);
		}
		break;

	case TSDA_USER:
		m_lbAttribList.GetSelectedAttributes(mapAttrib);
		mapAttrib.Add(TDCA_TASKNAME);
		break;
	}

	return mapAttrib.GetCount();
}

void CTDLTaskSelectionPage::OnEnable(BOOL bEnable)
{
	CDialogHelper::EnableAllCtrls(this, bEnable);

	if (bEnable)
		EnableDisableControls();
}

BOOL CTDLTaskSelectionPage::GetWantSelectedSubtasks() const
{
	return (GetWantSelectedTasks() && m_bSelectedSubtasks);
}

BOOL CTDLTaskSelectionPage::GetWantSelectedParentTask() const
{
	return (GetWantSelectedTasks() && m_bSelectedParentTask);
}

BOOL CTDLTaskSelectionPage::GetWantCompletedTasksOnly() const
{
	return (!GetWantSelectedTasks() && m_bCompletedTasks && !m_bIncompleteTasks);
}

BOOL CTDLTaskSelectionPage::GetWantIncompleteTasksOnly() const
{
	return (!GetWantSelectedTasks() && !m_bCompletedTasks && m_bIncompleteTasks);
}
