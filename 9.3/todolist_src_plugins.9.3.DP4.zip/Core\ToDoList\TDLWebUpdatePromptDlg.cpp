// TDLWebUpdateDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "TDLWebUpdatePromptDlg.h"
#include "TDCWebUpdateScript.h"

#include "..\Shared\EnString.h"
#include "..\Shared\misc.h"
#include "..\Shared\webmisc.h"
#include "..\Shared\DialogHelper.h"
#include "..\Shared\GraphicsMisc.h"
#include "..\Shared\icon.h"

#include "..\3rdparty\XNamedColors.h"

#include <WININET.H>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

#define PSH_WIZARD97_EX 0x01000000

/////////////////////////////////////////////////////////////////////////////
// CTDLWebUpdatePromptDlg

IMPLEMENT_DYNAMIC(CTDLWebUpdatePromptDlg, CTDLWizard)

CTDLWebUpdatePromptDlg::CTDLWebUpdatePromptDlg(LPCTSTR szExeVer, const CStringArray& aChanges) 
	: 
	CTDLWizard(IDS_WEBUPDATE_TITLE, IDI_TDLUPDATE)
{
	m_page.SetInfo(szExeVer, aChanges);
	AddPage(&m_page);

	EnableProgressBar(FALSE);
}

CTDLWebUpdatePromptDlg::~CTDLWebUpdatePromptDlg()
{
}

BEGIN_MESSAGE_MAP(CTDLWebUpdatePromptDlg, CTDLWizard)
END_MESSAGE_MAP()

// ---------------------------------------------------------------

TDL_WEBUPDATE_CHECK CTDLWebUpdatePromptDlg::CheckForUpdates()
{
	if (!WebMisc::IsOnline())
		return TDLWUC_NOTCONNECTED;

	// download the update script to temp file
	CTDCWebUpdateScript script;
	CWaitCursor wait;

	// first for pre-release update
	BOOL bPreReleaseUpdates = script.CheckForPreReleaseUpdates();
	BOOL bUpdates = (bPreReleaseUpdates || script.CheckForUpdates());

	if (bUpdates)
	{
		CString sNewExeVer, sNewDisplayVer;
		CStringArray aUpdates;

		VERIFY(script.GetScriptDetails(sNewExeVer, sNewDisplayVer, aUpdates));
		ASSERT(!sNewDisplayVer.IsEmpty());

		// prompt user to update to new version
		CTDLWebUpdatePromptDlg dialog(sNewDisplayVer, aUpdates);
		
		if (dialog.DoModal() != ID_WIZFINISH)
			return TDLWUC_CANCELLED;
		
		return (bPreReleaseUpdates ? TDLWUC_WANTPRERELEASEUPDATE : TDLWUC_WANTUPDATE);
	}
	
	// else
	return TDLWUC_NOUPDATES;
} 

#ifdef _DEBUG
void CTDLWebUpdatePromptDlg::ShowDialog()
{
	CTDCWebUpdateScript script;

	if (!script.CheckForPreReleaseUpdates())
		script.CheckForUpdates();
	
	CString sNewExeVer, sNewDisplayVer;
	CStringArray aUpdates;

	if (script.GetScriptDetails(sNewExeVer, sNewDisplayVer, aUpdates))
		ASSERT(!sNewDisplayVer.IsEmpty());

	CTDLWebUpdatePromptDlg(sNewDisplayVer, aUpdates).DoModal();
}
#endif

BOOL CTDLWebUpdatePromptDlg::OnInitDialog() 
{
	CTDLWizard::OnInitDialog();
	
	SetWizardButtons(PSWIZB_FINISH);

	// hide back button
	GetDlgItem(ID_WIZBACK)->ShowWindow(SW_HIDE);

	// rename finish button
	SetDlgItemText(ID_WIZFINISH, CEnString(IDS_YES));
	GetDlgItem(ID_WIZFINISH)->SetFocus();

	// rename cancel button
	SetDlgItemText(IDCANCEL, CEnString(IDS_NO));

	// setup social media toolbar
	if (m_toolbar.CreateEx(this, (TBSTYLE_FLAT, WS_CHILD | CBRS_TOOLTIPS | WS_VISIBLE)))
	{
		VERIFY(m_toolbar.LoadToolBar(IDR_SOCIAL_TOOLBAR, IDB_SOCIAL_TOOLBAR, colorMagenta));
		VERIFY(m_tbHelper.Initialize(&m_toolbar));

		CRect rToolbar = CDialogHelper::GetCtrlRect(this, IDCANCEL);

		rToolbar.left = 10;
		rToolbar.right = (rToolbar.left + m_toolbar.GetMinReqLength());

		m_toolbar.MoveWindow(rToolbar, FALSE);
	}
	
	return FALSE;
}

BOOL CTDLWebUpdatePromptDlg::OnCommand(WPARAM wParam, LPARAM lParam)
{
	// Forward toolbar commands to app window
	switch (LOWORD(wParam))
	{
	case ID_HELP_WIKI:
		AfxGetApp()->WinHelp(IDD_WEBUPDATE_PROMPT_PAGE);
		return TRUE;

	case ID_HELP_FORUM:
		return AfxGetMainWnd()->SendMessage(WM_COMMAND, wParam, lParam);
	}
	
	// else
	return CTDLWizard::OnCommand(wParam, lParam);
}

/////////////////////////////////////////////////////////////////////////////
// CTDLWebUpdatePromptPage dialog

IMPLEMENT_DYNCREATE(CTDLWebUpdatePromptPage, CTDLWizardPage)

CTDLWebUpdatePromptPage::CTDLWebUpdatePromptPage()
	: 
	CTDLWizardPage(IDD_WEBUPDATE_PROMPT_PAGE)
{
}

void CTDLWebUpdatePromptPage::DoDataExchange(CDataExchange* pDX)
{
	CTDLWizardPage::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_CHANGES, m_sChanges);
}

BEGIN_MESSAGE_MAP(CTDLWebUpdatePromptPage, CDialog)
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()

// ---------------------------------------------------------------

void CTDLWebUpdatePromptPage::SetInfo(LPCTSTR szExeVer, const CStringArray& aChanges)
{
	m_strHeaderTitle.Format(CEnString(IDS_WEBUPDATE_PROMPTHEADER), Misc::GetUserName(), szExeVer);
	m_strHeaderSubTitle = "\n" + CEnString(IDS_WEBUPDATE_PROMPT);

	m_sChanges = Misc::FormatArrayAsNumberedList(aChanges, _T(".\t"));

	// replace '\n' with '\r\n'
	m_sChanges.Replace(_T("\n"), _T("\r\n"));
}

BOOL CTDLWebUpdatePromptPage::OnInitDialog() 
{
	CTDLWizardPage::OnInitDialog();

	GetDlgItem(IDC_LABEL)->SetFocus();
	return FALSE;
}

HBRUSH CTDLWebUpdatePromptPage::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hBr =  CTDLWizardPage::OnCtlColor(pDC, pWnd, nCtlColor);
	
	if (pWnd->GetDlgCtrlID() == IDC_CHANGES)
	{
		pDC->SetBkColor(GetSysColor(COLOR_WINDOW));
		hBr = GetSysColorBrush(COLOR_WINDOW);
	}
	
	return hBr;
}

BOOL CTDLWebUpdatePromptPage::OnSetActive() 
{
	CTDLWizardPage::OnSetActive();

	UINT nTabStop = 16;
	GetDlgItem(IDC_CHANGES)->SendMessage(EM_SETTABSTOPS, 1, (LPARAM)&nTabStop);
	
	return TRUE;
}
