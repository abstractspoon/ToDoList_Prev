// WelcomeWizard.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "tdcStruct.h"
#include "TDLWelcomeWizard.h"

#include "..\shared\dialoghelper.h"
#include "..\shared\misc.h"
#include "..\shared\graphicsmisc.h"
#include "..\shared\filemisc.h"
#include "..\Shared\enstring.h"
#include "..\Shared\Localizer.h"
#include "..\Shared\icon.h"

#include "..\3rdParty\OSVersion.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

const int PSH_WIZARD97_EX		= 0x01000000;
const int IDC_TOPDIVIDERID		= 0x3027;
const int PROGRESS_INCREMENT	= 10;
const int PROGRESS_HEIGHT		= GraphicsMisc::ScaleByDPIFactor(3);
const int TIMERID_ANIMATEBACK	= 1;

/////////////////////////////////////////////////////////////////////////////
// CWelcomeWizard

IMPLEMENT_DYNAMIC(CTDLWelcomeWizard, CTDLWizard)

CTDLWelcomeWizard::CTDLWelcomeWizard(LPCTSTR szAppVer) 
	: 
	CTDLWizard(Misc::Format(_T("%s - %s"), CEnString(IDS_SETUP_TITLE), szAppVer), 
			   IDR_MAINFRAME,
			   IDD_WELCOME_PAGE1)
{
	AddPage(&m_page1);
	AddPage(&m_page2);
	AddPage(&m_page3);
}

CTDLWelcomeWizard::~CTDLWelcomeWizard()
{
}

BEGIN_MESSAGE_MAP(CTDLWelcomeWizard, CTDLWizard)
END_MESSAGE_MAP()

// ---------------------------------------------------------------------

void CTDLWelcomeWizard::GetColumnVisibility(TDCCOLEDITFILTERVISIBILITY& vis) const 
{ 
	m_page2.GetColumnVisibility(vis); 

	if (m_page3.GetHideAttributes())
		vis.SetShowFields(TDLSA_ASCOLUMN);
	else
		vis.SetShowFields(TDLSA_ALL);
}

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage1 property page

IMPLEMENT_DYNCREATE(CTDLWelcomePage1, CTDLWizardPage)

CTDLWelcomePage1::CTDLWelcomePage1() 
	: 
	CTDLWizardPage(IDD_WELCOME_PAGE1),
	m_bUseIniFile(1),
	m_bShareTasklists(0)
{
	m_strHeaderTitle = CEnString(IDS_WIZ_INTRO_HEADER);
	m_strHeaderSubTitle = "\n" + CEnString(IDS_WIZ_INTRO_SUBHEADER);
}

CTDLWelcomePage1::~CTDLWelcomePage1()
{
}

void CTDLWelcomePage1::DoDataExchange(CDataExchange* pDX)
{
	CTDLWizardPage::DoDataExchange(pDX);

	DDX_Radio(pDX, IDC_NOSHARE, m_bShareTasklists);
	DDX_Radio(pDX, IDC_REGISTRY, m_bUseIniFile);
}

BEGIN_MESSAGE_MAP(CTDLWelcomePage1, CTDLWizardPage)
END_MESSAGE_MAP()

// ---------------------------------------------------------------------

BOOL CTDLWelcomePage1::OnInitDialog() 
{
	CTDLWizardPage::OnInitDialog();

	GetDlgItem(IDC_REGISTRY)->EnableWindow(COSVersion() != OSV_LINUX);

	return TRUE;
}

BOOL CTDLWelcomePage1::OnSetActive() 
{
	// disable back button
	SetWizardButtons(PSWIZB_NEXT);
	
	return CTDLWizardPage::OnSetActive();
}

////////////////////////////////////////////////////////////////////////////
// CWelcomePage2 property page

IMPLEMENT_DYNCREATE(CTDLWelcomePage2, CTDLWizardPage)

CTDLWelcomePage2::CTDLWelcomePage2() 
	: 
	CTDLWizardPage(IDD_WELCOME_PAGE2)
{
	m_strHeaderTitle = CEnString(IDS_WIZ_INTRO_HEADER);
	m_strHeaderSubTitle = "\n" + CEnString(IDS_WIZ_INTRO_SUBHEADER);
}

CTDLWelcomePage2::~CTDLWelcomePage2()
{
}

void CTDLWelcomePage2::DoDataExchange(CDataExchange* pDX)
{
	CTDLWizardPage::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_COLUMNLIST, m_lbColumns);
}

BEGIN_MESSAGE_MAP(CTDLWelcomePage2, CTDLWizardPage)
END_MESSAGE_MAP()

// ---------------------------------------------------------------------

BOOL CTDLWelcomePage2::OnInitDialog() 
{
	return CTDLWizardPage::OnInitDialog();
}

BOOL CTDLWelcomePage2::OnSetActive() 
{
	SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);
	
	return CTDLWizardPage::OnSetActive();
}

void CTDLWelcomePage2::GetColumnVisibility(TDCCOLEDITFILTERVISIBILITY& vis) const 
{ 
	CTDCColumnIDArray aColumns;
	int nCol = m_lbColumns.GetVisibleColumns(aColumns); 

	CTDCColumnIDMap mapCols;
	
	while (nCol--)
		mapCols.Add(aColumns[nCol]);

	vis.Clear();
	vis.SetVisibleColumns(mapCols);
}

/////////////////////////////////////////////////////////////////////////////
// CWelcomePage3 property page

IMPLEMENT_DYNCREATE(CTDLWelcomePage3, CTDLWizardPage)

CTDLWelcomePage3::CTDLWelcomePage3() 
	: 
	CTDLWizardPage(IDD_WELCOME_PAGE3),
	m_eSampleTasklist(FES_RELATIVEPATHS)
{
	m_bHideAttrib = 1;
	m_bViewSample = 1;

	m_eSampleTasklist.SetFilter(CEnString(IDS_TDLFILEFILTER));
	m_eSampleTasklist.SetCurrentFolder(FileMisc::GetAppFolder());
	m_sSampleTaskList = _T(".\\Resources\\Examples\\Introduction.tdl");
	
	m_strHeaderTitle = CEnString(IDS_WIZ_INTRO_HEADER);
	m_strHeaderSubTitle = "\n" + CEnString(IDS_WIZ_INTRO_SUBHEADER);
}

CTDLWelcomePage3::~CTDLWelcomePage3()
{
}

void CTDLWelcomePage3::DoDataExchange(CDataExchange* pDX)
{
	CTDLWizardPage::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_SAMPLETASKLIST, m_eSampleTasklist);
	DDX_Text(pDX, IDC_SAMPLETASKLIST, m_sSampleTaskList);
	DDX_Radio(pDX, IDC_ALLOPTIONS, m_bHideAttrib);
	DDX_Radio(pDX, IDC_NOSAMPLE, m_bViewSample);
}

BEGIN_MESSAGE_MAP(CTDLWelcomePage3, CTDLWizardPage)
	ON_BN_CLICKED(IDC_NOSAMPLE, OnNosample)
	ON_BN_CLICKED(IDC_SAMPLE, OnSample)
	ON_REGISTERED_MESSAGE(WM_FE_GETFILEICON, OnGetFileIcon)
END_MESSAGE_MAP()

// ---------------------------------------------------------------------

BOOL CTDLWelcomePage3::OnInitDialog() 
{
	CTDLWizardPage::OnInitDialog();
	
	m_eSampleTasklist.SetButtonWidthDLU(1, 14);
	m_eSampleTasklist.EnableWindow(m_bViewSample);

	return TRUE; 
}

void CTDLWelcomePage3::OnNosample() 
{
	UpdateData();
	m_eSampleTasklist.EnableWindow(m_bViewSample);
}

CString CTDLWelcomePage3::GetSampleFilePath() const 
{ 
	if (m_bViewSample)
		return FileMisc::GetFullPath(m_sSampleTaskList, FileMisc::GetAppFolder());
	
	// else
	return _T("");
}

void CTDLWelcomePage3::OnSample() 
{
	UpdateData();
	m_eSampleTasklist.EnableWindow(m_bViewSample); 
}

BOOL CTDLWelcomePage3::OnSetActive() 
{
	SetWizardButtons(PSWIZB_BACK | PSWIZB_FINISH);
	
	return CTDLWizardPage::OnSetActive();
}

LRESULT CTDLWelcomePage3::OnGetFileIcon(WPARAM /*wParam*/, LPARAM lParam)
{
	if (FileMisc::HasExtension((LPCTSTR)lParam, _T("tdl")))
	{
		if (!m_iconTDL.IsValid())
			m_iconTDL.Load(IDR_MAINFRAME_STD);

		return (LRESULT)(HICON)m_iconTDL;
	}

	return 0L;
}
