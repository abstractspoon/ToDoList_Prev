#if !defined(AFX_PREFERENCESTASKPAGE_H__84CBF881_D8CA_4D00_ADD6_1DCB7DE71C5B__INCLUDED_)
#define AFX_PREFERENCESTASKPAGE_H__84CBF881_D8CA_4D00_ADD6_1DCB7DE71C5B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesTaskPage.h : header file
//

#include "..\shared\colorbutton.h"

/////////////////////////////////////////////////////////////////////////////
// CPreferencesTaskPage dialog

class CPreferencesTaskPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPreferencesTaskPage)

// Construction
public:
	CPreferencesTaskPage();
	~CPreferencesTaskPage();

	int GetDefaultPriority() { return m_nDefPriority; }
	CString GetDefaultPerson() { return m_sDefPerson; }
	int GetDefaultTimeEst() { return m_nDefTimeEst; }
	COLORREF GetDefaultColor() { return m_crDef; }
	COleDateTime GetDefaultStartDate();

	BOOL GetUseParentColorAttrib() { return m_bUseParentAttributes && m_bUseParentColorAttrib; }
	BOOL GetUseParentPersonAttrib() { return m_bUseParentAttributes && m_bUseParentPersonAttrib; }
	BOOL GetUseParentPriorityAttrib() { return m_bUseParentAttributes && m_bUseParentPriorityAttrib; }
	BOOL GetUseParentTimeEstAttrib() { return m_bUseParentAttributes && m_bUseParentTimeEstAttrib; }
	BOOL GetAutoReSort() { return m_bAutoReSort; }
	BOOL GetAveragePercentSubCompletion() { return m_bAveragePercentSubCompletion; }
	BOOL GetIncludeDoneInAverageCalc() { return m_bIncludeDoneInAverageCalc; }
	BOOL GetUseEarliestDueDate() { return m_bUseEarliestDueDate; }
	BOOL GetUsePercentDoneInTimeEst() { return m_bUsePercentDoneInTimeEst; }
	BOOL GetTreatSubCompletedAsDone() { return m_bTreatSubCompletedAsDone; }
	BOOL GetHidePercentForDoneTasks() { return m_bHidePercentForDoneTasks; }
	BOOL GetHideZeroTimeEst() { return m_bHideZeroTimeEst; }
	BOOL GetHideStartDueForDoneTasks() { return m_bHideStartDueForDoneTasks; }
	BOOL GetShowPercentAsProgressbar() { return m_bShowPercentAsProgressbar; }

// Dialog Data
	//{{AFX_DATA(CPreferencesTaskPage)
	enum { IDD = IDD_PREFTASK_PAGE };
	int		m_nDefPriority;
	int		m_nDefTimeEst;
	CString	m_sDefPerson;
	BOOL	m_bAutoReSort;
	BOOL	m_bUseParentAttributes;
	BOOL	m_bUseParentColorAttrib;
	BOOL	m_bUseParentPersonAttrib;
	BOOL	m_bUseParentPriorityAttrib;
	BOOL	m_bUseParentTimeEstAttrib;
	CColorButton	m_btDefColor;
	BOOL	m_bUseCreationForDefStartDate;
	BOOL	m_bHideZeroTimeEst;
	BOOL	m_bTreatSubCompletedAsDone;
	BOOL	m_bHideStartDueForDoneTasks;
	//}}AFX_DATA
	BOOL	m_bShowPercentAsProgressbar;
	COLORREF m_crDef;
	BOOL	m_bUseEarliestDueDate;
	BOOL	m_bUsePercentDoneInTimeEst;
	BOOL	m_bHidePercentForDoneTasks;
	BOOL	m_bAveragePercentSubCompletion;
	BOOL	m_bIncludeDoneInAverageCalc;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesTaskPage)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesTaskPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnSetdefaultcolor();
	afx_msg void OnUseparentattrib();
	//}}AFX_MSG
	afx_msg void OnAveragepercentChange();
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESTASKPAGE_H__84CBF881_D8CA_4D00_ADD6_1DCB7DE71C5B__INCLUDED_)
