#if !defined(AFX_PREFERENCESDLG_H__C3FCC72A_6C69_49A6_930D_D5C94EC31298__INCLUDED_)
#define AFX_PREFERENCESDLG_H__C3FCC72A_6C69_49A6_930D_D5C94EC31298__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesDlg.h : header file
//

#include "preferencesgenpage.h"
#include "preferencestaskpage.h"
#include "preferencestoolpage.h"
#include "preferencesuipage.h"
#include "preferencesshortcutspage.h"
#include "preferencesfilepage.h"

/////////////////////////////////////////////////////////////////////////////
// CPreferencesDlg dialog

class CPreferencesDlg : public CPropertySheet
{
// Construction
public:
	CPreferencesDlg(CShortcutManager* pMgr = NULL, UINT nMenuID = 0, CWnd* pParent = NULL);   // standard constructor
	virtual ~CPreferencesDlg();

	BOOL GetAlwaysOnTop() { return m_pageGen.GetAlwaysOnTop(); }
	BOOL GetUseSysTray() { return m_pageGen.GetUseSysTray(); }
	BOOL GetAutoSaveOnSysTray() { return m_pageGen.GetAutoSaveOnSysTray(); }
	BOOL GetConfirmDelete() { return m_pageGen.GetConfirmDelete(); }
	BOOL GetNotifyDue() { return m_pageGen.GetNotifyDue(); }
	BOOL GetAutoArchive() { return m_pageGen.GetAutoArchive(); }
	BOOL GetConfirmSaveOnExit() { return m_pageGen.GetConfirmSaveOnExit(); }
	BOOL GetNotifyReadOnly() { return m_pageGen.GetNotifyReadOnly(); }
	BOOL GetPromptReloadOnWritable() { return m_pageGen.GetPromptReloadOnWritable(); }
	BOOL GetPromptReloadOnTimestamp() { return m_pageGen.GetPromptReloadOnTimestamp(); }
	BOOL GetShowOnStartup() { return m_pageGen.GetShowOnStartup(); }
	int GetSysTrayOption() { return m_pageGen.GetSysTrayOption(); }
	BOOL GetToggleTrayVisibility() { return m_pageGen.GetToggleTrayVisibility(); }

	CString GetHtmlFont() { return m_pageFile.GetHtmlFont(); }
	BOOL GetPreviewExport() { return m_pageFile.GetPreviewExport(); }
	int GetTextIndent() { return m_pageFile.GetTextIndent(); }
	BOOL GetRemoveArchivedTasks() { return m_pageFile.GetRemoveArchivedTasks(); }
	BOOL GetRemoveOnlyOnAbsoluteCompletion() { return m_pageFile.GetRemoveOnlyOnAbsoluteCompletion(); }
	BOOL GetAutoHtmlExport() { return m_pageFile.GetAutoHtmlExport(); }
	BOOL GetExportVisibleOnly() { return m_pageFile.GetExportVisibleOnly(); }
	BOOL GetAutoSaveFrequency() { return m_pageFile.GetAutoSaveFrequency(); }

	int GetDefaultPriority() { return m_pageTask.GetDefaultPriority(); }
	CString GetDefaultPerson() { return m_pageTask.GetDefaultPerson(); }
	int GetDefaultTimeEst() { return m_pageTask.GetDefaultTimeEst(); }
	COLORREF GetDefaultColor() { return m_pageTask.GetDefaultColor(); }
	COleDateTime GetDefaultStartDate() { return m_pageTask.GetDefaultStartDate(); }
	BOOL GetUseParentColorAttrib() { return m_pageTask.GetUseParentColorAttrib(); }
	BOOL GetUseParentPersonAttrib() { return m_pageTask.GetUseParentPersonAttrib(); }
	BOOL GetUseParentPriorityAttrib() { return m_pageTask.GetUseParentPriorityAttrib(); }
	BOOL GetUseParentTimeEstAttrib() { return m_pageTask.GetUseParentTimeEstAttrib(); }
	BOOL GetAutoReSort() { return m_pageTask.GetAutoReSort(); }
	BOOL GetAveragePercentSubCompletion() { return m_pageTask.GetAveragePercentSubCompletion(); }
	BOOL GetIncludeDoneInAverageCalc() { return m_pageTask.GetIncludeDoneInAverageCalc(); }
	BOOL GetUseEarliestDueDate() { return m_pageTask.GetUseEarliestDueDate(); }
	BOOL GetUsePercentDoneInTimeEst() { return m_pageTask.GetUsePercentDoneInTimeEst(); }
	BOOL GetTreatSubCompletedAsDone() { return m_pageTask.GetTreatSubCompletedAsDone(); }
	BOOL GetHidePercentForDoneTasks() { return m_pageTask.GetHidePercentForDoneTasks(); }
	BOOL GetHideZeroTimeEst() { return m_pageTask.GetHideZeroTimeEst(); }
	BOOL GetHideStartDueForDoneTasks() { return m_pageTask.GetHideStartDueForDoneTasks(); }
	BOOL GetShowPercentAsProgressbar() { return m_pageTask.GetShowPercentAsProgressbar(); }

	BOOL GetColorTextByPriority() { return m_pageUI.GetColorTextByPriority(); }
	BOOL GetVaryCommentsHeight() { return m_pageUI.GetVaryCommentsHeight(); }
	BOOL GetShowButtonsInTree() { return m_pageUI.GetShowButtonsInTree(); }
	BOOL GetShowInfoTips() { return m_pageUI.GetShowInfoTips(); }
	BOOL GetShowComments() { return m_pageUI.GetShowComments(); }
	BOOL GetShowColumn(PTP_COLUMN nColumn) { return m_pageUI.GetShowColumn(nColumn); }
	BOOL GetColorPriority() { return m_pageUI.GetColorPriority(); }
	int GetPriorityColors(CDWordArray& aColors) { return m_pageUI.GetPriorityColors(aColors); }
	BOOL GetTreeFont(CString& sFaceName, int& nPointSize) { return m_pageUI.GetTreeFont(sFaceName, nPointSize); }
	BOOL GetShowCtrlsAsColumns() { return m_pageUI.GetShowCtrlsAsColumns(); }
	BOOL GetShowCommentsAlways() { return m_pageUI.GetShowCommentsAlways(); }
	BOOL GetAutoReposCtrls() { return m_pageUI.GetAutoReposCtrls(); }
	BOOL GetShowMenuBar() { return m_pageUI.GetShowMenuBar(); }
	COLORREF GetGridlineColor() { return m_pageUI.GetGridlineColor(); }

	int GetUserTools(CUserToolArray& aTools) { return m_pageTool.GetUserTools(aTools); }

//	BOOL Get() { return m_b; }

protected:
	CPreferencesGenPage m_pageGen;
	CPreferencesFilePage m_pageFile;
	CPreferencesUIPage m_pageUI;
	CPreferencesTaskPage m_pageTask;
	CPreferencesToolPage m_pageTool;
	CPreferencesShortcutsPage m_pageShortcuts;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesDlg)
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESDLG_H__C3FCC72A_6C69_49A6_930D_D5C94EC31298__INCLUDED_)
