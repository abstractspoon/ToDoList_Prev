// FilteredToDoCtrl.cpp: implementation of the CFilteredToDoCtrl class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FilteredToDoCtrl.h"
#include "todoitem.h"
#include "resource.h"
#include "tdcstatic.h"
#include "tdcmsg.h"

#include "..\shared\holdredraw.h"
#include "..\shared\datehelper.h"
#include "..\shared\enstring.h"
#include "..\shared\preferences.h"
#include "..\shared\deferwndmove.h"
#include "..\shared\autoflag.h"
#include "..\shared\holdredraw.h"
#include "..\shared\osversion.h"

#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#ifndef LVS_EX_DOUBLEBUFFER
#define LVS_EX_DOUBLEBUFFER 0x00010000
#endif

#ifndef LVS_EX_LABELTIP
#define LVS_EX_LABELTIP     0x00004000
#endif

const UINT SORTWIDTH = 10;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFilteredToDoCtrl::CFilteredToDoCtrl(CContentMgr& mgr, const CONTENTFORMAT& cfDefault) :
	CToDoCtrl(mgr, cfDefault), 
		m_nCurView(FTCV_UNSET), 
		m_bNeedRefilter(TRUE),
		m_bListNeedResort(FALSE),
		m_bTreeNeedResort(FALSE),
		m_nListSortBy(TDC_UNSORTED),
		m_bListSortAscending(-1),
		m_bListModSinceLastSort(FALSE)
{
	// add extra controls
	for (int nCtrl = 0; nCtrl < NUM_FTDCCTRLS; nCtrl++)
	{
		const TDCCONTROL& ctrl = FTDCCONTROLS[nCtrl];

		AddRCControl("CONTROL", ctrl.szClass, CEnString(ctrl.nIDCaption), 
					ctrl.dwStyle, ctrl.dwExStyle,
					ctrl.nX, ctrl.nY, ctrl.nCx, ctrl.nCy, ctrl.nID);
	}
	
}

CFilteredToDoCtrl::~CFilteredToDoCtrl()
{

}

BEGIN_MESSAGE_MAP(CFilteredToDoCtrl, CToDoCtrl)
//{{AFX_MSG_MAP(CFilteredToDoCtrl)
	ON_WM_SETCURSOR()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_NOTIFY(TCN_SELCHANGE, IDC_FTC_TABCTRL, OnSelchangeTabcontrol)
	ON_NOTIFY(NM_CUSTOMDRAW, 0, OnHeaderCustomDraw)
	ON_NOTIFY(NM_RCLICK, 0, OnRClickHeader)
	ON_NOTIFY(LVN_COLUMNCLICK, IDC_FTC_TASKLIST, OnClickHeader)
	ON_NOTIFY(NM_CLICK, IDC_FTC_TASKLIST, OnListClick)
	ON_NOTIFY(NM_DBLCLK, IDC_FTC_TASKLIST, OnListDblClick)
	ON_NOTIFY(NM_KEYDOWN, IDC_FTC_TASKLIST, OnListKeyDown)
	ON_REGISTERED_MESSAGE(WM_NCG_WIDTHCHANGE, OnGutterWidthChange)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_FTC_TASKLIST, OnListSelChanged)
	ON_WM_MEASUREITEM()
	ON_WM_DRAWITEM()
	ON_REGISTERED_MESSAGE(WM_TLDT_DROPFILE, OnDropFileRef)
	ON_NOTIFY(LVN_GETINFOTIP, IDC_FTC_TASKLIST, OnListGetInfoTip)
	ON_REGISTERED_MESSAGE(WM_PCANCELEDIT, OnEditCancel)
END_MESSAGE_MAP()

///////////////////////////////////////////////////////////////////////////

void CFilteredToDoCtrl::DoDataExchange(CDataExchange* pDX)
{
	CToDoCtrl::DoDataExchange(pDX);
	
	DDX_Control(pDX, IDC_FTC_TASKLIST, m_list);
	DDX_Control(pDX, IDC_FTC_TABCTRL, m_tabCtrl);
}

BOOL CFilteredToDoCtrl::OnInitDialog()
{
	CToDoCtrl::OnInitDialog();

	// prepare filtered view
	ListView_SetExtendedListViewStyleEx(m_list, 
										LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER, 
										LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER);
//	ListView_SetExtendedListViewStyleEx(m_list, LVS_EX_LABELTIP, LVS_EX_LABELTIP);
	m_dtList.Register(&m_list, this);
	m_list.EnableToolTips();
//	EnableToolTips();

	// prevent the list overwriting the label edit
	m_list.ModifyStyle(0, WS_CLIPSIBLINGS);

	// and hook it
	ScHookWindow(m_list);

	// add all columns
	BuildListColumns();

	// prepare tab bar
	if (m_ilTabs.Create(16, 16, ILC_COLOR32 | ILC_MASK, 2, 1))
	{
		CBitmap bm;
		bm.LoadBitmap(IDB_TREELIST);
		m_ilTabs.Add(&bm, RGB(255, 0, 255));
		m_tabCtrl.SetImageList(&m_ilTabs);
	}
		
	m_tabCtrl.InsertItem(TCIF_TEXT | TCIF_PARAM | TCIF_IMAGE, 0, CEnString(IDS_TASKTREE), 0, (LPARAM)&m_tree);
	m_tabCtrl.InsertItem(TCIF_TEXT | TCIF_PARAM | TCIF_IMAGE, 1, CEnString(IDS_LISTVIEW), 1, (LPARAM)&m_list);

	// filterbar
	m_filterBar.Create(this, (UINT)IDC_STATIC, FALSE);
	m_filterBar.ShowDivider(FALSE);

	Resize();

	return FALSE;
}

BOOL CFilteredToDoCtrl::PreTranslateMessage(MSG* pMsg) 
{
	return CToDoCtrl::PreTranslateMessage(pMsg);
}

BOOL CFilteredToDoCtrl::LoadTasks(const CTaskFile& file)
{
	CPreferences prefs;

	BOOL bSuccess = CToDoCtrl::LoadTasks(file);

	// reload last view
	if (m_nCurView == FTCV_UNSET)
	{
		RestoreFilter(prefs);

		CString sKey = GetPreferencesKey(); // no subkey
		
		if (!sKey.IsEmpty())
		{
			m_bNeedRefilter = TRUE;

			FTC_VIEW nView = (FTC_VIEW)prefs.GetProfileInt(sKey, "View", FTCV_TASKTREE);
			SetView(nView);
		}
	}
	else if (InListView())
		RefreshFilter();
	else
		m_bNeedRefilter = TRUE;

	return bSuccess;
}

void CFilteredToDoCtrl::RestoreFilter(const CPreferences& prefs)
{
	CString sKey = GetPreferencesKey("Filter");

	if (!sKey.IsEmpty())
	{
		m_filter.nFilter = (FILTER_TYPE)prefs.GetProfileInt(sKey, "Filter", FT_ALL);
		m_filter.nPriority = prefs.GetProfileInt(sKey, "Priority", FT_ANYPRIORITY);
		m_filter.nRisk = prefs.GetProfileInt(sKey, "Risk", FT_ANYRISK);
		m_filter.sAllocBy = prefs.GetProfileString(sKey, "AllocBy");
		m_filter.sStatus = prefs.GetProfileString(sKey, "Status");

		// cats
		m_filter.SetFlag(FT_ANYCATEGORY, prefs.GetProfileInt(sKey, "AnyCategory", FALSE));
		CString sCategory = prefs.GetProfileString(sKey, "Category");
		Misc::ParseIntoArray(sCategory, m_filter.aCategories, TRUE);

		// alloc to
		m_filter.SetFlag(FT_ANYALLOCTO, prefs.GetProfileInt(sKey, "AnyAllocTo", FALSE));
		CString sAllocTo = prefs.GetProfileString(sKey, "AllocTo");
		Misc::ParseIntoArray(sAllocTo, m_filter.aAllocTo, TRUE);
		
		if (m_filter.IsSet())
		{
			if (InListView())
				RefreshFilter();
			else
				m_bNeedRefilter = TRUE;
		}
	}
}

void CFilteredToDoCtrl::SaveFilter(CPreferences& prefs) const
{
	CString sKey = GetPreferencesKey("Filter");

	if (!sKey.IsEmpty())
	{
		prefs.WriteProfileInt(sKey, "Filter", m_filter.nFilter);
		prefs.WriteProfileInt(sKey, "Priority", m_filter.nPriority);
		prefs.WriteProfileInt(sKey, "Risk", m_filter.nRisk);
		prefs.WriteProfileString(sKey, "AllocBy", m_filter.sAllocBy);
		prefs.WriteProfileString(sKey, "Status", m_filter.sStatus);
		prefs.WriteProfileString(sKey, "AllocTo", Misc::FormatArray(m_filter.aAllocTo));
		prefs.WriteProfileInt(sKey, "AnyAllocTo", m_filter.HasFlag(FT_ANYALLOCTO));
		prefs.WriteProfileString(sKey, "Category", Misc::FormatArray(m_filter.aCategories));
		prefs.WriteProfileInt(sKey, "AnyCategory", m_filter.HasFlag(FT_ANYCATEGORY));
	}
}


void CFilteredToDoCtrl::OnDestroy() 
{
	if (m_nCurView != FTCV_UNSET)
	{
		CPreferences prefs;
		CString sKey = GetPreferencesKey(); // no subkey
		
		// save view
		if (!sKey.IsEmpty())
			prefs.WriteProfileInt(sKey, "View", m_nCurView);

		SaveFilter(prefs);
	}
		
	CToDoCtrl::OnDestroy();
}

void CFilteredToDoCtrl::BuildListColumns(BOOL bResizeCols)
{
	while (m_list.DeleteColumn(0));
	
	int nCol = NUM_COLUMNS - 1; // we handle title column separately
	
	while (nCol--)
	{
		const TDCCOLUMN& col = COLUMNS[nCol];
		UINT nFmt = col.nAlignment == DT_RIGHT ? LVCFMT_RIGHT : LVCFMT_LEFT;
		
		m_list.InsertColumn(0, "", nFmt, 10);
	}

	// title column
	if (HasStyle(TDCS_RIGHTSIDECOLUMNS))
		m_list.InsertColumn(0, "", LVCFMT_LEFT, 10);
	else
		m_list.InsertColumn(NUM_COLUMNS - 1, "", LVCFMT_LEFT, 10);

	if (bResizeCols)
		UpdateColumnWidths();
}

void CFilteredToDoCtrl::OnRClickHeader(NMHDR* /*pNMHDR*/, LRESULT* pResult)
{
	// forward on to parent
	const MSG* pMsg = GetCurrentMessage();
	LPARAM lPos = MAKELPARAM(pMsg->pt.x, pMsg->pt.y);

	GetParent()->SendMessage(WM_CONTEXTMENU, (WPARAM)GetSafeHwnd(), lPos);

	*pResult = 0;
}

void CFilteredToDoCtrl::OnClickHeader(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMLISTVIEW* pNMLV = (NMLISTVIEW*)pNMHDR;
	
	int nCol = pNMLV->iSubItem;
	TDCCOLUMN* pCol = GetColumn(nCol);

	if (pCol->nSortBy != TDC_UNSORTED)
	{
		TDC_SORTBY nPrev = m_nListSortBy;
		Sort(pCol->nSortBy);

		// notify parent
		if (m_nListSortBy != nPrev)
			GetParent()->SendMessage(WM_TDCN_SORT, GetDlgCtrlID(), MAKELPARAM((WORD)nPrev, (WORD)m_nListSortBy));
	}

	*pResult = 0;
}

void CFilteredToDoCtrl::SetVisibleColumns(const CTDCColumnArray& aColumns)
{
	CToDoCtrl::SetVisibleColumns(aColumns);

	if (InListView())
		UpdateColumnWidths();
}

void CFilteredToDoCtrl::OnSelchangeTabcontrol(NMHDR* /*pNMHDR*/, LRESULT* pResult) 
{
	SetView((FTC_VIEW)m_tabCtrl.GetCurSel());

	*pResult = 0;
}

BOOL CFilteredToDoCtrl::ArchiveDoneTasks(LPCTSTR szFilePath, TDC_ARCHIVE nFlags, BOOL bRemoveFlagged)
{
	if (CToDoCtrl::ArchiveDoneTasks(szFilePath, nFlags, bRemoveFlagged))
	{
		if (InListView())
			RefreshFilter();
		else
			m_bNeedRefilter = TRUE;
	}

	// else
	return FALSE;
}

void CFilteredToDoCtrl::SetView(FTC_VIEW nView) 
{
	if (nView == FTCV_UNSET)
	{
		ASSERT(0);
		return;
	}

	if (m_nCurView == nView)
		return;

	m_nCurView = nView;

	// show the incoming selection and hide the outgoing in that order
	switch (nView)
	{
	case FTCV_TASKTREE:
		// make sure something is selected
		if (GetSelectedCount() == 0)
		{
			HTREEITEM hti = m_tree.GetSelectedItem();
			CToDoCtrl::SelectTask(GetTaskID(hti));
	//		UpdateControls();
		}

		// update sort
		if (m_bTreeNeedResort)
		{
			m_bTreeNeedResort = FALSE;
			Resort();
		}

		m_tree.EnsureVisible(Selection().GetFirstItem());
		m_tree.ShowWindow(SW_SHOW);

		m_list.ShowWindow(SW_HIDE);
		m_filterBar.ShowWindow(SW_HIDE);
		
		m_tree.SetFocus();
		break;

	case FTCV_TASKLIST:
		// processed any unhandled comments
		HandleUnsavedComments(); 		
		
		// make sure filter view is correct for columns
//		CTDCColumnArray aColumns;
//		GetVisibleColumns(aColumns);
//		m_filterBar.SetVisibleFilters(aColumns);

		// take a note of what task is currently singly selected
		// so that we can prevent unnecessary calls to UpdateControls
		DWORD dwSelTaskID = (GetSelectedCount() == 1) ? GetTaskID(GetSelectedItem()) : 0;

		if (!m_header.GetSafeHwnd())
		{
			m_header.SubclassDlgItem(0, &m_list);
			m_header.EnableTracking(FALSE);

			// set the prompt now we know how tall the header is
			CRect rHeader;
			m_header.GetWindowRect(rHeader);
			m_list.ScreenToClient(rHeader);
			m_mgrPrompts.SetPrompt(m_list, IDS_TDC_FILTEREDTASKLISTPROMPT, LVM_GETITEMCOUNT, 0, rHeader.bottom);
		}

		// make sure row height is correct by forcing a WM_MEASUREITEM
		RemeasureList();

		// update column widths
		UpdateColumnWidths();

		// update filter
		BOOL bFiltered = m_bNeedRefilter;

		if (m_bNeedRefilter)
		{
			m_bNeedRefilter = FALSE;
			RefreshFilter();
		}

		// update sort
		if (m_bListNeedResort)
		{
			m_bListNeedResort = FALSE;
			Resort();
		}

		// restore selection
		ResyncListSelection();

		// update controls only if the selection has changed and 
		// we didn't refilter (RefreshFilter will already have called UpdateControls)
		BOOL bSelChange = !(GetSelectedCount() == 1 && GetTaskID(GetSelectedItem()) == dwSelTaskID);

		if (bSelChange && !bFiltered)
			UpdateControls();

		m_list.EnsureVisible(GetFirstSelectedItem(), FALSE);

		m_list.ShowWindow(SW_SHOW);
		m_list.SetFocus();

//		m_filterBar.ShowWindow(SW_SHOW);
		m_tree.ShowWindow(SW_HIDE);

		break;
	}

	m_tabCtrl.SetCurSel((int)nView);
}

void CFilteredToDoCtrl::RemeasureList()
{
	CRect rList;
	m_list.GetWindowRect(rList);
	ScreenToClient(rList);

	WINDOWPOS wpos = { m_list, NULL, rList.left, rList.top, rList.Width(), rList.Height(), SWP_NOZORDER };
	m_list.SendMessage(WM_WINDOWPOSCHANGED, 0, (LPARAM)&wpos);
}

void CFilteredToDoCtrl::UpdateColumnWidths()
{
	if (!InListView())
		return;

	int nCol = NUM_COLUMNS;
	int nTotalWidth = 0;
	BOOL bFirstWidth = TRUE;
	
	for (nCol = 0; nCol < NUM_COLUMNS; nCol++)
	{
		const TDCCOLUMN* pCol = GetColumn(nCol);
		ASSERT(pCol);

		if (pCol->nColID == TDCC_CLIENT)
			continue; // we'll deal with this at the end

		int nWidth = m_tree.GetColumnWidth(pCol->nColID);

		if (nWidth && bFirstWidth)
		{
			bFirstWidth = FALSE;
			nWidth += 1;
		}

		// sort indicator 
		if (m_nListSortBy == pCol->nSortBy && IsColumnShowing(pCol->nColID) && IsSortable())
		{
			if (m_nListSortBy != m_nSortBy)
				nWidth += SORTWIDTH;// * 2;
		}

		m_list.SetColumnWidth(nCol, nWidth);

		nTotalWidth += nWidth;
	}

	// client column is what's left
	CRect rList;
	m_list.GetClientRect(rList);

	int nColWidth = max(300, rList.Width() - nTotalWidth);
	m_list.SetColumnWidth(GetColumnIndex(TDCC_CLIENT), nColWidth);

	m_list.Invalidate(FALSE);
	m_list.UpdateWindow();
}

void CFilteredToDoCtrl::ReposTaskTree(CDeferWndMove* pDWM, const CRect& rPos)
{
	// position tab ctrl below task tree
	CRect rTabs(0, 0, rPos.Width(), 0);
	m_tabCtrl.AdjustRect(TRUE, rTabs);

	int nTabHeight = rTabs.Height();
	rTabs = rPos;
	rTabs.right += 2;
	rTabs.top = rTabs.bottom - nTabHeight + 3;

	pDWM->MoveWindow(&m_tabCtrl, rTabs);

	// adjust rect for tab ctrl
	CRect rList(rPos);
	rList.bottom = rTabs.top + 1;

	CToDoCtrl::ReposTaskTree(pDWM, rList);

	// repos tasklist with filterbar above
/*
	int nFilterHeight = m_filterBar.CalcHeight(rPos.Width());

	rList.bottom = rList.top + nFilterHeight;
	pDWM->MoveWindow(&m_filterBar, rList);

	rList.top = rList.bottom;
	rList.bottom = rPos.bottom;
*/

	pDWM->MoveWindow(&m_list, rList);
}

void CFilteredToDoCtrl::Resize(int cx, int cy)
{
	CToDoCtrl::Resize(cx, cy);

	UpdateColumnWidths();
}

int CFilteredToDoCtrl::OnToolHitTest(CPoint point, TOOLINFO* pTI) const
{
/*
	ClientToScreen(&point);
	m_list.ScreenToClient(&point);

	LVHITTESTINFO lvhti = { { point.x, point.y }, 0, 0, 0 };
	const_cast<CListCtrl*>(&m_list)->SubItemHitTest(&lvhti);
	
	int nHit = lvhti.iItem;
	
	if (nHit >= 0 && GetColumnID(lvhti.iSubItem) == TDCC_CLIENT)
	{
		pTI->hwnd = GetSafeHwnd();
		pTI->lpszText = LPSTR_TEXTCALLBACK;
		pTI->uId = nHit;

		return -1;
	}
*/

	return CToDoCtrl::OnToolHitTest(point, pTI);
}

void CFilteredToDoCtrl::SelectAll()
{
	if (InListView())
	{
		int nNumItems = m_list.GetItemCount();
		BOOL bAllTasks = (CToDoCtrl::GetTaskCount() == (UINT)nNumItems);
		CDWordArray aTaskIDs;

		for (int nItem = 0; nItem < nNumItems; nItem++)
		{
			// select item
			m_list.SetItemState(nItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);

			// save ID only not showing all tasks
			if (!bAllTasks)
				aTaskIDs.Add(m_list.GetItemData(nItem));
		}

		// select items in tree
		if (bAllTasks)
			CToDoCtrl::SelectAll();
		else
			MultiSelectItems(aTaskIDs, TSHS_SELECT, FALSE);
	}
	else
		CToDoCtrl::SelectAll();
}

void CFilteredToDoCtrl::DeselectAll()
{
	CToDoCtrl::DeselectAll();
	ClearListSelection();
}

int CFilteredToDoCtrl::GetTasks(CTaskFile& tasks, const TDCFILTER& filter) const
{
	if (InListView())
	{
		// we return exactly what's selected in the list and in the same order
		// so we make sure the filter includes TDCGT_NOTSUBTASKS
		TDCFILTER tdcf(filter);
		tdcf.dwFlags |= TDCGT_NOTSUBTASKS;

		for (int nItem = 0; nItem < m_list.GetItemCount(); nItem++)
		{
			HTREEITEM hti = GetTreeItem(nItem);
			AddItem(hti, tasks, NULL, tdcf, 0);
		}

		if (filter.dwFlags & TDCGT_FILENAME)
			tasks.SetFileName(m_sLastSavePath);

		return tasks.GetTaskCount();
	}
	else
		return CToDoCtrl::GetTasks(tasks, filter);
}

int CFilteredToDoCtrl::GetSelectedTasks(CTaskFile& tasks, const TDCFILTER& filter) const
{
	if (InListView())
	{
		// we return exactly what's selected in the list and in the same order
		// so we make sure the filter includes TDCGT_NOTSUBTASKS
		TDCFILTER tdcf(filter);
		tdcf.dwFlags |= TDCGT_NOTSUBTASKS;
	
		POSITION pos = m_list.GetFirstSelectedItemPosition();

		while (pos)
		{
			int nItem = m_list.GetNextSelectedItem(pos);
			HTREEITEM hti = GetTreeItem(nItem);

			AddItem(hti, tasks, NULL, tdcf, 0);
		}

		return tasks.GetTaskCount();
	}
	else
		return CToDoCtrl::GetSelectedTasks(tasks, filter);
}

FILTER_TYPE CFilteredToDoCtrl::GetFilter(FTDCFILTER& filter) const
{
	filter = m_filter;
	return m_filter.nFilter;
}

void CFilteredToDoCtrl::SetFilter(const FTDCFILTER& filter)
{
	FTDCFILTER fPrev = m_filter;
	m_filter = filter;

	if (fPrev == filter)
		return; // no change (except for unnecessary flags)

	if (m_bDelayLoaded)
		m_bNeedRefilter = TRUE;

	else if (InListView())
		RefreshFilter();
	else
	{
		m_bNeedRefilter = TRUE;
		SetView(FTCV_TASKLIST);
	}
}
	
void CFilteredToDoCtrl::ClearFilter()
{
	if (HasFilter())
	{
		FTDCFILTER filter; // empty filter

		SetFilter(filter);
		SetView(FTCV_TASKLIST);
	}
}

UINT CFilteredToDoCtrl::GetTaskCount(UINT* pVisible) const
{
	if (pVisible)
		*pVisible = m_list.GetItemCount();

	return CToDoCtrl::GetTaskCount();
}

void CFilteredToDoCtrl::BuildFindQuery(SEARCHPARAMS& params)
{
	// reset the search
	params.bIncludeDone = TRUE;
	params.rules.RemoveAll();

	// handle principle filter
	switch (m_filter.nFilter)
	{
	case FT_ALL:
		break;

	case FT_DONE:
		params.rules.Add(SEARCHPARAM(TDCA_DONEDATE, FO_SET));
		break;

	case FT_NOTDONE:
		params.rules.Add(SEARCHPARAM(TDCA_DONEDATE, FO_NOT_SET));
		break;

	case FT_STARTTODAY:
		{
			COleDateTime date = CDateHelper::GetDate(DHD_TODAY);
			params.rules.Add(SEARCHPARAM(TDCA_DONEDATE, FO_NOT_SET));
			params.rules.Add(SEARCHPARAM(TDCA_STARTDATE, FO_ON_OR_BEFORE, date.m_dt));
		}
		break;

	case FT_STARTENDTHISWEEK:
		{
			COleDateTime date = CDateHelper::GetDate(DHD_ENDTHISWEEK);
			params.rules.Add(SEARCHPARAM(TDCA_DONEDATE, FO_NOT_SET));
			params.rules.Add(SEARCHPARAM(TDCA_STARTDATE, FO_ON_OR_BEFORE, date.m_dt));
		}
		break;

	case FT_FLAGGED:
		params.rules.Add(SEARCHPARAM(TDCA_FLAG, FO_SET));
		break;

	default: // all the rest are due dates
		{
			COleDateTime dateDue;
			InitDueDate(dateDue);

			if (dateDue.m_dt > 0.0)
			{
				params.rules.Add(SEARCHPARAM(TDCA_DONEDATE, FO_NOT_SET));
				params.rules.Add(SEARCHPARAM(TDCA_DUEDATE, FO_ON_OR_BEFORE, dateDue.m_dt));
			}
		}
		break;
	}

	// handle other attributes
	if (m_filter.aCategories.GetSize())
	{
		CString sMatchBy = Misc::FormatArray(m_filter.aCategories);

		if (m_filter.aCategories.GetSize() == 1 && sMatchBy.IsEmpty())
			params.rules.Add(SEARCHPARAM(TDCA_CATEGORY, FO_NOT_SET));

		else if (m_filter.dwFlags & FT_ANYCATEGORY)
			params.rules.Add(SEARCHPARAM(TDCA_CATEGORY, FO_INCLUDES, sMatchBy));
		else
			params.rules.Add(SEARCHPARAM(TDCA_CATEGORY, FO_EQUALS, sMatchBy));
	}

	if (m_filter.aAllocTo.GetSize())
	{
		CString sMatchBy = Misc::FormatArray(m_filter.aAllocTo);

		if (m_filter.aAllocTo.GetSize() == 1 && sMatchBy.IsEmpty())
			params.rules.Add(SEARCHPARAM(TDCA_ALLOCTO, FO_NOT_SET));

		else if (m_filter.dwFlags & FT_ANYALLOCTO)
			params.rules.Add(SEARCHPARAM(TDCA_ALLOCTO, FO_INCLUDES, sMatchBy));
		else
			params.rules.Add(SEARCHPARAM(TDCA_ALLOCTO, FO_EQUALS, sMatchBy));
	}

	if (!m_filter.sAllocBy.IsEmpty())
	{
		params.rules.Add(SEARCHPARAM(TDCA_ALLOCBY, FO_EQUALS, m_filter.sAllocBy));
	}

	if (!m_filter.sStatus.IsEmpty())
	{
		params.rules.Add(SEARCHPARAM(TDCA_STATUS, FO_EQUALS, m_filter.sStatus));
	}

	if (m_filter.nPriority != FT_ANYPRIORITY)
	{
		if (m_filter.nPriority == FT_NOPRIORITY)
			params.rules.Add(SEARCHPARAM(TDCA_PRIORITY, FO_NOT_SET));

		else if (m_filter.nPriority != FT_ANYPRIORITY)
			params.rules.Add(SEARCHPARAM(TDCA_PRIORITY, FO_GREATER_OR_EQUAL, m_filter.nPriority));
	}

	if (m_filter.nRisk != FT_ANYRISK)
	{
		if (m_filter.nRisk == FT_NORISK)
			params.rules.Add(SEARCHPARAM(TDCA_RISK, FO_NOT_SET));
		
		else if (m_filter.nRisk != FT_ANYRISK)
			params.rules.Add(SEARCHPARAM(TDCA_RISK, FO_GREATER_OR_EQUAL, m_filter.nRisk));
	}
}

void CFilteredToDoCtrl::RefreshFilter() 
{
	// note: the call to CListCtrl::Scroll at the bottom fails if the 
	// list has redraw disabled so it must happen outside the scope of hr2
	CSize sizePos(0, 0);
	{
		CHoldRedraw hr2(m_list);
		CWaitCursor cursor;

		// cache current selection
		CDWordArray aTaskIDs;
		DWORD dwFocusedTaskID;
		GetSelectedTaskIDs(aTaskIDs, dwFocusedTaskID, FALSE);

		// and scrolled pos
		if (m_list.GetItemCount())
		{
			CRect rItem;
			m_list.GetItemRect(0, rItem, LVIR_BOUNDS);

			sizePos.cy = -rItem.top + rItem.Height();
		}

		// remove all existing items
		m_list.DeleteAllItems();

		// build a find query that matches the filter
		SEARCHPARAMS search;
		BuildFindQuery(search);

		// do the find
		CResultArray aResults;
		FindTasks(search, aResults);

		// add tasks to list
		for (int nRes = 0; nRes < aResults.GetSize(); nRes++)
		{
			const SEARCHRESULT& res = aResults[nRes];

			int nItem = m_list.InsertItem(nRes, LPSTR_TEXTCALLBACK, 0);
			m_list.SetItemData(nItem, res.dwID);
		}

		// redo last sort
		if (IsSortable())
		{
			Sort(GetSortBy(), FALSE);
			m_bListNeedResort = FALSE;
		}

		// restore selection
		SetSelectedListTasks(aTaskIDs, dwFocusedTaskID);

		// don't update controls is only one item is selected and it did not
		// change as a result of the filter
		BOOL bSelChange = !(GetSelectedCount() == 1 && aTaskIDs.GetSize() == 1 &&
							GetTaskID(GetSelectedItem()) == aTaskIDs[0]);

		if (bSelChange)
			UpdateControls();
	}
	
	// restore pos
	if (sizePos.cy != 0)
		m_list.Scroll(sizePos);

	UpdateColumnWidths();
}

void CFilteredToDoCtrl::OnHeaderCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMCUSTOMDRAW* pNMCD = (NMCUSTOMDRAW*)pNMHDR;
	
	if (pNMCD->dwDrawStage == CDDS_PREPAINT)
		*pResult |= CDRF_NOTIFYITEMDRAW | CDRF_NOTIFYPOSTPAINT;	
	
	else if (pNMCD->dwDrawStage == CDDS_ITEMPREPAINT)
		*pResult |= CDRF_NOTIFYPOSTPAINT;	

	else if (pNMCD->dwDrawStage == CDDS_ITEMPOSTPAINT)
	{
		CDC* pDC = CDC::FromHandle(pNMCD->hdc);
		CFont* pOldFont = (CFont*)pDC->SelectObject(CWnd::GetFont());

		// clip column to client rect
		CRect rHeader;
		m_header.GetClientRect(rHeader);
		pNMCD->rc.right = min(pNMCD->rc.right, rHeader.right);

		DrawColumnHeaderText(pDC, pNMCD->dwItemSpec, pNMCD->rc, pNMCD->uItemState);

		pDC->SelectObject(pOldFont);
	}
}

void CFilteredToDoCtrl::OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{
	if (nIDCtl == IDC_FTC_TASKLIST)
		lpMeasureItemStruct->itemHeight = m_tree.TCH().GetItemHeight();
	else
		CToDoCtrl::OnMeasureItem(nIDCtl, lpMeasureItemStruct);
}

void CFilteredToDoCtrl::RemoveDeletedListItems()
{
	int nItem = m_list.GetItemCount();

	while (nItem--)
	{
		DWORD dwTaskID = m_list.GetItemData(nItem);

		if (!GetTask(dwTaskID))
			m_list.DeleteItem(nItem);
	}
}

void CFilteredToDoCtrl::GetItemColors(int nItem, NCGITEMCOLORS& colors)
{
	// we let base class do most of the work but override in the case
	// of drop highlight selection
	if (m_list.GetItemState(nItem, LVIS_DROPHILITED) & LVIS_DROPHILITED)
	{
		colors.crBack = GetSysColor(COLOR_3DFACE);
		colors.crText = GetSysColor(COLOR_WINDOWTEXT);
		colors.bBackSet = colors.bTextSet = TRUE;
	}
	else
		CToDoCtrl::OnGutterGetItemColors(m_tree.GetDlgCtrlID(), (LPARAM)&colors);
}

void CFilteredToDoCtrl::GetTaskTextColors(HTREEITEM hti, const TODOITEM* pTDI, BOOL bDone, COLORREF& crText, COLORREF& crBack)
{
	// handle filtered *out* tasks
/*
	if (!InListView() && m_filter.IsSet() && FindTask(m_tree.GetItemData(hti)) == -1)
	{
		crText = RGB(200, 200, 200);
		crBack = GetItemLineColor(hti);
	}
	else
*/
		CToDoCtrl::GetTaskTextColors(hti, pTDI, bDone, crText, crBack);
}

void CFilteredToDoCtrl::DrawCommentsText(CDC* pDC, HTREEITEM hti, TODOITEM* pTDI, const CRect& rText)
{
	// don't draw comments for filtered *out* tasks
//	if (InListView() || !m_filter.IsSet() || FindTask(m_tree.GetItemData(hti)) != -1)
		CToDoCtrl::DrawCommentsText(pDC, hti, pTDI, rText);
}

void CFilteredToDoCtrl::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	if (nIDCtl == IDC_FTC_TASKLIST)
	{
		// don't bother drawing if we're just switching to the tree view
		if (!InListView())
			return;
		
		int nItem = lpDrawItemStruct->itemID;
		DWORD dwTaskID = lpDrawItemStruct->itemData;
		HTREEITEM hti = m_data.GetItem(dwTaskID);
		TODOITEM* pTDI = m_data.GetTask(dwTaskID);

		if (!pTDI)
			return;

		CRect rItem, rTitleBounds;

		m_list.GetSubItemRect(nItem, 0, LVIR_BOUNDS, rItem);
		GetItemTitleRect(nItem, TDCTR_BOUNDS, rTitleBounds);

		CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
		int nSaveDC = pDC->SaveDC(); // so that DrawFocusRect works

		pDC->SetBkMode(TRANSPARENT);

		COLORREF crGrid = m_tree.GetGridlineColor();
		NCGITEMCOLORS colors = { (DWORD)hti, 0, 0, FALSE, FALSE };
		
		GetItemColors(nItem, colors);

		// fill back color
		if (HasStyle(TDCS_FULLROWSELECTION) || !colors.bBackSet)
			pDC->FillSolidRect(rItem, colors.bBackSet ? colors.crBack : GetSysColor(COLOR_WINDOW));
		else
		{
			// calculate the rect containing the rest of the columns
			CRect rCols(rItem);

			if (HasStyle(TDCS_RIGHTSIDECOLUMNS))
			{
				rCols.left = rTitleBounds.right;
			}
			else
				rCols.right = rTitleBounds.left;

			// fill the background colour of the rest of the columns
			rCols.right--;
			pDC->FillSolidRect(rCols, colors.crBack);

			// check to see whether we should fill the label cell background
			// with the alternate line colour
			if (nItem % 2) // odd row
			{
				COLORREF crAltLine = m_tree.GetAlternateLineColor();
					
				if (crAltLine != (COLORREF)-1)
				{
					rTitleBounds.OffsetRect(-1, 0);
					pDC->FillSolidRect(rTitleBounds, crAltLine);
					rTitleBounds.OffsetRect(1, 0);
				}
			}
		}

		// and set the text color
		if (colors.bTextSet)
			pDC->SetTextColor(colors.crText);
		else
			pDC->SetTextColor(GetSysColor(COLOR_WINDOWTEXT));
		
		// render column text
		// use CToDoCtrl::OnGutterDrawItem to do the hard work
		NCGDRAWITEM ncgDI;
		CRect rFocus; // will be set up during TDCC_CLIENT handling
		
		for (int nCol = 0; nCol < NUM_COLUMNS; nCol++)
		{
			// client column/task title is special case
			TDCCOLUMN* pCol = GetColumn(nCol);

			if (pCol->nColID == TDCC_CLIENT)
			{
				BOOL bHasChildren = m_tree.ItemHasChildren(hti);
				BOOL bDoneAndStrikeThru = pTDI->IsDone() && HasStyle(TDCS_STRIKETHOUGHDONETASKS);

				// folder icon
				CRect rSubItem;

				if (bHasChildren && GetItemTitleRect(nItem, TDCTR_FOLDER, rSubItem))
					m_ilFileRef.GetImageList()->Draw(pDC, m_ilFileRef.GetFolderImageIndex(), rSubItem.TopLeft(), ILD_TRANSPARENT);

				// checkbox
				if (GetItemTitleRect(nItem, TDCTR_CHECKBOX, rSubItem))
				{
					int nImage = pTDI->IsDone() ? 2 : 1;
					CImageList::FromHandle(m_hilDone)->Draw(pDC, nImage, rSubItem.TopLeft(), ILD_TRANSPARENT);
				}

				// set fonts before calculating title rect
				HFONT hFontOld = NULL;

				if (bDoneAndStrikeThru)
					hFontOld = (HFONT)::SelectObject(lpDrawItemStruct->hDC, m_fontDone);

				else if (m_tree.GetParentItem(hti) == NULL) // top level item
					hFontOld = (HFONT)::SelectObject(lpDrawItemStruct->hDC, m_fontBold);

				// Task title 
				GetItemTitleRect(nItem, TDCTR_LABEL, rSubItem, pDC, pTDI->sTitle);
				rSubItem.OffsetRect(-1, 0);

				// back colour
				if (!HasStyle(TDCS_FULLROWSELECTION) && colors.bBackSet)
					pDC->FillSolidRect(rSubItem, colors.crBack);

				// text
				DrawGutterItemText(pDC, pTDI->sTitle, rSubItem, LVCFMT_LEFT);
				rFocus = rSubItem; // save for focus rect drawing

				// vertical divider
				if (crGrid != (COLORREF)-1)
					pDC->FillSolidRect(rTitleBounds.right - 1, rTitleBounds.top, 1, rTitleBounds.Height(), crGrid);

				// render comment text if not editing this task label
				if (m_dwEditingID != dwTaskID)
				{
					// deselect bold font if set
					if (bHasChildren && !bDoneAndStrikeThru)
					{
						::SelectObject(lpDrawItemStruct->hDC, hFontOld);
						hFontOld = NULL;
					}	

					rTitleBounds.top++;
					rTitleBounds.left = rSubItem.right + 4;
					DrawCommentsText(pDC, hti, pTDI, rTitleBounds);
				}

				if (hFontOld)
					::SelectObject(lpDrawItemStruct->hDC, hFontOld);
			}
			else
			{
				// get col rect
				CRect rSubItem;
				m_list.GetSubItemRect(nItem, nCol, LVIR_LABEL, rSubItem);
				rSubItem.OffsetRect(-1, 0);

				ncgDI.pDC = pDC;
				ncgDI.dwItem = (DWORD)hti;
				ncgDI.dwParentItem = (DWORD)m_tree.GetParentItem(hti);
				ncgDI.nLevel = 0;//nLevel;
				ncgDI.nItemPos = 0;//nPos;
				ncgDI.rWindow = &rSubItem;
				ncgDI.rItem = &rSubItem;
				ncgDI.nColID = pCol->nColID;
				ncgDI.nTextAlign = pCol->nAlignment;
				
				CToDoCtrl::OnGutterDrawItem(GetDlgCtrlID(), (LPARAM)&ncgDI);
			}
		}

		// base gridline
		if (crGrid != (COLORREF)-1)
			pDC->FillSolidRect(rItem.left, rItem.bottom - 1, rItem.Width() - 1, 1, crGrid);

		pDC->RestoreDC(nSaveDC); // so that DrawFocusRect works
		
		// focus rect
		if ((lpDrawItemStruct->itemState & ODS_FOCUS) && Selection().HasItem(hti) &&
			GetFocus() == &m_list)
		{
			pDC->DrawFocusRect(rFocus);
		}
	}
	else
		CToDoCtrl::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

COLORREF CFilteredToDoCtrl::GetItemLineColor(HTREEITEM hti)
{
	if (InListView())
	{
		COLORREF crAltLines = m_tree.GetAlternateLineColor();

		if (crAltLines != (COLORREF)-1)
		{
			int nItem = FindTask(GetTaskID(hti));

			if (nItem != -1 && (nItem % 2))
				return crAltLines;
		}
			
		// else
		return GetSysColor(COLOR_WINDOW);
	}

	// else
	return CToDoCtrl::GetItemLineColor(hti);
}

void CFilteredToDoCtrl::DrawColumnHeaderText(CDC* pDC, int nCol, const CRect& rCol, UINT nState)
{
	if (nCol >= NUM_COLUMNS)
		return;

	// filter out zero width columns
	if (rCol.Width() == 0)
		return;

	const TDCCOLUMN* pCol = GetColumn(nCol);
	ASSERT(pCol);

	CString sColumn;
	sColumn.LoadString(pCol->nIDName);

	// special cases
	if (sColumn.IsEmpty())
		sColumn = CString(static_cast<TCHAR>(pCol->nIDName));

	else if (pCol->nColID == TDCC_CLIENT && HasStyle(TDCS_SHOWPATHINHEADER) && m_list.GetSelectedCount() == 1)
	{
		int nColWidthInChars = (int)(rCol.Width() / m_fAveHeaderCharWidth);
		CString sPath = m_data.GetItemPath(GetSelectedItem(), nColWidthInChars);
			
		if (!sPath.IsEmpty())
			sColumn.Format("%s [%s]", CEnString(IDS_TDC_COLUMN_TASK), sPath);
	}
	else if (sColumn == "%%")
		sColumn = "%";

	const UINT DEFFLAGS = DT_END_ELLIPSIS | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX;
	pDC->SetBkMode(TRANSPARENT);
	
	CRect rText(rCol);
	rText.bottom -= 2;//(pCol->bSymbolFont ? 1 : 2);// + (pTheme ? 1 : 0);
	
	switch (pCol->nAlignment)
	{
	case DT_LEFT:
		rText.left += NCG_COLPADDING - 1;
		break;
		
	case DT_RIGHT:
		rText.right -= NCG_COLPADDING;
		break;

	case DT_CENTER:
		rText.right--;
	}
	
	BOOL bDown = (nState & CDIS_SELECTED);
	BOOL bSorted = (IsSortable() && m_nListSortBy == pCol->nSortBy);
	
	if (bDown)
		rText.OffsetRect(1, 1);
	
	if (bSorted)
		rText.right -= (SORTWIDTH + 2);

	if (pCol->szFont && *pCol->szFont)
	{
		CFont* pOldFont = NULL;

		if (CString(pCol->szFont).CompareNoCase("WingDings") == 0)
			pOldFont = pDC->SelectObject(&Misc::WingDings());
		
		else if (CString(pCol->szFont).CompareNoCase("Marlett") == 0)
			pOldFont = pDC->SelectObject(&Misc::Marlett());
		
		pDC->DrawText(sColumn, rText, DEFFLAGS | pCol->nAlignment);
		
		if (pOldFont)
			pDC->SelectObject(pOldFont);
	}
	else
		pDC->DrawText(sColumn, rText, DEFFLAGS | pCol->nAlignment);

	// draw sort direction if required
	if (bSorted)
	{
		// adjust for sort arrow
		if (pCol->nAlignment & DT_CENTER)
			rText.left = ((rText.left + rText.right + pDC->GetTextExtent(sColumn).cx) / 2) + 2;
			
		else if (pCol->nAlignment & DT_RIGHT)
			rText.left = rText.right + 2;
		else
			rText.left = rText.left + pDC->GetTextExtent(sColumn).cx + 2;

		BOOL bAscending = m_bListSortAscending ? 1 : -1;
		int nMidY = (bDown ? 1 : 0) + (rText.top + rText.bottom) / 2;
		POINT ptArrow[3] = { 
							{ 0, 0 }, 
							{ 3, -bAscending * 3 }, 
							{ 7, bAscending } };
		
		// translate the arrow to the appropriate location
		int nPoint = 3;
		
		while (nPoint--)
		{
			ptArrow[nPoint].x += rText.left + 3 + (bDown ? 1 : 0);
			ptArrow[nPoint].y += nMidY;
		}
		pDC->Polyline(ptArrow, 3);
	}
}


TDC_COLUMN CFilteredToDoCtrl::GetColumnID(int nCol) const
{
	TDCCOLUMN* pCol = GetColumn(nCol);
	return pCol ? pCol->nColID : (TDC_COLUMN)-1;
}

TDCCOLUMN* CFilteredToDoCtrl::GetColumn(int nCol) const
{
	if (nCol < 0 || nCol >= NUM_COLUMNS)
		return NULL;

	// else
	if (HasStyle(TDCS_RIGHTSIDECOLUMNS))
	{
		if (nCol == 0)
			return &COLUMNS[NUM_COLUMNS - 1];
		else
			return &COLUMNS[nCol - 1];
	}
	
	// else
	return &COLUMNS[nCol];

}

int CFilteredToDoCtrl::GetColumnIndex(TDC_COLUMN nColID) const
{
	if (HasStyle(TDCS_RIGHTSIDECOLUMNS))
	{
		if (nColID == TDCC_CLIENT)
			return 0;

		// else it's 1 more than the COLUMNS index
		int nCol = NUM_COLUMNS - 1;

		while (nCol--)
		{
			if (COLUMNS[nCol].nColID == nColID)
				return nCol + 1;
		}
		
		ASSERT(0);
		return 0;
	}
	
	// else as COLUMNS
	int nCol = NUM_COLUMNS;
	
	while (nCol--)
	{
		if (COLUMNS[nCol].nColID == nColID)
			return nCol;
	}
	
	ASSERT(0);
	return 0;
}

BOOL CFilteredToDoCtrl::SetStyle(TDC_STYLE nStyle, BOOL bOn, BOOL bWantUpdate)
{
	// preprocessing
	switch (nStyle)
	{
	case TDCS_SORTDONETASKSATBOTTOM:
		m_bListModSinceLastSort = TRUE;
		break;
	}

	// base class processing
	if (CToDoCtrl::SetStyle(nStyle, bOn, bWantUpdate))
	{
		// post-precessing
		switch (nStyle)
		{
		case TDCS_TREATSUBCOMPLETEDASDONE:
			if (m_filter.nFilter != FT_ALL)
			{
				if (InListView())
					RefreshFilter();
				else
					m_bNeedRefilter = TRUE;
			}
			break;

		case TDCS_RIGHTSIDECOLUMNS:
			BuildListColumns();
			break;

		case TDCS_SHOWINFOTIPS:
			ListView_SetExtendedListViewStyleEx(m_list, LVS_EX_INFOTIP, bOn ? LVS_EX_INFOTIP : 0);
			break;
		}

		return TRUE;
	}

	return FALSE;
}

void CFilteredToDoCtrl::InitDueDate(COleDateTime& dateDue) const
{
	switch (m_filter.nFilter)
	{
	case FT_ALL:
	case FT_DONE:
	case FT_NOTDONE:
	case FT_FLAGGED:
	case FT_STARTTODAY:
	case FT_STARTENDTHISWEEK:
		dateDue.m_dt = 0;
		break;

	case FT_DUETODAY:
		dateDue = CDateHelper::GetDate(DHD_TODAY);
		break;

	case FT_DUETOMORROW:
		dateDue = CDateHelper::GetDate(DHD_TOMORROW);
		break;

	case FT_DUEENDTHISWEEK:
		dateDue = CDateHelper::GetDate(DHD_ENDTHISWEEK);
		break;

	case FT_DUEENDNEXTWEEK: 
		dateDue = CDateHelper::GetDate(DHD_ENDNEXTWEEK);
		break;

	case FT_DUEENDTHISMONTH:
		dateDue = CDateHelper::GetDate(DHD_ENDTHISMONTH);
		break;

	case FT_DUEENDNEXTMONTH:
		dateDue = CDateHelper::GetDate(DHD_ENDNEXTMONTH);
		break;

	case FT_DUEENDTHISYEAR:
		dateDue = CDateHelper::GetDate(DHD_ENDTHISYEAR);
		break;

	case FT_DUEENDNEXTYEAR:
		dateDue = CDateHelper::GetDate(DHD_ENDNEXTYEAR);
		break;

	default:
		ASSERT(0);
		break;
	}
}

BOOL CFilteredToDoCtrl::DeleteSelectedTask(BOOL bWarnUser, BOOL bResetSel)
{
	BOOL bDel = CToDoCtrl::DeleteSelectedTask(bWarnUser, bResetSel);

	if (bDel && InListView())
	{
		// work out what to select
		DWORD dwSelID = GetSelectedTaskID();
		int nSel = FindTask(dwSelID);

		if (nSel == -1 && m_list.GetItemCount())
			nSel = 0;

		SelectTask(m_list.GetItemData(nSel));
	}

	return bDel;
}

BOOL CFilteredToDoCtrl::SelectedTasksHaveChildren() const
{
	return CToDoCtrl::SelectedTasksHaveChildren();
}

TODOITEM* CFilteredToDoCtrl::NewTask(HTREEITEM htiParent)
{
	TODOITEM* pTDI = CToDoCtrl::NewTask(htiParent);

	// fiddle with the default attributes so that the task 
	// will not be filtered out by the current filter
	if (InListView() && HasFilter())
	{
		if (m_filter.nRisk != FT_ANYRISK)
			pTDI->nRisk = max(pTDI->nRisk, m_filter.nRisk);

		if (m_filter.nPriority != FT_ANYPRIORITY)
			pTDI->nPriority = max(pTDI->nPriority, m_filter.nPriority);

		if (!m_filter.sAllocBy.IsEmpty() && pTDI->sAllocBy.IsEmpty())
			pTDI->sAllocBy = m_filter.sAllocBy;

		if (!m_filter.MatchAllocTo(pTDI->aAllocTo))
		{
			// if any category will match then set it to the first
			if (m_filter.HasFlag(FT_ANYALLOCTO))
			{
				pTDI->aAllocTo.RemoveAll();

				if (m_filter.aAllocTo.GetSize())
					pTDI->aAllocTo.Add(m_filter.aAllocTo[0]);
			}
			else // set it to all the filter cats
				pTDI->aAllocTo.Copy(m_filter.aAllocTo);
		}

		if (!m_filter.sStatus.IsEmpty() && pTDI->sStatus.IsEmpty())
			pTDI->sStatus = m_filter.sStatus;

		if (!m_filter.MatchCategories(pTDI->aCategories))
		{
			// if any category will match then set it to the first
			if (m_filter.HasFlag(FT_ANYCATEGORY))
			{
				pTDI->aCategories.RemoveAll();

				if (m_filter.aCategories.GetSize())
					pTDI->aCategories.Add(m_filter.aCategories[0]);
			}
			else // set it to all the filter cats
				pTDI->aCategories.Copy(m_filter.aCategories);
		}

		// if the filter is FT_DONE then complete the task
		switch (m_filter.nFilter)
		{
		case FT_ALL:
		case FT_NOTDONE:
			break;
		case FT_FLAGGED:
			pTDI->bFlagged = TRUE;
			break;
			
		case FT_DONE:
			pTDI->dateDone = floor(COleDateTime::GetCurrentTime());
			break;
			
		case FT_STARTTODAY:
		case FT_STARTENDTHISWEEK:
			pTDI->dateStart = floor(COleDateTime::GetCurrentTime());
			break;
			
		case FT_DUETODAY:
		case FT_DUETOMORROW:
		case FT_DUEENDTHISWEEK:
		case FT_DUEENDNEXTWEEK: 
		case FT_DUEENDTHISMONTH:
		case FT_DUEENDNEXTMONTH:
		case FT_DUEENDTHISYEAR:
		case FT_DUEENDNEXTYEAR:
			pTDI->dateDue = floor(COleDateTime::GetCurrentTime());
			break;
			
		default:
			ASSERT(0);
			break;
		}
	}

	return pTDI;
}

HTREEITEM CFilteredToDoCtrl::NewTask(LPCTSTR szText, TDC_INSERTWHERE nWhere, 
									BOOL bSelect, BOOL bEditText)
{
	BOOL bWantEditText = bEditText;

	if (InListView())
		bEditText = FALSE;

	HTREEITEM htiNew = CToDoCtrl::NewTask(szText, nWhere, bSelect, bEditText);

	if (htiNew && InListView())
	{
		DWORD dwTaskID = GetTaskID(htiNew);

		// select that task
		SelectTask(dwTaskID);
		
		if (bWantEditText)
		{
			m_dwLastAddedID = dwTaskID;
			EditSelectedTask(TRUE);
		}
	}

	return htiNew;
}

void CFilteredToDoCtrl::SetModified(BOOL bMod, TDC_ATTRIBUTE nAttrib)
{
	if (bMod && ModNeedsRefilter(nAttrib))
		RefreshFilter();

	if (nAttrib == TDCA_DELETE)
		RemoveDeletedListItems();

	else if (InListView())
		m_list.Invalidate(FALSE);

	CToDoCtrl::SetModified(bMod, nAttrib);
}

BOOL CFilteredToDoCtrl::ModNeedsResort(TDC_ATTRIBUTE nModType) const
{
	BOOL bListNeedsResort = CToDoCtrl::ModNeedsResort(nModType, m_nListSortBy);
	BOOL bTreeNeedsResort = CToDoCtrl::ModNeedsResort(nModType, m_nSortBy);

	if (InListView())
	{
		m_bTreeNeedResort |= bTreeNeedsResort;
		return bListNeedsResort;
	}
	else // tree view
	{
		m_bListNeedResort |= bListNeedsResort;
		return bTreeNeedsResort;
	}
}

void CFilteredToDoCtrl::ResortSelectedTaskParents() 
{ 
	// do a full sort
	Resort();
}

TDC_SORTBY CFilteredToDoCtrl::GetSortBy() const 
{ 
	return InListView() ? m_nListSortBy : m_nSortBy; 
}

void CFilteredToDoCtrl::Resort() 
{ 
	if (InListView())
		Sort(m_nListSortBy);
	else
		CToDoCtrl::Sort(m_nSortBy); 
}

void CFilteredToDoCtrl::SetModified(BOOL bMod)
{
	if (!IsReadOnly())
	{
		CToDoCtrl::SetModified(bMod);
		m_bListModSinceLastSort |= bMod;
	}
}

BOOL CFilteredToDoCtrl::ModNeedsRefilter(TDC_ATTRIBUTE nModType) const
{
	BOOL bNeedRefilter = FALSE;

	switch (nModType)
	{
	case TDCA_PRIORITY:		
		bNeedRefilter = (m_filter.nPriority != -1); 
		break;

	case TDCA_FLAG:		
		bNeedRefilter = (m_filter.nFilter == FT_FLAGGED); 
		break;

	case TDCA_RISK:			
		bNeedRefilter = (m_filter.nRisk != -1);
		break;
		
	case TDCA_ALLOCBY:		
		bNeedRefilter = (!m_filter.sAllocBy.IsEmpty());
		break;

	case TDCA_STATUS:		
		bNeedRefilter = (!m_filter.sStatus.IsEmpty());
		break;

	case TDCA_CATEGORY:		
		bNeedRefilter = (m_filter.aCategories.GetSize());
		break;

	case TDCA_ALLOCTO:		
		bNeedRefilter = (m_filter.aAllocTo.GetSize());
		break;

	case TDCA_PERCENT:
	case TDCA_DONEDATE:		
		bNeedRefilter = (m_filter.nFilter == FT_DONE || 
						m_filter.nFilter == FT_NOTDONE);
		break;
		
	case TDCA_DUEDATE:		
		bNeedRefilter = (m_filter.nFilter != FT_DONE &&
						m_filter.nFilter != FT_NOTDONE &&
						m_filter.nFilter != FT_ALL &&
						m_filter.nFilter != FT_STARTTODAY &&
						m_filter.nFilter != FT_STARTENDTHISWEEK);
		break;

	case TDCA_STARTDATE:		
		bNeedRefilter = (m_filter.nFilter == FT_STARTTODAY ||
						m_filter.nFilter == FT_STARTENDTHISWEEK);
		break;

	case TDCA_NEWTASK:
	case TDCA_UNDO:
		bNeedRefilter = TRUE;
		break;

	case TDCA_MOVE:
		bNeedRefilter = (!IsSortable());
		break;
	}

	if (!InListView())
	{
		m_bNeedRefilter |= bNeedRefilter; // don't override existing need
		bNeedRefilter = FALSE;
	}

	return bNeedRefilter;
}

BOOL CFilteredToDoCtrl::IsTaskDone(DWORD dwTaskID) const
{
	return CToDoCtrl::IsTaskDone(dwTaskID);
}

BOOL CFilteredToDoCtrl::HasTask(DWORD dwTaskID)
{
	return CToDoCtrl::HasTask(dwTaskID);
}

BOOL CFilteredToDoCtrl::SelectTask(DWORD dwTaskID)
{
	BOOL bRes = CToDoCtrl::SelectTask(dwTaskID);

	// check task has not been filtered out
	if (InListView())
	{
		int nItem = FindTask(dwTaskID);

		if (nItem == -1)
			return FALSE;
		
		// remove focused state from existing task
		int nFocus = m_list.GetNextItem(-1, LVNI_FOCUSED | LVNI_SELECTED);

		if (nFocus != -1)
			m_list.SetItemState(nFocus, 0, LVIS_SELECTED | LVIS_FOCUSED);

		m_list.SetItemState(nItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
		m_list.EnsureVisible(nItem, FALSE);
	}

	return bRes;
}

LRESULT CFilteredToDoCtrl::OnEditCancel(WPARAM wParam, LPARAM lParam)
{
	int nDelItem = -1;

	// check if we need to delete the just added item
	if (InListView() && GetSelectedTaskID() == m_dwLastAddedID)
		nDelItem = GetFirstSelectedItem();

	LRESULT lr = CToDoCtrl::OnEditCancel(wParam, lParam);

	// delete the item
	if (nDelItem != -1)
		m_list.DeleteItem(nDelItem);

	return lr;
}

int CFilteredToDoCtrl::FindTask(DWORD dwTaskID) const
{
	LVFINDINFO lvfi;
	ZeroMemory(&lvfi, sizeof(lvfi));

    lvfi.flags = LVFI_PARAM;
    lvfi.lParam = dwTaskID;
    lvfi.vkDirection = VK_DOWN;

	return m_list.FindItem(&lvfi);
}

DWORD CFilteredToDoCtrl::GetFocusedListTaskID() const
{
	int nItem = m_list.GetNextItem(-1, LVNI_FOCUSED | LVNI_SELECTED);

	if (nItem != -1)
		return m_list.GetItemData(nItem);

	// else
	return 0;
}

BOOL CFilteredToDoCtrl::UndoLastAction(BOOL bUndo)
{
	if (CToDoCtrl::UndoLastAction(bUndo))
	{
		if (InListView()) // refresh selection
			ResyncListSelection();
		
		return TRUE;
	}

	return FALSE;
}

void CFilteredToDoCtrl::SetSelectedListTasks(const CDWordArray& aTaskIDs, DWORD dwFocusedTaskID)
{
	for (int nTask = 0; nTask < aTaskIDs.GetSize(); nTask++)
	{
		DWORD dwTaskID = aTaskIDs[nTask];
		int nItem = FindTask(dwTaskID);

		if (nItem != -1)
		{
			if (dwTaskID == dwFocusedTaskID)
				m_list.SetItemState(nItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
			else
				m_list.SetItemState(nItem, LVIS_SELECTED, LVIS_SELECTED);
		}
		else // deselect in tree
		{
			HTREEITEM hti = m_data.GetItem(dwTaskID);
			Selection().SetItem(hti, TSHS_DESELECT, FALSE);
		}
	}

	// focused item
	if (dwFocusedTaskID)
	{
		int nItem = FindTask(dwFocusedTaskID);

		if (nItem != -1)
			m_list.SetItemState(nItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
	}

	// Make sure we have at least one task selected
/*
	if (!m_list.GetFirstSelectedItemPosition() && m_list.GetItemCount())
	{
		m_list.SetItemState(0, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
		
		HTREEITEM hti = m_data.GetItem(m_list.GetItemData(0));

		Selection().RemoveAll();
		Selection().SetItem(hti, TSHS_SELECT, FALSE);
		m_tree.SelectItem(hti);
	}
*/
}

LRESULT CFilteredToDoCtrl::OnGutterWidthChange(WPARAM wParam, LPARAM lParam)
{
	CToDoCtrl::OnGutterWidthChange(wParam, lParam);

	// update column widths if in list view
	if (InListView())
		UpdateColumnWidths();
	
	return 0;
}

void CFilteredToDoCtrl::OnListSelChanged(NMHDR* /*pNMHDR*/, LRESULT* pResult)
{
/*
	if (!m_bResyncingSel)
		TRACE ("CFilteredToDoCtrl::OnListSelChanged\n");

	LPNMLISTVIEW lpLV = (LPNMLISTVIEW)pNMHDR;

	if (!m_bResyncingSel && (lpLV->uChanged & LVIF_STATE))
	{
		TRACE ("CFilteredToDoCtrl::OnListSelChanged\n");

		CHoldRedraw hr(GetSafeHwnd());
		CHoldRedraw hr2(m_list);

		BOOL bSelected = (lpLV->uNewState & LVIS_SELECTED);
		BOOL bWasSelected = (lpLV->uOldState & LVIS_SELECTED);

		if (bSelected != bWasSelected)
		{
			HTREEITEM hti = m_data.GetItem(lpLV->lParam);
			Selection().SetItem(hti, bSelected ? TSHS_SELECT : TSHS_DESELECT, FALSE);

			if (m_list.GetSelectedCount() == 1)
				m_tree.SelectItem(hti);
		}

		// look through the tree selection and deselect any items not 
		// found in the list
		CDWordArray aTaskIDs;
		DWORD dwFocusedTaskID;

		GetSelectedTaskIDs(aTaskIDs, dwFocusedTaskID, FALSE);

		for (int nID = 0; nID < aTaskIDs.GetSize(); nID++)
		{
			DWORD dwID = aTaskIDs[nID];

			if (FindTask(dwID) == -1) 
			{
				HTREEITEM hti = m_data.GetItem(dwID);
				Selection().SetItem(hti, TSHS_DESELECT, FALSE);
			}
		}

		UpdateControls();
	}

*/

	*pResult = 0;
}

void CFilteredToDoCtrl::ClearListSelection()
{
	CHoldRedraw hr2(m_list);

	POSITION pos = m_list.GetFirstSelectedItemPosition();

	while (pos)
	{
		int nItem = m_list.GetNextSelectedItem(pos);
		m_list.SetItemState(nItem, 0, LVIS_SELECTED);
	}
}

int CFilteredToDoCtrl::GetFirstSelectedItem() const
{
	return m_list.GetNextItem(-1, LVNI_SELECTED);
}

int CFilteredToDoCtrl::GetSelectedListTaskIDs(CDWordArray& aTaskIDs, DWORD& dwFocusedTaskID) const
{
	aTaskIDs.RemoveAll();
	aTaskIDs.SetSize(m_list.GetSelectedCount());

	int nCount = 0;
	POSITION pos = m_list.GetFirstSelectedItemPosition();

	while (pos)
	{
		int nItem = m_list.GetNextSelectedItem(pos);

		aTaskIDs[nCount] = m_list.GetItemData(nItem);
		nCount++;
	}

	dwFocusedTaskID = GetFocusedListTaskID();

	return aTaskIDs.GetSize();
}

BOOL CFilteredToDoCtrl::SetTreeFont(HFONT hFont)
{
	CToDoCtrl::SetTreeFont(hFont);

	if (m_list.GetSafeHwnd())
	{
		if (!hFont) // set to our font
		{
			// for some reason i can not yet explain, our font
			// is not correctly set so we use our parent's font instead
			// hFont = (HFONT)SendMessage(WM_GETFONT);
			hFont = (HFONT)GetParent()->SendMessage(WM_GETFONT);
		}

		HFONT hListFont = (HFONT)m_list.SendMessage(WM_GETFONT);
		BOOL bChange = (hFont != hListFont || !Misc::SameFontNameSize(hFont, hListFont));

		if (bChange)
		{
			m_list.SendMessage(WM_SETFONT, (WPARAM)hFont, TRUE);
			RemeasureList();
		}
	}

	return TRUE;
}

void CFilteredToDoCtrl::OnListClick(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMIA = (LPNMITEMACTIVATE)pNMHDR;
//	TRACE ("CFilteredToDoCtrl::OnListClick\n");

	UpdateTreeSelection();

	if (pNMIA->iItem != -1) // validate item
	{
		int nHit = pNMIA->iItem;
		TDC_COLUMN nCol = GetColumnID(pNMIA->iSubItem);
		DWORD dwClickID = m_list.GetItemData(nHit);
		HTREEITEM htiHit = m_data.GetItem(dwClickID);

		BOOL bCtrl = Misc::ModKeysArePressed(MKS_CTRL);
		
		// column specific handling
		switch (nCol)
		{
		case TDCC_CLIENT:
			if (dwClickID == m_dw2ndClickItem)
				m_list.PostMessage(LVM_EDITLABEL);
			else
			{
				CRect rCheck;
								
				if (GetItemTitleRect(nHit, TDCTR_CHECKBOX, rCheck))
				{
					CPoint ptHit(::GetMessagePos());
					m_list.ScreenToClient(&ptHit);

					if (rCheck.PtInRect(ptHit))
					{
						BOOL bDone = m_data.IsTaskDone(htiHit);
						SetSelectedTaskDone(!bDone);
					}
				}
			}
			break;
			
		case TDCC_FILEREF:
			if (bCtrl)
			{
				CString sFile = m_data.GetTaskFileRef(dwClickID);
				
				if (!sFile.IsEmpty())
					GotoFile(sFile, TRUE);
			}
			break;
			
		case TDCC_DEPENDENCY:
			if (bCtrl)
			{
				CStringArray aDepends;
				m_data.GetTaskDependencies(dwClickID, aDepends);
				
				if (aDepends.GetSize())
					ShowTaskLink(0, aDepends[0]);
			}
			break;
			
		case TDCC_TRACKTIME:
			if (!IsReadOnly())
			{
				if (GetSelectedCount() == 1 && IsItemSelected(nHit) && 
					m_data.IsTaskTimeTrackable(htiHit))
				{
					TimeTrackTask(htiHit);
					m_list.RedrawItems(nHit, nHit);
				}
			}
			break;
			
		case TDCC_DONE:
			if (!IsReadOnly())
				SetSelectedTaskDone(!m_data.IsTaskDone(htiHit));
			break;
			
		case TDCC_FLAG:
			if (!IsReadOnly())
			{
				BOOL bFlagged = m_data.IsTaskFlagged(dwClickID);
				SetSelectedTaskFlag(!bFlagged);
			}
			break;
		}
	}

	m_dw2ndClickItem = 0;
	
	*pResult = 0;
}

void CFilteredToDoCtrl::OnListDblClick(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMIA = (LPNMITEMACTIVATE)pNMHDR;

	if (pNMIA->iItem != -1) // validate item
	{
		DWORD dwTaskID = GetTaskID(pNMIA->iItem);
		TDC_COLUMN nCol = GetColumnID(pNMIA->iSubItem);
		
		switch (nCol)
		{
		case TDCC_CLIENT:
			{
				// did they double click the label?
				CPoint ptHit(::GetMessagePos());
				m_list.ScreenToClient(&ptHit);
				
				CRect rLabel;
				CClientDC dc(&m_list);
				GetItemTitleRect(pNMIA->iItem, TDCTR_LABEL, rLabel, &dc, GetSelectedTaskTitle());
				
				if (rLabel.PtInRect(ptHit))
					m_list.PostMessage(LVM_EDITLABEL);
			}

		case TDCC_FILEREF:
			{
				CString sFile = m_data.GetTaskFileRef(dwTaskID);
				
				if (!sFile.IsEmpty())
					GotoFile(sFile, TRUE);
			}
			break;
			
		case TDCC_DEPENDENCY:
			{
				CStringArray aDepends;
				m_data.GetTaskDependencies(dwTaskID, aDepends);
				
				if (aDepends.GetSize())
					ShowTaskLink(0, aDepends[0]);
			}
			break;
						
		case TDCC_RECURRENCE:
			m_eRecurrence.DoEdit();
			break;
		}
	}
	
	*pResult = 0;
}

void CFilteredToDoCtrl::OnListKeyDown(NMHDR* /*pNMHDR*/, LRESULT* pResult)
{
	// for reasons I have not yet divined, we are not receiving this message
	// as expected. So I've added an ASSERT(0) should it ever come to life
	// and have handled the key down message in ScWindowProc
	//LPNMKEY pNMK = (LPNMKEY)pNMHDR;
	ASSERT(0);
//	TRACE ("CFilteredToDoCtrl::OnListKeyDown\n");
//	UpdateTreeSelection();

	*pResult = 0;
}

BOOL CFilteredToDoCtrl::PtInHeader(CPoint ptScreen) const
{
	if (InListView())
	{
		CRect rHeader;
		m_header.GetWindowRect(rHeader);
		
		return rHeader.PtInRect(ptScreen);
	}

	// else
	return CToDoCtrl::PtInHeader(ptScreen);
}

void CFilteredToDoCtrl::Sort(TDC_SORTBY nBy, BOOL bAllowToggle)
{
	if (!InListView())
	{
		CToDoCtrl::Sort(nBy, bAllowToggle);
		return;
	}
	
	if (nBy == TDC_UNSORTED || nBy == TDC_SORTDISABLED)
	{
		TDC_SORTBY nPrevBy = m_nListSortBy;
		m_nListSortBy = nBy;

		if (nPrevBy != TDC_UNSORTED)
		{
			RefreshFilter();
			UpdateColumnWidths();
		}
		
		return;
	}
	
	// else all the rest
	TDCCOLUMN* pTDCC = CToDoCtrl::GetColumn(nBy);
	ASSERT (pTDCC);
	
	if (!pTDCC)
		return;
	
	if (m_bListSortAscending == -1 || nBy != m_nListSortBy)
		m_bListSortAscending = pTDCC->bSortAscending;
	
	// if there's been a mod since last sorting then its reasonable to assume
	// that the user is not toggling direction but wants to simply resort
	// in the same direction.
	else if (bAllowToggle && !m_bListModSinceLastSort)
		m_bListSortAscending = !m_bListSortAscending;
	
	// do the sort using whatever we can out of CToDoCtrlData
	CHTIMap mapHTI;
	CTreeCtrlHelper(m_tree).BuildHTIMap(mapHTI);
	
	TDSORTSTRUCT ss = { &m_data, &mapHTI, nBy, m_bListSortAscending, FALSE };
	
	// sort this items children first
	m_list.SortItems(FTCCompareFunc, (DWORD)&ss);
	
	m_nListSortBy = nBy;
	m_bListModSinceLastSort = FALSE;
	
	// update registry
	SaveSortState(CPreferences());

	UpdateColumnWidths();
}

int CALLBACK CFilteredToDoCtrl::FTCCompareFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	TDSORTSTRUCT* pSS = (TDSORTSTRUCT*)lParamSort;
	
	// sort by id can be optimized since the IDs are the lParams
	if (pSS->nSortBy == TDC_SORTBYID)
		return (pSS->bAscending ? (lParam1 - lParam2) : (lParam2 - lParam1));
	
	// else all the rest require the task lookup
	TODOITEM* pTDI1 = pSS->pData->GetTask(lParam1);
	TODOITEM* pTDI2 = pSS->pData->GetTask(lParam2);
	
	HTREEITEM hti1 = NULL, hti2 = NULL;
	VERIFY(pSS->pMapHTItems->Lookup(lParam1, hti1) && hti1);
	VERIFY(pSS->pMapHTItems->Lookup(lParam2, hti2) && hti2);
	
	return pSS->pData->CompareTasks(pTDI1, hti1, pTDI2, hti2, pSS->nSortBy, pSS->bAscending);
}

BOOL CFilteredToDoCtrl::SplitSelectedTask(int nNumSubtasks) 
{ 
	return /*InListView() ? FALSE : */CToDoCtrl::SplitSelectedTask(nNumSubtasks);
}

BOOL CFilteredToDoCtrl::CanSplitSelectedTask() 
{ 
	return /*InListView() ? FALSE : */CToDoCtrl::CanSplitSelectedTask();
}

BOOL CFilteredToDoCtrl::MoveSelectedTask(TDC_MOVETASK nDirection) 
{ 
	return InListView() ? FALSE : CToDoCtrl::MoveSelectedTask(nDirection); 
}

BOOL CFilteredToDoCtrl::CanMoveSelectedTask(TDC_MOVETASK nDirection) const 
{ 
	return InListView() ? FALSE : CToDoCtrl::CanMoveSelectedTask(nDirection); 
}

BOOL CFilteredToDoCtrl::GotoNextTask(TDC_GOTO nDirection)
{
	if (InListView() && CanGotoNextTask(nDirection))
	{
		int nSel = GetFirstSelectedItem();

		if (nDirection == TDCG_NEXT)
			nSel++;
		else
			nSel--;

		return SelectTask(m_list.GetItemData(nSel));
	}
	
	// else
	return CToDoCtrl::GotoNextTask(nDirection);
}

CRect CFilteredToDoCtrl::GetSelectedItemsRect() const
{
	CRect rInvalid(0, 0, 0, 0), rItem;
	POSITION pos = m_list.GetFirstSelectedItemPosition();

	while (pos)
	{
		int nItem = m_list.GetNextSelectedItem(pos);

		if (m_list.GetItemRect(nItem, rItem, LVIR_BOUNDS))
			rInvalid |= rItem;
	}

	return rInvalid;
}

BOOL CFilteredToDoCtrl::CanGotoNextTask(TDC_GOTO nDirection) const
{
	if (InListView())
	{
		int nSel = GetFirstSelectedItem();

		if (nDirection == TDCG_NEXT)
			return (nSel >= 0 && nSel < m_list.GetItemCount() - 1);
		
		// else prev
		return (nSel > 0 && nSel <= m_list.GetItemCount() - 1);
	}
	else
		return CToDoCtrl::CanGotoNextTask(nDirection);
}

BOOL CFilteredToDoCtrl::GotoNextTopLevelTask(TDC_GOTO nDirection)
{
	if (InListView())
		return FALSE; // not supported

	// else
	return CToDoCtrl::GotoNextTopLevelTask(nDirection);
}

BOOL CFilteredToDoCtrl::CanGotoNextTopLevelTask(TDC_GOTO nDirection) const
{
	return InListView() ? FALSE : CToDoCtrl::CanGotoNextTopLevelTask(nDirection);
}

BOOL CFilteredToDoCtrl::CanExpandSelectedTask(BOOL bExpand) const 
{ 
	return InListView() ? FALSE : CToDoCtrl::CanExpandSelectedTask(bExpand);
}

void CFilteredToDoCtrl::ExpandSelectedTask(BOOL bExpand)
{
	if (InListView())
		return; // not supported

	CToDoCtrl::ExpandSelectedTask(bExpand);
}

void CFilteredToDoCtrl::ExpandAllTasks(BOOL bExpand)
{
	if (InListView())
		return; // not supported

	CToDoCtrl::ExpandAllTasks(bExpand);
}

void CFilteredToDoCtrl::SetFocusToTasks()
{
	if (InListView())
		m_list.SetFocus();

	else
		CToDoCtrl::SetFocusToTasks();
}

BOOL CFilteredToDoCtrl::TasksHaveFocus() const
{ 
	if (InListView())
		return (::GetFocus() == m_list);

	return CToDoCtrl::TasksHaveFocus(); 
}

void CFilteredToDoCtrl::SelectNextTasksInHistory()
{
	if (InListView() && CanSelectNextTasksInHistory())
	{
		// let CToDoCtrl do it's thing
		CToDoCtrl::SelectNextTasksInHistory();

		// then update our own selection
		ResyncListSelection();
	}
	else
		CToDoCtrl::SelectNextTasksInHistory();
}

void CFilteredToDoCtrl::ResyncListSelection()
{
//	CAutoFlag af(m_bResyncingSel, TRUE);
	ClearListSelection();
		
	// then update our own selection
	CDWordArray aTreeTaskIDs;
	DWORD dwFocusedID;
	
	GetSelectedTaskIDs(aTreeTaskIDs, dwFocusedID, FALSE);
	SetSelectedListTasks(aTreeTaskIDs, dwFocusedID);
	
	// now check that the tree is synced with us!
	CDWordArray aListTaskIDs;
	GetSelectedListTaskIDs(aListTaskIDs, dwFocusedID);
	
	if (!Misc::ArraysMatch(aListTaskIDs, aTreeTaskIDs))
		CToDoCtrl::MultiSelectItems(aListTaskIDs, TSHS_SELECT, FALSE);
}


void CFilteredToDoCtrl::SelectPrevTasksInHistory()
{
	if (InListView() && CanSelectPrevTasksInHistory())
	{
		// let CToDoCtrl do it's thing
		CToDoCtrl::SelectPrevTasksInHistory();

		// then update our own selection
		ResyncListSelection();
	}
	else
		CToDoCtrl::SelectPrevTasksInHistory();
}

void CFilteredToDoCtrl::InvalidateItem(HTREEITEM hti)
{
	if (InListView())
	{
		int nItem = GetListItem(hti);
		CRect rItem;

		if (GetItemTitleRect(nItem, TDCTR_BOUNDS, rItem))
			m_list.InvalidateRect(rItem, TRUE);
	}
	else
		CToDoCtrl::InvalidateItem(hti);
}

LRESULT CFilteredToDoCtrl::ScWindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case WM_RBUTTONDOWN:
		{
			// work out what got hit and make sure it's selected
			CPoint ptHit(lp);
			LVHITTESTINFO lvhti = { { ptHit.x, ptHit.y }, 0, 0, 0 };

			int nHit = m_list.HitTest(&lvhti);

			if (!IsItemSelected(nHit))
				SelectTask(GetTaskID(nHit));
		}
		break;

	case WM_LBUTTONDOWN:
		{
			// work out what got hit
			CPoint ptHit(lp);
			LVHITTESTINFO lvhti = { { ptHit.x, ptHit.y }, 0, 0, 0 };

			m_list.SubItemHitTest(&lvhti);
			int nHit = lvhti.iItem;

			if (nHit != -1 && !IsReadOnly())
			{
				TDC_COLUMN nCol = GetColumnID(lvhti.iSubItem);
				HTREEITEM htiHit = GetTreeItem(nHit);

				// if the user is clicking on an already multi-selected
				// item since we may need to carry out an operation on multiple items
				int nSelCount = GetSelectedCount();

				if (nSelCount > 1 && IsItemSelected(nHit))
				{
					switch (nCol)
					{
					case TDCC_DONE:
						{
							BOOL bDone = m_data.IsTaskDone(htiHit);
							SetSelectedTaskDone(!bDone);
							return 0; // eat it
						}
						break;

					case TDCC_CLIENT:
						{
							CRect rCheck;

							if (GetItemTitleRect(nHit, TDCTR_CHECKBOX, rCheck) && rCheck.PtInRect(ptHit))
							{
								BOOL bDone = m_data.IsTaskDone(htiHit);
								SetSelectedTaskDone(!bDone);
								return 0; // eat it
							}
						}
						break;
						
					case TDCC_FLAG:
						{
							BOOL bFlagged = m_data.IsTaskFlagged(GetTaskID(htiHit));
							SetSelectedTaskFlag(!bFlagged);
							return 0; // eat it
						}
						break;
					}
				}
				else if (nSelCount == 1)
				{
					// if the click was on the task title of an already singly selected item
					// we record the task ID unless the control key is down in which case
					// it really means that the user has deselected the item
					if (!Misc::ModKeysArePressed(MKS_CTRL))
					{
						m_dw2ndClickItem = 0;
						
						int nSel = GetFirstSelectedItem();
						if (nHit != -1 && nHit == nSel && nCol == TDCC_CLIENT)
						{
							// unfortunately we cannot rely on the flags attribute of LVHITTESTINFO
							// to see if the user clicked on the text because LVIR_LABEL == LVIR_BOUNDS
							CRect rLabel;
							CClientDC dc(&m_list);
							CFont* pOld = NULL;

							if (m_tree.GetParentItem(GetTreeItem(nHit)) == NULL) // top level items
								pOld = (CFont*)dc.SelectObject(CFont::FromHandle(m_fontBold));
							else
								pOld = (CFont*)dc.SelectObject(m_list.GetFont());

							GetItemTitleRect(nHit, TDCTR_LABEL, rLabel, &dc, GetSelectedTaskTitle());
			
							if (rLabel.PtInRect(ptHit))
								m_dw2ndClickItem = m_list.GetItemData(nHit);

							// cleanup
							dc.SelectObject(pOld);
						}

						// note: we handle WM_LBUTTONUP in OnListClick() to 
						// decide whether to do a label edit
					}
				}
			}

			// because the visual state of the list selection is actually handled by
			// whether the tree selection is up to date we need to update the tree
			// selection here, because the list ctrl does it this way natively.
			LRESULT	lr = CSubclasser::ScWindowProc(hRealWnd, msg, wp, lp);
			UpdateTreeSelection();

			return lr;
		}
		break;

	case LVM_EDITLABEL:
		if (!IsReadOnly())
			EditSelectedTask(FALSE);
		return 0; // eat it

	case WM_KEYDOWN:
		{
			// if any of the cursor keys are used and nothing is currently selected
			// then we select the top/bottom item and ignore the default list ctrl processing
			LRESULT lr = 0;

			if (GetSelectedCount() == 0 && Misc::IsCursorKey(wp))
			{
				int nNumItems = m_list.GetItemCount();

				if (nNumItems > 0)
				{
					int nSelItem = 0; // top item is default

					if (wp == VK_UP || wp == VK_PRIOR)
						nSelItem = nNumItems - 1; // bottom item

					m_list.SetItemState(nSelItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
				}
			}
			else
				lr = CSubclasser::ScWindowProc(hRealWnd, msg, wp, lp);

			UpdateTreeSelection();
			return lr;
		}
		break;

	case WM_KEYUP:
		if (Misc::IsCursorKey(wp))
			UpdateControls();
		break;

	case WM_MOUSEWHEEL:
	case WM_VSCROLL:
	case WM_HSCROLL:
		if (InListView() && IsTaskLabelEditing())
			EndLabelEdit(FALSE);

		// extra processing for WM_HSCROLL
		if (msg == WM_HSCROLL && InListView())
			m_header.Invalidate(FALSE);
		
		break;

		
	case WM_NOTIFY:
		{
			LPNMHDR pNMHDR = (LPNMHDR)lp;
			
			switch (pNMHDR->code)
			{
			case NM_CUSTOMDRAW:
				// We must forward on 
				if (pNMHDR->hwndFrom == m_header)
				{
					LRESULT lr = 0;
					OnHeaderCustomDraw(pNMHDR, &lr);
					return lr;
				}
				break;

/*
			case TTN_SHOW:
				{
					CWnd* pTooltipCtrl = CWnd::FromHandle(pNMHDR->hwndFrom);
					ASSERT (pTooltipCtrl);

					// only handle tooltips not infotips
					if (!HasStyle(TDCS_SHOWINFOTIPS))
					{
						// move the tooltip to the client column
						CRect rTooltip, rTitle;
						GetItemTitleRect(0, TDCTR_LABEL, rTitle); // we're only interested in the horz
						m_list.ClientToScreen(rTitle);

						pTooltipCtrl->GetWindowRect(rTooltip);
						pTooltipCtrl->SetWindowPos(NULL, rTitle.left, rTooltip.top, 0, 0, 
													SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);

						//return TRUE;
					}
				}
				break;
*/
			}
		}
		break;
	}

	return CSubclasser::ScWindowProc(hRealWnd, msg, wp, lp);
}

void CFilteredToDoCtrl::UpdateTreeSelection()
{
	// update the tree selection if it needs to be
	CDWordArray aListTaskIDs, aTreeTaskIDs;
	DWORD dwFocusedID;

	GetSelectedTaskIDs(aTreeTaskIDs, dwFocusedID, FALSE);
	GetSelectedListTaskIDs(aListTaskIDs, dwFocusedID);
	
	if (!Misc::ArraysMatch(aTreeTaskIDs, aListTaskIDs))
	{
		MultiSelectItems(aListTaskIDs, TSHS_SELECT, FALSE);
		m_list.Invalidate(FALSE);
	}
}

BOOL CFilteredToDoCtrl::IsItemSelected(int nItem) const
{
	HTREEITEM hti = GetTreeItem(nItem);
	return hti ? Selection().HasItem(hti) : FALSE;
}

HTREEITEM CFilteredToDoCtrl::GetTreeItem(int nItem) const
{
	if (nItem < 0 || nItem >= m_list.GetItemCount())
		return NULL;

	DWORD dwID = m_list.GetItemData(nItem);
	return m_data.GetItem(dwID);
}

int CFilteredToDoCtrl::GetListItem(HTREEITEM hti) const
{
	DWORD dwID = GetTaskID(hti);
	return (dwID ? FindTask(dwID) : -1);
}

BOOL CFilteredToDoCtrl::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	if (&m_list == pWnd)
	{
		CPoint pt(::GetMessagePos());
		m_list.ScreenToClient(&pt);

		LVHITTESTINFO lvhti = { { pt.x, pt.y }, 0, 0, 0 };
		m_list.SubItemHitTest(&lvhti);

		int nHit = lvhti.iItem;

		if (nHit >= 0)
		{
			TDC_COLUMN nCol	= GetColumnID(lvhti.iSubItem);
			HTREEITEM htiHit = GetTreeItem(nHit);
			DWORD dwID = m_list.GetItemData(nHit);

			BOOL bCtrl = Misc::ModKeysArePressed(MKS_CTRL);
			BOOL bShowHand = FALSE;

			switch (nCol)
			{
			case TDCC_FILEREF:
				if (bCtrl)
				{
					CString sFile = m_data.GetTaskFileRef(dwID);
					bShowHand = (!sFile.IsEmpty());
				}
				break;
				
			case TDCC_DEPENDENCY:
				if (bCtrl)
				{
					CStringArray aDepends;
					m_data.GetTaskDependencies(dwID, aDepends);
					bShowHand = aDepends.GetSize();
				}
				break;
				
			case TDCC_TRACKTIME:
				if (!IsReadOnly())
				{
					bShowHand = ((!IsItemSelected(nHit) || GetSelectedCount() == 1) && 
								 m_data.IsTaskTimeTrackable(htiHit));
				}
				break;
				
			case TDCC_FLAG:
				if (!IsReadOnly())
					bShowHand = TRUE;
			}

			if (bShowHand)
			{
				::SetCursor(Misc::HandCursor());
				return TRUE;
			}
		}
	}
		
	return CToDoCtrl::OnSetCursor(pWnd, nHitTest, message);
}

LRESULT CFilteredToDoCtrl::OnDropFileRef(WPARAM wParam, LPARAM lParam)
{
	int nItem = wParam;
	
	if (!InListView() || nItem == -1)
		return CToDoCtrl::OnDropFileRef(wParam, lParam);

	// else
	if (!IsReadOnly())
	{
		SelectTask(m_list.GetItemData(nItem));
		SetSelectedTaskFileRef((LPCTSTR)lParam);
	}
	
	return 0;
}

BOOL CFilteredToDoCtrl::GetItemTitleRect(HTREEITEM hti, TDC_TITLERECT nArea, CRect& rect) const
{
	if (InListView())
	{
		int nItem = GetListItem(hti);
		return GetItemTitleRect(nItem, nArea, rect);
	}

	// else
	return CToDoCtrl::GetItemTitleRect(hti, nArea, rect);
}

BOOL CFilteredToDoCtrl::GetItemTitleRect(int nItem, TDC_TITLERECT nArea, CRect& rect, CDC* pDC, LPCTSTR szTitle) const
{
	ASSERT (InListView());
	
	if (nItem == -1)
		return FALSE;

	// basic title rect
	int nColIndex = GetColumnIndex(TDCC_CLIENT);
	const_cast<CListCtrl*>(&m_list)->GetSubItemRect(nItem, nColIndex, LVIR_LABEL, rect);

	if (nColIndex == 0 && COSVersion() >= OSV_XP) // right side columns in XP
		rect.left -= 4;

	BOOL bFolder = HasStyle(TDCS_SHOWPARENTSASFOLDERS);
	BOOL bCheckbox = HasStyle(TDCS_TREECHECKBOXES) && !IsColumnShowing(TDCC_DONE);

	switch (nArea)
	{
	case TDCTR_CHECKBOX:
		if (bCheckbox)
		{
			rect.right = rect.left + 16;
			return TRUE;
		}
		break;

	case TDCTR_FOLDER:
		if (bFolder)
		{
			if (bCheckbox)
				rect.left += 18;

			rect.right = rect.left + 16;
			return TRUE;
		}
		break;
		
	case TDCTR_LABEL:
		{
			if (bFolder)
				rect.left += 18;

			if (bCheckbox)
				rect.left += 18;

			if (pDC && szTitle)
			{
				int nTextExt = pDC->GetTextExtent(szTitle).cx;
				rect.right = rect.left + min(rect.Width(), nTextExt + 6 + 1);
			}

			return TRUE;
		}
		break;

	case TDCTR_BOUNDS:
		return TRUE; // nothing more to do

	case TDCTR_EDIT:
		if (GetItemTitleRect(nItem, TDCTR_LABEL, rect)) // recursive call
		{
			// make sure it's at least 200 but always clipped to the client rect
//			rect.right = min(rect.right, rect.left + 200);
			
			CRect rClient, rInter;
			m_list.GetClientRect(rClient);
			
			if (rInter.IntersectRect(rect, rClient))
				rect = rInter;
			
			rect.top--;

			m_list.ClientToScreen(rect);
			ScreenToClient(rect);
			
			return TRUE;
		}
		break;
	}

	return FALSE;
}

void CFilteredToDoCtrl::OnListGetInfoTip(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMLVGETINFOTIP* pLVGIT = (NMLVGETINFOTIP*)pNMHDR;
	*pResult = 0;

	int nHit = pLVGIT->iItem;

	if (nHit >= 0)
	{
		HTREEITEM hti = GetTreeItem(nHit);
		TODOITEM* pTDI = GetTask(m_list.GetItemData(nHit));

		ASSERT (pTDI);

		if (!pTDI)
			return;

		// we only display info tips when over the task title
		CRect rTitle;
		CClientDC dc(&m_list);
		CFont* pOld = NULL;
		
		if (m_tree.GetParentItem(hti) == NULL) // top level item
			pOld = (CFont*)dc.SelectObject(CFont::FromHandle(m_fontBold));
		else
			pOld = (CFont*)dc.SelectObject(m_list.GetFont());
		
		GetItemTitleRect(nHit, TDCTR_LABEL, rTitle, &dc, pTDI->sTitle);
		
		// cleanup
		dc.SelectObject(pOld);
	
		CPoint pt(::GetMessagePos());
		m_list.ScreenToClient(&pt);
		
		if (rTitle.PtInRect(pt))
		{
			//fabio_2005
#if _MSC_VER >= 1400
			strncpy_s(pLVGIT->pszText, pLVGIT->cchTextMax, FormatInfoTip(hti, pTDI), pLVGIT->cchTextMax);
#else
			strncpy(pLVGIT->pszText, FormatInfoTip(hti, pTDI), pLVGIT->cchTextMax);
#endif
		}
	}
		
}

void CFilteredToDoCtrl::UpdateSelectedTaskPath()
{
	CToDoCtrl::UpdateSelectedTaskPath();

	// redraw the client column header
	if (m_header.GetSafeHwnd())
	{
		CRect rClient;

		if (m_header.GetItemRect(GetColumnIndex(TDCC_CLIENT), rClient))
			m_header.InvalidateRect(rClient, FALSE);
	}
}

void CFilteredToDoCtrl::SaveSortState(CPreferences& prefs)
{
	// ignore this if we have no tasks
	if (GetTaskCount() == 0)
		return;

	// create a new key using the filepath
	ASSERT (GetSafeHwnd());
	
	CString sKey = GetPreferencesKey("SortState");
	
	if (!sKey.IsEmpty())
	{
		prefs.WriteProfileInt(sKey, "ListColumn", m_nListSortBy);
		prefs.WriteProfileInt(sKey, "ListAscending", m_bListSortAscending);
	}

	// base class
	CToDoCtrl::SaveSortState(prefs);
}

void CFilteredToDoCtrl::LoadSortState(const CPreferences& prefs, LPCTSTR szFilePath)
{
	CString sKey = GetPreferencesKey("SortState", szFilePath);
	
	if (!sKey.IsEmpty())
	{
		// is this the first time since we restored tree sorting (disabled in 5.6)
		int nListSortBy = prefs.GetProfileInt(sKey, "ListColumn", -99);

		if (nListSortBy == -99) // yes
		{ 
			// so we use whatever the tree has set
			m_nListSortBy = (TDC_SORTBY)prefs.GetProfileInt(sKey, "Column", TDC_UNSORTED);
			m_bListSortAscending = prefs.GetProfileInt(sKey, "Ascending", TRUE);

			// and clear the tree's state
			m_nSortBy = TDC_UNSORTED;
			m_bSortAscending = -1;
		}
		else // each has separate settings
		{
			m_nListSortBy = (TDC_SORTBY)prefs.GetProfileInt(sKey, "ListColumn", TDC_UNSORTED);
			m_bListSortAscending = prefs.GetProfileInt(sKey, "ListAscending", TRUE);

			CToDoCtrl::LoadSortState(prefs, szFilePath);
		}
	}

	// update tree
	UpdateColumnHeaderClicking();
}

