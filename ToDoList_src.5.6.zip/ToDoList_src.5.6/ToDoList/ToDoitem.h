// ToDoCtrlData.h: interface for the CToDoCtrlData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TODOITEM_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_)
#define AFX_TODOITEM_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "tdcstruct.h"
#include <afxtempl.h>
#include "..\3rdparty\fixalloc.h" 

class TODOITEM
{
public:
	TODOITEM(LPCTSTR szTitle, LPCTSTR szComments = NULL); 
	TODOITEM(); 
	TODOITEM(const TODOITEM& tdi); 
	TODOITEM(const TODOITEM* pTDI); 
	
	const TODOITEM& operator=(const TODOITEM& tdi); 

	BOOL HasLastMod() const;
	BOOL HasCreation() const;
	BOOL HasStart() const;
	BOOL HasDue() const;
	BOOL HasDueTime() const;
	BOOL IsDone() const;
	
	void ClearStart();
	void ClearDue();
	void ClearDone();
	
	BOOL IsDue() const;
	BOOL IsDue(const COleDateTime& dateDueBy) const;
	
	void SetModified();
	void ResetCalcs() const; 

	CString GetFirstCategory() const;
	CString GetFirstAllocTo() const;
	CString GetFirstDependency() const;

	BOOL GetNextOccurence(COleDateTime& dtNext) const;
	BOOL IsRecentlyEdited(const COleDateTimeSpan& dtSpan = 1.0 / 24.0) const; // 1 hour default

	COleDateTimeSpan GetRemainingDueTime() const; // in days

	static COleDateTimeSpan GetRemainingDueTime(const COleDateTime& date); // in days
	static BOOL HasDueTime(const COleDateTime& date);

	//  ------------------------------------------
	
	CString sTitle;
	CString sComments, sCustomComments;
	CString sCommentsTypeID;
	COLORREF color;
	COleDateTime dateStart, dateDue, dateDone, dateCreated;
	int nPriority;
	double dCost;
	CStringArray aAllocTo;
	CString sAllocBy;
	CString sStatus;
	CStringArray aCategories;
	CString sCreatedBy;
	int nPercentDone;
	CString sFileRefPath;
	double dTimeEstimate, dTimeSpent;
	int nTimeEstUnits, nTimeSpentUnits;
	COleDateTime tLastMod;
	BOOL bFlagged;
	int nRisk;
	CString sExternalID;
	CStringArray aDependencies;
	TDIRECURRENCE trRecurrence;
	CString sVersion;
	
	// cached calculations for drawing optimization
	// mutable so that they can be updated in const methods
	mutable int nCalcPriority;
	mutable int nCalcPriorityIncDue;
	mutable int nCalcPercent;
	mutable int nCalcRisk;
	mutable double dCalcTimeEstimate, dCalcTimeSpent;
	mutable double dCalcCost;
	mutable COleDateTime dateEarliestDue;
	mutable BOOL bGoodAsDone, bDue;
	mutable int nSubtasksCount, nSubtasksDone;
	
	DECLARE_FIXED_ALLOC(TODOITEM);
};

#endif // !defined(AFX_TODOITEM_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_)
