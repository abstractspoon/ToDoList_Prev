// ToDoCtrlData.h: interface for the CToDoCtrlData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TODOCTRLDATA_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_)
#define AFX_TODOCTRLDATA_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "tdcstruct.h"
#include "tdcenum.h"
#include "todoctrlundo.h"
#include <afxtempl.h>

class TODOITEM;
class CToDoCtrlData;

typedef CMap<DWORD, DWORD, TODOITEM*, TODOITEM*&> CTDIMap;

// class to help start and end undo actions
class CUndoAction
{
public:
	CUndoAction(CToDoCtrlData& data, TDCUNDOACTIONTYPE nType = TDCUAT_EDIT);
	~CUndoAction();

protected:
	CToDoCtrlData& m_data;
	BOOL m_bSuccess;
};

#define IMPLEMENT_UNDO(op) CUndoAction ua(m_data, op)
#define IMPLEMENT_UNDOEDIT() CUndoAction ua(m_data, TDCUAT_EDIT)

class CToDoCtrlData  
{
public:
	CToDoCtrlData(CTreeCtrl& tree, const CWordArray& aStyles);
	virtual ~CToDoCtrlData();
	
	inline UINT GetTaskCount() const { return m_mapID2TDI.GetCount(); }
	DWORD GetTaskID(HTREEITEM hti) const;
	DWORD GetParentTaskID(HTREEITEM hti) const;
	
	HTREEITEM GetItem(DWORD dwID) const;
	
	TODOITEM* NewTask(const TODOITEM* pTDIRef = NULL);
	void AddTask(DWORD dwID, TODOITEM* pTDI, DWORD dwParentID, DWORD dwPrevSiblingID);
	TODOITEM* GetTask(DWORD dwID) const;
	TODOITEM* GetTask(HTREEITEM hti) const;
	void DeleteTask(DWORD dwID);
	BOOL DeleteTask(HTREEITEM hti);
	void DeleteAllTasks();

	HTREEITEM MoveTask(HTREEITEM hti, DWORD dwPrevSiblingID, HTREEITEM htiDestParent, HTREEITEM htiDestPrevSibling);

	// undo/redo
	BOOL BeginNewUndoAction(TDCUNDOACTIONTYPE nType);
	BOOL EndCurrentUndoAction();
	BOOL UndoLastAction(BOOL bUndo);
	BOOL CanUndoLastAction(BOOL bUndo) const;
	int GetLastUndoActionTaskIDs(BOOL bUndo, CDWordArray& aIDs) const;
	TDCUNDOACTIONTYPE GetLastUndoActionType(BOOL bUndo) const;
	BOOL DeleteLastUndoAction();

	// use only when this task does not provide a Set method eg. moving tasks
	void ClearUndo() { m_undo.ResetAll(); }

	double GetEarliestDueDate() const;
	
	void Sort(TDC_SORTBY nBy, BOOL bAscending, HTREEITEM htiRoot = NULL, BOOL bSortChildren = TRUE);
	void SetSortDueTodayHigh(BOOL bHigh);
	
	// Gets
	CString GetTaskTitle(DWORD dwID) const;
	COleDateTime GetTaskDate(DWORD dwID, TDC_DATE nDate) const;
	BOOL IsTaskDone(DWORD dwID) const;
	COLORREF GetTaskColor(DWORD dwID) const; // -1 on no item selected
	CString GetTaskComments(DWORD dwID) const;
	CString GetTaskCustomComments(DWORD dwID, CString& sCommentsTypeID) const;
	int GetTaskPercent(DWORD dwID, BOOL bCheckIfDone) const;
	double GetTaskTimeEstimate(DWORD dwID, int& nUnits) const;
	double GetTaskTimeSpent(DWORD dwID, int& nUnits) const;
	double GetTaskCost(DWORD dwID) const;
	int GetTaskAllocTo(DWORD dwID, CStringArray& aAllocTo) const;
	CString GetTaskAllocBy(DWORD dwID) const;
	CString GetTaskCreatedBy(DWORD dwID) const;
	CString GetTaskStatus(DWORD dwID) const;
	int GetTaskCategories(DWORD dwID, CStringArray& aCategories) const;
	int GetTaskDependencies(DWORD dwID, CStringArray& aDepends) const;
	CString GetTaskFileRef(DWORD dwID) const;
	CString GetTaskExtID(DWORD dwID) const;
	int GetTaskPriority(DWORD dwID) const;
	int GetTaskRisk(DWORD dwID) const;
	BOOL IsTaskFlagged(DWORD dwID) const;
	BOOL GetTaskRecurrence(DWORD dwID, TDIRECURRENCE& tr) const;
	BOOL GetTaskNextOccurrence(DWORD dwID, COleDateTime& dtNext) const;
	CString GetTaskVersion(DWORD dwID) const;

	COLORREF GetTaskColor(HTREEITEM hti) const;
	double GetTaskTimeEstimate(HTREEITEM hti, int& nUnits) const;
	double GetTaskTimeSpent(HTREEITEM hti, int& nUnits) const;
	int GetTaskPercent(HTREEITEM hti) const;
	int GetTaskAllocTo(HTREEITEM hti, CStringArray& aAllocTo) const;
	CString GetTaskAllocBy(HTREEITEM hti) const;
	CString GetTaskStatus(HTREEITEM hti) const;
	int GetTaskCategories(HTREEITEM hti, CStringArray& aCategories) const;
	int GetTaskDependencies(HTREEITEM hti, CStringArray& aDepends) const;
	CString GetTaskExtID(HTREEITEM hti) const;
	int GetTaskPriority(HTREEITEM hti) const;
	int GetTaskRisk(HTREEITEM hti) const;
	int GetItemPos(HTREEITEM hti, HTREEITEM htiSearch) const; // returns 0 if not found
	BOOL IsParentTaskDone(HTREEITEM hti) const; // this is recursive
	int AreChildTasksDone(HTREEITEM hti) const; // 1=yes, 0=no, -1=no children
	BOOL IsTaskFlagged(HTREEITEM hti) const;
	double GetTaskCost(HTREEITEM hti) const;
	COleDateTime GetTaskDate(HTREEITEM hti, TDC_DATE nDate) const;
	BOOL GetTaskRecurrence(HTREEITEM hti, TDIRECURRENCE& tr) const;
	CString GetTaskVersion(HTREEITEM hti) const;
	
	int GetTaskDependents(DWORD dwTaskID, CDWordArray& aDependents) const;
	int GetTaskDependencies(DWORD dwTaskID, CDWordArray& aDepends) const;
	BOOL TaskHasCircularDependencies(DWORD dwTaskID) const;

	BOOL IsTaskDue(HTREEITEM hti, BOOL bToday = FALSE) const;
	double GetEarliestDueDate(HTREEITEM hti, BOOL bCheckChildren) const;
	int GetHighestPriority(HTREEITEM hti, BOOL bIncludeDue = TRUE) const;
	int GetHighestRisk(HTREEITEM hti) const;
	int CalcPercentDone(HTREEITEM hti) const;
	double CalcCost(HTREEITEM hti) const;
	double CalcTimeEstimate(HTREEITEM hti, int nUnits) const;
	double CalcTimeSpent(HTREEITEM hti, int nUnits) const;
	BOOL GetSubtaskTotals(HTREEITEM hti, int& nSubtasksTotal, int& nSubtasksDone) const;
	CString GetItemPath(HTREEITEM hti, int nMaxLen = -1) const; 

	CString GetLongestVisibleExternalID() const;
	CString GetLongestVisibleCategory() const;
	CString GetLongestVisibleAllocTo() const;
	BOOL FindVisibleTaskWithDueTime() const;

	BOOL IsTaskDue(HTREEITEM hti, const TODOITEM* tdi, BOOL bToday = FALSE) const;
	double GetEarliestDueDate(HTREEITEM hti, const TODOITEM* pTDI, BOOL bCheckChildren) const;
	int GetHighestPriority(HTREEITEM hti, const TODOITEM* pTDI, BOOL bIncludeDue = TRUE) const;
	int GetHighestRisk(HTREEITEM hti, const TODOITEM* pTDI) const;
	double CalcCost(HTREEITEM hti, const TODOITEM* pTDI) const;
	double CalcTimeEstimate(HTREEITEM hti, const TODOITEM* pTDI, int nUnits) const;
	double CalcTimeSpent(HTREEITEM hti, const TODOITEM* pTDI, int nUnits) const;
	int CalcPercentDone(HTREEITEM hti, const TODOITEM* pTDI) const;
	int CalcPercentFromTime(HTREEITEM hti, const TODOITEM* pTDI) const; // spent / estimate
	BOOL GetSubtaskTotals(HTREEITEM hti, const TODOITEM* pTDI, 
							int& nSubtasksTotal, int& nSubtasksDone) const;
	
	// Sets. 0 = failed, 1 = success, -1 = success (no change)
	int SetTaskDate(DWORD dwID, TDC_DATE nDate, const COleDateTime& date);
	int SetTaskColor(DWORD dwID, COLORREF color);
	int ClearTaskColor(DWORD dwID) { SetTaskColor(dwID, (COLORREF)-1); }
	int SetTaskComments(DWORD dwID, LPCTSTR szComments, const CString& sCustomComments = "", LPCTSTR szCommentsTypeID = NULL);
	int SetTaskCommentsType(DWORD dwID, LPCTSTR szCommentsTypeID);
	int SetTaskPercent(DWORD dwID, int nPercent);
	int SetTaskTimeEstimate(DWORD dwID, double dTime, int nUnits = TDITU_HOURS);
	int SetTaskTimeSpent(DWORD dwID, double dTime, int nUnits = TDITU_HOURS);
	int SetTaskCost(DWORD dwID, double dCost);
	int SetTaskAllocTo(DWORD dwID, const CStringArray& aAllocTo);
	int SetTaskAllocBy(DWORD dwID, LPCTSTR szAllocBy);
	int SetTaskStatus(DWORD dwID, LPCTSTR szStatus);
	int SetTaskCategories(DWORD dwID, const CStringArray& aCategories);
	int SetTaskDependencies(DWORD dwID, const CStringArray& aDepends);
	int SetTaskExtID(DWORD dwID, LPCTSTR szID);
	int SetTaskFileRef(DWORD dwID, LPCTSTR szFilePath);
	int SetTaskPriority(DWORD dwID, int nPriority); // 0-10 (10 is highest)
	int SetTaskRisk(DWORD dwID, int nRisk); // 0-10 (10 is highest)
	int SetTaskTitle(DWORD dwID, LPCTSTR szTitle);
	int SetTaskFlag(DWORD dwID, BOOL bFlagged);
	int SetTaskRecurrence(DWORD dwID, const TDIRECURRENCE& tr);
	int SetTaskVersion(DWORD dwID, LPCTSTR szVersion);
	int OffsetTaskDate(HTREEITEM hti, TDC_DATE nDate, int nAmount, int nUnits, BOOL bAndSubtasks);

	int OffsetTaskDate(DWORD dwID, TDC_DATE nDate, int nAmount, int nUnits);

	int CopyTaskAttributes(DWORD dwToTaskID, DWORD dwFromTaskID, const CTDCAttributeArray& aAttribs);
	int CopyTaskAttributes(TODOITEM* pToTDI, DWORD dwFromTaskID, const CTDCAttributeArray& aAttribs);
	
	int FindTasks(const SEARCHPARAMS& params, CResultArray& aResults) const;
	DWORD FindFirstTask(const SEARCHPARAMS& params, SEARCHRESULT& result) const;
	BOOL TaskMatches(DWORD dwID, const SEARCHPARAMS& params, SEARCHRESULT& result) const;
	
	BOOL IsTaskFullyDone(HTREEITEM hti, const TODOITEM* pTDI, BOOL bCheckSiblings) const;
	
	void ResetCachedCalculations() const;
	
	BOOL IsTaskTimeTrackable(HTREEITEM hti) const;
	BOOL IsTaskDone(HTREEITEM hti, DWORD dwExtraCheck = TDCCHECKNONE) const;
	void ApplyLastChangeToSubtasks(HTREEITEM hti, const TODOITEM* pTDI, TDC_ATTRIBUTE nAttrib);
	
	//	void RefreshItemCheckState(HTREEITEM hti, int nDone = -1, BOOL bRefreshParents = FALSE);
	//	void RefreshAllCheckStates(HTREEITEM htiRoot = NULL);
	
	static int MapTimeUnits(const CString& sUnits);
	static CString MapTimeUnits(int nUnits);

	int CompareTasks(TODOITEM* pTDI1, HTREEITEM hti1, TODOITEM* pTDI2, HTREEITEM hti2, 
		TDC_SORTBY nSortBy, BOOL bAscending);
	
protected:
	CTDIMap m_mapID2TDI; // the real data
	CTreeCtrl& m_tree; // CToDoCtrl tree
	const CWordArray& m_aStyles; // CToDoCtrl styles
	BOOL m_bSortDueTodayHigh;
	CToDoCtrlUndo m_undo;
	mutable CHTIMap m_mapID2HTI; // task->tree lookup

protected:
	DWORD FindFirstTask(HTREEITEM hti, const SEARCHPARAMS& params, SEARCHRESULT& result) const;
	int FindTasks(HTREEITEM hti, const SEARCHPARAMS& params, CResultArray& aResults) const;
	BOOL TaskMatches(HTREEITEM hti, const SEARCHPARAMS& params, SEARCHRESULT& result) const;
	BOOL FindDependency(DWORD dwTaskID, DWORD dwDependsID) const;

	// internal use only
	void SumPercentDone(HTREEITEM hti, const TODOITEM* pTDI,
		double& dTotalPercent, double& dTotalWeighting) const;
	BOOL AddUndoElement(TDCUNDOELMOP nOp, DWORD dwTaskID, DWORD dwParentID = 0, 
						DWORD dwPrevSiblingID = 0, WORD wFlags = 0);
	
	BOOL TaskMatches(const COleDateTime& date, const SEARCHPARAM& sp, SEARCHRESULT& result) const;
	BOOL TaskMatches(const CString& sText, const SEARCHPARAM& sp, SEARCHRESULT& result) const;
	BOOL TaskMatches(double dValue, const SEARCHPARAM& sp, SEARCHRESULT& result/*, BOOL bTime = FALSE*/) const;
	BOOL TaskMatches(int nValue, const SEARCHPARAM& sp, SEARCHRESULT& result/*, BOOL bPriorityRisk = FALSE*/) const;
	BOOL TaskMatches(const CStringArray& aItems, const SEARCHPARAM& sp, SEARCHRESULT& result) const;
	
	CString GetLongestVisibleExternalID(HTREEITEM hti) const;
	CString GetLongestVisibleCategory(HTREEITEM hti) const;
	CString GetLongestVisibleAllocTo(HTREEITEM hti) const;
	BOOL FindVisibleTaskWithDueTime(HTREEITEM hti) const;

	CString GetLongestVisibleExternalID(HTREEITEM hti, const TODOITEM* pTDI) const;
	CString GetLongestVisibleCategory(HTREEITEM hti, const TODOITEM* pTDI) const;
	CString GetLongestVisibleAllocTo(HTREEITEM hti, const TODOITEM* pTDI) const;
	BOOL FindVisibleTaskWithDueTime(HTREEITEM hti, const TODOITEM* pTDI) const;

	inline BOOL HasStyle(int nStyle) const { return m_aStyles[nStyle] ? TRUE : FALSE; }
	
	void Sort(HTREEITEM hti, const TDSORTSTRUCT& ss);

	static int CALLBACK CompareFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort); 
	static int Compare(const COleDateTime& date1, const COleDateTime& date2);
	static int Compare(const CString& sText1, const CString& sText2, BOOL bCheckEmpty = FALSE);
	static int Compare(int nNum1, int nNum2);
	static int Compare(double dNum1, double dNum2);
	
	static TDC_ATTRIBUTE MapDateToAttribute(TDC_DATE nDate);

};

#endif // !defined(AFX_TODOCTRLDATA_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_)
