// NcGutter.cpp: implementation of the CNcGutter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "NcGutter.h"
#include "holdredraw.h"
#include "themed.h"
#include "dlgunits.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const UINT WM_NCG_FORCERESIZE = ::RegisterWindowMessage("WM_NCG_FORCERESIZE");
UINT HEADERHEIGHT = 0; // set in WM_NCCALCSIZE
UINT BORDER = 0; // set in WM_NCCALCSIZE
const UINT SORTWIDTH = 10;

CNcGutter::CNcGutter() : 
	m_bSetRedraw(TRUE), 
	m_dwItemClick(0), 
	m_bShowHeader(TRUE), 
	m_bFirstRecalc(TRUE),
	m_nHeaderColDown(-1)
{
	// add client header hot rect placeholder
	if (m_bShowHeader && CThemed().AreControlsThemed())
		m_hotTrack.AddRect();

	// client column is always last so we add it first
	m_aColumns.Add(COLUMNDESC(NCG_CLIENTCOLUMNID));
}

CNcGutter::~CNcGutter()
{

}

BOOL CNcGutter::Initialize(HWND hwnd)
{
	if (CSubclassWnd::HookWindow(hwnd))
	{
		// reset calculated widths
		int nCol = m_aColumns.GetSize() - 1; // omit last column == client

		while (nCol--)
		{
			if (m_aColumns[nCol].bCalcWidth)
				m_aColumns[nCol].nWidth = 0;
		}
		
		RecalcGutter();

		// hot tracking
		if (m_bShowHeader && CThemed().AreControlsThemed())
			m_hotTrack.Initialize(GetCWnd());

		return TRUE;
	}

	return FALSE;
}

BOOL CNcGutter::AddColumn(UINT nID, LPCTSTR szTitle, UINT nWidth, UINT nTextAlign)
{
	ASSERT (GetColumnIndex(nID) == -1);

	if (GetColumnIndex(nID) >= 0)
		return FALSE;

	COLUMNDESC cd(nID);

	cd.sTitle = szTitle;
	cd.nWidth = nWidth;
	cd.nTextAlign = nTextAlign;
	cd.bCalcWidth = !nWidth;

	// client column is always last
	m_aColumns.InsertAt(m_aColumns.GetSize() - 1, cd);

	// add a placeholder to the hot tracker
	if (CThemed().AreControlsThemed())
		m_hotTrack.AddRect();

	if (IsHooked())
		RecalcGutter();

	return TRUE;
}

void CNcGutter::PressColumnHeader(UINT nID, BOOL bPress)
{
	int nColumn = GetColumnIndex(nID);

	UnpressAllColumnHeaders(nColumn);
	
	if (nColumn >= 0 && nColumn < m_aColumns.GetSize())
	{
		if (m_aColumns[nColumn].bPressed != bPress)
		{
			m_aColumns[nColumn].bPressed = bPress;
			Redraw();
		}
	}
}

void CNcGutter::SetColumnHeaderTitle(UINT nID, LPCTSTR szTitle)
{
	int nColumn = GetColumnIndex(nID);

	if (nColumn >= 0 && nColumn < m_aColumns.GetSize())
	{
		if (m_aColumns[nColumn].sTitle != szTitle)
		{
			m_aColumns[nColumn].sTitle = szTitle;
			Redraw();
		}
	}
}

void CNcGutter::SetColumnSort(UINT nID, NCGSORT nSortDir, BOOL bExclusive)
{
	BOOL bNeedsRecalc = FALSE;

	int nCol = m_aColumns.GetSize();

	while (nCol--)
	{
		COLUMNDESC& cd = m_aColumns[nCol];

		if (cd.nColID != nID) // other column
		{
			if (bExclusive)
			{
				BOOL bChange = (cd.nSortDir != NCGSORT_NONE);

				// adjust column width if fixed size and was sorted
				if (bChange)
				{
					if (!cd.bCalcWidth)
						cd.nWidth -= SORTWIDTH;
					else
						bNeedsRecalc = TRUE;
				}

				cd.nSortDir = NCGSORT_NONE;
				bNeedsRecalc |= bChange;
			}
		}
		else
		{
			BOOL bChange = (cd.nSortDir != NCGSORT_NONE && nSortDir == NCGSORT_NONE) ||
							(cd.nSortDir == NCGSORT_NONE && nSortDir != NCGSORT_NONE);

			// adjust column width if fixed size and was sorted
			if (bChange)
			{
				if (!cd.bCalcWidth)
					cd.nWidth += SORTWIDTH;
				else
					bNeedsRecalc = TRUE;
			}

			cd.nSortDir = nSortDir;
		}

		if (bNeedsRecalc)
			RecalcGutter();
		else
			Redraw();
	}
}

void CNcGutter::EnableColumnHeaderClicking(UINT nID, BOOL bEnable)
{
	int nColumn = GetColumnIndex(nID);

	if (nColumn >= 0 && nColumn < m_aColumns.GetSize())
		m_aColumns[nColumn].bClickable = bEnable;
}

int CNcGutter::GetColumnIndex(UINT nID)
{
	int nCol = m_aColumns.GetSize();

	while (nCol-- && (nID != m_aColumns[nCol].nColID));

	return nCol; // can be -1
}

void CNcGutter::UnpressAllColumnHeaders(int nExcludeCol)
{
	int nCol = m_aColumns.GetSize();

	while (nCol--)
	{
		if (nCol != nExcludeCol)
			m_aColumns[nCol].bPressed = FALSE;
	}
}

void CNcGutter::Redraw()
{
	CNcRedraw hr(GetHwnd());
}

void CNcGutter::RecalcGutter()
{
	int nCurWidth = GetGutterWidth();
	int nNewWidth = RecalcGutterWidth();

	if (IsHooked())
	{
		TRACE("CNcGutter::RecalcGutter(old width = %d, new width = %d)\n", nCurWidth, nNewWidth);

		if (nNewWidth != nCurWidth || m_bFirstRecalc)
		{
			m_bFirstRecalc = FALSE;
			PostMessage(WM_NCG_FORCERESIZE);

			// notify hooked wnd and parent
			UINT nID = GetDlgCtrlID(GetHwnd());

			SendMessage(WM_NCG_WIDTHCHANGE, nID, MAKELPARAM(nCurWidth, nNewWidth));
			::SendMessage(GetParent(), WM_NCG_WIDTHCHANGE, nID, MAKELPARAM(nCurWidth, nNewWidth));

			// update header tracking rects
			UpdateHeaderHotRects();
		}
		else
			Redraw();
	}
}

void CNcGutter::ShowHeader(BOOL bShow)
{
	if (m_bShowHeader != bShow)
	{
		if (CThemed().AreControlsThemed())
		{
			if (!bShow)
				m_hotTrack.Reset();
			else
			{
				m_hotTrack.Initialize(GetCWnd());

				for (int nCol = 0; nCol < m_aColumns.GetSize(); nCol++)
					m_hotTrack.AddRect();

				UpdateHeaderHotRects();
			}
		}

		m_bShowHeader = bShow;
		PostMessage(WM_NCG_FORCERESIZE);
	}
}

int CNcGutter::GetGutterWidth()
{
	int nWidth = 0;

	for (int nCol = 0; nCol < m_aColumns.GetSize() - 1; nCol++)
		nWidth += m_aColumns[nCol].nWidth;

	return nWidth;
}

void CNcGutter::AddRecalcMessage(UINT nMessage, UINT nNotification)
{
	m_mapRecalcMessages.SetAt(MAKELONG((WORD)nMessage, (WORD)nNotification), 0);
}

void CNcGutter::AddRedrawMessage(UINT nMessage, UINT nNotification)
{
	m_mapRedrawMessages.SetAt(MAKELONG((WORD)nMessage, (WORD)nNotification), 0);
}

LRESULT CNcGutter::WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case WM_CAPTURECHANGED:
		m_nHeaderColDown = -1;
		// fall thru
	case WM_SETFOCUS:
	case WM_VSCROLL:
	case WM_KILLFOCUS:
		if (m_bSetRedraw)
		{
			CNcRedraw hr(hRealWnd);
			return Default();
		}
		break;

	case WM_MOUSEWHEEL:
		{
			m_dwItemClick = FALSE;
			
			if (m_bSetRedraw)
			{
				CNcRedraw hr(hRealWnd);
				return Default();
			}
		}
		break;

	case WM_KEYDOWN:
		switch (wp) // virtual key
		{
		// the standard scroll keypresses
		case VK_DOWN:
		case VK_UP:
		case VK_LEFT:
		case VK_RIGHT:
		case VK_PRIOR: 
		case VK_NEXT:  
		case VK_END:   
		case VK_HOME:  
		case VK_ESCAPE:  
			{
				m_dwItemClick = FALSE;
			
				if (m_bSetRedraw)
				{
					CNcRedraw hr(hRealWnd);
					return Default();
				}
			}

		// keys that might modify the cursor
		case VK_CONTROL:
		case VK_SHIFT:
		case VK_MENU:
			// but only on the first event (ie not repeats)
			if (!(lp & 0x40000000))
				OnSetCursor();
		}
		break;

	case WM_KEYUP:
		switch (wp) // virtual key
		{
		// keys that might modify the cursor
		case VK_CONTROL:
		case VK_SHIFT:
		case VK_MENU:
			if (!OnSetCursor())
			{
				// draw the default cursor
				SendMessage(WM_SETCURSOR, (WPARAM)GetHwnd(), MAKELPARAM(HTCLIENT, WM_MOUSEMOVE));
			}
		}
		break;

	case WM_LBUTTONDOWN:
	case WM_RBUTTONDOWN:
		OnButtonDown(msg, lp);
		break;

	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
		OnButtonUp(msg, lp);
		break;

	case WM_LBUTTONDBLCLK:
		m_bClickSelChange = TRUE;
		break;

	case WM_NCRBUTTONDOWN:
	case WM_NCLBUTTONDOWN:
	case WM_NCLBUTTONDBLCLK:
		if (wp == HTBORDER) // means gutter
			OnNcButtonDown(msg, lp);
		break;

	case WM_NCRBUTTONUP:
		if (wp == HTBORDER) // means gutter
		{
			OnNcButtonUp(msg, lp);
			return 0;
		}
		break;

	case WM_NCLBUTTONUP:
		if (wp == HTBORDER) // means gutter
			OnNcButtonUp(msg, lp);
		break;

	case WM_ERASEBKGND:
		// its not a neat solution but it does ensure that when expanding and collapsing
		// tree controls that any animations look correct
		{
			HDC hdc = (HDC)wp;
			UINT nFlags = PRF_CLIENT;
			OnPrint(hdc, nFlags);
		}
		return TRUE; // always

	case WM_NCHITTEST:
		return OnNcHitTest(lp);

	case WM_PAINT:
		OnPaint();
		return 0;

	case WM_NCCALCSIZE:
		if (wp)
			return OnNcCalcSize((LPNCCALCSIZE_PARAMS)lp);
		break;

	case WM_NCPAINT:
		Default();

		if (m_bSetRedraw)
			OnNcPaint();
		return 0;

	case WM_PRINT:
		if (m_bSetRedraw)
			OnPrint((HDC)wp, (UINT&)lp);
		break;

	case WM_SETREDRAW:
		m_bSetRedraw = wp;
		
		if (m_bSetRedraw)
		{
			RecalcGutter();
			Redraw();
		}
		break;

	case WM_SETFONT:
		Default();
		RecalcGutter();
		return 0;

	case WM_SETCURSOR:
		if (LOWORD(lp) == HTBORDER && OnSetCursor())
			return TRUE;
		break;

	case WM_SIZE:
		if (m_hotTrack.IsValid())
		{
			Default();
			UpdateHeaderHotRects();
			return 0;
		}
	}

	// registered messages must be handled explicitly
	if (msg == WM_NCG_FORCERESIZE)
		return SetWindowPos(hRealWnd, NULL, 0, 0, 0, 0, SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER); 

	else if (msg == WM_HTHOTCHANGE)
		OnHotChange(wp, lp);

	// test for specific messages wanting recalcs/redraws
	LRESULT lr = 0;

	if (WantsRecalc(msg, wp, lp, lr) || WantsRedraw(msg, wp, lp, lr))
		return lr;

	return CSubclassWnd::WindowProc(hRealWnd, msg, wp, lp);
}

LRESULT CNcGutter::OnNcCalcSize(LPNCCALCSIZE_PARAMS lpncsp)
{
	LRESULT lr = Default();
	
	if (BORDER == 0)
		BORDER = lpncsp->rgrc[0].left - lpncsp->rgrc[1].left; // diff between window and client
	
	lpncsp->rgrc[0].left += GetGutterWidth();
	
	if (m_bShowHeader)
    {
        if (HEADERHEIGHT == 0)
            HEADERHEIGHT = CDlgUnits().ToPixelsY(8); // handles font sizes

		lpncsp->rgrc[0].top += HEADERHEIGHT;
    }
	
	return lr;
}

BOOL CNcGutter::WantsRecalc(UINT nMsg, WPARAM wp, LPARAM lp, LRESULT& lr)
{
	if (!m_bSetRedraw)
		return FALSE;

	// convert message to lookup key
	WORD nNotification = 0;

	if (nMsg == WM_COMMAND)
		nNotification = HIWORD(wp);
	else if (nMsg == WM_NOTIFY)
	{
		NMHDR* pNMHDR = (NMHDR*)lp;
		nNotification = pNMHDR->code;
	}

	DWORD dwKey = MAKELONG((WORD)nMsg, nNotification);
	char dummy;

	if (m_mapRecalcMessages.Lookup(dwKey, dummy))
	{
		m_dwItemClick = FALSE;

		lr = Default();
		RecalcGutter();

		return TRUE;
	}

	return FALSE;
}

BOOL CNcGutter::WantsRedraw(UINT nMsg, WPARAM wp, LPARAM lp, LRESULT& lr)
{
	if (!m_bSetRedraw)
		return FALSE;

	// convert message to lookup key
	WORD nNotification = 0;

	if (nMsg == WM_COMMAND)
		nNotification = HIWORD(wp);
	else if (nMsg == WM_NOTIFY)
	{
		NMHDR* pNMHDR = (NMHDR*)lp;
		nNotification = pNMHDR->code;
	}

	DWORD dwKey = MAKELONG((WORD)nMsg, nNotification);
	char dummy;

	if (m_mapRedrawMessages.Lookup(dwKey, dummy))
	{
		m_dwItemClick = FALSE;

		lr = Default();
		CNcRedraw hr(GetHwnd());

		return TRUE;
	}

	return FALSE;
}

void CNcGutter::OnPaint()
{
	PAINTSTRUCT ps;
			
	HDC hdc = ::BeginPaint(GetHwnd(), &ps); // device context for painting

	if (m_bSetRedraw)
	{
		UINT nFlags = PRF_CLIENT;
		OnPrint(hdc, nFlags);
	}

	::EndPaint(GetHwnd(), &ps);
}

LRESULT CNcGutter::OnNcHitTest(CPoint point)
{
	LRESULT lHitTest = Default();
	
	switch (lHitTest)
	{
	case HTNOWHERE:
		return HTBORDER;
		
	case HTCAPTION:
		if (m_bShowHeader && HeaderHitTest(point) >= 0)
			return HTBORDER;
		break;
	}
		
	// everything else
	return lHitTest;
}

void CNcGutter::OnButtonDown(UINT nMsg, CPoint point)
{
	DWORD dwItem = HitTest(point);
	
	// if dwItem is not the selected item then we must cache the hit item
	// to ensure the gutter gets drawn properly
	if (GetSelectedItem() != dwItem)
	{
		m_bClickSelChange = TRUE;
		m_dwItemClick = dwItem;
	}
	else
	{
		m_bClickSelChange = FALSE;
		m_dwItemClick = 0;
	}
	
	SetFocus(GetHwnd());
	CNcRedraw hr(GetHwnd());
}

void CNcGutter::OnButtonUp(UINT nMsg, CPoint point)
{
	// if the header column is set it means that we're in the middle
	// of a column click
	if (m_nHeaderColDown >= 0)
	{
		ClientToScreen(&point);
		int nHitCol = HeaderHitTest(point);

		// send notification if column header currently pressed
		if (nHitCol == m_nHeaderColDown)
		{
			UINT nColID = m_aColumns[nHitCol].nColID;
			NCGHDRCLICK nghc = { nColID, WM_NCLBUTTONUP, FALSE };
					
			// try hook window and parent
			UINT nID = GetDlgCtrlID(GetHwnd());
			
			SendMessage(WM_NCG_NOTIFYHEADERCLICK, nID, (LPARAM)&nghc);
			::SendMessage(GetParent(), WM_NCG_NOTIFYHEADERCLICK, nID, (LPARAM)&nghc);
			
			m_nHeaderColDown = -1;
			PressColumnHeader(nColID, nghc.bPressed);
		}
		else
		{
			m_nHeaderColDown = -1;
			Redraw();
		}

		ReleaseCapture();
	}

	m_dwItemClick = 0;
	m_bClickSelChange = FALSE;
	CNcRedraw hr(GetHwnd());
}

void CNcGutter::OnNcButtonDown(UINT nMsg, CPoint point)
{
	SetFocus(GetHwnd());
	
	// get column
	int nCol = ColumnHitTest(point);
	ASSERT (nCol != -1);

	const COLUMNDESC& cd = m_aColumns[nCol];

	// is it a header click?
	CPoint ptCursor(point);
	::ScreenToClient(GetHwnd(), &ptCursor);
	
	if (ptCursor.y < 0 && nMsg == WM_NCLBUTTONDOWN)
	{
		// check its a clickable column
		if (nCol >= 0 && cd.bClickable)
		{
			SetCapture(GetHwnd());
			m_nHeaderColDown = nCol;
			Redraw();
		}
	}
	else if (ptCursor.y >= 0) // get item
	{
		// check if point is below client area
		CRect rClient;
		GetClientRect(rClient);
		
		if (ptCursor.y <= rClient.bottom)
		{
			ptCursor.x = 0; // rClient.left
			DWORD dwItem = HitTest(ptCursor);
			
			NCGITEMCLICK ngic = { dwItem, cd.nColID, nMsg, { point.x, point.y } };
			
			// try hook window and parent
			UINT nID = GetDlgCtrlID(GetHwnd());
			
			SendMessage(WM_NCG_NOTIFYCOLUMNCLICK, nID, (LPARAM)&ngic);
			::SendMessage(GetParent(), WM_NCG_NOTIFYCOLUMNCLICK, nID, (LPARAM)&ngic);
		}
	}
	
	// redraw for good measure
	Redraw();
}

void CNcGutter::OnNcButtonUp(UINT nMsg, CPoint point)
{
	if (nMsg == WM_NCRBUTTONUP)
	{
		// is it a header click?
		CPoint ptClient(point);
		::ScreenToClient(GetHwnd(), &ptClient);
		
		if (ptClient.y > 0) // no
			SendMessage(WM_CONTEXTMENU, (WPARAM)GetHwnd(), MAKELPARAM(point.x, point.y));
	}
	else if (nMsg == WM_NCLBUTTONUP)
	{
		// all column clicks now got to OnButtonUp
		// cos we have captured the mouse
	}
}

void CNcGutter::OnHotChange(int nPrevHot, int nHot)
{
	ASSERT (m_bShowHeader);

	if (m_bShowHeader)
	{
		CRect rWindow, rClient;

		// convert rects to window coords
		GetWindowRect(rWindow);
		GetClientRect(rClient);

		CPoint ptWindowTL = rWindow.TopLeft();

		ClientToScreen(rClient);
		rClient.OffsetRect(-ptWindowTL);
		rWindow.OffsetRect(-ptWindowTL);

		// allow for client edge, etc
		rWindow.DeflateRect(BORDER, BORDER);

		// adjust top of window rect to be top of header (if showing)
		CRect rHeader(rWindow);
		rHeader.bottom = rClient.top;
		rHeader.top = rHeader.bottom - HEADERHEIGHT;

		CWindowDC dc(GetCWnd());
		CPoint ptCursor(::GetMessagePos());
		ptCursor.Offset(-ptWindowTL);

		// nc portion
		int nClientCol = m_aColumns.GetSize() - 1;
		BOOL bDrawNonClient = FALSE;

		if (nPrevHot >= 0 && nPrevHot != nClientCol)
		{
			const COLUMNDESC& cd = m_aColumns[nPrevHot];
			bDrawNonClient = (cd.bClickable/* && !cd.bPressed*/);
		}

		if (!bDrawNonClient && nHot >= 0 && nHot != nClientCol)
		{
			const COLUMNDESC& cd = m_aColumns[nHot];
			bDrawNonClient = (cd.bClickable/* && !cd.bPressed*/);
		}

		if (bDrawNonClient)
		{
			rHeader.right = rClient.left;
			NcDrawHeader(&dc, rHeader, NONCLIENT, &ptCursor);
		}

		// client bit
		BOOL bDrawClient = FALSE;

		if (nPrevHot == nClientCol || nHot == nClientCol)
		{
			const COLUMNDESC& cd = m_aColumns[nClientCol];

			if (cd.bClickable)
			{
				rHeader.left = rClient.left;
				rHeader.right = rWindow.right;
				NcDrawHeader(&dc, rHeader, CLIENT, &ptCursor);
			}
		}
	}
}

int CNcGutter::HeaderHitTest(CPoint ptScreen)
{
	int nCol = ColumnHitTest(ptScreen);
	ASSERT (nCol >= 0);

	ScreenToClient(&ptScreen);

	CRect rClient;
	GetClientRect(rClient);

	if (ptScreen.y < rClient.top && ptScreen.y > (int)(rClient.top - HEADERHEIGHT))
		return nCol;

	return -1;
}

BOOL CNcGutter::OnSetCursor()
{
	CPoint ptScreen(::GetMessagePos());
	int nCol = ColumnHitTest(ptScreen);

	if (nCol >= 0)
	{
		ScreenToClient(&ptScreen);

		if (ptScreen.y > 0) // else in the header
		{
			ptScreen.x = 0; // client coords

			DWORD dwItem = HitTest(ptScreen);

			if (dwItem)
			{
				NCGGETCURSOR ncgsc = { m_aColumns[nCol].nColID, dwItem };
				UINT nID = GetDlgCtrlID(GetHwnd());

				HCURSOR hCursor = (HCURSOR)SendMessage(WM_NCG_GETCURSOR, nID, (LPARAM)&ncgsc);

				if (!hCursor)
					hCursor = (HCURSOR)::SendMessage(GetParent(), WM_NCG_GETCURSOR, nID, (LPARAM)&ncgsc);

				if (hCursor)
				{
					::SetCursor(hCursor);
					return TRUE;
				}
			}
		}
	}

	return FALSE;
}

void CNcGutter::OnNcPaint() 
{
	// see if we can avoid any unnecessary drawing
	if (GetGutterWidth() == 0 && !m_bShowHeader)
		return;

	DWORD dwTick = GetTickCount();

	CRect rWindow, rClient;
	CPoint ptWindowTL;

	GetWindowRect(rWindow);
	ptWindowTL = rWindow.TopLeft();
	rWindow.OffsetRect(-ptWindowTL);

	GetClientRect(rClient);
	ClientToScreen(rClient);
	rClient.OffsetRect(-ptWindowTL);

	// get cursor pos in window coords for header drawing
	CPoint ptCursor;

	if (m_bShowHeader)
	{
		::GetCursorPos(&ptCursor);
		ptCursor.Offset(-ptWindowTL);
	}

	// allow for client edge, etc
	rWindow.DeflateRect(BORDER, BORDER);

	// adjust top of window rect to be top of header (if showing)
	rWindow.top = rClient.top - (m_bShowHeader ? HEADERHEIGHT : 0);
	CRect rWindowOrg(rWindow); // and save

	// to avoid creating excessively large bitmaps we'll render the client header straight
	// into the window dc ie only the non-client gutter & header is rendered on the bitmap
	rWindow.bottom = rClient.bottom;
	rWindow.right = rClient.left;

	CWindowDC dc(GetCWnd());
	CDC dcMem;
	CDC* pOutputDC = &dc; // default backup plan in case mem dc or bitmap cannot be created
	CBitmap* pBMOld = NULL;

	if (GetGutterWidth() > 0 && dcMem.CreateCompatibleDC(NULL) && 
		PrepareBitmap(&dc, &m_bmNonClient, CRect(0, 0, rWindow.right, rWindow.bottom), FALSE))
	{		
		pOutputDC = &dcMem;
		pBMOld = dcMem.SelectObject(&m_bmNonClient);
	}

	pOutputDC->FillSolidRect(rWindow.left, rClient.top, rWindow.Width(), rWindow.Height(), ::GetSysColor(COLOR_WINDOW));

	// iterate the top level items
	CFont* pFont = GetCWnd()->GetFont();
	CFont* pOldFont = NULL;

	if (pFont)
		pOldFont = pOutputDC->SelectObject(pFont);
	else
		pOutputDC->SelectStockObject(DEFAULT_GUI_FONT);
				
	int nItem = 1;
	DWORD dwItem = GetFirstVisibleTopLevelItem(nItem);
				
	while (dwItem)
	{
		CRect rItem;
		CString sPrevPos;
		NcDrawItem(pOutputDC, dwItem, 0, 0, nItem, rWindow, rClient, rItem);
					
		dwItem = GetNextItem(dwItem);
		nItem++;
					
		if (rItem.bottom >= rWindow.bottom)
			break;
	}
				
	PostNcDraw(pOutputDC, rWindow);

	// non-client header
	if (m_bShowHeader)
	{
		CRect rHeader(rWindowOrg);
		rHeader.bottom = rHeader.top + HEADERHEIGHT;
		rHeader.right = rClient.left;
		NcDrawHeader(pOutputDC, rHeader, NONCLIENT, &ptCursor);
	}

	// blt to window dc if nec
	if (pOutputDC == &dcMem)
	{
		dc.BitBlt(rWindow.left, rWindow.top, rWindow.Width(), rWindow.Height(),
				  &dcMem, rWindow.left, rWindow.top, SRCCOPY);

		dcMem.SelectObject(pBMOld); // V.V.IMPORTANT
	}

	// cleanup			
	if (pFont)
		pOutputDC->SelectObject(pOldFont);

	// two items we render direct to the window dc
	
	// 1. the client header
	if (m_bShowHeader)
	{
		CRect rHeader(rWindowOrg);
		rHeader.bottom = rHeader.top + HEADERHEIGHT;
		rHeader.left = rClient.left;
		NcDrawHeader(&dc, rHeader, CLIENT, &ptCursor);
	}
				
	// 2. if the window base does not match the client bottom then 
	// paint the extra bit gray (means there is a horz scrollbar)
	if (rWindowOrg.bottom != rClient.bottom)
	{
		CRect rScroll(rWindowOrg.left, rClient.bottom, rClient.left, rWindowOrg.bottom);

		if (CThemed().IsNonClientThemed())
		{
			CThemed th;

			if (th.Open(GetCWnd(), "SCROLLBAR"))
				th.DrawBackground(&dc, SBP_LOWERTRACKHORZ, SCRBS_NORMAL, rScroll);
			else
				dc.FillSolidRect(rScroll, ::GetSysColor(COLOR_SCROLLBAR));
		}
		else
			dc.FillSolidRect(rScroll, ::GetSysColor(COLOR_SCROLLBAR));
	}
}

void CNcGutter::NcDrawHeaderColumn(CDC* pDC, int nColumn, CRect rColumn, CThemed* pTheme, LPPOINT pCursor)
{
	COLUMNDESC& cd = m_aColumns[nColumn];

	BOOL bDown = (nColumn == m_nHeaderColDown);
	BOOL bPressed = (cd.bPressed || bDown);
	BOOL bSorted = (cd.nSortDir != NCGSORT_NONE);
	
	if (!pTheme)
	{
		if (bPressed)
		{
			pDC->FillSolidRect(rColumn, ::GetSysColor(COLOR_3DHIGHLIGHT));
			pDC->Draw3dRect(rColumn, ::GetSysColor(COLOR_3DFACE), ::GetSysColor(COLOR_3DSHADOW));
		}
		else
			pDC->Draw3dRect(rColumn, ::GetSysColor(COLOR_3DHIGHLIGHT), ::GetSysColor(COLOR_3DSHADOW));
	}
	else
	{
		BOOL bHot = rColumn.PtInRect(*pCursor);
		
		// divider positions look wrong so we make small adjustment here
		CRect rClip(rColumn);
		rColumn.right += (1 - bPressed);	
		
		BOOL bClickable = (bHot && cd.bClickable);
		
		pTheme->DrawBackground(pDC, HP_HEADERITEM, bPressed ? HIS_PRESSED : 
								((bHot && cd.bClickable) ? HIS_HOT : HIS_NORMAL), rColumn);
								
		rColumn.right -= (1 - bPressed);	
	}
	
	// text
	if (!cd.sTitle.IsEmpty())
	{
		const UINT DEFFLAGS = DT_END_ELLIPSIS | DT_BOTTOM | DT_SINGLELINE;

		CRect rText(rColumn);
		rText.DeflateRect(2, 0, 2, 2 + (pTheme ? 1 : 0));
		
		if (bDown)
			rText.OffsetRect(1, 1);
		
		// pad the text a bit more if not centered
		if (!(cd.nTextAlign & DT_CENTER))
			rText.DeflateRect(2, 0);

		if (bSorted)
			rText.right -= (SORTWIDTH + 2);
		
		pDC->SelectStockObject(DEFAULT_GUI_FONT);
		pDC->DrawText(cd.sTitle, rText, DEFFLAGS | cd.nTextAlign);

		// adjust for sort arrow
		if (bSorted)
		{
			if (cd.nTextAlign & DT_CENTER)
				rColumn.left = ((rText.left + rText.right + pDC->GetTextExtent(cd.sTitle).cx) / 2) + 2;

			else if (cd.nTextAlign & DT_RIGHT)
				rColumn.left = rText.right + 2;
			else
				rColumn.left = rText.left + pDC->GetTextExtent(cd.sTitle).cx + 2;
		}
	}

	// draw sort direction if required
	if (bSorted)
	{
		int nMidY = (bDown ? 1 : 0) + (rColumn.top + rColumn.bottom) / 2;
		POINT ptArrow[3] = { { 0, 0 }, { 3, (int)cd.nSortDir * 3 }, { 7, -(int)cd.nSortDir } };
		
		// translate the arrow to the appropriate location
		int nPoint = 3;
		
		while (nPoint--)
		{
			ptArrow[nPoint].x += rColumn.left + 3 + (bDown ? 1 : 0);
			ptArrow[nPoint].y += nMidY;
		}
		pDC->Polyline(ptArrow, 3);
	}
	
}

void CNcGutter::NcDrawHeader(CDC* pDC, const CRect& rHeader, HCHDRPART nPart, const LPPOINT pCursor)
{
	if (!m_bShowHeader)
		return;

	CThemed th;
	BOOL bThemed = th.AreControlsThemed() && th.Open(GetCWnd(), "HEADER");

	if (!bThemed)
		pDC->FillSolidRect(rHeader, ::GetSysColor(COLOR_3DFACE));

	pDC->SetBkMode(TRANSPARENT);

	CRect rColumn(rHeader);

	if (nPart == NONCLIENT)
	{
		rColumn.right = rColumn.left;

		int nNumCols = m_aColumns.GetSize() - 1; // omit last column == client

		for (int nCol = 0; nCol < nNumCols; nCol++)
		{
			COLUMNDESC& cd = m_aColumns[nCol];
			int nColWidth = (int)cd.nWidth;

			if (!nColWidth)
				continue;

			rColumn.left = rColumn.right;
			rColumn.right += nColWidth;

			NcDrawHeaderColumn(pDC, nCol, rColumn, bThemed ? &th : NULL, bThemed ? pCursor : NULL);
		}
	}
	else // the rest is over the client area
	{
		int nCol = GetColumnIndex(NCG_CLIENTCOLUMNID);
		ASSERT (nCol != -1);

		NcDrawHeaderColumn(pDC, nCol, rColumn, bThemed ? &th : NULL, bThemed ? pCursor : NULL);
	}
}

void CNcGutter::OnPrint(HDC hdc, UINT& nFlags)
{
	if (nFlags & PRF_CLIENT)
	{
		// render the control to a bitmap for flicker free
		CRect rClient;
		GetClientRect(rClient);
		rClient.InflateRect(1, 1);

		CDC dcMem, dc;

		if (dcMem.CreateCompatibleDC(NULL))
		{
			dc.Attach(hdc);

			if (PrepareBitmap(&dc, &m_bmClient, rClient, TRUE))
			{
				CBitmap* pBMOld = dcMem.SelectObject(&m_bmClient);
				dcMem.FillSolidRect(rClient, GetSysColor(COLOR_WINDOW));

				CSubclassWnd::WindowProc(GetHwnd(), WM_PRINT, (WPARAM)(HDC)dcMem, PRF_CLIENT);

				dc.BitBlt(0, 0, rClient.right, rClient.bottom, &dcMem, 0, 0, SRCCOPY);

				nFlags &= ~PRF_CLIENT; // we just drawn this bit

				// cleanup
				dcMem.SelectObject(pBMOld); // V.V.IMPORTANT
			}

			dc.Detach();
		}
	}
}

DWORD CNcGutter::GetFirstVisibleTopLevelItem(int& nItem)
{
	// try hook window then parent
	UINT nID = GetDlgCtrlID(GetHwnd());

	DWORD dwItem = (DWORD)SendMessage(WM_NCG_GETFIRSTVISIBLETOPLEVELITEM, nID, (LPARAM)(LPINT)&nItem);

	if (!dwItem)
		dwItem = (DWORD)::SendMessage(GetParent(), WM_NCG_GETFIRSTVISIBLETOPLEVELITEM, nID, (LPARAM)(LPINT)&nItem);

	// else
	return dwItem;
}

void CNcGutter::NcDrawItem(CDC* pDC, DWORD dwItem, DWORD dwParentItem, int nLevel, int nPos, 
						   const CRect& rWindow, const CRect& rClient, CRect& rItem)
{
	rItem = GetItemRect(dwItem);
							
	if (!rItem.IsRectEmpty())
	{
		// convert rItem to window coords
		rItem.OffsetRect(0, rClient.TopLeft().y); // convert to window coords
		rItem.left = rWindow.left;
		rItem.right = rWindow.right;

		NCGDRAWITEM ncgDI;
		
		ncgDI.pDC = pDC;
		ncgDI.dwItem = dwItem;
		ncgDI.dwParentItem = dwParentItem;
		ncgDI.nLevel = nLevel;
		ncgDI.nItemPos = nPos;
		ncgDI.rWindow = &rWindow;
		ncgDI.rItem = &rItem;
		
		if (m_dwItemClick)
			ncgDI.bSelected = (m_bClickSelChange && dwItem == m_dwItemClick);
		else
			ncgDI.bSelected = (dwItem == GetSelectedItem());
		
		UINT nID = GetDlgCtrlID(GetHwnd());
		
		// draw each column in turn
		rItem.right = rItem.left;
		int nNumCols = m_aColumns.GetSize() - 1; // omit last column == client
		
		for (int nCol = 0; nCol < nNumCols; nCol++)
		{
			ncgDI.nColID = m_aColumns[nCol].nColID;
			rItem.left = rItem.right;
			
			// if we're out of the window rect then stop
			if (rItem.left > rWindow.right)
				break;
			
			int nColWidth = (int)m_aColumns[nCol].nWidth;
			
			if (!nColWidth)
				continue;
			
			rItem.right += nColWidth;
			
			int nSaveDC = pDC->SaveDC();
			
			// try hook window then parent
			if (!SendMessage(WM_NCG_DRAWITEM, nID, (LPARAM)&ncgDI))
				::SendMessage(GetParent(), WM_NCG_DRAWITEM, nID, (LPARAM)&ncgDI);
			
			pDC->RestoreDC(nSaveDC);
		}

		// draw children
		int nChild = 1;
		DWORD dwChild = GetFirstChildItem(dwItem);
		CRect rChild;
		
		while (dwChild)
		{
			NcDrawItem(pDC, dwChild, dwItem, nLevel + 1, nChild, rWindow, rClient, rChild);
			
			dwChild = GetNextItem(dwChild);
			nChild++;
			
			// accumulate child rects into rItem
			rItem |= rChild;
			
			if (rItem.bottom >= rWindow.bottom)
				break;
		}
		
		// post draw only if we reached the last item
		CRect rItemTotal(rItem);
		rItemTotal.left = rWindow.left;
		rItemTotal.right = rWindow.right;
		
		if (!dwChild)
			PostNcDrawItem(pDC, dwItem, rItemTotal, nLevel);
		
		rItem = rItemTotal;
	}
}

void CNcGutter::PostNcDrawItem(CDC* pDC, DWORD dwItem, const CRect& rItem, int nLevel)
{
	// try hook window then parent
	NCGDRAWITEM ncgDI;
		
	ncgDI.pDC = pDC;
	ncgDI.dwItem = dwItem;
	ncgDI.rItem = &rItem;
	ncgDI.nLevel = nLevel;

	UINT nID = GetDlgCtrlID(GetHwnd());
		
	if (!SendMessage(WM_NCG_POSTDRAWITEM, nID, (LPARAM)&ncgDI))
		::SendMessage(GetParent(), WM_NCG_POSTDRAWITEM, nID, (LPARAM)&ncgDI);
}

void CNcGutter::PostNcDraw(CDC* pDC, const CRect& rWindow)
{
	// try hook window then parent
	NCGDRAWITEM ncgDI;
		
	ncgDI.pDC = pDC;
	ncgDI.rWindow = &rWindow;

	UINT nID = GetDlgCtrlID(GetHwnd());
		
	if (!SendMessage(WM_NCG_POSTNCDRAW, nID, (LPARAM)&ncgDI))
		::SendMessage(GetParent(), WM_NCG_POSTNCDRAW, nID, (LPARAM)&ncgDI);
}

DWORD CNcGutter::GetNextItem(DWORD dwItem)
{
	// try hook window then parent
	UINT nID = GetDlgCtrlID(GetHwnd());
	DWORD dwNextItem = (DWORD)SendMessage(WM_NCG_GETNEXTITEM, nID, dwItem);

	if (!dwNextItem)
		dwNextItem = (DWORD)::SendMessage(GetParent(), WM_NCG_GETNEXTITEM, nID, dwItem);

	return dwNextItem;
}

int CNcGutter::RecalcGutterWidth()
{
	if (!IsHooked())
		return 0;

	// optimization
	if (!m_bSetRedraw)
		return GetGutterWidth();

	CWindowDC dc(GetCWnd());

	CFont* pFont = GetCWnd()->GetFont();
	CFont* pOldFont = NULL;

	if (pFont)
		pOldFont = dc.SelectObject(pFont);
	else
		dc.SelectStockObject(DEFAULT_GUI_FONT);

	NCGRECALCCOLUMN ncrc;
	ncrc.pDC = &dc;

	// try hook window then parent
	UINT nID = GetDlgCtrlID(GetHwnd());
	int nGutter = 0;
	int nCol = m_aColumns.GetSize() - 1; // omit last column == client

	while (nCol--)
	{
		// check if its a fixed size column
		COLUMNDESC& cd = m_aColumns[nCol];

		if (cd.bCalcWidth)
		{
			ncrc.nColID = cd.nColID;
			ncrc.nWidth = 0;

			if (!SendMessage(WM_NCG_RECALCCOLWIDTH, nID, (LPARAM)&ncrc))
				::SendMessage(GetParent(), WM_NCG_RECALCCOLWIDTH, nID, (LPARAM)&ncrc);

			cd.nWidth = ncrc.nWidth;
			
			if (cd.nWidth > 0 && cd.nSortDir != NCGSORT_NONE)
				cd.nWidth += SORTWIDTH;
		}
		nGutter += cd.nWidth;
	}

	return nGutter;
}

CRect CNcGutter::GetItemRect(DWORD dwItem)
{
	// try hook window then parent
	UINT nID = GetDlgCtrlID(GetHwnd());
	NCGITEMRECT ncgGI;
	ncgGI.dwItem = dwItem;

	if (!SendMessage(WM_NCG_GETITEMRECT, nID, (LPARAM)&ncgGI))
		::SendMessage(GetParent(), WM_NCG_GETITEMRECT, nID, (LPARAM)&ncgGI);

	return ncgGI.rItem;
}

DWORD CNcGutter::GetFirstChildItem(DWORD dwItem)
{
	// try hook window then parent
	UINT nID = GetDlgCtrlID(GetHwnd());
	DWORD dwChildItem = (DWORD)SendMessage(WM_NCG_GETFIRSTCHILDITEM, nID, dwItem);

	if (!dwChildItem)
		dwChildItem = (DWORD)::SendMessage(GetParent(), WM_NCG_GETFIRSTCHILDITEM, nID, dwItem);

	return dwChildItem;
}

DWORD CNcGutter::GetSelectedItem()
{
	// try hook window then parent
	UINT nID = GetDlgCtrlID(GetHwnd());

	DWORD dwItem = (DWORD)SendMessage(WM_NCG_GETSELECTEDITEM, nID, 0);

	if (!dwItem)
		dwItem = (DWORD)::SendMessage(GetParent(), WM_NCG_GETSELECTEDITEM, nID, 0);

	// else
	return dwItem;
}

DWORD CNcGutter::HitTest(CPoint point)
{
	// try hook window then parent
	UINT nID = GetDlgCtrlID(GetHwnd());

	DWORD dwItem = (DWORD)SendMessage(WM_NCG_HITTEST, nID, MAKELONG(point.x, point.y));

	if (!dwItem)
		dwItem = (DWORD)::SendMessage(GetParent(), WM_NCG_HITTEST, nID, MAKELONG(point.x, point.y));

	// else
	return dwItem;
}

BOOL CNcGutter::SetSelectedItem(DWORD dwItem)
{
	// try hook window then parent
	UINT nID = GetDlgCtrlID(GetHwnd());

	if (!SendMessage(WM_NCG_SETSELECTEDITEM, nID, dwItem))
		return ::SendMessage(GetParent(), WM_NCG_SETSELECTEDITEM, nID, dwItem);

	// else
	return TRUE;
}

int CNcGutter::ColumnHitTest(CPoint ptScreen)
{
	CRect rWindow;
	GetWindowRect(rWindow);

	ptScreen.Offset(-rWindow.TopLeft());

	if (ptScreen.x <= 0)
		return 0;

	int nCol = m_aColumns.GetSize() - 1;  // omit last column == client
	DWORD nGutter = GetGutterWidth();

	// check if we're on the right most limit
	if (ptScreen.x > (LONG)nGutter)
	{
		CRect rClient;
		GetClientRect(rClient);
		ClientToScreen(rClient);
		rClient.OffsetRect(-rWindow.TopLeft());

		if (ptScreen.x < rClient.left)
			return nCol - 1; // last non client column
		else
			return nCol; // client area
	}

	while (nCol--)
	{
		int nColWidth = m_aColumns[nCol].nWidth;

		if (ptScreen.x >= (LONG)(nGutter - nColWidth) && ptScreen.x <= (LONG)nGutter)
			return nCol;

		nGutter -= nColWidth;
	}

	return -1; // ?? 
}

BOOL CNcGutter::PrepareBitmap(CDC* pDC, CBitmap* pBitmap, const CRect& rect, BOOL bClient)
{
	BOOL bRecreate = !pBitmap->GetSafeHandle();

	if (!bRecreate)
	{
		BITMAP BM;

		bRecreate = (!pBitmap->GetBitmap(&BM));

		if (!bRecreate)
		{
			int nBitDepth = pDC->GetDeviceCaps(BITSPIXEL);

			bRecreate = (nBitDepth != BM.bmBitsPixel || 
						rect.Width() > BM.bmWidth ||
						rect.Height() > BM.bmHeight);
		}
	}

	if (bRecreate)
	{
		pBitmap->DeleteObject();
		pBitmap->CreateCompatibleBitmap(pDC, rect.Width(), rect.Height());
		TRACE("CNcGutter::PrepareBitmap(recreating %s bitmap)\n", bClient ? "client" : "non-client");
	}

	return (NULL != pBitmap->GetSafeHandle());
}

void CNcGutter::UpdateHeaderHotRects()
{
	if (!m_bShowHeader || !CThemed().AreControlsThemed())
		return;

	CRect rWindow, rClient;

	// convert rects to client coords
	GetWindowRect(rWindow);
	ScreenToClient(rWindow);

	GetClientRect(rClient);

	// allow for client edge, etc
	rWindow.DeflateRect(BORDER, BORDER);

	// adjust top of window rect to be top of header (if showing)
	CRect rHeader(rWindow);
	rHeader.bottom = rClient.top;
	rHeader.top = rHeader.bottom - HEADERHEIGHT;

	CRect rItem(rHeader);
	rItem.right = rItem.left;

	int nNumCols = m_aColumns.GetSize() - 1;  // omit last column == client

	for (int nCol = 0; nCol < nNumCols; nCol++)
	{
		rItem.left = rItem.right;
		rItem.right += m_aColumns[nCol].nWidth;
		rItem.right = min(rItem.right, rWindow.right);
		
		m_hotTrack.UpdateRect(nCol, rItem);
		
		if (rItem.right == rWindow.right)
			break;
	}

	// client bit
	rItem.left = rClient.left;
	rItem.right = rClient.right;

	m_hotTrack.UpdateRect(nNumCols, rItem);
}
