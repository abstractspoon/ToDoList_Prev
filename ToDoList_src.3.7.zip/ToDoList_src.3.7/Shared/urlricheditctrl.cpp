// urlricheditctrl.cpp : implementation file
//

#include "stdafx.h"
#include "urlricheditctrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static LPSTR URLTYPES[] = 
{
	"www",
	"http:",
	"https:",
	"ftp:",
	"file:",
};

static LPSTR URLDELIMS[] = 
{ 
	" ", 
	"\n",
	"\t",
	",",
	". ",
	";"
};

const LPCTSTR FILEPREFIX = "file:///";

/////////////////////////////////////////////////////////////////////////////
// CUrlRichEditCtrl

CUrlRichEditCtrl::CUrlRichEditCtrl() : m_hHandCursor(NULL), m_nLBtnDownUrl(-1), m_ptLBtnDown(-1, -1)
{
}

CUrlRichEditCtrl::~CUrlRichEditCtrl()
{
}


BEGIN_MESSAGE_MAP(CUrlRichEditCtrl, CRichEditCtrl)
	//{{AFX_MSG_MAP(CUrlRichEditCtrl)
	ON_CONTROL_REFLECT_EX(EN_CHANGE, OnChangeText)
	ON_WM_SETCURSOR()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_CHAR()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_SETTEXT, OnSetText)
	ON_MESSAGE(WM_SETFONT, OnSetFont)
	ON_MESSAGE(WM_DROPFILES, OnDropFiles)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUrlRichEditCtrl message handlers

BOOL CUrlRichEditCtrl::OnChangeText() 
{
	ParseAndFormatText();

	return FALSE;
}

LRESULT CUrlRichEditCtrl::OnDropFiles(WPARAM wp, LPARAM lp) 
{
	CPoint ptCursor;
	GetCursorPos(&ptCursor);
	ScreenToClient(&ptCursor);

	long nChar = -1;
	GetSel(nChar, nChar);

	CString sText, sFile;
	TCHAR szFileName[_MAX_PATH];
	UINT nFileCount = ::DragQueryFile((HDROP)wp, 0xFFFFFFFF, NULL, 0);

	ASSERT(nFileCount != 0);

	for (UINT i=0; i < nFileCount; i++)
	{
		::DragQueryFile((HDROP)wp, i, szFileName, _MAX_PATH);

		sFile.Format("%s%s", FILEPREFIX, szFileName);
		sFile.Replace(" ", "%20");
		sFile.Replace('\\', '/');

		sText += sFile;
	}
	::DragFinish((HDROP)wp);

	if (!sText.IsEmpty())
		PathReplaceSel(sText, TRUE);

	return FALSE;
}
/*
int CUrlRichEditCtrl::CharFromPoint(const CPoint& point)
{
	int nFirstLine = GetFirstVisibleLine();
	int nLineCount = GetLineCount();
	
	for (int nLine = nFirstLine; nLine < nLineCount; nLine++)
	{
		int nFirstChar = LineIndex(nLine);
		CPoint ptChar = GetCharPos(nFirstChar);
		int nLineHeight = GetLineHeight();

		if (point.y >= ptChar.y && point.y < ptChar.y + nLineHeight)
		{
			int nLineLength = LineLength(nFirstChar);

			for (int nChar = nFirstChar; nChar < (nFirstChar + nLineLength); nChar++)
			{
				ptChar = GetCharPos(nChar);

				if (point.x < ptChar.x)
					return nChar;
			}
		}
	}

	return GetTextLength();
}
*/
void CUrlRichEditCtrl::PreSubclassWindow() 
{
	SetEventMask(GetEventMask() | ENM_CHANGE | ENM_DROPFILES | ENM_DRAGDROPDONE );
	DragAcceptFiles();

	VERIFY(SetOLECallback(&m_xRichEditOleCallback));
	
	CRichEditCtrl::PreSubclassWindow();
}

LRESULT CUrlRichEditCtrl::OnSetText(WPARAM wp, LPARAM lp)
{
	LRESULT lr = Default();

	ParseAndFormatText();

	return lr;
}

LRESULT CUrlRichEditCtrl::OnSetFont(WPARAM wp, LPARAM lp)
{
	LRESULT lr = Default();

	ParseAndFormatText(TRUE);

	return lr;
}

void CUrlRichEditCtrl::ParseAndFormatText(BOOL bForceReformat)
{
	CString sText;
	GetWindowText(sText);

	// parse the text into an array of URLPOS
	CUrlArray aUrls;

	int nType = sizeof(URLTYPES) / sizeof(LPCTSTR);

	while (nType--)
	{
		FINDTEXTEX fte = { { 0, GetTextLength() - 1 }, URLTYPES[nType], {0, 0} };
		long lFind = FindText(FR_WHOLEWORD, &fte);

		while (lFind != -1)
		{
			URLITEM urli;
			urli.cr.cpMin = fte.chrgText.cpMin;
			urli.cr.cpMax = -1;

			// find the end of the url (URLDELIMS)
			int nDelim = sizeof(URLDELIMS) / sizeof(LPCTSTR);
			int nStart = fte.chrgText.cpMax;

			while (nDelim--)
			{
				fte.lpstrText = URLDELIMS[nDelim];

				long nFind = sText.Find(URLDELIMS[nDelim], nStart);

				if (nFind >= 0 && (nFind < urli.cr.cpMax || urli.cr.cpMax == -1))
					urli.cr.cpMax = nFind;
			}

			if (urli.cr.cpMax == -1)
				urli.cr.cpMax = sText.GetLength();
		
			urli.sUrl = sText.Mid(urli.cr.cpMin, urli.cr.cpMax - urli.cr.cpMin);
			aUrls.Add(urli);

			fte.chrg.cpMin = urli.cr.cpMax + 1;
			fte.lpstrText = URLTYPES[nType];

			lFind = FindText(FR_WHOLEWORD, &fte);
		}
	}

	// compare aUrls with m_aUrls to see if anything has changed
	BOOL bReformat = (bForceReformat || (aUrls.GetSize() != m_aUrls.GetSize()));

	if (!bReformat)
	{
		int nUrl = aUrls.GetSize();

		while (nUrl--)
		{
			if (aUrls[nUrl].cr.cpMin != m_aUrls[nUrl].cr.cpMin ||
				aUrls[nUrl].cr.cpMax != m_aUrls[nUrl].cr.cpMax)
			{
				bReformat = TRUE;
				break;
			}
		}
	}

	if (bReformat)
	{
		SetRedraw(FALSE);

		// save current selection
		CHARRANGE crSel;
		GetSel(crSel);

		// then clear
		CHARFORMAT cf;
		cf.cbSize = sizeof(cf);
		GetDefaultCharFormat(cf);

		cf.dwMask = CFM_UNDERLINE | CFM_COLOR | CFM_FACE | CFM_ITALIC | CFM_SIZE | CFM_STRIKEOUT;
		cf.dwEffects = CFE_AUTOCOLOR;

		SetSel(0, -1);
		SetSelectionCharFormat(cf);

		// format urls
		int nUrl = aUrls.GetSize();

		while (nUrl--)
		{
			CHARFORMAT cf;
			cf.cbSize = sizeof(cf);
			cf.dwMask = CFM_UNDERLINE | CFM_COLOR;
			cf.dwEffects = CFM_UNDERLINE;
			cf.crTextColor = RGB(0, 0, 255);

			SetSel(aUrls[nUrl].cr);
			SetSelectionCharFormat(cf);
		}		

		// restore selection
		SetSel(crSel);

		m_aUrls.Copy(aUrls);
		SetRedraw(TRUE);
		Invalidate(FALSE);
	}
}

BOOL CUrlRichEditCtrl::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	CPoint ptCursor;
	GetCursorPos(&ptCursor);
	ScreenToClient(&ptCursor);

	if ((GetKeyState(VK_CONTROL) & 0x8000) && UrlHitTest(ptCursor) != -1)
	{
		// show hand cursor
#ifndef IDC_HAND
#	define IDC_HAND  MAKEINTRESOURCE(32649) // from winuser.h
#endif
		
		if (!m_hHandCursor)
		{
			m_hHandCursor = ::LoadCursor(NULL, IDC_HAND);
			
			// fallback hack for win9x
			if (!m_hHandCursor)
			{
				CString sWinHlp32;
				
				GetWindowsDirectory(sWinHlp32.GetBuffer(MAX_PATH), MAX_PATH);
				sWinHlp32.ReleaseBuffer();
				sWinHlp32 += _T("\\winhlp32.exe");
				
				HMODULE hMod = LoadLibrary(sWinHlp32);
				
				if (hMod)
					m_hHandCursor = ::LoadCursor(hMod, MAKEINTRESOURCE(106));
			}
		}

		if (m_hHandCursor)
		{
			SetCursor(m_hHandCursor);
			return TRUE;
		}
	}
	
	return CRichEditCtrl::OnSetCursor(pWnd, nHitTest, message);
}

int CUrlRichEditCtrl::UrlHitTest(const CPoint& point) // can't be const
{
	// see if we are over any urls
	for (int nUrl = 0; nUrl < m_aUrls.GetSize(); nUrl++)
	{
		// get the four corners of the url
		URLITEM urli = m_aUrls[nUrl];
		int nLineHeight = GetLineHeight();
		
		CPoint ptTopLeft = GetCharPos(urli.cr.cpMin);
		CPoint ptBotRight = GetCharPos(urli.cr.cpMax) + CSize(0, nLineHeight);

		CRect rUrl(ptTopLeft, ptBotRight);

		// if a simple rect then easy
		if (rUrl.bottom == rUrl.top + nLineHeight)
		{
			if (rUrl.PtInRect(point))
				return nUrl;
		}
		else // create a rgn representing the url
		{
			CRgn rgn;
			rgn.CreateRectRgn(0, 0, 0, 0); // empty rgn

			// work our way down each line building the rgn as we go
			long nStartLine = LineFromChar(urli.cr.cpMin);
			long nEndLine = LineFromChar(urli.cr.cpMax);

			for (long nLine = nStartLine; nLine <= nEndLine; nLine++)
			{
				int nStartChar = LineIndex(nLine);

				if (nLine == nStartLine)
					ptTopLeft = GetCharPos(urli.cr.cpMin);
				else
					ptTopLeft = GetCharPos(nStartChar);

				if (nLine == nEndLine)
					ptBotRight = GetCharPos(urli.cr.cpMax);
				else
					ptBotRight = GetCharPos(nStartChar + LineLength(nStartChar) - 1);

				CRgn rgnLine;
				rgnLine.CreateRectRgn(ptTopLeft.x, ptTopLeft.y, ptBotRight.x, ptBotRight.y + nLineHeight);

				rgn.CombineRgn(&rgn, &rgnLine, RGN_OR);
			}

			if (rgn.PtInRegion(point))
				return nUrl;
		}
	}

	return -1;
}

int CUrlRichEditCtrl::GetLineHeight() // can't be const
{
	CHARFORMAT cf;
	GetDefaultCharFormat(cf);

	// convert height in Twips to pixels
	int nTwipsPerInch = 1440;
    int nPixelsPerInch = GetDeviceCaps(CClientDC(this), LOGPIXELSY);

	return (cf.yHeight * nPixelsPerInch) / nTwipsPerInch + 2;
}


void CUrlRichEditCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if (GetKeyState(VK_CONTROL) & 0x8000)
	{
		m_nLBtnDownUrl = UrlHitTest(point);

		if (m_nLBtnDownUrl >= 0)
			m_ptLBtnDown = point;
	}
	else
		m_nLBtnDownUrl = -1;

	CRichEditCtrl::OnLButtonDown(nFlags, point);
}

void CUrlRichEditCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if (GetKeyState(VK_CONTROL) & 0x8000)
	{
		if (m_nLBtnDownUrl >= 0 && UrlHitTest(point) == m_nLBtnDownUrl)
		{
			// check its within the clickable range
			if (abs(point.x - m_ptLBtnDown.x) <= GetSystemMetrics(SM_CXDOUBLECLK) / 2 &&
				abs(point.y - m_ptLBtnDown.y) <= GetSystemMetrics(SM_CYDOUBLECLK) / 2)
			{
				ShellExecute(*this, NULL, m_aUrls[m_nLBtnDownUrl].sUrl, NULL, NULL, SW_SHOWNORMAL);
			}
		}
	}
	else
		m_nLBtnDownUrl = -1;
	
	CRichEditCtrl::OnLButtonUp(nFlags, point);
}

/////////////////////////////////////////////////////////////////////////////
// CUrlRichEditCtrl::XRichEditOleCallback

BEGIN_INTERFACE_MAP(CUrlRichEditCtrl, CRichEditCtrl)
	// we use IID_IUnknown because richedit doesn't define an IID
	INTERFACE_PART(CUrlRichEditCtrl, IID_IUnknown, RichEditOleCallback)
END_INTERFACE_MAP()

STDMETHODIMP_(ULONG) CUrlRichEditCtrl::XRichEditOleCallback::AddRef()
{
	METHOD_PROLOGUE_EX_(CUrlRichEditCtrl, RichEditOleCallback)
	return (ULONG)pThis->InternalAddRef();
}

STDMETHODIMP_(ULONG) CUrlRichEditCtrl::XRichEditOleCallback::Release()
{
	METHOD_PROLOGUE_EX_(CUrlRichEditCtrl, RichEditOleCallback)
	return (ULONG)pThis->InternalRelease();
}

STDMETHODIMP CUrlRichEditCtrl::XRichEditOleCallback::QueryInterface(
	REFIID iid, LPVOID* ppvObj)
{
	METHOD_PROLOGUE_EX_(CUrlRichEditCtrl, RichEditOleCallback)
	return (HRESULT)pThis->InternalQueryInterface(&iid, ppvObj);
}

STDMETHODIMP CUrlRichEditCtrl::XRichEditOleCallback::GetNewStorage(LPSTORAGE* ppstg)
{
	return E_NOTIMPL;
}

STDMETHODIMP CUrlRichEditCtrl::XRichEditOleCallback::GetInPlaceContext(
	LPOLEINPLACEFRAME* lplpFrame, LPOLEINPLACEUIWINDOW* lplpDoc,
	LPOLEINPLACEFRAMEINFO lpFrameInfo)
{
	return E_NOTIMPL;
}

STDMETHODIMP CUrlRichEditCtrl::XRichEditOleCallback::ShowContainerUI(BOOL fShow)
{
	return E_NOTIMPL;
}

STDMETHODIMP CUrlRichEditCtrl::XRichEditOleCallback::QueryInsertObject(
	LPCLSID , LPSTORAGE, LONG)
{
	return E_NOTIMPL;
}

STDMETHODIMP CUrlRichEditCtrl::XRichEditOleCallback::DeleteObject(LPOLEOBJECT )
{
	return E_NOTIMPL;
}

STDMETHODIMP CUrlRichEditCtrl::XRichEditOleCallback::QueryAcceptData(
	LPDATAOBJECT lpdataobj, CLIPFORMAT* lpcfFormat, DWORD reco,
	BOOL fReally, HGLOBAL hMetaPict)
{
	// only plain text
	*lpcfFormat = CF_TEXT;

	return S_OK;
}

STDMETHODIMP CUrlRichEditCtrl::XRichEditOleCallback::ContextSensitiveHelp(BOOL )
{
	return E_NOTIMPL;
}

STDMETHODIMP CUrlRichEditCtrl::XRichEditOleCallback::GetClipboardData(
	CHARRANGE* lpchrg, DWORD reco, LPDATAOBJECT* lplpdataobj)
{
	return E_NOTIMPL;
}

STDMETHODIMP CUrlRichEditCtrl::XRichEditOleCallback::GetDragDropEffect(
	BOOL fDrag, DWORD grfKeyState, LPDWORD pdwEffect)
{
	if (!fDrag) // allowable dest effects
	{
		DWORD dwEffect;
		// check for force link
		if ((grfKeyState & (MK_CONTROL|MK_SHIFT)) == (MK_CONTROL|MK_SHIFT))
			dwEffect = DROPEFFECT_LINK;
		// check for force copy
		
		else if ((grfKeyState & MK_ALT) == MK_ALT)
			dwEffect = DROPEFFECT_MOVE;
		// default -- recommended action is move
		else
			dwEffect = DROPEFFECT_MOVE;
		if (dwEffect & *pdwEffect) // make sure allowed type
			*pdwEffect = dwEffect;
	}
	return S_OK;
}

STDMETHODIMP CUrlRichEditCtrl::XRichEditOleCallback::GetContextMenu(
	WORD seltype, LPOLEOBJECT lpoleobj, CHARRANGE* lpchrg,
	HMENU* lphmenu)
{
	METHOD_PROLOGUE_EX(CUrlRichEditCtrl, RichEditOleCallback)

	// post on as a simple context menu message
	pThis->GetParent()->PostMessage(WM_CONTEXTMENU, (WPARAM)pThis->GetSafeHwnd(), (LPARAM)::GetMessagePos());
	return E_NOTIMPL;
}

/////////////////////////////////////////////////////////////////////////////


void CUrlRichEditCtrl::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CRichEditCtrl::OnChar(nChar, nRepCnt, nFlags);
	
	int nDelim = sizeof(URLDELIMS) / sizeof(LPCTSTR);

	while (nDelim--)
	{
		if (nChar == (UINT)URLDELIMS[nDelim][0])
		{
			ParseAndFormatText(TRUE);
			break;
		}
	}
}

CString CUrlRichEditCtrl::GetUrl(int nURL, BOOL bAsFile) const
{
	ASSERT (nURL >= 0 && nURL < m_aUrls.GetSize());

	if (nURL >= 0 && nURL < m_aUrls.GetSize())
	{
		CString sFile(m_aUrls[nURL].sUrl);
		sFile.MakeLower();

		if (!bAsFile || sFile.Find(FILEPREFIX) == -1)
			return sFile;
		else
		{
			sFile = sFile.Mid(sFile.Find(FILEPREFIX) + lstrlen(FILEPREFIX));
			sFile.Replace("%20", " ");
			sFile.Replace('/', '\\');
		}

		return sFile;
	}

	// else
	return "";
}

void CUrlRichEditCtrl::PathReplaceSel(LPCTSTR lpszPath, BOOL bCanUndo)
{
	CString sPath(lpszPath);

	if (sPath.Find(":\\") != -1 || sPath.Find("\\\\") != -1)
	{
		sPath = FILEPREFIX + sPath;
		sPath.Replace(" ", "%20");
		sPath.Replace('\\', '/');
	}

	// add space fore and aft depending on selection
	CHARRANGE crSel, crSelOrg;
	GetSel(crSelOrg); // save this off
	GetSel(crSel);

	// enlarge to include end items
	if (crSel.cpMin > 0)
		crSel.cpMin--;

	if (crSel.cpMax < GetTextLength() - 1)
		crSel.cpMax++;

	SetSel(crSel);
	CString sSelText = GetSelText();
	SetSel(crSelOrg);

	// test
	if (!sSelText.IsEmpty())
	{
		if (!isspace(sSelText[0]))
			sPath = ' ' + sPath;

		if (!isspace(sSelText[sSelText.GetLength() - 1]))
			sPath += ' ';
	}

	ReplaceSel(sPath, bCanUndo);
	ParseAndFormatText();

	// set the new selection to be the dropped text
	SetSel(crSelOrg.cpMin, crSelOrg.cpMin + sPath.GetLength());
	SetFocus();
}
