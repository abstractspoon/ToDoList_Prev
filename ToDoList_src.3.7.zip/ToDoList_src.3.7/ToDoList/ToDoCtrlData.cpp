// ToDoCtrlData.cpp: implementation of the CToDoCtrlData class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "todolist.h"
#include "ToDoCtrlData.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CToDoCtrlData::CToDoCtrlData()
{

}

CToDoCtrlData::~CToDoCtrlData()
{

}

int CToDoCtrlData::FindTasks(const SEARCHPARAMS& params, CDWordArray& aResults) const
{
	if (!GetTaskCount())
		return 0;

	switch (params.nFindWhat)
	{
	case FIND_TITLECOMMENTS:
	case FIND_PERSON:
		return FindTasksByText(params, aResults);

	case FIND_STARTDATE:
	case FIND_DUEDATE:
	case FIND_DONEDATE:
		return FindTasksByDate(params, aResults);

	case FIND_PRIORITY:
		return FindTasksByPriority(params, aResults);

	case FIND_PERCENTDONE:
		return FindTasksByPercentDone(params, aResults);

	case FIND_TIMEEST:
		return FindTasksByTimeEst(params, aResults);
	}

	// else
	return 0;
}

int CToDoCtrlData::FindTasksByText(const SEARCHPARAMS& params, CDWordArray& aResults) const
{
	CStringArray aWords;
	
	if (!ParseSearchString(params.sText, aWords))
		return 0;

	// i would have prefered a neat recursive solution that returned each result
	// as it was found but i gave up, so instead we do the brute force method :(
	int nCount = 0;
	BOOL bMatchCase = (params.dwFlags & FIND_MATCHCASE);
	BOOL bMatchWholeWord = (params.dwFlags & FIND_MATCHWHOLEWORD);
	BOOL bIncludeDone = (params.dwFlags & FIND_INCLUDEDONE);

	DWORD dwUniqueID = 0;
	TODOITEM tdi;
	POSITION pos = m_mapTDItems.GetStartPosition();

	while (pos)
	{
		m_mapTDItems.GetNextAssoc(pos, dwUniqueID, tdi);

		if (!bIncludeDone && tdi.IsDone())
			continue;

		// cycle all the words on each item
		BOOL bMatch = FALSE;

		for (int nWord = 0; !bMatch && nWord < aWords.GetSize(); nWord++)
		{
			CString sWord = aWords.GetAt(nWord);

			if (params.nFindWhat == FIND_PERSON)
				bMatch = FindWord(sWord, tdi.sPerson, bMatchCase, bMatchWholeWord);
			else
			{
				bMatch = FindWord(sWord, tdi.sTitle, bMatchCase, bMatchWholeWord);

				if (!bMatch)
					bMatch = FindWord(sWord, tdi.sComments, bMatchCase, bMatchWholeWord);
			}
		}

		if (bMatch)
		{
			aResults.Add(dwUniqueID);
			nCount++;
		}
	}

	return nCount;
}

int CToDoCtrlData::FindTasksByDate(const SEARCHPARAMS& params, CDWordArray& aResults) const
{
	int nCount = 0;
	BOOL bIncludeDone = (params.dwFlags & FIND_INCLUDEDONE);

	DWORD dwUniqueID = 0;
	TODOITEM tdi;
	POSITION pos = m_mapTDItems.GetStartPosition();

	while (pos)
	{
		m_mapTDItems.GetNextAssoc(pos, dwUniqueID, tdi);
		BOOL bMatch = FALSE;

		switch (params.nFindWhat)
		{
		case FIND_STARTDATE:
			if (!tdi.HasStart() || (!bIncludeDone && tdi.IsDone()))
				continue;

			// simple comparison
			bMatch = (tdi.dateStart >= params.dateFrom && tdi.dateStart <= params.dateTo);
			break;

		case FIND_DUEDATE:
			if (!tdi.HasDue() || (!bIncludeDone && tdi.IsDone()))
				continue;

			// simple comparison
			bMatch = (tdi.dateDue >= params.dateFrom && tdi.dateDue <= params.dateTo);
			break;

		case FIND_DONEDATE:
			if (tdi.IsDone())
				bMatch = (tdi.dateDone >= params.dateFrom && tdi.dateDone <= params.dateTo);
			break;
		}

		if (bMatch)
		{
			aResults.Add(dwUniqueID);
			nCount++;
		}
	}

	return nCount;
}

int CToDoCtrlData::FindTasksByPriority(const SEARCHPARAMS& params, CDWordArray& aResults) const
{
	int nCount = 0;
	BOOL bIncludeDone = (params.dwFlags & FIND_INCLUDEDONE);

	DWORD dwUniqueID = 0;
	TODOITEM tdi;
	POSITION pos = m_mapTDItems.GetStartPosition();

	while (pos)
	{
		m_mapTDItems.GetNextAssoc(pos, dwUniqueID, tdi);

		if (!bIncludeDone && tdi.IsDone())
			continue;

		// simple comparison
		if (tdi.nPriority >= params.nFrom && tdi.nPriority <= params.nTo)
		{
			aResults.Add(dwUniqueID);
			nCount++;
		}
	}

	return nCount;
}

int CToDoCtrlData::FindTasksByPercentDone(const SEARCHPARAMS& params, CDWordArray& aResults) const
{
	int nCount = 0;
	BOOL bIncludeDone = (params.dwFlags & FIND_INCLUDEDONE);

	DWORD dwUniqueID = 0;
	TODOITEM tdi;
	POSITION pos = m_mapTDItems.GetStartPosition();

	while (pos)
	{
		m_mapTDItems.GetNextAssoc(pos, dwUniqueID, tdi);

		if (!bIncludeDone && tdi.IsDone())
			continue;

		// correct done %
		int nPercent = tdi.IsDone() ? 100 : tdi.nPercentDone;

		// simple comparison
		if (nPercent >= params.nFrom && nPercent <= params.nTo)
		{
			aResults.Add(dwUniqueID);
			nCount++;
		}
	}

	return nCount;
}

int CToDoCtrlData::FindTasksByTimeEst(const SEARCHPARAMS& params, CDWordArray& aResults) const
{
	int nCount = 0;
	BOOL bIncludeDone = (params.dwFlags & FIND_INCLUDEDONE);

	DWORD dwUniqueID = 0;
	TODOITEM tdi;
	POSITION pos = m_mapTDItems.GetStartPosition();

	while (pos)
	{
		m_mapTDItems.GetNextAssoc(pos, dwUniqueID, tdi);

		if (!bIncludeDone && tdi.IsDone())
			continue;

		// simple comparison
		if (tdi.dTimeEstimate >= params.dFrom && tdi.dTimeEstimate <= params.nTo)
		{
			aResults.Add(dwUniqueID);
			nCount++;
		}
	}

	return nCount;
}

BOOL CToDoCtrlData::FindWord(LPCTSTR szWord, LPCTSTR szText, BOOL bMatchCase, BOOL bMatchWholeWord)
{
	CString sWord(szWord), sText(szText);

	if (sWord.GetLength() > sText.GetLength())
		return FALSE;

	sWord.TrimLeft();
	sWord.TrimRight();

	if (!bMatchCase)
	{
		sWord.MakeUpper();
		sText.MakeUpper();
	}

	int nFind = sText.Find(sWord);

	if (nFind == -1)
		return FALSE;

	else if (bMatchWholeWord) // test whole word
	{
		const CString DELIMS("()-\\/{}[]:;,. ?\"'");

		// prior and next chars must be delimeters
		char cPrevChar = 0, cNextChar = 0;
		
		// prev
		if (nFind == 0) // word starts at start
			cPrevChar = ' '; // known delim
		else
			cPrevChar = sText[nFind - 1];

		// next
		if ((nFind + sWord.GetLength() + 1) < sText.GetLength())
			cNextChar = sText[nFind + sWord.GetLength()];
		else
			cNextChar = ' '; // known delim

		if (DELIMS.Find(cPrevChar) == -1 || DELIMS.Find(cNextChar) == -1)
			return FALSE;
	}

	return TRUE;
}

int CToDoCtrlData::ParseSearchString(LPCTSTR szLookFor, CStringArray& aWords)
{
	aWords.RemoveAll();

	// parse on spaces unless enclosed in double-quotes
	int nLen = lstrlen(szLookFor);
	BOOL bInQuotes = FALSE, bAddWord = FALSE;
	CString sWord;

	for (int nPos = 0; nPos < nLen; nPos++)
	{
		switch (szLookFor[nPos])
		{
		case ' ': // word break
			if (bInQuotes)
				sWord += szLookFor[nPos];
			else
				bAddWord = TRUE;
			break;

		case '\"':
			// whether its the start or end we add the current word
			// and flip bInQuotes
			bInQuotes = !bInQuotes;
			bAddWord = TRUE;
			break;

		default: // everything else
			sWord += szLookFor[nPos];

			// also if its the last char then add it
			bAddWord = (nPos == nLen - 1);
			break;
		}

		if (bAddWord)
		{
			sWord.TrimLeft();
			sWord.TrimRight();
			
			if (!sWord.IsEmpty())
				aWords.Add(sWord);
			
			sWord.Empty(); // next word
		}
	}

	return aWords.GetSize();
}

CString CToDoCtrlData::GetTaskComments(DWORD dwUniqueID) const
{
	TODOITEM tdi;

	if (GetTask(dwUniqueID, tdi))
		return tdi.sComments;

	return "";
}

double CToDoCtrlData::GetTaskEstimate(DWORD dwUniqueID) const
{
	TODOITEM tdi;

	if (GetTask(dwUniqueID, tdi))
		return tdi.dTimeEstimate;

	return 0;
}

CString CToDoCtrlData::GetTaskPerson(DWORD dwUniqueID) const
{
	TODOITEM tdi;

	if (GetTask(dwUniqueID, tdi))
		return tdi.sPerson;

	return "";
}

COLORREF CToDoCtrlData::GetTaskColor(DWORD dwUniqueID) const
{
	TODOITEM tdi;

	if (GetTask(dwUniqueID, tdi))
		return tdi.color;

	return 0;
}

int CToDoCtrlData::GetTaskPriority(DWORD dwUniqueID) const
{
	TODOITEM tdi;

	if (GetTask(dwUniqueID, tdi))
		return tdi.nPriority;

	return 0;
}

COleDateTime CToDoCtrlData::GetTaskDueDate(DWORD dwUniqueID) const
{
	TODOITEM tdi;

	if (GetTask(dwUniqueID, tdi))
		return tdi.dateDue;

	return COleDateTime();
}

COleDateTime CToDoCtrlData::GetTaskStartDate(DWORD dwUniqueID) const
{
	TODOITEM tdi;

	if (GetTask(dwUniqueID, tdi))
		return tdi.dateStart;

	return COleDateTime();
}

COleDateTime CToDoCtrlData::GetTaskDoneDate(DWORD dwUniqueID) const
{
	TODOITEM tdi;

	if (GetTask(dwUniqueID, tdi))
		return tdi.dateDone;

	return COleDateTime();
}

BOOL CToDoCtrlData::IsTaskDone(DWORD dwUniqueID) const
{
	TODOITEM tdi;

	if (GetTask(dwUniqueID, tdi))
		return tdi.IsDone();

	return FALSE;
}

BOOL CToDoCtrlData::IsTaskDue(DWORD dwUniqueID) const
{
	TODOITEM tdi;
	
	if (GetTask(dwUniqueID, tdi))
		return tdi.IsDue();

	return FALSE;
}
	
int CToDoCtrlData::GetTaskPercent(DWORD dwUniqueID, BOOL bCheckIfDone) const
{
	TODOITEM tdi;

	if (GetTask(dwUniqueID, tdi))
	{
		if (bCheckIfDone)
			return tdi.IsDone() ? 100 : tdi.nPercentDone;
		else
			return tdi.nPercentDone;
	}

	return 0;
}

CString CToDoCtrlData::GetTaskFileRef(DWORD dwUniqueID) const
{
	TODOITEM tdi;

	if (GetTask(dwUniqueID, tdi))
		return tdi.sFileRefPath;

	return "";
}
