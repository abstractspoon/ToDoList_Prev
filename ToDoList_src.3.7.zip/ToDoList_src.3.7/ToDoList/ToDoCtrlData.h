// ToDoCtrlData.h: interface for the CToDoCtrlData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TODOCTRLDATA_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_)
#define AFX_TODOCTRLDATA_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>

enum // find flags
{
	FIND_TITLECOMMENTS	= 0,
	FIND_PRIORITY,
	FIND_PERCENTDONE,
	FIND_TIMEEST,
	FIND_STARTDATE,
	FIND_DUEDATE,
	FIND_DONEDATE,
	FIND_PERSON,

	FIND_INCLUDEDONE	= 0x0100,
	FIND_MATCHCASE		= 0x0200,
	FIND_MATCHWHOLEWORD	= 0x0400,
};

struct SEARCHPARAMS
{
	int nFindWhat;
	DWORD dwFlags;

	CString sText;
	COleDateTime dateFrom, dateTo;
	int nFrom, nTo;
	double dFrom, dTo;
};

struct TODOITEM
{
	TODOITEM(LPCTSTR szTitle, LPCTSTR szComments = NULL) 
	{ 
		sTitle = szTitle; 
		sComments = szComments; 
		color = 0; 
		dateStart.m_dt = dateDone.m_dt = dateDue.m_dt = 0;
		nPriority = 5;
		nPercentDone = 0;
		dTimeEstimate = 0;
		
		SetModified();
	}
	
	TODOITEM() 
	{ 
		color = 0; 
		dateStart.m_dt = dateDone.m_dt = dateDue.m_dt = 0;
		nPriority = 5;
		nPercentDone = 0;
		dTimeEstimate = 0;
		
		SetModified();
	}
	
	TODOITEM(const TODOITEM& tdi) 
	{ 
		sTitle = tdi.sTitle; 
		sComments = tdi.sComments; 
		color = tdi.color; 
		dateStart = tdi.dateStart;
		dateDone = tdi.dateDone;
		dateDue = tdi.dateDue;
		nPriority = tdi.nPriority;
		nPercentDone = tdi.nPercentDone;
		sFileRefPath = tdi.sFileRefPath;
		dTimeEstimate = tdi.dTimeEstimate;
		
		SetModified();
	}
	
	inline BOOL HasStart() const { return (dateStart.m_dt > 0) ? TRUE : FALSE;; }
	inline BOOL HasDue() const { return (dateDue.m_dt > 0) ? TRUE : FALSE;; }
	inline BOOL IsDone() const { return (dateDone.m_dt > 0) ? TRUE : FALSE; }
	
	BOOL IsDue() const
	{ 
		return IsDue(COleDateTime::GetCurrentTime());
	}
	
	BOOL IsDue(const COleDateTime& dateDueBy) const
	{ 
		if (IsDone() || !HasDue())
			return FALSE;
		
		return ((double)(int)dateDue.m_dt <= (double)(int)dateDueBy.m_dt); 
	}
	
	void SetModified() { tLastMod = COleDateTime::GetCurrentTime(); }
	
	CString sTitle;
	CString sComments;
	COLORREF color;
	COleDateTime dateStart, dateDue, dateDone;
	int nPriority;
	CString sPerson;
	int nPercentDone;
	CString sFileRefPath;
	double dTimeEstimate;
	COleDateTime tLastMod;
};

typedef CMap<DWORD, DWORD, TODOITEM, TODOITEM&> CTDIMap;

class CToDoCtrlData  
{
public:
	CToDoCtrlData();
	virtual ~CToDoCtrlData();

	inline BOOL GetTask(DWORD dwUniqueID, TODOITEM& tdi) const { return m_mapTDItems.Lookup(dwUniqueID, tdi); }
	inline void UpdateTask(DWORD dwUniqueID, TODOITEM& tdi) { tdi.SetModified(); m_mapTDItems[dwUniqueID] = tdi; }
	inline void AddTask(DWORD dwUniqueID, TODOITEM& tdi) { m_mapTDItems.SetAt(dwUniqueID, tdi); }
	inline void DeleteTask(DWORD dwUniqueID) { m_mapTDItems.RemoveKey(dwUniqueID); }
	inline void DeleteAllTasks() { m_mapTDItems.RemoveAll(); }
	inline UINT GetTaskCount() const { return m_mapTDItems.GetCount(); }

	// Gets
	COleDateTime GetTaskDoneDate(DWORD dwUniqueID) const;
	COleDateTime GetTaskDueDate(DWORD dwUniqueID) const;
	COleDateTime GetTaskStartDate(DWORD dwUniqueID) const;
	BOOL IsTaskDone(DWORD dwUniqueID) const;
	BOOL IsTaskDue(DWORD dwUniqueID) const;
	COLORREF GetTaskColor(DWORD dwUniqueID) const; // -1 on no item selected
	CString GetTaskComments(DWORD dwUniqueID) const;
	int GetTaskPercent(DWORD dwUniqueID, BOOL bCheckIfDone) const;
	double GetTaskEstimate(DWORD dwUniqueID) const;
	CString GetTaskPerson(DWORD dwUniqueID) const;
	CString GetTaskFileRef(DWORD dwUniqueID) const;
	int GetTaskPriority(DWORD dwUniqueID) const;

	// Sets
/*	BOOL SetTaskStartDate(DWORD dwUniqueID, COleDateTime& date);
	BOOL SetTaskDoneDate(DWORD dwUniqueID, COleDateTime& date);
	BOOL SetTaskDueDate(DWORD dwUniqueID, COleDateTime& date);
	BOOL SetTaskDone(DWORD dwUniqueID, BOOL bDone = TRUE);
	BOOL SetTaskColor(DWORD dwUniqueID, COLORREF color);
	BOOL SetTaskComments(DWORD dwUniqueID, LPCTSTR szComments);
	BOOL SetTaskPercentDone(DWORD dwUniqueID, int nPercent);
	BOOL SetTaskEstimate(DWORD dwUniqueID, double dHours);
	BOOL SetTaskPerson(DWORD dwUniqueID, LPCTSTR szPerson);
	BOOL SetTaskFileRef(DWORD dwUniqueID, LPCTSTR szFilePath);
	BOOL SetTaskPriority(DWORD dwUniqueID, int nPriority); // 0-10 (10 is highest)
*/
	int FindTasks(const SEARCHPARAMS& params, CDWordArray& aResults) const;

protected:
	CTDIMap m_mapTDItems;

protected:
	static int ParseSearchString(LPCTSTR szLookFor, CStringArray& aWords);
	static BOOL FindWord(LPCTSTR szWord, LPCTSTR szText, BOOL bMatchCase, BOOL bMatchWholeWord);
	
	int FindTasksByText(const SEARCHPARAMS& params, CDWordArray& aResults) const;
	int FindTasksByDate(const SEARCHPARAMS& params, CDWordArray& aResults) const;
	int FindTasksByPriority(const SEARCHPARAMS& params, CDWordArray& aResults) const;
	int FindTasksByPercentDone(const SEARCHPARAMS& params, CDWordArray& aResults) const;
	int FindTasksByTimeEst(const SEARCHPARAMS& params, CDWordArray& aResults) const;

};

#endif // !defined(AFX_TODOCTRLDATA_H__02C3C360_45AB_45DC_B1BF_BCBEA472F0C7__INCLUDED_)
