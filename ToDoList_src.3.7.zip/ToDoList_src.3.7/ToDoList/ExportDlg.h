#if !defined(AFX_EXPORTDLG_H__2F5B4FD1_E968_464E_9734_AC995DB13B35__INCLUDED_)
#define AFX_EXPORTDLG_H__2F5B4FD1_E968_464E_9734_AC995DB13B35__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ExportDlg.h : header file
//

#include "..\shared\fileedit.h"
#include "..\shared\dialoghelper.h"

/////////////////////////////////////////////////////////////////////////////
// CExportDlg dialog

enum { ED_HTMLFMT, ED_TEXTFMT };

class CExportDlg : public CDialog, public CDialogHelper
{
// Construction
public:
	CExportDlg(BOOL bSingleTaskList, LPCTSTR szFilePath = NULL, LPCTSTR szFolderPath = NULL, CWnd* pParent = NULL);   // standard constructor

	BOOL GetExportAllTasklists();
	BOOL GetExportFormat() { return m_nFormatOption; }
	CString GetExportPath() { return m_sExportPath; } // can be folder or path
	BOOL GetIncludeCompletedTasks() { return m_bIncludeDone; }
	BOOL GetIncludeUncompletedTasks() { return m_bIncludeNotDone; }
	BOOL GetExportOneFile() { return (m_bSingleTaskList || m_bExportOneFile); }

protected:
// Dialog Data
	//{{AFX_DATA(CExportDlg)
	enum { IDD = IDD_EXPORT_DIALOG };
	CFileEdit	m_eExportPath;
	int		m_nExportOption;
	int		m_nFormatOption;
	CString	m_sExportPath;
	BOOL	m_bIncludeDone;
	BOOL	m_bIncludeNotDone;
	BOOL	m_bExportOneFile;
	//}}AFX_DATA
	BOOL m_bSingleTaskList; 
	CString m_sFolderPath, m_sFilePath;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExportDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	virtual void OnOK();

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CExportDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeTasklistoptions();
	afx_msg void OnSelchangeFormatoptions();
	afx_msg void OnExportonefile();
	afx_msg void OnInclude();
	afx_msg void OnChangeExportpath();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void EnableOK();

	static void ReplaceExtension(CString& sPathName, int nFormat);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXPORTDLG_H__2F5B4FD1_E968_464E_9734_AC995DB13B35__INCLUDED_)
