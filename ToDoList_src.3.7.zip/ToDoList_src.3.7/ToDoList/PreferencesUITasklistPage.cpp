// PreferencesUITasklistPage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesUITasklistPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUITasklistPage property page

// default priority colors
const COLORREF PRIORITYLOWCOLOR = RGB(30, 225, 0);
const COLORREF PRIORITYHIGHCOLOR = RGB(255, 0, 0);
const COLORREF CBMASKCOLOR = RGB(255, 0, 0);

IMPLEMENT_DYNCREATE(CPreferencesUITasklistPage, CPropertyPage)

CPreferencesUITasklistPage::CPreferencesUITasklistPage() : 
	CPropertyPage(CPreferencesUITasklistPage::IDD),
	m_eCheckboxImagePath(FES_COMBOSTYLEBTN, "Image Files (*.bmp, *.gif)|*.bmp;*.gif||")

{
	//{{AFX_DATA_INIT(CPreferencesUITasklistPage)
	m_bUseISOForDates = FALSE;
	//}}AFX_DATA_INIT
	// priority colors

	m_crLow = AfxGetApp()->GetProfileInt("Preferences\\Colors", "Low", PRIORITYLOWCOLOR);
	m_crHigh = AfxGetApp()->GetProfileInt("Preferences\\Colors", "High", PRIORITYHIGHCOLOR);

	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P0", RGB(30, 225, 0)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P1", RGB(30, 225, 0)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P2", RGB(30, 225, 0)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P3", RGB(30, 225, 0)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P4", RGB(0, 0, 255)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P5", RGB(0, 0, 255)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P6", RGB(0, 0, 255)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P7", RGB(0, 0, 255)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P8", RGB(255, 0, 0)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P9", RGB(255, 0, 0)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P10", RGB(255, 0, 0)));

	// column visibility
	m_aColPrefs.Add(COLUMNPREF("Position", PTPC_POSITION, -1)); 
	m_aColPrefs.Add(COLUMNPREF("ID", PTPC_ID, -1)); 
	m_aColPrefs.Add(COLUMNPREF("Priority", PTPC_PRIORITY, -1)); 
	m_aColPrefs.Add(COLUMNPREF("Percent Complete", PTPC_PERCENT, -1)); 
	m_aColPrefs.Add(COLUMNPREF("Time Estimate", PTPC_TIMEEST, -1)); 
	m_aColPrefs.Add(COLUMNPREF("Start Date", PTPC_STARTDATE, -1));
	m_aColPrefs.Add(COLUMNPREF("Due Date", PTPC_DUEDATE, -1)); 
	m_aColPrefs.Add(COLUMNPREF("Completed Date", PTPC_DONEDATE, -1)); 
	m_aColPrefs.Add(COLUMNPREF("Allocated To", PTPC_PERSON, -1)); 
	m_aColPrefs.Add(COLUMNPREF("File Reference", PTPC_FILEREF, -1)); 
	m_aColPrefs.Add(COLUMNPREF("Completed", PTPC_DONE, -1)); 

	BOOL bBkwdComp = (-1 == AfxGetApp()->GetProfileInt("Preferences\\ColumnVisibility", "Col0", -1));

	// backwards compatibility
	if (bBkwdComp)
	{
		int nIndex = m_aColPrefs.GetSize();

		while (nIndex--)
		{
			switch (m_aColPrefs[nIndex].nCol)
			{
			case PTPC_PERCENT:
				m_aColPrefs[nIndex].bVisible = AfxGetApp()->GetProfileInt("Preferences", "ShowPercentColumn", 1);
				break;

			case PTPC_PRIORITY:
				m_aColPrefs[nIndex].bVisible = AfxGetApp()->GetProfileInt("Preferences", "ShowPriorityColumn", 1);
				break;

			case PTPC_TIMEEST:
				m_aColPrefs[nIndex].bVisible = AfxGetApp()->GetProfileInt("Preferences", "ShowTimeColumn", 1);
				break;

			case PTPC_POSITION:
			case PTPC_DONE:
				m_aColPrefs[nIndex].bVisible = TRUE;
				break;

			default:
				m_aColPrefs[nIndex].bVisible = FALSE;
				break;
			}
		}
	}
	else
	{
		int nIndex = m_aColPrefs.GetSize();

		while (nIndex--)
		{
			CString sKey;
			sKey.Format("Col%d", m_aColPrefs[nIndex].nCol);

			PTP_COLUMN nCol = m_aColPrefs[nIndex].nCol;
			BOOL bDefault = (nCol == PTPC_POSITION || nCol == PTPC_DONE);

			m_aColPrefs[nIndex].bVisible = AfxGetApp()->GetProfileInt("Preferences\\ColumnVisibility", 
															sKey, bDefault);
		}
	}

	// prefs
	m_bColorTextByPriority = AfxGetApp()->GetProfileInt("Preferences", "ColorByPriority", FALSE);
	m_bShowInfoTips = AfxGetApp()->GetProfileInt("Preferences", "ShowInfoTips", TRUE);
	m_bShowComments = AfxGetApp()->GetProfileInt("Preferences", "ShowComments", TRUE);
	m_bColorPriority = AfxGetApp()->GetProfileInt("Preferences", "ColorPriority", FALSE);
	m_bShowButtonsInTree = AfxGetApp()->GetProfileInt("Preferences", "ShowButtonsInTree", TRUE);
	m_bIndividualPriorityColors = AfxGetApp()->GetProfileInt("Preferences", "IndividualPriorityColors", FALSE);
	m_sTreeFont = AfxGetApp()->GetProfileString("Preferences", "TreeFont", "Arial");
	m_nFontSize = AfxGetApp()->GetProfileInt("Preferences", "FontSize", 8);
	m_bSpecifyTreeFont = AfxGetApp()->GetProfileInt("Preferences", "SpecifyTreeFont", FALSE);
	m_bSpecifyGridColor = AfxGetApp()->GetProfileInt("Preferences", "SpecifyGridColor", TRUE);
	m_crGridlines = AfxGetApp()->GetProfileInt("Preferences\\Colors", "Gridlines", GRIDLINECOLOR);
	m_bSpecifyDoneColor = AfxGetApp()->GetProfileInt("Preferences", "SpecifyDoneColor", TRUE);
	m_crDone = AfxGetApp()->GetProfileInt("Preferences\\Colors", "TaskDone", TASKDONECOLOR);
	m_bStrikethroughDone = AfxGetApp()->GetProfileInt("Preferences", "StrikethroughDone", TRUE);
	m_bShowPathInHeader = AfxGetApp()->GetProfileInt("Preferences", "ShowPathInHeader", TRUE);
	m_bFullRowSelection = AfxGetApp()->GetProfileInt("Preferences", "FullRowSelection", FALSE);
	m_bTreeCheckboxes = AfxGetApp()->GetProfileInt("Preferences", "TreeCheckboxes", FALSE);
	m_bEnableHeaderSorting = AfxGetApp()->GetProfileInt("Preferences", "EnableHeaderSorting", TRUE);
	m_bSpecifyCheckboxImage = AfxGetApp()->GetProfileInt("Preferences", "SpecifyCheckboxImage", FALSE);
	m_sCheckboxImagePath = AfxGetApp()->GetProfileString("Preferences", "CheckboxImagePath");
	m_crCheckboxMask = AfxGetApp()->GetProfileInt("Preferences", "CheckboxMaskColor", CBMASKCOLOR);
	m_bColorTaskBackground = AfxGetApp()->GetProfileInt("Preferences", "ColorTaskBackground", FALSE);
	m_bCommentsUseTreeFont = AfxGetApp()->GetProfileInt("Preferences", "CommentsUseTreeFont", FALSE);
	m_bUseISOForDates = AfxGetApp()->GetProfileInt("Preferences", "DisplayDatesInISO", FALSE);
}

CPreferencesUITasklistPage::~CPreferencesUITasklistPage()
{
}

void CPreferencesUITasklistPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesUITasklistPage)
	DDX_Check(pDX, IDC_COLORTASKBKGND, m_bColorTaskBackground);
	DDX_Check(pDX, IDC_COMMENTSUSETREEFONT, m_bCommentsUseTreeFont);
	DDX_Check(pDX, IDC_USEISODATEFORMAT, m_bUseISOForDates);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_CHECKBOXMASKCOLOR, m_btCheckboxMaskColor);
	DDX_Control(pDX, IDC_CHECKBOXIMAGEPATH, m_eCheckboxImagePath);
	DDX_Control(pDX, IDC_SETDONECOLOR, m_btDoneColor);
	DDX_Control(pDX, IDC_SETGRIDLINECOLOR, m_btGridlineColor);
	DDX_Control(pDX, IDC_TREEFONTSIZE, m_cbFontSize);
	DDX_Control(pDX, IDC_TREEFONTLIST, m_cbFonts);
	DDX_Check(pDX, IDC_SPECIFYTREEFONT, m_bSpecifyTreeFont);
	DDX_Check(pDX, IDC_SPECIFYGRIDLINECOLOR, m_bSpecifyGridColor);
	DDX_Check(pDX, IDC_SPECIFYDONECOLOR, m_bSpecifyDoneColor);
	DDX_Check(pDX, IDC_DISPLAYPATHINHEADER, m_bShowPathInHeader);
	DDX_Check(pDX, IDC_STRIKETHROUGHDONE, m_bStrikethroughDone);
	DDX_Check(pDX, IDC_FULLROWSELECTION, m_bFullRowSelection);
	DDX_Check(pDX, IDC_TREECHECKBOXES, m_bTreeCheckboxes);
	DDX_Check(pDX, IDC_ENABLEHEADERSORTING, m_bEnableHeaderSorting);
	DDX_Check(pDX, IDC_SPECIFYCHECKIMAGE, m_bSpecifyCheckboxImage);
	DDX_Text(pDX, IDC_CHECKBOXIMAGEPATH, m_sCheckboxImagePath);
	DDX_Control(pDX, IDC_COLUMNVISIBILITY, m_lbColumnVisibility);
	DDX_Control(pDX, IDC_SETPRIORITYCOLOR, m_btSetColor);
	DDX_Control(pDX, IDC_LOWPRIORITYCOLOR, m_btLowColor);
	DDX_Control(pDX, IDC_HIGHPRIORITYCOLOR, m_btHighColor);
	DDX_Check(pDX, IDC_COLORTEXTBYPRIORITY, m_bColorTextByPriority);
	DDX_Check(pDX, IDC_SHOWINFOTIPS, m_bShowInfoTips);
	DDX_Check(pDX, IDC_SHOWCOMMENTS, m_bShowComments);
	DDX_Check(pDX, IDC_COLORPRIORITY, m_bColorPriority);
	DDX_Check(pDX, IDC_SHOWBUTTONSINTREE, m_bShowButtonsInTree);
	DDX_Radio(pDX, IDC_GRADIENTPRIORITYCOLORS, m_bIndividualPriorityColors);
	DDX_CBIndex(pDX, IDC_PRIORITYCOLORS, m_nSelPriorityColor);
	DDX_LBIndex(pDX, IDC_COLUMNVISIBILITY, m_nSelColumnVisibility);

	if (pDX->m_bSaveAndValidate)
	{
		m_sTreeFont = m_cbFonts.GetSelectedFont();

		CString sSize;
		m_cbFontSize.GetLBText(m_cbFontSize.GetCurSel(), sSize);
		m_nFontSize = atoi(sSize);
	}
	else
	{
		m_cbFonts.SetSelectedFont(m_sTreeFont);

		CString sFontSize;
		sFontSize.Format("%d", m_nFontSize);

		if (CB_ERR == m_cbFontSize.SelectString(-1, sFontSize))
		{
			m_nFontSize = 9;
			m_cbFontSize.SetCurSel(0);
		}
	}
}


BEGIN_MESSAGE_MAP(CPreferencesUITasklistPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPreferencesUITasklistPage)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_SPECIFYTREEFONT, OnSpecifytreefont)
	ON_BN_CLICKED(IDC_SETGRIDLINECOLOR, OnSetgridlinecolor)
	ON_BN_CLICKED(IDC_SPECIFYGRIDLINECOLOR, OnSpecifygridlinecolor)
	ON_BN_CLICKED(IDC_SETDONECOLOR, OnSetdonecolor)
	ON_BN_CLICKED(IDC_SPECIFYDONECOLOR, OnSpecifydonecolor)
	ON_BN_CLICKED(IDC_CHECKBOXMASKCOLOR, OnCheckboxmaskcolor)
	ON_BN_CLICKED(IDC_LOWPRIORITYCOLOR, OnLowprioritycolor)
	ON_BN_CLICKED(IDC_HIGHPRIORITYCOLOR, OnHighprioritycolor)
	ON_BN_CLICKED(IDC_SETPRIORITYCOLOR, OnSetprioritycolor)
	ON_BN_CLICKED(IDC_GRADIENTPRIORITYCOLORS, OnChangePriorityColorOption)
	ON_BN_CLICKED(IDC_COLORPRIORITY, OnColorPriority)
	ON_CBN_SELCHANGE(IDC_PRIORITYCOLORS, OnSelchangePrioritycolors)
	ON_BN_CLICKED(IDC_INDIVIDUALPRIORITYCOLORS, OnChangePriorityColorOption)
	ON_BN_CLICKED(IDC_SPECIFYCHECKIMAGE, OnSpecifycheckimage)
	ON_CLBN_CHKCHANGE(IDC_COLUMNVISIBILITY, OnColVisibilityChange)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUITasklistPage message handlers

BOOL CPreferencesUITasklistPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	GetDlgItem(IDC_GRADIENTPRIORITYCOLORS)->EnableWindow(m_bColorPriority);
	GetDlgItem(IDC_INDIVIDUALPRIORITYCOLORS)->EnableWindow(m_bColorPriority);
	GetDlgItem(IDC_COLORTEXTBYPRIORITY)->EnableWindow(m_bColorPriority);
	GetDlgItem(IDC_PRIORITYCOLORS)->EnableWindow(m_bColorPriority && m_bIndividualPriorityColors);
	GetDlgItem(IDC_TREEFONTLIST)->EnableWindow(m_bSpecifyTreeFont);
	GetDlgItem(IDC_TREEFONTSIZE)->EnableWindow(m_bSpecifyTreeFont);
	GetDlgItem(IDC_TREEFONTSIZELABEL)->EnableWindow(m_bSpecifyTreeFont);
	GetDlgItem(IDC_COMMENTSUSETREEFONT)->EnableWindow(m_bSpecifyTreeFont);
	GetDlgItem(IDC_CHECKBOXIMAGEPATH)->EnableWindow(m_bSpecifyCheckboxImage);
	GetDlgItem(IDC_CHECKBOXMASKCOLOR)->EnableWindow(m_bSpecifyCheckboxImage);

	m_btSetColor.EnableWindow(m_bColorPriority && m_bIndividualPriorityColors);
	m_btLowColor.EnableWindow(m_bColorPriority && !m_bIndividualPriorityColors);
	m_btHighColor.EnableWindow(m_bColorPriority && !m_bIndividualPriorityColors);
	m_btGridlineColor.EnableWindow(m_bSpecifyGridColor);
	m_btDoneColor.EnableWindow(m_bSpecifyDoneColor);
	m_btCheckboxMaskColor.EnableWindow(m_bSpecifyCheckboxImage);
	
	m_btGridlineColor.SetColor(m_crGridlines);
	m_btLowColor.SetColor(m_crLow);
	m_btHighColor.SetColor(m_crHigh);
	m_btSetColor.SetColor(m_aPriorityColors[0]);
	m_btDoneColor.SetColor(m_crDone);
	m_btCheckboxMaskColor.SetColor(m_crCheckboxMask);

	int nIndex = (int)m_aColPrefs.GetSize();
	
	while (nIndex--)
	{
		int nPos = m_lbColumnVisibility.InsertString(0, m_aColPrefs[nIndex].szName);
		m_lbColumnVisibility.SetCheck(nPos, m_aColPrefs[nIndex].bVisible ? 1 : 0);

		// note: we can't use SetItemData because CCheckListBox uses it
	}
		
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CPreferencesUITasklistPage::GetShowColumn(PTP_COLUMN nColumn) const
{ 
	int nIndex = (int)m_aColPrefs.GetSize();
	
	while (nIndex--)
	{
		if (m_aColPrefs[nIndex].nCol == nColumn)
			return m_aColPrefs[nIndex].bVisible; 
	}

	// else
	return FALSE;
}

void CPreferencesUITasklistPage::OnLowprioritycolor() 
{
	m_crLow = m_btLowColor.GetColor();
}

void CPreferencesUITasklistPage::OnHighprioritycolor() 
{
	m_crHigh = m_btHighColor.GetColor();
}

void CPreferencesUITasklistPage::OnSetprioritycolor() 
{
	VERIFY(m_nSelPriorityColor >= 0);

	m_aPriorityColors.SetAt(m_nSelPriorityColor, m_btSetColor.GetColor());
}

void CPreferencesUITasklistPage::OnChangePriorityColorOption() 
{
	UpdateData();

	GetDlgItem(IDC_PRIORITYCOLORS)->EnableWindow(m_bColorPriority && m_bIndividualPriorityColors);

	m_btSetColor.EnableWindow(m_bColorPriority && m_bIndividualPriorityColors && m_nSelPriorityColor >= 0);
	m_btLowColor.EnableWindow(m_bColorPriority && !m_bIndividualPriorityColors);
	m_btHighColor.EnableWindow(m_bColorPriority && !m_bIndividualPriorityColors);
}

void CPreferencesUITasklistPage::OnColorPriority() 
{
	UpdateData();

	GetDlgItem(IDC_GRADIENTPRIORITYCOLORS)->EnableWindow(m_bColorPriority);
	GetDlgItem(IDC_INDIVIDUALPRIORITYCOLORS)->EnableWindow(m_bColorPriority);
	GetDlgItem(IDC_COLORTEXTBYPRIORITY)->EnableWindow(m_bColorPriority);

	OnChangePriorityColorOption(); // to handle the other controls
}

int CPreferencesUITasklistPage::GetPriorityColors(CDWordArray& aColors) const 
{ 
	aColors.RemoveAll();

	if (m_bColorPriority)
	{
		if (m_bIndividualPriorityColors)
			aColors.Copy(m_aPriorityColors); 
		else
		{
			aColors.Add(m_crLow);
			aColors.Add(m_crHigh);
		}
	}
	
	return aColors.GetSize(); 
}

void CPreferencesUITasklistPage::OnSelchangePrioritycolors() 
{
	UpdateData();

	ASSERT (m_nSelPriorityColor >= 0);
	
	if (m_nSelPriorityColor >= 0)
		m_btSetColor.SetColor(m_aPriorityColors[m_nSelPriorityColor]);
}

void CPreferencesUITasklistPage::OnColVisibilityChange()
{
	UpdateData();

	ASSERT (m_nSelColumnVisibility >= 0);
	
	if (m_nSelColumnVisibility >= 0)
		m_aColPrefs[m_nSelColumnVisibility].bVisible = m_lbColumnVisibility.GetCheck(m_nSelColumnVisibility);
}


void CPreferencesUITasklistPage::OnOK() 
{
	CPropertyPage::OnOK();
	
	// save settings
	// priority colors
	AfxGetApp()->WriteProfileInt("Preferences\\Colors", "Low", m_crLow);
	AfxGetApp()->WriteProfileInt("Preferences\\Colors", "High", m_crHigh);

	int nColor = 11;

	while (nColor--)
	{
		CString sKey;
		sKey.Format("P%d", nColor);
		AfxGetApp()->WriteProfileInt("Preferences\\Colors", sKey, m_aPriorityColors[nColor]);
	}

	// column visibility
	int nIndex = m_aColPrefs.GetSize();

	while (nIndex--)
	{
		CString sKey;
		sKey.Format("Col%d", m_aColPrefs[nIndex].nCol);

		AfxGetApp()->WriteProfileInt("Preferences\\ColumnVisibility", sKey, m_aColPrefs[nIndex].bVisible);
	}

	// save settings
	AfxGetApp()->WriteProfileInt("Preferences", "ColorByPriority", m_bColorTextByPriority);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowInfoTips", m_bShowInfoTips);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowComments", m_bShowComments);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowPercentColumn", m_bShowPercentColumn);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowPriorityColumn", m_bShowPriorityColumn);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowTimeColumn", m_bShowTimeColumn);
	AfxGetApp()->WriteProfileInt("Preferences", "ColorPriority", m_bColorPriority);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowButtonsInTree", m_bShowButtonsInTree);
	AfxGetApp()->WriteProfileInt("Preferences", "IndividualPriorityColors", m_bIndividualPriorityColors);
	AfxGetApp()->WriteProfileString("Preferences", "TreeFont", m_sTreeFont);
	AfxGetApp()->WriteProfileInt("Preferences", "FontSize", m_nFontSize);
	AfxGetApp()->WriteProfileInt("Preferences", "SpecifyTreeFont", m_bSpecifyTreeFont);
	AfxGetApp()->WriteProfileInt("Preferences", "SpecifyGridColor", m_bSpecifyGridColor);
	AfxGetApp()->WriteProfileInt("Preferences\\Colors", "Gridlines", m_crGridlines);
	AfxGetApp()->WriteProfileInt("Preferences", "SpecifyDoneColor", m_bSpecifyDoneColor);
	AfxGetApp()->WriteProfileInt("Preferences\\Colors", "TaskDone", m_crDone);
	AfxGetApp()->WriteProfileInt("Preferences", "StrikethroughDone", m_bStrikethroughDone);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowPathInHeader", m_bShowPathInHeader);
	AfxGetApp()->WriteProfileInt("Preferences", "FullRowSelection", m_bFullRowSelection);
	AfxGetApp()->WriteProfileInt("Preferences", "TreeCheckboxes", m_bTreeCheckboxes);
	AfxGetApp()->WriteProfileInt("Preferences", "SpecifyTreeFont", m_bSpecifyTreeFont);
	AfxGetApp()->WriteProfileInt("Preferences", "EnableHeaderSorting", m_bEnableHeaderSorting);
	AfxGetApp()->WriteProfileInt("Preferences", "SpecifyCheckboxImage", m_bSpecifyCheckboxImage);
	AfxGetApp()->WriteProfileString("Preferences", "CheckboxImagePath", m_sCheckboxImagePath);
	AfxGetApp()->WriteProfileInt("Preferences", "CheckboxMaskColor", m_crCheckboxMask);
	AfxGetApp()->WriteProfileInt("Preferences", "ColorTaskBackground", m_bColorTaskBackground);
	AfxGetApp()->WriteProfileInt("Preferences", "CommentsUseTreeFont", m_bCommentsUseTreeFont);
	AfxGetApp()->WriteProfileInt("Preferences", "DisplayDatesInISO", m_bUseISOForDates);
}

void CPreferencesUITasklistPage::OnSpecifytreefont() 
{
	UpdateData();

	GetDlgItem(IDC_TREEFONTLIST)->EnableWindow(m_bSpecifyTreeFont);
	GetDlgItem(IDC_TREEFONTSIZE)->EnableWindow(m_bSpecifyTreeFont);
	GetDlgItem(IDC_TREEFONTSIZELABEL)->EnableWindow(m_bSpecifyTreeFont);
	GetDlgItem(IDC_COMMENTSUSETREEFONT)->EnableWindow(m_bSpecifyTreeFont);

	if (m_bSpecifyTreeFont)
		m_cbFonts.SetSelectedFont(m_sTreeFont);
}

BOOL CPreferencesUITasklistPage::GetTreeFont(CString& sFaceName, int& nPointSize) const
{
	sFaceName = m_sTreeFont;
	nPointSize = m_nFontSize;

	return m_bSpecifyTreeFont;
}

void CPreferencesUITasklistPage::OnSetgridlinecolor() 
{
	m_crGridlines = m_btGridlineColor.GetColor();
}

void CPreferencesUITasklistPage::OnSpecifygridlinecolor() 
{
	UpdateData();	

	m_btGridlineColor.EnableWindow(m_bSpecifyGridColor);
}

void CPreferencesUITasklistPage::OnSetdonecolor() 
{
	m_crDone = m_btDoneColor.GetColor();
}

void CPreferencesUITasklistPage::OnSpecifydonecolor() 
{
	UpdateData();	

	m_btDoneColor.EnableWindow(m_bSpecifyDoneColor);
}

void CPreferencesUITasklistPage::OnCheckboxmaskcolor() 
{
	m_crCheckboxMask = m_btCheckboxMaskColor.GetColor();
}

void CPreferencesUITasklistPage::OnSpecifycheckimage() 
{
	UpdateData();	

	GetDlgItem(IDC_CHECKBOXIMAGEPATH)->EnableWindow(m_bSpecifyCheckboxImage);
	GetDlgItem(IDC_CHECKBOXMASKCOLOR)->EnableWindow(m_bSpecifyCheckboxImage);
}
