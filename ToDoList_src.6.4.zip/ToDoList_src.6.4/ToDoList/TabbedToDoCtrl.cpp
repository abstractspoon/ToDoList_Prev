// Fi M_BlISlteredToDoCtrl.cpp: implementation of the CTabbedToDoCtrl class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TabbedToDoCtrl.h"
#include "todoitem.h"
#include "resource.h"
#include "tdcstatic.h"
#include "tdcmsg.h"

#include "..\shared\holdredraw.h"
#include "..\shared\datehelper.h"
#include "..\shared\enstring.h"
#include "..\shared\preferences.h"
#include "..\shared\deferwndmove.h"
#include "..\shared\autoflag.h"
#include "..\shared\holdredraw.h"
#include "..\shared\osversion.h"
#include "..\shared\graphicsmisc.h"

#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#ifndef LVS_EX_DOUBLEBUFFER
#define LVS_EX_DOUBLEBUFFER 0x00010000
#endif

#ifndef LVS_EX_LABELTIP
#define LVS_EX_LABELTIP     0x00004000
#endif

const UINT SORTWIDTH = 10;
#define NOCOLOR ((COLORREF)-1)

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTabbedToDoCtrl::CTabbedToDoCtrl(CContentMgr& mgr, const CONTENTFORMAT& cfDefault) :
	CToDoCtrl(mgr, cfDefault), m_bTreeNeedResort(FALSE)
{
	// add extra controls
	for (int nCtrl = 0; nCtrl < NUM_FTDCCTRLS; nCtrl++)
	{
		const TDCCONTROL& ctrl = FTDCCONTROLS[nCtrl];

		AddRCControl(_T("CONTROL"), ctrl.szClass, CString((LPCTSTR)ctrl.nIDCaption), 
					ctrl.dwStyle, ctrl.dwExStyle,
					ctrl.nX, ctrl.nY, ctrl.nCx, ctrl.nCy, ctrl.nID);
	}

	// tab is on by default
	m_aStyles.SetAt(TDCS_SHOWTREELISTBAR, 1);
}

CTabbedToDoCtrl::~CTabbedToDoCtrl()
{

}

BEGIN_MESSAGE_MAP(CTabbedToDoCtrl, CToDoCtrl)
//{{AFX_MSG_MAP(CTabbedToDoCtrl)
	ON_WM_SETCURSOR()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_REGISTERED_MESSAGE(WM_TDCN_VIEWPRECHANGE, OnPreTabViewChange)
	ON_REGISTERED_MESSAGE(WM_TDCN_VIEWPOSTCHANGE, OnPostTabViewChange)
	ON_NOTIFY(NM_CUSTOMDRAW, 0, OnHeaderCustomDraw)
	ON_NOTIFY(NM_RCLICK, 0, OnRClickHeader)
	ON_NOTIFY(LVN_COLUMNCLICK, IDC_FTC_TASKLIST, OnClickHeader)
	ON_NOTIFY(NM_CLICK, IDC_FTC_TASKLIST, OnListClick)
	ON_NOTIFY(NM_DBLCLK, IDC_FTC_TASKLIST, OnListDblClick)
	ON_NOTIFY(NM_KEYDOWN, IDC_FTC_TASKLIST, OnListKeyDown)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_FTC_TASKLIST, OnListSelChanged)
	ON_WM_MEASUREITEM()
	ON_WM_DRAWITEM()
	ON_NOTIFY(LVN_GETINFOTIP, IDC_FTC_TASKLIST, OnListGetInfoTip)
	ON_NOTIFY(LVN_GETDISPINFO, IDC_FTC_TASKLIST, OnListGetDispInfo)
	ON_REGISTERED_MESSAGE(WM_TLDT_DROP, OnDropObject)
	ON_REGISTERED_MESSAGE(WM_PCANCELEDIT, OnEditCancel)
	ON_REGISTERED_MESSAGE(WM_NCG_WIDTHCHANGE, OnGutterWidthChange)
	ON_REGISTERED_MESSAGE(WM_NCG_RECALCCOLWIDTH, OnGutterRecalcColWidth)
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()

///////////////////////////////////////////////////////////////////////////

void CTabbedToDoCtrl::DoDataExchange(CDataExchange* pDX)
{
	CToDoCtrl::DoDataExchange(pDX);
	
	DDX_Control(pDX, IDC_FTC_TASKLIST, m_list);
	DDX_Control(pDX, IDC_FTC_TABCTRL, m_tabViews);
}

BOOL CTabbedToDoCtrl::OnInitDialog()
{
	CToDoCtrl::OnInitDialog();

	ListView_SetExtendedListViewStyleEx(m_list, 
										LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER, 
										LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER);
	m_dtList.Register(&m_list, this);

	// prevent the list overwriting the label edit
	m_list.ModifyStyle(0, WS_CLIPSIBLINGS);

	// and hook it
	ScHookWindow(m_list);

	// add all columns
	BuildListColumns();
		
	m_tabViews.AddView(&m_tree, FTCV_TASKTREE, IDS_TASKTREE, NULL);
	m_tabViews.AddView(&m_list, FTCV_TASKLIST, IDS_LISTVIEW, NewViewData());

	Resize();

	return FALSE;
}

BOOL CTabbedToDoCtrl::PreTranslateMessage(MSG* pMsg) 
{
	return CToDoCtrl::PreTranslateMessage(pMsg);
}

void CTabbedToDoCtrl::SetUITheme(const UITHEME& theme)
{
	CToDoCtrl::SetUITheme(theme);

	m_tabViews.SetBackgroundColor(theme.crAppBackLight);
}

BOOL CTabbedToDoCtrl::LoadTasks(const CTaskFile& file)
{
	BOOL bSuccess = CToDoCtrl::LoadTasks(file);

	// reload last view
	if (GetView() == FTCV_UNSET)
	{
		CString sKey = GetPreferencesKey(); // no subkey
		
		if (!sKey.IsEmpty()) // first time
		{
			CPreferences prefs;
			FTC_VIEW nView = (FTC_VIEW)prefs.GetProfileInt(sKey, _T("View"), FTCV_TASKTREE);
			
			if ((nView != FTCV_UNSET) && (nView != GetView()))
				SetView(nView);
			
			// clear the view so we don't keep restoring it
			prefs.WriteProfileInt(sKey, _T("View"), FTCV_UNSET);		
		}
	}
	return bSuccess;
}

void CTabbedToDoCtrl::OnDestroy() 
{
	if (GetView() != FTCV_UNSET)
	{
		CPreferences prefs;
		CString sKey = GetPreferencesKey(); // no subkey
		
		// save view
		if (!sKey.IsEmpty())
			prefs.WriteProfileInt(sKey, _T("View"), GetView());
	}
		
	CToDoCtrl::OnDestroy();
}

void CTabbedToDoCtrl::BuildListColumns(BOOL bResizeCols)
{
	while (m_list.DeleteColumn(0));
	
	int nCol = NUM_COLUMNS - 1; // we handle title column separately
	
	while (nCol--)
	{
		const TDCCOLUMN& col = COLUMNS[nCol];
		UINT nFmt = col.nAlignment == DT_RIGHT ? LVCFMT_RIGHT : LVCFMT_LEFT;
		
		m_list.InsertColumn(0, _T(""), nFmt, 10);
	}

	// title column
	if (HasStyle(TDCS_RIGHTSIDECOLUMNS))
		m_list.InsertColumn(0, _T(""), LVCFMT_LEFT, 10);
	else
		m_list.InsertColumn(NUM_COLUMNS - 1, _T(""), LVCFMT_LEFT, 10);

	if (bResizeCols)
		UpdateListColumnWidths();
}

void CTabbedToDoCtrl::OnRClickHeader(NMHDR* /*pNMHDR*/, LRESULT* pResult)
{
	// forward on to parent
	const MSG* pMsg = GetCurrentMessage();
	LPARAM lPos = MAKELPARAM(pMsg->pt.x, pMsg->pt.y);

	GetParent()->SendMessage(WM_CONTEXTMENU, (WPARAM)GetSafeHwnd(), lPos);

	*pResult = 0;
}

void CTabbedToDoCtrl::OnClickHeader(NMHDR* pNMHDR, LRESULT* pResult)
{
	ASSERT(InListView());

	NMLISTVIEW* pNMLV = (NMLISTVIEW*)pNMHDR;
	
	int nCol = pNMLV->iSubItem;
	TDCCOLUMN* pCol = GetColumn(nCol);

	if (pCol->nSortBy != TDC_UNSORTED)
	{
		VIEWDATA* pLVData = GetActiveViewData();

		const TDSORTCOLUMNS& sort = pLVData->sort;
		TDC_SORTBY nPrev = sort.nBy1;

		Sort(pCol->nSortBy);

		// notify parent
		if (sort.nBy1 != nPrev)
			GetParent()->SendMessage(WM_TDCN_SORT, GetDlgCtrlID(), MAKELPARAM((WORD)nPrev, (WORD)sort.nBy1));
	}

	*pResult = 0;
}

void CTabbedToDoCtrl::OnListGetDispInfo(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMLVDISPINFO* lplvdi = (NMLVDISPINFO*)pNMHDR;
	*pResult = 0;

	UINT nMask = lplvdi->item.mask;
	DWORD dwTaskID = (DWORD)lplvdi->item.lParam;

	if ((nMask & LVIF_TEXT) &&  m_dwEditingID != dwTaskID)
	{
		TODOITEM* pTDI = GetTask(dwTaskID);

		// it's possible that the task does not exist if it's just been 
		// deleted from the tree view
		if (!pTDI)
			return;

		// all else
		lplvdi->item.pszText = (LPTSTR)(LPCTSTR)pTDI->sTitle;
	}

	if (nMask & LVIF_IMAGE)
	{
		if (!HasStyle(TDCS_TREETASKICONS))
			lplvdi->item.iImage = -1;
		else
		{
			TODOITEM* pTDI = NULL;
			TODOSTRUCTURE* pTDS = NULL;
			m_data.GetTask(dwTaskID, pTDI, pTDS);

			BOOL bHasChildren = pTDS->HasSubTasks();
			int nImage = -1;
			
			if (!pTDI->sIcon.IsEmpty())
				nImage = m_ilTaskIcons.GetImageIndex(pTDI->sIcon);
			
			else if (HasStyle(TDCS_SHOWPARENTSASFOLDERS) && bHasChildren)
				nImage = 0;
			
			lplvdi->item.iImage = nImage;
		}
	}
}

TDC_COLUMN CTabbedToDoCtrl::GetColumnID(int nCol) const
{
	TDCCOLUMN* pCol = GetColumn(nCol);
	return pCol ? pCol->nColID : (TDC_COLUMN)-1;
}

TDCCOLUMN* CTabbedToDoCtrl::GetColumn(int nCol) const
{
	if (nCol < 0 || nCol >= NUM_COLUMNS)
		return NULL;

	// else
	if (HasStyle(TDCS_RIGHTSIDECOLUMNS))
	{
		if (nCol == 0)
			return &COLUMNS[NUM_COLUMNS - 1];
		else
			return &COLUMNS[nCol - 1];
	}
	
	// else
	return &COLUMNS[nCol];

}

int CTabbedToDoCtrl::GetColumnIndex(TDC_COLUMN nColID) const
{
	if (HasStyle(TDCS_RIGHTSIDECOLUMNS))
	{
		if (nColID == TDCC_CLIENT)
			return 0;

		// else it's 1 more than the COLUMNS index
		int nCol = NUM_COLUMNS - 1;

		while (nCol--)
		{
			if (COLUMNS[nCol].nColID == nColID)
				return nCol + 1;
		}
		
		ASSERT(0);
		return 0;
	}
	
	// else as COLUMNS
	int nCol = NUM_COLUMNS;
	
	while (nCol--)
	{
		if (COLUMNS[nCol].nColID == nColID)
			return nCol;
	}
	
	ASSERT(0);
	return 0;
}


void CTabbedToDoCtrl::SetVisibleColumns(const CTDCColumnArray& aColumns)
{
	CToDoCtrl::SetVisibleColumns(aColumns);

	UpdateListColumnWidths();
}

LRESULT CTabbedToDoCtrl::OnPreTabViewChange(WPARAM nOldView, LPARAM nNewView) 
{
	EndLabelEdit(FALSE);

	// notify parent
	GetParent()->SendMessage(WM_TDCN_VIEWPRECHANGE, nOldView, nNewView);

	// show the incoming selection and hide the outgoing in that order
	BOOL bFiltered = FALSE;

	// take a note of what task is currently singly selected
	// so that we can prevent unnecessary calls to UpdateControls
	DWORD dwSelTaskID = (GetSelectedCount() == 1) ? GetTaskID(GetSelectedItem()) : 0;
	
	switch (nNewView)
	{
	case FTCV_TASKTREE:
		// make sure something is selected
		if (GetSelectedCount() == 0)
		{
			HTREEITEM hti = m_tree.GetSelectedItem();

			if (!hti)
				hti = m_tree.GetChildItem(NULL);

			CToDoCtrl::SelectTask(GetTaskID(hti));
		}

		// update sort
		if (m_bTreeNeedResort)
		{
			m_bTreeNeedResort = FALSE;
			Resort();
		}

		m_tree.EnsureVisible(Selection().GetFirstItem());
		break;

	case FTCV_TASKLIST:
		// processed any unhandled comments
		HandleUnsavedComments(); 		
		
		// set the prompt now we know how tall the header is
		m_mgrPrompts.SetPrompt(m_list, IDS_TDC_FILTEREDTASKLISTPROMPT, LVM_GETITEMCOUNT, 0, m_list.GetHeaderHeight());

		// make sure row height is correct by forcing a WM_MEASUREITEM
		RemeasureList();

		// update column widths
		UpdateListColumnWidths(FALSE);

		// restore selection
		ResyncListSelection();

		m_list.EnsureVisible(GetFirstSelectedItem(), FALSE);
		break;
	}

	// update controls only if the selection has changed and 
	// we didn't refilter (RefreshFilter will already have called UpdateControls)
	BOOL bSelChange = !(GetSelectedCount() == 1 && GetTaskID(GetSelectedItem()) == dwSelTaskID);
	
	if (bSelChange && !bFiltered)
		UpdateControls();

	return 0L;
}

LRESULT CTabbedToDoCtrl::OnPostTabViewChange(WPARAM nOldView, LPARAM nNewView)
{
	switch (nNewView)
	{
	case FTCV_TASKTREE:
		break;

	case FTCV_TASKLIST:
		// update sort
		VIEWDATA* pLVData = GetViewData(FTCV_TASKLIST);

		if (pLVData->bNeedResort)
		{
			pLVData->bNeedResort = FALSE;
			Resort();
		}

		// update column widths
		UpdateListColumnWidths(FALSE);
		break;
	}

	// notify parent
	GetParent()->SendMessage(WM_TDCN_VIEWPOSTCHANGE, nOldView, nNewView);

	return 0L;
}

void CTabbedToDoCtrl::GetCompletedTasks(const TODOSTRUCTURE* pTDS, CTaskFile& tasks, HTASKITEM hTaskParent, BOOL bSelectedOnly) const
{
	const TODOITEM* pTDI = NULL;

	if (!pTDS->IsRoot())
	{
		DWORD dwTaskID = pTDS->GetTaskID();
		pTDI = GetTask(dwTaskID);
		ASSERT(pTDI);

		// we add the task if it is completed (and optionally selected) or it has children
		if (pTDI->IsDone() || pTDS->HasSubTasks())
		{
			HTASKITEM hTask = tasks.NewTask(_T(""), hTaskParent, dwTaskID);
			ASSERT(hTask);

			// copy attributes
			TDCGETTASKS allTasks;
			SetTaskAttributes(pTDI, pTDS, tasks, hTask, allTasks, FALSE);

			// this task is now the new parent
			hTaskParent = hTask;
		}
	}

	// children
	if (pTDS->HasSubTasks())
	{
		for (int nSubtask = 0; nSubtask < pTDS->GetSubTaskCount(); nSubtask++)
		{
			const TODOSTRUCTURE* pTDSChild = pTDS->GetSubTask(nSubtask);
			GetCompletedTasks(pTDSChild, tasks, hTaskParent, bSelectedOnly);
		}

		// if no subtasks were added and the parent is not completed 
		// (and optionally selected) then we remove it
		if (hTaskParent && tasks.GetFirstTask(hTaskParent) == NULL)
		{
			ASSERT(pTDI);

			if (!pTDI->IsDone())
				tasks.DeleteTask(hTaskParent);
		}
	}
}

VIEWDATA* CTabbedToDoCtrl::GetViewData(FTC_VIEW nView) const
{
	return (VIEWDATA*)m_tabViews.GetViewData(nView);
}

VIEWDATA* CTabbedToDoCtrl::GetActiveViewData() const
{
	return (VIEWDATA*)m_tabViews.GetViewData(GetView());
}

void CTabbedToDoCtrl::SetView(FTC_VIEW nView) 
{
	// take a note of what task is currently singly selected
	// so that we can prevent unnecessary calls to UpdateControls
	DWORD dwSelTaskID = (GetSelectedCount() == 1) ? GetTaskID(GetSelectedItem()) : 0;
	
	if (!m_tabViews.SetActiveView(nView, TRUE))
		return;

	// update controls only if the selection has changed and 
	BOOL bSelChange = !(GetSelectedCount() == 1 && GetTaskID(GetSelectedItem()) == dwSelTaskID);
	
	if (bSelChange)
		UpdateControls();
}

void CTabbedToDoCtrl::RemeasureList()
{
	CRect rList;
	m_list.GetWindowRect(rList);
	ScreenToClient(rList);

	WINDOWPOS wpos = { m_list, NULL, rList.left, rList.top, rList.Width(), rList.Height(), SWP_NOZORDER };
	m_list.SendMessage(WM_WINDOWPOSCHANGED, 0, (LPARAM)&wpos);

	// set tree header height to match listview
	int nHeight = m_list.GetHeaderHeight();

	if (nHeight != -1)
		m_tree.SetHeaderHeight(nHeight);
}

LRESULT CTabbedToDoCtrl::OnGutterRecalcColWidth(WPARAM wParam, LPARAM lParam)
{
	NCGRECALCCOLUMN* pNCRC = (NCGRECALCCOLUMN*)lParam;
	
	// special case: PATH column
	if (pNCRC->nColID != TDCC_PATH)
		return CToDoCtrl::OnGutterRecalcColWidth(wParam, lParam);

	// else tree does not show the path column
	pNCRC->nWidth = 0;
	return TRUE;
}

void CTabbedToDoCtrl::UpdateListColumnWidths(BOOL bCheckListVisibility)
{
	if (bCheckListVisibility && InTreeView())
		return;

	int nCol = NUM_COLUMNS;
	int nTotalWidth = 0;
	BOOL bFirstWidth = TRUE;

	CClientDC dc(&m_list);
	CFont* pOldFont = GraphicsMisc::PrepareDCFont(&dc, &m_list);
	float fAve = GraphicsMisc::GetAverageCharWidth(&dc);

	CHoldRedraw hr(m_list, NCR_PAINT | NCR_UPDATE);
	
	for (nCol = 0; nCol < NUM_COLUMNS; nCol++)
	{
		const TDCCOLUMN* pCol = GetColumn(nCol);
		ASSERT(pCol);

		// get column width from tree except for some special cases
		// the reason we can't just take the tree's widths is that the
		// list always shows _all_ items whereas the tree hides some
		int nWidth = 0, nTreeColWidth = m_tree.GetColumnWidth(pCol->nColID);
		CString sLongest;

		if (IsColumnShowing(pCol->nColID))
		{
			switch (pCol->nColID)
			{
			case TDCC_CLIENT:
				continue; // we'll deal with this at the end

			case TDCC_EXTERNALID:
				sLongest = m_find.GetLongestExternalID(FALSE);
				break;

			case TDCC_POSITION:
				sLongest = m_find.GetLongestPosition(FALSE);
				break;

			case TDCC_CATEGORY:
				{
					// determine the longest visible string
					sLongest = m_find.GetLongestCategory(FALSE);

					// include whatever's in the category edit field
					CString sEdit;
					m_cbCategory.GetWindowText(sEdit);

					if (sEdit.GetLength() > sLongest.GetLength())
						sLongest = sEdit;
				}
				break;

			case TDCC_TAGS:
				{
					// determine the longest visible string
					sLongest = m_find.GetLongestTag(FALSE);

					// include whatever's in the category edit field
					CString sEdit;
					m_cbTags.GetWindowText(sEdit);

					if (sEdit.GetLength() > sLongest.GetLength())
						sLongest = sEdit;
				}
				break;

			case TDCC_ALLOCTO:
				{
					// determine the longest visible string
					sLongest = m_find.GetLongestAllocTo(FALSE);

					// include whatever's in the category edit field
					CString sEdit;
					m_cbAllocTo.GetWindowText(sEdit);

					if (sEdit.GetLength() > sLongest.GetLength())
						sLongest = sEdit;
				}
				break;

			case TDCC_RECURRENCE:
				sLongest = m_find.GetLongestRecurrence(FALSE);
				break;

			case TDCC_TIMEEST:
			case TDCC_TIMESPENT:
				if (HasStyle(TDCS_DISPLAYHMSTIMEFORMAT))
					nWidth = m_tree.GetColumnWidth(pCol->nColID);
				else
				{
					BOOL bTimeEst = (pCol->nColID == TDCC_TIMEEST);
					sLongest = m_find.GetLongestTime(s_tdDefault.nTimeEstUnits, bTimeEst);
				}
				break;

			case TDCC_PATH:
				nTreeColWidth = 150;
				break;

				// all else
			default:
				break;
			}

			if (!sLongest.IsEmpty())
			{
				int nAveExtent = (int)(sLongest.GetLength() * fAve);
				int nTextExtent = dc.GetTextExtent(sLongest).cx;

				// mimic width of tree columns
				nWidth = max(nAveExtent, nTextExtent) + 2 * NCG_COLPADDING;

				// can't be narrower than tree column 
				nWidth = max(nWidth, nTreeColWidth);
			}
			else
				nWidth = nTreeColWidth;

			// maximum width
			if (m_nMaxColWidth != -1 && nWidth > m_nMaxColWidth)
				nWidth = m_nMaxColWidth;

			// DON'T KNOW WHAT THIS IS FOR???
			if (nWidth && bFirstWidth)
			{
				bFirstWidth = FALSE;
				nWidth += 1;
			}

			// sort indicator 
			BOOL bTreeColWidened = !(m_bMultiSort || m_sort.nBy1 == TDC_UNSORTED) && m_sort.nBy1 == pCol->nSortBy;
			
			VIEWDATA* pListData = GetViewData(FTCV_TASKLIST);
			BOOL bListColWidened = !(pListData->bMultiSort || pListData->sort.nBy1 == TDC_UNSORTED) && pListData->sort.nBy1 == pCol->nSortBy;
			
			if (!bTreeColWidened && bListColWidened)
				nWidth += SORTWIDTH;
			
			else if (bTreeColWidened && !bListColWidened)
				nWidth -= SORTWIDTH;
		}

		m_list.SetColumnWidth(nCol, nWidth);

		nTotalWidth += nWidth;
	}

	// client column is what's left
	CRect rList;
	m_list.GetClientRect(rList);

	int nColWidth = max(300, rList.Width() - nTotalWidth);
	m_list.SetColumnWidth(GetColumnIndex(TDCC_CLIENT), nColWidth);

	// cleanup
	dc.SelectObject(pOldFont);
}

void CTabbedToDoCtrl::ReposTaskTree(CDeferWndMove* pDWM, const CRect& rPos)
{
	CRect rView;
	m_tabViews.Resize(rPos, pDWM, rView);

	CToDoCtrl::ReposTaskTree(pDWM, rView);
}

void CTabbedToDoCtrl::UpdateTasklistVisibility()
{
	BOOL bTasksVis = (m_nMaxState != TDCMS_MAXCOMMENTS);

	if (InListView())
		m_list.ShowWindow(bTasksVis ? SW_SHOW : SW_HIDE);
	else
		CToDoCtrl::UpdateTasklistVisibility();

	// handle tab control
	m_tabViews.ShowWindow(bTasksVis && HasStyle(TDCS_SHOWTREELISTBAR) ? SW_SHOW : SW_HIDE);
}

BOOL CTabbedToDoCtrl::OnEraseBkgnd(CDC* pDC)
{
	// clip out tab ctrl
	if (m_tabViews.GetSafeHwnd())
		ExcludeChild(this, pDC, &m_tabViews);

	return CToDoCtrl::OnEraseBkgnd(pDC);
}

void CTabbedToDoCtrl::Resize(int cx, int cy)
{
	CToDoCtrl::Resize(cx, cy);

	if (m_list.GetSafeHwnd())
		UpdateListColumnWidths();
}

BOOL CTabbedToDoCtrl::GetSelectionBoundingRect(CRect& rSelection) const
{
	if (InListView())
	{
		rSelection.SetRectEmpty();

		POSITION pos = m_list.GetFirstSelectedItemPosition();

		// initialize to first item
		if (pos)
			VERIFY(GetItemTitleRect(m_list.GetNextSelectedItem(pos), TDCTR_LABEL, rSelection));

		// rest of selection
		while (pos)
		{
			CRect rItem;
			VERIFY(GetItemTitleRect(m_list.GetNextSelectedItem(pos), TDCTR_LABEL, rItem));
				
			rSelection |= rItem;
		}

		m_list.ClientToScreen(rSelection);
		ScreenToClient(rSelection);
	}
	else
		CToDoCtrl::GetSelectionBoundingRect(rSelection);

	return (!rSelection.IsRectNull());
}

void CTabbedToDoCtrl::SelectAll()
{
	if (InListView())
	{
		int nNumItems = m_list.GetItemCount();
		BOOL bAllTasks = (CToDoCtrl::GetTaskCount() == (UINT)nNumItems);
		CDWordArray aTaskIDs;

		for (int nItem = 0; nItem < nNumItems; nItem++)
		{
			// select item
			m_list.SetItemState(nItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);

			// save ID only not showing all tasks
			if (!bAllTasks)
				aTaskIDs.Add(m_list.GetItemData(nItem));
		}

		// select items in tree
		if (bAllTasks)
			CToDoCtrl::SelectAll();
		else
			MultiSelectItems(aTaskIDs, TSHS_SELECT, FALSE);
	}
	else
		CToDoCtrl::SelectAll();
}

void CTabbedToDoCtrl::DeselectAll()
{
	CToDoCtrl::DeselectAll();
	ClearListSelection();
}

int CTabbedToDoCtrl::GetTasks(CTaskFile& tasks, const TDCGETTASKS& filter) const
{
	if (InListView())
	{
		// we return exactly what's selected in the list and in the same order
		// so we make sure the filter includes TDCGT_NOTSUBTASKS
		TDCGETTASKS tdcf(filter);
		tdcf.dwFlags |= TDCGTF_NOTSUBTASKS;

		for (int nItem = 0; nItem < m_list.GetItemCount(); nItem++)
		{
			HTREEITEM hti = GetTreeItem(nItem);
			AddTreeItemToTaskFile(hti, tasks, NULL, tdcf);
		}

		if (filter.dwFlags & TDCGTF_FILENAME)
			tasks.SetFileName(m_sLastSavePath);

		return tasks.GetTaskCount();
	}
	else
		return CToDoCtrl::GetTasks(tasks, filter);
}

int CTabbedToDoCtrl::GetSelectedTasks(CTaskFile& tasks, const TDCGETTASKS& filter) const
{
	if (InListView())
	{
		// we return exactly what's selected in the list and in the same order
		// so we make sure the filter includes TDCGT_NOTSUBTASKS
		TDCGETTASKS tdcf(filter);
		tdcf.dwFlags |= TDCGTF_NOTSUBTASKS;
	
		POSITION pos = m_list.GetFirstSelectedItemPosition();

		while (pos)
		{
			int nItem = m_list.GetNextSelectedItem(pos);
			HTREEITEM hti = GetTreeItem(nItem);

			AddTreeItemToTaskFile(hti, tasks, NULL, tdcf);
		}

		return tasks.GetTaskCount();
	}
	else
		return CToDoCtrl::GetSelectedTasks(tasks, filter);
}

void CTabbedToDoCtrl::OnHeaderCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMCUSTOMDRAW* pNMCD = (NMCUSTOMDRAW*)pNMHDR;
	
	if (pNMCD->dwDrawStage == CDDS_PREPAINT)
		*pResult |= CDRF_NOTIFYITEMDRAW | CDRF_NOTIFYPOSTPAINT;	
	
	else if (pNMCD->dwDrawStage == CDDS_ITEMPREPAINT)
		*pResult |= CDRF_NOTIFYPOSTPAINT;	

	else if (pNMCD->dwDrawStage == CDDS_ITEMPOSTPAINT)
	{
		CDC* pDC = CDC::FromHandle(pNMCD->hdc);
		CFont* pOldFont = (CFont*)pDC->SelectObject(CWnd::GetFont());

		DrawColumnHeaderText(pDC, pNMCD->dwItemSpec, pNMCD->rc, pNMCD->uItemState);

		pDC->SelectObject(pOldFont);
	}
}

void CTabbedToDoCtrl::OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{
	if (nIDCtl == IDC_FTC_TASKLIST)
		lpMeasureItemStruct->itemHeight = m_tree.TCH().GetItemHeight();
	else
		CToDoCtrl::OnMeasureItem(nIDCtl, lpMeasureItemStruct);
}

void CTabbedToDoCtrl::RemoveDeletedListItems()
{
	int nItem = m_list.GetItemCount();

	while (nItem--)
	{
		DWORD dwTaskID = m_list.GetItemData(nItem);

		if (!GetTask(dwTaskID))
			m_list.DeleteItem(nItem);
	}
}

CTabbedToDoCtrl::TDI_STATE CTabbedToDoCtrl::GetItemState(int nItem)
{
	if (m_list.GetItemState(nItem, LVIS_DROPHILITED) & LVIS_DROPHILITED)
		return TDIS_DROPHILITED;
	
	else if (m_list.GetItemState(nItem, LVIS_SELECTED) & LVIS_SELECTED)
		return (TasksHaveFocus() ? TDIS_SELECTED : TDIS_SELECTEDNOTFOCUSED);
	
	return TDIS_NONE;
}

void CTabbedToDoCtrl::GetItemColors(int nItem, NCGITEMCOLORS& colors)
{
	TDI_STATE nState = GetItemState(nItem);
	DWORD dwID = GetTaskID(nItem);

	colors.crText = GetSysColor(COLOR_WINDOWTEXT);
	colors.crBack = GetSysColor(COLOR_WINDOW);

	if (nItem % 2)
	{
		COLORREF crAlt = m_tree.GetAlternateLineColor();

		if (crAlt != NOCOLOR)
			colors.crBack = crAlt;
	}

	CToDoCtrl::GetItemColors(dwID, &colors, nState);
}

void CTabbedToDoCtrl::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	if (nIDCtl == IDC_FTC_TASKLIST)
	{
		// don't bother drawing if we're just switching to the tree view
		if (InTreeView())
			return;
			
		int nItem = lpDrawItemStruct->itemID;
		DWORD dwTaskID = lpDrawItemStruct->itemData;

		TODOITEM* pTDI = NULL;
		TODOSTRUCTURE* pTDS = NULL;

		if (!m_data.GetTask(dwTaskID, pTDI, pTDS))
			return;

		CRect rItem, rTitleBounds;

		m_list.GetSubItemRect(nItem, 0, LVIR_BOUNDS, rItem);
		GetItemTitleRect(nItem, TDCTR_BOUNDS, rTitleBounds);

		CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
		int nSaveDC = pDC->SaveDC(); // so that DrawFocusRect works

		pDC->SetBkMode(TRANSPARENT);

		COLORREF crGrid = m_tree.GetGridlineColor();
		NCGITEMCOLORS colors = { 0, 0, 0, FALSE, FALSE };
		
		GetItemColors(nItem, colors);
		TDI_STATE nState = GetItemState(nItem);

		// fill back color
		if (HasStyle(TDCS_FULLROWSELECTION) || !colors.bBackSet)
		{
			DrawItemBackColor(pDC, rItem, colors.crBack);
		}
		else
		{
			// calculate the rect containing the rest of the columns
			CRect rCols(rItem);

			if (HasStyle(TDCS_RIGHTSIDECOLUMNS))
			{
				rCols.left = rTitleBounds.right;
			}
			else
				rCols.right = rTitleBounds.left;

			// fill the background colour of the rest of the columns
			rCols.right--;

			DrawItemBackColor(pDC, rCols, colors.crBack);

			// check to see whether we should fill the label cell background
			// with the alternate line colour
			if (nItem % 2) // odd row
			{
				COLORREF crAltLine = m_tree.GetAlternateLineColor();
					
				if (crAltLine != NOCOLOR)
				{
					rTitleBounds.OffsetRect(-1, 0);
					pDC->FillSolidRect(rTitleBounds, crAltLine);
					rTitleBounds.OffsetRect(1, 0);
				}
			}
		}

		// and set the text color
		if (colors.bTextSet)
			pDC->SetTextColor(colors.crText);
		else
			pDC->SetTextColor(GetSysColor(COLOR_WINDOWTEXT));
		
		// render column text
		// use CToDoCtrl::OnGutterDrawItem to do the hard work
		NCGDRAWITEM ncgDI;
		CRect rFocus; // will be set up during TDCC_CLIENT handling
		
		for (int nCol = 0; nCol < NUM_COLUMNS; nCol++)
		{
			// client column/task title is special case
			TDCCOLUMN* pCol = GetColumn(nCol);

			if (pCol->nColID == TDCC_CLIENT)
			{
				BOOL bTopLevel = pTDS->ParentIsRoot();
				BOOL bFolder = pTDS->HasSubTasks() && HasStyle(TDCS_SHOWPARENTSASFOLDERS);
				BOOL bDoneAndStrikeThru = pTDI->IsDone() && HasStyle(TDCS_STRIKETHOUGHDONETASKS);

				// icon
				CRect rSubItem;
				
				if (GetItemTitleRect(nItem, TDCTR_ICON, rSubItem))
				{
					if (!pTDI->sIcon.IsEmpty())
					{
						int nImage = m_ilTaskIcons.GetImageIndex(pTDI->sIcon);
						m_ilTaskIcons.Draw(pDC, nImage, rSubItem.TopLeft(), ILD_TRANSPARENT);
					}
					else if (bFolder)
						m_ilTaskIcons.Draw(pDC, 0, rSubItem.TopLeft(), ILD_TRANSPARENT);
				}

				// checkbox
				if (GetItemTitleRect(nItem, TDCTR_CHECKBOX, rSubItem))
				{
					int nImage = pTDI->IsDone() ? 2 : 1;
					CImageList::FromHandle(m_hilDone)->Draw(pDC, nImage, rSubItem.TopLeft(), ILD_TRANSPARENT);
				}

				// set fonts before calculating title rect
				HFONT hFontOld = NULL;

				if (bDoneAndStrikeThru)
					hFontOld = (HFONT)::SelectObject(lpDrawItemStruct->hDC, m_fontDone);

				else if (bTopLevel) 
					hFontOld = (HFONT)::SelectObject(lpDrawItemStruct->hDC, m_fontBold);

				// Task title 
				GetItemTitleRect(nItem, TDCTR_LABEL, rSubItem, pDC, pTDI->sTitle);
				rSubItem.OffsetRect(-1, 0);

				// back colour
				if (!HasStyle(TDCS_FULLROWSELECTION) && colors.bBackSet)
				{
					DrawItemBackColor(pDC, rSubItem, colors.crBack);
				}

				// text
				DrawGutterItemText(pDC, pTDI->sTitle, rSubItem, LVCFMT_LEFT);
				rFocus = rSubItem; // save for focus rect drawing

				// vertical divider
				if (crGrid != NOCOLOR)
					pDC->FillSolidRect(rTitleBounds.right - 1, rTitleBounds.top, 1, rTitleBounds.Height(), crGrid);

				// render comment text if not editing this task label
				if (m_dwEditingID != dwTaskID)
				{
					// deselect bold font if set
					if (bTopLevel && !bDoneAndStrikeThru)
					{
						::SelectObject(lpDrawItemStruct->hDC, hFontOld);
						hFontOld = NULL;
					}	

					rTitleBounds.top++;
					rTitleBounds.left = rSubItem.right + 4;
					DrawCommentsText(pDC, pTDI, pTDS, rTitleBounds, nState);
				}

				if (hFontOld)
					::SelectObject(lpDrawItemStruct->hDC, hFontOld);
			}
			else
			{
				// get col rect
				CRect rSubItem;
				m_list.GetSubItemRect(nItem, nCol, LVIR_LABEL, rSubItem);
				rSubItem.OffsetRect(-1, 0);

				ncgDI.pDC = pDC;
				ncgDI.dwItem = NULL;
				ncgDI.dwParentItem = NULL;
				ncgDI.nLevel = 0;
				ncgDI.nItemPos = 0;
				ncgDI.rWindow = &rSubItem;
				ncgDI.rItem = &rSubItem;
				ncgDI.nColID = pCol->nColID;
				ncgDI.nTextAlign = pCol->nAlignment;
				
				DrawItem(pTDI, pTDS, &ncgDI, nState);
			}
		}

		// base gridline
		if (crGrid != NOCOLOR)
			pDC->FillSolidRect(rItem.left, rItem.bottom - 1, rItem.Width() - 1, 1, crGrid);

		pDC->RestoreDC(nSaveDC); // so that DrawFocusRect works
		
		// focus rect
		if ((lpDrawItemStruct->itemState & ODS_FOCUS) && (nState == TDIS_SELECTED))
		{
			pDC->DrawFocusRect(rFocus);
		}

	}
	else
		CToDoCtrl::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

COLORREF CTabbedToDoCtrl::GetItemLineColor(HTREEITEM hti)
{
	if (InListView())
	{
		COLORREF crAltLines = m_tree.GetAlternateLineColor();

		if (crAltLines != NOCOLOR)
		{
			int nItem = FindTask(GetTaskID(hti));

			if (nItem != -1 && (nItem % 2))
				return crAltLines;
		}
			
		// else
		return GetSysColor(COLOR_WINDOW);
	}

	// else
	return CToDoCtrl::GetItemLineColor(hti);
}

void CTabbedToDoCtrl::DrawColumnHeaderText(CDC* pDC, int nCol, const CRect& rCol, UINT nState)
{
	if (nCol >= NUM_COLUMNS)
		return;

	// filter out zero width columns
	if (rCol.Width() == 0)
		return;

	const TDCCOLUMN* pCol = GetColumn(nCol);
	ASSERT(pCol);

	CEnString sColumn(pCol->nIDName);

	// special cases
	if (sColumn.IsEmpty())
		sColumn = CString(static_cast<TCHAR>(pCol->nIDName));

	else if (pCol->nColID == TDCC_CLIENT && HasStyle(TDCS_SHOWPATHINHEADER) && m_list.GetSelectedCount() == 1)
	{
		int nColWidthInChars = (int)(rCol.Width() / m_fAveHeaderCharWidth);
		CString sPath = m_data.GetTaskPath(GetSelectedTaskID(), nColWidthInChars);
			
		if (!sPath.IsEmpty())
			sColumn.Format(_T("%s [%s]"), CEnString(IDS_TDC_COLUMN_TASK), sPath);
	}
	else if (sColumn == _T("%%"))
		sColumn = _T("%");

	const UINT DEFFLAGS = DT_END_ELLIPSIS | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX;
	pDC->SetBkMode(TRANSPARENT);
	
	CRect rText(rCol);
	rText.bottom -= 2;
	
	switch (pCol->nAlignment)
	{
	case DT_LEFT:
		rText.left += NCG_COLPADDING - 1;
		break;
		
	case DT_RIGHT:
		rText.right -= NCG_COLPADDING;
		break;

	case DT_CENTER:
		rText.right--;
	}
	
	BOOL bDown = (nState & CDIS_SELECTED);

	VIEWDATA* pLVData = GetViewData(FTCV_TASKLIST);
	BOOL bSorted = (IsSortable() && pLVData->sort.nBy1 == pCol->nSortBy && !pLVData->bMultiSort);
	
	if (bDown)
		rText.OffsetRect(1, 1);
	
	if (bSorted)
		rText.right -= (SORTWIDTH + 2);

	if (pCol->szFont && *pCol->szFont)
	{
		CFont* pOldFont = NULL;

		if (CString(pCol->szFont).CompareNoCase(_T("WingDings")) == 0)
			pOldFont = pDC->SelectObject(&GraphicsMisc::WingDings());
		
		else if (CString(pCol->szFont).CompareNoCase(_T("Marlett")) == 0)
			pOldFont = pDC->SelectObject(&GraphicsMisc::Marlett());
		
		pDC->DrawText(sColumn, rText, DEFFLAGS | pCol->nAlignment);
		
		if (pOldFont)
			pDC->SelectObject(pOldFont);
	}
	else
		pDC->DrawText(sColumn, rText, DEFFLAGS | pCol->nAlignment);

	// draw sort direction if required
	if (bSorted)
	{
		// adjust for sort arrow
		if (pCol->nAlignment & DT_CENTER)
			rText.left = ((rText.left + rText.right + pDC->GetTextExtent(sColumn).cx) / 2) + 2;
			
		else if (pCol->nAlignment & DT_RIGHT)
			rText.left = rText.right + 2;
		else
			rText.left = rText.left + pDC->GetTextExtent(sColumn).cx + 2;

		BOOL bAscending = pLVData->sort.bAscending1 ? 1 : -1;
		int nMidY = (bDown ? 1 : 0) + (rText.top + rText.bottom) / 2;
		POINT ptArrow[3] = { 
							{ 0, 0 }, 
							{ 3, -bAscending * 3 }, 
							{ 7, bAscending } };
		
		// translate the arrow to the appropriate location
		int nPoint = 3;
		
		while (nPoint--)
		{
			ptArrow[nPoint].x += rText.left + 3 + (bDown ? 1 : 0);
			ptArrow[nPoint].y += nMidY;
		}
		pDC->Polyline(ptArrow, 3);
	}
}


BOOL CTabbedToDoCtrl::SetStyle(TDC_STYLE nStyle, BOOL bOn, BOOL bWantUpdate)
{
	// base class processing
	if (CToDoCtrl::SetStyle(nStyle, bOn, bWantUpdate))
	{
		// post-precessing
		switch (nStyle)
		{
		case TDCS_RIGHTSIDECOLUMNS:
			BuildListColumns();
			break;

		case TDCS_SHOWINFOTIPS:
			ListView_SetExtendedListViewStyleEx(m_list, LVS_EX_INFOTIP, bOn ? LVS_EX_INFOTIP : 0);
			break;

		case TDCS_TREETASKICONS:
			if (bOn && !IsColumnShowing(TDCC_ICON)) // this overrides
				ListView_SetImageList(m_list, m_ilTaskIcons, LVSIL_NORMAL);
			else
				ListView_SetImageList(m_list, NULL, LVSIL_NORMAL);
			break;

		case TDCS_SHOWTREELISTBAR:
			m_tabViews.ShowTabControl(bOn);

			if (bWantUpdate)
				Resize();
			break;
		}

		return TRUE;
	}

	return FALSE;
}

CString CTabbedToDoCtrl::GetControlDescription(CWnd* pCtrl) const
{
	if (pCtrl && *pCtrl == m_list)
		return CEnString(IDS_LISTVIEW);

	// else
	return CToDoCtrl::GetControlDescription(pCtrl);
}

BOOL CTabbedToDoCtrl::DeleteSelectedTask(BOOL bWarnUser, BOOL bResetSel)
{
	BOOL bDel = CToDoCtrl::DeleteSelectedTask(bWarnUser, bResetSel);

	if (bDel && InListView())
	{
		// work out what to select
		DWORD dwSelID = GetSelectedTaskID();
		int nSel = FindTask(dwSelID);

		if (nSel == -1 && m_list.GetItemCount())
			nSel = 0;

		if (nSel != -1)
			SelectTask(m_list.GetItemData(nSel));
	}

	return bDel;
}

BOOL CTabbedToDoCtrl::SelectedTasksHaveChildren() const
{
	return CToDoCtrl::SelectedTasksHaveChildren();
}

HTREEITEM CTabbedToDoCtrl::NewTask(LPCTSTR szText, TDC_INSERTWHERE nWhere, BOOL bEditText)
{
	BOOL bWantEditText = bEditText;

	if (InListView())
		bEditText = FALSE;

	HTREEITEM htiNew = CToDoCtrl::NewTask(szText, nWhere, bEditText);

	if (htiNew)
	{
		if (InListView())
		{
			DWORD dwTaskID = GetTaskID(htiNew);
			ASSERT(dwTaskID == m_dwNextUniqueID - 1);

			// make the new task appear
			RebuildList(NULL); 

			// select that task
			SelectTask(dwTaskID);
			
			if (bWantEditText)
			{
				m_dwLastAddedID = dwTaskID;

				// scroll the list item into view
				EditSelectedTask(TRUE);
			}
		}
	}

	return htiNew;
}

void CTabbedToDoCtrl::RebuildList(const void* pContext)
{
	if (!m_data.GetTaskCount())
	{
		m_list.DeleteAllItems(); 
		return;
	}

	// note: the call to CListCtrl::Scroll at the bottom fails if the 
	// list has redraw disabled so it must happen outside the scope of hr2
	CSize sizePos(0, 0);
	{
		CHoldRedraw hr(GetSafeHwnd());
		CHoldRedraw hr2(m_list);
		CWaitCursor cursor;

		// cache current selection
		CDWordArray aTaskIDs;
		DWORD dwFocusedTaskID;
		GetSelectedTaskIDs(aTaskIDs, dwFocusedTaskID, FALSE);

		// and scrolled pos
		if (m_list.GetItemCount())
		{
			CRect rItem;
			m_list.GetItemRect(0, rItem, LVIR_BOUNDS);

			sizePos.cy = -rItem.top + rItem.Height();
		}

		// remove all existing items
		m_list.DeleteAllItems();
		
		// rebuild the list from the tree
		AddTreeItemToList(NULL, pContext);

		// redo last sort
		if (InListView() && IsSortable())
		{
			VIEWDATA* pLVData = GetViewData(FTCV_TASKLIST);
			pLVData->bNeedResort = FALSE;

			Resort();
		}

		// restore selection
		SetSelectedListTasks(aTaskIDs, dwFocusedTaskID);

		// don't update controls is only one item is selected and it did not
		// change as a result of the filter
		BOOL bSelChange = !(GetSelectedCount() == 1 && aTaskIDs.GetSize() == 1 &&
							GetTaskID(GetSelectedItem()) == aTaskIDs[0]);

		if (bSelChange)
			UpdateControls();
	}
	
	// restore pos
	if (sizePos.cy != 0)
		m_list.Scroll(sizePos);

	UpdateListColumnWidths();
}

void CTabbedToDoCtrl::AddTreeItemToList(HTREEITEM hti, const void* pContext)
{
	if (hti)
	{
		int nItem = m_list.InsertItem(m_list.GetItemCount(), LPSTR_TEXTCALLBACK, I_IMAGECALLBACK);
		m_list.SetItemData(nItem, GetTaskID(hti));
	}

	// children
	HTREEITEM htiChild = m_tree.GetChildItem(hti);

	while (htiChild)
	{
		AddTreeItemToList(htiChild, pContext);
		htiChild = m_tree.GetNextItem(htiChild, TVGN_NEXT);
	}
}

void CTabbedToDoCtrl::SetModified(BOOL bMod, TDC_ATTRIBUTE nAttrib)
{
	if (bMod)
	{
		if (nAttrib == TDCA_DELETE || nAttrib == TDCA_ARCHIVE)
			RemoveDeletedListItems();

		else if (InListView())
			m_list.Invalidate(FALSE);
	}
	
	CToDoCtrl::SetModified(bMod, nAttrib);
}

BOOL CTabbedToDoCtrl::ModNeedsResort(TDC_ATTRIBUTE nModType) const
{
	// need to check all three sort attributes if multi-sorting
	VIEWDATA* pLVData = GetViewData(FTCV_TASKLIST);
	BOOL bListNeedsResort = CToDoCtrl::ModNeedsResort(nModType, pLVData->sort.nBy1);

	if (!bListNeedsResort && pLVData->bMultiSort)
	{
		bListNeedsResort |= CToDoCtrl::ModNeedsResort(nModType, pLVData->sort.nBy2);
		
		if (!bListNeedsResort)
			bListNeedsResort |= CToDoCtrl::ModNeedsResort(nModType, pLVData->sort.nBy3);
	}

	BOOL bTreeNeedsResort = CToDoCtrl::ModNeedsResort(nModType);

	if (InListView())
	{
		m_bTreeNeedResort |= bTreeNeedsResort;
		return bListNeedsResort;
	}
	else // tree view
	{
		pLVData->bNeedResort |= bListNeedsResort;
		return bTreeNeedsResort;
	}
}

void CTabbedToDoCtrl::ResortSelectedTaskParents() 
{ 
	// do a full sort
	Resort();
}

TDC_SORTBY CTabbedToDoCtrl::GetSortBy() const 
{ 
	VIEWDATA* pVData = GetActiveViewData();

	return pVData ? pVData->sort.nBy1 : m_sort.nBy1; 
}

void CTabbedToDoCtrl::GetSortBy(TDSORTCOLUMNS& sort) const
{
	VIEWDATA* pVData = GetActiveViewData();

	sort = pVData ? pVData->sort : m_sort;
}

BOOL CTabbedToDoCtrl::SelectTask(DWORD dwTaskID)
{
	BOOL bRes = CToDoCtrl::SelectTask(dwTaskID);

	// check task has not been filtered out
	if (InListView())
	{
		int nItem = FindTask(dwTaskID);

		if (nItem == -1)
		{
			ASSERT(0);
			return FALSE;
		}
		
		// remove focused state from existing task
		int nFocus = m_list.GetNextItem(-1, LVNI_FOCUSED | LVNI_SELECTED);

		if (nFocus != -1)
			m_list.SetItemState(nFocus, 0, LVIS_SELECTED | LVIS_FOCUSED);

		m_list.SetItemState(nItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
		m_list.EnsureVisible(nItem, FALSE);

		ScrollClientColumnIntoView();
	}

	return bRes;
}

BOOL CTabbedToDoCtrl::EditSelectedTask(BOOL bTaskIsNew)
{
	ScrollClientColumnIntoView();

	return CToDoCtrl::EditSelectedTask(bTaskIsNew);
}

void CTabbedToDoCtrl::ScrollClientColumnIntoView()
{
	// check task has not been filtered out
	if (InListView() && m_list.GetItemCount())
	{
		// scroll client column into view if necessary
		CRect rItem, rClient;
		GetItemTitleRect(0, TDCTR_EDIT, rItem);

		m_list.GetWindowRect(rClient);
		ScreenToClient(rClient);

		CSize pos(0, 0);

		if (rItem.left < rClient.left)
		{
			// scroll left edge to left client edge
			pos.cx = rItem.left - rClient.left;
		}
		else if (rItem.right > rClient.right)
		{
			// scroll right edge to right client edge so long as
			// left edge is still in view
			int nToScrollRight = rItem.right - rClient.right;
			int nMaxScrollLeft = rItem.left - rClient.left;

			pos.cx = min(nMaxScrollLeft, nToScrollRight);
		}

		if (pos.cx)
			m_list.Scroll(pos);
	}
}

LRESULT CTabbedToDoCtrl::OnEditCancel(WPARAM wParam, LPARAM lParam)
{
	// check if we need to delete the just added item
	if (InListView() && GetSelectedTaskID() == m_dwLastAddedID)
	{
		int nDelItem = GetFirstSelectedItem();
		m_list.DeleteItem(nDelItem);
	}

	LRESULT lr = CToDoCtrl::OnEditCancel(wParam, lParam);

	return lr;
}

int CTabbedToDoCtrl::FindTask(DWORD dwTaskID) const
{
	if (!dwTaskID)
		return -1;

	LVFINDINFO lvfi;
	ZeroMemory(&lvfi, sizeof(lvfi));

    lvfi.flags = LVFI_PARAM;
    lvfi.lParam = dwTaskID;
    lvfi.vkDirection = VK_DOWN;

	return m_list.FindItem(&lvfi);
}

DWORD CTabbedToDoCtrl::GetFocusedListTaskID() const
{
	int nItem = m_list.GetNextItem(-1, LVNI_FOCUSED | LVNI_SELECTED);

	if (nItem != -1)
		return m_list.GetItemData(nItem);

	// else
	return 0;
}

void CTabbedToDoCtrl::SetSelectedListTasks(const CDWordArray& aTaskIDs, DWORD dwFocusedTaskID)
{
//	int nSel = -1;

	for (int nTask = 0; nTask < aTaskIDs.GetSize(); nTask++)
	{
		DWORD dwTaskID = aTaskIDs[nTask];
		int nItem = FindTask(dwTaskID);

		if (nItem != -1)
		{
			if (dwTaskID == dwFocusedTaskID)
				m_list.SetItemState(nItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
			else
				m_list.SetItemState(nItem, LVIS_SELECTED, LVIS_SELECTED);

//			if (nSel == -1)
//				nSel = nItem;
		}
		else // deselect in tree
		{
			HTREEITEM hti = m_find.GetItem(dwTaskID);
			Selection().SetItem(hti, TSHS_DESELECT, FALSE);
		}
	}

/*	// focused item
	if (dwFocusedTaskID)
	{
		int nItem = FindTask(dwFocusedTaskID);

		if (nItem != -1)
		{
			m_list.SetItemState(nItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
//			nSel = nItem;
		}
	}
*/
	// make sure selection is visible
//	if (nSel != -1)
//		m_list.EnsureVisible(nSel, FALSE);
}

LRESULT CTabbedToDoCtrl::OnGutterWidthChange(WPARAM wParam, LPARAM lParam)
{
	CToDoCtrl::OnGutterWidthChange(wParam, lParam);

	// update column widths if in list view
	UpdateListColumnWidths();
	
	return 0;
}

void CTabbedToDoCtrl::OnListSelChanged(NMHDR* /*pNMHDR*/, LRESULT* pResult)
{
	*pResult = 0;
}

void CTabbedToDoCtrl::ClearListSelection()
{
	//CHoldRedraw hr2(m_list);

	POSITION pos = m_list.GetFirstSelectedItemPosition();

	while (pos)
	{
		int nItem = m_list.GetNextSelectedItem(pos);
		m_list.SetItemState(nItem, 0, LVIS_SELECTED);
	}
}

int CTabbedToDoCtrl::GetFirstSelectedItem() const
{
	return m_list.GetNextItem(-1, LVNI_SELECTED);
}

int CTabbedToDoCtrl::GetSelectedListTaskIDs(CDWordArray& aTaskIDs, DWORD& dwFocusedTaskID) const
{
	aTaskIDs.RemoveAll();
	aTaskIDs.SetSize(m_list.GetSelectedCount());

	int nCount = 0;
	POSITION pos = m_list.GetFirstSelectedItemPosition();

	while (pos)
	{
		int nItem = m_list.GetNextSelectedItem(pos);

		aTaskIDs[nCount] = m_list.GetItemData(nItem);
		nCount++;
	}

	dwFocusedTaskID = GetFocusedListTaskID();

	return aTaskIDs.GetSize();
}

BOOL CTabbedToDoCtrl::SetTreeFont(HFONT hFont)
{
	CToDoCtrl::SetTreeFont(hFont);

	if (m_list.GetSafeHwnd())
	{
		if (!hFont) // set to our font
		{
			// for some reason i can not yet explain, our font
			// is not correctly set so we use our parent's font instead
			// hFont = (HFONT)SendMessage(WM_GETFONT);
			hFont = (HFONT)GetParent()->SendMessage(WM_GETFONT);
		}

		HFONT hListFont = (HFONT)m_list.SendMessage(WM_GETFONT);
		BOOL bChange = (hFont != hListFont || !GraphicsMisc::SameFontNameSize(hFont, hListFont));

		if (bChange)
		{
			m_list.SendMessage(WM_SETFONT, (WPARAM)hFont, TRUE);
			RemeasureList();

			if (InListView())
				m_list.Invalidate(TRUE);
		}
	}

	return TRUE;
}

void CTabbedToDoCtrl::OnListClick(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMIA = (LPNMITEMACTIVATE)pNMHDR;
//	TRACE ("CTabbedToDoCtrl::OnListClick\n");

	UpdateTreeSelection();

	if (pNMIA->iItem != -1) // validate item
	{
		int nHit = pNMIA->iItem;
		TDC_COLUMN nCol = GetColumnID(pNMIA->iSubItem);

		DWORD dwClickID = m_list.GetItemData(nHit);
		HTREEITEM htiHit = m_find.GetItem(dwClickID);
		ASSERT(htiHit);

/*		if (Misc::KeyIsPressed(VK_MENU))
		{

			UINT nCtrlID = MapColumnToCtrlID(nCol);

			if (nCtrlID)
				GetDlgItem(nCtrlID)->SetFocus();


			return;
		}
*/		
		// column specific handling
		BOOL bCtrl = Misc::KeyIsPressed(VK_CONTROL);

		switch (nCol)
		{
		case TDCC_CLIENT:
			if (dwClickID == m_dw2ndClickItem)
				m_list.PostMessage(LVM_EDITLABEL);
			else
			{
				CRect rCheck;
								
				if (GetItemTitleRect(nHit, TDCTR_CHECKBOX, rCheck))
				{
					CPoint ptHit(::GetMessagePos());
					m_list.ScreenToClient(&ptHit);

					if (rCheck.PtInRect(ptHit))
					{
						BOOL bDone = m_data.IsTaskDone(dwClickID);
						SetSelectedTaskDone(!bDone);
					}
				}
			}
			break;
			
		case TDCC_FILEREF:
			if (bCtrl)
			{
				CString sFile = m_data.GetTaskFileRef(dwClickID);
				
				if (!sFile.IsEmpty())
					GotoFile(sFile, TRUE);
			}
			break;
			
		case TDCC_DEPENDENCY:
			if (bCtrl)
			{
				CStringArray aDepends;
				m_data.GetTaskDependencies(dwClickID, aDepends);
				
				if (aDepends.GetSize())
					ShowTaskLink(0, aDepends[0]);
			}
			break;
			
		case TDCC_TRACKTIME:
			if (!IsReadOnly())
			{
				if (GetSelectedCount() == 1 && IsItemSelected(nHit) && m_data.IsTaskTimeTrackable(dwClickID))
				{
					int nPrev = FindTask(m_dwTimeTrackTaskID);

					if (nPrev == -1)
					{
						m_list.RedrawItems(nPrev, nPrev);
						m_list.UpdateWindow();
					}

					TimeTrackTask(htiHit);
					m_list.RedrawItems(nHit, nHit);
					m_list.UpdateWindow();

					// resort if required
					VIEWDATA* pLVData = GetViewData(FTCV_TASKLIST);

					if (!pLVData->bMultiSort && pLVData->sort.nBy1 == TDC_SORTBYTIMETRACKING)
						Sort(TDC_SORTBYTIMETRACKING, FALSE);
				}
			}
			break;
			
		case TDCC_DONE:
			if (!IsReadOnly())
				SetSelectedTaskDone(!m_data.IsTaskDone(dwClickID));
			break;
			
		case TDCC_FLAG:
			if (!IsReadOnly())
			{
				BOOL bFlagged = m_data.IsTaskFlagged(dwClickID);
				SetSelectedTaskFlag(!bFlagged);
			}
			break;
		}
	}

	m_dw2ndClickItem = 0;
	
	*pResult = 0;
}

void CTabbedToDoCtrl::OnListDblClick(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMIA = (LPNMITEMACTIVATE)pNMHDR;

	if (pNMIA->iItem != -1) // validate item
	{
		DWORD dwTaskID = GetTaskID(pNMIA->iItem);
		TDC_COLUMN nCol = GetColumnID(pNMIA->iSubItem);
		
		switch (nCol)
		{
		case TDCC_CLIENT:
			{
				// where did they double-click?
				CRect rItem;
				
				if (GetItemTitleRect(pNMIA->iItem, TDCTR_ICON, rItem) && rItem.PtInRect(pNMIA->ptAction))
					EditSelectedTaskIcon();
				else
				{
					CClientDC dc(&m_list);
					GetItemTitleRect(pNMIA->iItem, TDCTR_LABEL, rItem, &dc, GetSelectedTaskTitle());
					
					if (rItem.PtInRect(pNMIA->ptAction))
						m_list.PostMessage(LVM_EDITLABEL);
				}
			}
			break;

		case TDCC_FILEREF:
			{
				CString sFile = m_data.GetTaskFileRef(dwTaskID);
				
				if (!sFile.IsEmpty())
					GotoFile(sFile, TRUE);
			}
			break;
			
		case TDCC_DEPENDENCY:
			{
				CStringArray aDepends;
				m_data.GetTaskDependencies(dwTaskID, aDepends);
				
				if (aDepends.GetSize())
					ShowTaskLink(0, aDepends[0]);
			}
			break;
						
		case TDCC_RECURRENCE:
			m_eRecurrence.DoEdit();
			break;
					
		case TDCC_ICON:
			EditSelectedTaskIcon();
			break;
			
		case TDCC_REMINDER:
			AfxGetMainWnd()->SendMessage(WM_TDCN_DOUBLECLKREMINDERCOL);
			break;
		}
	}
	
	*pResult = 0;
}

void CTabbedToDoCtrl::OnListKeyDown(NMHDR* /*pNMHDR*/, LRESULT* pResult)
{
	// for reasons I have not yet divined, we are not receiving this message
	// as expected. So I've added an ASSERT(0) should it ever come to life
	// and have handled the key down message in ScWindowProc
	//LPNMKEY pNMK = (LPNMKEY)pNMHDR;
	ASSERT(0);
//	TRACE ("CTabbedToDoCtrl::OnListKeyDown\n");
//	UpdateTreeSelection();

	*pResult = 0;
}

BOOL CTabbedToDoCtrl::PtInHeader(CPoint ptScreen) const
{
	if (InListView())
		return m_list.PtInHeader(ptScreen);

	// else
	return CToDoCtrl::PtInHeader(ptScreen);
}

BOOL CTabbedToDoCtrl::IsMultiSorting() const
{
	if (InTreeView())
		return CToDoCtrl::IsMultiSorting();

	// else
	return GetActiveViewData()->bMultiSort;
}

void CTabbedToDoCtrl::MultiSort(const TDSORTCOLUMNS& sort)
{
	if (InTreeView())
	{
		CToDoCtrl::MultiSort(sort);
		return;
	}
	
	ASSERT (sort.nBy1 != TDC_UNSORTED);

	if (sort.nBy1 == TDC_UNSORTED)
		return;

	// do the sort using whatever we can out of CToDoCtrlData
	TDSORTPARAMS ss;
	ss.sort = sort;
	ss.pData = &m_data;
	ss.bSortChildren = FALSE;
	ss.dwTimeTrackID = 0;

	m_list.SortItems(CToDoCtrl::SortFuncMulti, (DWORD)&ss);
	
	VIEWDATA* pLVData = GetViewData(FTCV_TASKLIST);

	pLVData->bModSinceLastSort = FALSE;
	pLVData->bMultiSort = TRUE;
	pLVData->sort = sort;
	
	// update registry
	SaveSortState(CPreferences());

	UpdateListColumnWidths();
}

void CTabbedToDoCtrl::Sort(TDC_SORTBY nBy, BOOL bAllowToggle)
{
	if (InTreeView())
	{
		CToDoCtrl::Sort(nBy, bAllowToggle);
		return;
	}
	
	VIEWDATA* pLVData = GetViewData(FTCV_TASKLIST);

	// else all the rest
	TDCCOLUMN* pTDCC = CToDoCtrl::GetColumn(nBy);
	ASSERT (pTDCC);
	
	if (!pTDCC)
		return;
	
	if (pLVData->sort.bAscending1 == -1 || nBy != pLVData->sort.nBy1)
		pLVData->sort.bAscending1 = pTDCC->bSortAscending;
	
	// if there's been a mod since last sorting then its reasonable to assume
	// that the user is not toggling direction but wants to simply resort
	// in the same direction.
	else if (bAllowToggle && !pLVData->bModSinceLastSort)
		pLVData->sort.bAscending1 = !pLVData->sort.bAscending1;
	
	// do the sort using whatever we can out of CToDoCtrlData
	TDSORTPARAMS ss(nBy, pLVData->sort.bAscending1);
	ss.pData = &m_data;
	ss.bSortChildren = FALSE;
	ss.dwTimeTrackID = m_dwTimeTrackTaskID;

	m_list.SortItems(CToDoCtrl::SortFunc, (DWORD)&ss);
	
	pLVData->sort.nBy1 = nBy;
	pLVData->sort.nBy2 = TDC_UNSORTED;
	pLVData->sort.nBy3 = TDC_UNSORTED;
	pLVData->bModSinceLastSort = FALSE;
	pLVData->bMultiSort = FALSE;
	
	// update registry
	SaveSortState(CPreferences());

	UpdateListColumnWidths();
}

BOOL CTabbedToDoCtrl::MoveSelectedTask(TDC_MOVETASK nDirection) 
{ 
	return !InTreeView() ? FALSE : CToDoCtrl::MoveSelectedTask(nDirection); 
}

BOOL CTabbedToDoCtrl::CanMoveSelectedTask(TDC_MOVETASK nDirection) const 
{ 
	return !InTreeView() ? FALSE : CToDoCtrl::CanMoveSelectedTask(nDirection); 
}

BOOL CTabbedToDoCtrl::GotoNextTask(TDC_GOTO nDirection)
{
	if (InListView() && CanGotoNextTask(nDirection))
	{
		int nSel = GetFirstSelectedItem();

		if (nDirection == TDCG_NEXT)
			nSel++;
		else
			nSel--;

		return SelectTask(m_list.GetItemData(nSel));
	}
	
	// else
	return CToDoCtrl::GotoNextTask(nDirection);
}

CRect CTabbedToDoCtrl::GetSelectedItemsRect() const
{
	CRect rInvalid(0, 0, 0, 0), rItem;
	POSITION pos = m_list.GetFirstSelectedItemPosition();

	while (pos)
	{
		int nItem = m_list.GetNextSelectedItem(pos);

		if (m_list.GetItemRect(nItem, rItem, LVIR_BOUNDS))
			rInvalid |= rItem;
	}

	return rInvalid;
}

BOOL CTabbedToDoCtrl::CanGotoNextTask(TDC_GOTO nDirection) const
{
	if (InListView())
	{
		int nSel = GetFirstSelectedItem();

		if (nDirection == TDCG_NEXT)
			return (nSel >= 0 && nSel < m_list.GetItemCount() - 1);
		
		// else prev
		return (nSel > 0 && nSel <= m_list.GetItemCount() - 1);
	}
	else
		return CToDoCtrl::CanGotoNextTask(nDirection);
}

BOOL CTabbedToDoCtrl::GotoNextTopLevelTask(TDC_GOTO nDirection)
{
	if (InListView())
		return FALSE; // not supported

	// else
	return CToDoCtrl::GotoNextTopLevelTask(nDirection);
}

BOOL CTabbedToDoCtrl::CanGotoNextTopLevelTask(TDC_GOTO nDirection) const
{
	return InListView() ? FALSE : CToDoCtrl::CanGotoNextTopLevelTask(nDirection);
}

BOOL CTabbedToDoCtrl::CanExpandTasks(TDC_EXPANDCOLLAPSE nWhat, BOOL bExpand) const 
{ 
	return InListView() ? FALSE : CToDoCtrl::CanExpandTasks(nWhat, bExpand);
}

void CTabbedToDoCtrl::SetFocusToTasks()
{
	if (InListView())
		m_list.SetFocus();
	else
		CToDoCtrl::SetFocusToTasks();
}

BOOL CTabbedToDoCtrl::TasksHaveFocus() const
{ 
	if (InListView())
		return (::GetFocus() == m_list);

	return CToDoCtrl::TasksHaveFocus(); 
}

int CTabbedToDoCtrl::FindTasks(const SEARCHPARAMS& params, CResultArray& aResults) const
{
	if (InTreeView())
		return CToDoCtrl::FindTasks(params, aResults);

	// iterate the tasks
	for (int nItem = 0; nItem < m_list.GetItemCount(); nItem++)
	{
		DWORD dwTaskID = GetTaskID(nItem);
		SEARCHRESULT result;

		if (m_data.TaskMatches(dwTaskID, params, result))
			aResults.Add(result);
	}

	return aResults.GetSize();
}


BOOL CTabbedToDoCtrl::SelectTask(CString sPart, TDC_SELECTTASK nSelect)
{
	if (InTreeView())
		return CToDoCtrl::SelectTask(sPart, nSelect);

	// else
	int nFind = -1;

	switch (nSelect)
	{
	case TDC_SELECTFIRST:
		nFind = FindTask(sPart);
		break;

	case TDC_SELECTNEXT:
		nFind = FindTask(sPart, GetFirstSelectedItem() + 1);
		break;

 	case TDC_SELECTNEXTINCLCURRENT:
 		nFind = FindTask(sPart, GetFirstSelectedItem());
 		break;

	case TDC_SELECTPREV:
		nFind = FindTask(sPart, GetFirstSelectedItem() - 1, FALSE);
		break;

	case TDC_SELECTLAST:
		nFind = FindTask(sPart, m_list.GetItemCount() - 1, FALSE);
		break;
	}

	if (nFind != -1)
		SelectTask(GetTaskID(nFind));

	return (nFind != -1);
}

int CTabbedToDoCtrl::FindTask(LPCTSTR szPart, int nStart, BOOL bNext)
{
	// build a search query
	SEARCHPARAMS params;
	params.rules.Add(SEARCHPARAM(TDCA_TASKNAMEORCOMMENTS, FO_INCLUDES, szPart));

	// we need to do this manually because CListCtrl::FindItem 
	// only looks at the start of the string
	SEARCHRESULT result;

	int nFrom = nStart;
	int nTo = bNext ? m_list.GetItemCount() : -1;
	int nInc = bNext ? 1 : -1;

	for (int nItem = nFrom; nItem != nTo; nItem += nInc)
	{
		DWORD dwTaskID = GetTaskID(nItem);

		if (m_data.TaskMatches(dwTaskID, params, result))
			return nItem;
	}

	return -1; // no match
}

void CTabbedToDoCtrl::SelectNextTasksInHistory()
{
	if (InListView() && CanSelectNextTasksInHistory())
	{
		// let CToDoCtrl do it's thing
		CToDoCtrl::SelectNextTasksInHistory();

		// then update our own selection
		ResyncListSelection();
	}
	else
		CToDoCtrl::SelectNextTasksInHistory();
}

BOOL CTabbedToDoCtrl::MultiSelectItems(const CDWordArray& aTasks, TSH_SELECT nState, BOOL bRedraw)
{
	BOOL bRes = CToDoCtrl::MultiSelectItems(aTasks, nState, bRedraw);

	if (InListView())
		ResyncListSelection();

	return bRes;
}

void CTabbedToDoCtrl::ResyncListSelection()
{
	ClearListSelection();
		
	// then update our own selection
	CDWordArray aTreeTaskIDs;
	DWORD dwFocusedID;
	
	GetSelectedTaskIDs(aTreeTaskIDs, dwFocusedID, FALSE);
	SetSelectedListTasks(aTreeTaskIDs, dwFocusedID);
	
	// now check that the tree is synced with us!
	CDWordArray aListTaskIDs;
	GetSelectedListTaskIDs(aListTaskIDs, dwFocusedID);
	
	if (!Misc::ArraysMatch(aListTaskIDs, aTreeTaskIDs))
		CToDoCtrl::MultiSelectItems(aListTaskIDs, TSHS_SELECT, FALSE);
}


void CTabbedToDoCtrl::SelectPrevTasksInHistory()
{
	if (InListView() && CanSelectPrevTasksInHistory())
	{
		// let CToDoCtrl do it's thing
		CToDoCtrl::SelectPrevTasksInHistory();

		// then update our own selection
		ResyncListSelection();
	}
	else
		CToDoCtrl::SelectPrevTasksInHistory();
}

void CTabbedToDoCtrl::InvalidateItem(HTREEITEM hti)
{
	if (InListView())
	{
		int nItem = GetListItem(hti);
		CRect rItem;

		if (GetItemTitleRect(nItem, TDCTR_BOUNDS, rItem))
			m_list.InvalidateRect(rItem, FALSE);
	}
	else
		CToDoCtrl::InvalidateItem(hti);
}

LRESULT CTabbedToDoCtrl::ScWindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case WM_RBUTTONDOWN:
		{
			// work out what got hit and make sure it's selected
			CPoint ptHit(lp);
			LVHITTESTINFO lvhti = { { ptHit.x, ptHit.y }, 0, 0, 0 };

			int nHit = m_list.HitTest(&lvhti);

			if (!IsItemSelected(nHit))
				SelectTask(GetTaskID(nHit));
		}
		break;

	case WM_LBUTTONDOWN:
		{
			// work out what got hit
			CPoint ptHit(lp);
			LVHITTESTINFO lvhti = { { ptHit.x, ptHit.y }, 0, 0, 0 };

			m_list.SubItemHitTest(&lvhti);
			int nHit = lvhti.iItem;

			if (nHit != -1 && !IsReadOnly())
			{
				TDC_COLUMN nCol = GetColumnID(lvhti.iSubItem);
				DWORD dwTaskID = GetTaskID(nHit);
				//HTREEITEM htiHit = GetTreeItem(nHit);

				// if the user is clicking on an already multi-selected
				// item since we may need to carry out an operation on multiple items
				int nSelCount = GetSelectedCount();

				if (nSelCount > 1 && IsItemSelected(nHit))
				{
					switch (nCol)
					{
					case TDCC_DONE:
						{
							BOOL bDone = m_data.IsTaskDone(dwTaskID);
							SetSelectedTaskDone(!bDone);
							return 0; // eat it
						}
						break;

					case TDCC_CLIENT:
						{
							CRect rCheck;

							if (GetItemTitleRect(nHit, TDCTR_CHECKBOX, rCheck) && rCheck.PtInRect(ptHit))
							{
								BOOL bDone = m_data.IsTaskDone(dwTaskID);
								SetSelectedTaskDone(!bDone);
								return 0; // eat it
							}
						}
						break;
						
					case TDCC_FLAG:
						{
							BOOL bFlagged = m_data.IsTaskFlagged(dwTaskID);
							SetSelectedTaskFlag(!bFlagged);
							return 0; // eat it
						}
						break;
					}
				}
				else if (nSelCount == 1)
				{
					// if the click was on the task title of an already singly selected item
					// we record the task ID unless the control key is down in which case
					// it really means that the user has deselected the item
					if (!Misc::KeyIsPressed(VK_CONTROL))
					{
						m_dw2ndClickItem = 0;
						
						int nSel = GetFirstSelectedItem();
						if (nHit != -1 && nHit == nSel && nCol == TDCC_CLIENT)
						{
							// unfortunately we cannot rely on the flags attribute of LVHITTESTINFO
							// to see if the user clicked on the text because LVIR_LABEL == LVIR_BOUNDS
							CRect rLabel;
							CClientDC dc(&m_list);
							CFont* pOld = NULL;

							if (m_tree.GetParentItem(GetTreeItem(nHit)) == NULL) // top level items
								pOld = (CFont*)dc.SelectObject(CFont::FromHandle(m_fontBold));
							else
								pOld = (CFont*)dc.SelectObject(m_list.GetFont());

							GetItemTitleRect(nHit, TDCTR_LABEL, rLabel, &dc, GetSelectedTaskTitle());
			
							if (rLabel.PtInRect(ptHit))
								m_dw2ndClickItem = m_list.GetItemData(nHit);

							// cleanup
							dc.SelectObject(pOld);
						}

						// note: we handle WM_LBUTTONUP in OnListClick() to 
						// decide whether to do a label edit
					}
				}
			}

			// because the visual state of the list selection is actually handled by
			// whether the tree selection is up to date we need to update the tree
			// selection here, because the list ctrl does it this way natively.
			LRESULT	lr = CSubclasser::ScWindowProc(hRealWnd, msg, wp, lp);
			UpdateTreeSelection();

			return lr;
		}
		break;

	case LVM_EDITLABEL:
		if (!IsReadOnly())
			EditSelectedTask(FALSE);
		return 0; // eat it

	case WM_KEYDOWN:
		{
			// if any of the cursor keys are used and nothing is currently selected
			// then we select the top/bottom item and ignore the default list ctrl processing
			LRESULT lr = 0;

/*
			if (GetSelectedCount() == 0 && Misc::IsCursorKey(wp))
			{
				int nNumItems = m_list.GetItemCount();

				if (nNumItems > 0)
				{
					int nSelItem = 0; // top item is default

					if (wp == VK_UP || wp == VK_PRIOR)
						nSelItem = nNumItems - 1; // bottom item

					m_list.SetItemState(nSelItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
				}
			}
			else
*/
				lr = CSubclasser::ScWindowProc(hRealWnd, msg, wp, lp);

			m_wKeyPress = (WORD)wp;

			if (Misc::IsCursorKey(wp))
				UpdateTreeSelection();

			return lr;
		}
		break;

	case WM_KEYUP:
		if (Misc::IsCursorKey(wp))
			UpdateControls();
		break;

	case WM_MOUSEWHEEL:
	case WM_VSCROLL:
	case WM_HSCROLL:
		if (InListView() && IsTaskLabelEditing())
			EndLabelEdit(FALSE);

		// extra processing for WM_HSCROLL
 		if (msg == WM_HSCROLL && InListView())
 			m_list.RedrawHeader();
		
		break;

		
	case WM_NOTIFY:
		{
			LPNMHDR pNMHDR = (LPNMHDR)lp;
			
			switch (pNMHDR->code)
			{
			case NM_CUSTOMDRAW:
				if (pNMHDR->hwndFrom == m_list.GetHeader())
				{
					LRESULT lr = 0;
					OnHeaderCustomDraw(pNMHDR, &lr);
					return lr;
				}
				break;
			}
		}
		break;
	}

	return CSubclasser::ScWindowProc(hRealWnd, msg, wp, lp);
}

void CTabbedToDoCtrl::UpdateTreeSelection()
{
	// update the tree selection if it needs to be
	CDWordArray aListTaskIDs, aTreeTaskIDs;
	DWORD dwTreeFocusedID, dwListFocusedID;

	GetSelectedTaskIDs(aTreeTaskIDs, dwTreeFocusedID, FALSE);
	GetSelectedListTaskIDs(aListTaskIDs, dwListFocusedID);
	
	if (!Misc::ArraysMatch(aTreeTaskIDs, aListTaskIDs) || (dwTreeFocusedID != dwListFocusedID))
	{
		// select tree item first then multi-select after
		HTREEITEM htiFocus = m_find.GetItem(dwListFocusedID);
		m_tree.SelectItem(htiFocus);

		MultiSelectItems(aListTaskIDs, TSHS_SELECT, FALSE);

		// reset list selection
		int nFocus = FindTask(dwListFocusedID);
		m_list.SetItemState(nFocus, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
		m_list.RedrawItems(nFocus, nFocus);
	}
}

BOOL CTabbedToDoCtrl::IsItemSelected(int nItem) const
{
	HTREEITEM hti = GetTreeItem(nItem);
	return hti ? Selection().HasItem(hti) : FALSE;
}

HTREEITEM CTabbedToDoCtrl::GetTreeItem(int nItem) const
{
	if (nItem < 0 || nItem >= m_list.GetItemCount())
		return NULL;

	DWORD dwID = m_list.GetItemData(nItem);
	return m_find.GetItem(dwID);
}

int CTabbedToDoCtrl::GetListItem(HTREEITEM hti) const
{
	DWORD dwID = GetTaskID(hti);
	return (dwID ? FindTask(dwID) : -1);
}

BOOL CTabbedToDoCtrl::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	if (&m_list == pWnd)
	{
		CPoint pt(::GetMessagePos());
		m_list.ScreenToClient(&pt);

		LVHITTESTINFO lvhti = { { pt.x, pt.y }, 0, 0, 0 };
		m_list.SubItemHitTest(&lvhti);

		int nHit = lvhti.iItem;

		if (nHit >= 0)
		{
			TDC_COLUMN nCol	= GetColumnID(lvhti.iSubItem);
			DWORD dwID = m_list.GetItemData(nHit);

			BOOL bCtrl = Misc::KeyIsPressed(VK_CONTROL);
			BOOL bShowHand = FALSE;

			switch (nCol)
			{
			case TDCC_FILEREF:
				if (bCtrl)
				{
					CString sFile = m_data.GetTaskFileRef(dwID);
					bShowHand = (!sFile.IsEmpty());
				}
				break;
				
			case TDCC_DEPENDENCY:
				if (bCtrl)
				{
					CStringArray aDepends;
					m_data.GetTaskDependencies(dwID, aDepends);
					bShowHand = aDepends.GetSize();
				}
				break;
				
			case TDCC_TRACKTIME:
				if (!IsReadOnly())
				{
					bShowHand = ((!IsItemSelected(nHit) || GetSelectedCount() == 1) && 
								 m_data.IsTaskTimeTrackable(dwID));
				}
				break;
				
			case TDCC_FLAG:
				if (!IsReadOnly())
					bShowHand = TRUE;
			}

			if (bShowHand)
			{
				::SetCursor(GraphicsMisc::HandCursor());
				return TRUE;
			}
		}
	}
		
	return CToDoCtrl::OnSetCursor(pWnd, nHitTest, message);
}

LRESULT CTabbedToDoCtrl::OnDropObject(WPARAM wParam, LPARAM lParam)
{
	if (IsReadOnly())
		return 0L;

	TLDT_DATA* pData = (TLDT_DATA*)wParam;
	CWnd* pTarget = (CWnd*)lParam;

	if (pTarget == &m_list)
	{
		ASSERT (InListView());

		// simply convert the list item into the corresponding tree
		// item and pass to base class
		if (pData->nItem != -1)
			m_list.SetCurSel(pData->nItem);

		pData->hti = GetTreeItem(pData->nItem);
		pData->nItem = -1;

		lParam = (LPARAM)&m_tree;
		// fall thru
	}

	// all else
	return CToDoCtrl::OnDropObject(wParam, lParam);
}

BOOL CTabbedToDoCtrl::GetItemTitleRect(HTREEITEM hti, TDC_TITLERECT nArea, CRect& rect) const
{
	if (InListView())
	{
		int nItem = GetListItem(hti);
		return GetItemTitleRect(nItem, nArea, rect);
	}

	// else
	return CToDoCtrl::GetItemTitleRect(hti, nArea, rect);
}

BOOL CTabbedToDoCtrl::GetItemTitleRect(int nItem, TDC_TITLERECT nArea, CRect& rect, CDC* pDC, LPCTSTR szTitle) const
{
	ASSERT (InListView());
	
	if (nItem == -1)
		return FALSE;

	// basic title rect
	int nColIndex = GetColumnIndex(TDCC_CLIENT);
	const_cast<CTDCListView*>(&m_list)->GetSubItemRect(nItem, nColIndex, LVIR_LABEL, rect);

	if (nColIndex == 0 && COSVersion() >= OSV_XP) // right side columns in XP
		rect.left -= 4;

	BOOL bIcon = HasStyle(TDCS_TREETASKICONS) && !IsColumnShowing(TDCC_ICON);
	BOOL bCheckbox = HasStyle(TDCS_TREECHECKBOXES) && !IsColumnShowing(TDCC_DONE);

	switch (nArea)
	{
	case TDCTR_CHECKBOX:
		if (bCheckbox)
		{
			rect.right = rect.left + 16;
			return TRUE;
		}
		break;

	case TDCTR_ICON:
		if (bIcon)
		{
			if (bCheckbox)
				rect.left += 18;

			rect.right = rect.left + 16;
			return TRUE;
		}
		break;
		
	case TDCTR_LABEL:
		{
			if (bIcon)
				rect.left += 18;

 			if (bCheckbox)
 				rect.left += 18;

			if (pDC && szTitle)
			{
				int nTextExt = pDC->GetTextExtent(szTitle).cx;
				rect.right = rect.left + min(rect.Width(), nTextExt + 6 + 1);
			}

			return TRUE;
		}
		break;

	case TDCTR_BOUNDS:
		return TRUE; // nothing more to do

	case TDCTR_EDIT:
		if (GetItemTitleRect(nItem, TDCTR_LABEL, rect)) // recursive call
		{
			// make sure it's at least 200 but always clipped to the client rect
//			rect.right = min(rect.right, rect.left + 200);
			
			CRect rClient, rInter;
			m_list.GetClientRect(rClient);
			
			if (rInter.IntersectRect(rect, rClient))
				rect = rInter;
			
			rect.top--;

			m_list.ClientToScreen(rect);
			ScreenToClient(rect);
			
			return TRUE;
		}
		break;
	}

	return FALSE;
}

void CTabbedToDoCtrl::OnListGetInfoTip(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMLVGETINFOTIP* pLVGIT = (NMLVGETINFOTIP*)pNMHDR;
	*pResult = 0;

	int nHit = pLVGIT->iItem;

	if (nHit >= 0)
	{
		HTREEITEM hti = GetTreeItem(nHit);
		TODOITEM* pTDI = GetTask(m_list.GetItemData(nHit));

		ASSERT (pTDI);

		if (!pTDI)
			return;

		// we only display info tips when over the task title
		CRect rTitle;
		CClientDC dc(&m_list);
		CFont* pOld = NULL;
		
		if (m_tree.GetParentItem(hti) == NULL) // top level item
			pOld = (CFont*)dc.SelectObject(CFont::FromHandle(m_fontBold));
		else
			pOld = (CFont*)dc.SelectObject(m_list.GetFont());
		
		GetItemTitleRect(nHit, TDCTR_LABEL, rTitle, &dc, pTDI->sTitle);
		
		// cleanup
		dc.SelectObject(pOld);
	
		CPoint pt(::GetMessagePos());
		m_list.ScreenToClient(&pt);
		
		if (rTitle.PtInRect(pt))
		{
			//fabio_2005
#if _MSC_VER >= 1400
			strncpy_s(pLVGIT->pszText, pLVGIT->cchTextMax, FormatInfoTip(hti, pTDI), pLVGIT->cchTextMax);
#else
			_tcsncpy(pLVGIT->pszText, FormatInfoTip(hti, pTDI), pLVGIT->cchTextMax);
#endif
		}
	}
}

void CTabbedToDoCtrl::UpdateSelectedTaskPath()
{
	CToDoCtrl::UpdateSelectedTaskPath();

	// redraw the client column header
	m_list.RedrawHeaderColumn(GetColumnIndex(TDCC_CLIENT));
}

void CTabbedToDoCtrl::SaveSortState(CPreferences& prefs)
{
	// ignore this if we have no tasks
	if (GetTaskCount() == 0)
		return;

	// create a new key using the filepath
	ASSERT (GetSafeHwnd());
	
	CString sKey = GetPreferencesKey(_T("SortState"));
	
	if (!sKey.IsEmpty())
	{
		VIEWDATA* pLVData = GetViewData(FTCV_TASKLIST);

		prefs.WriteProfileInt(sKey, _T("ListMulti"), pLVData->bMultiSort);
		prefs.WriteProfileInt(sKey, _T("ListColumn"), pLVData->sort.nBy1);
		prefs.WriteProfileInt(sKey, _T("ListColumn2"), pLVData->sort.nBy2);
		prefs.WriteProfileInt(sKey, _T("ListColumn3"), pLVData->sort.nBy3);
		prefs.WriteProfileInt(sKey, _T("ListAscending"), pLVData->sort.bAscending1);
		prefs.WriteProfileInt(sKey, _T("ListAscending2"), pLVData->sort.bAscending2);
		prefs.WriteProfileInt(sKey, _T("ListAscending3"), pLVData->sort.bAscending3);
	}

	// base class
	CToDoCtrl::SaveSortState(prefs);
}

void CTabbedToDoCtrl::LoadSortState(const CPreferences& prefs, LPCTSTR szFilePath)
{
	CString sKey = GetPreferencesKey(_T("SortState"), szFilePath);
	
	if (!sKey.IsEmpty())
	{
		VIEWDATA* pLVData = GetViewData(FTCV_TASKLIST);

		pLVData->bMultiSort = prefs.GetProfileInt(sKey, _T("ListMulti"), FALSE);
		pLVData->sort.nBy1 = (TDC_SORTBY)prefs.GetProfileInt(sKey, _T("ListColumn"), TDC_UNSORTED);
		pLVData->sort.nBy2 = (TDC_SORTBY)prefs.GetProfileInt(sKey, _T("ListColumn2"), TDC_UNSORTED);
		pLVData->sort.nBy3 = (TDC_SORTBY)prefs.GetProfileInt(sKey, _T("ListColumn3"), TDC_UNSORTED);
		pLVData->sort.bAscending1 = prefs.GetProfileInt(sKey, _T("ListAscending"), TRUE);
		pLVData->sort.bAscending2 = prefs.GetProfileInt(sKey, _T("ListAscending2"), TRUE);
		pLVData->sort.bAscending3 = prefs.GetProfileInt(sKey, _T("ListAscending3"), TRUE);

		CToDoCtrl::LoadSortState(prefs, szFilePath);

		pLVData->sort.nBy1 = max(pLVData->sort.nBy1, TDC_UNSORTED); // backwards compatibility
		pLVData->bNeedResort = (pLVData->sort.nBy1 != TDC_UNSORTED);
	}
}


void CTabbedToDoCtrl::RedrawReminders() const
{ 
	if (InTreeView())
		CToDoCtrl::RedrawReminders();

	else if (IsColumnShowing(TDCC_REMINDER))
	{
		CListCtrl* pList = const_cast<CTDCListView*>(&m_list);
		pList->Invalidate(FALSE);
	}
}
