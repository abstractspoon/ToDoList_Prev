// TaskFile.h: interface for the CTaskFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TASKFILE_H__BA5D71E7_2770_45FD_A693_A2344B589DF4__INCLUDED_)
#define AFX_TASKFILE_H__BA5D71E7_2770_45FD_A693_A2344B589DF4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\SHARED\ITaskList.h"

#include <afxtempl.h>

#ifdef NO_TL_ENCRYPTDECRYPT
#	include "..\SHARED\xmlfile.h"
#	define XMLBASE CXmlFile
#else
#	include "..\SHARED\xmlfileex.h"
#	define XMLBASE CXmlFileEx
#endif

struct TDIRECURRENCE; // predeclaration
class CBinaryData;
class TODOITEM;

struct TASKFILE_HEADER
{
	TASKFILE_HEADER() : bArchive(-1), bUnicode(-1), dwNextID(0), nFileFormat(-1), nFileVersion(-1)
	{

	}

	CString sXmlHeader;
	CString sProjectName;
	CString sFileName;
	CString sCheckedOutTo;
	BOOL bArchive;
	BOOL bUnicode;
	COleDateTime dtEarliestDue;
	DWORD dwNextID;
	int nFileFormat;
	int nFileVersion;
};

class CTaskFile : public ITASKLISTBASE, public XMLBASE
{
	friend class CMultiTaskFile;

public:
	CTaskFile(LPCTSTR szPassword = NULL);
	CTaskFile(const CTaskFile& tasks, LPCTSTR szPassword = NULL);
	CTaskFile(const ITaskList* pTasks, LPCTSTR szPassword = NULL);
	virtual ~CTaskFile();

	BOOL Load(LPCTSTR szFilePath, IXmlParse* pCallback = NULL, BOOL bDecrypt = TRUE);

	virtual BOOL LoadEx(IXmlParse* pCallback = NULL);
	virtual BOOL SaveEx();
	virtual BOOL LoadHeader(LPCTSTR szFilePath, TASKFILE_HEADER* pHeader = NULL);

	void SetHeader(const TASKFILE_HEADER& header);
	void GetHeader(TASKFILE_HEADER& header) const;

#ifndef NO_TL_ENCRYPTDECRYPT
	virtual BOOL Decrypt(LPCTSTR szPassword = NULL); 
#endif

	BOOL CopyFrom(const CTaskFile& tasks);
	BOOL CopyFrom(const ITaskList* pTasks);
	BOOL CopyTo(ITaskList* pTasks);
	
	BOOL CopyTaskFrom(const ITaskList* pSrcTasks, HTASKITEM hSrcTask, HTASKITEM hDestParent);
	BOOL CopyTaskTo(HTASKITEM hSrcTask, ITaskList* pDestTasks, HTASKITEM hDestParent);

	void Reset();
	int GetTaskCount() const;

#ifndef NO_TL_MERGE
	int Merge(const CTaskFile& tasks, BOOL bByID, BOOL bMoveExist);
	int Merge(LPCTSTR szTaskFilePath, BOOL bByID, BOOL bMoveExist);
#endif

	HTASKITEM NewTask(LPCTSTR szTitle, HTASKITEM hParent, DWORD dwID);

	DWORD GetNextUniqueID() const; 
	BOOL SetNextUniqueID(DWORD dwNextID); 

	BOOL SetCheckedOutTo(const CString& sCheckedOutTo);
	BOOL IsCheckedOutTo(const CString& sCheckedOutTo) const;

	BOOL SetArchive(BOOL bArchive = TRUE);
	BOOL SetFileFormat(unsigned long lFormat);
	BOOL SetCharSet(LPCTSTR szCharSet);
	BOOL SetFileName(LPCTSTR szFilename);

	void SetHtmlImageFolder(LPCTSTR szImgFolder) { m_sHtmlImgFolder = szImgFolder; }
	CString GetHtmlImageFolder() { return m_sHtmlImgFolder; }
	
	BOOL SetCategoryNames(const CStringArray& aCategories);
	BOOL SetTagNames(const CStringArray& aTags);
	BOOL SetStatusNames(const CStringArray& aStatuses);
	BOOL SetAllocToNames(const CStringArray& aAllocTo);
	BOOL SetAllocByNames(const CStringArray& aAllocBy);
	BOOL SetVersionNames(const CStringArray& aVersions);
	int GetCategoryNames(CStringArray& aCategories) const;
	int GetTagNames(CStringArray& aTags) const;
	int GetStatusNames(CStringArray& aStatuses) const;
	int GetAllocToNames(CStringArray& aAllocTo) const;
	int GetAllocByNames(CStringArray& aAllocBy) const;
	int GetVersionNames(CStringArray& aVersions) const;

	BOOL SetEarliestDueDate(const COleDateTime& date);
	BOOL GetEarliestDueDate(COleDateTime& date) const;

	CString GetCommentsType() const; 
	void EnableISODates(BOOL bEnable = TRUE) { m_bISODates = bEnable; }

	COleDateTime GetTaskLastModifiedOle(HTASKITEM hTask) const;
	COleDateTime GetTaskDoneDateOle(HTASKITEM hTask) const;
	COleDateTime GetTaskDueDateOle(HTASKITEM hTask) const;
	COleDateTime GetTaskStartDateOle(HTASKITEM hTask) const;
	COleDateTime GetTaskCreationDateOle(HTASKITEM hTask) const;

	BOOL SetTaskID(HTASKITEM hTask, unsigned long nID, BOOL bVisible = TRUE);

	BOOL SetTaskAttributes(HTASKITEM hTask, const TODOITEM* pTDI);
	BOOL GetTaskAttributes(HTASKITEM hTask, TODOITEM* pTDI) const;

	BOOL SetTaskLastModified(HTASKITEM hTask, const COleDateTime& tLastMod);
	BOOL SetTaskDoneDate(HTASKITEM hTask, const COleDateTime& date);
	BOOL SetTaskDueDate(HTASKITEM hTask, const COleDateTime& date);
	BOOL SetTaskStartDate(HTASKITEM hTask, const COleDateTime& date);
	BOOL SetTaskCreationDate(HTASKITEM hTask, const COleDateTime& date);

	BOOL SetTaskRecurrence(HTASKITEM hTask, const TDIRECURRENCE& tr);
	BOOL GetTaskRecurrence(HTASKITEM hTask, TDIRECURRENCE& tr) const;

	BOOL SetTaskTextColor(HTASKITEM hTask, COLORREF color);
	BOOL SetTaskPriorityColor(HTASKITEM hTask, COLORREF color);
	BOOL SetTaskCalcTimeEstimate(HTASKITEM hTask, double dTime);
	BOOL SetTaskCalcTimeSpent(HTASKITEM hTask, double dTime);
	BOOL SetTaskEarliestDueDate(HTASKITEM hTask,  const COleDateTime& date);
	BOOL SetTaskCalcCompletion(HTASKITEM hTask, int nPercent);
	BOOL SetTaskHighestPriority(HTASKITEM hTask, int nPriority);
	BOOL SetTaskHighestRisk(HTASKITEM hTask, int nRisk);
	BOOL SetTaskCalcCost(HTASKITEM hTask, double dCost);

	BOOL SetTaskIcon(HTASKITEM hTask, const CString& sIcon);
	CString GetTaskIcon(HTASKITEM hTask) const;

	BOOL SetTaskCategories(HTASKITEM hTask, const CStringArray& aCategories);
	int  GetTaskCategories(HTASKITEM hTask, CStringArray& aCategories) const;

	BOOL SetTaskTags(HTASKITEM hTask, const CStringArray& aTags);
	int  GetTaskTags(HTASKITEM hTask, CStringArray& aTags) const;

	BOOL SetTaskDependencies(HTASKITEM hTask, const CStringArray& aDepends);
	int  GetTaskDependencies(HTASKITEM hTask, CStringArray& aDepends) const;

	BOOL SetTaskAllocatedTo(HTASKITEM hTask, const CStringArray& aAllocTo);
	int  GetTaskAllocatedTo(HTASKITEM hTask, CStringArray& aAllocTo) const;

	BOOL SetTaskCustomComments(HTASKITEM hTask, const CBinaryData& content, const CString& sType);
	BOOL GetTaskCustomComments(HTASKITEM hTask, CBinaryData& content, CString& sType) const;
	BOOL SetTaskHtmlComments(HTASKITEM hTask, const CString& sContent, BOOL bForTransform);
	
	BOOL DeleteTaskAttributes(HTASKITEM hTask);// deletes all but child tasks
	BOOL DeleteTask(HTASKITEM hTask);

	BOOL CheckOut(LPCTSTR szCheckOutTo, CString& sCheckedOutTo);
	BOOL CheckOut(LPCTSTR szCheckOutTo);

	BOOL SetReportAttributes(LPCTSTR szTitle, const COleDateTime& date = 0.0);
	BOOL HideAttribute(HTASKITEM hTask, LPCTSTR szAttrib, BOOL bHide = TRUE);

	//////////////////////////////////////////////////////////////
	// ITaskList9 implementation 
	unsigned char GetTaskTagCount(HTASKITEM hTask) const;
	LPCTSTR GetTaskTag(HTASKITEM hTask, int nIndex) const;
	bool AddTaskTag(HTASKITEM hTask, LPCTSTR szTag);
	
	LPCTSTR GetTaskPositionString(HTASKITEM hTask) const;
	bool SetTaskPosition(HTASKITEM hTask, LPCTSTR szPos);

	//////////////////////////////////////////////////////////////
	// ITaskList8 implementation 
	unsigned long GetTaskParentID(HTASKITEM hTask) const;
	HTASKITEM FindTask(unsigned long dwTaskID) const;
 	bool SetTaskAttribute(HTASKITEM hTask, LPCTSTR szAttrib, LPCTSTR szValue);

	// already exists above
	// HTASKITEM NewTask(LPCTSTR szTitle, HTASKITEM hParent, DWORD dwID);
	// int GetTaskCount() const;
	// void Reset();

	//////////////////////////////////////////////////////////////
	// ITaskList7 implementation 
	unsigned char GetTaskDependencyCount(HTASKITEM hTask) const;
	bool AddTaskDependency(HTASKITEM hTask, LPCTSTR szDepends);
	bool AddTaskDependency(HTASKITEM hTask, unsigned long dwID);
	LPCTSTR GetTaskDependency(HTASKITEM hTask, int nIndex) const;

	unsigned char GetTaskAllocatedToCount(HTASKITEM hTask) const;
	bool AddTaskAllocatedTo(HTASKITEM hTask, LPCTSTR szAllocTo);
	LPCTSTR GetTaskAllocatedTo(HTASKITEM hTask, int nIndex) const;

	//////////////////////////////////////////////////////////////
	// ITaskList6 implementation 
	LPCTSTR GetTaskVersion(HTASKITEM hTask) const;
	bool GetTaskRecurrence(HTASKITEM hTask, int& nRegularity, DWORD& dwSpecific1, 
									DWORD& dwSpecific2, BOOL& bRecalcFromDue, int& nReuse) const;

	bool SetTaskVersion(HTASKITEM hTask, LPCTSTR szVersion);
	bool SetTaskRecurrence(HTASKITEM hTask, int nRegularity, DWORD dwSpecific1, 
									DWORD dwSpecific2, BOOL bRecalcFromDue, int nReuse);

	//////////////////////////////////////////////////////////////
	// ITaskList5 implementation 
	bool AddTaskCategory(HTASKITEM hTask, LPCTSTR szCategory);

	//////////////////////////////////////////////////////////////
	// ITaskList4 implementation 
	LPCTSTR GetAttribute(LPCTSTR szAttrib) const;

	LPCTSTR GetHtmlCharSet() const;
	LPCTSTR GetReportTitle() const;
	LPCTSTR GetReportDate() const;
	double GetTaskCost(HTASKITEM hTask, BOOL bCalc) const;
	unsigned char GetTaskCategoryCount(HTASKITEM hTask) const;
	LPCTSTR GetTaskCategory(HTASKITEM hTask, int nIndex) const;
	LPCTSTR GetTaskDependency(HTASKITEM hTask) const;

	bool SetTaskCost(HTASKITEM hTask, double dCost);
	bool SetTaskDependency(HTASKITEM hTask, LPCTSTR szDepends);

	//////////////////////////////////////////////////////////////
	// ITaskList3 implementation 
	time_t GetTaskDueDate(HTASKITEM hTask, BOOL bEarliest) const;
	LPCTSTR GetTaskDueDateString(HTASKITEM hTask, BOOL bEarliest) const;
	unsigned long GetTaskTextColor(HTASKITEM hTask) const;
	int GetTaskRisk(HTASKITEM hTask, BOOL bHighest) const;
	LPCTSTR GetTaskExternalID(HTASKITEM hTask) const;

	bool SetTaskRisk(HTASKITEM hTask, int nRisk);
	bool SetTaskExternalID(HTASKITEM hTask, LPCTSTR szID);

	//////////////////////////////////////////////////////////////
	// ITaskList2 implementation 
	
	LPCTSTR GetTaskCreatedBy(HTASKITEM hTask) const;
	time_t GetTaskCreationDate(HTASKITEM hTask) const;
	LPCTSTR GetTaskCreationDateString(HTASKITEM hTask) const;

	bool SetTaskCreatedBy(HTASKITEM hTask, LPCTSTR szCreatedBy);
	bool SetTaskCreationDate(HTASKITEM hTask, time_t tCreationDate);

	//////////////////////////////////////////////////////////////
	// ITaskList implementation 

	bool IsArchive() const;
	
	LPCTSTR GetProjectName() const;

	bool IsSourceControlled() const;
	LPCTSTR GetCheckOutTo() const;
	bool IsCheckedOut() const { ASSERT(0); return false; } // Deprecated
	
	unsigned long GetFileFormat() const;
	unsigned long GetFileVersion() const;
	
	time_t GetLastModified() const { ASSERT(0); return 0; } // Deprecated

	bool SetProjectName(LPCTSTR szName);
	bool SetFileVersion(unsigned long nVersion);

	//////////////////////////////////////////////////////////////

	HTASKITEM NewTask(LPCTSTR szTitle, HTASKITEM hParent = NULL);

	HTASKITEM GetFirstTask(HTASKITEM hParent = NULL) const;
	HTASKITEM GetNextTask(HTASKITEM hTask) const;

	LPCTSTR GetTaskTitle(HTASKITEM hTask) const;
	LPCTSTR GetTaskComments(HTASKITEM hTask) const;
	LPCTSTR GetTaskAllocatedTo(HTASKITEM hTask) const;
	LPCTSTR GetTaskAllocatedBy(HTASKITEM hTask) const;
	LPCTSTR GetTaskCategory(HTASKITEM hTask) const;
	LPCTSTR GetTaskStatus(HTASKITEM hTask) const;
	LPCTSTR GetTaskFileReferencePath(HTASKITEM hTask) const;
	LPCTSTR GetTaskWebColor(HTASKITEM hTask) const;
	LPCTSTR GetTaskPriorityWebColor(HTASKITEM hTask) const;

	unsigned long GetTaskID(HTASKITEM hTask) const;
	unsigned long GetTaskColor(HTASKITEM hTask) const;
	unsigned long GetTaskPriorityColor(HTASKITEM hTask) const;
	unsigned long GetTaskPosition(HTASKITEM hTask) const;

	int GetTaskPriority(HTASKITEM hTask, BOOL bHighest) const;
	unsigned char GetTaskPercentDone(HTASKITEM hTask, BOOL bCalc) const;

	double GetTaskTimeEstimate(HTASKITEM hTask, TCHAR& cUnits, BOOL bCalc) const;
	double GetTaskTimeSpent(HTASKITEM hTask, TCHAR& cUnits, BOOL bCalc) const;

	time_t GetTaskLastModified(HTASKITEM hTask) const;
	time_t GetTaskDoneDate(HTASKITEM hTask) const;
	time_t GetTaskDueDate(HTASKITEM hTask) const;
	time_t GetTaskStartDate(HTASKITEM hTask) const;

	LPCTSTR GetTaskDoneDateString(HTASKITEM hTask) const;
	LPCTSTR GetTaskDueDateString(HTASKITEM hTask) const;
	LPCTSTR GetTaskStartDateString(HTASKITEM hTask) const;
	
	bool IsTaskDone(HTASKITEM hTask) const;
	bool IsTaskDue(HTASKITEM hTask) const;
	bool IsTaskFlagged(HTASKITEM hTask) const;

	bool TaskHasAttribute(HTASKITEM hTask, LPCTSTR szAttrib) const;
	LPCTSTR GetTaskAttribute(HTASKITEM hTask, LPCTSTR szAttrib) const;
	HTASKITEM GetTaskParent(HTASKITEM hTask) const;

	/////////////////////////////////////////////////////

	bool SetTaskTitle(HTASKITEM hTask, LPCTSTR szTitle);
	bool SetTaskComments(HTASKITEM hTask, LPCTSTR szComments);
	bool SetTaskAllocatedTo(HTASKITEM hTask, LPCTSTR szAllocTo);
	bool SetTaskAllocatedBy(HTASKITEM hTask, LPCTSTR szAllocBy);
	bool SetTaskCategory(HTASKITEM hTask, LPCTSTR szCategory);
	bool SetTaskStatus(HTASKITEM hTask, LPCTSTR szStatus);
	bool SetTaskFileReferencePath(HTASKITEM hTask, LPCTSTR szFileRefpath);

	bool SetTaskColor(HTASKITEM hTask, unsigned long nColor);
	bool SetTaskWebColor(HTASKITEM hTask, unsigned long nColor);

	bool SetTaskPriority(HTASKITEM hTask, int nPriority);
	bool SetTaskPercentDone(HTASKITEM hTask, unsigned char nPercent);

	bool SetTaskTimeEstimate(HTASKITEM hTask, double dTimeEst, TCHAR cUnits);
	bool SetTaskTimeSpent(HTASKITEM hTask, double dTimeSpent, TCHAR cUnits);

	bool SetTaskLastModified(HTASKITEM hTask, time_t tLastMod);
	bool SetTaskDoneDate(HTASKITEM hTask, time_t tDoneDate);
	bool SetTaskDueDate(HTASKITEM hTask, time_t tDueDate);
	bool SetTaskStartDate(HTASKITEM hTask, time_t tStartDate);

	bool SetTaskPosition(HTASKITEM hTask, unsigned long nPos);
	bool SetTaskFlag(HTASKITEM hTask, bool bFlag);

	/////////////////////////////////////////////////////
	// IUnknown implementation
	HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void __RPC_FAR *__RPC_FAR *ppvObject);
    ULONG STDMETHODCALLTYPE AddRef(void) { return 1; } // do nothing
    ULONG STDMETHODCALLTYPE Release( void) { return 1; } // do nothing

protected:
	mutable CMap <HTASKITEM, HTASKITEM, CXmlItem*, CXmlItem*&> m_mapHandles;
	DWORD m_dwNextUniqueID;
	BOOL m_bISODates;
	CString m_sHtmlImgFolder;

protected:
	void BuildHandleMap() const;
	void AddTaskToMap(const CXmlItem* pXITask, BOOL bRecurse) const;
	void RemoveTaskFromMap(const CXmlItem* pXITask) const;
	CXmlItem* TaskFromHandle(HTASKITEM hTask) const;
	
	double GetTaskTime(HTASKITEM hTask, const CString& sTimeItem) const;
	char GetTaskTimeUnits(HTASKITEM hTask, const CString& sUnitsItem) const;
	time_t GetTaskDate(HTASKITEM hTask, const CString& sDateItem, BOOL bIncTime) const;
	COleDateTime GetTaskDateOle(HTASKITEM hTask, const CString& sDateItem, BOOL bIncTime) const;
	unsigned char GetTaskUChar(HTASKITEM hTask, const CString& sUCharItem) const;
	unsigned long GetTaskULong(HTASKITEM hTask, const CString& sULongItem) const;
	int GetTaskInt(HTASKITEM hTask, const CString& sIntItem) const;
	CString GetTaskString(HTASKITEM hTask, const CString& sStringItem) const;
	double GetTaskDouble(HTASKITEM hTask, const CString& sDoubleItem) const;
	
	CString GetTaskAttribute(HTASKITEM hTask, const CString& sAttrib) const;

	bool SetTaskDate(HTASKITEM hTask, const CString& sDateItem, time_t tVal, BOOL bIncTime);
	bool SetTaskDate(HTASKITEM hTask, const CString& sDateItem, const COleDateTime& tVal, BOOL bIncTime, const CString& sDateStringItem = _T(""));
	bool SetTaskUChar(HTASKITEM hTask, const CString& sUCharItem, unsigned char cVal);
	bool SetTaskULong(HTASKITEM hTask, const CString& sULongItem, unsigned long lVal);
	bool SetTaskInt(HTASKITEM hTask, const CString& sIntItem, int iVal);
	bool SetTaskString(HTASKITEM hTask, const CString& sStringItem, const CString& sVal, XI_TYPE nType = XIT_ATTRIB);
	bool SetTaskDouble(HTASKITEM hTask, const CString& sDoubleItem, double dVal);
	bool SetTaskTime(HTASKITEM hTask, const CString& sTimeItem, double dTime,
					 const CString& sUnitsItem, TCHAR cUnits);

	// for handling arrays at *task* level
	bool AddTaskArrayItem(HTASKITEM hTask, const CString& sNumItemTag, 
						  const CString& sItemTag, const CString& sItem);
	CString GetTaskArrayItem(HTASKITEM hTask, const CString& sNumItemTag, 
				  				 const CString& sItemTag, int nIndex) const;
	BOOL SetTaskArray(HTASKITEM hTask, const CString& sNumItemTag, 
				  	 const CString& sItemTag, const CStringArray& aItems);
	int GetTaskArray(HTASKITEM hTask, const CString& sNumItemTag, 
				  	 const CString& sItemTag, CStringArray& aItems) const;
	bool DeleteTaskArray(HTASKITEM hTask, const CString& sNumItemTag, 
						 const CString& sItemTag);

	// for handling arrays at *tasklist* level
	BOOL SetArray(const CString& sItemTag, const CStringArray& aItems);
	int GetArray(const CString& sItemTag, CStringArray& aItems) const;

	virtual CXmlItem* NewItem(const CString& sName = _T(""));

	// helper
	static BOOL CopyTask(const ITaskList* pSrcTasks, HTASKITEM hSrcTask, ITaskList* pDestTasks, HTASKITEM hDestParent);

	static CString GetWebColor(COLORREF color);
};

#endif // !defined(AFX_TASKFILE_H__BA5D71E7_2770_45FD_A693_A2344B589DF4__INCLUDED_)
