// MenuEx.cpp: implementation of the CEnMenu class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "EnMenu.h"
#include "Themed.h"
#include "osversion.h"
#include "itranstext.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#ifndef HBMMENU_MBAR_CLOSE
#	define HBMMENU_CALLBACK            ((HBITMAP) -1)
#	define HBMMENU_SYSTEM              ((HBITMAP)  1)
#	define HBMMENU_MBAR_RESTORE        ((HBITMAP)  2)
#	define HBMMENU_MBAR_MINIMIZE       ((HBITMAP)  3)
#	define HBMMENU_MBAR_CLOSE          ((HBITMAP)  5)
#	define HBMMENU_MBAR_CLOSE_D        ((HBITMAP)  6)
#	define HBMMENU_MBAR_MINIMIZE_D     ((HBITMAP)  7)
#	define HBMMENU_POPUP_CLOSE         ((HBITMAP)  8)
#	define HBMMENU_POPUP_RESTORE       ((HBITMAP)  9)
#	define HBMMENU_POPUP_MAXIMIZE      ((HBITMAP) 10)
#	define HBMMENU_POPUP_MINIMIZE      ((HBITMAP) 11)
#endif

#ifndef ODS_HOTLIGHT
#	define ODS_HOTLIGHT        0x0040
#	define ODS_INACTIVE        0x0080
#endif

#define BTNBORDER 0
#define FUDGE 8

//////////////////////////////////////////////////////////////////////

ITransText* CEnMenu::s_pTT = NULL;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEnMenu::CEnMenu()
{

}

CEnMenu::~CEnMenu()
{
}

BOOL CEnMenu::AddMDIButton(MENUEX_BTN nBtn, UINT nCmdID, BOOL bRightJustify)
{
	ASSERT (GetSafeHmenu());

	if (!GetSafeHmenu())
		return FALSE;

	HBITMAP hbm = NULL;

	if (!IsThemed() || COSVersion() > OSV_XP)
	{
		switch (nBtn)
		{
		case MEB_MINIMIZE:
			hbm = HBMMENU_MBAR_MINIMIZE;
			break;
			
		case MEB_RESTORE:
			hbm = HBMMENU_MBAR_RESTORE;
			break;
			
		case MEB_CLOSE:
			hbm = HBMMENU_MBAR_CLOSE;
			break;
			
		default:
			return FALSE;
		}
	}
	
	UINT nFlags = (bRightJustify ? MFT_RIGHTJUSTIFY : 0);
	
	if (!IsThemed() || COSVersion() > OSV_XP)
		nFlags |= MFT_BITMAP;
	else
		nFlags |= MFT_OWNERDRAW;
		
	if (InsertMenu((UINT)-1, nFlags, nCmdID, CBitmap::FromHandle(hbm)))
	{
		m_mapCmd2ID[nCmdID] = nBtn;
		return TRUE;
	}

	// else
	return FALSE;
}

BOOL CEnMenu::DeleteMDIMenu(UINT nCmdID)
{
	// CMenu::DeleteMenu won't work on bitmap buttons directly
	// so we must traverse all menu items looking for nCmdID
	int nItem = GetMenuItemCount();

	while (nItem--)
	{
		UINT nMenuCmdID = GetMenuItemID(nItem);

		if (nCmdID == nMenuCmdID)
		{
			DeleteMenu(nItem, MF_BYPOSITION);
			m_mapCmd2ID.RemoveKey(nCmdID);

			return TRUE;
		}
	}

	return FALSE;
}

BOOL CEnMenu::IsThemed()
{
	return CThemed().IsNonClientThemed();
}

BOOL CEnMenu::DrawMDIButton(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	if (!IsThemed())
		return FALSE;

	// draw the button
	CRect rect(lpDrawItemStruct->rcItem);
	CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);

	int nBtn = -1;
	m_mapCmd2ID.Lookup(lpDrawItemStruct->itemID, nBtn);

	CThemed th;
		
	if (!th.Open(AfxGetMainWnd(), _T("WINDOW")))
		return FALSE;

	int nThPart = 0, nThState = 0;

	switch (nBtn)
	{
	case MEB_MINIMIZE:
		nThPart = WP_MDIMINBUTTON;
		break;

	case MEB_RESTORE:
		nThPart = WP_MDIRESTOREBUTTON;
		break;

	case MEB_CLOSE:
		nThPart = WP_MDICLOSEBUTTON;
		break;
	}
		
	th.DrawBackground(pDC, nThPart, nThState, rect, NULL);

	return TRUE;
}

BOOL CEnMenu::MeasureMDIButton(LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{
	lpMeasureItemStruct->itemHeight = 4;
	lpMeasureItemStruct->itemWidth = 4;

	return TRUE;
}

void CEnMenu::SetBackgroundColor(COLORREF color)
{
	ASSERT(GetSafeHmenu());

	// menu background color
	m_brBkgnd.DeleteObject();
	m_brBkgnd.CreateSolidBrush(color);
	
	MENUINFO MenuInfo = {0};
	MenuInfo.cbSize = sizeof(MenuInfo);
	MenuInfo.hbrBack = m_brBkgnd; 
	MenuInfo.fMask = MIM_BACKGROUND;
	
	::SetMenuInfo(GetSafeHmenu(), &MenuInfo);
}

BOOL CEnMenu::LoadMenu(UINT nMenuResID, HWND hWndRef, BOOL bTranslateAll)
{
	if (CMenu::LoadMenu(nMenuResID))
	{
		if (s_pTT)
			s_pTT->TranslateMenu(*this, hWndRef, bTranslateAll);

		return TRUE;
	}

	// else
	return FALSE;
}

void CEnMenu::SetLocalizer(ITransText* pTT)
{
	s_pTT = pTT;
}
