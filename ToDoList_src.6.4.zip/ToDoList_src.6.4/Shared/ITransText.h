// ITransText.h: interface for the ITransText class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ITRANSTEXT_H__B685332D_C395_46B1_8DDB_ED8196B3A63F__INCLUDED_)
#define AFX_ITRANSTEXT_H__B685332D_C395_46B1_8DDB_ED8196B3A63F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// function to be exported from dll to create instance of interface
#ifdef _EXPORTING // declare this in project settings for dll _only_
#	define DLL_DECLSPEC __declspec(dllexport)
#else
#	define DLL_DECLSPEC __declspec(dllimport)
#endif 

const UINT ITRANSTEXT_VERSION = 0x0000;

class ITransText;

typedef ITransText* (*PFNCREATE)(LPCTSTR, BOOL); // function prototype
extern "C" DLL_DECLSPEC ITransText* CreateTransTextInterface(LPCTSTR szDictPath, BOOL bAddToDictionary); // single exported function

typedef int (*PFNGETVERSION)(); // function prototype
extern "C" DLL_DECLSPEC int GetInterfaceVersion();

static ITransText* CreateTransTextInterface(LPCTSTR szDllPath, LPCTSTR szTransFile = NULL, BOOL bAddToDictionary = TRUE)
{
    ITransText* pInterface = NULL;
    HMODULE hDll = LoadLibrary(szDllPath);
	
    if (hDll)
    {
        PFNCREATE pCreate = (PFNCREATE)GetProcAddress(hDll, "CreateTransTextInterface");
		
        if (pCreate)
		{
			if (ITRANSTEXT_VERSION == 0)
				pInterface = pCreate(szTransFile, bAddToDictionary);
			else
			{
				// check version
				PFNGETVERSION pVersion = (PFNGETVERSION)GetProcAddress(hDll, "GetInterfaceVersion");

				if ((pVersion && pVersion() >= ITRANSTEXT_VERSION))
					pInterface = pCreate(szTransFile, bAddToDictionary);
			}
		}
    }
	
    return pInterface;
}

static BOOL IsTransTextDll(LPCTSTR szDllPath)
{
    HMODULE hDll = LoadLibrary(szDllPath);
	
    if (hDll)
    {
        PFNCREATE pCreate = (PFNCREATE)GetProcAddress(hDll, "CreateTransTextInterface");
		FreeLibrary(hDll);

		return (NULL != pCreate);
	}

	return FALSE;
}

class ITransText
{
public:
	virtual BOOL Initialize(LPCTSTR szDictPath, BOOL bAddToDictionary = FALSE) = 0;
    virtual void Release() = 0; // releases the interface
	
	virtual LPCTSTR GetDictionaryFile() const = 0;
	virtual void EnableAddToDictionary(BOOL bEnable = TRUE) = 0;

	virtual BOOL TranslateText(LPCTSTR szText, LPTSTR& szTranslated) = 0;
	virtual BOOL TranslateText(LPCTSTR szText, HWND hWndRef, LPTSTR& szTranslated) = 0;
	virtual BOOL TranslateMenu(HMENU hMenu, HWND hWndRef, BOOL bRecursive = TRUE) = 0;
	virtual void UpdateMenu(HWND hWnd) = 0;

	virtual void PreventTranslation(HWND hWnd) = 0;
	virtual void PreventTranslation(HMENU hMenu) = 0;
	virtual void PreventTranslation(UINT nMenuID) = 0;
	virtual void IgnoreString(LPCTSTR szText) = 0;
};


#endif // !defined(AFX_ITRANSTEXT_H__B685332D_C395_46B1_8DDB_ED8196B3A63F__INCLUDED_)
