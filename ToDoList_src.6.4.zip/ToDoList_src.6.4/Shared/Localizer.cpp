// Localizer.cpp: implementation of the CLocalizer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Localizer.h"
#include "ITransText.h"
#include "FileMisc.h"
#include "enstring.h"
#include "enmenu.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#define NEEDSINIT ((ITransText*)-1)

ITransText* CLocalizer::s_pTransText = NEEDSINIT; // we only initialize once even if it fails

BOOL CLocalizer::Initialize(LPCTSTR szDictFile, BOOL bAddToDictionary)
{
	if (s_pTransText == NEEDSINIT)
	{
		// Load TransText module
		CString sTTDll = FileMisc::GetAppFolder() + _T("\\TransText.dll");
		
		if (IsTransTextDll(sTTDll) && (bAddToDictionary || FileMisc::FileExists(szDictFile)))
		{
			s_pTransText = CreateTransTextInterface(sTTDll, szDictFile, bAddToDictionary);
			ASSERT(s_pTransText);

			CEnString::SetLocalizer(s_pTransText);
			CEnMenu::SetLocalizer(s_pTransText);
		}
		else
			s_pTransText = NULL;
	}

	return (s_pTransText != NEEDSINIT);
}

void CLocalizer::Release()
{
	if (s_pTransText && (s_pTransText != NEEDSINIT))
		s_pTransText->Release();

	s_pTransText = NEEDSINIT;
}

void CLocalizer::EnableAddToDictionary(BOOL bEnable)
{
	if (s_pTransText && (s_pTransText != NEEDSINIT))
		s_pTransText->EnableAddToDictionary(bEnable);
}

BOOL CLocalizer::TranslateText(CString& sText, HWND hWndRef)
{
	VERIFY (Initialize());

	if (s_pTransText)
	{
		LPTSTR szTranslated = NULL;
		
		if (s_pTransText->TranslateText(sText, hWndRef, szTranslated))
		{
			sText = szTranslated;
			delete [] szTranslated;

			return TRUE;
		}
	}

	return FALSE;
}

BOOL CLocalizer::TranslateMenu(HMENU hMenu, HWND hWndRef, BOOL bRecursive)
{
	VERIFY (Initialize());

	if (s_pTransText)
		return s_pTransText->TranslateMenu(hMenu, hWndRef, bRecursive);

	return FALSE;
}

void CLocalizer::UpdateMenu(HWND hWnd)
{
	VERIFY (Initialize());

	if (s_pTransText)
		s_pTransText->UpdateMenu(hWnd);
}

void CLocalizer::PreventTranslation(HWND hWnd)
{
	VERIFY (Initialize());

	if (s_pTransText)
		s_pTransText->PreventTranslation(hWnd);
}

void CLocalizer::PreventTranslation(const CWnd& hWnd)
{
	VERIFY (Initialize());

	if (s_pTransText)
		s_pTransText->PreventTranslation(hWnd.GetSafeHwnd());
}

void CLocalizer::PreventTranslation(HMENU hMenu)
{
	VERIFY (Initialize());

	if (s_pTransText)
		s_pTransText->PreventTranslation(hMenu);
}

void CLocalizer::PreventTranslation(UINT nMenuID)
{
	VERIFY (Initialize());

	if (s_pTransText)
		s_pTransText->PreventTranslation(nMenuID);
}

void CLocalizer::IgnoreString(const CString& sText)
{
	VERIFY (Initialize());

	if (s_pTransText)
		s_pTransText->IgnoreString(sText);
}
