// Localizer.h: interface for the CLocalizer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOCALIZER_H__6AE74534_3914_4C84_97D1_25C6FF75B9FE__INCLUDED_)
#define AFX_LOCALIZER_H__6AE74534_3914_4C84_97D1_25C6FF75B9FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ITransText;

class CLocalizer  
{
public:
	static BOOL Initialize(LPCTSTR szTransFile = _T(""), BOOL bAddToDictionary = FALSE);
	static void Release();

	static void EnableAddToDictionary(BOOL bEnable = TRUE);

	static BOOL TranslateText(CString& sText, HWND hWndRef = NULL);
	static BOOL TranslateMenu(HMENU hMenu, HWND hWndRef = NULL, BOOL bRecursive = TRUE);
	static void UpdateMenu(HWND hWnd);
	static void UpdateMenu(HMENU hMenu);
	static void PreventTranslation(const CWnd& hWnd);
	static void PreventTranslation(HWND hWnd);
	static void PreventTranslation(HMENU hMenu);
	static void PreventTranslation(UINT nMenuID);
	static void IgnoreString(const CString& sText);

protected:
	CLocalizer() {}

protected:
	static ITransText* s_pTransText;

};

#endif // !defined(AFX_LOCALIZER_H__6AE74534_3914_4C84_97D1_25C6FF75B9FE__INCLUDED_)
