// TransTextMgr.h: interface for the CTransTextMgr class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRANSTEXTMGR_H__1F1C6D57_D2C6_4C06_9E7C_1E0C54B65D30__INCLUDED_)
#define AFX_TRANSTEXTMGR_H__1F1C6D57_D2C6_4C06_9E7C_1E0C54B65D30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "hookwndmgr.h"

#include <afxtempl.h>

class CXmlItem;
class CTransWnd;

struct DICTITEM
{
	DICTITEM() {}
	DICTITEM(const DICTITEM& di);
	DICTITEM(const CXmlItem* pXI);
	DICTITEM(const CString& sText);

	DICTITEM& operator= (const DICTITEM& di);

	BOOL Translate(CString& sText);
	BOOL Translate(CString& sText, HWND hWndRef, LPCTSTR szClassID = NULL);
	BOOL Translate(CString& sText, HMENU hMenu, int nMenuID);
	BOOL IsTranslated() const;

	BOOL ToXml(CXmlItem* pXI) const;
	BOOL FromXml(const CXmlItem* pXI);

	BOOL ToCsv(CStringArray& aTransLines, CStringArray& aNeedTransLines) const;
	BOOL FromCsv(const CStringArray& aLines, int& nLine);

	const CString& GetTextIn() const { return m_sTextIn; }
	const CString& GetTextOut() const { return m_sTextOut; }
// 	void SetTextIn(const CString& sText) { m_sTextIn = sText; }
// 	void SetTextOut(const CString& sText) { m_sTextOut = sText; }

	static void EnableAddToDictionary(BOOL bEnable = TRUE);

protected:
	CString m_sTextIn;
	CString m_sTextOut;
	CString m_sClassID;

	static BOOL s_bAddToDictionary;

	// map alternatives by path
	CMapStringToString m_mapAlternatives;

//	static void ToCsv(CString& sLine, const DICTITEM& di);
	static void ToXml(CXmlItem* pXI, const DICTITEM& di);
	static int GetDlgCtrlID(HWND hWnd);
	static BOOL FromCsv(const CString& sLine, DICTITEM& di);

#ifdef _DEBUG
	static void FixupFormatString(CString& sFormat);
#endif

	BOOL Translate(CString& sText, const CString& sClassID);
};

class CTransTextMgr : protected CHookWndMgr<CTransTextMgr>
{
	friend class CHookMgr<CTransTextMgr>; // so CHookMgr can access protected constructor
	friend class CHookWndMgr<CTransTextMgr>; // so CHookMgr can access protected constructor
	friend DICTITEM;
	friend CTransWnd;

public:
	virtual ~CTransTextMgr();

	static BOOL Initialize(LPCTSTR szDictPath = _T(""), BOOL bAddToDictionary = TRUE);
	static void Release();

	static LPCTSTR GetDictionaryFile() { return GetInstance().GetDictionaryFile(); }
	static void EnableAddToDictionary(BOOL bEnable);
	
	static BOOL TranslateText(CString& sText, HWND hWndRef, LPCTSTR szClassID = NULL);
	static BOOL TranslateMenu(HMENU hMenu, HWND hWndRef = NULL, BOOL bRecursive = FALSE);
	static void UpdateMenu(HWND hWnd);
	static void UpdateMenu(HMENU hMenu);
	
	static void PreventTranslation(HWND hWnd);
	static void PreventTranslation(HMENU hMenu);
	static void PreventTranslation(UINT nMenuID);
	static void IgnoreString(const CString& sText);

protected:
	CString m_sDictFile;
	BOOL m_bAddToDictionary;
	CMap<CString, LPCTSTR, DICTITEM*, DICTITEM*&> m_mapDictionary;
	CMap<HWND, HWND&, void*, void*&> m_mapWndIgnore;
	CMap<UINT, UINT&, void*, void*&> m_mapMenuIgnore;
	CMapStringToPtr m_mapStringIgnore;

protected:
	CTransTextMgr();

	BOOL InitHooks(LPCTSTR szDictPath, BOOL bAddToDictionary);
	void ReleaseHooks();

	virtual CSubclassWnd* NewHookWnd(HWND hWnd, const CString& sClass, DWORD dwStyle) const;
	virtual BOOL WantHookWnd(HWND hWnd, UINT nMsg, WPARAM wp, LPARAM lp) const;
	virtual void PostHookWnd(HWND hWnd);
	virtual BOOL RemoveHookWnd(HWND hWnd);
	virtual BOOL OnCallWndProc(const MSG& msg);

	BOOL HandleInitMenuPopup(HWND hWnd, UINT nMsg, WPARAM wp, LPARAM lp);
	BOOL HandleTootipNeedText(HWND hWnd, UINT nMsg, WPARAM wp, LPARAM lp);
	BOOL HandleSetText(HWND hWnd, UINT nMsg, WPARAM wp, LPARAM lp);

	BOOL SaveDictionary(LPCTSTR szAltPath = NULL) const;
	BOOL SaveXmlDictionary(LPCTSTR szDictPath) const;
	BOOL SaveCsvDictionary(LPCTSTR szDictPath) const;
	void DeleteDictionary();
	BOOL LoadDictionary(LPCTSTR szDictPath);
	BOOL LoadXmlDictionary(LPCTSTR szDictPath);
	BOOL LoadCsvDictionary(LPCTSTR szDictPath);
	void LoadItem(const CXmlItem* pXI);
	BOOL LoadDictionaryItem(const CXmlItem* pXIDict);
	BOOL WantTranslation(HWND hWnd, UINT nMsg = 0) const;
	BOOL WantTranslation(UINT nMenuID) const;

	DICTITEM* GetDictionary(const CString& sText);
	BOOL WantIgnore(const CString& sText);
	void AddToFile(const DICTITEM* pDI, CXmlItem* pXI);

	// helpers
	static CString GetFriendlyClass(const CString& sClass, HWND hWndRef = NULL);
	static CString GetClassIDPath(HWND hWnd, BOOL bFriendly);
	static CString GetClassIDPath(HMENU hMenu, int nMenuID, HWND hWndRef, BOOL bFriendly);
	static CString GetClassIDName(HWND hWnd, BOOL bFriendly);
	static CString GetClassIDName(HMENU hMenu, int nMenuID, BOOL bFriendly);
	static CString FormatPath(const CString& sItemPath, const CString& sClassID);

	static BOOL IsDlgOrPopup(HWND hWnd);
	static BOOL IsOwnerDraw(int nCmdID, HMENU hMenu);
	static CString& EncodeChars(CString& sText);
	static CString& DecodeChars(CString& sText);

	static int CALLBACK CompareProc(const CString& sFirst, const CString& sSecond);

};

#endif // !defined(AFX_TRANSTEXTMGR_H__1F1C6D57_D2C6_4C06_9E7C_1E0C54B65D30__INCLUDED_)
