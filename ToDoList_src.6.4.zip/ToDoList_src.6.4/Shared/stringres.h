#if !defined(AFX_STRING_RESOURCES_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_)
#define AFX_STRING_RESOURCES_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// stringres.h : header file
//

static LPCTSTR BTN_OK = _T("OK");
static LPCTSTR BTN_CANCEL = _T("Cancel");
static LPCTSTR BTN_CLOSE = _T("Close");

static LPCTSTR ABOUT_TITLE = _T("About");

static LPCTSTR MISC_ELLIPSIS = _T("...");

static LPCTSTR FILTER_ALLFILES = _T("All Files (*.*)|*.*||");

static LPCTSTR SPELLCHECK_ACTIVEDICT = _T("Ac&tive Dictionary:");
static LPCTSTR SPELLCHECK_BROWSE = _T("Bro&wse");
static LPCTSTR SPELLCHECK_BROWSE_TITLE = _T("Select Dictionary");
static LPCTSTR SPELLCHECK_DOWNLOADMORE = _T("Download More Dictionaries");
static LPCTSTR SPELLCHECK_CHECKING = _T("C&hecking Text:");
static LPCTSTR SPELLCHECK_RESTART = _T("R&estart");
static LPCTSTR SPELLCHECK_BTN_REPLACE = _T("&Replace");
static LPCTSTR SPELLCHECK_WITH = _T("&With:");
static LPCTSTR SPELLCHECK_REPLACE = _T("Replace:");
static LPCTSTR SPELLCHECK_NEXTWORD = _T("&Next Word");
static LPCTSTR SPELLCHECK_SETUP_MSG = _T("Before you can spell check for the first time you need \nto specify the location of the Spell Checker.");
static LPCTSTR SPELLCHECK_TITLE = _T("Spell Checker");
static LPCTSTR SPELLCHECK_DICT_FILTER = _T("Dictionaries (*.dic)|*.dic||");
static LPCTSTR SPELLCHECK_ENGINE_FILTER = _T("SpellChecker Engines|*.dll||");
static LPCTSTR SPELLCHECK_ENGINE_TITLE = _T("Locate Spell Check Engine");

static LPCTSTR TIME_YEARS = _T("Y(ears)");
static LPCTSTR TIME_MONTHS = _T("M(onths)");
static LPCTSTR TIME_WEEKS = _T("W(eeks)");
static LPCTSTR TIME_DAYS = _T("D(ays)");
static LPCTSTR TIME_HOURS = _T("H(ours)");
static LPCTSTR TIME_MINS = _T("m(inutes)");
static const TCHAR	  TIME_YEAR_ABBREV = 'Y';
static const TCHAR    TIME_MONTH_ABBREV = 'M';
static const TCHAR    TIME_WEEK_ABBREV = 'W';
static const TCHAR    TIME_DAY_ABBREV = 'D';
static const TCHAR    TIME_HOUR_ABBREV = 'H';
static const TCHAR    TIME_MIN_ABBREV = 'm';
static LPCTSTR TIME_UNITS = _T("Time Units");

static LPCTSTR FILEEDIT_ASSOCAPPFAILURE = _T("The application associated with '%s'\ncould not be launched.\n\nPlease check the file associations in Explorer before trying again.");
static LPCTSTR FILEEDIT_FILEOPENFAILED = _T("'%s' could not be opened (%d).\n\nPlease check that the file exists and that you have the appropriate access rights before trying again.");
static LPCTSTR FILEEDIT_FILENOTFOUND = _T("'%s' could not be found.");
static LPCTSTR FILEEDIT_BROWSE = _T("Browse");
static LPCTSTR FILEEDIT_BROWSE_TITLE = _T("Select File");
static LPCTSTR FILEEDIT_SELECTFOLDER = _T("Select Folder");
static LPCTSTR FILEEDIT_VIEW = _T("View");
static LPCTSTR FILEEDIT_VIEWFOLDER = _T("View Folder");

static LPCTSTR PASSWORD_ENTERPWD = _T("Enter Password:");
static LPCTSTR PASSWORD_CONFIRMPWD = _T("Confirm Password:");
static LPCTSTR PASSWORD_TITLE = _T("Password Required");
static LPCTSTR PASSWORD_CONFIRMFAILED = _T("Unfortunately the confirmation did not match the password.\n\nPlease try again.");
static LPCTSTR PASSWORD_CONFIRMFAILED_TITLE = _T("Password Confirmation Incorrect");

static LPCTSTR ENCRYPT_NOTINSTALLED = _T("The file '%s' is encrypted, but you do not have the necessary components installed to decrypt it.");
static LPCTSTR ENCRYPT_ENTERPWD = _T("The file '%s' is encrypted.\n\nPlease enter your password below.");
static LPCTSTR ENCRYPT_DECRYPTFAILED = _T("The file '%s' could not be decrypted using the supplied password.\n\nWound you like to try again?");

// static LPCTSTR  = _T("");
// static LPCTSTR  = _T("");
// static LPCTSTR  = _T("");
// static LPCTSTR  = _T("");
// static LPCTSTR  = _T("");


#endif // AFX_SHARED_STRING_RESOURCES_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_