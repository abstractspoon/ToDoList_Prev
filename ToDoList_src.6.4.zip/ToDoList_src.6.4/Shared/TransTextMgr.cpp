// TransTextMgr.cpp: implementation of the CTransTextMgr class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TransTextMgr.h"
#include "subclass.h"
#include "xmlfile.h"
#include "winclasses.h"
#include "filemisc.h"
#include "misc.h"
#include "enstring.h"

#include "..\3rdparty\StdioFileEx.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////

#ifdef _DEBUG
static UINT nDICount = 0;
#endif

static LPCTSTR TRANSTEXT_HEADER = _T("TRANSTEXT");
static LPCTSTR LANGUAGE = _T("LANGUAGE");
static LPCTSTR TEXTOUT = _T("TEXTOUT");
static LPCTSTR TEXTIN = _T("TEXTIN");
static LPCTSTR ALTERNATIVE = _T("ALTERNATIVE");
static LPCTSTR CLASSID = _T("CLASSID");
static LPCTSTR TRANSLATED = _T("TRANSLATED");
static LPCTSTR NEED_TRANSLATION = _T("NEED_TRANSLATION");
static LPCTSTR ITEM = _T("ITEM");
static LPCTSTR CSVCOLUMN_HEADER = _T("English Text\tTranslated Text\tItem Type");
// static LPCTSTR _T("");

#ifndef _countof
#define _countof(array) (sizeof(array)/sizeof(array[0]))
#endif

//////////////////////////////////////////////////////////////////////
// private helper class

enum
{
	TWS_HANDLENONE		= 0x00,

	TWS_HANDLESETTEXT	= 0x01,
	TWS_HANDLETOOLTIPS	= 0x02,
	TWS_HANDLEMENUPOPUP	= 0x04,

	// more here

	TWS_HANDLEALL		= 0xff,
	TWS_NOHANDLESETTEXT	= (TWS_HANDLEALL ^ TWS_HANDLESETTEXT),
};

class CTransWnd : public CSubclassWnd
{
public:
	static CTransWnd* NewTransWnd(const CString& sClass, DWORD dwStyle);

	CTransWnd(DWORD dwOptions = TWS_HANDLEALL);
	virtual ~CTransWnd();
	
	void UpdateMenu() { TranslateMenu(::GetMenu(GetHwnd()), FALSE); }
	void AllowTranslation(BOOL bAllow) { m_bAllowTranslate = bAllow; }
	void PostHookWindow();
	
protected:
	DWORD m_dwOptions;
	BOOL m_bInit;
	BOOL m_bAllowTranslate;

protected:
	virtual LRESULT WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp);
	virtual BOOL HookWindow(HWND hRealWnd, CSubclasser* pSubclasser);
	virtual void Initialize();
	
	BOOL TranslateText(CString& sText);
	void TranslateMenu(HMENU hMenu, BOOL bToplevelOnly);
	BOOL HasFlag(DWORD dwFlag) { return Misc::HasFlag(m_dwOptions, dwFlag); }
};

//////////////////////////////////////////////////////////////////////

class CTransComboBox : public CTransWnd
{
public:
	CTransComboBox() : CTransWnd(TWS_HANDLENONE) {}

protected:
	virtual void Initialize();
	virtual LRESULT WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp);
};

class CTransComboBoxEx : public CTransWnd
{
public:
	CTransComboBoxEx() : CTransWnd(TWS_HANDLENONE) {}

protected:
	virtual void Initialize();
	virtual LRESULT WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp);
};

class CTransListBox : public CTransWnd
{
public:
	CTransListBox(BOOL bCheckListBox = FALSE) : CTransWnd(TWS_HANDLENONE), m_bCheckLB(bCheckListBox) { }

protected:
	virtual void Initialize();
	virtual LRESULT WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp);

protected:
	BOOL m_bCheckLB;
};

class CTransTabCtrl : public CTransWnd
{
public:
	CTransTabCtrl() : CTransWnd(TWS_HANDLENONE) {}

protected:
	virtual void Initialize();
	virtual LRESULT WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp);
};

class CTransHeaderCtrl : public CTransWnd
{
public:
	CTransHeaderCtrl() : CTransWnd(TWS_HANDLENONE) {}

protected:
	virtual void Initialize();
	virtual LRESULT WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp);
};

class CTransListCtrl : public CTransWnd
{
public:
	CTransListCtrl() : CTransWnd(TWS_HANDLENONE) {}

protected:
	virtual void Initialize();
	virtual LRESULT WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp);
};

class CTransTooltips : public CTransWnd
{
public:
	CTransTooltips() : CTransWnd(TWS_HANDLENONE) {}

protected:
	virtual void Initialize();
	virtual LRESULT WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp);
};

class CTransToolBar : public CTransWnd
{
public:
	CTransToolBar() : CTransWnd(TWS_HANDLETOOLTIPS) {}

protected:
	virtual void Initialize();
	virtual LRESULT WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp);
};

class CTransStatusBar : public CTransWnd
{
public:
	CTransStatusBar() : CTransWnd(TWS_HANDLETOOLTIPS) {}

protected:
	virtual void Initialize();
	virtual LRESULT WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp);
};

//////////////////////////////////////////////////////////////////////
// Construction/Destruction

BOOL DICTITEM::s_bAddToDictionary = FALSE;

void DICTITEM::EnableAddToDictionary(BOOL bEnable)
{
	s_bAddToDictionary = bEnable;
}

// --------------------------------

DICTITEM::DICTITEM(const DICTITEM& di)
{
	*this = di;

#ifdef _DEBUG
	nDICount++;
#endif
}

DICTITEM::DICTITEM(const CXmlItem* pXI)
{
	FromXml(pXI);

#ifdef _DEBUG
	nDICount++;
#endif
}

DICTITEM::DICTITEM(const CString& sText) : m_sTextIn(sText)
{
#ifdef _DEBUG
	nDICount++;
#endif
}

DICTITEM& DICTITEM::operator= (const DICTITEM& di)
{
	m_sTextIn = di.m_sTextIn;
	m_sTextOut = di.m_sTextOut;
	m_sClassID = di.m_sClassID;

	m_mapAlternatives.RemoveAll();

	if (di.m_mapAlternatives.GetCount())
	{
		POSITION pos = di.m_mapAlternatives.GetStartPosition();

		while (pos)
		{
			CString sKey, sText;
			di.m_mapAlternatives.GetNextAssoc(pos, sKey, sText);

			m_mapAlternatives[sKey] = sText;
		}
	}

	return *this;
}

// --------------------------------

BOOL DICTITEM::IsTranslated() const 
{ 
	return !m_sTextOut.IsEmpty(); 
}

int DICTITEM::GetDlgCtrlID(HWND hWnd)
{
	int nCtrlID = ::GetDlgCtrlID(hWnd);

	return max(nCtrlID, -1);
}

void DICTITEM::ToXml(CXmlItem* pXI, const DICTITEM& di) 
{
	ASSERT(!di.m_sTextIn.IsEmpty());
	pXI->SetItemValue(TEXTIN, di.m_sTextIn);
	
#ifdef _DEBUG
	if (di.m_sTextOut.IsEmpty())
	{
		CString sTextOutDebug(di.m_sTextIn);
		sTextOutDebug.MakeUpper();
		FixupFormatString(sTextOutDebug);

		pXI->SetItemValue(TEXTOUT, sTextOutDebug);
	}
	else
#endif
	pXI->SetItemValue(TEXTOUT, di.m_sTextOut);
	pXI->SetItemValue(CLASSID, di.m_sClassID);
}

#ifdef _DEBUG
void DICTITEM::FixupFormatString(CString& sFormat)
{
	// check that the char following the % is valid
	static const CString FMTCHARS = _T("cCdiouxXeEfgGnpsS.*012346789 \t\n%");
	int nFind = sFormat.Find('%', 0);

	if (nFind != -1)
	{
		int nLen = sFormat.GetLength();

		while (nFind != -1 && ((nFind + 1) < nLen))
		{
			TCHAR cNext = sFormat[nFind + 1];
			
			if (FMTCHARS.Find(cNext) == -1) // invalid char
			{
				// try flipping the char
				if (_istlower(cNext))
					cNext = _totupper(cNext);
				else
					cNext = _totlower(cNext);

				sFormat.SetAt(nFind + 1, cNext);
				ASSERT(FMTCHARS.Find(cNext) != -1);
			}

			// next
			nFind = sFormat.Find('%', nFind + 1);
		}
	}
}
#endif

BOOL DICTITEM::ToXml(CXmlItem* pXI) const
{
	if (pXI && pXI->NameIs(ITEM))
	{
		ToXml(pXI, *this);
		
		// alternatives
		if (m_mapAlternatives.GetCount())
		{
			CString sClassID, sAlternative;
			POSITION pos = m_mapAlternatives.GetStartPosition();

			while (pos)
			{
				m_mapAlternatives.GetNextAssoc(pos, sClassID, sAlternative);
				ASSERT (!sClassID.IsEmpty());

				if (!sClassID.IsEmpty())
				{
					CXmlItem* pXISub = pXI->AddItem(ALTERNATIVE);

					pXISub->SetItemValue(CLASSID, sClassID);
					pXISub->SetItemValue(TEXTOUT, sAlternative);
				}
			}
		}

		return TRUE;
	}

	return FALSE;
}

BOOL DICTITEM::FromXml(const CXmlItem* pXI)
{
	if (pXI && pXI->NameIs(ITEM))
	{
		m_sTextIn = pXI->GetItemValue(TEXTIN);
		m_sTextOut = pXI->GetItemValue(TEXTOUT);
		m_sClassID = pXI->GetItemValue(CLASSID);

		// mark text out as being not-translatable
		// else the translated text can itself be translated!
		if (!m_sTextOut.IsEmpty())
			CTransTextMgr::IgnoreString(m_sTextOut);

		//  alternatives
		const CXmlItem* pXISub = pXI->GetItem(ALTERNATIVE);

		while (pXISub)
		{
			CString sClassID = pXISub->GetItemValue(CLASSID);
			CString sAlternative = pXISub->GetItemValue(TEXTOUT);

			if (!sClassID.IsEmpty())
			{
				m_mapAlternatives[sClassID] = sAlternative;

				// mark text out as being not-translatable
				// else the translated text can itself be translated!
				if (!sAlternative.IsEmpty())
					CTransTextMgr::IgnoreString(sAlternative);
			}

			// next
			pXISub = pXISub->GetSibling();
		}

		return TRUE;
	}

	return FALSE;
}

BOOL DICTITEM::ToCsv(CStringArray& aTransLines, CStringArray& aNeedTransLines) const
{
	aTransLines.RemoveAll();
	aNeedTransLines.RemoveAll();

	if (!m_sTextIn.IsEmpty())
	{
		// replace certain chars in text else they'll trip up the dictionary when it's read back in
		CString sTextIn(m_sTextIn), sTextOut(m_sTextOut);

		CTransTextMgr::EncodeChars(sTextIn);
		CTransTextMgr::EncodeChars(sTextOut);
			
		CString sLine;
		sLine.Format(_T("\"%s\"\t\"%s\"\t\"%s\""), sTextIn, sTextOut, m_sClassID);

		if (m_sTextOut.IsEmpty())
			aNeedTransLines.Add(sLine);
		else
			aTransLines.Add(sLine);

		// add alternatives
		CString sAltTextOut, sAltClassID;
		POSITION pos = m_mapAlternatives.GetStartPosition();

		while (pos)
		{
			m_mapAlternatives.GetNextAssoc(pos, sAltClassID, sAltTextOut);

			if (!sAltClassID.IsEmpty())
			{
				CTransTextMgr::EncodeChars(sAltTextOut);

				sLine.Format(_T("\"%s\"\t\"%s\"\t\"%s\""), m_sTextIn, sAltTextOut, sAltClassID);

				if (sAltTextOut.IsEmpty())
					aNeedTransLines.Add(sLine);
				else
					aTransLines.Add(sLine);
			}
		}
	}

	return (aTransLines.GetSize() > 0 || aNeedTransLines.GetSize() > 0);
}

BOOL DICTITEM::FromCsv(const CStringArray& aLines, int& nLine)
{
	const CString& sLine = aLines[nLine];

	if (sLine == NEED_TRANSLATION || sLine == TRANSLATED)
		return FALSE;

	if (FromCsv(sLine, *this))
	{
		// mark text out as being not-translatable
		// else the translated text can itself be translated!
		if (!m_sTextOut.IsEmpty())
			CTransTextMgr::IgnoreString(m_sTextOut);

		// check for alternatives
		int nNextLine = nLine + 1;

		while (nNextLine < aLines.GetSize())
		{
			const CString& sNextLine = aLines[nNextLine];
			DICTITEM diAlt;

			if (FromCsv(sNextLine, diAlt) && diAlt.m_sTextIn == m_sTextIn)
			{
				ASSERT(!diAlt.m_sClassID.IsEmpty());

				if (!diAlt.m_sClassID.IsEmpty())
					m_mapAlternatives[diAlt.m_sClassID] = diAlt.m_sTextOut;

				// mark text out as being not-translatable
				// else the translated text can itself be translated!
				if (!diAlt.m_sTextOut.IsEmpty())
					CTransTextMgr::IgnoreString(diAlt.m_sTextOut);

				nLine++;
				nNextLine++;
			}
			else
				break;
		}

		return TRUE;
	}

	return FALSE;
}

// static helper
BOOL DICTITEM::FromCsv(const CString& sLine, DICTITEM& di)
{
	CStringArray aFields;
	int nNumFields = Misc::Split(sLine, aFields, TRUE, _T("\t"));

	switch (nNumFields)
	{
	case 3:
		di.m_sClassID = aFields[2];
		// fall thru

	case 2:
		di.m_sTextOut = aFields[1];
		CTransTextMgr::DecodeChars(di.m_sTextOut);
		// fall thru

	case 1:
		di.m_sTextIn = aFields[0];
		CTransTextMgr::DecodeChars(di.m_sTextIn);

		// ignore purely numeric text and symbols
		return (!Misc::IsNumber(di.m_sTextIn) && !Misc::IsSymbol(di.m_sTextIn));
	}

	// all else
	return FALSE;
}

BOOL DICTITEM::Translate(CString& sText)
{
	ASSERT (!sText.IsEmpty() && sText == m_sTextIn);

	if (m_sTextOut.IsEmpty())
	{
#ifdef _DEBUG
		//sText.MakeUpper();
		//FixupFormatString(sText);
		//return TRUE;
#endif
		return FALSE;
	}

	// else
	sText = m_sTextOut;

	return TRUE;
}

BOOL DICTITEM::Translate(CString& sText, HWND hWndRef, LPCTSTR szClassID)
{
	if (szClassID && *szClassID)
		return Translate(sText, szClassID);
	 
	// else
	return Translate(sText, CTransTextMgr::GetClassIDName(hWndRef, TRUE)); // TRUE ==  friendly name
}

BOOL DICTITEM::Translate(CString& sText, HMENU hMenu, int nMenuID)
{
	return Translate(sText, CTransTextMgr::GetClassIDName(hMenu, nMenuID, TRUE)); // TRUE ==  friendly name
}

BOOL DICTITEM::Translate(CString& sText, const CString& sClassID)
{
#ifdef _DEBUG
	// this will catch windows who have used CEnString
	// to load strings (causing the 'text' entry) and then
	// have also been translated automatically.
	// When we find them we either disable translation or
	// replace CenString with CString.
	if (m_sClassID == _T("text") && sClassID != _T("text"))
	{
		int breakpoint = 0;
	}
	else if (sClassID == _T("text"))
	{
		int breakpoint = 0;
	}
#endif

	// 1. check for an 'alternative' entry
	if (!sClassID.IsEmpty() && !m_mapAlternatives.IsEmpty())
	{
		CString sTextOut;

		if (m_mapAlternatives.Lookup(sClassID, sTextOut) && !sTextOut.IsEmpty())
		{
			sText = sTextOut;
			return TRUE;
		}
	}

	// 2. check root item
	if (sClassID.IsEmpty() || m_sClassID.IsEmpty() || sClassID == m_sClassID)
	{
		BOOL bTrans = Translate(sText);

		// if the root item has no class ID then use this one
		if (s_bAddToDictionary && m_sClassID.IsEmpty() && !sClassID.IsEmpty())
			m_sClassID = sClassID;

		return bTrans;
	}

	// 3. No translation so add as an alternative and use the root translation
	if (s_bAddToDictionary)
		m_mapAlternatives[sClassID] = _T("");

	return Translate(sText);
}

// ---------------------------------------------------------------------

CTransTextMgr::CTransTextMgr() : m_bAddToDictionary(TRUE)
{
}

CTransTextMgr::~CTransTextMgr()
{
	m_mapDictionary.RemoveAll();
}

BOOL CTransTextMgr::Initialize(LPCTSTR szDictPath, BOOL bAddToDictionary)
{
	return GetInstance().InitHooks(szDictPath, bAddToDictionary);
}

void CTransTextMgr::Release()
{
	GetInstance().SaveDictionary();
	GetInstance().ReleaseHooks();
}

BOOL CTransTextMgr::InitHooks(LPCTSTR szDictPath, BOOL bAddToDictionary)
{
	if (!LoadDictionary(szDictPath))
	{
		if (!bAddToDictionary)
			return FALSE;

		// else
		m_sDictFile = szDictPath;
	}

	m_bAddToDictionary = bAddToDictionary;
	DICTITEM::EnableAddToDictionary(bAddToDictionary);

	return CHookWndMgr<CTransTextMgr>::InitHooks();
}

void CTransTextMgr::EnableAddToDictionary(BOOL bEnable)
{
	// if enabling there must be a dictionary specified
	CTransTextMgr& ttm = GetInstance();

	if (!bEnable || !ttm.m_sDictFile.IsEmpty())
	{
		ttm.m_bAddToDictionary = bEnable;
		DICTITEM::EnableAddToDictionary(bEnable);
	}
}

BOOL CTransTextMgr::LoadDictionary(LPCTSTR szDictPath)
{
	DeleteDictionary();

	// load the DictFile
	if (LoadXmlDictionary(szDictPath) || LoadCsvDictionary(szDictPath))
	{
		m_sDictFile = szDictPath;
		return TRUE;
	}

	// else
	return FALSE;
}

BOOL CTransTextMgr::LoadXmlDictionary(LPCTSTR szDictPath)
{
	if (!FileMisc::HasExtension(szDictPath, _T("xml")))
		return FALSE;

	CXmlFile file(TRANSTEXT_HEADER);

	if (file.Load(szDictPath))
	{
		// process all top level items
		const CXmlItem* pXITrans = file.Root()->GetItem(TRANSLATED);

		if (pXITrans)
		{
			POSITION pos = pXITrans->GetFirstItemPos();
			
			while (pos)
			{	
				const CXmlItem* pXI = pXITrans->GetNextItem(pos);
				LoadItem(pXI);
			}
		}

		const CXmlItem* pXINeedTrans = file.Root()->GetItem(NEED_TRANSLATION);

		if (pXINeedTrans)
		{
			POSITION pos = pXINeedTrans->GetFirstItemPos();
			
			while (pos)
			{	
				const CXmlItem* pXI = pXINeedTrans->GetNextItem(pos);
				LoadItem(pXI);
			}
		}

		return TRUE;
	}

	return FALSE;
}

BOOL CTransTextMgr::LoadCsvDictionary(LPCTSTR szDictPath)
{
	if (!FileMisc::HasExtension(szDictPath, _T("csv")) &&
		!FileMisc::HasExtension(szDictPath, _T("txt")))
		return FALSE;

	CString sCsvContents;
	CStdioFileEx file;

	if (file.Open(szDictPath, CFile::modeRead) && file.ReadFile(sCsvContents) && !sCsvContents.IsEmpty())
	{
		file.Close();
		CStringArray aLines;

		if (Misc::Split(sCsvContents, aLines, FALSE, _T("\n")))
		{
			int nNumLines = aLines.GetSize();

			// first line is header
			if (aLines[0] != TRANSTEXT_HEADER)
				return FALSE;

			int nStartLine = 1;

			// skip column header
			if (aLines[1] == CSVCOLUMN_HEADER)
				nStartLine++;

			// the dictionary itself
			for (int nLine = nStartLine; nLine < nNumLines; nLine++)
			{
#ifdef _DEBUG
				const CString& sLine = aLines[nLine];
#endif
					
				DICTITEM diTemp;

				// this call will pull all consecutive lines having the same text
				if (diTemp.FromCsv(aLines, nLine))
				{
					DICTITEM* pDI = new DICTITEM(diTemp);
					m_mapDictionary[pDI->GetTextIn()] = pDI;
				}			
			}
		}

		return TRUE;
	}

	return FALSE;
}

BOOL CTransTextMgr::LoadDictionaryItem(const CXmlItem* pXIDict)
{
	if (pXIDict && pXIDict->NameIs(_T("ITEM")))
	{
		DICTITEM* pDI = new DICTITEM(pXIDict);
		m_mapDictionary[pDI->GetTextIn()] = pDI;

		// next
		LoadDictionaryItem(pXIDict->GetSibling());
		return TRUE;
	}

	return FALSE;
}

void CTransTextMgr::LoadItem(const CXmlItem* pXI)
{
	if (pXI == NULL)
		return;

	// trying loading a DICTITEM
	if (LoadDictionaryItem(pXI))
	{
		// DICTITEM will have loaded itself and all subitems
		// and all siblings
	}
	else // not a DICTITEM so process all children
	{
		POSITION pos = pXI->GetFirstItemPos();

		while (pos)
		{
			const CXmlItem* pXISub = pXI->GetNextItem(pos);
			LoadItem(pXISub);
		}
	}
}

void CTransTextMgr::DeleteDictionary()
{
	POSITION pos = m_mapDictionary.GetStartPosition();

	while (pos)
	{
		DICTITEM* pDI = NULL;
		CString sPath;

		m_mapDictionary.GetNextAssoc(pos, sPath, pDI);
		delete pDI;
	}

#ifdef _DEBUG
	TRACE (_T("%d dictionary items created\n"), nDICount);
	TRACE (_T("%d dictionary items disposed of\n"), m_mapDictionary.GetCount());
#endif

	m_mapDictionary.RemoveAll();
}

void CTransTextMgr::ReleaseHooks()
{
	// cleanup
	DeleteDictionary();

	CHookWndMgr<CTransTextMgr>::Release();
}

void CTransTextMgr::PostHookWnd(HWND hWnd)
{
	CTransWnd* pTWnd = (CTransWnd*)GetHookWnd(hWnd);
	ASSERT (pTWnd);

	if (pTWnd)
		pTWnd->PostHookWindow();
}

BOOL CTransTextMgr::SaveDictionary(LPCTSTR szAltPath) const
{
	if (!m_bAddToDictionary)
		return TRUE; // nothing to do

	if (szAltPath == NULL)
		szAltPath = m_sDictFile;

	return (SaveCsvDictionary(szAltPath) || SaveXmlDictionary(szAltPath));
}

BOOL CTransTextMgr::SaveXmlDictionary(LPCTSTR szDictPath) const
{
	if (!FileMisc::HasExtension(szDictPath, _T("xml")))
		return FALSE;

	CXmlFile file(TRANSTEXT_HEADER);
	CXmlItem* pXITrans = file.Root()->AddItem(TRANSLATED);
	CXmlItem* pXINeedTrans = file.Root()->AddItem(NEED_TRANSLATION);

	// build xml file
	POSITION pos = m_mapDictionary.GetStartPosition();

	while (pos)
	{
		DICTITEM* pDI = NULL;
		CString sKey;

		m_mapDictionary.GetNextAssoc(pos, sKey, pDI);
		ASSERT(pDI && sKey == pDI->GetTextIn());

		// separate translated and non-translated items
		// remember, in DEBUG we always override empty textout
		// with UPPERCASED text
		CXmlItem* pXItem = NULL;

#ifdef _DEBUG
		pXItem = pXITrans->AddItem(ITEM);
#else
		if (pDI->IsTranslated())
			pXItem = pXITrans->AddItem(ITEM);
		else
			pXItem = pXINeedTrans->AddItem(ITEM);
#endif

		if (pXItem)
			pDI->ToXml(pXItem);
	}

	// sort by original text to maintain some sort of order
	pXITrans->SortItems(ITEM, TEXTIN);
	pXINeedTrans->SortItems(ITEM, TEXTIN);

	// mess about with the output to make it easier to understand
	CString sFileContents;
	file.Export(sFileContents);

	sFileContents.Replace(_T("<ITEM"), _T("\t<ITEM"));
	sFileContents.Replace(_T("</ITEM"), _T("\t</ITEM"));
	sFileContents.Replace(_T("<ALTERNATIVE"), _T("\t\t<ALTERNATIVE"));

	return FileMisc::SaveFile(szDictPath, sFileContents, SFE_UNICODE);
}

BOOL CTransTextMgr::SaveCsvDictionary(LPCTSTR szDictPath) const
{
	if (!FileMisc::HasExtension(szDictPath, _T("csv")) && 
		!FileMisc::HasExtension(szDictPath, _T("txt")))
		return FALSE;

	// build csv file
	CStringArray aLines, aTranslated, aNeedTranslation;

	// header
	aLines.Add(TRANSTEXT_HEADER);

	// column header
	aLines.Add(CSVCOLUMN_HEADER);

	// dictionary
	POSITION pos = m_mapDictionary.GetStartPosition();

	while (pos)
	{
		DICTITEM* pDI = NULL;
		CString sKey;
		CStringArray aTransLines, aNeedTransLines;

		m_mapDictionary.GetNextAssoc(pos, sKey, pDI);
		ASSERT(pDI && sKey == pDI->GetTextIn());

		if (pDI->ToCsv(aTransLines, aNeedTransLines))
		{
			if (pDI->IsTranslated())
			{
				aTranslated.Append(aTransLines);
				aTranslated.Append(aNeedTransLines);
			}
			else
			{
				aNeedTranslation.Append(aTransLines);
				aNeedTranslation.Append(aNeedTransLines);
			}
		}
	}

	// sort by original text to maintain some sort of order
	Misc::SortArray(aTranslated, TRUE, CompareProc);
	Misc::SortArray(aNeedTranslation, TRUE, CompareProc);

	// put NEED_TRANSLATION first
	if (aNeedTranslation.GetSize() > 0)
	{
		aLines.Add(NEED_TRANSLATION);
		aLines.Append(aNeedTranslation);
	}

	if (aTranslated.GetSize() > 0)
	{
		aLines.Add(TRANSLATED);
		aLines.Append(aTranslated);
	}

	// mess about with the output to make it easier to understand
	CString sFileContents = Misc::FormatArray(aLines, _T("\r\n"));

	return FileMisc::SaveFile(szDictPath, sFileContents, SFE_UNICODE);
}

int CTransTextMgr::CompareProc(const CString& sFirst, const CString& sSecond)
{
	// compare only up to the second double-quote (ie the input text only)
	int nFirstEnd = sFirst.Find(_T("\"\t"));
	int nSecondEnd = sSecond.Find(_T("\"\t"));

	if (nFirstEnd != nSecondEnd) // not the same input string
		return sFirst.CompareNoCase(sSecond);

	// else only compare up to the tab chars
	return _tcsnicmp(sFirst, sSecond, nFirstEnd);
}

void CTransTextMgr::IgnoreString(const CString& sText)
{
	CTransTextMgr& ttm = GetInstance();
	ttm.m_mapStringIgnore[sText] = _T("");
}

BOOL CTransTextMgr::TranslateText(CString& sText, HWND hWndRef, LPCTSTR szClassID)
{
	// remove trailing/leading spaces
	sText.TrimLeft(' ');
	sText.TrimRight(' ');

	if (sText.GetLength())
	{
		CTransTextMgr& ttm = GetInstance();
		DICTITEM* pDI = ttm.GetDictionary(sText);

		if (pDI && pDI->Translate(sText, hWndRef, szClassID))
		{
			ASSERT(!sText.IsEmpty());
			
			// mark text out as being not-translatable
			// else the translated text can itself be translated!
			ttm.IgnoreString(sText);
			
			return TRUE;
		}
		else
		{
			int breakpoint = 0;
		}
	}

	return FALSE;
}

void CTransTextMgr::PreventTranslation(HWND hWnd)
{
	if (hWnd)
	{
		CTransTextMgr& ttm = GetInstance();

		if (ttm.WantTranslation(hWnd))
		{
			// unhook window if already hooked
			ttm.RemoveHookWnd(hWnd);
			//ttm.RemoveDictionary(hWnd);

			// save for posterity
			ttm.m_mapWndIgnore[hWnd] = NULL;
		}
	}
}

BOOL CTransTextMgr::WantTranslation(HWND hWnd, UINT nMsg) const
{
	void* pDummy = NULL;

	if (m_mapWndIgnore.Lookup(hWnd, pDummy))
		return FALSE;

	// weed out various window types
	if (nMsg == WM_SETTEXT && CWinClasses::IsEditControl(hWnd))
		return FALSE;

	// else
	return TRUE;
}

void CTransTextMgr::PreventTranslation(HMENU hMenu)
{
	if (hMenu)
	{
		CTransTextMgr& ttm = GetInstance();
		
		for (int nItem = 0; nItem < ::GetMenuItemCount(hMenu); nItem++)
		{
			UINT nID = ::GetMenuItemID(hMenu, nItem);
			
			// save for posterity
			ttm.m_mapMenuIgnore[nID] = NULL;
		}
	}
}

void CTransTextMgr::PreventTranslation(UINT nMenuID)
{
	if (nMenuID)
	{
		CTransTextMgr& ttm = GetInstance();
		ttm.m_mapMenuIgnore[nMenuID] = NULL;
	}
}

BOOL CTransTextMgr::WantTranslation(UINT nMenuID) const
{
	void* pDummy = NULL;
	
	if (nMenuID && m_mapMenuIgnore.Lookup(nMenuID, pDummy))
		return FALSE;
	
	// else
	return TRUE;
}

BOOL CTransTextMgr::RemoveHookWnd(HWND hWnd)
{
	if (hWnd)
		return UnhookWnd(hWnd);
	
	// else
	return FALSE;
}

CSubclassWnd* CTransTextMgr::NewHookWnd(HWND hWnd, const CString& sClass, DWORD dwStyle) const
{
	// pre-check
	if (!WantTranslation(hWnd))
		return NULL;

#ifdef _DEBUG
	int nCtrlID = ::GetDlgCtrlID(hWnd);
#endif

	return CTransWnd::NewTransWnd(sClass, dwStyle);
}

void CTransTextMgr::UpdateMenu(HWND hWnd)
{
	CTransTextMgr& ttm = GetInstance();
	CTransWnd* pTWnd = (CTransWnd*)ttm.GetHookWnd(hWnd);

	if (pTWnd)
		pTWnd->UpdateMenu();
}

BOOL CTransTextMgr::HandleInitMenuPopup(HWND hWnd, UINT nMsg, WPARAM wp, LPARAM lp)
{
	if (nMsg != WM_INITMENUPOPUP)
		return FALSE;
	
	if (!WantTranslation(hWnd, nMsg))
		return FALSE;
	
	TranslateMenu((HMENU)wp, hWnd);

	return TRUE; // handled
}

BOOL CTransTextMgr::HandleSetText(HWND hWnd, UINT nMsg, WPARAM wp, LPARAM lp)
{
	if (nMsg != WM_SETTEXT || !lp)
		return FALSE;

	if (!WantTranslation(hWnd, nMsg))
		return FALSE;

	LPCTSTR szText = (LPCTSTR)lp;

	if (*szText == 0)
		return FALSE;

	CString sText(szText);
		
	if (TranslateText(sText, hWnd))
	{
		MSG msg = { hWnd, nMsg, wp, (LPARAM)(LPCTSTR)sText, 0, { 0, 0 } };
		CHookWndMgr<CTransTextMgr>::OnCallWndProc(msg);

		return TRUE; // handled
	}

	// else 
	return FALSE;
}

BOOL CTransTextMgr::HandleTootipNeedText(HWND hWnd, UINT nMsg, WPARAM wp, LPARAM lp)
{
	if (nMsg != WM_NOTIFY)
		return FALSE;

	NMHDR* pNMHDR = (NMHDR*)lp;

	if (pNMHDR->code != TTN_NEEDTEXTA && pNMHDR->code != TTN_NEEDTEXTW)
		return FALSE;

	if (!WantTranslation(hWnd, nMsg))
		return FALSE;

	// need to handle both ANSI and UNICODE versions of the message
	TOOLTIPTEXTA* pTTTA = (TOOLTIPTEXTA*)pNMHDR;
	TOOLTIPTEXTW* pTTTW = (TOOLTIPTEXTW*)pNMHDR;
	
	UINT_PTR nID = pNMHDR->idFrom;
	
	if (pNMHDR->code == TTN_NEEDTEXTA && (pTTTA->uFlags & TTF_IDISHWND) ||
		pNMHDR->code == TTN_NEEDTEXTW && (pTTTW->uFlags & TTF_IDISHWND))
	{
		// idFrom is actually the HWND of the tool
		nID = ::GetDlgCtrlID((HWND)nID);
	}
	
	if (nID == 0) // will be zero on a separator
		return FALSE;

	// see if the tooltip has already been handled
	static CString strTipText;

	if (pNMHDR->code == TTN_NEEDTEXTA)
	{
		strTipText = pTTTA->szText;

		if (strTipText.IsEmpty())
			strTipText = pTTTA->lpszText;
	}
	else
	{
		strTipText = pTTTW->szText;

		if (strTipText.IsEmpty())
			strTipText = pTTTW->lpszText;
	}

	if (strTipText.IsEmpty())
	{
		CString sFullText((LPCTSTR)nID);
		
		// don't handle the message if no string resource found
		if (sFullText.IsEmpty())
			return FALSE;
		
		// this is the command id, not the button index
		AfxExtractSubString(strTipText, sFullText, 1, '\n');
		
		if (strTipText.IsEmpty())
			return FALSE;
	}
	
	// override class id
	CString sClassID;
	sClassID.Format(_T("tooltip.%d"), nID);

	// translate tip text
	TranslateText(strTipText, hWnd, sClassID);
	
	// copy back to TOOLTIPTEXT
#ifndef _UNICODE
	if (pNMHDR->code == TTN_NEEDTEXTA)
	{
		strncpy(pTTTA->szText, strTipText, sizeof(pTTTA->szText));
		pTTTW->lpszText = (LPTSTR)(LPCTSTR)strTipText;
	}
	else
	{
		_mbstowcsz(pTTTW->szText, strTipText, _countof(pTTTW->szText));
	}
#else
	if (pNMHDR->code == TTN_NEEDTEXTA)
	{
		_wcstombsz(pTTTA->szText, strTipText, _countof(pTTTA->szText));
	}
	else
	{
		wcsncpy(pTTTW->szText, strTipText, _countof(pTTTW->szText));
		pTTTW->lpszText = (LPTSTR)(LPCTSTR)strTipText;
	}
#endif
	
	//*pResult = 0;
	return TRUE; // handled
}

BOOL CTransTextMgr::OnCallWndProc(const MSG& msg)
{   
#ifdef _USRDLL
	// If this is a DLL, need to set up MFC state
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
#endif
	
	BOOL bRes = FALSE;
	
	switch (msg.message)
	{
	case WM_SETTEXT:
		// let hook wnd override
		if (!IsHooked(msg.hwnd))
			bRes = HandleSetText(msg.hwnd, msg.message, msg.wParam, msg.lParam);
		break;

	case WM_INITMENUPOPUP:
		// let hook wnd override
		if (!IsHooked(msg.hwnd))
			bRes = HandleInitMenuPopup(msg.hwnd, msg.message, msg.wParam, msg.lParam);
		break;

	case WM_NOTIFY:
		// let hook wnd override
		if (!IsHooked(msg.hwnd))
			bRes = HandleTootipNeedText(msg.hwnd, msg.message, msg.wParam, msg.lParam);
		break;

	case WM_CONTEXTMENU:
		// we handle this directly
		break;

	default:
		bRes = CHookWndMgr<CTransTextMgr>::OnCallWndProc(msg);
		break;
	}
	
	return bRes;
}


BOOL CTransTextMgr::WantHookWnd(HWND hWnd, UINT nMsg, WPARAM wp, LPARAM lp) const
{
#ifdef _DEBUG
//	CString sClass = CWinClasses::GetClass(hWnd);
//	int nCtrlID = ::GetDlgCtrlID(hWnd);
#endif

	// filter out marked windows
	if (!WantTranslation(hWnd))
	{
		return FALSE;
	}
	else if (CHookWndMgr<CTransTextMgr>::WantHookWnd(hWnd, nMsg, wp, lp))
	{
		// we hook dialog/popup only when then are about to be shown.
		// as a byproduct their children will be hooked also at that point
		if (nMsg != WM_PARENTNOTIFY)
			return IsDlgOrPopup(hWnd); 

		else if (GetHookWnd(::GetParent(hWnd)))
			return TRUE;

		// else 
		return FALSE;
	}

	return FALSE;
}

BOOL CTransTextMgr::IsDlgOrPopup(HWND hWnd)
{
	CString sClass(CWinClasses::GetClassEx(hWnd)); // converts Afx class names into something more useful

	DWORD dwStyle = GetWindowLong(hWnd, GWL_STYLE);
	DWORD dwMask = (WS_POPUP | WS_CAPTION);

	return ((dwStyle & dwMask) || CWinClasses::IsClass(hWnd, WC_DIALOGBOX));
}

BOOL CTransTextMgr::WantIgnore(const CString& sText)
{
	void* pDummy = 0;

	if (m_mapStringIgnore.Lookup(sText, pDummy))
		return TRUE;

	// else
	return FALSE;
}

DICTITEM* CTransTextMgr::GetDictionary(const CString& sText)
{
	// check list of items to be ignored
	if (sText.IsEmpty() || WantIgnore(sText))
		return NULL;

	// ignore purely numeric strings and symbols
	if (Misc::IsNumber(sText) && !Misc::IsSymbol(sText))
		return NULL;

	DICTITEM* pDI = NULL;

	if (!m_mapDictionary.Lookup(sText, pDI) && m_bAddToDictionary)
	{
		pDI = new DICTITEM(sText);
		m_mapDictionary[sText] = pDI;
	}
	else if (pDI && !pDI->GetTextOut().IsEmpty())
	{
		int breakpoint = 0;
	}

	return pDI;
}

CString CTransTextMgr::GetClassIDName(HWND hWnd, BOOL bFriendly)
{
	if (hWnd == NULL)
		return _T("text");

	CString sClass = (bFriendly ? GetFriendlyClass(CWinClasses::GetClassEx(hWnd), hWnd) : CWinClasses::GetClass(hWnd));

	// do we have a 'valid' id
	int nCtrlID = ::GetDlgCtrlID(hWnd);

	if (bFriendly && (nCtrlID <= 0))
		return sClass;

	// else
	CString sName;
	sName.Format(_T("%s.%d"), sClass, nCtrlID);

	return sName;
}

CString CTransTextMgr::GetClassIDName(HMENU hMenu, int nMenuID, BOOL bFriendly)
{
	CString sClass = bFriendly ? GetFriendlyClass(WC_MENU) : WC_MENU;

	if (bFriendly && nMenuID < 0)
		return sClass;

	CString sName;
	sName.Format(_T("%s.%d"), sClass, nMenuID);	
	
	return sName;
}

CString CTransTextMgr::GetFriendlyClass(const CString& sClass, HWND hWndRef)
{
	if (CWinClasses::IsClass(sClass, WC_DIALOGBOX))
		return _T("dialog");
	
	else if (CWinClasses::IsClass(sClass, WC_STATIC))
		return _T("label");
	
	else if (CWinClasses::IsClass(sClass, WC_MENU))
		return _T("menu");
	
	else if (CWinClasses::IsClass(sClass, WC_BUTTON) && hWndRef)
	{
		int nBtnType = (::GetWindowLong(hWndRef, GWL_STYLE) & 0xf);   

		switch (nBtnType)
		{
		case BS_CHECKBOX:         
		case BS_AUTOCHECKBOX:  
		case BS_3STATE:           
		case BS_AUTO3STATE:  
			return _T("checkbox");
			
		case BS_RADIOBUTTON:      
		case BS_AUTORADIOBUTTON:
			return _T("radiobutton");

		case BS_GROUPBOX:      
			return _T("groupbox");
		}

		// all else
		return sClass;
	}

	return sClass;
}

CString CTransTextMgr::GetClassIDPath(HWND hWnd, BOOL bFriendly)
{
	if (hWnd == NULL)
		return _T("");

	CString sWndPath = GetClassIDPath(::GetParent(hWnd), bFriendly);
	CString sClassID = GetClassIDName(hWnd, bFriendly);

	return FormatPath(sWndPath, sClassID);
}

CString CTransTextMgr::GetClassIDPath(HMENU hMenu, int nMenuID, HWND hWndRef, BOOL bFriendly)
{
	if (hMenu == NULL)
		return _T("");

	CString sWndPath = GetClassIDPath(hWndRef, bFriendly);
	CString sClassID = GetClassIDName(hMenu, nMenuID, bFriendly);

	return FormatPath(sWndPath, sClassID);
}

CString CTransTextMgr::FormatPath(const CString& sItemPath, const CString& sClassID)
{
	if (sItemPath.IsEmpty())
		return sClassID;

	// else
	CString sPath;
	sPath.Format(_T("%s/%s"), sItemPath, sClassID);

	return sPath;
}

BOOL CTransTextMgr::TranslateMenu(HMENU hMenu, HWND hWndRef, BOOL bRecursive)
{
	if (!hMenu || !::IsMenu(hMenu))
		return FALSE;

	int nCount = (int)::GetMenuItemCount(hMenu);
	CTransTextMgr& ttm = CTransTextMgr::GetInstance();

	for (int nPos = 0; nPos < nCount; nPos++)
	{
		int nCmdID = (int)::GetMenuItemID(hMenu, nPos);

		// we don't do separators or ownerdraw or menus tagged as not-translatable
		if (!nCmdID || IsOwnerDraw(nCmdID, hMenu) || !ttm.WantTranslation(nCmdID))
			continue;

		CString sItem;
		int nLen = ::GetMenuString(hMenu, nPos, NULL, 0, MF_BYPOSITION);

		::GetMenuString(hMenu, nPos, sItem.GetBuffer(nLen + 1), nLen + 1, MF_BYPOSITION);
		sItem.ReleaseBuffer();

		// trim off everything after a tab
		int nTab = sItem.Find('\t');
		
		// remove it
		if (nTab >= 0)
			sItem = sItem.Left(nTab);

		if (!sItem.IsEmpty())
		{
			DICTITEM* pDI = ttm.GetDictionary(sItem);

			if (pDI && pDI->Translate(sItem, hMenu, nCmdID))
			{
				ASSERT (!sItem.IsEmpty());

				MENUITEMINFO minfo;
				minfo.cbSize = sizeof(minfo);
		        minfo.fMask = MIIM_STRING;
				minfo.dwTypeData = (LPTSTR)(LPCTSTR)sItem;

				SetMenuItemInfo(hMenu, nPos, TRUE, &minfo);

				// mark text out as being not-translatable
				// else the translated text can itself be translated!
				ttm.IgnoreString(sItem);
			}

			// submenus?
			if (bRecursive && nCmdID == -1)
			{
				HMENU hSubMenu = ::GetSubMenu(hMenu, nPos);

				if (hSubMenu)
					TranslateMenu(hSubMenu, hWndRef, bRecursive);
			}
		}
	}

	return TRUE;
}

BOOL CTransTextMgr::IsOwnerDraw(int nCmdID, HMENU hMenu)
{
	if (nCmdID > 0)
	{
		MENUITEMINFO mii;
		ZeroMemory(&mii, sizeof(mii));

		mii.cbSize = sizeof(mii);
		mii.fMask = MIIM_TYPE;

		if (GetMenuItemInfo(hMenu, nCmdID, FALSE, &mii))
			return (mii.fType & MFT_OWNERDRAW);
	}

	return FALSE;
}

CString& CTransTextMgr::EncodeChars(CString& sText)
{
	if (!sText.IsEmpty())
	{
		if (sText.Find('\t') >= 0)
			sText.Replace(_T("\t"), _T("\\t"));

		if (sText.Find('\r') >= 0)
			sText.Replace(_T("\r"), _T("\\r"));

		if (sText.Find('\n') >= 0)
			sText.Replace(_T("\n"), _T("\\n"));
	}

	return sText;
}

CString& CTransTextMgr::DecodeChars(CString& sText)
{
	if (!sText.IsEmpty())
	{
		if (sText.Find(_T("\\t")) >= 0)
			sText.Replace(_T("\\t"), _T("\t"));

		if (sText.Find(_T("\\r")) >= 0)
			sText.Replace(_T("\\r"), _T("\r"));

		if (sText.Find(_T("\\n")) >= 0)
			sText.Replace(_T("\\n"), _T("\n"));
	}

	return sText;
}

//////////////////////////////////////////////////////////////////////
// CTransWnd implementation

CTransWnd::CTransWnd(DWORD dwOptions) : m_bInit(FALSE), m_bAllowTranslate(TRUE), m_dwOptions(dwOptions)
{
}

CTransWnd::~CTransWnd() 
{
}
	
BOOL CTransWnd::HookWindow(HWND hRealWnd, CSubclasser* pSubclasser)
{
	return CSubclassWnd::HookWindow(hRealWnd, pSubclasser);
}

void CTransWnd::PostHookWindow()
{
	ASSERT(IsHooked());

	m_bInit = TRUE;
	Initialize();
	m_bInit = FALSE;
}

void CTransWnd::TranslateMenu(HMENU hMenu, BOOL bToplevelOnly)
{
	CTransTextMgr::TranslateMenu(hMenu, GetHwnd(), bToplevelOnly);
}

void CTransWnd::Initialize()
{
	CWnd* pThis = GetCWnd();
	
	// caption
	CString sText;
	pThis->GetWindowText(sText);

	if (TranslateText(sText))
		pThis->SetWindowText(sText);

	// menu - captioned windows only
	if (GetStyle() & WS_CAPTION)
	{
		HMENU hMenu = ::GetMenu(*pThis);

		if (hMenu && ::IsMenu(hMenu))	
			TranslateMenu(hMenu, TRUE);
	}
}

BOOL CTransWnd::TranslateText(CString& sText) 
{
	if (!m_bAllowTranslate)
		return FALSE;

	return CTransTextMgr::TranslateText(sText, GetHwnd());
}

LRESULT CTransWnd::WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	// let others do their stuff first then we translate that
	// if required
	LRESULT lRes = CSubclassWnd::WindowProc(hRealWnd, msg, wp, lp);

	switch (msg)
	{
	case WM_NOTIFY:
		{
			NMHDR* pNMHDR = (NMHDR*)lp;
			
			if ((pNMHDR->code == TTN_NEEDTEXTA || pNMHDR->code == TTN_NEEDTEXTW))
			{
				if (HasFlag(TWS_HANDLETOOLTIPS))
				{
					CTransTextMgr::GetInstance().HandleTootipNeedText(hRealWnd, msg, wp, lp);
				}
			}
		}
		break;

	case WM_SETTEXT:
		if (HasFlag(TWS_HANDLESETTEXT))
		{
			// call default handling
			CTransTextMgr::GetInstance().HandleSetText(hRealWnd, msg, wp, lp);
		}
		break;
		
	case WM_INITMENUPOPUP:
		if (HasFlag(TWS_HANDLEMENUPOPUP))
		{
			// call default handling
			CTransTextMgr::GetInstance().HandleInitMenuPopup(hRealWnd, msg, wp, lp);
		}
		break;
	}
		
	return lRes;
}

CTransWnd* CTransWnd::NewTransWnd(const CString& sClass, DWORD dwStyle)
{
	if (CWinClasses::IsClass(sClass, WC_STATIC))
	{
		return new CTransWnd; // standard
	}
	else if (CWinClasses::IsClass(sClass, WC_BUTTON))
	{
		return new CTransWnd; // standard
	}
	else if (CWinClasses::IsClass(sClass, WC_COMBOBOX))
	{
		// we do not translate ownerdraw (unless CBS_HASSTRINGS) or dropdown
		BOOL bOwnerDraw = (dwStyle & (CBS_OWNERDRAWFIXED | CBS_OWNERDRAWVARIABLE));
		BOOL bHasStrings = (dwStyle & CBS_HASSTRINGS);

		UINT nStyle = (dwStyle & 0xf);
		if ((nStyle == CBS_DROPDOWNLIST) && (!bOwnerDraw || bHasStrings))
			return new CTransComboBox;
	}
	else if (CWinClasses::IsClass(sClass, WC_LISTBOX) || 
			CWinClasses::IsClass(sClass, WC_CHECKLISTBOX))
	{
		// we do not translate ownerdraw (unless LBS_HASSTRINGS) 
		BOOL bOwnerDraw = (dwStyle & (LBS_OWNERDRAWFIXED | LBS_OWNERDRAWVARIABLE));
		BOOL bHasStrings = (dwStyle & LBS_HASSTRINGS);

		if (!bOwnerDraw || bHasStrings)
		{
			BOOL bCheckLB = CWinClasses::IsClass(sClass, WC_CHECKLISTBOX);
			return new CTransListBox(bCheckLB);
		}
	}
	else if (CWinClasses::IsClass(sClass, WC_TOOLBAR))
	{
		return new CTransWnd;//ToolBar;
	}
	else if (CWinClasses::IsClass(sClass, WC_STATUSBAR))
	{
		return new CTransStatusBar;
	}
	else if (CWinClasses::IsClass(sClass, WC_TABCONTROL))
	{
		return new CTransTabCtrl; 
	}
	else if (CWinClasses::IsClass(sClass, WC_COMBOBOXEX))
	{
		// we do not translate dropdown
		if (dwStyle & CBS_SIMPLE) // this will also catch CBS_DROPDOWNLIST
			return new CTransComboBoxEx;
	}
	else if (CWinClasses::IsClass(sClass, WC_HEADER))
	{
		return new CTransHeaderCtrl; // we translate the item text
	}
	else if (CWinClasses::IsClass(sClass, WC_LISTVIEW))
	{
		return new CTransListCtrl; // we translate the header item text
	}
	else if (CWinClasses::IsClass(sClass, WC_DIALOGBOX))
	{
		return new CTransWnd; // standard
	}
	else if (CWinClasses::IsClass(sClass, WC_TOOLTIPS))
	{
		return new CTransTooltips; 
	}
	else if (CWinClasses::IsClassEx(sClass, WC_MFCMDIFRAME))
	{
		return new CTransWnd; 
	}
	else if (CWinClasses::IsClassEx(sClass, WC_MFCFRAME))
	{
		// don't translated application title because it's dynamic
		return new CTransWnd(TWS_NOHANDLESETTEXT); 
	}

	// everything else
	return NULL;
}

//////////////////////////////////////////////////////////////////////
// CTransWnd derived classes

void CTransComboBox::Initialize() 
{
	if (!m_bAllowTranslate)
		return;

	CString sText;
	int nItem = SendMessage(CB_GETCOUNT);
	int nSel = SendMessage(CB_GETCURSEL);

	// for each item: get the text, translate it, delete the current item and re-add
	while (nItem--)
	{
		int nLen = SendMessage(CB_GETLBTEXTLEN, nItem);
		SendMessage(CB_GETLBTEXT, nItem, (LPARAM)sText.GetBuffer(nLen + 1));
		sText.ReleaseBuffer();
		
		if (TranslateText(sText))
		{
			DWORD dwItemData = SendMessage(CB_GETITEMDATA, nItem);
			SendMessage(CB_DELETESTRING, nItem);
			
			int nIndex = SendMessage(CB_INSERTSTRING, nItem, (LPARAM)(LPCTSTR)sText);
			SendMessage(CB_SETITEMDATA, nIndex, dwItemData);
		}
	}

	SendMessage(CB_SETCURSEL, nSel);
}

LRESULT CTransComboBox::WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	// we don't handle if this originated in Initialize() else
	// cos it'll already have been done
	if (!m_bInit && m_bAllowTranslate)
	{
		switch (msg)
		{
		case CB_ADDSTRING:
		case CB_INSERTSTRING:
			{
				CString sText((LPCTSTR)lp);

				if (TranslateText(sText))
					return CSubclassWnd::WindowProc(hRealWnd, msg, wp, (LPARAM)(LPCTSTR)sText);
			}
			break;
		}
	}
	
	return CTransWnd::WindowProc(hRealWnd, msg, wp, lp);
}

//////////////////

void CTransComboBoxEx::Initialize() 
{
	if (!m_bAllowTranslate)
		return;

	TCHAR szText[255];
	
	COMBOBOXEXITEM cbi;
	cbi.mask = CBEIF_TEXT;
	cbi.pszText = szText;
	cbi.cchTextMax = 255;

	int nItem = SendMessage(CB_GETCOUNT);

	while (nItem--)
	{
		cbi.iItem = nItem;

		if (SendMessage(CBEM_GETITEM, 0, (LPARAM)&cbi))
			SendMessage(CBEM_SETITEM, 0, (LPARAM)&cbi); // will get handled in WindowProc
	}
}

LRESULT CTransComboBoxEx::WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case CBEM_INSERTITEM:
	case CBEM_SETITEM:
		{
			COMBOBOXEXITEM* pItem = (COMBOBOXEXITEM*)lp;

			if ((pItem->mask & CBEIF_TEXT) && pItem->pszText)
			{
				CString sText(pItem->pszText);

				if (!sText.IsEmpty() && TranslateText(sText))
				{
					TCHAR* szOrgText = pItem->pszText;
					pItem->pszText = (LPTSTR)(LPCTSTR)sText;

					LRESULT lr = CTransWnd::WindowProc(hRealWnd, msg, wp, lp);

					pItem->pszText = szOrgText;
					return lr;
				}
			}
		}
		break;
	}
	
	return CTransWnd::WindowProc(hRealWnd, msg, wp, lp);
}

//////////////////

void CTransListBox::Initialize()
{
	if (!m_bAllowTranslate)
		return;

	CString sText;
	int nItem = SendMessage(LB_GETCOUNT);
	int nSel = SendMessage(LB_GETCURSEL);

	// for each item: get the text, translate it, delete the current item and re-add
	while (nItem--)
	{
		// trickiness to get round implementation of CCheckListBox
		int nLen = SendMessage(LB_GETTEXTLEN, nItem);
		SendMessage(LB_GETTEXT, nItem, (LPARAM)sText.GetBuffer(nLen + 1));
		sText.ReleaseBuffer();

		if (TranslateText(sText))
		{
			DWORD dwItemData = SendMessage(LB_GETITEMDATA, nItem, 0);
			int nCheck = 0;
			
			if (m_bCheckLB)
			{
				CCheckListBox* pCLB = (CCheckListBox*)GetCWnd();
				nCheck = pCLB->GetCheck(nItem);
			}

			SendMessage(LB_GETITEMDATA, nItem, 0);
			SendMessage(LB_DELETESTRING, nItem);

			int nIndex = SendMessage(LB_INSERTSTRING, nItem, (LPARAM)(LPCTSTR)sText);

			// restore item data
			if (dwItemData)
				SendMessage(LB_SETITEMDATA, nItem, dwItemData);

			// and check state
			if (nCheck && m_bCheckLB)
			{
				CCheckListBox* pCLB = (CCheckListBox*)GetCWnd();
				pCLB->SetCheck(nItem, nCheck);
			}

		}
	}
	
	SendMessage(LB_SETCURSEL, nSel);
}

LRESULT CTransListBox::WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	// we don't handle if this originated in Initialize() else
	// cos it'll already have been done
	if (!m_bInit && m_bAllowTranslate)
	{
		switch (msg)
		{
		case LB_ADDSTRING:
		case LB_INSERTSTRING:
			{
				CString sText((LPCTSTR)lp);

				if (TranslateText(sText))
					return CSubclassWnd::WindowProc(hRealWnd, msg, wp, (LPARAM)(LPCTSTR)sText);
			}
			break;
		}
	}
	
	return CTransWnd::WindowProc(hRealWnd, msg, wp, lp);
}

//////////////////

void CTransTabCtrl::Initialize() 
{
	if (m_bAllowTranslate)
	{
		TCHAR szText[255];
		HWND hThis = GetHwnd();
		
		TCITEM tci;
		tci.mask = TCIF_TEXT;
		tci.pszText = szText;
		tci.cchTextMax = 255;

		int nItem = TabCtrl_GetItemCount(hThis);

		while (nItem--)
		{
			if (TabCtrl_GetItem(hThis, nItem, &tci))
				TabCtrl_SetItem(hThis, nItem, &tci); // will get handled in WindowProc
		}
	}
}

LRESULT CTransTabCtrl::WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case TCM_INSERTITEM:
	case TCM_SETITEM:
		if (m_bAllowTranslate)
		{
			TCITEM* pItem = (TCITEM*)lp;

			if ((pItem->mask & TCIF_TEXT) && pItem->pszText)
			{
				CString sText(pItem->pszText);

				if (!sText.IsEmpty() && TranslateText(sText))
				{
					TCHAR* szOrgText = pItem->pszText;
					pItem->pszText = (LPTSTR)(LPCTSTR)sText;

					LRESULT lr = CTransWnd::WindowProc(hRealWnd, msg, wp, lp);

					pItem->pszText = szOrgText;
					return lr;
				}
			}
		}
		break;
	}
	
	return CTransWnd::WindowProc(hRealWnd, msg, wp, lp);
}

//////////////////

void CTransHeaderCtrl::Initialize() 
{
	if (!m_bAllowTranslate)
		return;

	TCHAR szText[255];
	HWND hThis = GetHwnd();
	
	HDITEM hdi;
	hdi.mask = HDI_TEXT;
	hdi.pszText = szText;
	hdi.cchTextMax = 255;

	int nItem = Header_GetItemCount(hThis);

	while (nItem--)
	{
		if (Header_GetItem(hThis, nItem, &hdi))
			Header_SetItem(hThis, nItem, &hdi); // will get handled in WindowProc
	}
}

LRESULT CTransHeaderCtrl::WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case HDM_INSERTITEM:
	case HDM_SETITEM:
		if (m_bAllowTranslate)
		{
			HDITEM* pItem = (HDITEM*)lp;

			if ((pItem->mask & HDI_TEXT) && pItem->pszText)
			{
				CString sText(pItem->pszText);

				if (!sText.IsEmpty() && TranslateText(sText))
				{
					TCHAR* szOrgText = pItem->pszText;
					pItem->pszText = (LPTSTR)(LPCTSTR)sText;

					LRESULT lr = CTransWnd::WindowProc(hRealWnd, msg, wp, lp);

					pItem->pszText = szOrgText;
					return lr;
				}
			}
		}
		break;
	}
	
	return CTransWnd::WindowProc(hRealWnd, msg, wp, lp);
}

//////////////////

void CTransListCtrl::Initialize() 
{
	// do nothing. header control will handle itself
}

LRESULT CTransListCtrl::WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case LVM_INSERTCOLUMN:
	case LVM_SETCOLUMN:
		if (m_bAllowTranslate)
		{
			LVCOLUMN* pItem = (LVCOLUMN*)lp;

			if ((pItem->mask & LVIF_TEXT) && pItem->pszText)
			{
				CString sText(pItem->pszText);

				if (!sText.IsEmpty() && TranslateText(sText))
				{
					TCHAR* szOrgText = pItem->pszText;
					pItem->pszText = (LPTSTR)(LPCTSTR)sText;

					LRESULT lr = CTransWnd::WindowProc(hRealWnd, msg, wp, lp);

					pItem->pszText = szOrgText;
					return lr;
				}
			}
		}
		break;
	}
	
	return CTransWnd::WindowProc(hRealWnd, msg, wp, lp);
}

//////////////////

void CTransTooltips::Initialize()
{
	if (!m_bAllowTranslate)
		return;

	HWND hThis = GetHwnd();
	int nItem = ::SendMessage(hThis, TTM_GETTOOLCOUNT, 0, 0);

	while (nItem--)
	{
		TOOLINFO ti;
		ZeroMemory(&ti, sizeof(ti));
		ti.cbSize = sizeof(ti);

		if (::SendMessage(hThis, TTM_GETTEXT, nItem, (LPARAM)&ti))
			::SendMessage(hThis, TTM_SETTOOLINFO, nItem, (LPARAM)&ti);
	}
}

LRESULT CTransTooltips::WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case TTM_UPDATETIPTEXT:
		{
			TOOLINFO* pTI = (TOOLINFO*)lp;
			CString sText(pTI->lpszText);
			
			if (!sText.IsEmpty() && TranslateText(sText))
			{
				TCHAR* szOrgText = pTI->lpszText;
				pTI->lpszText = (LPTSTR)(LPCTSTR)sText;
				
				LRESULT lr = CTransWnd::WindowProc(hRealWnd, msg, wp, lp);
				
				pTI->lpszText = szOrgText;
				return lr;
			}
		}
		break;
	}

	return CTransWnd::WindowProc(hRealWnd, msg, wp, lp);
}

//////////////////

void CTransToolBar::Initialize()
{
	// handle tooltips too
//	CToolBar* pToolBar = (CToolBar*)GetCWnd();
//	CToolBarCtrl& ttCtrl = pToolBar->GetToolBarCtrl();


}

LRESULT CTransToolBar::WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
// 	switch (msg)
// 	{
// 
// 	}

	return CTransWnd::WindowProc(hRealWnd, msg, wp, lp);
}

//////////////////

void CTransStatusBar::Initialize()
{
	if (!m_bAllowTranslate)
		return;

	TCHAR szText[255];
	HWND hThis = GetHwnd();
	
	int nItem = ::SendMessage(hThis, SB_GETPARTS, 0, NULL);

	while (nItem--)
	{
		if (::SendMessage(hThis, SB_GETTEXT, nItem, (LPARAM)(LPCTSTR)szText))
			::SendMessage(hThis, SB_SETTEXT, nItem, (LPARAM)(LPCTSTR)szText);

		if (::SendMessage(hThis, SB_GETTIPTEXT, MAKEWPARAM(nItem, 255), (LPARAM)(LPCTSTR)szText))
			::SendMessage(hThis, SB_SETTIPTEXT, nItem, (LPARAM)(LPCTSTR)szText);
	}
}

LRESULT CTransStatusBar::WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case SB_SETTEXT:
	case SB_SETTIPTEXT:
		if (m_bAllowTranslate)
		{
			LPCTSTR szOrgText = (LPCTSTR)lp;

			// only translate if changed
			if (szOrgText)
			{
				CString sText(szOrgText);

				if (TranslateText(sText))
				{
					LRESULT lr = CSubclassWnd::WindowProc(hRealWnd, msg, wp, (LPARAM)(LPCTSTR)sText);

					// restore text ptr
					lp = (LPARAM)szOrgText;
				}
			}
		}
		break;
	}

	return CTransWnd::WindowProc(hRealWnd, msg, wp, lp);
}

//////////////////

