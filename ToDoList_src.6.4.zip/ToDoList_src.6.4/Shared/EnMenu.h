// MenuEx.h: interface for the CEnMenu class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ENMENU_H__5AB11CC8_CCF5_4D52_ADC7_27FDC151F3FE__INCLUDED_)
#define AFX_ENMENU_H__5AB11CC8_CCF5_4D52_ADC7_27FDC151F3FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>
#include "EnBitmapEx.h"

enum MENUEX_BTN
{
	MEB_MINIMIZE,
	MEB_RESTORE,
	MEB_CLOSE,
};

class ITransText;

class CEnMenu : public CMenu  
{
public:
	CEnMenu();
	virtual ~CEnMenu();

	BOOL LoadMenu(UINT nMenuResID, HWND hWndRef = NULL, BOOL bTranslateAll = FALSE);

	void SetBackgroundColor(COLORREF color);
	
	// pass -1 as nThemeBMID is you want ownerdraw
	BOOL AddMDIButton(MENUEX_BTN nBtn, UINT nCmdID, BOOL bRightJustify = TRUE);
	BOOL DeleteMDIMenu(UINT nCmdID);

	// for themed buttons only
	BOOL DrawMDIButton(LPDRAWITEMSTRUCT lpDrawItemStruct); 
	BOOL MeasureMDIButton(LPMEASUREITEMSTRUCT lpMeasureItemStruct); 

	static void SetLocalizer(ITransText* pTT);

protected:
	static ITransText* s_pTT;

protected:
	CMap<UINT, UINT, int, int> m_mapCmd2ID;
	CBrush m_brBkgnd;

protected:
	static BOOL IsThemed();
};

#endif // !defined(AFX_ENMENU_H__5AB11CC8_CCF5_4D52_ADC7_27FDC151F3FE__INCLUDED_)
