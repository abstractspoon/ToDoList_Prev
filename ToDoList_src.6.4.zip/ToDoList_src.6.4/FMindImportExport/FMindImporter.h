// FMindImporter.h: interface for the CFMindImporter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FMINDIMPORTER_H__48AE3CCE_E042_432D_B5DB_D7E310CF99CE__INCLUDED_)
#define AFX_FMINDIMPORTER_H__48AE3CCE_E042_432D_B5DB_D7E310CF99CE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\SHARED\IImportExport.h"
#include "..\SHARED\ITasklist.h"
#include "..\SHARED\xmlfile.h"

class CFMindImporter : public IImportTasklist  
{
public:
	CFMindImporter();
	virtual ~CFMindImporter();
	// interface implementation
	void Release() { delete this; }
	
	// caller must copy only
	LPCTSTR GetMenuText() { return _T("FreeMind"); }
	LPCTSTR GetFileFilter() { return _T("FreeMind Files (*.mm)|*.mm||"); }
	LPCTSTR GetFileExtension() { return _T("mm"); }
	
	bool Import(LPCTSTR szSrcFilePath, ITaskList* pDestTaskFile, BOOL bSilent);

protected:
	bool ImportTask(const CXmlItem* pFMTask, ITaskList7* pDestTaskFile, HTASKITEM hParent) const;
	long GetColor(const CXmlItem* pFMTask, LPCTSTR szColorField) const;
	long GetDate(const CXmlItem* pFMTask, LPCTSTR szColorField) const;
	CString GetAttribValueS(const CXmlItem* pFMTask , LPCTSTR szAttribName) const;
	int GetAttribValueI(const CXmlItem* pFMTask , LPCTSTR szAttribName) const;
	bool GetAttribValueB(const CXmlItem* pFMTask , LPCTSTR szAttribName) const;
	double GetAttribValueD(const CXmlItem* pFMTask , LPCTSTR szAttribName) const;
	CString GetTaskRichContent(const CXmlItem* pFMTask , LPCTSTR szRichType) const;

};

#endif // !defined(AFX_FMINDIMPORTER_H__48AE3CCE_E042_432D_B5DB_D7E310CF99CE__INCLUDED_)
