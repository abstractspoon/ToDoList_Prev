// RTFContentCtrl.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "RTFContentCtrl.h"
#include "RTFContentControl.h"

#include "..\3rdparty\compression.h"
#include "..\3rdparty\stdiofileex.h"

#include "..\shared\filemisc.h"
#include "..\shared\misc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// from r2h.h
typedef int (*PFNCONVERTRTF2HTML)(const char*, const char*, unsigned long, const char*);

/*
static AFX_EXTENSION_MODULE AfxdllDLL = { NULL, NULL };

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	// Remove this if you use lpReserved
	UNREFERENCED_PARAMETER(lpReserved);

	if (dwReason == DLL_PROCESS_ATTACH)
	{
		TRACE0("AFXDLL.DLL Initializing!\n");
		
		// Extension DLL one-time initialization
		if (!AfxInitExtensionModule(AfxdllDLL, hInstance))
			return 0;

		// Insert this DLL into the resource chain
		// NOTE: If this Extension DLL is being implicitly linked to by
		//  an MFC Regular DLL (such as an ActiveX Control)
		//  instead of an MFC application, then you will want to
		//  remove this line from DllMain and put it in a separate
		//  function exported from this Extension DLL.  The Regular DLL
		//  that uses this Extension DLL should then explicitly call that
		//  function to initialize this Extension DLL.  Otherwise,
		//  the CDynLinkLibrary object will not be attached to the
		//  Regular DLL's resource chain, and serious problems will
		//  result.

		new CDynLinkLibrary(AfxdllDLL);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		TRACE0("AFXDLL.DLL Terminating!\n");
		// Terminate the library before destructors are called
		AfxTermExtensionModule(AfxdllDLL);
	}
	return 1;   // ok
}
*/

static CRTFContentCtrlApp theApp;

DLL_DECLSPEC IContent* CreateContentInterface()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	return &theApp;
//	return new CRTFContentCtrlApp;
}

DLL_DECLSPEC int GetInterfaceVersion() 
{ 
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	return ICONTENTCTRL_VERSION; 
}

CRTFContentCtrlApp::CRTFContentCtrlApp()
{
}

LPCTSTR CRTFContentCtrlApp::GetTypeID() const
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	static CString sID;

	Misc::GuidToString(RTF_TYPEID, sID); 

	return sID;
}

LPCTSTR CRTFContentCtrlApp::GetTypeDescription() const
{
	return _T("Rich Text");
}

IContentControl* CRTFContentCtrlApp::CreateCtrl(unsigned short nCtrlID, unsigned long nStyle, 
						long nLeft, long nTop, long nWidth, long nHeight, HWND hwndParent)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// load localized resources
	HINSTANCE hResDll = LoadLibrary(_T("RTFContentCtrlLOC.dll"));

	if (hResDll)
		AfxSetResourceHandle(hResDll);

	CRTFContentControl* pControl = new CRTFContentControl;

	if (pControl)
	{
		CRect rect(nLeft, nTop, nLeft + nWidth, nTop + nHeight);

		if (pControl->Create(nStyle, rect, CWnd::FromHandle(hwndParent), nCtrlID, TRUE))
		{
			return pControl;
		}
	}

	delete pControl;
	return NULL;
}

void CRTFContentCtrlApp::Release()
{
//	AFX_MANAGE_STATE(AfxGetStaticModuleState());
//	delete this;
}

int CRTFContentCtrlApp::ConvertToHtml(const unsigned char* pContent, int nLength, 
									  LPCTSTR szCharSet, LPTSTR& szHtml, LPCTSTR szImgDir)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (nLength == 0)
		return 0; // nothing to convert

	// we may have to decompress it first
	unsigned char* pDecompressed = NULL;

	if (strncmp((const char*)pContent, RTFTAG, LENTAG) != 0)
	{
		int nLenDecompressed = 0;

		if (Compression::Decompress(pContent, nLength, pDecompressed, nLenDecompressed))
		{
			pContent = pDecompressed;
			nLength = nLenDecompressed;
		}
		else
			return 0;
	}

	// copy rtf to CString
	CString sHtml;
	int nRTFLen = nLength;
	nLength = 0; // reuse for resultant html length

	// try loading our new converter
	CString sRtf2HtmlPath = FileMisc::GetAppFolder() + _T("\\rtf2htmlbridge.dll");
	static HMODULE hMod = LoadLibrary(sRtf2HtmlPath);

	if (hMod)
	{
		typedef int (*PFNCONVERTRTF2HTML)(LPCTSTR, LPCTSTR, LPCTSTR, 
											LPCTSTR, LPCTSTR, LPCTSTR, 
											LPCTSTR, LPCTSTR, LPCTSTR, 
											LPCTSTR, LPCTSTR);
		
		PFNCONVERTRTF2HTML fnRtf2Html = (PFNCONVERTRTF2HTML)GetProcAddress(hMod, "fnRtf2Html");

		if (fnRtf2Html)
		{
			CString sTempRtf = FileMisc::GetTempFileName(_T("Rtf2Html"), _T("rtf"));
			FileMisc::SaveFile(sTempRtf, CString((const char*)pContent, nRTFLen));

			// arguments
			CString sCharSet;
			sCharSet.Format(_T("/CS:%s"), szCharSet);

			// image folder
			CString sImgDir(szImgDir), sUniqueDir;

			if (sImgDir.IsEmpty())
				sImgDir = FileMisc::GetTempFolder();

			// create a unique image folder every time this is called for this session
			static int nImgCount = 1;
			sUniqueDir.Format(_T("/ID:%s/img%d"), sImgDir, nImgCount);
			nImgCount++;

			CString sTempHtml = FileMisc::GetTempFileName(_T("Rtf2Html"), _T("html"));

			try
			{
				nLength = 0;
				int nRet = fnRtf2Html(sTempRtf, FileMisc::GetTempFolder(), sUniqueDir, 
									  _T("/IT:png"), _T("/DS:content"), sCharSet, _T(""), _T(""), _T(""), _T(""), _T(""));
				if (nRet)
				{
					CStdioFileEx file;
					
					if (file.Open(sTempHtml, CFile::modeRead))
					{
						file.ReadFile(sHtml);
						nLength = sHtml.GetLength();
					}
				}
			}
			catch (...)
			{
				// nLength = 0
			}

			// cleanup
			DeleteFile(sTempRtf);
			DeleteFile(sTempHtml);
		}
	}

	if (nLength)
	{
		szHtml = new TCHAR[nLength + 1];

		memcpy(szHtml, sHtml, nLength * sizeof(TCHAR));
		szHtml[nLength] = 0;
	}

	delete [] pDecompressed;

	return nLength;
}
