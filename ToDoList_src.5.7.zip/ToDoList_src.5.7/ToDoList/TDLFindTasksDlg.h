#if !defined(AFX_TDLFINDTASKSDLG_H__9118493D_32FD_434D_B549_8947D00277CD__INCLUDED_)
#define AFX_TDLFINDTASKSDLG_H__9118493D_32FD_434D_B549_8947D00277CD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TDLFindTasksDlg.h : header file
//
#include "TDLfindtaskexpressionlistctrl.h"
#include "tdlfindresultslistctrl.h"
#include "tdlfilteroptioncombobox.h"

#include "..\shared\dockmanager.h"
#include "..\shared\entoolbar.h"
#include "..\shared\toolbarhelper.h"
#include "..\shared\tabbedcombobox.h"
#include "..\shared\wndprompt.h"

#include "..\3rdparty\lockableheaderctrl.h"

/////////////////////////////////////////////////////////////////////////////
// CTDLFindTasksDlg dialog

const UINT WM_FTD_FIND = ::RegisterWindowMessage("WM_FTD_FIND");
const UINT WM_FTD_SELECTRESULT = ::RegisterWindowMessage("WM_FTD_SELECTRESULT");
const UINT WM_FTD_SELECTALL = ::RegisterWindowMessage("WM_FTD_SELECTALL");
const UINT WM_FTD_CLOSE = ::RegisterWindowMessage("WM_FTD_CLOSE");

class CTDLFindTasksDlg : public CDialog
{
// Construction
public:
	CTDLFindTasksDlg(CWnd* pParent = NULL);   // standard constructor
	~CTDLFindTasksDlg();

	BOOL Initialize(CWnd* pParent, BOOL bDockable = TRUE);
	BOOL Show(BOOL bShow = TRUE);
	void RefreshSearch();

	BOOL GetSearchAllTasklists();
	int GetSearchParams(SEARCHPARAMS& params);
	BOOL GetAutoSelectSingles();

	void AddHeaderRow(LPCTSTR szText, BOOL bSpaceAbove = TRUE);
	void AddResult(const SEARCHRESULT& result, LPCTSTR szTask, LPCTSTR szPath, int nTaskList);

	int GetResultCount() const; // all tasklists
	int GetResultCount(int nTaskList) const;
	int GetAllResults(CFTDResultsArray& aResults) const;
	int GetResults(int nTaskList, CFTDResultsArray& aResults) const;
	int GetResultIDs(int nTaskList, CDWordArray& aTaskIDs) const;
	void DeleteResults(int nTaskList);

	void RefreshUserPreferences() { m_lcResults.RefreshUserPreferences(); }

protected:
// Dialog Data
	//{{AFX_DATA(CTDLFindTasksDlg)
	enum { IDD = IDD_FINDTASKS_DIALOG };
	CCheckComboBox	m_cbInclude;
	CComboBox	m_cbSearches;
	//}}AFX_DATA
	CTDLFindTaskExpressionListCtrl	m_lcFindSetup;
	CTDLFindResultsListCtrl	m_lcResults;

	CWndPromptManager m_mgrPrompts;
	CDockManager m_dockMgr;
	CEnToolBar m_toolbar;
	CToolbarHelper m_tbHelper;
	BOOL m_bDockable;
	int m_nCurSel;
	int		m_bAllTasklists;
	CString	m_sResultsLabel;
	BOOL	m_bAutoSelectSingles;
	CString m_sActiveSearch;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTDLFindTasksDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	virtual void OnCancel() { ShowWindow(SW_HIDE); }
	virtual void OnOK();
	//}}AFX_VIRTUAL

// Implementation
protected:
	int DoModal() { return -1; } // not for public use

	// Generated message map functions
	//{{AFX_MSG(CTDLFindTasksDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnAddRule();
	afx_msg void OnDeleteRule();
	afx_msg void OnUpdateDeleteRule(CCmdUI* pCmdUI);
	afx_msg void OnFind();
	afx_msg void OnClose();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDestroy();
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnSelectall();
	afx_msg void OnDockright();
	afx_msg void OnUpdateDockright(CCmdUI* pCmdUI);
	afx_msg void OnDockleft();
	afx_msg void OnUpdateDockleft(CCmdUI* pCmdUI);
	afx_msg void OnUndock();
	afx_msg void OnUpdateUndock(CCmdUI* pCmdUI);
	afx_msg void OnDockbelow();
	afx_msg void OnUpdateDockbelow(CCmdUI* pCmdUI);
	afx_msg void OnSearchresults();
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnItemchangingResults(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSaveSearch();
	afx_msg void OnItemchangedRulelist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangeSearchlist();
	afx_msg void OnNewSearch();
	afx_msg void OnDeleteSearch();
	afx_msg void OnEditchangeSearchlist();
	afx_msg void OnUpdateDeleteSearch(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSaveSearch(CCmdUI* pCmdUI);
	afx_msg void OnMoveRuleUp();
	afx_msg void OnUpdateMoveRuleUp(CCmdUI* pCmdUI);
	afx_msg void OnMoveRuleDown();
	afx_msg void OnUpdateMoveRuleDown(CCmdUI* pCmdUI);
	//}}AFX_MSG
	afx_msg void OnItemActivated(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnToolTipNotify( UINT id, NMHDR* pNMHDR, LRESULT* pResult );	
	DECLARE_MESSAGE_MAP()

protected:
	void SaveSettings();
	void ResizeDlg(int cx = 0, int cy = 0);
	void LoadSettings();
	CSize GetMinDockedSize(DM_POS nPos);
	int GetNextResult(int nItem, BOOL bDown);
	void SelectItem(int nItem);
	int GetSelectedItem();
	CString GetCurrentSearch(BOOL bSelected);
	BOOL InitializeToolbar();
	void DeleteAllResults();

	BOOL LoadSearch(LPCTSTR szName, CSearchParamArray& params) const;
	BOOL SaveSearch(LPCTSTR szName, const CSearchParamArray& params);
	int LoadSearches();
	int SaveSearches();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TDLFINDTASKSDLG_H__9118493D_32FD_434D_B549_8947D00277CD__INCLUDED_)
