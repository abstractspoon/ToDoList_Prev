// FilteredToDoCtrl.h: interface for the CFilteredToDoCtrl class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILTEREDTODOCTRL_H__356A6EB9_C7EC_4395_8716_623AFF4A269B__INCLUDED_)
#define AFX_FILTEREDTODOCTRL_H__356A6EB9_C7EC_4395_8716_623AFF4A269B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ToDoCtrl.h"
#include "..\shared\misc.h"
#include "..\shared\enheaderctrl.h"
#include "..\shared\subclass.h"
#include "..\3rdparty\xptabctrl.h"

class CFilteredToDoCtrl : public CToDoCtrl, public CSubclasser  
{
public:
	CFilteredToDoCtrl(CContentMgr& mgr, const CONTENTFORMAT& cfDefault);
	virtual ~CFilteredToDoCtrl();

	BOOL ArchiveDoneTasks(LPCTSTR szFilePath, TDC_ARCHIVE nFlags, BOOL bRemoveFlagged); // returns true if any tasks were removed

	void SetFilter(const FTDCFILTER& filter);
	FILTER_TYPE GetFilter(FTDCFILTER& filter) const;
	void RefreshFilter();
	void ClearFilter();
	BOOL HasFilter() const { return m_filter.IsSet(); }

	UINT GetTaskCount(UINT* pVisible = 0) const;
	BOOL DeleteSelectedTask() { return CToDoCtrl::DeleteSelectedTask(); }

	int GetTasks(CTaskFile& tasks, const TDCGETTASKS& filter = TDCGETTASKS(TDCGT_ALL)) const;
	int GetSelectedTasks(CTaskFile& tasks, const TDCGETTASKS& filter = TDCGETTASKS(TDCGT_ALL)) const;

	HTREEITEM NewTask(LPCTSTR szText, TDC_INSERTWHERE nWhere = TDC_INSERTATTOPOFSELTASKPARENT, 
					/*BOOL bSelect = TRUE, */BOOL bEditText = TRUE);

	void SetModified(BOOL bMod = TRUE) { CToDoCtrl::SetModified(bMod); }
	BOOL SelectTask(DWORD dwTaskID);

	int FindTasks(const SEARCHPARAMS& params, CResultArray& aResults) const;
	BOOL SelectTask(CString sPart, TDC_SELECTTASK nSelect); 
	
	BOOL SetStyles(const CTDCStyles& styles);
	BOOL SetStyle(TDC_STYLE nStyle, BOOL bOn = TRUE) { return CToDoCtrl::SetStyle(nStyle, bOn); }

	void SetView(FTC_VIEW nView);
	FTC_VIEW GetView() const { return m_nCurView == FTCV_UNSET ? FTCV_TASKTREE : m_nCurView; }

	BOOL SetTreeFont(HFONT hFont); // setter responsible for deleting

	BOOL PtInHeader(CPoint ptScreen) const;
	void SetVisibleColumns(const CTDCColumnArray& aColumns);

	virtual void Sort(TDC_SORTBY nBy, BOOL bAllowToggle = TRUE);
	virtual TDC_SORTBY GetSortBy() const;

	BOOL MoveSelectedTask(TDC_MOVETASK nDirection);
	BOOL CanMoveSelectedTask(TDC_MOVETASK nDirection) const;

	BOOL GotoNextTask(TDC_GOTO nDirection); 
	BOOL CanGotoNextTask(TDC_GOTO nDirection) const;
	BOOL GotoNextTopLevelTask(TDC_GOTO nDirection); 
	BOOL CanGotoNextTopLevelTask(TDC_GOTO nDirection) const;

	BOOL CanExpandSelectedTask(BOOL bExpand) const;
	void ExpandSelectedTask(BOOL bExpand = TRUE);
	void ExpandAllTasks(BOOL bExpand = TRUE);

	void SetFocusToTasks();
	BOOL TasksHaveFocus() const;

	void SelectAll();
	void DeselectAll(); // call externally only
	void SelectNextTasksInHistory();
	void SelectPrevTasksInHistory();

	BOOL UndoLastAction(BOOL bUndo);

protected:
	CXPTabCtrl m_tabCtrl;
	CListCtrl m_list;
	CEnHeaderCtrl m_header;

	FTDCFILTER m_filter;
	FTC_VIEW m_nCurView;
	DWORD m_dw2ndClickItem;
	TDC_SORTBY m_nListSortBy;

	CTaskListDropTarget m_dtList;
	CImageList m_ilTabs;

	mutable BOOL m_bListNeedRefilter;
	mutable BOOL m_bListNeedResort, m_bTreeNeedResort;
	BOOL m_bListSortAscending;
	BOOL m_bListModSinceLastSort;

// Overrides
protected:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFilteredToDoCtrl)
	//}}AFX_VIRTUAL
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
//	virtual int OnToolHitTest(CPoint point, TOOLINFO* pTI) const;

public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);

protected:
	// Generated message map functions
	//{{AFX_MSG(CFilteredToDoCtrl)
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	afx_msg void OnSelchangeTabcontrol(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnHeaderCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRClickHeader(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickHeader(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnListSelChanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnListClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnListDblClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnListKeyDown(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTreeExpandItem(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTreeGetDispInfo(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnListGetDispInfo(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg LRESULT OnDropFileRef(WPARAM wParam, LPARAM lParam);
	afx_msg void OnListGetInfoTip(NMHDR* pNMHDR, LRESULT* pResult);
//	afx_msg BOOL OnToolTipNotify( UINT id, NMHDR* pNMHDR, LRESULT* pResult );	
//	afx_msg BOOL OnToolTipShow( UINT id, NMHDR* pNMHDR, LRESULT* pResult );	
	afx_msg LRESULT OnEditCancel(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGutterWidthChange(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()

protected:
	void InitFilterDueDate(COleDateTime& dateDue) const;
	BOOL ModNeedsRefilter(TDC_ATTRIBUTE nModType, FTC_VIEW nView) const;
	BOOL ModNeedsResort(TDC_ATTRIBUTE nModType) const;
	void ResortSelectedTaskParents();

	virtual BOOL DeleteSelectedTask(BOOL bWarnUser, BOOL bResetSel = FALSE);
	virtual BOOL SelectedTasksHaveChildren() const;
	virtual void SetModified(BOOL bMod, TDC_ATTRIBUTE nAttrib);
	virtual TODOITEM* NewTask(HTREEITEM htiParent);
	virtual void ReposTaskTree(CDeferWndMove* pDWM, const CRect& rPos);
	virtual COLORREF GetItemLineColor(HTREEITEM hti);
	CRect GetSelectedItemsRect() const;
	virtual BOOL SetStyle(TDC_STYLE nStyle, BOOL bOn, BOOL bWantUpdate); // one style at a time only 

	virtual BOOL LoadTasks(const CTaskFile& file);
	virtual void SaveSortState(CPreferences& prefs);
	virtual void LoadSortState(const CPreferences& prefs, LPCTSTR szFilePath);

	// we hook the list view for mouse clicks
	virtual LRESULT ScWindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp);

	int FindTask(DWORD dwTaskID) const;
	void BuildFilterQuery(SEARCHPARAMS& params);
	void DrawColumnHeaderText(CDC* pDC, int nCol, const CRect& rCol, UINT nState);
	void UpdateColumnWidths();
	TDCCOLUMN* GetColumn(int nCol) const;
	TDC_COLUMN GetColumnID(int nCol) const;
	int GetColumnIndex(TDC_COLUMN nColID) const;
	int GetSelectedListTaskIDs(CDWordArray& aTaskIDs, DWORD& dwFocusedTaskID) const;
	void SetSelectedListTasks(const CDWordArray& aTaskIDs, DWORD dwFocusedTaskID);
	void RemoveDeletedListItems();
	DWORD GetFocusedListTaskID() const;
	void RemeasureList();
	void BuildListColumns(BOOL bResizeCols = TRUE);
	int GetFirstSelectedItem() const;
	void ClearListSelection();
	void ResyncListSelection();
	BOOL IsItemSelected(int nItem) const;
	void GetItemColors(int nItem, NCGITEMCOLORS& colors);
	void UpdateTreeSelection();
	void UpdateSelectedTaskPath();
	void InvalidateItem(HTREEITEM hti);
	virtual void Resize(int cx = 0, int cy = 0);
	int FindTask(LPCTSTR szPart, int nStart = 0, BOOL bNext = TRUE);
	void RestoreTreeSelection(const CDWordArray& aTaskIDs, DWORD dwDefaultID = 0);
	
	virtual int GetArchivableTasks(CTaskFile& tasks) const;
	void GetCompletedTasks(const TODOSTRUCTURE* pTDS, CTaskFile& tasks, HTASKITEM hTaskParent) const;
	virtual BOOL RemoveArchivedTask(DWORD dwTaskID);

	void RestoreFilter(const CPreferences& prefs);
	void SaveFilter(CPreferences& prefs) const;
	void RefreshListFilter();
	void RefreshTreeFilter();

	void RebuildTree(const SEARCHPARAMS& filter);
	BOOL BuildTreeItem(HTREEITEM hti, const TODOSTRUCTURE* pTDS, const SEARCHPARAMS& filter);
	void RebuildList(const SEARCHPARAMS& filter);
	void AddTreeItemToList(HTREEITEM hti, const SEARCHPARAMS& filter);

	virtual BOOL GetItemTitleRect(HTREEITEM hti, TDC_TITLERECT nArea, CRect& rect) const;
	BOOL GetItemTitleRect(int nItem, TDC_TITLERECT nArea, CRect& rect, CDC* pDC = NULL, LPCTSTR szTitle = NULL) const;
	TDI_STATE GetItemState(int nItem);

	HTREEITEM GetTreeItem(int nItem) const;
	int GetListItem(HTREEITEM hti) const;
	DWORD GetTaskID(int nItem) const { return m_list.GetItemData(nItem); }
	DWORD GetTaskID(HTREEITEM hti) const { return CToDoCtrl::GetTaskID(hti); }

	BOOL InListView() const { return (GetView() == FTCV_TASKLIST); }
	BOOL IsFilterSet(FTC_VIEW nView) const;

	static int CALLBACK FTCCompareFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort); 
	BOOL IsFilterSet(const FTDCFILTER& filter, FTC_VIEW nView) const;
	BOOL FiltersMatch(const FTDCFILTER& filter1, const FTDCFILTER& filter2, FTC_VIEW nView) const;

};

#endif // !defined(AFX_FILTEREDTODOCTRL_H__356A6EB9_C7EC_4395_8716_623AFF4A269B__INCLUDED_)
