#if !defined(AFX_TDLFINDRESULTSLISTCTRL_H__E3FBC372_D7CC_457E_B7BB_1036256A64E9__INCLUDED_)
#define AFX_TDLFINDRESULTSLISTCTRL_H__E3FBC372_D7CC_457E_B7BB_1036256A64E9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// tdlfindresultslistctrl.h : header file
//

#include "tdcstruct.h"
#include "..\shared\enlistctrl.h"

/////////////////////////////////////////////////////////////////////////////
// CTDLFindResultsListCtrl window

struct FTDRESULT
{
	FTDRESULT(DWORD dwID = 0, int nList = 0, BOOL done = FALSE) : dwTaskID(dwID), nTaskList(nList), bDone(done) {}
	
	DWORD dwTaskID;
	int nTaskList;
	BOOL bDone;
};

typedef CArray<FTDRESULT, FTDRESULT&> CFTDResultsArray;


class CTDLFindResultsListCtrl : public CEnListCtrl
{
// Construction
public:
	CTDLFindResultsListCtrl();

// Attributes
public:
	BOOL AddHeaderRow(LPCTSTR szText, BOOL bSpaceAbove = TRUE);
	int AddResult(const SEARCHRESULT& result, LPCTSTR szTask, LPCTSTR szPath, int nTaskList);

	int GetResultCount() const; // all tasklists
	int GetResultCount(int nTaskList) const;
	int GetAllResults(CFTDResultsArray& aResults) const;
	int GetResults(int nTaskList, CFTDResultsArray& aResults) const;
	int GetResultIDs(int nTaskList, CDWordArray& aTaskIDs) const;

	void DeleteResults(int nTaskList);
	void DeleteAllResults();
	
	FTDRESULT* GetResult(int nItem) const { return (FTDRESULT*)GetItemData(nItem); }

	void RefreshUserPreferences();

protected:
	CFont m_fontBold, m_fontStrike;
	COLORREF m_crDone;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTDLFindResultsListCtrl)
	//}}AFX_VIRTUAL
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual void PreSubclassWindow();

// Implementation
public:
	virtual ~CTDLFindResultsListCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CTDLFindResultsListCtrl)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

protected:
  	virtual COLORREF GetItemTextColor(int nItem, int nSubItem, BOOL bSelected, BOOL bDropHighlighted, BOOL bWndFocus) const;
	virtual CFont* GetItemFont(int nItem, int nSubItem);
	int GetNextResult(int nItem, BOOL bDown);

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TDLFINDRESULTSLISTCTRL_H__E3FBC372_D7CC_457E_B7BB_1036256A64E9__INCLUDED_)
