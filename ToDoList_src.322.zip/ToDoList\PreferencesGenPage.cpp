// PreferencesGenPage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesGenPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesGenPage property page

IMPLEMENT_DYNCREATE(CPreferencesGenPage, CPropertyPage)

CPreferencesGenPage::CPreferencesGenPage() : CPropertyPage(CPreferencesGenPage::IDD)
{
	m_psp.dwFlags &= ~PSP_HASHELP;

	//{{AFX_DATA_INIT(CPreferencesGenPage)
	//}}AFX_DATA_INIT

	// load settings
	m_bAlwaysOnTop = AfxGetApp()->GetProfileInt("Preferences", "AlwaysOnTop", FALSE);
	m_bUseSysTray = AfxGetApp()->GetProfileInt("Preferences", "UseSysTray", FALSE);
	m_bAutoSaveOnSysTray = AfxGetApp()->GetProfileInt("Preferences", "AutoSave", TRUE);
	m_bConfirmDelete = AfxGetApp()->GetProfileInt("Preferences", "ConfirmDelete", TRUE);
	m_bNotifyDue = AfxGetApp()->GetProfileInt("Preferences", "NotifyDue", FALSE);
	m_bAutoArchive = AfxGetApp()->GetProfileInt("Preferences", "AutoArchive", FALSE);
	m_bConfirmSaveOnExit = AfxGetApp()->GetProfileInt("Preferences", "ConfirmSaveOnExit", TRUE);
	m_bNotifyReadOnly = AfxGetApp()->GetProfileInt("Preferences", "NotifyReadOnly", TRUE);
	m_bPromptReloadOnWritable = AfxGetApp()->GetProfileInt("Preferences", "PromptReloadOnWritable", TRUE);
	m_bPromptReloadOnTimestamp = AfxGetApp()->GetProfileInt("Preferences", "PromptReloadOnTimestamp", TRUE);
	m_bShowOnStartup = AfxGetApp()->GetProfileInt("Preferences", "ShowOnStartup", TRUE);
	m_nSysTrayOption = AfxGetApp()->GetProfileInt("Preferences", "SysTrayOption", STO_ONCLOSE);
	m_bToggleTrayVisibility = AfxGetApp()->GetProfileInt("Preferences", "ToggleTrayVisibility", FALSE);
//	m_b = AfxGetApp()->GetProfileInt("Preferences", "", TRUE);
}

CPreferencesGenPage::~CPreferencesGenPage()
{
}

void CPreferencesGenPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesGenPage)
	DDX_Check(pDX, IDC_NOTIFYREADONLY, m_bNotifyReadOnly);
	DDX_Check(pDX, IDC_PROMPTRELOADONWRITABLE, m_bPromptReloadOnWritable);
	DDX_Check(pDX, IDC_PROMPTRELOADONCHANGE, m_bPromptReloadOnTimestamp);
	DDX_Check(pDX, IDC_SHOWONSTARTUP, m_bShowOnStartup);
	DDX_CBIndex(pDX, IDC_SYSTRAYOPTION, m_nSysTrayOption);
	DDX_Check(pDX, IDC_TOGGLETRAYVISIBILITY, m_bToggleTrayVisibility);
	//}}AFX_DATA_MAP
	DDX_Check(pDX, IDC_ALWAYSONTOP, m_bAlwaysOnTop);
	DDX_Check(pDX, IDC_USESYSTRAY, m_bUseSysTray);
	DDX_Check(pDX, IDC_AUTOSAVEONSYSTRAY, m_bAutoSaveOnSysTray);
	DDX_Check(pDX, IDC_CONFIRMDELETE, m_bConfirmDelete);
	DDX_Check(pDX, IDC_TASKNOTIFICATIONS, m_bNotifyDue);
	DDX_Check(pDX, IDC_AUTOARCHIVE, m_bAutoArchive);
	DDX_Check(pDX, IDC_CONFIRMSAVEONEXIT, m_bConfirmSaveOnExit);
}


BEGIN_MESSAGE_MAP(CPreferencesGenPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPreferencesGenPage)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_USESYSTRAY, OnUseSystray)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesGenPage message handlers


void CPreferencesGenPage::OnUseSystray() 
{
	UpdateData();

	GetDlgItem(IDC_AUTOSAVEONSYSTRAY)->EnableWindow(m_bUseSysTray);
	GetDlgItem(IDC_SHOWONSTARTUP)->EnableWindow(m_bUseSysTray);
	GetDlgItem(IDC_SYSTRAYOPTION)->EnableWindow(m_bUseSysTray);
	GetDlgItem(IDC_TOGGLETRAYVISIBILITY)->EnableWindow(m_bUseSysTray);

	GetDlgItem(IDC_CONFIRMSAVEONEXIT)->EnableWindow(!m_bUseSysTray); // mutually exclusive
}

BOOL CPreferencesGenPage::OnInitDialog() 
{
	CDialog::OnInitDialog();

	GetDlgItem(IDC_AUTOSAVEONSYSTRAY)->EnableWindow(m_bUseSysTray);
	GetDlgItem(IDC_SHOWONSTARTUP)->EnableWindow(m_bUseSysTray);
	GetDlgItem(IDC_SYSTRAYOPTION)->EnableWindow(m_bUseSysTray);
	GetDlgItem(IDC_TOGGLETRAYVISIBILITY)->EnableWindow(m_bUseSysTray);
	GetDlgItem(IDC_CONFIRMSAVEONEXIT)->EnableWindow(!m_bUseSysTray);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreferencesGenPage::OnOK() 
{
	CPropertyPage::OnOK();
	
	// save settings
	AfxGetApp()->WriteProfileInt("Preferences", "AlwaysOnTop", m_bAlwaysOnTop);
	AfxGetApp()->WriteProfileInt("Preferences", "UseSysTray", m_bUseSysTray);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoSave", m_bAutoSaveOnSysTray);
	AfxGetApp()->WriteProfileInt("Preferences", "ConfirmDelete", m_bConfirmDelete);
	AfxGetApp()->WriteProfileInt("Preferences", "NotifyDue", m_bNotifyDue);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoArchive", m_bAutoArchive);
	AfxGetApp()->WriteProfileInt("Preferences", "ConfirmSaveOnExit", m_bConfirmSaveOnExit);
	AfxGetApp()->WriteProfileInt("Preferences", "NotifyReadOnly", m_bNotifyReadOnly);
	AfxGetApp()->WriteProfileInt("Preferences", "PromptReloadOnWritable", m_bPromptReloadOnWritable);
	AfxGetApp()->WriteProfileInt("Preferences", "PromptReloadOnTimestamp", m_bPromptReloadOnTimestamp);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowOnStartup", m_bShowOnStartup);
	AfxGetApp()->WriteProfileInt("Preferences", "SysTrayOption", m_nSysTrayOption);
	AfxGetApp()->WriteProfileInt("Preferences", "ToggleTrayVisibility", m_bToggleTrayVisibility);
//	AfxGetApp()->WriteProfileInt("Preferences", "", m_b);
}
