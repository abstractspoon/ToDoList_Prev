// PreferencesUIPage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesUIPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUIPage property page

// default priority colors
const COLORREF PRIORITYLOWCOLOR = RGB(30, 225, 0);
const COLORREF PRIORITYHIGHCOLOR = RGB(255, 0, 0);

struct COLUMNPREF
{
	LPCTSTR szName;
	PTP_COLUMN nCol;
	BOOL bVisible;
};

static COLUMNPREF COLUMNS[] = 
{ 
	{ "Position", PTPC_POSITION, -1 }, 
	{ "ID", PTPC_ID, -1 }, 
	{ "Priority", PTPC_PRIORITY, -1 }, 
	{ "Percent Complete", PTPC_PERCENT, -1 }, 
	{ "Time Estimate", PTPC_TIMEEST, -1 }, 
	{ "Start Date", PTPC_STARTDATE, -1 },
	{ "Due Date", PTPC_DUEDATE, -1 }, 
	{ "Completed Date", PTPC_DONEDATE, -1 }, 
	{ "Allocated To", PTPC_PERSON, -1 }, 
	{ "File Reference", PTPC_FILEREF, -1 }, 
};

const int NUM_COLUMNS = sizeof(COLUMNS) / sizeof(COLUMNPREF);

IMPLEMENT_DYNCREATE(CPreferencesUIPage, CPropertyPage)

CPreferencesUIPage::CPreferencesUIPage() : CPropertyPage(CPreferencesUIPage::IDD)
{
	m_psp.dwFlags &= ~PSP_HASHELP;

	//{{AFX_DATA_INIT(CPreferencesUIPage)
	m_nSelPriorityColor = 0;
	m_sTreeFont = "Arial";
	//}}AFX_DATA_INIT

	// priority colors
	m_crLow = AfxGetApp()->GetProfileInt("Preferences\\Colors", "Low", PRIORITYLOWCOLOR);
	m_crHigh = AfxGetApp()->GetProfileInt("Preferences\\Colors", "High", PRIORITYHIGHCOLOR);

	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P0", RGB(30, 225, 0)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P1", RGB(30, 225, 0)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P2", RGB(30, 225, 0)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P3", RGB(30, 225, 0)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P4", RGB(0, 0, 255)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P5", RGB(0, 0, 255)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P6", RGB(0, 0, 255)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P7", RGB(0, 0, 255)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P8", RGB(255, 0, 0)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P9", RGB(255, 0, 0)));
	m_aPriorityColors.Add(AfxGetApp()->GetProfileInt("Preferences\\Colors", "P10", RGB(255, 0, 0)));

	// column visibility
	BOOL bBkwdComp = (-1 == AfxGetApp()->GetProfileInt("Preferences\\ColumnVisibility", "Col0", -1));

	// backwards compatibility
	if (bBkwdComp)
	{
		int nIndex = NUM_COLUMNS;

		while (nIndex--)
		{
			switch (COLUMNS[nIndex].nCol)
			{
			case PTPC_PERCENT:
				COLUMNS[nIndex].bVisible = AfxGetApp()->GetProfileInt("Preferences", "ShowPercentColumn", 1);
				break;

			case PTPC_PRIORITY:
				COLUMNS[nIndex].bVisible = AfxGetApp()->GetProfileInt("Preferences", "ShowPriorityColumn", 1);
				break;

			case PTPC_TIMEEST:
				COLUMNS[nIndex].bVisible = AfxGetApp()->GetProfileInt("Preferences", "ShowTimeColumn", 1);
				break;

			case PTPC_POSITION:
				COLUMNS[nIndex].bVisible = TRUE;
				break;

			default:
				COLUMNS[nIndex].bVisible = FALSE;
				break;
			}
		}
	}
	else
	{
		int nIndex = NUM_COLUMNS;

		while (nIndex--)
		{
			CString sKey;
			sKey.Format("Col%d", COLUMNS[nIndex].nCol);

			COLUMNS[nIndex].bVisible = AfxGetApp()->GetProfileInt("Preferences\\ColumnVisibility", 
															sKey, (COLUMNS[nIndex].nCol == PTPC_POSITION));
		}
	}

	// load settings
	m_bColorTextByPriority = AfxGetApp()->GetProfileInt("Preferences", "ColorByPriority", FALSE);
	m_bShowInfoTips = AfxGetApp()->GetProfileInt("Preferences", "ShowInfoTips", TRUE);
	m_bShowComments = AfxGetApp()->GetProfileInt("Preferences", "ShowComments", TRUE);
	m_bColorPriority = AfxGetApp()->GetProfileInt("Preferences", "ColorPriority", FALSE);
	m_bVaryCommentsHeight = AfxGetApp()->GetProfileInt("Preferences", "VaryCommentsHeight", TRUE);
	m_bShowButtonsInTree = AfxGetApp()->GetProfileInt("Preferences", "ShowButtonsInTree", TRUE);
	m_bIndividualPriorityColors = AfxGetApp()->GetProfileInt("Preferences", "IndividualPriorityColors", FALSE);
	m_sTreeFont = AfxGetApp()->GetProfileString("Preferences", "TreeFont", "Arial");
	m_nFontSize = AfxGetApp()->GetProfileInt("Preferences", "FontSize", 8);
	m_bSpecifyTreeFont = AfxGetApp()->GetProfileInt("Preferences", "SpecifyTreeFont", FALSE);
	m_bShowCtrlsAsColumns = AfxGetApp()->GetProfileInt("Preferences", "ShowCtrlsAsColumns", FALSE);
	m_bShowCommentsAlways = AfxGetApp()->GetProfileInt("Preferences", "ShowCommentsAlways", FALSE);
	m_bAutoReposCtrls = AfxGetApp()->GetProfileInt("Preferences", "AutoReposCtrls", TRUE);
	m_bShowMenuBar = AfxGetApp()->GetProfileInt("Preferences", "ShowMenuBar", FALSE);
	m_bSpecifyGridColor = AfxGetApp()->GetProfileInt("Preferences", "SpecifyGridColor", TRUE);
	m_crGridlines = AfxGetApp()->GetProfileInt("Preferences\\Colors", "Gridlines", GRIDLINECOLOR);
}

CPreferencesUIPage::~CPreferencesUIPage()
{
}

void CPreferencesUIPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesUIPage)
	DDX_Control(pDX, IDC_SETGRIDLINECOLOR, m_btGridlines);
	DDX_Control(pDX, IDC_FONTSIZE, m_cbFontSize);
	DDX_Control(pDX, IDC_FONTLIST, m_cbFonts);
	DDX_Check(pDX, IDC_SPECIFYTREEFONT, m_bSpecifyTreeFont);
	DDX_Check(pDX, IDC_SHOWCTRLSASCOLUMNS, m_bShowCtrlsAsColumns);
	DDX_Check(pDX, IDC_SHOWCOMMENTSALWAYS, m_bShowCommentsAlways);
	DDX_Check(pDX, IDC_AUTOREPOSCTRLS, m_bAutoReposCtrls);
	DDX_Control(pDX, IDC_COLUMNVISIBILITY, m_lbColumnVisibility);
	DDX_Control(pDX, IDC_SETPRIORITYCOLOR, m_btSetColor);
	DDX_Control(pDX, IDC_LOWPRIORITYCOLOR, m_btLowColor);
	DDX_Control(pDX, IDC_HIGHPRIORITYCOLOR, m_btHighColor);
	DDX_Check(pDX, IDC_COLORTEXTBYPRIORITY, m_bColorTextByPriority);
	DDX_Check(pDX, IDC_SHOWINFOTIPS, m_bShowInfoTips);
	DDX_Check(pDX, IDC_SHOWCOMMENTS, m_bShowComments);
	DDX_Check(pDX, IDC_COLORPRIORITY, m_bColorPriority);
	DDX_Check(pDX, IDC_VARYCOMMENTSHEIGHT, m_bVaryCommentsHeight);
	DDX_Check(pDX, IDC_SHOWBUTTONSINTREE, m_bShowButtonsInTree);
	DDX_Radio(pDX, IDC_GRADIENTPRIORITYCOLORS, m_bIndividualPriorityColors);
	DDX_CBIndex(pDX, IDC_PRIORITYCOLORS, m_nSelPriorityColor);
	DDX_LBIndex(pDX, IDC_COLUMNVISIBILITY, m_nSelColumnVisibility);
	DDX_Check(pDX, IDC_SPECIFYGRIDLINECOLOR, m_bSpecifyGridColor);
	//}}AFX_DATA_MAP
	DDX_Check(pDX, IDC_SHOWMENUBAR, m_bShowMenuBar);

	const int CB2FONTSIZE[] = { 8, 9, 10, 12, 14, 16, 18, 20 };

	if (pDX->m_bSaveAndValidate)
	{
		m_sTreeFont = m_cbFonts.GetSelectedFont();

		ASSERT ((sizeof(CB2FONTSIZE) / sizeof(int)) == m_cbFontSize.GetCount());
		m_nFontSize = CB2FONTSIZE[m_cbFontSize.GetCurSel()];
	}
	else
	{
		m_cbFonts.SetSelectedFont(m_sTreeFont);

		CString sFontSize;
		sFontSize.Format("%d", m_nFontSize);

		if (CB_ERR == m_cbFontSize.SelectString(-1, sFontSize))
		{
			m_nFontSize = CB2FONTSIZE[0];
			m_cbFontSize.SetCurSel(0);
		}
	}
}

BEGIN_MESSAGE_MAP(CPreferencesUIPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPreferencesUIPage)
	ON_BN_CLICKED(IDC_SPECIFYTREEFONT, OnSpecifytreefont)
	ON_BN_CLICKED(IDC_SETGRIDLINECOLOR, OnSetgridlinecolor)
	ON_BN_CLICKED(IDC_LOWPRIORITYCOLOR, OnLowprioritycolor)
	ON_BN_CLICKED(IDC_HIGHPRIORITYCOLOR, OnHighprioritycolor)
	ON_BN_CLICKED(IDC_SETPRIORITYCOLOR, OnSetprioritycolor)
	ON_BN_CLICKED(IDC_GRADIENTPRIORITYCOLORS, OnChangePriorityColorOption)
	ON_BN_CLICKED(IDC_COLORPRIORITY, OnColorPriority)
	ON_CBN_SELCHANGE(IDC_PRIORITYCOLORS, OnSelchangePrioritycolors)
	ON_BN_CLICKED(IDC_INDIVIDUALPRIORITYCOLORS, OnChangePriorityColorOption)
	ON_BN_CLICKED(IDC_SPECIFYGRIDLINECOLOR, OnSpecifygridlinecolor)
	//}}AFX_MSG_MAP
	ON_CLBN_CHKCHANGE(IDC_COLUMNVISIBILITY, OnColVisibilityChange)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUIPage message handlers

BOOL CPreferencesUIPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	GetDlgItem(IDC_GRADIENTPRIORITYCOLORS)->EnableWindow(m_bColorPriority);
	GetDlgItem(IDC_INDIVIDUALPRIORITYCOLORS)->EnableWindow(m_bColorPriority);
	GetDlgItem(IDC_COLORTEXTBYPRIORITY)->EnableWindow(m_bColorPriority);
	GetDlgItem(IDC_LOWPRIORITYCOLOR)->EnableWindow(m_bColorPriority && !m_bIndividualPriorityColors);
	GetDlgItem(IDC_HIGHPRIORITYCOLOR)->EnableWindow(m_bColorPriority && !m_bIndividualPriorityColors);
	GetDlgItem(IDC_PRIORITYCOLORS)->EnableWindow(m_bColorPriority && m_bIndividualPriorityColors);
	GetDlgItem(IDC_SETPRIORITYCOLOR)->EnableWindow(m_bColorPriority && m_bIndividualPriorityColors);
	GetDlgItem(IDC_FONTLIST)->EnableWindow(m_bSpecifyTreeFont);
	GetDlgItem(IDC_FONTSIZE)->EnableWindow(m_bSpecifyTreeFont);
	GetDlgItem(IDC_FONTSIZELABEL)->EnableWindow(m_bSpecifyTreeFont);
	GetDlgItem(IDC_SETGRIDLINECOLOR)->EnableWindow(m_bSpecifyGridColor);
	
	m_btGridlines.SetColor(m_crGridlines);
	m_btLowColor.SetColor(m_crLow);
	m_btHighColor.SetColor(m_crHigh);
	m_btSetColor.SetColor(m_aPriorityColors[0]);

	int nIndex = (int)NUM_COLUMNS;
	
	while (nIndex--)
	{
		int nPos = m_lbColumnVisibility.InsertString(0, COLUMNS[nIndex].szName);
		m_lbColumnVisibility.SetCheck(nPos, COLUMNS[nIndex].bVisible ? 1 : 0);

		// note: we can't use SetItemData because CCheckListBox uses it
	}
		
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CPreferencesUIPage::GetShowColumn(PTP_COLUMN nColumn) 
{ 
	int nIndex = (int)NUM_COLUMNS;
	
	while (nIndex--)
	{
		if (COLUMNS[nIndex].nCol == nColumn)
			return COLUMNS[nIndex].bVisible; 
	}

	// else
	return FALSE;
}

void CPreferencesUIPage::OnLowprioritycolor() 
{
	m_crLow = m_btLowColor.GetColor();
}

void CPreferencesUIPage::OnHighprioritycolor() 
{
	m_crHigh = m_btHighColor.GetColor();
}

void CPreferencesUIPage::OnSetprioritycolor() 
{
	VERIFY(m_nSelPriorityColor >= 0);

	m_aPriorityColors.SetAt(m_nSelPriorityColor, m_btSetColor.GetColor());
}

void CPreferencesUIPage::OnChangePriorityColorOption() 
{
	UpdateData();

	GetDlgItem(IDC_LOWPRIORITYCOLOR)->EnableWindow(m_bColorPriority && !m_bIndividualPriorityColors);
	GetDlgItem(IDC_HIGHPRIORITYCOLOR)->EnableWindow(m_bColorPriority && !m_bIndividualPriorityColors);
	GetDlgItem(IDC_PRIORITYCOLORS)->EnableWindow(m_bColorPriority && m_bIndividualPriorityColors);
	GetDlgItem(IDC_SETPRIORITYCOLOR)->EnableWindow(m_bColorPriority && m_bIndividualPriorityColors && m_nSelPriorityColor >= 0);
}

void CPreferencesUIPage::OnColorPriority() 
{
	UpdateData();

	GetDlgItem(IDC_GRADIENTPRIORITYCOLORS)->EnableWindow(m_bColorPriority);
	GetDlgItem(IDC_INDIVIDUALPRIORITYCOLORS)->EnableWindow(m_bColorPriority);
	GetDlgItem(IDC_COLORTEXTBYPRIORITY)->EnableWindow(m_bColorPriority);

	OnChangePriorityColorOption(); // to handle the other controls
}

int CPreferencesUIPage::GetPriorityColors(CDWordArray& aColors) 
{ 
	aColors.RemoveAll();

	if (m_bColorPriority)
	{
		if (m_bIndividualPriorityColors)
			aColors.Copy(m_aPriorityColors); 
		else
		{
			aColors.Add(m_crLow);
			aColors.Add(m_crHigh);
		}
	}
	
	return aColors.GetSize(); 
}

void CPreferencesUIPage::OnSelchangePrioritycolors() 
{
	UpdateData();

	ASSERT (m_nSelPriorityColor >= 0);
	
	if (m_nSelPriorityColor >= 0)
		m_btSetColor.SetColor(m_aPriorityColors[m_nSelPriorityColor]);
}

void CPreferencesUIPage::OnColVisibilityChange()
{
	UpdateData();

	ASSERT (m_nSelColumnVisibility >= 0);
	
	if (m_nSelColumnVisibility >= 0)
		COLUMNS[m_nSelColumnVisibility].bVisible = m_lbColumnVisibility.GetCheck(m_nSelColumnVisibility);
}


void CPreferencesUIPage::OnOK() 
{
	CPropertyPage::OnOK();
	
	// save settings
	// priority colors
	AfxGetApp()->WriteProfileInt("Preferences\\Colors", "Low", m_crLow);
	AfxGetApp()->WriteProfileInt("Preferences\\Colors", "High", m_crHigh);

	int nColor = 11;

	while (nColor--)
	{
		CString sKey;
		sKey.Format("P%d", nColor);
		AfxGetApp()->WriteProfileInt("Preferences\\Colors", sKey, m_aPriorityColors[nColor]);
	}

	// column visibility
	int nIndex = NUM_COLUMNS;

	while (nIndex--)
	{
		CString sKey;
		sKey.Format("Col%d", COLUMNS[nIndex].nCol);

		AfxGetApp()->WriteProfileInt("Preferences\\ColumnVisibility", sKey, COLUMNS[nIndex].bVisible);
	}

	// save settings
	AfxGetApp()->WriteProfileInt("Preferences", "ColorByPriority", m_bColorTextByPriority);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowInfoTips", m_bShowInfoTips);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowComments", m_bShowComments);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowPercentColumn", m_bShowPercentColumn);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowPriorityColumn", m_bShowPriorityColumn);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowTimeColumn", m_bShowTimeColumn);
	AfxGetApp()->WriteProfileInt("Preferences", "ColorPriority", m_bColorPriority);
	AfxGetApp()->WriteProfileInt("Preferences", "VaryCommentsHeight", m_bVaryCommentsHeight);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowButtonsInTree", m_bShowButtonsInTree);
	AfxGetApp()->WriteProfileInt("Preferences", "IndividualPriorityColors", m_bIndividualPriorityColors);
	AfxGetApp()->WriteProfileString("Preferences", "TreeFont", m_sTreeFont);
	AfxGetApp()->WriteProfileInt("Preferences", "FontSize", m_nFontSize);
	AfxGetApp()->WriteProfileInt("Preferences", "SpecifyTreeFont", m_bSpecifyTreeFont);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowCtrlsAsColumns", m_bShowCtrlsAsColumns);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowCommentsAlways", m_bShowCommentsAlways);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoReposCtrls", m_bAutoReposCtrls);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowMenuBar", m_bShowMenuBar);
	AfxGetApp()->WriteProfileInt("Preferences\\Colors", "Gridlines", m_crGridlines);
//	AfxGetApp()->WriteProfileInt("Preferences", "", m_b);
}

void CPreferencesUIPage::OnSpecifytreefont() 
{
	UpdateData();

	GetDlgItem(IDC_FONTLIST)->EnableWindow(m_bSpecifyTreeFont);
	GetDlgItem(IDC_FONTSIZE)->EnableWindow(m_bSpecifyTreeFont);
	GetDlgItem(IDC_FONTSIZELABEL)->EnableWindow(m_bSpecifyTreeFont);

	if (m_bSpecifyTreeFont)
		m_cbFonts.SetSelectedFont(m_sTreeFont);
}

BOOL CPreferencesUIPage::GetTreeFont(CString& sFaceName, int& nPointSize)
{
	sFaceName = m_sTreeFont;
	nPointSize = m_nFontSize;

	return m_bSpecifyTreeFont;
}


void CPreferencesUIPage::OnSetgridlinecolor() 
{
	m_crGridlines = m_btGridlines.GetColor();
}

void CPreferencesUIPage::OnSpecifygridlinecolor() 
{
	UpdateData();	

	GetDlgItem(IDC_SETGRIDLINECOLOR)->EnableWindow(m_bSpecifyGridColor);
}
