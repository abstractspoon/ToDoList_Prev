// PreferencesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesDlg dialog

// default priority colors
const COLORREF PRIORITYLOWCOLOR = RGB(30, 225, 0);
const COLORREF PRIORITYHIGHCOLOR = RGB(255, 0, 0);

CPreferencesDlg::CPreferencesDlg(CShortcutManager* pMgr, UINT nMenuID, CWnd* pParent /*=NULL*/)
	: CPropertySheet("Preferences - ToDoList � AbstractSpoon", pParent), m_pageShortcuts(pMgr, nMenuID)
{
	AddPage(&m_pageGen);
	AddPage(&m_pageFile);
	AddPage(&m_pageUI);
	AddPage(&m_pageTask);
	AddPage(&m_pageTool);
	AddPage(&m_pageShortcuts);

	m_psh.dwFlags |= PSH_NOAPPLYNOW;
	m_psh.dwFlags &= ~PSH_HASHELP;
	m_psh.nStartPage = AfxGetApp()->GetProfileInt("Preferences", "StartPage", 0);
}

CPreferencesDlg::~CPreferencesDlg()
{
}

BEGIN_MESSAGE_MAP(CPreferencesDlg, CPropertySheet)
	//{{AFX_MSG_MAP(CPreferencesDlg)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesDlg message handlers


BOOL CPreferencesDlg::OnInitDialog() 
{
	CPropertySheet::OnInitDialog();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreferencesDlg::OnDestroy() 
{
	CPropertySheet::OnDestroy();
	
	AfxGetApp()->WriteProfileInt("Preferences", "StartPage", GetActiveIndex());
}
