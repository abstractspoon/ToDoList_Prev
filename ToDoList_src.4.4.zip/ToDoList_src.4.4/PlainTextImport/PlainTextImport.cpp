// PlainTextImport.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "plaintextimporter.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

DLL_DECLSPEC IImportTasklist* CreateImportInterface()
{
	return new CPlainTextImporter;
}


DLL_DECLSPEC int GetInterfaceVersion()
{
	return IIMPORTEXPORT_VERSION;
}
