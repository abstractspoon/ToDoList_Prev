// PlainTextImporter.cpp: implementation of the CPlainTextImporter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PlainTextImporter.h"
#include <time.h>
#include <unknwn.h>
#include "..\SHARED\iTasklist.h"

#include <string>
#include <fstream>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPlainTextImporter::CPlainTextImporter()
{

}

CPlainTextImporter::~CPlainTextImporter()
{

}

bool CPlainTextImporter::Import(const char* szSrcFilePath, ITaskList* pDestTaskFile)
{
	ITaskList2* pTL2 = 0;
	pDestTaskFile->QueryInterface(IID_TASKLIST2, reinterpret_cast<void**>(&pTL2));


   std::ifstream in(szSrcFilePath); 
   std::string sLine;
   
   while (std::getline(in, sLine))
   {
      if (sLine.length())
      {
         HTASKITEM hNew;
         size_t delim = sLine.find("|");
         if (delim != std::string::npos)
         {
            hNew = pDestTaskFile->NewTask(sLine.substr(0, 
               delim).c_str());
            bool res = pDestTaskFile->SetTaskComments(hNew, 
               sLine.substr(delim+1).c_str());
         }
         else
            hNew = pDestTaskFile->NewTask(sLine.c_str());
         
         pDestTaskFile->SetTaskPriority(hNew, 5);

		 if (pTL2)
			pTL2->SetTaskCreatedBy(hNew, "danny boy");
      }
   }
   return true;
}
