// TDLPrintDialog.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "TDLPrintDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTDLPrintDialog dialog


CTDLPrintDialog::CTDLPrintDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CTDLPrintDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTDLPrintDialog)
	//}}AFX_DATA_INIT
	m_bCompletedTasks = AfxGetApp()->GetProfileInt("Print", "CompletedTasks", TRUE);
	m_bIncompleteTasks = AfxGetApp()->GetProfileInt("Print", "IncompleteTasks", TRUE);
	m_bSelectedTasks = FALSE;
}


void CTDLPrintDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTDLPrintDialog)
	DDX_Check(pDX, IDC_INCLUDEDONE, m_bCompletedTasks);
	DDX_Check(pDX, IDC_INCLUDENOTDONE, m_bIncompleteTasks);
	DDX_Radio(pDX, IDC_ALLTASKS, m_bSelectedTasks);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTDLPrintDialog, CDialog)
	//{{AFX_MSG_MAP(CTDLPrintDialog)
	ON_BN_CLICKED(IDC_ALLTASKS, OnChangetasksOption)
	ON_BN_CLICKED(IDC_INCLUDEDONE, OnInclude)
	ON_BN_CLICKED(IDC_SELTASK, OnChangetasksOption)
	ON_BN_CLICKED(IDC_INCLUDENOTDONE, OnInclude)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTDLPrintDialog message handlers

void CTDLPrintDialog::OnOK() 
{
	CDialog::OnOK();
	
	// save settings
	AfxGetApp()->WriteProfileInt("Print", "CompletedTasks", m_bCompletedTasks);
	AfxGetApp()->WriteProfileInt("Print", "IncompleteTasks", m_bIncompleteTasks);
}

void CTDLPrintDialog::OnChangetasksOption() 
{
	UpdateData();

	GetDlgItem(IDC_INCLUDEDONE)->EnableWindow(!m_bSelectedTasks);
	GetDlgItem(IDC_INCLUDENOTDONE)->EnableWindow(!m_bSelectedTasks);
}

void CTDLPrintDialog::OnInclude() 
{
	UpdateData();
	EnableOK();
}

void CTDLPrintDialog::EnableOK()
{
	GetDlgItem(IDOK)->EnableWindow(m_bCompletedTasks || m_bIncompleteTasks);
}


BOOL CTDLPrintDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	GetDlgItem(IDC_INCLUDEDONE)->EnableWindow(!m_bSelectedTasks);
	GetDlgItem(IDC_INCLUDENOTDONE)->EnableWindow(!m_bSelectedTasks);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
