#if !defined(AFX_TDSTRING_RESOURCES_ENG_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_)
#define AFX_TDSTRING_RESOURCES_ENG_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// stringres.h : header file
//

const LPCTSTR TDC_COLUMN_ID = _T("ID");
const LPCTSTR TDC_COLUMN_PRIORITY = _T("!");
const LPCTSTR TDC_COLUMN_PERCENT = _T("%");
const LPCTSTR TDC_COLUMN_TIMEEST = _T("Est.");
const LPCTSTR TDC_COLUMN_TIMESPENT = _T("Spent");
const LPCTSTR TDC_COLUMN_STARTDATE = _T("Start");
const LPCTSTR TDC_COLUMN_DUEDATE = _T("Due");
const LPCTSTR TDC_COLUMN_DONEDATE = _T("Completed");
const LPCTSTR TDC_COLUMN_ALLOCTO = _T("To");
const LPCTSTR TDC_COLUMN_ALLOCBY = _T("By");
const LPCTSTR TDC_COLUMN_STATUS = _T("Status");
const LPCTSTR TDC_COLUMN_CATEGORY = _T("Cat.");
const LPCTSTR TDC_COLUMN_TASK = _T("Task");
const LPCTSTR TDC_COLUMN_CREATEDBY = _T("By");
const LPCTSTR TDC_COLUMN_CREATEDATE = _T("Created");

const LPCTSTR TDC_PRIORITY_0 = _T("0 (Lowest)");
const LPCTSTR TDC_PRIORITY_1 = _T("1 (Low)");
const LPCTSTR TDC_PRIORITY_2 = _T("2 (Low)");
const LPCTSTR TDC_PRIORITY_3 = _T("3 (Low)");
const LPCTSTR TDC_PRIORITY_4 = _T("4 (Medium)");
const LPCTSTR TDC_PRIORITY_5 = _T("5 (Medium)");
const LPCTSTR TDC_PRIORITY_6 = _T("6 (Medium)");
const LPCTSTR TDC_PRIORITY_7 = _T("7 (High)");
const LPCTSTR TDC_PRIORITY_8 = _T("8 (High)");
const LPCTSTR TDC_PRIORITY_9 = _T("9 (High)");
const LPCTSTR TDC_PRIORITY_10 = _T("10 (Highest)");

const LPCTSTR TDC_FIELD_TASKLIST = _T("&Body");
const LPCTSTR TDC_FIELD_PRIORITY = _T("Priorit&y");
const LPCTSTR TDC_FIELD_PERCENT = _T("% &Complete");
const LPCTSTR TDC_FIELD_TIMEEST = _T("T&ime Est.");
const LPCTSTR TDC_FIELD_TIMESPENT = _T("Ti&me Spent");
const LPCTSTR TDC_FIELD_STARTDATE = _T("St&art Date");
const LPCTSTR TDC_FIELD_DUEDATE = _T("D&ue Date");
const LPCTSTR TDC_FIELD_DONEDATE = _T("Com&pleted");
const LPCTSTR TDC_FIELD_ALLOCTO = _T("A&llocated To");
const LPCTSTR TDC_FIELD_ALLOCBY = _T("Alloca&ted By");
const LPCTSTR TDC_FIELD_STATUS = _T("&Status");
const LPCTSTR TDC_FIELD_CATEGORY = _T("Cate&gory");
const LPCTSTR TDC_FIELD_FILEREF = _T("File &Ref.");
const LPCTSTR TDC_FIELD_COMMENTS = _T("C&omments");
const LPCTSTR TDC_FIELD_PROJECT = _T("Pro&ject");

const LPCTSTR TDCTIP_TASK = _T("Task:\t\t");
const LPCTSTR TDCTIP_PRIORITY = _T("Priority:\t\t");
const LPCTSTR TDCTIP_PERCENT = _T("% Complete:\t");
const LPCTSTR TDCTIP_TIMEEST = _T("Time Est:\t");
const LPCTSTR TDCTIP_STARTDATE = _T("Start Date:\t");
const LPCTSTR TDCTIP_DUEDATE = _T("Due Date:\t");
const LPCTSTR TDCTIP_DONEDATE = _T("Completed:\t");
const LPCTSTR TDCTIP_ALLOCTO = _T("Assigned To:\t");
const LPCTSTR TDCTIP_FILEREF = _T("File Ref:\t\t");
const LPCTSTR TDCTIP_ALLOCBY = _T("Assigned By:\t");
const LPCTSTR TDCTIP_STATUS = _T("Status:\t");
const LPCTSTR TDCTIP_CATEGORY = _T("Category:\t");
const LPCTSTR TDCTIP_TIMESPENT = _T("Time Spent:\t");
const LPCTSTR TDCTIP_COMMENTS = _T("Comments:\t");
const LPCTSTR TDCTIP_LASTMOD = _T("Last Modified:\t");

const LPCTSTR TDC_CONFIRMDELETESEL = _T("Are you sure you want to delete the selected task(s)?");
const LPCTSTR TDC_CONFIRMDELETEONEWARNSUBTASKS = _T("\n\n(ATTENTION: This task has subtasks which will also be deleted)");
const LPCTSTR TDC_CONFIRMDELETEMOREWARNSUBTASKS = _T("\n\n(ATTENTION: One or more of these tasks has subtasks which will also be deleted)");
const LPCTSTR TDC_CONFIRMDELETEALL = _T("Are you sure you want to delete all the tasks in this task list?");
const LPCTSTR TDC_CONFIRMDELETE_TITLE = _T("Confirm Delete");
const LPCTSTR TDC_CONFIRMRELOAD = _T("");
const LPCTSTR TDC_CONFIRMRELOAD_TITLE = _T("");
const LPCTSTR TDC_CONFIRMOVERWRITE = _T("The tasklist '%s' has been modified \nsince you opened it or last saved your changes.\n\nIf you continue you will overwrite those changes.\n\nAre you sure you want to proceed?");
const LPCTSTR TDC_CONFIRMOVERWRITE_TITLE = _T("Confirm Overwrite");
const LPCTSTR TDC_SPELLCHECK_TITLE = _T("Spell Checking");
const LPCTSTR TDC_NOTITLESPELLERRORS = _T("The selected task's title had no spelling errors");
const LPCTSTR TDC_NOCOMMENTSPELLERRORS = _T("The selected task's comments had no spelling errors");
const LPCTSTR TDC_TASKIDNOTFOUND = _T("A task with an ID of '%d' could not be found in the active tasklist");
const LPCTSTR TDC_TASKIDNOTFOUND_TITLE = _T("Task Not Found");
const LPCTSTR TDC_ZEROINVALIDTASKID = _T("0 (zero) is not a valid task ID");
const LPCTSTR TDC_ZEROINVALIDTASKID_TITLE = _T("Invalid Task ID");
const LPCTSTR TDC_SEECOMMENTS = _T("[see comments]");
const LPCTSTR TDC_STARTSTOPCLOCK = _T("Start/Stop Clock");
const LPCTSTR TDC_SELTASKHASINCOMPLETE = _T("The selected task contains one or more uncompleted subtasks.\n\nWould you also like to set those subtasks to be completed?");
const LPCTSTR TDC_TASKHASINCOMPLETE = _T("One or more of the selected tasks has uncompleted subtasks.\n\nWould you also like to set those subtasks to be completed?");
const LPCTSTR TDC_ARCHIVEPROJECT = _T("archive");
const LPCTSTR TDC_UNTITLEDFILE = _T("untitled");
const LPCTSTR TDC_TASK = _T("Task");
const LPCTSTR TDC_DONE = _T("done");

const LPCTSTR TDC_EDITPROMPT_NAME = _T("Select a name");
const LPCTSTR TDC_EDITPROMPT_COMMENTS = _T("Type some comments");
const LPCTSTR TDC_EDITPROMPT_STATUS = _T("Select a status");
const LPCTSTR TDC_EDITPROMPT_CATEGORY = _T("Select a category");
const LPCTSTR TDC_EDITPROMPT_FILEREF = _T("Browse or type a file or folder pathname");
const LPCTSTR TDC_EDITPROMPT_PROJECT = _T("Type a descriptive name for your tasklist");

/* 
const LPCTSTR  = _T("");
const LPCTSTR  = _T("");
const LPCTSTR  = _T("");
const LPCTSTR  = _T("");
const LPCTSTR  = _T("");
*/


#endif // AFX_TDSHARED_STRING_RESOURCES_H__5951FDE6_508A_4A9D_A55D_D16EB026AEF7__INCLUDED_