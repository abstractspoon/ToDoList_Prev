// PreferencesUIPage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesUIPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUIPage property page

IMPLEMENT_DYNCREATE(CPreferencesUIPage, CPropertyPage)

CPreferencesUIPage::CPreferencesUIPage() : 
	CPropertyPage(CPreferencesUIPage::IDD) 
{
	//{{AFX_DATA_INIT(CPreferencesUIPage)
	m_bKeepTabsOrdered = FALSE;
	m_bShowTasklistCloseButton = FALSE;
	m_bEnableCtrlMBtnClose = FALSE;
	m_bRTLComments = FALSE;
	//}}AFX_DATA_INIT

	// load settings
	m_bShowCtrlsAsColumns = AfxGetApp()->GetProfileInt("Preferences", "ShowCtrlsAsColumns", FALSE);
	m_bShowCommentsAlways = AfxGetApp()->GetProfileInt("Preferences", "ShowCommentsAlways", FALSE);
	m_bAutoReposCtrls = AfxGetApp()->GetProfileInt("Preferences", "AutoReposCtrls", TRUE);
	m_bSpecifyToolbarImage = AfxGetApp()->GetProfileInt("Preferences", "SpecifyToolbarImage", FALSE);
	m_bSharedCommentsHeight = AfxGetApp()->GetProfileInt("Preferences", "SharedCommentsHeight", TRUE);
	m_bAutoHideTabbar = AfxGetApp()->GetProfileInt("Preferences", "AutoHideTabbar", TRUE);
	m_bStackTabbarItems = AfxGetApp()->GetProfileInt("Preferences", "StackTabbarItems", FALSE);
	m_bRightAlignLabels = AfxGetApp()->GetProfileInt("Preferences", "RightAlignLabels", FALSE);
	m_bFocusTreeOnEnter = AfxGetApp()->GetProfileInt("Preferences", "FocusTreeOnEnter", FALSE);
	m_bLargeToolbarIcons = AfxGetApp()->GetProfileInt("Preferences", "LargeToolbarIcons", TRUE);
	m_nNewTaskPos = AfxGetApp()->GetProfileInt("Preferences", "NewTaskPos", PUIP_ABOVE);
	m_nNewSubtaskPos = AfxGetApp()->GetProfileInt("Preferences", "NewSubtaskPos", PUIP_TOP);
	m_bKeepTabsOrdered = AfxGetApp()->GetProfileInt("Preferences", "KeepTabsOrdered", FALSE);
	m_bShowTasklistCloseButton = AfxGetApp()->GetProfileInt("Preferences", "ShowTasklistCloseButton", TRUE);
	m_bEnableCtrlMBtnClose = AfxGetApp()->GetProfileInt("Preferences", "EnableCtrlMBtnClose", TRUE);
	m_bEnableHeaderSorting = AfxGetApp()->GetProfileInt("Preferences", "EnableHeaderSorting", TRUE);
	m_bAutoReSort = AfxGetApp()->GetProfileInt("Preferences", "AutoReSort", FALSE);
	m_bSortVisibleOnly = AfxGetApp()->GetProfileInt("Preferences", "SortVisibleOnly", FALSE);
	m_bSortDoneTasksAtBottom = AfxGetApp()->GetProfileInt("Preferences", "SortDoneTasksAtBottom", TRUE);
	m_bRTLComments = AfxGetApp()->GetProfileInt("Preferences", "RTLComments", FALSE);
//	m_b = AfxGetApp()->GetProfileInt("Preferences", "", FALSE);
}

CPreferencesUIPage::~CPreferencesUIPage()
{
}

void CPreferencesUIPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesUIPage)
	DDX_Check(pDX, IDC_SHOWCTRLSASCOLUMNS, m_bShowCtrlsAsColumns);
	DDX_Check(pDX, IDC_SHOWCOMMENTSALWAYS, m_bShowCommentsAlways);
	DDX_Check(pDX, IDC_AUTOREPOSCTRLS, m_bAutoReposCtrls);
	DDX_Check(pDX, IDC_SHAREDCOMMENTSHEIGHT, m_bSharedCommentsHeight);
	DDX_Check(pDX, IDC_AUTOHIDETABBAR, m_bAutoHideTabbar);
	DDX_Check(pDX, IDC_STACKTABBARITEMS, m_bStackTabbarItems);
	DDX_Check(pDX, IDC_RIGHTALIGNLABELS, m_bRightAlignLabels);
	DDX_Check(pDX, IDC_FOCUSTREEONENTER, m_bFocusTreeOnEnter);
	DDX_Check(pDX, IDC_LARGETOOLBARICONS, m_bLargeToolbarIcons);
	DDX_CBIndex(pDX, IDC_NEWTASKPOSITION, m_nNewTaskPos);
	DDX_CBIndex(pDX, IDC_NEWSUBTASKPOSITION, m_nNewSubtaskPos);
	DDX_Check(pDX, IDC_KEEPTABSORDERED, m_bKeepTabsOrdered);
	DDX_Check(pDX, IDC_SHOWTASKLISTCLOSEBTN, m_bShowTasklistCloseButton);
	DDX_Check(pDX, IDC_ENABLECTRLMBTNCLOSE, m_bEnableCtrlMBtnClose);
	//}}AFX_DATA_MAP
	DDX_Check(pDX, IDC_AUTORESORT, m_bAutoReSort);
	DDX_Check(pDX, IDC_SORTVISIBLEONLY, m_bSortVisibleOnly);
	DDX_Check(pDX, IDC_SORTDONETASKSATBOTTOM, m_bSortDoneTasksAtBottom);
	DDX_Check(pDX, IDC_ENABLEHEADERSORTING, m_bEnableHeaderSorting);
//	DDX_Check(pDX, IDC_RTLCOMMENTS, m_bRTLComments);
}

BEGIN_MESSAGE_MAP(CPreferencesUIPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPreferencesUIPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUIPage message handlers

BOOL CPreferencesUIPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreferencesUIPage::OnOK() 
{
	CPropertyPage::OnOK();
	
	// save settings
	AfxGetApp()->WriteProfileInt("Preferences", "ShowCtrlsAsColumns", m_bShowCtrlsAsColumns);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowCommentsAlways", m_bShowCommentsAlways);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoReposCtrls", m_bAutoReposCtrls);
	AfxGetApp()->WriteProfileInt("Preferences", "SpecifyToolbarImage", m_bSpecifyToolbarImage);
	AfxGetApp()->WriteProfileInt("Preferences", "SharedCommentsHeight", m_bSharedCommentsHeight);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoHideTabbar", m_bAutoHideTabbar);
	AfxGetApp()->WriteProfileInt("Preferences", "StackTabbarItems", m_bStackTabbarItems);
	AfxGetApp()->WriteProfileInt("Preferences", "RightAlignLabels", m_bRightAlignLabels);
	AfxGetApp()->WriteProfileInt("Preferences", "FocusTreeOnEnter", m_bFocusTreeOnEnter);
	AfxGetApp()->WriteProfileInt("Preferences", "LargeToolbarIcons", m_bLargeToolbarIcons);
	AfxGetApp()->WriteProfileInt("Preferences", "NewTaskPos", m_nNewTaskPos);
	AfxGetApp()->WriteProfileInt("Preferences", "NewSubtaskPos", m_nNewSubtaskPos);
	AfxGetApp()->WriteProfileInt("Preferences", "KeepTabsOrdered", m_bKeepTabsOrdered);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowTasklistCloseButton", m_bShowTasklistCloseButton);
	AfxGetApp()->WriteProfileInt("Preferences", "EnableCtrlMBtnClose", m_bEnableCtrlMBtnClose);
	AfxGetApp()->WriteProfileInt("Preferences", "EnableHeaderSorting", m_bEnableHeaderSorting);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoReSort", m_bAutoReSort);
	AfxGetApp()->WriteProfileInt("Preferences", "SortVisibleOnly", m_bSortVisibleOnly);
	AfxGetApp()->WriteProfileInt("Preferences", "SortDoneTasksAtBottom", m_bSortDoneTasksAtBottom);
	AfxGetApp()->WriteProfileInt("Preferences", "RTLComments", m_bRTLComments);
//	AfxGetApp()->WriteProfileInt("Preferences", "", m_b);
}
