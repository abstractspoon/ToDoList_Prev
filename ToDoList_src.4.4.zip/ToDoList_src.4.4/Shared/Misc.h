// Misc.h: interface for the CMisc class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MISC_H__4B2FDA3E_63C5_4F52_A139_9512105C3AD4__INCLUDED_)
#define AFX_MISC_H__4B2FDA3E_63C5_4F52_A139_9512105C3AD4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

namespace Misc  
{
	enum
	{
		OS_95,
		OS_98,
		OS_ME,
		OS_NT4,
		OS_2K,
		OS_XP,
		OS_XPP, // after xp
	};

	void CopyTexttoClipboard(const CString& sText, HWND hwnd);
	BOOL GuidFromString(LPCTSTR szGuid, GUID& guid);
	BOOL GuidToString(const GUID& guid, CString& sGuid);
	BOOL GuidIsNull(const GUID& guid);
	HFONT CreateFont(LPCTSTR szFaceName, int nPoint, BOOL bStrikeThru = FALSE);
	int GetFontNameSize(HFONT hFont, CString& sFaceName);
	int GetOS();

};

#endif // !defined(AFX_MISC_H__4B2FDA3E_63C5_4F52_A139_9512105C3AD4__INCLUDED_)
