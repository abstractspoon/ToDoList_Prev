// NcGutter.cpp: implementation of the CNcGutter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "NcGutter.h"
#include "holdredraw.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const UINT WM_NCG_FORCERESIZE = ::RegisterWindowMessage("WM_NCG_FORCERESIZE");
const UINT HEADERHEIGHT = 17;

CNcGutter::CNcGutter() : m_bSetRedraw(TRUE), m_dwItemClick(0), m_bShowHeader(TRUE), m_bFirstRecalc(TRUE)
{

}

CNcGutter::~CNcGutter()
{

}

BOOL CNcGutter::Initialize(HWND hwnd)
{
	if (CSubclassWnd::HookWindow(hwnd))
	{
		RecalcGutter();
		return TRUE;
	}

	return FALSE;
}

int CNcGutter::AddColumn(LPCTSTR szTitle, UINT nWidth, UINT nTextAlign)
{
	COLUMNDESC cd;
	cd.sTitle = szTitle;
	cd.nWidth = nWidth;
	cd.nTextAlign = nTextAlign;
	cd.bCalcWidth = !nWidth;

	m_aColumns.Add(cd);

	if (IsHooked())
		RecalcGutter();

	return m_aColumns.GetSize() - 1;
}

void CNcGutter::PressColumnHeader(int nColumn, BOOL bPress)
{
	UnpressAllColumnHeaders(nColumn);

	if (nColumn != NCG_CLIENTCOLUMN && !(nColumn >= 0 && nColumn < m_aColumns.GetSize()))
		return;

	COLUMNDESC& cd = (nColumn == NCG_CLIENTCOLUMN) ? m_cdClient : m_aColumns[nColumn];

	if (cd.bPressed != bPress)
	{
		cd.bPressed = bPress;
		Redraw();
	}
}

void CNcGutter::SetColumnHeaderTitle(int nColumn, LPCTSTR szTitle)
{
	if (nColumn != NCG_CLIENTCOLUMN && !(nColumn >= 0 && nColumn < m_aColumns.GetSize()))
		return;

	COLUMNDESC& cd = (nColumn == NCG_CLIENTCOLUMN) ? m_cdClient : m_aColumns[nColumn];

	if (cd.sTitle != szTitle)
	{
		cd.sTitle = szTitle;
		Redraw();
	}
}

void CNcGutter::EnableColumnHeaderClicking(int nColumn, BOOL bEnable)
{
	if (nColumn != NCG_CLIENTCOLUMN && !(nColumn >= 0 && nColumn < m_aColumns.GetSize()))
		return;

	COLUMNDESC& cd = (nColumn == NCG_CLIENTCOLUMN) ? m_cdClient : m_aColumns[nColumn];

	cd.bClickable = bEnable;
}

CNcGutter::COLUMNDESC* CNcGutter::GetColumn(int nCol)
{
	if (nCol != NCG_CLIENTCOLUMN && !(nCol >= 0 && nCol < m_aColumns.GetSize()))
		return NULL;

	return (nCol == NCG_CLIENTCOLUMN) ? &m_cdClient : &m_aColumns[nCol];
}

void CNcGutter::UnpressAllColumnHeaders(int nExcludeCol)
{
	int nCol = m_aColumns.GetSize();

	while (nCol--)
	{
		if (nExcludeCol == NCG_CLIENTCOLUMN || nCol != nExcludeCol)
			m_aColumns[nCol].bPressed = FALSE;
	}

	if (nExcludeCol != NCG_CLIENTCOLUMN)
		m_cdClient.bPressed = FALSE;
}

void CNcGutter::Redraw()
{
	CNcRedraw hr(GetHwnd());
}

void CNcGutter::RecalcGutter()
{
	int nCurWidth = GetGutterWidth();
	int nNewWidth = RecalcGutterWidth();

	if (IsHooked() && (nNewWidth != nCurWidth || m_bFirstRecalc))
	{
		m_bFirstRecalc = FALSE;
		PostMessage(WM_NCG_FORCERESIZE);

		// notify hooked wnd and parent
		UINT nID = GetDlgCtrlID(GetHwnd());

		SendMessage(WM_NCG_WIDTHCHANGE, nID, MAKELPARAM(nCurWidth, nNewWidth));
		::SendMessage(GetParent(), WM_NCG_WIDTHCHANGE, nID, MAKELPARAM(nCurWidth, nNewWidth));
	}

#ifdef _DEBUG
	else
		ASSERT(1);
#endif
}

void CNcGutter::ShowHeader(BOOL bShow)
{
	if (m_bShowHeader != bShow)
	{
		m_bShowHeader = bShow;
		PostMessage(WM_NCG_FORCERESIZE);
	}
}

int CNcGutter::GetGutterWidth()
{
	int nWidth = 0;

	for (int nCol = 0; nCol < m_aColumns.GetSize(); nCol++)
		nWidth += m_aColumns[nCol].nWidth;

	return nWidth;
}

void CNcGutter::AddRecalcMessage(UINT nMessage, UINT nNotification)
{
	m_mapRecalcMessages.SetAt(MAKELONG((WORD)nMessage, (WORD)nNotification), 0);
}

void CNcGutter::AddRedrawMessage(UINT nMessage, UINT nNotification)
{
	m_mapRedrawMessages.SetAt(MAKELONG((WORD)nMessage, (WORD)nNotification), 0);
}

LRESULT CNcGutter::WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case WM_SETFOCUS:
	case WM_VSCROLL:
	case WM_CAPTURECHANGED:
	case WM_KILLFOCUS:
		if (m_bSetRedraw)
		{
			CNcRedraw hr(hRealWnd);
			return Default();
		}
		break;

	case WM_MOUSEWHEEL:
		{
			m_dwItemClick = FALSE;
			
			if (m_bSetRedraw)
			{
				CNcRedraw hr(hRealWnd);
				return Default();
			}
		}
		break;

	case WM_KEYDOWN:
		// we handle only the standard scroll keypresses
		switch (wp) // virtual key
		{
		case VK_DOWN:
		case VK_UP:
		case VK_LEFT:
		case VK_RIGHT:
		case VK_PRIOR: 
		case VK_NEXT:  
		case VK_END:   
		case VK_HOME:  
		case VK_ESCAPE:  
			{
				m_dwItemClick = FALSE;
			
				if (m_bSetRedraw)
				{
					CNcRedraw hr(hRealWnd);
					return Default();
				}
			}
		}
		break;

	case WM_LBUTTONDOWN:
	case WM_RBUTTONDOWN:
		{
			CPoint point(GET_X_LPARAM(lp), GET_Y_LPARAM(lp));
			DWORD dwItem = HitTest(point);

			// if dwItem is not the selected item then we must cache the hit item
			// to ensure the gutter gets drawn properly
			if (GetSelectedItem() != dwItem)
			{
				m_bClickSelChange = TRUE;
				m_dwItemClick = dwItem;
			}
			else
			{
				m_bClickSelChange = FALSE;
				m_dwItemClick = 0;
			}
			
			SetFocus(GetHwnd());
			CNcRedraw hr(hRealWnd);
		}
		break;

	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
		{
			m_dwItemClick = 0;
			m_bClickSelChange = FALSE;
			CNcRedraw hr(hRealWnd);
		}
		break;

	case WM_LBUTTONDBLCLK:
		m_bClickSelChange = TRUE;
		break;

	case WM_NCRBUTTONDOWN:
	case WM_NCLBUTTONDOWN:
	case WM_NCLBUTTONDBLCLK:
		if (wp == HTBORDER) // means gutter
		{
			SetFocus(GetHwnd());

			// get column
			CPoint point(GET_X_LPARAM(lp), GET_Y_LPARAM(lp));
			int nCol = ColumnHitTest(point);

			// is it a header click?
			::ScreenToClient(GetHwnd(), &point);

			if (point.y < 0)
			{
				// check its a clickable column
				COLUMNDESC* pCol = GetColumn(nCol);

				if (pCol && pCol->bClickable)
					PressColumnHeader(nCol);
			}
			else // get item
			{
				// check if point is below client area
				CRect rClient;
				GetClientRect(rClient);

				if (point.y <= rClient.bottom)
				{
					ASSERT (nCol >= 0);

					point.x = 0; // rClient.left
					DWORD dwItem = HitTest(point);

					NCGITEMCLICK ngic = { dwItem, nCol, msg };

					// try hook window then parent
					UINT nID = GetDlgCtrlID(GetHwnd());

					if (!SendMessage(WM_NCG_NOTIFYCOLUMNCLICK, nID, (LPARAM)&ngic))
						::SendMessage(GetParent(), WM_NCG_NOTIFYCOLUMNCLICK, nID, (LPARAM)&ngic);
				}
			}

			// redraw for good measure
			Redraw();
		}
		break;

	case WM_NCRBUTTONUP:
		if (wp == HTBORDER) // means gutter
		{
			// is it a header click?
			CPoint point(GET_X_LPARAM(lp), GET_Y_LPARAM(lp));
			::ScreenToClient(GetHwnd(), &point);

			if (point.y > 0) // no
				SendMessage(WM_CONTEXTMENU, (WPARAM)hRealWnd, lp);

			return 0;
		}
		break;

	case WM_NCLBUTTONUP:
		if (wp == HTBORDER) // means gutter
		{
			// get column
			CPoint point(GET_X_LPARAM(lp), GET_Y_LPARAM(lp));
			int nCol = ColumnHitTest(point);

			::ScreenToClient(GetHwnd(), &point);

			// is it a header click?
			if (point.y < 0)
			{
				// send notification if column header currently pressed
				COLUMNDESC* pCol = GetColumn(nCol);

				if (pCol && pCol->bClickable && pCol->bPressed)
				{
					NCGHDRCLICK nghc = { nCol, msg, FALSE };

					// try hook window then parent
					UINT nID = GetDlgCtrlID(GetHwnd());

					if (!SendMessage(WM_NCG_NOTIFYHEADERCLICK, nID, (LPARAM)&nghc))
						::SendMessage(GetParent(), WM_NCG_NOTIFYHEADERCLICK, nID, (LPARAM)&nghc);

					PressColumnHeader(nCol, nghc.bPressed);

					return 0;
				}
			}
		}
		break;

	case WM_ERASEBKGND:
		// its not a neat solution but it does ensure that when expanding and collapsing
		// tree controls that any animations look correct
		{
			HDC hdc = (HDC)wp;
			UINT nFlags = PRF_CLIENT;
			OnPrint(hdc, nFlags);
		}
		return TRUE; // always

	case WM_NCHITTEST:
		{
			LRESULT lHitTest = Default();
			
			if (lHitTest == HTNOWHERE)
				return HTBORDER;
			else
				return lHitTest;
		}
		break;

	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			
			HDC hdc = ::BeginPaint(hRealWnd, &ps); // device context for painting

			if (m_bSetRedraw)
			{
				UINT nFlags = PRF_CLIENT;
				OnPrint(hdc, nFlags);
			}

			::EndPaint(hRealWnd, &ps);

			return 0;
		}
		break;

	case WM_NCCALCSIZE:
		if (wp)
		{
			LRESULT lr = Default();
			LPNCCALCSIZE_PARAMS lpncsp = (LPNCCALCSIZE_PARAMS)lp;

			lpncsp->rgrc[0].left += GetGutterWidth();

			if (m_bShowHeader)
				lpncsp->rgrc[0].top += HEADERHEIGHT;

			return lr;
		}
		break;

	case WM_NCPAINT:
		Default();

		if (m_bSetRedraw)
			OnNcPaint();
		return 0;

	case WM_PRINT:
		if (m_bSetRedraw)
			OnPrint((HDC)wp, (UINT&)lp);
		break;

	case WM_SETREDRAW:
		m_bSetRedraw = wp;
		
		if (m_bSetRedraw)
		{
			RecalcGutter();
			Redraw();
		}
		break;

	case WM_SETFONT:
		Default();
		RecalcGutter();
		return 0;
	}

	// registered messages must be handled explicitly
	if (msg == WM_NCG_FORCERESIZE)
		return SetWindowPos(hRealWnd, NULL, 0, 0, 0, 0, SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER); 

	// convert message to lookup key
	WORD nNotification = 0;

	if (msg == WM_COMMAND)
		nNotification = HIWORD(wp);
	else if (msg == WM_NOTIFY)
	{
		NMHDR* pNMHDR = (NMHDR*)lp;
		nNotification = pNMHDR->code;
	}

	DWORD dwKey = MAKELONG((WORD)msg, nNotification);
	char dummy;

	// test for recalc
	if (m_bSetRedraw && m_mapRecalcMessages.Lookup(dwKey, dummy))
	{
		m_dwItemClick = FALSE;

		LRESULT lr = Default();
		RecalcGutter();
		return lr;
	}

	// test for redraw 
	if (m_bSetRedraw && m_mapRedrawMessages.Lookup(dwKey, dummy))
	{
		m_dwItemClick = FALSE;

		LRESULT lr = Default();
		CNcRedraw hr(hRealWnd);
		return lr;
	}

	return CSubclassWnd::WindowProc(hRealWnd, msg, wp, lp);
}

void CNcGutter::OnNcPaint() 
{
	// see if we can avoid any unnecessary drawing
	if (GetGutterWidth() == 0 && !m_bShowHeader)
		return;

	DWORD dwTick = GetTickCount();

	CRect rWindow, rClient;
	CPoint ptWindowTL, ptClientTL;

	GetWindowRect(rWindow);
	ptWindowTL = rWindow.TopLeft();

	GetClientRect(rClient);
	ClientToScreen(rClient);

	rWindow.OffsetRect(-ptWindowTL);
	rClient.OffsetRect(-ptWindowTL);
	ptClientTL = rClient.TopLeft();

	const int BORDER = ::GetSystemMetrics(SM_CXEDGE);

	rWindow.DeflateRect(BORDER, BORDER);
	CRect rWindowOrg(rWindow);

	// to avoid creating excessively large bitmaps we'll render the client header straight
	// into the window dc ie only the non-client gutter & header is rendered on the bitmap
	rWindow.bottom = rClient.bottom;
	rWindow.right = rClient.left;

	CWindowDC dc(GetCWnd());
	CDC dcMem;
	CDC* pOutputDC = &dc; // default backup plan in case mem dc or bitmap cannot be created
	CBitmap* pBMOld = NULL;

	if (GetGutterWidth() > 0 && dcMem.CreateCompatibleDC(NULL) && 
		PrepareBitmap(&dc, &m_bmNonClient, CRect(0, 0, rWindow.right, rWindow.bottom), FALSE))
	{		
		pOutputDC = &dcMem;
		dcMem.SelectObject(&m_bmNonClient);
	}

	pOutputDC->FillSolidRect(rWindow.left, rClient.top, rWindow.Width(), rWindow.Height(), ::GetSysColor(COLOR_WINDOW));

	// iterate the top level items
	CFont* pFont = GetCWnd()->GetFont();
	CFont* pOldFont = NULL;

	if (pFont)
		pOldFont = pOutputDC->SelectObject(pFont);
	else
		pOutputDC->SelectStockObject(ANSI_VAR_FONT);
				
	int nItem = 1;
	DWORD dwItem = GetFirstVisibleTopLevelItem(nItem);
				
	while (dwItem)
	{
		CRect rItem;
		CString sPrevPos;
		NcDrawItem(pOutputDC, dwItem, 0, 0, nItem, rWindow, rClient, rItem);
					
		dwItem = GetNextItem(dwItem);
		nItem++;
					
		if (rItem.bottom >= rWindow.bottom)
			break;
	}
				
	PostNcDraw(pOutputDC, rWindow);

	// non-client header
	if (m_bShowHeader)
	{
		pOutputDC->SelectStockObject(ANSI_VAR_FONT);

		CRect rHeader(rWindowOrg);
		rHeader.bottom = rHeader.top + HEADERHEIGHT;
		rHeader.right = rClient.left;
		NcDrawHeader(pOutputDC, rHeader, NONCLIENT);
	}

	// cleanup			
	if (pFont)
		pOutputDC->SelectObject(pOldFont);

	if (pFont)
		pOutputDC->SelectObject(pBMOld); // V.V.IMPORTANT

	// blt to window dc if nec
	if (pOutputDC == &dcMem)
	{
		dc.BitBlt(rWindow.left, rWindow.top, rWindow.Width(), rWindow.Height(),
				  &dcMem, rWindow.left, rWindow.top, SRCCOPY);
	}

	// two items we render direct to the window dc
	
	// 1. the client header
	if (m_bShowHeader)
	{
		dc.SelectStockObject(ANSI_VAR_FONT);

		CRect rHeader(rWindowOrg);
		rHeader.bottom = rWindow.top + HEADERHEIGHT;
		rHeader.left = rClient.left;
		NcDrawHeader(&dc, rHeader, CLIENT);
	}
				
	// 2. if the window base does not match the client bottom then 
	// paint the extra bit gray (means there is a horz scrollbar)
	if (rWindowOrg.bottom != rClient.bottom)
		dc.FillSolidRect(rWindowOrg.left, rClient.bottom, 
								rClient.left - rWindowOrg.left, 
								rWindowOrg.bottom - rClient.bottom, ::GetSysColor(COLOR_SCROLLBAR));


// clip out client area and scrollbars
//dc.ExcludeClipRect(rClient);
//dc.ExcludeClipRect(rClient.left, rClient.bottom, rClient.right, rWindowOrg.bottom);
//dc.ExcludeClipRect(rClient.right, rClient.top, rWindowOrg.right, rWindowOrg.bottom);

	TRACE ("CNcGutter::OnNcPaint() took %d ms\n", GetTickCount() - dwTick);
}

void CNcGutter::NcDrawHeader(CDC* pDC, const CRect& rHeader, HCHDRPART nPart)
{
	if (!m_bShowHeader)
		return;

	COLORREF crShadow = ::GetSysColor(COLOR_3DSHADOW);
	COLORREF crHilite = ::GetSysColor(COLOR_3DHIGHLIGHT);
	COLORREF crFace = ::GetSysColor(COLOR_3DFACE);
	static UINT DEFFLAGS = DT_END_ELLIPSIS | DT_BOTTOM | DT_SINGLELINE;

	pDC->FillSolidRect(rHeader, crFace);
	pDC->SetBkMode(TRANSPARENT);

	CRect rColumn(rHeader);

	if (nPart == NONCLIENT)
	{
		rColumn.right = rColumn.left;

		int nNumCols = m_aColumns.GetSize();

		for (int nCol = 0; nCol < nNumCols; nCol++)
		{
			COLUMNDESC& cd = m_aColumns[nCol];
			int nColWidth = (int)cd.nWidth;

			if (!nColWidth)
				continue;

			rColumn.left = rColumn.right;
			rColumn.right += nColWidth;

			if (cd.bPressed)
				pDC->FillSolidRect(rColumn, crHilite);

			pDC->Draw3dRect(rColumn, cd.bPressed ? crFace : crHilite, crShadow);

			if (!cd.sTitle.IsEmpty())
			{
				CRect rText(rColumn);
				rText.DeflateRect(2, 1);
				rText.bottom--;

				if (cd.bPressed)
					rText.OffsetRect(1, 1);

				// pad the text a bit more if not centered
				if (!(cd.nTextAlign & DT_CENTER))
					rText.DeflateRect(2, 0);

				pDC->DrawText(cd.sTitle, rText, DEFFLAGS | cd.nTextAlign);
			}
		}
	}
	else // the rest is over the client area
	{
		if (m_cdClient.bPressed)
			pDC->FillSolidRect(rColumn, crHilite);

		pDC->Draw3dRect(rColumn, m_cdClient.bPressed ? crFace : crHilite, crShadow);
		
		if (!m_cdClient.sTitle.IsEmpty())
		{
			CRect rText(rColumn);
			rText.DeflateRect(2, 1);
			rText.bottom--;
			
			if (m_cdClient.bPressed)
				rText.OffsetRect(1, 1);

			rText.DeflateRect(2, 0); // pad because left justified
			
			pDC->DrawText(m_cdClient.sTitle, rText, DEFFLAGS | m_cdClient.nTextAlign);
		}
	}
}

void CNcGutter::OnPrint(HDC hdc, UINT& nFlags)
{
	if (nFlags & PRF_CLIENT)
	{
		// render the control to a bitmap for flicker free
		CRect rClient;
		GetClientRect(rClient);
		rClient.InflateRect(1, 1);

		CDC dcMem, dc;

		if (dcMem.CreateCompatibleDC(NULL))
		{
			dc.Attach(hdc);

			if (PrepareBitmap(&dc, &m_bmClient, rClient, TRUE))
			{
				CBitmap* pBMOld = dcMem.SelectObject(&m_bmClient);
				dcMem.FillSolidRect(rClient, GetSysColor(COLOR_WINDOW));

				CSubclassWnd::WindowProc(GetHwnd(), WM_PRINT, (WPARAM)(HDC)dcMem, PRF_CLIENT);

				dc.BitBlt(0, 0, rClient.right, rClient.bottom, &dcMem, 0, 0, SRCCOPY);

				nFlags &= ~PRF_CLIENT; // we just drawn this bit

				// cleanup
				dcMem.SelectObject(pBMOld); // V.V.IMPORTANT
			}

			dc.Detach();
		}
	}
}

DWORD CNcGutter::GetFirstVisibleTopLevelItem(int& nItem)
{
	// try hook window then parent
	UINT nID = GetDlgCtrlID(GetHwnd());

	DWORD dwItem = (DWORD)SendMessage(WM_NCG_GETFIRSTVISIBLETOPLEVELITEM, nID, (LPARAM)(LPINT)&nItem);

	if (!dwItem)
		dwItem = (DWORD)::SendMessage(GetParent(), WM_NCG_GETFIRSTVISIBLETOPLEVELITEM, nID, (LPARAM)(LPINT)&nItem);

	// else
	return dwItem;
}

void CNcGutter::NcDrawItem(CDC* pDC, DWORD dwItem, DWORD dwParentItem, int nLevel, int nPos, 
						   const CRect& rWindow, const CRect& rClient, CRect& rItem)
{
	rItem = GetItemRect(dwItem);
							
	if (!rItem.IsRectEmpty())
	{
		// convert rItem to window coords
		rItem.OffsetRect(0, rClient.TopLeft().y); // convert to window coords
		rItem.left = rWindow.left;
		rItem.right = rWindow.right;

		NCGDRAWITEM ncgDI;
		
		ncgDI.pDC = pDC;
		ncgDI.dwItem = dwItem;
		ncgDI.dwParentItem = dwParentItem;
		ncgDI.nLevel = nLevel;
		ncgDI.nItemPos = nPos;
		ncgDI.rWindow = &rWindow;
		ncgDI.rItem = &rItem;
		
		if (m_dwItemClick)
			ncgDI.bSelected = (m_bClickSelChange && dwItem == m_dwItemClick);
		else
			ncgDI.bSelected = (dwItem == GetSelectedItem());
		
		UINT nID = GetDlgCtrlID(GetHwnd());
		
		// draw each column in turn
		rItem.right = rItem.left;
		int nNumCols = m_aColumns.GetSize();
		
		for (int nCol = 0; nCol < nNumCols; nCol++)
		{
			ncgDI.nColPos = nCol;
			rItem.left = rItem.right;
			
			// if we're out of the window rect then stop
			if (rItem.left > rWindow.right)
				break;
			
			int nColWidth = (int)m_aColumns[nCol].nWidth;
			
			if (!nColWidth)
				continue;
			
			rItem.right += nColWidth;
			
			int nSaveDC = pDC->SaveDC();
			
			// try hook window then parent
			if (!SendMessage(WM_NCG_DRAWITEM, nID, (LPARAM)&ncgDI))
				::SendMessage(GetParent(), WM_NCG_DRAWITEM, nID, (LPARAM)&ncgDI);
			
			pDC->RestoreDC(nSaveDC);
		}

		// draw children
		int nChild = 1;
		DWORD dwChild = GetFirstChildItem(dwItem);
		CRect rChild;
		
		while (dwChild)
		{
			NcDrawItem(pDC, dwChild, dwItem, nLevel + 1, nChild, rWindow, rClient, rChild);
			
			dwChild = GetNextItem(dwChild);
			nChild++;
			
			// accumulate child rects into rItem
			rItem |= rChild;
			
			if (rItem.bottom >= rWindow.bottom)
				break;
		}
		
		// post draw
		CRect rItemTotal(rItem);
		rItemTotal.left = rWindow.left;
		rItemTotal.right = rWindow.right;
		
		PostNcDrawItem(pDC, dwItem, rItemTotal, nLevel);
		
		rItem = rItemTotal;
	}
}

void CNcGutter::PostNcDrawItem(CDC* pDC, DWORD dwItem, const CRect& rItem, int nLevel)
{
	// try hook window then parent
	NCGDRAWITEM ncgDI;
		
	ncgDI.pDC = pDC;
	ncgDI.dwItem = dwItem;
	ncgDI.rItem = &rItem;
	ncgDI.nLevel = nLevel;

	UINT nID = GetDlgCtrlID(GetHwnd());
		
	if (!SendMessage(WM_NCG_POSTDRAWITEM, nID, (LPARAM)&ncgDI))
		::SendMessage(GetParent(), WM_NCG_POSTDRAWITEM, nID, (LPARAM)&ncgDI);
}

void CNcGutter::PostNcDraw(CDC* pDC, const CRect& rWindow)
{
	// try hook window then parent
	NCGDRAWITEM ncgDI;
		
	ncgDI.pDC = pDC;
	ncgDI.rWindow = &rWindow;

	UINT nID = GetDlgCtrlID(GetHwnd());
		
	if (!SendMessage(WM_NCG_POSTNCDRAW, nID, (LPARAM)&ncgDI))
		::SendMessage(GetParent(), WM_NCG_POSTNCDRAW, nID, (LPARAM)&ncgDI);
}

DWORD CNcGutter::GetNextItem(DWORD dwItem)
{
	// try hook window then parent
	UINT nID = GetDlgCtrlID(GetHwnd());
	DWORD dwNextItem = (DWORD)SendMessage(WM_NCG_GETNEXTITEM, nID, dwItem);

	if (!dwNextItem)
		dwNextItem = (DWORD)::SendMessage(GetParent(), WM_NCG_GETNEXTITEM, nID, dwItem);

	return dwNextItem;
}

int CNcGutter::RecalcGutterWidth()
{
	if (!IsHooked())
		return 0;

	// try hook window then parent
	UINT nID = GetDlgCtrlID(GetHwnd());
	int nGutter = 0;
	int nCol = m_aColumns.GetSize();

	CWindowDC dc(GetCWnd());

	CFont* pFont = GetCWnd()->GetFont();
	CFont* pOldFont = NULL;

	if (pFont)
		pOldFont = dc.SelectObject(pFont);
	else
		dc.SelectStockObject(ANSI_VAR_FONT);

	NCGRECALCCOLUMN ncrc;
	ncrc.pDC = &dc;

	while (nCol--)
	{
		// check if its a fixed size column
		COLUMNDESC& cd = m_aColumns[nCol];

		if (cd.bCalcWidth)
		{
			ncrc.nColPos = nCol;
			ncrc.nWidth = 0;

			if (!SendMessage(WM_NCG_RECALCCOLWIDTH, nID, (LPARAM)&ncrc))
				::SendMessage(GetParent(), WM_NCG_RECALCCOLWIDTH, nID, (LPARAM)&ncrc);

			cd.nWidth = ncrc.nWidth;
		}
		nGutter += cd.nWidth;
	}

	return nGutter;
}

CRect CNcGutter::GetItemRect(DWORD dwItem)
{
	// try hook window then parent
	UINT nID = GetDlgCtrlID(GetHwnd());
	NCGITEMRECT ncgGI;
	ncgGI.dwItem = dwItem;

	if (!SendMessage(WM_NCG_GETITEMRECT, nID, (LPARAM)&ncgGI))
		::SendMessage(GetParent(), WM_NCG_GETITEMRECT, nID, (LPARAM)&ncgGI);

	return ncgGI.rItem;
}

DWORD CNcGutter::GetFirstChildItem(DWORD dwItem)
{
	// try hook window then parent
	UINT nID = GetDlgCtrlID(GetHwnd());
	DWORD dwChildItem = (DWORD)SendMessage(WM_NCG_GETFIRSTCHILDITEM, nID, dwItem);

	if (!dwChildItem)
		dwChildItem = (DWORD)::SendMessage(GetParent(), WM_NCG_GETFIRSTCHILDITEM, nID, dwItem);

	return dwChildItem;
}

DWORD CNcGutter::GetSelectedItem()
{
	// try hook window then parent
	UINT nID = GetDlgCtrlID(GetHwnd());

	DWORD dwItem = (DWORD)SendMessage(WM_NCG_GETSELECTEDITEM, nID, 0);

	if (!dwItem)
		dwItem = (DWORD)::SendMessage(GetParent(), WM_NCG_GETSELECTEDITEM, nID, 0);

	// else
	return dwItem;
}

DWORD CNcGutter::HitTest(CPoint point)
{
	// try hook window then parent
	UINT nID = GetDlgCtrlID(GetHwnd());

	DWORD dwItem = (DWORD)SendMessage(WM_NCG_HITTEST, nID, MAKELONG(point.x, point.y));

	if (!dwItem)
		dwItem = (DWORD)::SendMessage(GetParent(), WM_NCG_HITTEST, nID, MAKELONG(point.x, point.y));

	// else
	return dwItem;
}

BOOL CNcGutter::SetSelectedItem(DWORD dwItem)
{
	// try hook window then parent
	UINT nID = GetDlgCtrlID(GetHwnd());

	if (!SendMessage(WM_NCG_SETSELECTEDITEM, nID, dwItem))
		return ::SendMessage(GetParent(), WM_NCG_SETSELECTEDITEM, nID, dwItem);

	// else
	return TRUE;
}

BOOL CNcGutter::NotifyItemClicked(DWORD dwItem)
{
	// try hook window _and_ parent
	UINT nID = GetDlgCtrlID(GetHwnd());

	if (SendMessage(WM_NCG_NOTIFYITEMCLICK, nID, dwItem))
		return TRUE;

	return ::SendMessage(GetParent(), WM_NCG_NOTIFYITEMCLICK, nID, dwItem);
}

int CNcGutter::ColumnHitTest(CPoint ptScreen)
{
	CRect rWindow;
	GetWindowRect(rWindow);

	ptScreen.Offset(-rWindow.TopLeft());

	if (ptScreen.x <= 0)
		return 0;

	int nCol = m_aColumns.GetSize();
	DWORD nGutter = GetGutterWidth();

	// check if we're on the right most limit
	if (ptScreen.x > (LONG)nGutter)
	{
		CRect rClient;
		GetClientRect(rClient);
		ClientToScreen(rClient);
		rClient.OffsetRect(-rWindow.TopLeft());

		if (ptScreen.x < rClient.left)
			return nCol - 1; // last column
		else
			return NCG_CLIENTCOLUMN; // client area
	}

	while (nCol--)
	{
		int nColWidth = m_aColumns[nCol].nWidth;

		if (ptScreen.x >= (LONG)(nGutter - nColWidth) && ptScreen.x <= (LONG)nGutter)
			return nCol;

		nGutter -= nColWidth;
	}

	return -1; // ?? 
}

BOOL CNcGutter::PrepareBitmap(CDC* pDC, CBitmap* pBitmap, const CRect& rect, BOOL bClient)
{
	BOOL bRecreate = !pBitmap->GetSafeHandle();

	if (!bRecreate)
	{
		BITMAP BM;

		bRecreate = (!pBitmap->GetBitmap(&BM));

		if (!bRecreate)
		{
			int nBitDepth = pDC->GetDeviceCaps(BITSPIXEL);

			bRecreate = (nBitDepth != BM.bmBitsPixel || 
						rect.Width() > BM.bmWidth ||
						rect.Height() > BM.bmHeight);
		}
	}

	if (bRecreate)
	{
		pBitmap->DeleteObject();
		pBitmap->CreateCompatibleBitmap(pDC, rect.Width(), rect.Height());
		TRACE("CNcGutter::PrepareBitmap(recreating %s bitmap)\n", bClient ? "client" : "non-client");
	}

	return (NULL != pBitmap->GetSafeHandle());
}

