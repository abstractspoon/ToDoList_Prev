// ToDoList.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "ToDoList.h"
#include "ToDoListDlg.h"

#include "..\shared\LimitSingleInstance.h"
#include "..\shared\encommandlineinfo.h"

#include <afxpriv.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CLimitSingleInstance g_SingleInstanceObj(_T("{3A4EFC98-9BA9-473D-A3CF-6B0FE644470D}")); 

BOOL CALLBACK FindOtherInstance(HWND hwnd, LPARAM lParam);

/////////////////////////////////////////////////////////////////////////////
// CToDoListApp

BEGIN_MESSAGE_MAP(CToDoListApp, CWinApp)
	//{{AFX_MSG_MAP(CToDoListApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CToDoListApp construction

CToDoListApp::CToDoListApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CToDoListApp object

CToDoListApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CToDoListApp initialization

BOOL CToDoListApp::InitInstance()
{
	AfxOleInit(); // for handling drag and drop via explorer

	CEnCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	if (g_SingleInstanceObj.IsAnotherInstanceRunning())
	{
		HWND hWnd = NULL;
		EnumWindows(FindOtherInstance, (LPARAM)&hWnd);
		
		if (hWnd)
		{
			SendMessage(hWnd, WM_TDL_SHOWWINDOW, 0, 0);

			// pass on file to open
			if (!cmdInfo.m_strFileName.IsEmpty())
			{
				COPYDATASTRUCT cds;

				cds.dwData = OPENTASKLIST;
				cds.cbData = MAX_PATH;
				cds.lpData = (LPVOID)cmdInfo.m_strFileName.GetBuffer(MAX_PATH);

				SendMessage(hWnd, WM_COPYDATA, NULL, (LPARAM)&cds);
				
				cmdInfo.m_strFileName.ReleaseBuffer();
			}

			return FALSE;
		}
	}

	SetRegistryKey(_T("AbstractSpoon"));

	BOOL bForceVisible = cmdInfo.GetOption("v");

	CToDoListDlg dlg(bForceVisible, cmdInfo.m_strFileName);

	m_pMainWnd = &dlg;

	dlg.DoModal();

	return FALSE;
}

int CToDoListApp::ExitInstance() 
{
	return CWinApp::ExitInstance();
}

BOOL CToDoListApp::OnIdle(LONG lCount) 
{
	return CWinApp::OnIdle(lCount);
}

BOOL CALLBACK FindOtherInstance(HWND hwnd, LPARAM lParam)
{
	CString sCaption;

	int nLen = ::GetWindowTextLength(hwnd);
	::GetWindowText(hwnd, sCaption.GetBuffer(nLen + 1), nLen + 1);
	sCaption.ReleaseBuffer();
	sCaption.MakeLower();

	if (sCaption.Find("todolist � abstractspoon") != -1)
	{
		HWND* pWnd = (HWND*)lParam;
		*pWnd = hwnd;
		return FALSE;
	}

	return TRUE;
}


BOOL CToDoListApp::PreTranslateMessage(MSG* pMsg) 
{
	// give first chance to main window for handling accelerators
	if (m_pMainWnd && m_pMainWnd->PreTranslateMessage(pMsg))
		return TRUE;

	return CWinApp::PreTranslateMessage(pMsg);
}

