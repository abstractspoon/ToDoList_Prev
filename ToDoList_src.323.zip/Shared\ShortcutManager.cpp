// ShortcutManager.cpp: implementation of the CShortcutManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ShortcutManager.h"
#include "wclassdefines.h"
#include "runtimedlg.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

enum
{
	VK_0 = 0x30,
	VK_9 = 0x39,
	VK_A = 0x41,
	VK_Z = 0x5A,
};

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CShortcutManager::CShortcutManager(BOOL bAutoSendCmds) : m_bAutoSendCmds(bAutoSendCmds), m_wInvalidComb(0)
{

}

CShortcutManager::~CShortcutManager()
{

}

BOOL CShortcutManager::Initialize(WORD wInvalidComb)
{
	if (wInvalidComb && !IsHooked())
	{
		CWnd* pWnd = AfxGetMainWnd();
		
		if (pWnd && HookWindow(*pWnd))
		{
			m_wInvalidComb = wInvalidComb;
			LoadSettings();

			return TRUE;
		}
	}

	return FALSE;
}

void CShortcutManager::PreDetachWindow()
{
	SaveSettings();
}

void CShortcutManager::SetShortcut(UINT nCmdID, WORD wVirtKeyCode, WORD wModifiers)
{
	UINT nOtherCmdID = 0;
	DWORD dwShortcut = MAKELONG(wVirtKeyCode, wModifiers);

	// if the shortcut == 0 then remove the existing shortcut associated with nCmdID
	if (!dwShortcut)
	{
		m_mapID2Shortcut.Lookup(nCmdID, dwShortcut);

		m_mapShortcut2ID.RemoveKey(dwShortcut);
		m_mapID2Shortcut.RemoveKey(nCmdID);

		return;
	}
	// check for existing cmds using this shortcut to remove
	else if (m_mapShortcut2ID.Lookup(dwShortcut, nOtherCmdID))
	{
		m_mapShortcut2ID.RemoveKey(dwShortcut);
		m_mapID2Shortcut.RemoveKey(nOtherCmdID);
	}

	// then simple add
	AddShortcut(nCmdID, wVirtKeyCode, wModifiers);
}

void CShortcutManager::SetShortcut(UINT nCmdID, DWORD dwShortcut)
{
	SetShortcut(nCmdID, LOWORD(dwShortcut), HIWORD(dwShortcut));
}

BOOL CShortcutManager::AddShortcut(UINT nCmdID, DWORD dwShortcut)
{
	return AddShortcut(nCmdID, LOWORD(dwShortcut), HIWORD(dwShortcut));
}

BOOL CShortcutManager::AddShortcut(UINT nCmdID, WORD wVirtKeyCode, WORD wModifiers)
{
	// check for existing cmds using this shortcut
	DWORD dwShortcut = MAKELONG(wVirtKeyCode, wModifiers);

	if (!nCmdID || !dwShortcut)
		return FALSE;

	UINT nOtherCmdID = 0;

	if (m_mapShortcut2ID.Lookup(dwShortcut, nOtherCmdID) && nOtherCmdID)
		return FALSE;

	// check for existing shortcut on this cmd that we'll need to clean up
	DWORD dwOtherShortcut = 0;

	if (m_mapID2Shortcut.Lookup(nCmdID, dwOtherShortcut))
		m_mapShortcut2ID.RemoveKey(dwOtherShortcut);

	// test for invalid combinations
	BOOL bCtrl = (wModifiers & HOTKEYF_CONTROL);
	BOOL bShift = (wModifiers & HOTKEYF_SHIFT);
	BOOL bAlt = (wModifiers & HOTKEYF_ALT);

	if ((m_wInvalidComb & HKCOMB_NONE) && !bCtrl && !bShift && !bAlt)
		return FALSE;

	if ((m_wInvalidComb & HKCOMB_S) && !bCtrl && bShift && !bAlt)
		return FALSE;

	if ((m_wInvalidComb & HKCOMB_C) && bCtrl && !bShift && !bAlt)
		return FALSE;

	if ((m_wInvalidComb & HKCOMB_A) && !bCtrl && !bShift && bAlt)
		return FALSE;

	if ((m_wInvalidComb & HKCOMB_SC) && bCtrl && bShift && !bAlt)
		return FALSE;

	if ((m_wInvalidComb & HKCOMB_SA) && !bCtrl && bShift && bAlt)
		return FALSE;

	if ((m_wInvalidComb & HKCOMB_CA) && bCtrl && !bShift && bAlt)
		return FALSE;

	if ((m_wInvalidComb & HKCOMB_SCA) && bCtrl && bShift && bAlt)
		return FALSE;

	m_mapShortcut2ID[dwShortcut] = nCmdID;
	m_mapID2Shortcut[nCmdID] = dwShortcut;

	return TRUE;
}

DWORD CShortcutManager::GetShortcut(WORD wVirtKeyCode, BOOL bExtended) const
{
	BOOL bCtrl = (GetKeyState(VK_CONTROL) & 0x8000);
	BOOL bShift = (GetKeyState(VK_SHIFT) & 0x8000);
	BOOL bAlt = (GetKeyState(VK_MENU) & 0x8000);

	WORD wModifiers = (bCtrl ? HOTKEYF_CONTROL : 0) |
						(bShift ? HOTKEYF_SHIFT : 0) |
						(bAlt ? HOTKEYF_ALT : 0) |
						(bExtended ? HOTKEYF_EXT : 0);

	return MAKELONG(wVirtKeyCode, wModifiers);
}

UINT CShortcutManager::ProcessMessage(MSG* pMsg) const
{
	// only process accelerators if we are not disabled and visible
	if (!IsWindowEnabled() || !IsWindowVisible())
		return FALSE;

	switch (pMsg->message)
	{
	case WM_KEYDOWN:
	case WM_SYSKEYDOWN: // usually <alt> + ...
		{
			switch (pMsg->wParam)
			{
			case VK_CONTROL:
			case VK_SHIFT:
			case VK_MENU:
				return FALSE;

			// don't handle return/cancel keys
			case VK_RETURN:
			case VK_CANCEL:
				return FALSE;

			// shortcut keys
			default: 
				{
					// get DWORD shortcut
					BOOL bExtKey = (pMsg->lParam & 0x01000000);
					DWORD dwShortcut = GetShortcut((WORD)pMsg->wParam, bExtKey);

					// look it up
					UINT nCmdID = 0;

					if (!m_mapShortcut2ID.Lookup(dwShortcut, nCmdID) || !nCmdID)
						return FALSE;

					// make sure its not a keypress that reasonably might be processed
					// by the control to whom its being sent
					// NEEDS MORE THOUGHT
/*					CString sClass = CRuntimeDlg::GetControlClassName(CWnd::FromHandle(pMsg->hwnd));

					// if its an edit and there are no ctrl/alt modifiers then don't process
					if (sClass.CompareNoCase("edit") == 0)
					{
						WORD wModifiers = HIWORD(dwShortcut);

						if (!(wModifiers & (HOTKEYF_CONTROL | HOTKEYF_ALT))
							return 0;
					}
*/
					// return command ID
					if (m_bAutoSendCmds)
						SendMessage(WM_COMMAND, nCmdID);

					return nCmdID;
				}
			}
		}
	}

	return FALSE;
}

LRESULT CShortcutManager::WindowProc(HWND hRealWnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg)
	{
	case WM_INITMENUPOPUP:
		{
			PrepareMenuItems(CMenu::FromHandle((HMENU)wp));
		}
		break;
	}

	return CSubclassWnd::WindowProc(hRealWnd, msg, wp, lp);
}

void CShortcutManager::PrepareMenuItems(CMenu* pMenu) const
{
	if (!pMenu || !pMenu->GetSafeHmenu())
		return;

	// we iterate all the menu items
	// if we find a match we get the menu text and add the shortcut
	// first removing any existing one
	int nItem = pMenu->GetMenuItemCount();

	while (nItem--)
	{
		UINT nCmdID = pMenu->GetMenuItemID(nItem);
		DWORD dwShortcut = GetShortcut(nCmdID);

		if (dwShortcut)
		{
			CString sShortcut = GetShortcutText(dwShortcut);

			if (!sShortcut.IsEmpty())
			{
				CString sMenuText;
				pMenu->GetMenuString(nItem, sMenuText, MF_BYPOSITION);

				// look for '\t' indicating existing hint
				int nTab = sMenuText.Find('\t');

				// remove it
				if (nTab >= 0)
					sMenuText = sMenuText.Left(nTab + 1);
				else
					sMenuText += '\t';

				// add new hint
				sMenuText += sShortcut;

				pMenu->ModifyMenu(nItem, MF_BYPOSITION, nCmdID, sMenuText);
			}
		}
	}
}

DWORD CShortcutManager::GetShortcut(UINT nCmdID) const
{
	DWORD dwShortcut = 0;

	m_mapID2Shortcut.Lookup(nCmdID, dwShortcut);
	
	return dwShortcut;
}

BOOL CShortcutManager::IsAlphaNum(WORD wVKCode)
{
	return ((wVKCode >= VK_0 && wVKCode <= VK_9) || (wVKCode >= VK_A && wVKCode <= VK_Z));
}

CString CShortcutManager::GetShortcutText(DWORD dwShortcut)
{
	CString sText;

	WORD wVirtKeyCode = LOWORD(dwShortcut);
	WORD wModifiers = HIWORD(dwShortcut);

	if (wModifiers & HOTKEYF_CONTROL)
		sText += "Ctrl+";

	if (wModifiers & HOTKEYF_SHIFT)
		sText += "Shift+";

	if (wModifiers & HOTKEYF_ALT)
		sText += "Alt+";

	if (IsAlphaNum(wVirtKeyCode))
		sText += (char)toupper(wVirtKeyCode);
	else
	{
		CString sKey;

		// needs special translation
		switch (wVirtKeyCode)
		{
		case VK_BACK: sKey = "Backspace"; break;
		case VK_TAB: sKey = "Tab"; break;
		case VK_RETURN: sKey = "Enter"; break;
		case VK_PAUSE: sKey = "Pause"; break;
		case VK_ESCAPE: sKey = "Escape"; break;
		case VK_SPACE: sKey = "Space"; break;
		case VK_PRIOR: sKey = "PageUp"; break;
		case VK_NEXT: sKey = "PageDown"; break;
		case VK_END: sKey = "End"; break;
		case VK_HOME: sKey = "Home"; break;
		case VK_LEFT: sKey = "Left"; break;
		case VK_RIGHT: sKey = "Right"; break;
		case VK_UP: sKey = "Up"; break;
		case VK_DOWN: sKey = "Down"; break;
		case VK_SNAPSHOT: sKey = "PrintScrn"; break;
		case VK_INSERT: sKey = "Insert"; break;
		case VK_DELETE: sKey = "Delete"; break;
		case VK_F1: sKey = "F1"; break;
		case VK_F2: sKey = "F2"; break;
		case VK_F3: sKey = "F3"; break;
		case VK_F4: sKey = "F4"; break;
		case VK_F5: sKey = "F5"; break;
		case VK_F6: sKey = "F6"; break;
		case VK_F7: sKey = "F7"; break;
		case VK_F8: sKey = "F8"; break;
		case VK_F9: sKey = "F9"; break;
		case VK_F10: sKey = "F10"; break;
		case VK_F11: sKey = "F11"; break;
		case VK_F12: sKey = "F12"; break;
		case VK_F13: sKey = "F13"; break;
		case VK_F14: sKey = "F14"; break;
		case VK_F15: sKey = "F15"; break;
		case VK_F16: sKey = "F16"; break;
		case VK_F17: sKey = "F17"; break;
		case VK_F18: sKey = "F18"; break;
		case VK_F19: sKey = "F19"; break;
		case VK_F20: sKey = "F20"; break;
		case VK_F21: sKey = "F21"; break;
		case VK_F22: sKey = "F22"; break;
		case VK_F23: sKey = "F23"; break;
		case VK_F24: sKey = "F24"; break;
		}

		if (sKey.IsEmpty())
			return "";
		else
			sText += sKey;
	}

	return sText;
}

void CShortcutManager::LoadSettings()
{
	int nItem = AfxGetApp()->GetProfileInt("KeyboardShortcuts", "NumItems", 0);

	while (nItem--)
	{
		CString sKey;
		sKey.Format("KeyboardShortcuts\\Item%02d", nItem);

		UINT nCmdID = (UINT)AfxGetApp()->GetProfileInt(sKey, "CmdID", 0);
		DWORD dwShortcut = (DWORD)AfxGetApp()->GetProfileInt(sKey, "Shortcut", 0);

		if (nCmdID && dwShortcut)
			AddShortcut(nCmdID, dwShortcut);
	}
}

void CShortcutManager::SaveSettings()
{
	AfxGetApp()->WriteProfileInt("KeyboardShortcuts", "NumItems", m_mapID2Shortcut.GetCount());

	POSITION pos = m_mapID2Shortcut.GetStartPosition();
	int nItem = 0;

	while (pos)
	{
		UINT nCmdID = 0;
		DWORD dwShortcut = 0;

		m_mapID2Shortcut.GetNextAssoc(pos, nCmdID, dwShortcut);

		if (nCmdID && dwShortcut)
		{
			CString sKey;
			sKey.Format("KeyboardShortcuts\\Item%02d", nItem);

			AfxGetApp()->WriteProfileInt(sKey, "CmdID", nCmdID);
			AfxGetApp()->WriteProfileInt(sKey, "Shortcut", dwShortcut);

			nItem++;
		}
	}
}
