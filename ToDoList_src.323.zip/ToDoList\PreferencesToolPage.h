#if !defined(AFX_PREFERENCESTOOLPAGE_H__6B9BF0B2_D6DE_4868_B97E_8F6288C77778__INCLUDED_)
#define AFX_PREFERENCESTOOLPAGE_H__6B9BF0B2_D6DE_4868_B97E_8F6288C77778__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesToolPage.h : header file
//

#include "..\shared\fileedit.h"
#include "..\shared\sysimagelist.h"

#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////
// CPreferencesToolPage dialog

struct USERTOOL
{
	CString sToolName;
	CString sToolPath;
	CString sCmdline;
	BOOL bRunMinimized;
};

typedef CArray<USERTOOL, USERTOOL&> CUserToolArray;

class CPreferencesToolPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPreferencesToolPage)

// Construction
public:
	CPreferencesToolPage();
	~CPreferencesToolPage();

	int GetUserTools(CUserToolArray& aTools); // returns the number of tools

protected:

// Dialog Data
	//{{AFX_DATA(CPreferencesToolPage)
	enum { IDD = IDD_PREFTOOLS_PAGE };
	CButton	m_btPlaceholders;
	CEdit	m_eCmdLine;
	CFileEdit	m_eToolPath;
	CListCtrl	m_lcTools;
	CString	m_sToolPath;
	CString	m_sCommandLine;
	BOOL	m_bRunMinimized;
	//}}AFX_DATA
	CUserToolArray m_aTools;
	CSysImageList m_ilSys;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesToolPage)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesToolPage)
	afx_msg void OnNewtool();
	afx_msg void OnDeletetool();
	afx_msg void OnEndlabeleditToollist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemchangedToollist(NMHDR* pNMHDR, LRESULT* pResult);
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeToolpath();
	afx_msg void OnKeydownToollist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnChangeCmdline();
	afx_msg void OnDisplayPlaceholders();
	afx_msg void OnInsertPlaceholder(UINT nCmdID);
	afx_msg void OnRunminimized();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void EnableControls();
	int GetCurSel();

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESTOOLPAGE_H__6B9BF0B2_D6DE_4868_B97E_8F6288C77778__INCLUDED_)
