// PreferencesTaskPage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesTaskPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesTaskPage property page

IMPLEMENT_DYNCREATE(CPreferencesTaskPage, CPropertyPage)

CPreferencesTaskPage::CPreferencesTaskPage() : CPropertyPage(CPreferencesTaskPage::IDD)
{
	m_psp.dwFlags &= ~PSP_HASHELP;

	//{{AFX_DATA_INIT(CPreferencesTaskPage)
	m_bHideZeroTimeEst = FALSE;
	m_bHideStartDueForDoneTasks = FALSE;
	//}}AFX_DATA_INIT

	// load settings
	m_nDefPriority = AfxGetApp()->GetProfileInt("Preferences", "DefaultPriority", 5);
	m_sDefPerson = AfxGetApp()->GetProfileString("Preferences", "DefaultPerson", "");
	m_nDefTimeEst = AfxGetApp()->GetProfileInt("Preferences", "DefaultTimeEstimate", 0);
	m_crDef = AfxGetApp()->GetProfileInt("Preferences", "DefaultColor", 0);
	m_bUseParentAttributes = AfxGetApp()->GetProfileInt("Preferences", "UseParentAttributes", TRUE);
	m_bUseParentColorAttrib = AfxGetApp()->GetProfileInt("Preferences", "UseParentColorAttrib", TRUE);
	m_bUseParentPersonAttrib = AfxGetApp()->GetProfileInt("Preferences", "UseParentPersonAttrib", TRUE);
	m_bUseParentPriorityAttrib = AfxGetApp()->GetProfileInt("Preferences", "UseParentPriorityAttrib", TRUE);
	m_bUseParentTimeEstAttrib = AfxGetApp()->GetProfileInt("Preferences", "UseParentTimeEstAttrib", TRUE);
	m_bAutoReSort = AfxGetApp()->GetProfileInt("Preferences", "AutoReSort", FALSE);
	m_bTreatSubCompletedAsDone = AfxGetApp()->GetProfileInt("Preferences", "TreatSubCompletedAsDone", TRUE);
	m_bHidePercentForDoneTasks = AfxGetApp()->GetProfileInt("Preferences", "HidePercentForDoneTasks", TRUE);
	m_bHideStartDueForDoneTasks = AfxGetApp()->GetProfileInt("Preferences", "HideStartDueForDoneTasks", TRUE);
	m_bAveragePercentSubCompletion = AfxGetApp()->GetProfileInt("Preferences", "AveragePercentSubCompletion", FALSE);
	m_bIncludeDoneInAverageCalc = AfxGetApp()->GetProfileInt("Preferences", "IncludeDoneInAverageCalc", TRUE);
	m_bUseEarliestDueDate = AfxGetApp()->GetProfileInt("Preferences", "UseEarliestDueDate", FALSE);
	m_bUsePercentDoneInTimeEst = AfxGetApp()->GetProfileInt("Preferences", "UsePercentDoneInTimeEst", TRUE);
	m_bUseCreationForDefStartDate = AfxGetApp()->GetProfileInt("Preferences", "UseCreationForDefStartDate", TRUE);
	m_bHideZeroTimeEst = AfxGetApp()->GetProfileInt("Preferences", "HideZeroTimeEst", TRUE);
	m_bShowPercentAsProgressbar = AfxGetApp()->GetProfileInt("Preferences", "ShowPercentAsProgressbar", FALSE);
}

CPreferencesTaskPage::~CPreferencesTaskPage()
{
}

void CPreferencesTaskPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesTaskPage)
	DDX_CBIndex(pDX, IDC_DEFAULTPRIORITY, m_nDefPriority);
	DDX_Text(pDX, IDC_DEFAULTTIMEEST, m_nDefTimeEst);
	DDX_Text(pDX, IDC_DEFAULTPERSON, m_sDefPerson);
	DDX_Check(pDX, IDC_AUTORESORT, m_bAutoReSort);
	DDX_Check(pDX, IDC_USEPARENTATTRIB, m_bUseParentAttributes);
	DDX_Check(pDX, IDC_USEPARENTCOLORATTRIB, m_bUseParentColorAttrib);
	DDX_Check(pDX, IDC_USEPARENTPERSONATTRIB, m_bUseParentPersonAttrib);
	DDX_Check(pDX, IDC_USEPARENTPRIORITYATTRIB, m_bUseParentPriorityAttrib);
	DDX_Check(pDX, IDC_USEPARENTTIMEESTATTRIB, m_bUseParentTimeEstAttrib);
	DDX_Check(pDX, IDC_USECREATIONFORDEFSTARTDATE, m_bUseCreationForDefStartDate);
	DDX_Check(pDX, IDC_HIDEUNDEFINEDTIMEST, m_bHideZeroTimeEst);
	DDX_Check(pDX, IDC_TREATSUBCOMPLETEDASDONE, m_bTreatSubCompletedAsDone);
	DDX_Check(pDX, IDC_HIDESTARTDUEFORDONETASKS, m_bHideStartDueForDoneTasks);
	//}}AFX_DATA_MAP
	DDX_Check(pDX, IDC_SHOWPERCENTPROGRESSBAR, m_bShowPercentAsProgressbar);
	DDX_Control(pDX, IDC_SETDEFAULTCOLOR, m_btDefColor);
	DDX_Check(pDX, IDC_USEEARLIESTDUEDATE, m_bUseEarliestDueDate);
	DDX_Check(pDX, IDC_USEPERCENTDONEINTIMEEST, m_bUsePercentDoneInTimeEst);
	DDX_Check(pDX, IDC_HIDEPERCENTFORDONETASKS, m_bHidePercentForDoneTasks);
	DDX_Check(pDX, IDC_AVERAGEPERCENTSUBCOMPLETION, m_bAveragePercentSubCompletion);
	DDX_Check(pDX, IDC_INCLUDEDONEINAVERAGECALC, m_bIncludeDoneInAverageCalc);
}


BEGIN_MESSAGE_MAP(CPreferencesTaskPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPreferencesTaskPage)
	ON_BN_CLICKED(IDC_SETDEFAULTCOLOR, OnSetdefaultcolor)
	ON_BN_CLICKED(IDC_USEPARENTATTRIB, OnUseparentattrib)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_AVERAGEPERCENTSUBCOMPLETION, OnAveragepercentChange)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesTaskPage message handlers

BOOL CPreferencesTaskPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	GetDlgItem(IDC_INCLUDEDONEINAVERAGECALC)->EnableWindow(m_bAveragePercentSubCompletion);
	GetDlgItem(IDC_USEPARENTPERSONATTRIB)->EnableWindow(m_bUseParentAttributes);
	GetDlgItem(IDC_USEPARENTPRIORITYATTRIB)->EnableWindow(m_bUseParentAttributes);
	GetDlgItem(IDC_USEPARENTTIMEESTATTRIB)->EnableWindow(m_bUseParentAttributes);
	GetDlgItem(IDC_USEPARENTCOLORATTRIB)->EnableWindow(m_bUseParentAttributes);
	
	m_btDefColor.SetColor(m_crDef);
		
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

COleDateTime CPreferencesTaskPage::GetDefaultStartDate()
{
	if (m_bUseCreationForDefStartDate)
		return COleDateTime::GetCurrentTime();

	// else
	return 0.0;
}

void CPreferencesTaskPage::OnSetdefaultcolor() 
{
	m_crDef = m_btDefColor.GetColor();
}

void CPreferencesTaskPage::OnUseparentattrib() 
{
	UpdateData();

	GetDlgItem(IDC_USEPARENTPERSONATTRIB)->EnableWindow(m_bUseParentAttributes);
	GetDlgItem(IDC_USEPARENTPRIORITYATTRIB)->EnableWindow(m_bUseParentAttributes);
	GetDlgItem(IDC_USEPARENTTIMEESTATTRIB)->EnableWindow(m_bUseParentAttributes);
	GetDlgItem(IDC_USEPARENTCOLORATTRIB)->EnableWindow(m_bUseParentAttributes);
}

void CPreferencesTaskPage::OnOK() 
{
	CPropertyPage::OnOK();
	
	// save settings
	AfxGetApp()->WriteProfileInt("Preferences", "DefaultPriority", m_nDefPriority);
	AfxGetApp()->WriteProfileString("Preferences", "DefaultPerson", m_sDefPerson);
	AfxGetApp()->WriteProfileInt("Preferences", "DefaultTimeEstimate", m_nDefTimeEst);
	AfxGetApp()->WriteProfileInt("Preferences", "DefaultColor", m_crDef);
	AfxGetApp()->WriteProfileInt("Preferences", "UseParentAttributes", m_bUseParentAttributes);
	AfxGetApp()->WriteProfileInt("Preferences", "UseParentColorAttrib", m_bUseParentColorAttrib);
	AfxGetApp()->WriteProfileInt("Preferences", "UseParentPersonAttrib", m_bUseParentPersonAttrib);
	AfxGetApp()->WriteProfileInt("Preferences", "UseParentPriorityAttrib", m_bUseParentPriorityAttrib);
	AfxGetApp()->WriteProfileInt("Preferences", "UseParentTimeEstAttrib", m_bUseParentTimeEstAttrib);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoReSort", m_bAutoReSort);
	AfxGetApp()->WriteProfileInt("Preferences", "TreatSubCompletedAsDone", m_bTreatSubCompletedAsDone);
	AfxGetApp()->WriteProfileInt("Preferences", "HidePercentForDoneTasks", m_bHidePercentForDoneTasks);
	AfxGetApp()->WriteProfileInt("Preferences", "HideStartDueForDoneTasks", m_bHideStartDueForDoneTasks);
	AfxGetApp()->WriteProfileInt("Preferences", "AveragePercentSubCompletion", m_bAveragePercentSubCompletion);
	AfxGetApp()->WriteProfileInt("Preferences", "IncludeDoneInAverageCalc", m_bIncludeDoneInAverageCalc);
	AfxGetApp()->WriteProfileInt("Preferences", "UseEarliestDueDate", m_bUseEarliestDueDate);
	AfxGetApp()->WriteProfileInt("Preferences", "UsePercentDoneInTimeEst", m_bUsePercentDoneInTimeEst);
	AfxGetApp()->WriteProfileInt("Preferences", "UseCreationForDefStartDate", m_bUseCreationForDefStartDate);
	AfxGetApp()->WriteProfileInt("Preferences", "HideZeroTimeEst", m_bHideZeroTimeEst);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowPercentAsProgressbar", m_bShowPercentAsProgressbar);
//	AfxGetApp()->WriteProfileInt("Preferences", "", m_b);
}

void CPreferencesTaskPage::OnAveragepercentChange() 
{
	UpdateData();

	GetDlgItem(IDC_INCLUDEDONEINAVERAGECALC)->EnableWindow(m_bAveragePercentSubCompletion);
}

