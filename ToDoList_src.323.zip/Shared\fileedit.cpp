// fileedit.cpp : implementation file
//

#include "stdafx.h"
#include "fileedit.h"
#include "folderdialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileEdit

CFileEdit::CFileEdit(int nStyle) : 
	m_nStyle(nStyle), 
	m_bFirstShow(TRUE), 
	m_bBrowseButtonDown(FALSE), 
	m_bTipNeeded(FALSE),
	ICON_WIDTH(20),
	BUTTON_WIDTH(::GetSystemMetrics(SM_CXHTHUMB))
{
}

CFileEdit::~CFileEdit()
{
}


BEGIN_MESSAGE_MAP(CFileEdit, CEdit)
	//{{AFX_MSG_MAP(CFileEdit)
	ON_WM_PAINT()
	ON_WM_NCPAINT()
	ON_WM_NCLBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_NCCALCSIZE()
	ON_WM_KILLFOCUS()
	ON_WM_NCHITTEST()
	ON_WM_MOUSEMOVE()
	ON_CONTROL_REFLECT_EX(EN_CHANGE, OnChange)
	ON_WM_ENABLE()
	ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_SETTEXT, OnSetText)
	ON_NOTIFY(TTN_NEEDTEXT, 0, OnNeedTooltip)
	ON_NOTIFY(TTN_SHOW, 0, OnShowTooltip)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileEdit message handlers

BOOL CFileEdit::OnChange() 
{
	SendMessage(WM_NCPAINT);
	
	return FALSE;
}

LRESULT CFileEdit::OnSetText(WPARAM wp, LPARAM lp)
{
	LRESULT lr = Default();

	SendMessage(WM_NCPAINT);

	return lr;
}

void CFileEdit::OnPaint() 
{
	m_bTipNeeded = FALSE;

	if (GetFocus() != this)
	{
		CString sText;
		GetWindowText(sText);

		if (sText.IsEmpty())
			Default();
		else
		{
			CPaintDC dc(this); // device context for painting
			dc.SelectStockObject(ANSI_VAR_FONT);
			
			// see if the text length exceeds the client width
			CRect rClient;
			GetClientRect(rClient);

			CSize sizeText = dc.GetTextExtent(sText);

			if (sizeText.cx <= rClient.Width() - 4) // -2 allows for later DeflateRect
			{
				DefWindowProc(WM_PAINT, (WPARAM)(HDC)dc, 0);
			}
			else
			{
				// fill bkgnd
				HBRUSH hBkgnd = NULL;
				
				if (!IsWindowEnabled() || (GetStyle() & ES_READONLY))
					hBkgnd = GetSysColorBrush(COLOR_3DFACE);
				else
					hBkgnd = (HBRUSH)GetParent()->SendMessage(WM_CTLCOLOREDIT, (WPARAM)(HDC)dc, (LPARAM)(HWND)GetSafeHwnd());
				
				if (!hBkgnd || hBkgnd == GetStockObject(NULL_BRUSH))
					hBkgnd = ::GetSysColorBrush(COLOR_WINDOW);
				
				::FillRect(dc, rClient, hBkgnd);
				
				rClient.DeflateRect(1, 1);
				rClient.right -= 2;
				
				dc.SetBkMode(TRANSPARENT);
				
				if (!IsWindowEnabled())
					dc.SetTextColor(::GetSysColor(COLOR_3DSHADOW));
				
				dc.DrawText(sText, rClient, DT_PATH_ELLIPSIS);
				m_bTipNeeded = TRUE;
			}
		}
	}
	else
		Default();
}

void CFileEdit::OnNcPaint() 
{
	if (m_bFirstShow)
	{
		m_bFirstShow = FALSE;
		SetWindowPos(NULL, 0, 0, 0, 0, SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER); 
	}
	
	Default();

	// draw the icon and browse button
	CWindowDC dc(this);

	CRect rWindow;
	GetWindowRect(rWindow);

	if (!HasStyle(FES_NOBROWSE))
	{
		CRect rBrowse = GetBrowseButtonRect();
		rBrowse.OffsetRect(-rWindow.TopLeft());

		if (HasStyle(FES_COMBOBORDERBROWSEBTN))	// mimic combo drop button
		{
			if (m_bBrowseButtonDown)
			{
				dc.Draw3dRect(rBrowse, GetSysColor(COLOR_3DSHADOW), GetSysColor(COLOR_3DSHADOW));
				rBrowse.DeflateRect(1, 1);
				dc.FillSolidRect(rBrowse, GetSysColor(COLOR_3DFACE));
				rBrowse.DeflateRect(2, 2);
			}
			else
			{
				dc.DrawFrameControl(rBrowse, DFC_SCROLL, DFCS_SCROLLCOMBOBOX);
				rBrowse.DeflateRect(3, 3);
			}
		}
		else
		{
			dc.DrawFrameControl(rBrowse, DFC_BUTTON, DFCS_BUTTONPUSH | (m_bBrowseButtonDown ? DFCS_PUSHED : 0));
			rBrowse.DeflateRect(3, 3);
		}

		// draw an ellipsis
		if (m_bBrowseButtonDown)
			rBrowse.OffsetRect(1, 1);

		dc.SelectStockObject(ANSI_VAR_FONT);
		dc.SetBkMode(OPAQUE);
		dc.SetBkColor(GetSysColor(COLOR_3DFACE));

		if (IsWindowEnabled())
			dc.DrawText("���", rBrowse, DT_CENTER | DT_VCENTER);
		else
		{
			// draw embossed
			dc.SetTextColor(GetSysColor(COLOR_3DSHADOW));
			dc.DrawText("���", rBrowse, DT_CENTER | DT_VCENTER);

			rBrowse.OffsetRect(1, 1);
			dc.SetBkMode(TRANSPARENT);
			dc.SetTextColor(GetSysColor(COLOR_3DHIGHLIGHT));
			dc.DrawText("���", rBrowse, DT_CENTER | DT_VCENTER);
		}
	}

	// icon
	// background color
	CRect rIcon = GetIconRect();
	rIcon.OffsetRect(-rWindow.TopLeft());
	
	HBRUSH hBkgnd = NULL;
	
	if (!IsWindowEnabled() || (GetStyle() & ES_READONLY))
		hBkgnd = GetSysColorBrush(COLOR_3DFACE);
	else
		hBkgnd = (HBRUSH)GetParent()->SendMessage(WM_CTLCOLOREDIT, (WPARAM)(HDC)dc, (LPARAM)(HWND)GetSafeHwnd());

	if (!hBkgnd || hBkgnd == GetStockObject(NULL_BRUSH))
		hBkgnd = ::GetSysColorBrush(COLOR_WINDOW);

	::FillRect(dc, rIcon, hBkgnd);

	if (GetWindowTextLength())
	{
		CString sFilePath;
		GetWindowText(sFilePath);

		sFilePath.TrimLeft();
		sFilePath.TrimRight();

		rIcon.top++;
		rIcon.left++;

		int nImage = -1;

		if (HasStyle(FES_FOLDERS))
			nImage = m_ilSys.GetFolderImageIndex();
		else
			nImage = m_ilSys.GetFileImageIndex(sFilePath);

		if (nImage != -1)
			m_ilSys.GetImageList()->Draw(&dc, nImage, rIcon.TopLeft(), ILD_TRANSPARENT);
	}
}

void CFileEdit::OnNcLButtonDown(UINT nHitTest, CPoint point) 
{
	CEdit::OnNcLButtonDown(nHitTest, point);

	if (IsWindowEnabled())
	{
		if (!HasStyle(FES_NOBROWSE) && GetBrowseButtonRect().PtInRect(point))
		{
			SetCapture();
			m_bBrowseButtonDown = TRUE;

			SendMessage(WM_NCPAINT);
		}
		else
			SetFocus();
	}
}

void CFileEdit::OnLButtonUp(UINT nHitTest, CPoint point) 
{
	CEdit::OnNcLButtonUp(nHitTest, point);

	if (m_bBrowseButtonDown && !HasStyle(FES_NOBROWSE))
	{
		ReleaseCapture();
		m_bBrowseButtonDown = FALSE;

		SendMessage(WM_NCPAINT);

		ClientToScreen(&point);

		if (GetBrowseButtonRect().PtInRect(point))
		{
			// show browse dialog
			CString sFilename;
			GetWindowText(sFilename);

			if (HasStyle(FES_FOLDERS))
			{
				CFolderDialog dialog("Select Folder", sFilename);

				if (dialog.DoModal() == IDOK)
				{
					CString sFolder = dialog.GetFolderPath();
					SetWindowText(sFolder);

					// send parent a change notification
					GetParent()->SendMessage(WM_COMMAND, MAKELPARAM(EN_CHANGE, GetDlgCtrlID()), (LPARAM)GetSafeHwnd());
				}
			}
			else
			{
				CFileDialog dialog(TRUE, NULL, sFilename, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "All Files (*.*)|*.*||");
				dialog.m_ofn.lpstrTitle = "Select File";

				if (dialog.DoModal() == IDOK)
				{
					SetWindowText(dialog.GetPathName());

					// send parent a change notification
					GetParent()->SendMessage(WM_COMMAND, MAKELPARAM(EN_CHANGE, GetDlgCtrlID()), (LPARAM)GetSafeHwnd());
				}
			}
		}
	}
}

void CFileEdit::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
	CEdit::OnNcCalcSize(bCalcValidRects, lpncsp);

	if (bCalcValidRects)
	{
		m_bFirstShow = FALSE; // in case we get here before OnNcPaint()

		lpncsp->rgrc[0].left += ICON_WIDTH;

		if (!HasStyle(FES_NOBROWSE))
			lpncsp->rgrc[0].right -= BUTTON_WIDTH;
	}
}

void CFileEdit::OnKillFocus(CWnd* pNewWnd) 
{
	CEdit::OnKillFocus(pNewWnd);
	
	Invalidate();
}

CRect CFileEdit::GetBrowseButtonRect()
{
	CRect rButton;
	GetClientRect(rButton);

	rButton.left = rButton.right;
	rButton.right += BUTTON_WIDTH;

	ClientToScreen(rButton);

	return rButton;
}

CRect CFileEdit::GetIconRect()
{
	CRect rButton;
	GetClientRect(rButton);

	rButton.right = rButton.left;
	rButton.left -= ICON_WIDTH;

	ClientToScreen(rButton);

	return rButton;
}

UINT CFileEdit::OnNcHitTest(CPoint point) 
{
	if (GetBrowseButtonRect().PtInRect(point) || GetIconRect().PtInRect(point))
		return HTBORDER;
	
	return CEdit::OnNcHitTest(point);
}

void CFileEdit::OnMouseMove(UINT nHitTest, CPoint point) 
{
	CEdit::OnMouseMove(nHitTest, point);

	if (m_bBrowseButtonDown)
	{
		ClientToScreen(&point);

		if (!GetBrowseButtonRect().PtInRect(point))
		{
			ReleaseCapture();
			m_bBrowseButtonDown = FALSE;
			SendMessage(WM_NCPAINT);
		}
	}
}

void CFileEdit::OnEnable(BOOL bEnable) 
{
	CEdit::OnEnable(bEnable);
	
	SendMessage(WM_NCPAINT);	
}

void CFileEdit::OnNeedTooltip(NMHDR* pNMHDR, LRESULT* pResult)
{
	// to be thorough we will need to handle UNICODE versions of the message also
	TOOLTIPTEXT* pTTT = (TOOLTIPTEXT*)pNMHDR;
	*pResult = 0;
	
	if (m_bTipNeeded)
	{
		CString sFilePath;
		GetWindowText(sFilePath);
 
		lstrcpyn(pTTT->szText, sFilePath, sizeof(pTTT->szText));
	}
}

void CFileEdit::OnShowTooltip(NMHDR* pNMHDR, LRESULT* pResult)
{
	// hide tip as required
	if (!m_bTipNeeded)
	{
		::SetWindowPos(pNMHDR->hwndFrom, NULL, 0, 0, 0, 0, SWP_HIDEWINDOW | SWP_NOACTIVATE);
		*pResult = TRUE;
	}
}

int CFileEdit::OnToolHitTest(CPoint pt, TOOLINFO* pTI) const
{
	int nHit = MAKELONG(pt.x, pt.y);

	pTI->hwnd = m_hWnd;
	pTI->uId  = GetDlgCtrlID();
	GetClientRect(&pTI->rect);
	pTI->uFlags |= TTF_NOTBUTTON;
	pTI->lpszText = LPSTR_TEXTCALLBACK;

	return nHit;
}

void CFileEdit::PreSubclassWindow() 
{
	EnableToolTips();
	
	CEdit::PreSubclassWindow();
}

void CFileEdit::OnSetFocus(CWnd* pOldWnd) 
{
	CEdit::OnSetFocus(pOldWnd);
	
	Invalidate();	
}
