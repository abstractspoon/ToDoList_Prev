#if !defined(AFX_PREFERENCESUIPAGE_H__5AE787F2_44B0_4A48_8D75_24C6C16B45DF__INCLUDED_)
#define AFX_PREFERENCESUIPAGE_H__5AE787F2_44B0_4A48_8D75_24C6C16B45DF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PreferencesUIPage.h : header file
//

#include "..\shared\colorbutton.h"
#include "..\shared\fontcombobox.h"
#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUIPage dialog

enum PTP_COLUMN
{
	PTPC_PRIORITY,
	PTPC_PERCENT,
	PTPC_TIMEEST,
	PTPC_STARTDATE,
	PTPC_DUEDATE,
	PTPC_DONEDATE,
	PTPC_PERSON,
	PTPC_FILEREF,
	PTPC_POSITION,
	PTPC_ID,
};

const COLORREF GRIDLINECOLOR = RGB(192, 192, 192);

class CPreferencesUIPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CPreferencesUIPage)

// Construction
public:
	CPreferencesUIPage();
	~CPreferencesUIPage();

	BOOL GetColorPriority() { return m_bColorPriority; }
	BOOL GetColorTextByPriority() { return m_bColorPriority && m_bColorTextByPriority; }
	BOOL GetShowInfoTips() { return m_bShowInfoTips; }
	BOOL GetShowComments() { return m_bShowComments; }
	BOOL GetShowColumn(PTP_COLUMN nColumn);
	BOOL GetVaryCommentsHeight() { return m_bVaryCommentsHeight; }
	BOOL GetShowButtonsInTree() { return m_bShowButtonsInTree; }
	BOOL GetShowCtrlsAsColumns() { return m_bShowCtrlsAsColumns; }
	BOOL GetShowCommentsAlways() { return m_bShowCommentsAlways; }
	int GetPriorityColors(CDWordArray& aColors);
	BOOL GetTreeFont(CString& sFaceName, int& nPointSize);
	BOOL GetAutoReposCtrls() { return m_bAutoReposCtrls; }
	BOOL GetShowMenuBar() { return m_bShowMenuBar; }
	COLORREF GetGridlineColor() { return m_bSpecifyGridColor ? m_crGridlines : GRIDLINECOLOR; }

protected:
// Dialog Data
	//{{AFX_DATA(CPreferencesUIPage)
	enum { IDD = IDD_PREFUI_PAGE };
	CColorButton	m_btGridlines;
	CComboBox	m_cbFontSize;
	CFontComboBox	m_cbFonts;
	BOOL	m_bSpecifyTreeFont;
	BOOL	m_bShowCtrlsAsColumns;
	BOOL	m_bShowCommentsAlways;
	BOOL	m_bAutoReposCtrls;
	BOOL	m_bSpecifyGridColor;
	//}}AFX_DATA
	CCheckListBox	m_lbColumnVisibility;
	CColorButton	m_btSetColor;
	CColorButton	m_btLowColor;
	CColorButton	m_btHighColor;
	BOOL	m_bColorTextByPriority;
	BOOL	m_bShowInfoTips;
	BOOL	m_bShowComments;
	BOOL	m_bShowPercentColumn;
	BOOL	m_bShowPriorityColumn;
	BOOL	m_bColorPriority;
	BOOL	m_bVaryCommentsHeight;
	BOOL	m_bShowButtonsInTree;
	int		m_bIndividualPriorityColors;
	int		m_nSelPriorityColor;
	BOOL	m_bShowTimeColumn;
	int		m_nSelColumnVisibility;
	CDWordArray m_aPriorityColors;
	COLORREF m_crLow, m_crHigh;
	CString m_sTreeFont;
	int		m_nFontSize;
	BOOL	m_bShowMenuBar;
	COLORREF m_crGridlines;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPreferencesUIPage)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
public:
	virtual void OnOK();

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPreferencesUIPage)
	afx_msg void OnSpecifytreefont();
	afx_msg void OnSetgridlinecolor();
	afx_msg void OnSpecifygridlinecolor();
	//}}AFX_MSG
	virtual BOOL OnInitDialog();
	afx_msg void OnLowprioritycolor();
	afx_msg void OnHighprioritycolor();
	afx_msg void OnSetprioritycolor();
	afx_msg void OnChangePriorityColorOption();
	afx_msg void OnColorPriority();
	afx_msg void OnSelchangePrioritycolors();
	afx_msg void OnColVisibilityChange();
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PREFERENCESUIPAGE_H__5AE787F2_44B0_4A48_8D75_24C6C16B45DF__INCLUDED_)
