// PreferencesFilePage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesFilePage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesFilePage property page

const int CB2INDENT[] = { 1, 2, 4, 8 };
const int CB2FREQ[] = { 1, 2, 5, 10, 15 };

IMPLEMENT_DYNCREATE(CPreferencesFilePage, CPropertyPage)

CPreferencesFilePage::CPreferencesFilePage() : 
		CPropertyPage(CPreferencesFilePage::IDD),
		m_eExportFolderPath(FES_FOLDERS | FES_COMBOBORDERBROWSEBTN)
{
	m_psp.dwFlags &= ~PSP_HASHELP;

	//{{AFX_DATA_INIT(CPreferencesFilePage)
	m_bExportToFolder = FALSE;
	//}}AFX_DATA_INIT
	m_bRemoveArchivedTasks = AfxGetApp()->GetProfileInt("Preferences", "RemoveArchivedTasks", TRUE);
	m_bRemoveOnlyOnAbsoluteCompletion = AfxGetApp()->GetProfileInt("Preferences", "RemoveOnlyOnAbsoluteCompletion", TRUE);
	m_sHtmlFont = AfxGetApp()->GetProfileString("Preferences", "HTMLFont", "Verdana");
	m_bPreviewSaveAs = AfxGetApp()->GetProfileInt("Preferences", "PreviewSaveAs", TRUE);
	m_nTextIndent = AfxGetApp()->GetProfileInt("Preferences", "TextIndent", 2);
	m_nAutoSaveFrequency = AfxGetApp()->GetProfileInt("Preferences", "AutoSaveFrequency", 0);
	m_bAutoSave = (m_nAutoSaveFrequency > 0);
	m_bExportVisibleOnly = AfxGetApp()->GetProfileInt("Preferences", "ExportVisibleOnly", FALSE);
	m_bAutoHtmlExport = AfxGetApp()->GetProfileInt("Preferences", "AutoHtmlExport", FALSE);
	m_bExportIncompleteOnly = AfxGetApp()->GetProfileInt("Preferences", "ExportIncompleteOnly", FALSE);
	m_sExportFolderPath = AfxGetApp()->GetProfileString("Preferences", "ExportFolderPath", "");

	m_sExportFolderPath.TrimLeft();
	m_sExportFolderPath.TrimRight();

	m_bExportToFolder = !m_sExportFolderPath.IsEmpty();
}

CPreferencesFilePage::~CPreferencesFilePage()
{
}

void CPreferencesFilePage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesFilePage)
	DDX_Control(pDX, IDC_EXPORTFOLDER, m_eExportFolderPath);
	DDX_Check(pDX, IDC_EXPORTINCOMPLETEONLY, m_bExportIncompleteOnly);
	DDX_Check(pDX, IDC_EXPORTTOFOLDER, m_bExportToFolder);
	DDX_Text(pDX, IDC_EXPORTFOLDER, m_sExportFolderPath);
	//}}AFX_DATA_MAP

	DDX_Control(pDX, IDC_AUTOSAVEFREQUENCY, m_cbAutoSave);
	DDX_Check(pDX, IDC_AUTOHTMLEXPORT, m_bAutoHtmlExport);
	DDX_Control(pDX, IDC_TABWIDTHS, m_cbIndent);
	DDX_Control(pDX, IDC_FONTLIST, m_cbFonts);
	DDX_Check(pDX, IDC_PREVIEWSAVEAS, m_bPreviewSaveAs);
	DDX_Check(pDX, IDC_REMOVEARCHIVEDITEMS, m_bRemoveArchivedTasks);
	DDX_Check(pDX, IDC_REMOVEONLYONABSCOMPLETION, m_bRemoveOnlyOnAbsoluteCompletion);
	DDX_Check(pDX, IDC_EXPORTVISIBLEONLY, m_bExportVisibleOnly);
	DDX_Check(pDX, IDC_AUTOSAVE, m_bAutoSave);

	// custom
	if (pDX->m_bSaveAndValidate)
	{
		m_sHtmlFont = m_cbFonts.GetSelectedFont();

		ASSERT ((sizeof(CB2INDENT) / sizeof(int)) == m_cbIndent.GetCount());
		m_nTextIndent = CB2INDENT[m_cbIndent.GetCurSel()];

		if (m_bAutoSave)
		{
			ASSERT ((sizeof(CB2FREQ) / sizeof(int)) == m_cbAutoSave.GetCount());
			m_nAutoSaveFrequency = CB2FREQ[m_cbAutoSave.GetCurSel()];
		}
		else
			m_nAutoSaveFrequency = 0;
	}
	else
	{
		m_cbFonts.SetSelectedFont(m_sHtmlFont);

		CString sIndent;
		sIndent.Format("%d", m_nTextIndent);

		if (CB_ERR == m_cbIndent.SelectString(-1, sIndent))
		{
			m_nTextIndent = CB2INDENT[1];
			m_cbIndent.SetCurSel(1);
		}

		if (m_bAutoSave)
		{
			CString sFreq;
			sFreq.Format("%d", m_nAutoSaveFrequency);

			if (CB_ERR == m_cbAutoSave.SelectString(-1, sFreq))
			{
				m_nAutoSaveFrequency = CB2FREQ[2];
				m_cbAutoSave.SetCurSel(2);
			}
		}
		else
			m_cbAutoSave.SetCurSel(2);
	}
}


BEGIN_MESSAGE_MAP(CPreferencesFilePage, CPropertyPage)
	//{{AFX_MSG_MAP(CPreferencesFilePage)
	ON_BN_CLICKED(IDC_EXPORTTOFOLDER, OnExporttofolder)
	ON_BN_CLICKED(IDC_AUTOHTMLEXPORT, OnAutohtmlexport)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_REMOVEARCHIVEDITEMS, OnRemovearchiveditems)
	ON_BN_CLICKED(IDC_AUTOSAVE, OnAutosave)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesFilePage message handlers

void CPreferencesFilePage::OnRemovearchiveditems() 
{
	UpdateData();

	GetDlgItem(IDC_REMOVEONLYONABSCOMPLETION)->EnableWindow(m_bRemoveArchivedTasks);
}

void CPreferencesFilePage::OnOK() 
{
	CPropertyPage::OnOK();
	
	// save settings
	AfxGetApp()->WriteProfileString("Preferences", "HTMLFont", m_sHtmlFont);
	AfxGetApp()->WriteProfileInt("Preferences", "PreviewSaveAs", m_bPreviewSaveAs);
	AfxGetApp()->WriteProfileInt("Preferences", "TextIndent", m_nTextIndent);
	AfxGetApp()->WriteProfileInt("Preferences", "RemoveArchivedTasks", m_bRemoveArchivedTasks);
	AfxGetApp()->WriteProfileInt("Preferences", "RemoveOnlyOnAbsoluteCompletion", m_bRemoveOnlyOnAbsoluteCompletion);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoHtmlExport", m_bAutoHtmlExport);
	AfxGetApp()->WriteProfileInt("Preferences", "ExportVisibleOnly", m_bExportVisibleOnly);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoSaveFrequency", m_nAutoSaveFrequency);
	AfxGetApp()->WriteProfileInt("Preferences", "ExportIncompleteOnly", m_bExportIncompleteOnly);
	AfxGetApp()->WriteProfileString("Preferences", "ExportFolderPath", m_bExportToFolder ? m_sExportFolderPath : "");
//	AfxGetApp()->WriteProfileInt("Preferences", "", m_b);
}

void CPreferencesFilePage::OnAutosave() 
{
	UpdateData();

	GetDlgItem(IDC_AUTOSAVEFREQUENCY)->EnableWindow(m_bAutoSave);

	if (m_bAutoSave && !m_nAutoSaveFrequency)
	{
		m_nAutoSaveFrequency = CB2FREQ[2];
		m_cbAutoSave.SetCurSel(2);
	}
}

BOOL CPreferencesFilePage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	GetDlgItem(IDC_REMOVEONLYONABSCOMPLETION)->EnableWindow(m_bRemoveArchivedTasks);
	GetDlgItem(IDC_AUTOSAVEFREQUENCY)->EnableWindow(m_bAutoSave);
	GetDlgItem(IDC_EXPORTTOFOLDER)->EnableWindow(m_bAutoHtmlExport);
	GetDlgItem(IDC_EXPORTFOLDER)->EnableWindow(m_bAutoHtmlExport && m_bExportToFolder);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreferencesFilePage::OnExporttofolder() 
{
	UpdateData();

	GetDlgItem(IDC_EXPORTFOLDER)->EnableWindow(m_bAutoHtmlExport && m_bExportToFolder);
}

void CPreferencesFilePage::OnAutohtmlexport() 
{
	UpdateData();	

	GetDlgItem(IDC_EXPORTTOFOLDER)->EnableWindow(m_bAutoHtmlExport);
	GetDlgItem(IDC_EXPORTFOLDER)->EnableWindow(m_bAutoHtmlExport && m_bExportToFolder);
}

CString CPreferencesFilePage::GetAutoExportFolderPath() const 
{ 
	if (m_bAutoHtmlExport && m_bExportToFolder)
		return m_sExportFolderPath;
	else
		return "";
}
