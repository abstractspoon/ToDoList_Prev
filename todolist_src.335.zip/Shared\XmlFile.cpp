// XmlFile.cpp: implementation of the CXmlFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "XmlFile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////

#include "xmlcharmap.h"
#include "htmlcharmap.h"

CString& XML2TXT(CString& xml) { return CHtmlCharMap::ConvertFromRep(xml); } // we use the html map for backwards compatibility
CString& TXT2XML(CString& txt) { return CXmlCharMap::ConvertToRep(txt); }

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const char SINGLE_QUOTE = 0x27;
const char DOUBLE_QUOTE = 0x22;
const LPCTSTR ENDL = "\r\n";

CXmlItem::CXmlItem(const CXmlItem* pParent, CString sName, CString sValue) :
	m_pParent(pParent), m_pSibling(NULL), m_bNotAttribute(FALSE)
{
	sName.TrimLeft();
	sName.TrimRight();
	sValue.TrimLeft();
	sValue.TrimRight();
	
	m_sName = sName;
	m_sValue = sValue;
}

CXmlItem::CXmlItem(const CXmlItem& xi, const CXmlItem* pParent) : m_pParent(pParent), m_pSibling(NULL)
{
	m_sName = xi.GetName();
	m_sValue = xi.GetValue();
	m_bNotAttribute = !xi.IsAttribute();

	// copy siblings
	const CXmlItem* pXISibling = xi.GetSibling();

	if (pXISibling)
		m_pSibling = new CXmlItem(*pXISibling, pParent);

	// copy children
	POSITION pos = xi.GetFirstItemPos();

	while (pos)
	{
		const CXmlItem* pXIChild = xi.GetNextItem(pos);
		ASSERT (pXIChild);

		AddItem(*pXIChild);
	}
}

CXmlItem::~CXmlItem()
{
	Reset();
}

void CXmlItem::Reset()
{
	// delete children
	POSITION pos = m_mapItems.GetStartPosition();
	
	while (pos)
	{
		CXmlItem* pXI = NULL;
		CString sItem;
		
		m_mapItems.GetNextAssoc(pos, sItem, pXI);
		delete pXI;
	}

	m_mapItems.RemoveAll();

	// and siblings
	// note: because sibling ~tor calls its own Reset() the chain 
	// of siblings will be correctly cleaned up
	delete m_pSibling;
	m_pSibling = NULL;
}

const CXmlItem* CXmlItem::GetItem(CString sItem, CString sSubItem) const
{
	CXmlItem* pXI = NULL;
	sItem.MakeUpper();
	
	m_mapItems.Lookup(sItem, pXI);
	
	if (pXI && !sSubItem.IsEmpty())
		return pXI->GetItem(sSubItem);

	return pXI;
}

// non-const internal version
CXmlItem* CXmlItem::GetItem(CString sItem, CString sSubItem)
{
	CXmlItem* pXI = NULL;
	sItem.MakeUpper();
	
	m_mapItems.Lookup(sItem, pXI);
	
	if (pXI && !sSubItem.IsEmpty())
		return pXI->GetItem(sSubItem);

	return pXI;
}

LPCTSTR CXmlItem::GetItemValue(CString sItem, CString sSubItem) const
{
	const CXmlItem* pXI = GetItem(sItem, sSubItem);

	return pXI ? pXI->GetValue() : "";
}

LPCTSTR CXmlItem::GetItemValue(CString sItem) const
{
	const CXmlItem* pXI = GetItem(sItem);

	return pXI ? pXI->GetValue() : "";
}

CXmlItem* CXmlItem::AddItem(CString sName, LPCTSTR szValue)
{
	ASSERT (!sName.IsEmpty());
	
	if (sName.IsEmpty())
		return NULL;

	CXmlItem* pXI = new CXmlItem(this, sName, szValue);
	
	// if an item of the same name already exists then add this
	// item as a sibling to the existing item else its a new item
	// so add and map name to this object
	CXmlItem* pXPExist = GetItem(sName);

	if (pXPExist)
		pXPExist->AddSibling(pXI);
	else
	{
		sName.MakeUpper();
		m_mapItems[sName] = pXI;
	}
	
	return pXI;
}

CXmlItem* CXmlItem::AddItem(const CXmlItem& xi)
{
	CXmlItem* pXI = new CXmlItem(xi, this);
	
	// if an item of the same name already exists then add this
	// item as a sibling to the existing item else its a new item
	// so add and map name to this object
	CXmlItem* pXPExist = GetItem(xi.GetName());

	if (pXPExist)
		pXPExist->AddSibling(pXI);
	else
		m_mapItems[xi.GetName()] = pXI;
	
	return pXI;
}

CXmlItem* CXmlItem::AddItem(CString sName, int nValue)
{
	CString sValue;
	sValue.Format("%d", nValue);

	return AddItem(sName, sValue);
}

CXmlItem* CXmlItem::AddItem(CString sName, double fValue)
{
	CString sValue;
	sValue.Format("%.8f", fValue);

	return AddItem(sName, sValue);
}

void CXmlItem::SetValue(LPCTSTR szValue)
{
	m_sValue = szValue;
}

void CXmlItem::SetValue(int nValue)
{
	CString sValue;
	sValue.Format("%d", nValue);

	SetValue(sValue);
}

void CXmlItem::SetValue(double fValue)
{
	CString sValue;
	sValue.Format("%.8f", fValue);

	SetValue(sValue);
}

BOOL CXmlItem::DeleteItem(const CXmlItem* pXI)
{
	if (!pXI)
		return FALSE;

	// lookup by name first
	CString sName = pXI->GetName();
	CXmlItem* pXIMatch = GetItem(sName);

	if (!pXIMatch)
		return FALSE;

	// now search the sibling chain looking for exact match
	CXmlItem* pXIPrevSibling = NULL;

	while (pXIMatch != pXI)
	{
		pXIPrevSibling = pXIMatch;
		pXIMatch = pXIMatch->GetSibling();
	}

	if (!pXIMatch) // no match
		return FALSE;

	// else
	ASSERT (pXIMatch == pXI);

	CXmlItem* pNextSibling = pXIMatch->GetSibling();

	if (!pXIPrevSibling) // head of the chain
	{
		if (!pNextSibling)
			m_mapItems.RemoveKey(sName);
		else
			m_mapItems[sName] = pNextSibling;
	}
	else // somewhere else in the chain
	{
		pXIPrevSibling->m_pSibling = pNextSibling; // can be NULL
	}

	// finally delete the item
	delete pXI;

	return TRUE;
}

BOOL CXmlItem::AddSibling(CXmlItem* pXI)
{
	ASSERT (pXI);

	if (!pXI)
		return FALSE;

	// must share the same name and parent
	ASSERT (m_sName.CompareNoCase(pXI->GetName()) == 0 && m_pParent == pXI->GetParent());

	if (!(m_sName.CompareNoCase(pXI->GetName()) == 0 && m_pParent == pXI->GetParent()))
		return FALSE;

	if (!m_pSibling)
		m_pSibling = pXI;
	else
		m_pSibling->AddSibling(pXI); // recursive

	return TRUE;
}

POSITION CXmlItem::GetFirstItemPos() const
{
	return m_mapItems.GetStartPosition();
}

const CXmlItem* CXmlItem::GetNextItem(POSITION& pos) const
{
	if (!pos)
		return NULL;

	CString sTemp;
	CXmlItem* pItem = NULL;

	m_mapItems.GetNextAssoc(pos, sTemp, pItem);
	return pItem;
}

CXmlItem* CXmlItem::GetNextItem(POSITION& pos)
{
	if (!pos)
		return NULL;

	CString sTemp;
	CXmlItem* pItem = NULL;

	m_mapItems.GetNextAssoc(pos, sTemp, pItem);
	return pItem;
}

BOOL CXmlItem::NameMatches(const CXmlItem* pXITest, BOOL bIgnoreCase) const
{
	if (!pXITest)
		return FALSE;

	if (bIgnoreCase)
		return (m_sName.CompareNoCase(pXITest->GetName()) == 0);

	// else
	return (m_sName == pXITest->GetName());
}

BOOL CXmlItem::ValueMatches(const CXmlItem* pXITest, BOOL bIgnoreCase) const
{
	if (!pXITest)
		return FALSE;

	if (bIgnoreCase)
		return (m_sValue.CompareNoCase(pXITest->GetValue()) == 0);

	// else
	return (m_sValue == pXITest->GetValue());
}

BOOL CXmlItem::ItemValueMatches(const CXmlItem* pXITest, CString sItemName, BOOL bIgnoreCase) const
{
	if (sItemName.IsEmpty())
		return FALSE;

	const CXmlItem* pXIItem = GetItem(sItemName);
	const CXmlItem* pXITestItem = pXITest->GetItem(sItemName);

	if (pXIItem && pXITestItem)
		return pXIItem->ValueMatches(pXITestItem, bIgnoreCase);

	// else
	return FALSE;
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CXmlFile::CXmlFile(LPCTSTR szRootItemName) : 
	m_xiRoot(NULL, szRootItemName), m_sHeader("?xml version=\"1.0\" encoding=\"windows-1252\"?")
{
	// get active code page
	CString sCodePage;

	GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_IDEFAULTANSICODEPAGE, sCodePage.GetBuffer(7), 6);
	sCodePage.ReleaseBuffer();

	// and replace in header
	if (atoi(sCodePage) > 0)
		m_sHeader.Replace("1252", sCodePage);
}

CXmlFile::~CXmlFile()
{

}

BOOL CXmlFile::Load(LPCTSTR szFilePath, LPCTSTR szRootItemName)
{
	if (!szFilePath || !strlen(szFilePath))
		return FALSE;

	if (GetFileHandle() != CFile::hFileNull)
		Close();

	if (Open(szFilePath, XF_READ))
	{
		BOOL bRes = LoadEx(szRootItemName);
		Close();

		return bRes;
	}

	return FALSE;
}

BOOL CXmlFile::Save(LPCTSTR szFilePath, BOOL bAllowAttributes)
{
	if (!szFilePath || !strlen(szFilePath))
		return FALSE;

	if (GetFileHandle() != CFile::hFileNull)
		Close();

	if (Open(szFilePath, XF_WRITE))
	{
		BOOL bRes = SaveEx(bAllowAttributes);
		Close();

		return bRes;
	}

	return FALSE;
}

BOOL CXmlFile::Open(LPCTSTR szFilePath, XF_OPEN nOpenFlag)
{
	if (!szFilePath || !strlen(szFilePath))
		return FALSE;

	if (GetFileHandle() != CFile::hFileNull)
		Close();

	switch (nOpenFlag)
	{
	case XF_READ:
		return CStdioFile::Open(szFilePath, CFile::shareDenyNone | CFile::modeRead | CFile::typeText);

	case XF_WRITE:
		return CStdioFile::Open(szFilePath, CFile::shareExclusive | CFile::modeWrite | CFile::modeCreate | CFile::typeText);

	case XF_READWRITE:
		return CStdioFile::Open(szFilePath, CFile::shareExclusive | CFile::modeReadWrite | 
											CFile::modeCreate | CFile::modeNoTruncate | CFile::typeText);
	}

	return FALSE;
}

BOOL CXmlFile::SaveEx(BOOL bAllowAttributes)
{
	if (GetFileHandle() == CFile::hFileNull)
		return FALSE;

	CExportToXml e2xml(bAllowAttributes);
	CString sXml;
	
	e2xml.Export(&m_xiRoot, 0, 1, sXml);
	
	// add header
	if (!m_sHeader.IsEmpty())
	{
		CString sHeader;
		sHeader.Format("<%s>%s", m_sHeader, ENDL);
		sXml = sHeader + sXml;
	}
	
	try
	{
		Seek(0, CFile::begin); // move to start
		WriteString(sXml);
	}
	catch (...)
	{
		return FALSE;
	}

	return TRUE;
}

BOOL CXmlFile::LoadEx(LPCTSTR szRootItemName)
{
	if (GetFileHandle() == CFile::hFileNull)
		return FALSE;

	CString sLine, sFile;
	BOOL bInComment = FALSE;
	
	// concatenate entire file into one long string
	try
	{
		Seek(0, CFile::begin); // move to start

		while (ReadString(sLine))
		{
			// ignore empty lines
			if (sLine.IsEmpty())
				continue;
			
			// ignore code contained in '<!--...-->'
			if (!bInComment)
			{
				int nFind = sLine.Find("<!--");
				
				if (nFind != -1)
				{
					bInComment = TRUE;
					sFile += sLine.Left(nFind);
					sLine = sLine.Mid(nFind + strlen("<!--"));
				}
			}
			
			// check for end of comment
			if (bInComment)
			{
				int nFind = sLine.Find("-->");
				
				if (nFind != -1)
				{
					bInComment = FALSE;
					sLine = sLine.Mid(nFind + strlen("-->"));
				}
				else 
					continue; // ignore rest of this line
			}
			
			sFile += sLine;
			sLine.Empty();
		}
	}
	catch (...)
	{
		return FALSE;
	}
	
	if (!sLine.IsEmpty())
		sFile += sLine;
	
	if (!szRootItemName && lstrlen(m_xiRoot.GetName()))
		szRootItemName = m_xiRoot.GetName();
	
	return ParseRootItem(szRootItemName, sFile);
}

BOOL CXmlFile::ParseRootItem(LPCTSTR szRootItemName, CString& sFile)
{
	m_xiRoot.Reset();

	CString sRootItem(szRootItemName);
	sRootItem.TrimLeft();
	sRootItem.TrimRight();

	// find first valid item in file
	while (!sFile.IsEmpty())
	{
		CString sItem = GetNextItem(sFile);

		// save off the header string
		if (sItem.Find("?XML") == 0)
		{
			m_sHeader = sItem;
			continue;
		}
		else if (sItem.CompareNoCase(sRootItem) != 0)
			return FALSE;

		// else trim up to first child item
		CString sValue = GetNextValue(sFile);
		break;
	}

	// parse rest of file
	ParseItem(m_xiRoot, sFile);
	return TRUE;
}

void CXmlFile::ParseItem(CXmlItem& xi, CString& sFile)
{
	CString sThisItem = xi.GetName();
	CString sCloseTag = "/" + sThisItem;

	while (!sFile.IsEmpty())
	{
		CString sItem = GetNextItem(sFile);

		// item closure can occur in a number of ways
		// 1. the close tag is found
		// 2. the item has a non-empty value and another start tag is found
		// 3. a parent close tag is found
		if (!sThisItem.IsEmpty())
		{
			if (sItem.CompareNoCase(sCloseTag) == 0) // 1.
				return; 

			else if (lstrlen(xi.GetValue())) // 2.
			{
				// prepend the item back onto the file
				sItem = "<" + sItem + ">";
				sFile = sItem + sFile;
				return;
			}
			else if (sItem.Left(1) == "/") // 3.
			{
				const CXmlItem* pParent = xi.GetParent();

				while (pParent)
				{
					CString sParentItem = pParent->GetName();
					CString sParentCloseTag = "/" + sParentItem;

					if (sItem.CompareNoCase(sParentCloseTag) == 0) 
					{
						// prepend the item back onto the file
						sItem = "<" + sItem + ">";
						sFile = sItem + sFile;
						return;
					}
					else
						pParent = pParent->GetParent();
				}
			}
		}

		// else
		CString sValue = GetNextValue(sFile);
		sValue.Replace("\r", "\r\n");

		CXmlItem* pXI = xi.AddItem(sItem, XML2TXT(sValue));

		ParseItem(*pXI, sFile);
	}
}

CString CXmlFile::GetNextItem(CString& sFile)
{
	CString sItem;
	int nFind = sFile.Find('<');

	if (nFind >= 0)
	{
		sFile = sFile.Mid(nFind + 1);
		nFind = sFile.Find('>');

		if (nFind >= 0)
		{
			sItem = sFile.Left(nFind);
			sFile = sFile.Mid(nFind + 1);
		}
	}

	sItem.TrimLeft();
	sItem.TrimRight();

	// for items NOT starting with '?'
	if (sItem.Left(1) != "?")
	{
		// 1. check for '/' at end of tag and insert an end tag in the file stream
		BOOL bEndTag = FALSE;

		if (sItem.Right(1) == "/")
		{
			bEndTag = TRUE;
			sItem = sItem.Left(sItem.GetLength() - 1);
		}

		// 2. process the tag looking for attribute/value pairs and add them to the file too
		// note: up to the first space is the item name
		nFind = sItem.Find(' ');

		if (nFind > 0)
		{
			CString sRest = sItem.Mid(nFind + 1);
			sItem = sItem.Left(nFind);

			// do we need to add an end tag first
			if (bEndTag)
			{
				CString sEndTag;
				sEndTag.Format("</%s>\n", sItem);

				sFile = sEndTag + sFile;
			}
			
			sRest.TrimLeft();
			
			while (!sRest.IsEmpty())
			{
				// look for attribute="value" pairs
				int nFind = sRest.Find('=');
				
				if (nFind > 0)
				{
					CString sAttribute = sRest.Left(nFind);
					sAttribute.TrimLeft();
					sAttribute.TrimRight();

					sRest = sRest.Mid(nFind + 1);
					
					// opening quote
					char cQuote = 0;

					int nSGFind = sRest.Find(SINGLE_QUOTE); 
					int nDGFind = sRest.Find(DOUBLE_QUOTE); 

					if (nSGFind >= 0 && (nSGFind < nDGFind || nDGFind == -1))
					{
						nFind = nSGFind;
						cQuote = SINGLE_QUOTE;
					}
					else if (nDGFind >= 0)
					{
						nFind = nDGFind;
						cQuote = DOUBLE_QUOTE;
					}
					
					if (cQuote)
					{
						sRest = sRest.Mid(nFind + 1);
						
						nFind = sRest.Find(cQuote); // closing quote
						
						if (nFind >= 0)
						{
							CString sValue = sRest.Left(nFind);
							sRest = sRest.Mid(nFind + 1);
							
							CString sAttributeTag;
							sAttributeTag.Format("<%s>%s</%s>\n", sAttribute, sValue, sAttribute);
							
							sFile = sAttributeTag + sFile;
							
							// next pair
							int nFind = sRest.Find(' ');
							
							if (nFind >= 0)
								sRest = sRest.Mid(nFind + 1);
							else
								break;
						}
						else
							break;
					}
					else
						break;
				}
				else
					break;
			}
		}
		// else do we need to add an end tag
		else if (bEndTag)
		{
			CString sEndTag;
			sEndTag.Format("</%s>\n", sItem);
			
			sFile = sEndTag + sFile;
		}
	}

	sItem.MakeUpper();

	return sItem;
}

CString CXmlFile::GetNextValue(CString& sFile)
{
	CString sItem;
	int nFind = sFile.Find('<');

	if (nFind >= 0)
	{
		sItem = sFile.Left(nFind);
		sFile = sFile.Mid(nFind);
	}
	else
	{
		sItem = sFile;
		sFile.Empty();
	}

	return sItem;
}

CString& CXmlFile::CExportToXml::Export(const CXmlItem* pItem, int nDepth, int nPos, CString& sOutput) const
{
	// process children first so attributes can be included in opening tag
	CString sChildXml, sChildAttrib;

	if (pItem->GetItemCount())
	{
		POSITION pos = pItem->GetFirstItemPos();
		int nItem = 1;

		while (pos)
		{
			const CXmlItem* pXI = pItem->GetNextItem(pos);
			ASSERT (pXI);
			
			if (m_bAllowAttributes && pXI->IsAttribute())
			{
				sChildAttrib += ' ';
				sChildAttrib += ExportAsAttribute(pXI);
			}
			else
			{
				CString sTemp;
				sChildXml += Export(pXI, nDepth + 1, nItem++, sTemp);
			}
		}
	}

	CString sDepth(' ', nDepth * 4);

	// format our name and value
	CString sName(pItem->GetName());
	CString sValue(pItem->GetValue());
	TXT2XML(sValue); 

	if (sChildXml.IsEmpty()) // means all children are attributes
	{
		if (sValue.IsEmpty())
			sOutput.Format("%s<%s%s/>%s", sDepth, sName, sChildAttrib, ENDL);
		else
		{
			sOutput.Format("%s<%s%s>%s</%s>%s", 
							sDepth, 
							sName, 
							sChildAttrib, 
							sValue, 
							sName, 
							ENDL);
		}
	}	
	else
	{
		sOutput.Format("%s<%s%s>%s%s%s%s</%s>%s", 
						sDepth, 
						sName, 
						sChildAttrib, 
						sValue, 
						ENDL, 
						sChildXml, 
						sDepth, 
						sName, 
						ENDL);
	}

	// add siblings
	if (pItem->GetSibling())
	{
		CString sTemp;
		sOutput += Export(pItem->GetSibling(), nDepth, nPos + 1, sTemp);
	}

	return sOutput;
}

CString CXmlFile::CExportToXml::ExportAsAttribute(const CXmlItem* pItem) const
{
	if (pItem->IsAttribute())
	{
		CString sValue(pItem->GetValue());
		TXT2XML(sValue); 

		CString sAttrib;
		sAttrib.Format("%s=\"%s\"", pItem->GetName(), sValue);
		return sAttrib;
	}

	return "";
}

