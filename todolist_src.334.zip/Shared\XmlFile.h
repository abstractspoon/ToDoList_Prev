// XmlFile.h: interface for the CXmlFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_XMLFILE_H__54045703_1A98_41AB_B1A1_0B165C350AA0__INCLUDED_)
#define AFX_XMLFILE_H__54045703_1A98_41AB_B1A1_0B165C350AA0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>

// global fns for translating text to/from xml representations eg '&lt;' becomes '<' and vice versa
CString& XML2TXT(CString& xml);
CString& TXT2XML(CString& txt);

class CXmlItem
{
public:
	CXmlItem(const CXmlItem* pParent = NULL, CString sName = "", CString sValue = "");
	CXmlItem(const CXmlItem& xi, const CXmlItem* pParent = NULL);
	virtual ~CXmlItem();

	void Reset();

	const CXmlItem* GetItem(CString sItemName, CString sSubItemName = "") const;
	CXmlItem* GetItem(CString sItemName, CString sSubItemName = "");

	inline LPCTSTR GetName() const { return m_sName; }
	inline LPCTSTR GetValue() const { return m_sValue; }
	LPCTSTR GetItemValue(CString sItemName) const;
	LPCTSTR GetItemValue(CString sItemName, CString sSubItemName) const;
	inline int GetItemCount() const { return m_mapItems.GetCount(); }

	inline int GetValueI() const { return atoi(m_sValue); }
	int GetItemValueI(CString sItemName) const { return atoi(GetItemValue(sItemName)); }
	int GetItemValueI(CString sItemName, CString sSubItemName) const { return atoi(GetItemValue(sItemName, sSubItemName)); }

	inline double GetValueF() const { return (double)atof(m_sValue); }
	double GetItemValueF(CString sItemName) const { return (double)atof(GetItemValue(sItemName)); }
	double GetItemValueF(CString sItemName, CString sSubItemName) const { return (double)atof(GetItemValue(sItemName, sSubItemName)); }

	CXmlItem* AddItem(CString sName, LPCTSTR sValue = NULL);
	CXmlItem* AddItem(CString sName, int nValue);
	CXmlItem* AddItem(CString sName, double fValue);
	CXmlItem* AddItem(const CXmlItem& xi); // item and all attributes are copied

	void SetValue(LPCTSTR sValue);
	void SetValue(int nValue);
	void SetValue(double fValue);

	BOOL DeleteItem(const CXmlItem* pXI); // must be a direct child

	inline const CXmlItem* GetParent() const { return m_pParent; }
	inline const CXmlItem* GetSibling() const { return m_pSibling; }
	inline CXmlItem* GetSibling() { return m_pSibling; }

	inline BOOL IsAttribute() const { return !m_bNotAttribute && !m_sValue.IsEmpty() && !m_mapItems.GetCount(); }
	inline void SetNotAttribute() { m_bNotAttribute = TRUE; }

	POSITION GetFirstItemPos() const;
	const CXmlItem* GetNextItem(POSITION& pos) const;
	CXmlItem* GetNextItem(POSITION& pos);

	// matching helpers
	BOOL NameMatches(const CXmlItem* pXITest, BOOL bIgnoreCase = TRUE) const;
	BOOL ValueMatches(const CXmlItem* pXITest, BOOL bIgnoreCase = TRUE) const;
	BOOL ItemValueMatches(const CXmlItem* pXITest, CString sItemName, BOOL bIgnoreCase = TRUE) const;

protected:
	CString m_sName;
	CString m_sValue;

	const CXmlItem* m_pParent;
	CXmlItem* m_pSibling;

	CMap<CString, LPCTSTR, CXmlItem*, CXmlItem*&> m_mapItems; // children

	BOOL m_bNotAttribute; // allows overiding of attribute status (see IsAttribute() above)

protected:
	BOOL AddSibling(CXmlItem* pXI); // must share the same name and parent
};

// v simple interface for exporting to multiple formats
class IXmlExporter
{
	virtual CString& Export(const CXmlItem* pItem, int nDepth, int nPos, CString& sOutput) const = 0;
};

enum XF_OPEN 
{
	XF_READ,
	XF_WRITE,
	XF_READWRITE,
};

class CXmlFile : private CStdioFile  
{
public:
	CXmlFile(LPCTSTR szRootItemName = NULL);
	virtual ~CXmlFile();
	inline void Reset() { m_xiRoot.Reset(); }

	BOOL Load(LPCTSTR szFilePath, LPCTSTR szRootItemName = NULL);
	BOOL Save(LPCTSTR szFilePath, BOOL bAllowAttributes = FALSE);

	// extended interface
	BOOL Open(LPCTSTR szFilePath, XF_OPEN nOpenFlags);
	BOOL SaveEx(BOOL bAllowAttributes = FALSE);
	BOOL LoadEx(LPCTSTR szRootItemName = NULL);
	void Close() { CStdioFile::Close(); }

	inline const CXmlItem* Root() const { return &m_xiRoot; }
	inline CXmlItem* Root() { return &m_xiRoot; }

	inline const CXmlItem* GetItem(CString sItemName) const { return m_xiRoot.GetItem(sItemName); } 
	inline CXmlItem* GetItem(CString sItemName) { return m_xiRoot.GetItem(sItemName); }

	inline CXmlItem* AddItem(CString sName, CString sValue = "") { return m_xiRoot.AddItem(sName, sValue); }
	inline CXmlItem* AddItem(CString sName, int nValue) { return m_xiRoot.AddItem(sName, nValue); }
	inline CXmlItem* AddItem(CString sName, double fValue) { return m_xiRoot.AddItem(sName, fValue); }

	inline BOOL DeleteItem(const CXmlItem* pXI) { return m_xiRoot.DeleteItem(pXI); }

	inline LPCTSTR GetItemValue(CString sItemName) const { return m_xiRoot.GetItemValue(sItemName); }
	inline LPCTSTR GetItemValue(CString sItemName, CString sSubItemName) const { return m_xiRoot.GetItemValue(sItemName, sSubItemName); }

	inline int GetItemValueI(CString sItemName) const { return m_xiRoot.GetItemValueI(sItemName); }
	inline int GetItemValueI(CString sItemName, CString sSubItemName) const { return m_xiRoot.GetItemValueI(sItemName, sSubItemName); }

	inline double GetItemValueF(CString sItemName) const { return m_xiRoot.GetItemValueF(sItemName); }
	inline double GetItemValueF(CString sItemName, CString sSubItemName) const { return m_xiRoot.GetItemValueF(sItemName, sSubItemName); }

	inline CString GetFilePath() { return CStdioFile::GetFilePath(); }
	inline HFILE GetFileHandle() { return CStdioFile::m_hFile; }

	inline LPCTSTR GetHeader() { return m_sHeader; }
	inline void SetHeader(LPCTSTR szHeader) { m_sHeader = szHeader; m_sHeader.MakeLower(); }

protected:
	CXmlItem m_xiRoot;
	CString m_sHeader;

	// this is a built-in exporter for saving to disk
	class CExportToXml : protected IXmlExporter
	{
	public:
		CExportToXml(BOOL bAllowAttributes = FALSE) : m_bAllowAttributes(bAllowAttributes) { }
		virtual CString& Export(const CXmlItem* pItem, int nDepth, int nPos, CString& sOutput) const;

	protected:
		BOOL m_bAllowAttributes;

	protected:
		CString ExportAsAttribute(const CXmlItem* pItem) const;
	};

protected:
	void ParseItem(CXmlItem& xi, CString& sFile);
	BOOL ParseRootItem(LPCTSTR szRootItemName, CString& sFile);
	CString GetNextItem(CString& sFile);
	CString GetNextValue(CString& sFile);

};

#endif // !defined(AFX_XMLFILE_H__54045703_1A98_41AB_B1A1_0B165C350AA0__INCLUDED_)
