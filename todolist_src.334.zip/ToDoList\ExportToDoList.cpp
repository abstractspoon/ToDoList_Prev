// ExportToDoList.cpp: implementation of the CExportToDoListTo... classes.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ExportToDoList.h"
#include "todoctrl.h" // for styles only

//////////////////////////////////////////////////////////////////////
// Base class
//////////////////////////////////////////////////////////////////////

int CExportToDoList::CalcPercentDone(const CXmlItem* pItem) const
{
	int nPercent = pItem->GetItemValueF("DONEDATE") > 0 ? 100 : pItem->GetItemValueI("PERCENTDONE"); // default

	if (nPercent < 100 && HasPref(TDCS_AVERAGEPERCENTSUBCOMPLETION))
	{
		const CXmlItem* pXIChild = pItem->GetItem("TASK");

		if (pXIChild)
		{
			int nNumChildren = 0;
			nPercent = 0;
			BOOL bIncludeDone = HasPref(TDCS_INCLUDEDONEINAVERAGECALC);

			while (pXIChild)
			{
				if (bIncludeDone || pItem->GetItemValueF("DONEDATE") == 0)
				{
					nPercent += CalcPercentDone(pXIChild);
					nNumChildren++;
				}

				pXIChild = pXIChild->GetSibling();
			}

			// average
			nPercent /= nNumChildren;
		}
	}

	return nPercent;
}

double CExportToDoList::CalcTimeEstimate(const CXmlItem* pItem) const
{
	const CXmlItem* pXIChild = pItem->GetItem("TASK");

	if (!pXIChild)
		return pItem->GetItemValueF("TIMEESTIMATE");

	// else
	double dTime = 0;

	while (pXIChild)
	{
		dTime += CalcTimeEstimate(pXIChild);
		
		pXIChild = pXIChild->GetSibling();
	}

	return dTime;
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const LPCTSTR ENDL = "\r\n";

CExportToDoListToHtml::CExportToDoListToHtml(LPCTSTR szProjectName, DWORD dwUserPref, const CDWordArray& aColors, LPCTSTR szFontName) 
	: CExportToDoList(szProjectName, dwUserPref), m_sFontName(szFontName)
{
	m_aPriorityColors.Copy(aColors);
}

CExportToDoListToHtml::~CExportToDoListToHtml()
{

}

CString& CExportToDoListToHtml::Export(const CXmlItem* pItem, int nDepth, int nPos, CString& sOutput) const
{
	// if depth == 0 then we're at the root so just add sub-tasks
	// else insert pItem first
	if (nDepth > 0)
	{
		// if there is a POS child item then this replaces nPos
		if (pItem->GetItem("POS"))
			nPos = pItem->GetItemValueI("POS");

		CString sItem, sColor("#000000"), sPriority, sPerson, sTitle, sPercent, sTimeEst, sFileRef, sComments;
		CString sStartDate, sDueDate, sDoneDate, sID;

		// ID
		if (pItem->GetItem("ID"))
			sID.Format("(ID: %d) ", pItem->GetItemValueI("ID"));

		// title
		CString sItemTitle = pItem->GetItemValue("TITLE");
		TXT2XML(sItemTitle);

		if (nDepth == 1) // toplevel == bold
			sTitle.Format("<b>%s</b>", sItemTitle);
		else
			sTitle = sItemTitle;

		// priority, start/due/done dates
		int nPercent = CalcPercentDone(pItem);
		BOOL bDoneDate = (pItem->GetItemValueF("DONEDATE") > 0);
		BOOL bDone = (nPercent == 100 || bDoneDate);

		if (bDone)
		{
			sColor = "#c4c4c4";

			if (bDoneDate)
				sDoneDate.Format(" (%s)", pItem->GetItemValue("DONEDATESTRING"));
		}
		else
		{
			COLORREF color = CalcItemColor(pItem);
			sColor.Format("#%02X%02X%02X", GetRValue(color), GetGValue(color), GetBValue(color));

			if (pItem->GetItem("PRIORITY"))
				sPriority.Format("[%s] ", pItem->GetItemValue("PRIORITY"));

			if (pItem->GetItem("STARTDATESTRING"))
				sStartDate.Format(" (start: %s)", pItem->GetItemValue("STARTDATESTRING"));

			if (pItem->GetItem("DUEDATESTRING"))
				sDueDate.Format(" (due: %s)", pItem->GetItemValue("DUEDATESTRING"));

			if (pItem->GetItem("PERCENTDONE"))
				sPercent.Format(" (%d%%) ", nPercent);

			double dTimeEst = CalcTimeEstimate(pItem);

			if (dTimeEst)
				sTimeEst.Format(" (time est: %.02f hrs)", dTimeEst);
		}

		// person
		if (pItem->GetItem("PERSON"))
			sPerson.Format(" (allocated to: %s)", pItem->GetItemValue("PERSON"));

		// fileref
		if (pItem->GetItem("FILEREFPATH"))
		{
			CString sFilePath = pItem->GetItemValue("FILEREFPATH");
			sFileRef.Format("<br>(file ref: <a href=\"%s\">%s</a>)", sFilePath, sFilePath);
		}

		BOOL bGrayed = (IsItemDone(pItem, TRUE) || bDone);

		// comments
		CString sItemComments = pItem->GetItemValue("COMMENTS");

		if (!sItemComments.IsEmpty())
		{
			TXT2XML(sItemComments);
			sComments.Format(bGrayed ? "<br><font color='#c4c4c4'>[%s] </font>" : "<br><font color='#606060'>[%s] </font>", 
							sItemComments);

			// replace carriage returns with <br>
			sComments.Replace(ENDL, "<br>");
			sComments.Replace("\n", "<br>");
		}

		CString sFormat = bDone ? "%s%s%s<font color='%s'><s>%s%s%s%s%s</s></font>%s<s>%s</s>%s" :
							(bGrayed ? "%s%s%s<font color='%s'>%s%s%s%s%s</font>%s%s%s" : 
										"%s%s%s<font color='%s'>%s</font>%s%s%s%s%s%s%s");

		sItem.Format(sFormat, sID, sPriority, sPercent, sColor, sTitle, sPerson, sStartDate, sDueDate, 
					sTimeEst, sDoneDate, sComments, sFileRef);

		if (nDepth == 1) // toplevel
			sOutput += "<br>";

		sOutput += "<li>";
		sOutput += sItem;
	}
	else
	{
		if (!m_sFontName.IsEmpty())
			sOutput.Format("<font face='%s'>", m_sFontName);

		// project name
		if (!m_sProjectName.IsEmpty())
		{
			CString sProjTitle;
			sProjTitle.Format("<h2>%s</h2>", m_sProjectName);
			sOutput += sProjTitle;
		}
	}

	// begin new ordered list for sub-tasks
	const CXmlItem* pTask = pItem->GetItem("TASK");

	if (pTask) // at least one sub-task
	{
		sOutput += ENDL;
		sOutput += "<ol>";
		sOutput += ENDL;

		int nChildPos = 1;

		while (pTask)
		{
			CString sTask;
			sOutput += Export(pTask, nDepth + 1, nChildPos++, sTask);

			pTask = pTask->GetSibling();
		}

		// end ordered list
		sOutput += "</ol>";
		sOutput += ENDL;
	}

	// end of item
	if (nDepth > 0)
	{
		sOutput += "</li>";
		sOutput += ENDL;
	}
	else if (!m_sFontName.IsEmpty()) // && nDepth == 0
		sOutput += "</font>";

	return sOutput;
}

COLORREF CExportToDoListToHtml::CalcPriorityColor(int nPriority) const
{
	if (nPriority < 0 || nPriority > 10)
		return GetSysColor(COLOR_WINDOW);

	COLORREF crLow = 0, crHigh = 0;

	if (HasPref(TDCS_COLORPRIORITY))
	{
		if (m_aPriorityColors.GetSize() == 11)
			return (COLORREF)m_aPriorityColors[nPriority];

		// else
		ASSERT (m_aPriorityColors.GetSize() == 2);

		crLow = m_aPriorityColors[0];
		crHigh = m_aPriorityColors[1];
	}
	else
	{
		crLow = RGB(225, 225, 225);
		crHigh = 0;
	}

	if (nPriority == 0)
		return crLow;
	
	else if (nPriority == 10)
		return crHigh;

	BYTE redLow = GetRValue(crLow);
	BYTE greenLow = GetGValue(crLow);
	BYTE blueLow = GetBValue(crLow);

	BYTE redHigh = GetRValue(crHigh);
	BYTE greenHigh = GetGValue(crHigh);
	BYTE blueHigh = GetBValue(crHigh);

	double dRed = (redLow * (10 - nPriority) / 10) + (redHigh * nPriority / 10);
	double dGreen = (greenLow * (10 - nPriority) / 10) + (greenHigh * nPriority / 10);
	double dBlue = (blueLow * (10 - nPriority) / 10) + (blueHigh * nPriority / 10);

	double dColor = dRed + (dGreen * 256) + (dBlue * 256 * 256);

	return min(RGB(255, 255, 255), (COLORREF)(int)dColor);
}

COLORREF CExportToDoListToHtml::CalcItemColor(const CXmlItem* pItem) const
{
	COLORREF color = 0; // black
	BOOL bParentDone = FALSE, bItemDone = IsItemDone(pItem, FALSE);

	if (!bItemDone)
		bParentDone = IsItemDone(pItem, TRUE);

	if (bParentDone || bItemDone)
		color = RGB(128, 128, 128); // parent and/or item is done
				
	else if (IsItemDue(pItem))
	{
		if (HasPref(TDCS_COLORTEXTBYPRIORITY))
			color = CalcPriorityColor(10);
		else
			color = 255;
	}
	else if (HasPref(TDCS_COLORTEXTBYPRIORITY))
		color = CalcPriorityColor(pItem->GetItemValueI("PRIORITY")); 
				
	else if (pItem->GetItem("COLOR"))
		color = pItem->GetItemValueI("COLOR");

	return color;
}

BOOL CExportToDoListToHtml::IsItemDone(const CXmlItem* pItem, BOOL bCheckParent) const
{
	if (pItem->GetItemValueF("DONEDATE") > 0)
		return TRUE;

	else if (bCheckParent && pItem->GetParent())
		return IsItemDone(pItem->GetParent(), TRUE);

	else
		return FALSE;
}

BOOL CExportToDoListToHtml::IsItemDue(const CXmlItem* pItem) const
{
	if (!pItem->GetItem("DUEDATE") || IsItemDone(pItem, TRUE))
		return FALSE;
			
	COleDateTime today = COleDateTime::GetCurrentTime();
	today = COleDateTime(today.GetYear(), today.GetMonth(), today.GetDay(), 23, 59, 59); // end of today

	return (pItem->GetItemValueF("DUEDATE") <= today.m_dt); 
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CExportToDoListToText::CExportToDoListToText(LPCTSTR szProjectName, DWORD dwUserPref, int nIndentWidth)
	 : CExportToDoList(szProjectName, dwUserPref), INDENT(' ', nIndentWidth)
{

}

CExportToDoListToText::~CExportToDoListToText()
{

}

CString& CExportToDoListToText::Export(const CXmlItem* pItem, int nDepth, int nPos, CString& sOutput) const
{
	// if depth == 0 then we're at the root so just add sub-tasks
	// else insert pItem first
	if (nDepth > 0)
	{
		// first create string to hold TABs
		CString sTabs;

		for (int nTab = 0; nTab < nDepth; nTab++)
			sTabs += INDENT;

		// if there is a POS child item then this replaces nPos
		if (pItem->GetItem("POS"))
			nPos = pItem->GetItemValueI("POS");

		CString sItem, sPriority, sStartDate, sDueDate, sDoneDate, sPerson, sComments, sPercent, sTimeEst, sFileRef;

		// title
		CString sTitle(pItem->GetItemValue("TITLE"));

		// priority, start/due/done dates
		BOOL bDone = (NULL != pItem->GetItem("DONEDATESTRING"));

		if (bDone)
			sDoneDate.Format(" (completed: %s)", pItem->GetItemValue("DONEDATESTRING"));
		else
		{
			sPriority.Format("[%s] ", pItem->GetItemValue("PRIORITY"));

			if (pItem->GetItem("STARTDATESTRING"))
				sStartDate.Format(" (start: %s)", pItem->GetItemValue("STARTDATESTRING"));

			if (pItem->GetItem("DUEDATESTRING"))
				sDueDate.Format(" (due: %s)", pItem->GetItemValue("DUEDATESTRING"));


			double dTimeEst = CalcTimeEstimate(pItem);

			if (dTimeEst)
				sTimeEst.Format(" (time est: %.02f hrs)", dTimeEst);
		}

		sPercent.Format(" (%d%%) ", CalcPercentDone(pItem));

		// person
		if (pItem->GetItem("PERSON"))
			sPerson.Format(" (allocated to: %s)", pItem->GetItemValue("PERSON"));

		// fileref
		if (pItem->GetItem("FILEREFPATH"))
			sFileRef.Format("%s%s(file ref: %s)", ENDL, sTabs, pItem->GetItemValue("FILEREFPATH"));

		// comments
		if (pItem->GetItem("COMMENTS"))
			sComments.Format("%s%s[%s]", ENDL, sTabs, pItem->GetItemValue("COMMENTS"));

		sItem.Format("%d. %s%s%s%s%s%s%s%s%s%s", nPos, sPriority, sPercent, sTitle, sPerson, sDoneDate, sStartDate, sDueDate, sTimeEst, sFileRef, sComments, ENDL);

		// indent to match depth
		sOutput += sTabs;
		sOutput += sItem;
	}
	else if (!m_sProjectName.IsEmpty())
	{
		CString sUnderline('-', m_sProjectName.GetLength());
		sOutput.Format("%s%s%s%s", m_sProjectName, ENDL, sUnderline, ENDL);
	}

	// begin new ordered list for sub-tasks
	const CXmlItem* pTask = pItem->GetItem("TASK");

	if (pTask) // at least one sub-task
	{
		int nChildPos = 1;

		while (pTask)
		{
			CString sTask;
			sOutput += ENDL;
			sOutput += Export(pTask, nDepth + 1, nChildPos++, sTask);

			pTask = pTask->GetSibling();
		}
	}

	// extra line between top level items
	if (nDepth == 1)
		sOutput += ENDL;

	return sOutput;
}

