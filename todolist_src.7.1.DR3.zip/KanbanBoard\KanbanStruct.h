// KanbanStruct.h: interface for the CKanbanStruct class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_KanbanSTRUCT_H__C83C53D4_887E_4D5C_A8A7_85C8FDB19307__INCLUDED_)
#define AFX_KanbanSTRUCT_H__C83C53D4_887E_4D5C_A8A7_85C8FDB19307__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\Interfaces\iuiextension.h"

#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////

struct KANBANITEM 
{ 
	KANBANITEM(DWORD dwID = 0);
	KANBANITEM(const KANBANITEM& ki);
	virtual ~KANBANITEM();
	
	KANBANITEM& operator=(const KANBANITEM& ki);
	BOOL operator==(const KANBANITEM& ki) const;

	DWORD dwTaskID;
	COLORREF crText;
	BOOL bDone, bGoodAsDone;

	CString sTitle;
	CString sPath;
	CString sAllocTo;
	CString sTimeEst, sTimeSpent;

	void SetAttributeValue(LPCTSTR szAttrib, LPCTSTR szValue);
	CString GetAttributeValue(LPCTSTR szAttrib) const;

protected:
	CMapStringToString mapAttribValues;
};
typedef CArray<const KANBANITEM*, const KANBANITEM*> CKanbanItemArray;

/////////////////////////////////////////////////////////////////////////////

class CKanbanItemArrayMap : public CMap<CString, LPCTSTR, CKanbanItemArray*, CKanbanItemArray*&>
{
public:
	virtual ~CKanbanItemArrayMap();

	void RemoveAll();
};

/////////////////////////////////////////////////////////////////////////////

class CKanbanItemMap : public CMap<DWORD, DWORD, KANBANITEM*, KANBANITEM*&>
{
public:
	virtual ~CKanbanItemMap();

	void RemoveAll();
	BOOL RemoveKey(DWORD dwKey);
	BOOL HasItem(DWORD dwTaskID) const;
	int BuildTempItemArrays(LPCTSTR szAttribID, CKanbanItemArrayMap& map, CStringArray& aAttribValues) const;
	KANBANITEM* GetItem(DWORD dwTaskID) const;
	KANBANITEM* NewItem(DWORD dwTaskID, const CString& sTitle);
};

/////////////////////////////////////////////////////////////////////////////

struct KANBANCOLUMN
{
	KANBANCOLUMN();
	KANBANCOLUMN(const KANBANCOLUMN& kc);

	KANBANCOLUMN& operator=(const KANBANCOLUMN& kc);
	BOOL operator==(const KANBANCOLUMN& kc) const;
//	BOOL AttributeMatches(const KANBANCOLUMN& kc) const;

	CString sTitle;
	CString sAttribID;
	CStringArray aAttribValues;
	int nMaxTaskCount;
	COLORREF crBackground;
	COLORREF crExcess;
};
typedef CArray<KANBANCOLUMN, KANBANCOLUMN&> CKanbanColumnArray;

/////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_KanbanSTRUCT_H__C83C53D4_887E_4D5C_A8A7_85C8FDB19307__INCLUDED_)
