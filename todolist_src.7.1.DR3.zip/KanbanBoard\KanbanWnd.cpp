// KanbanWnd.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "KanbanBoard.h"
#include "KanbanWnd.h"

#include "..\todolist\tdcenum.h"
#include "..\todolist\tdcmsg.h"

#include "..\shared\misc.h"
#include "..\shared\themed.h"
#include "..\shared\graphicsmisc.h"
#include "..\shared\dialoghelper.h"
#include "..\shared\datehelper.h"
#include "..\shared\localizer.h"
#include "..\shared\autoflag.h"

#include "..\Interfaces\ipreferences.h"

#include <afxpriv.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

const COLORREF DEF_DONECOLOR		= RGB(128, 128, 128);

/////////////////////////////////////////////////////////////////////////////
// CKanbanWnd

CKanbanWnd::CKanbanWnd(CWnd* pParent /*=NULL*/)
	: 
	CDialog(IDD_KanbanTREE_DIALOG, pParent), 
	m_hIcon(NULL),
	m_bReadOnly(FALSE),
	m_bInSelectTask(FALSE)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_KANBAN);
}

CKanbanWnd::~CKanbanWnd()
{
}

void CKanbanWnd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CKanbanWnd)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CKanbanWnd, CDialog)
	//{{AFX_MSG_MAP(CKanbanWnd)
	ON_WM_SIZE()
	ON_WM_CTLCOLOR()
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_KANBAN_PREFS, OnKanbanPreferences)
	ON_UPDATE_COMMAND_UI(ID_KANBAN_PREFS, OnUpdateKanbanPreferences)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
	ON_WM_ERASEBKGND()
	ON_REGISTERED_MESSAGE(WM_KBC_STATUSCHANGE, OnKanbanNotifyStatusChange)
	ON_REGISTERED_MESSAGE(WM_KBC_NOTIFYSORT, OnKanbanNotifySortChange)
	ON_REGISTERED_MESSAGE(WM_KBC_SELECTIONCHANGE, OnKanbanNotifySelectionChange)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CKanbanWnd message handlers

void CKanbanWnd::SetReadOnly(bool bReadOnly)
{
	m_bReadOnly = bReadOnly;
	m_ctrlKanban.SetReadOnly(bReadOnly);
}

BOOL CKanbanWnd::Create(DWORD dwStyle, const RECT &/*rect*/, CWnd* pParentWnd, UINT nID)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	if (CDialog::Create(IDD_KANBAN_DIALOG, pParentWnd))
	{
		SetWindowLong(*this, GWL_STYLE, dwStyle);
		SetDlgCtrlID(nID);

		return TRUE;
	}

	return FALSE;
}

void CKanbanWnd::SavePreferences(IPreferences* pPrefs, LPCTSTR szKey) const 
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	CString sKey(szKey);

// 	pPrefs->WriteProfileInt(sKey, _T("MonthDisplay"), m_nDisplay);
// 	pPrefs->WriteProfileInt(sKey, _T("SortColumn"), m_ctrlKanban.GetSortColumn());
// 	pPrefs->WriteProfileInt(sKey, _T("SortAscending"), m_ctrlKanban.GetSortAscending());
// 
// 	// snap modes
// 	CString sSnapKey = sKey + _T("\\Snap");
// 
// 	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_YEARS, _T("Year"));
// 	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_QUARTERS_SHORT, _T("QuarterShort"));
// 	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_QUARTERS_MID, _T("QuarterMid"));
// 	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_QUARTERS_LONG, _T("QuarterLong"));
// 	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_MONTHS_SHORT, _T("MonthShort"));
// 	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_MONTHS_MID, _T("MonthMid"));
// 	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_MONTHS_LONG, _T("MonthLong"));
// 	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_WEEKS_SHORT, _T("WeekShort"));
// 	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_WEEKS_MID, _T("WeekMid"));
// 	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_WEEKS_LONG, _T("WeekLong"));
// 	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_DAYS_SHORT, _T("DayShort"));
// 	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_DAYS_MID, _T("DayMid"));
// 	SaveSnapModePreference(pPrefs, sSnapKey, GTLC_DISPLAY_DAYS_LONG, _T("DayLong"));
// 
// 	// column widths
// 	CIntArray aTreeOrder, aTreeWidths, aListWidths, aTreeTracked, aListTracked;
// 
// 	m_ctrlKanban.GetColumnOrder(aTreeOrder);
// 	m_ctrlKanban.GetColumnWidths(aTreeWidths, aListWidths);
// 	m_ctrlKanban.GetTrackedColumns(aTreeTracked, aListTracked);
// 
// 	SaveColumnState(pPrefs, (sKey + _T("\\TreeOrder")), aTreeOrder);
// 	SaveColumnState(pPrefs, (sKey + _T("\\TreeWidths")), aTreeWidths);
// 	SaveColumnState(pPrefs, (sKey + _T("\\ListWidths")), aListWidths);
// 	SaveColumnState(pPrefs, (sKey + _T("\\TreeTracked")), aTreeTracked);
// 	SaveColumnState(pPrefs, (sKey + _T("\\ListTracked")), aListTracked);

	m_dlgPrefs.SavePreferences(pPrefs, sKey);
}

/*
void CKanbanWnd::SaveColumnOrder(IPreferences* pPrefs, LPCTSTR szKey, const CIntArray& aStates) const
{
	int nCol = aStates.GetSize();
	pPrefs->WriteProfileInt(szKey, _T("Count"), nCol);

	while (nCol--)
	{
		CString sItemKey;
		sItemKey.Format(_T("Item%d"), nCol);
		pPrefs->WriteProfileInt(szKey, sItemKey, aStates[nCol]);
	}
}

int CKanbanWnd::LoadColumnOrder(const IPreferences* pPrefs, LPCTSTR szKey, CIntArray& aStates) const
{
	int nCol = pPrefs->GetProfileInt(szKey, _T("Count"), 0);

	if (!nCol)
		return 0;

	aStates.SetSize(nCol);
	
	while (nCol--)
	{
		CString sItemKey;
		sItemKey.Format(_T("Item%d"), nCol);
		aStates[nCol] = pPrefs->GetProfileInt(szKey, sItemKey);
	}

	return aStates.GetSize();
}
*/

void CKanbanWnd::LoadPreferences(const IPreferences* pPrefs, LPCTSTR szKey, bool bAppOnly) 
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	// application preferences

	// Completion color and strikethru
	BOOL bStrikeThru = pPrefs->GetProfileInt(_T("Preferences"), _T("StrikethroughDone"), TRUE);
	COLORREF crDone = CLR_NONE;

	if (pPrefs->GetProfileInt(_T("Preferences"), _T("SpecifyDoneColor"), TRUE))
		crDone = pPrefs->GetProfileInt(_T("Preferences\\Colors"), _T("TaskDone"), DEF_DONECOLOR);

	m_ctrlKanban.SetDoneTaskAttributes(crDone, bStrikeThru);

	// Kanban specific options
	if (!bAppOnly)
	{
		CString sKey(szKey);

		m_dlgPrefs.LoadPreferences(pPrefs, sKey);
		UpdateKanbanCtrlPreferences();
		
		if (GetSafeHwnd())
			UpdateData(FALSE);
	}
}

void CKanbanWnd::SetUITheme(const UITHEME* pTheme)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	GraphicsMisc::VerifyDeleteObject(m_brBack);

	if (CThemed::IsAppThemed() && pTheme)
	{
		m_theme = *pTheme;
		m_brBack.CreateSolidBrush(m_theme.crAppBackLight);
		
		// intentionally set background colours to be same as ours
		m_toolbar.SetBackgroundColors(m_theme.crAppBackLight, m_theme.crAppBackLight, FALSE, FALSE);
	}
}

bool CKanbanWnd::ProcessMessage(MSG* pMsg) 
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	if (IsWindowEnabled())
	{
		switch (pMsg->message)
		{
		// handle 'escape' during dragging
		case WM_KEYDOWN:
			if (pMsg->wParam == VK_ESCAPE)
			{
				if (m_ctrlKanban.CancelOperation())
				{
					return true;
				}
			}
			break;
		}
	}

	// all else
	return false;
}

bool CKanbanWnd::PrepareNewTask(ITaskList* pTask) const
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	return m_ctrlKanban.PrepareNewTask(pTask);
}

bool CKanbanWnd::GetLabelEditRect(LPRECT pEdit)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	if (m_ctrlKanban.GetLabelEditRect(pEdit))
	{
		// convert to screen coords
		ClientToScreen(pEdit);
		return true;
	}

	return false;
}

IUI_HITTEST CKanbanWnd::HitTest(const POINT& ptScreen) const
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	// specific task
	if (m_ctrlKanban.HitTestTask(ptScreen))
		return IUI_TASK;

	// else check elsewhere in ctrl client
	CRect rKanban;
	
	m_ctrlKanban.GetClientRect(rKanban);
	m_ctrlKanban.ClientToScreen(rKanban);

	if (rKanban.PtInRect(ptScreen))
		return IUI_TASKLIST;

	// else 
	return IUI_NOWHERE;
}


bool CKanbanWnd::SelectTask(DWORD dwTaskID)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	CAutoFlag af(m_bInSelectTask, TRUE);

	return (m_ctrlKanban.SelectTask(dwTaskID) != FALSE);
}

bool CKanbanWnd::SelectTasks(LPDWORD pdwTaskIDs, int nTaskCount)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	ASSERT(pdwTaskIDs);
	ASSERT(nTaskCount);
	
	CAutoFlag af(m_bInSelectTask, TRUE);
	CDWordArray aTaskIDs;

	for (int nID = 0; nID < nTaskCount; nID++)
		aTaskIDs.Add(pdwTaskIDs[nID]);
		
	return (m_ctrlKanban.SelectTasks(aTaskIDs) != FALSE);
}

bool CKanbanWnd::WantUpdate(IUI_ATTRIBUTEEDIT nAttribute) const
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	return (CKanbanCtrl::WantAttributeUpdate(nAttribute) != FALSE);
}

void CKanbanWnd::UpdateTasks(const ITaskList* pTasks, IUI_UPDATETYPE nUpdate, IUI_ATTRIBUTEEDIT nEditAttribute)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	m_ctrlKanban.UpdateTasks(pTasks, nUpdate, nEditAttribute);
}

void CKanbanWnd::Release()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	if (GetSafeHwnd())
		DestroyWindow();
	
	delete this;
}

void CKanbanWnd::DoAppCommand(IUI_APPCOMMAND nCmd, DWORD dwExtra) 
{ 
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

/*
	switch (nCmd)
	{
	case IUI_EXPANDALL:
		m_ctrlKanban.ExpandAll(TRUE);
		break;

	case IUI_COLLAPSEALL:
		m_ctrlKanban.ExpandAll(FALSE);
		break;

	case IUI_EXPANDSELECTED:
		{
			HTREEITEM htiSel = m_ctrlKanban.GetSelectedItem();
			m_ctrlKanban.ExpandItem(htiSel, TRUE, TRUE);
		}
		break;

	case IUI_COLLAPSESELECTED:
		{
			HTREEITEM htiSel = m_ctrlKanban.GetSelectedItem();
			m_ctrlKanban.ExpandItem(htiSel, FALSE);
		}
		break;

	case IUI_TOGGLABLESORT:
		m_ctrlKanban.Sort(MapColumn(dwExtra), TRUE);
		break;
				
	case IUI_SORT:
		m_ctrlKanban.Sort(MapColumn(dwExtra), FALSE);
		break;

	case IUI_SETFOCUS:
		m_ctrlKanban.SetFocus();
		break;

	case IUI_RESIZEATTRIBCOLUMNS:
		m_ctrlKanban.ResizeColumnsToFit();
		break;
	}
*/
}

bool CKanbanWnd::CanDoAppCommand(IUI_APPCOMMAND nCmd, DWORD dwExtra) const 
{ 
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
/*
	switch (nCmd)
	{
	case IUI_EXPANDALL:
	case IUI_COLLAPSEALL:
	case IUI_RESIZEATTRIBCOLUMNS:
		return true;

	case IUI_EXPANDSELECTED:
		{
			HTREEITEM htiSel = m_ctrlKanban.GetSelectedItem();
			return (m_ctrlKanban.CanExpandItem(htiSel, TRUE) != FALSE);
		}
		break;
	case IUI_COLLAPSESELECTED:
		{
			HTREEITEM htiSel = m_ctrlKanban.GetSelectedItem();
			return (m_ctrlKanban.CanExpandItem(htiSel, FALSE) != FALSE);
		}
		break;

	case IUI_TOGGLABLESORT:
	case IUI_SORT:
		return (MapColumn(dwExtra) != GTLCC_NONE);

	case IUI_SETFOCUS:
		return (m_ctrlKanban.HasFocus() != FALSE);
	}
*/

	// all else
	return false;
}

void CKanbanWnd::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	Resize(cx, cy);
}

BOOL CKanbanWnd::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// non-translatables
	CLocalizer::EnableTranslation(*GetDlgItem(IDC_SELECTEDTASKDATES), FALSE);

	// create toolbar
	if (m_toolbar.CreateEx(this))
	{
		const COLORREF MAGENTA = RGB(255, 0, 255);
		
		VERIFY(m_toolbar.LoadToolBar(IDR_TOOLBAR, IDB_TOOLBAR_STD, MAGENTA));
		VERIFY(m_tbHelper.Initialize(&m_toolbar, this));
		
		CRect rToolbar = CDialogHelper::GetCtrlRect(this, IDC_TB_PLACEHOLDER);
		m_toolbar.Resize(rToolbar.Width(), rToolbar.TopLeft());
		m_toolbar.RefreshButtonStates(TRUE);
	}

	// init syncer
	m_ctrlKanban.Create(WS_CHILD | WS_VISIBLE | WS_TABSTOP, CRect(0, 0, 0, 0), this, 101);

	CRect rClient;
	GetClientRect(rClient);
	Resize(rClient.Width(), rClient.Height());

	m_ctrlKanban.SetFocus();

	ModifyStyleEx(0, WS_EX_CONTROLPARENT, 0);

	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CKanbanWnd::Resize(int cx, int cy)
{
	if (m_ctrlKanban.GetSafeHwnd())
	{
		CRect rToolbar;
		m_toolbar.GetWindowRect(rToolbar);
		
		m_ctrlKanban.MoveWindow(0, rToolbar.Height(), cx, (cy - rToolbar.Height()));
	}
}

HBRUSH CKanbanWnd::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	if (nCtlColor == CTLCOLOR_STATIC && m_brBack.GetSafeHandle())
	{
		pDC->SetTextColor(m_theme.crAppText);
		pDC->SetBkMode(TRANSPARENT);
		hbr = m_brBack;
	}

	return hbr;
}

BOOL CKanbanWnd::OnEraseBkgnd(CDC* pDC) 
{
	// clip out our children
 	CDialogHelper::ExcludeChild(&m_ctrlKanban, pDC);

	// then our background
	if (m_brBack.GetSafeHandle())
	{
		CRect rClient;
		GetClientRect(rClient);

		pDC->FillSolidRect(rClient, m_theme.crAppBackLight);
		return TRUE;
	}
	
	// else
	return CDialog::OnEraseBkgnd(pDC);
}

void CKanbanWnd::SendParentSelectionUpdate()
{
	if (m_bInSelectTask)
		return;

	CDWordArray aSelIDs;
	m_ctrlKanban.GetSelectedTaskIDs(aSelIDs);

	//if (aSelIDs.GetSize())
	{
		switch (aSelIDs.GetSize())
		{
		case 0:
			GetParent()->SendMessage(WM_IUI_SELECTTASK, 0, 0);
			break;
			
		case 1:
			GetParent()->SendMessage(WM_IUI_SELECTTASK, 0, aSelIDs[0]);
			break;
			
		default:
			GetParent()->SendMessage(WM_IUI_SELECTTASK, (WPARAM)aSelIDs.GetData(), (LPARAM)aSelIDs.GetSize());
		}
	}
}

void CKanbanWnd::OnSetFocus(CWnd* pOldWnd) 
{
	// DON'T call dialog base class because
	// it will forcibly set focus to first list ctrl
// 	CDialog::OnSetFocus(pOldWnd);
	
	m_ctrlKanban.SetFocus();
}

void CKanbanWnd::UpdateKanbanCtrlPreferences()
{
	CString sCustomAttribID;
	IUI_ATTRIBUTEEDIT nTrackAttrib = m_dlgPrefs.GetAttribute(sCustomAttribID);

	CKanbanColumnArray aColDefs;
	m_dlgPrefs.GetColumnDefinitions(aColDefs);
	
	m_ctrlKanban.TrackAttribute(nTrackAttrib, sCustomAttribID, aColDefs);
}

LRESULT CKanbanWnd::OnKanbanNotifyStatusChange(WPARAM /*wp*/, LPARAM lp)
{
	IUITASKMOD mod = { IUI_STATUS, 0 };
	mod.szValue = (LPCTSTR)lp;
		
	GetParent()->SendMessage(WM_IUI_MODIFYSELECTEDTASK, 1, (LPARAM)&mod);
	return 0L;
}

LRESULT CKanbanWnd::OnKanbanNotifySelectionChange(WPARAM /*wp*/, LPARAM /*lp*/) 
{
	SendParentSelectionUpdate();
	
	return 0L;
}

LRESULT CKanbanWnd::OnKanbanNotifySortChange(WPARAM /*wp*/, LPARAM /*lp*/)
{
	// notify app
	//	GetParent()->SendMessage(WM_IUI_SORTCOLUMNCHANGE, 0, MapColumn((GTLC_COLUMN)lp));
	
	return 0L;
}

void CKanbanWnd::OnKanbanPreferences() 
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	if (m_dlgPrefs.DoModal() == IDOK)
	{
		// update Kanban control
		UpdateKanbanCtrlPreferences();
		
		// and set focus back to it
		m_ctrlKanban.SetFocus();
	}
}

void CKanbanWnd::OnUpdateKanbanPreferences(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(TRUE);
}

void CKanbanWnd::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	if (!bShow)
		m_ctrlKanban.CancelOperation();
}

/*
void CKanbanWnd::OnKanbanNewDepends() 
{
	OnKanbanDepends(GCDDM_ADD);
}

void CKanbanWnd::OnUpdateKanbanNewDepends(CCmdUI* pCmdUI) 
{
	OnUpdateKanbanDepends(GCDDM_ADD, pCmdUI);
}

void CKanbanWnd::OnKanbanEditDepends() 
{
	OnKanbanDepends(GCDDM_EDIT);
}

void CKanbanWnd::OnUpdateKanbanEditDepends(CCmdUI* pCmdUI) 
{
	OnUpdateKanbanDepends(GCDDM_EDIT, pCmdUI);
}

void CKanbanWnd::OnKanbanDeleteDepends() 
{
	OnKanbanDepends(GCDDM_DELETE);
}

void CKanbanWnd::OnUpdateKanbanDeleteDepends(CCmdUI* pCmdUI) 
{
	OnUpdateKanbanDepends(GCDDM_DELETE, pCmdUI);
}

void CKanbanWnd::OnKanbanDepends(GCDD_MODE nMode)
{
	if (!m_bReadOnly)
	{
		ASSERT (m_dlgDepends.GetSafeHwnd() == NULL);
		
		if (m_dlgDepends.Create(nMode, this))
		{
			VERIFY (m_ctrlKanban.BeginDependencyEdit(&m_dlgDepends));
			m_toolbar.RefreshButtonStates();
		}
	}
}

void CKanbanWnd::OnUpdateKanbanDepends(GCDD_MODE nMode, CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_dlgDepends.GetMode() == nMode);
	pCmdUI->Enable(!m_bReadOnly && ((m_dlgDepends.GetMode() == nMode) || (m_dlgDepends.GetMode() == GCDDM_NONE)));
}

LRESULT CKanbanWnd::OnKanbanDependencyDlgClose(WPARAM wp, LPARAM lp)
{
	UNREFERENCED_PARAMETER(lp);
	ASSERT(((HWND)lp) == m_dlgDepends);
	

	if (m_dlgDepends.IsPickingCompleted())
	{
		// make sure the from task is selected
		DWORD dwFromTaskID = m_dlgDepends.GetFromTask();

		if (m_ctrlKanban.GetSelectedTaskID() != dwFromTaskID)
		{
			SelectTask(dwFromTaskID);

			// explicitly update parent because SelectTask will not
			SendParentSelectionUpdate();
		}

		CStringArray aDepends;
		m_ctrlKanban.GetSelectedTaskDependencies(aDepends);
		
		switch (wp)
		{
		case GCDDM_ADD:
			{
				DWORD dwToTaskID = m_dlgDepends.GetToTask();
				aDepends.Add(Misc::Format(dwToTaskID));
			}
			break;
			
		case GCDDM_EDIT:
			{
				DWORD dwToTaskID = m_dlgDepends.GetToTask();
				aDepends.Add(Misc::Format(dwToTaskID));
			}
			 //fall thru to delete prev dependency
			
		case GCDDM_DELETE:
			{
				DWORD dwPrevToTask;
				VERIFY(m_dlgDepends.GetFromDependency(dwPrevToTask));

				CString sDepend = Misc::Format(dwPrevToTask);
				VERIFY(Misc::RemoveItem(sDepend, aDepends));
			}
			break;
			
		default:
			ASSERT(0);
			return 0L;
			
		}

		// notify parent
		CString sDepends = Misc::FormatArray(aDepends);
		IUITASKMOD mod = { 0 };

		mod.szValue = sDepends;
		mod.nAttrib = TDCA_DEPENDENCY;
			
		if (GetParent()->SendMessage(WM_IUI_MODIFYSELECTEDTASK, 1, (LPARAM)&mod))
		{
			// update Kanban ctrl
			m_ctrlKanban.SetSelectedTaskDependencies(aDepends);
		}
	}

	m_toolbar.RefreshButtonStates(FALSE);
	m_ctrlKanban.OnEndDepedencyEdit();
	m_ctrlKanban.SetFocus();

	return 0L;
}
*/
