#if !defined(AFX_KANBANLISTCTRL_H__059495EC_3D8D_4607_A4CF_20C142F8A294__INCLUDED_)
#define AFX_KANBANLISTCTRL_H__059495EC_3D8D_4607_A4CF_20C142F8A294__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// KanbanListCtrl.h : header file
//

#include "Kanbanstruct.h"

#include "..\Shared\EnHeaderCtrl.h"
#include "..\Shared\fontcache.h"

/////////////////////////////////////////////////////////////////////////////

enum // display flags
{
	KLC_DISPLAYPATH		= 0x01,
	KLC_DISPLAYALLOCTO	= 0x02,
	KLC_DISPLAYATTRIB	= 0x04,
	KLC_DISPLAYESTIMATE	= 0x08,
	KLC_DISPLAYSPENT	= 0x10,

	KLC_DISPLAYALL		= 0xff
};

/////////////////////////////////////////////////////////////////////////////
// CKanbanListCtrl window

class CKanbanListCtrl : public CListCtrl
{
// Construction
public:
	CKanbanListCtrl(const CKanbanItemMap& data, 
					const KANBANCOLUMN& columnDef, 
					CFontCache& fonts,
					DWORD dwDisplay = KLC_DISPLAYALL);

	CString GetAttributeID() const;
	int GetAttributeValues(CStringArray& aValues) const;
	CString GetAttributeValue() const;
	BOOL HasMultipleValues() const;
	BOOL HasAnyValues() const;
	//COLORREF GetBkgndColor() const { return m_columnDef.crBackground; }

	BOOL Create(UINT nID, CWnd* pParentWnd, HIMAGELIST hilHeight);
	int AddTask(LPCTSTR szTitle, DWORD dwTaskID, BOOL bSelect);
	void RefreshColumnTitle();
	void SetDisplay(DWORD dwDisplay);
	void SetDoneTaskAttributes(COLORREF color, BOOL bStrikeThru);

	int FindTask(DWORD dwItemID) const;
	int FindTask(const CPoint& ptScreen) const;

	int GetSelectedTasks(CDWordArray& aTaskIDs) const;
	BOOL SelectTasks(const CDWordArray& aTaskIDs);
	BOOL SelectTask(DWORD dwTaskID);
	void ScrollToSelection();
	BOOL SelectItem(int nItem, BOOL bFocus = FALSE);

protected:
	const CKanbanItemMap& m_data;
	CFontCache& m_fonts;
// 	CString m_sStatus;
// 	COLORREF m_color;
	CEnHeaderCtrl m_header;
	KANBANCOLUMN m_columnDef;
	DWORD m_dwDisplay;
	COLORREF m_crDoneTasks;
	BOOL m_bStrikeThruDoneTasks;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CKanbanListCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CKanbanListCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CKanbanListCtrl)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	afx_msg void OnListCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnHeaderCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);

	DECLARE_MESSAGE_MAP()

protected:
	const KANBANITEM* GetKanbanItem(DWORD dwTaskID) const;

};

/////////////////////////////////////////////////////////////////////////////

class CKanbanListCtrlArray : public CArray<CKanbanListCtrl*, CKanbanListCtrl*&>
{
public:
	virtual ~CKanbanListCtrlArray();
	
	void RemoveAll();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_KANBANLISTCTRL_H__059495EC_3D8D_4607_A4CF_20C142F8A294__INCLUDED_)
