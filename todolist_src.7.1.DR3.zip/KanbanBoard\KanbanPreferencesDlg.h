#if !defined(AFX_KANBANPREFERENCESDLG_H__4BEDF571_7002_4C0D_B355_1334515CA1F9__INCLUDED_)
#define AFX_KANBANPREFERENCESDLG_H__4BEDF571_7002_4C0D_B355_1334515CA1F9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// KanbanPreferencesDlg.h : header file
//

#include "KanbanStruct.h"

//#include "..\shared\colorbutton.h"
#include "..\shared\groupline.h"
#include "..\shared\scrollingpropertypagehost.h"
#include "..\shared\inputlistctrl.h"
#include "..\Shared\entoolbar.h"
#include "..\Shared\toolbarhelper.h"

#include "..\Interfaces\ipreferences.h"
#include "..\Interfaces\iuiextension.h"

/////////////////////////////////////////////////////////////////////////////
// CKanbanPreferencesPage dialog

class CKanbanPreferencesPage : public CPropertyPage
{
// Construction
public:
	CKanbanPreferencesPage(CWnd* pParent = NULL);   // standard constructor

	int GetColumnDefinitions(CKanbanColumnArray& aColumnDefs) const;
	BOOL GetShowParents() const { return m_bShowParents; }
	BOOL GetSortSubtasksBelowParents() const { return m_bSortSubtaskBelowParent; }
	BOOL GetHideEmptyColumns() const { return m_bHideEmptyColumns; }
	IUI_ATTRIBUTEEDIT GetAttribute(CString& sCustomID) const;

	void SavePreferences(IPreferences* pPrefs, LPCTSTR szKey) const;
	void LoadPreferences(const IPreferences* pPrefs, LPCTSTR szKey);

protected:
// Dialog Data
	//{{AFX_DATA(CKanbanPreferencesPage)
	//}}AFX_DATA
	CComboBox	m_cbAttributes;
	CInputListCtrl	m_lcColumnDefs;
	CGroupLineManager m_mgrGroupLines;
	CEnToolBar m_toolbar;
	CToolbarHelper m_tbHelper;

	BOOL	m_bShowParents;
	BOOL	m_bSortSubtaskBelowParent;
	int		m_bFixedColumns;
	BOOL	m_bHideEmptyColumns;
	CString	m_sCustomAttribID;
	IUI_ATTRIBUTEEDIT m_nAttrib;

	CKanbanColumnArray m_aColumnDefs;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CKanbanPreferencesPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	//}}AFX_VIRTUAL
	virtual void OnOK();

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CKanbanPreferencesPage)
	afx_msg void OnChangeColumnType();
	afx_msg void OnSelchangeAttribute();
	afx_msg void OnMoveColDown();
	afx_msg void OnUpdateMoveColDown(CCmdUI* pCmdUI);
	afx_msg void OnMoveColUp();
	afx_msg void OnUpdateMoveColUp(CCmdUI* pCmdUI);
	afx_msg void OnItemchangedColumndefs(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);

	DECLARE_MESSAGE_MAP()

protected:
	BOOL MoveSelectedColumnRow(BOOL bUp);
	BOOL CanMoveSelectedColumnRow(BOOL bUp) const;
};

/////////////////////////////////////////////////////////////////////////////
// CKanbanPreferencesDlg dialog

class CKanbanPreferencesDlg : public CDialog
{
// Construction
public:
	CKanbanPreferencesDlg(CWnd* pParent = NULL);   // standard constructor

	int GetColumnDefinitions(CKanbanColumnArray& aColumnDefs) const { return m_page.GetColumnDefinitions(aColumnDefs); }
	BOOL GetShowParents() const { return m_page.GetShowParents(); }
	BOOL GetSortSubtasksBelowParents() const { return m_page.GetSortSubtasksBelowParents(); }
	BOOL GetHideEmptyColumns() const { return m_page.GetHideEmptyColumns(); }
	IUI_ATTRIBUTEEDIT GetAttribute(CString& sCustomID) const { return m_page.GetAttribute(sCustomID); }

	void SavePreferences(IPreferences* pPrefs, LPCTSTR szKey) const { m_page.SavePreferences(pPrefs, szKey); }
	void LoadPreferences(const IPreferences* pPrefs, LPCTSTR szKey) { m_page.LoadPreferences(pPrefs, szKey); }

protected:
	CKanbanPreferencesPage m_page;
	CScrollingPropertyPageHost m_ppHost;
	HICON m_hIcon;

protected:
	virtual BOOL OnInitDialog();
	virtual void OnOK();

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CKanbanPreferencesDlg)
	//}}AFX_MSG
	afx_msg void OnDestroy();
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_KanbanPREFERENCESDLG_H__4BEDF571_7002_4C0D_B355_1334515CA1F9__INCLUDED_)
