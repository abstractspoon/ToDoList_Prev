// colorbutton.cpp : implementation file
//

#include "stdafx.h"
#include "iconbutton.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIconButton

CIconButton::CIconButton()
{
}

CIconButton::~CIconButton()
{
	m_ilIcon.DeleteImageList();
}


BEGIN_MESSAGE_MAP(CIconButton, CCustomButton)
	//{{AFX_MSG_MAP(CIconButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIconButton message handlers

void CIconButton::DoExtraPaint(CDC* pDC, const CRect& rExtra)
{
	if (m_ilIcon.GetSafeHandle() && (m_ilIcon.GetImageCount() == 1))
		m_ilIcon.Draw(pDC, 0, rExtra.TopLeft(), ILD_TRANSPARENT);
}

void CIconButton::SetIcon(HICON hIcon, BOOL bCleanup)
{ 
	if (hIcon)
	{
		if (!m_ilIcon.GetSafeHandle())
		{
			m_ilIcon.Create(16, 16, (ILC_COLOR32 | ILC_MASK), 1, 1);
			VERIFY(m_ilIcon.Add(hIcon) == 0);
		}
		else
		{
			ASSERT(m_ilIcon.GetImageCount() == 1);
			m_ilIcon.Replace(0, hIcon);
		}
		
		if (bCleanup)
			::DestroyIcon(hIcon);
	}
	else
	{
		m_ilIcon.DeleteImageList();
	}
	
	if (GetSafeHwnd())
		Invalidate();
}

