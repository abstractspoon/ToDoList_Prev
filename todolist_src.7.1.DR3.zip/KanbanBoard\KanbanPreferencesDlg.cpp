// KanbanPreferencesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "KanbanPreferencesDlg.h"

#include "..\shared\dialoghelper.h"
#include "..\shared\misc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CKanbanPreferencesPage dialog

CKanbanPreferencesPage::CKanbanPreferencesPage(CWnd* /*pParent*/ /*=NULL*/)
	: 
	CPropertyPage(IDD_PREFERENCES_PAGE), 
	m_nAttrib(IUI_STATUS)
{
	//{{AFX_DATA_INIT(CKanbanPreferencesPage)
	m_bShowParents = FALSE;
	m_bSortSubtaskBelowParent = FALSE;
	m_bFixedColumns = FALSE;
	m_bHideEmptyColumns = FALSE;
	m_sCustomAttribID = _T("");
	//}}AFX_DATA_INIT
}

void CKanbanPreferencesPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);

	//{{AFX_DATA_MAP(CKanbanPreferencesPage)
	DDX_Control(pDX, IDC_ATTRIBUTES, m_cbAttributes);
	DDX_Check(pDX, IDC_SHOWPARENTTASKS, m_bShowParents);
	DDX_Check(pDX, IDC_SORTSUBTASKSBELOWPARENT, m_bSortSubtaskBelowParent);
	DDX_Radio(pDX, IDC_DYNAMICCOLUMNS, m_bFixedColumns);
	DDX_Check(pDX, IDC_HIDEEMPTYCOLS, m_bHideEmptyColumns);
	DDX_Control(pDX, IDC_COLUMNDEFS, m_lcColumnDefs);
	DDX_Text(pDX, IDC_CUSTOMATTRIBID, m_sCustomAttribID);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CKanbanPreferencesPage, CPropertyPage)
	//{{AFX_MSG_MAP(CKanbanPreferencesPage)
	ON_BN_CLICKED(IDC_DYNAMICCOLUMNS, OnChangeColumnType)
	ON_CBN_SELCHANGE(IDC_ATTRIBUTES, OnSelchangeAttribute)
	ON_COMMAND(ID_MOVECOL_DOWN, OnMoveColDown)
	ON_UPDATE_COMMAND_UI(ID_MOVECOL_DOWN, OnUpdateMoveColDown)
	ON_COMMAND(ID_MOVECOL_UP, OnMoveColUp)
	ON_UPDATE_COMMAND_UI(ID_MOVECOL_UP, OnUpdateMoveColUp)
	ON_BN_CLICKED(IDC_FIXEDCOLUMNS, OnChangeColumnType)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_COLUMNDEFS, OnItemchangedColumndefs)
	//}}AFX_MSG_MAP
	ON_WM_CTLCOLOR()
	ON_WM_ERASEBKGND()
	ON_WM_SHOWWINDOW()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CKanbanPreferencesPage message handlers

BOOL CKanbanPreferencesPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// create toolbar
	if (m_toolbar.CreateEx(this, (TBSTYLE_FLAT | TBSTYLE_WRAPABLE)))
	{
		const COLORREF MAGENTA = RGB(255, 0, 255);
		
		VERIFY(m_toolbar.LoadToolBar(IDR_COLUMN_TOOLBAR, IDB_COLUMN_TOOLBAR_STD, MAGENTA));
		VERIFY(m_tbHelper.Initialize(&m_toolbar, this));
		
		CRect rToolbar = CDialogHelper::GetCtrlRect(this, IDC_TB_PLACEHOLDER);
		m_toolbar.Resize(rToolbar.Width(), rToolbar.TopLeft());
		m_toolbar.RefreshButtonStates(TRUE);
		m_toolbar.SetBackgroundColors(GetSysColor(COLOR_WINDOW),GetSysColor(COLOR_WINDOW), FALSE, FALSE);
	}
	
	m_mgrGroupLines.AddGroupLine(IDC_COLUMNGROUP, *this);

	CDialogHelper::AddString(m_cbAttributes, CEnString(IDS_STATUSATTRIB), IUI_STATUS);
	CDialogHelper::AddString(m_cbAttributes, CEnString(IDS_CUSTOMATTRIB), IUI_CUSTOMATTRIB);

	CRect rClient;
	m_lcColumnDefs.GetClientRect(rClient);

	m_lcColumnDefs.AddCol(CEnString(IDS_COLUMNTITLE), (rClient.Width() / 3));
	m_lcColumnDefs.AddCol(CEnString(IDS_ATTRIBVALUES), (rClient.Width() / 3));
	m_lcColumnDefs.AddCol(CEnString(IDS_MAXTASKCOUNT), (rClient.Width() / 3));

	m_lcColumnDefs.SetAutoRowPrompt(CEnString(IDS_NEWCOLUMN));
	m_lcColumnDefs.AutoAdd(TRUE, FALSE);
	m_lcColumnDefs.ShowGrid(TRUE, TRUE);
	m_lcColumnDefs.EnableHeaderTracking(FALSE);
	
	CDialogHelper::SelectItemByData(m_cbAttributes, m_nAttrib);
	
	OnChangeColumnType();
	OnSelchangeAttribute();

	// fill column defs
	int nNumDefs = m_aColumnDefs.GetSize();
	
	for (int nDef = 0; nDef < nNumDefs; nDef++)
	{
		const KANBANCOLUMN& colDef = m_aColumnDefs.GetData()[nDef];
		
		int nItem = m_lcColumnDefs.InsertItem(nDef, colDef.sTitle);

		m_lcColumnDefs.SetItemText(nItem, 1, Misc::FormatArray(colDef.aAttribValues));

		if (colDef.nMaxTaskCount > 0)
			m_lcColumnDefs.SetItemText(nItem, 2, Misc::Format(colDef.nMaxTaskCount));
	}
	m_lcColumnDefs.SetCurSel(0);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

IUI_ATTRIBUTEEDIT CKanbanPreferencesPage::GetAttribute(CString& sCustomAttribID) const
{
	if (m_nAttrib == IUI_CUSTOMATTRIB)
		sCustomAttribID = m_sCustomAttribID;
	else
		sCustomAttribID.Empty();

	return m_nAttrib;
}

void CKanbanPreferencesPage::OnOK()
{
	CPropertyPage::OnOK();

	int nNumDefs = (m_lcColumnDefs.GetItemCount() - 1);
	
	m_aColumnDefs.SetSize(nNumDefs);
	
	for (int nDef = 0; nDef < nNumDefs; nDef++)
	{
		KANBANCOLUMN& colDef = m_aColumnDefs[nDef];
		
		colDef.sTitle = m_lcColumnDefs.GetItemText(nDef, 0);
		colDef.nMaxTaskCount = _ttoi(m_lcColumnDefs.GetItemText(nDef, 2));

		Misc::Split(m_lcColumnDefs.GetItemText(nDef, 1), colDef.aAttribValues);
	}
}

int CKanbanPreferencesPage::GetColumnDefinitions(CKanbanColumnArray& aColumnDefs) const
{
	aColumnDefs.RemoveAll();

	if (m_bFixedColumns)
		aColumnDefs.Copy(m_aColumnDefs);

	return aColumnDefs.GetSize();
}

BOOL CKanbanPreferencesPage::OnEraseBkgnd(CDC* pDC)
{
	CRect rClient;
	GetClientRect(rClient);
	pDC->FillSolidRect(rClient, GetSysColor(COLOR_WINDOW));

	return TRUE;
}

HBRUSH CKanbanPreferencesPage::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CPropertyPage::OnCtlColor(pDC, pWnd, nCtlColor);

	if (nCtlColor == CTLCOLOR_STATIC)
	{
		pDC->SetBkMode(TRANSPARENT);
		hbr = GetSysColorBrush(COLOR_WINDOW);
	}
	
	return hbr;
}

void CKanbanPreferencesPage::OnShowWindow(BOOL bShow, UINT nStatus)
{
	CPropertyPage::OnShowWindow(bShow, nStatus);

	if (bShow)
		CDialogHelper::ResizeButtonStaticTextFieldsToFit(this);
}

void CKanbanPreferencesPage::SavePreferences(IPreferences* pPrefs, LPCTSTR szKey) const
{
	pPrefs->WriteProfileInt(szKey, _T("Attribute"), m_nAttrib);
	pPrefs->WriteProfileString(szKey, _T("CustomAttributeID"), m_sCustomAttribID);

	pPrefs->WriteProfileInt(szKey, _T("FixedColumns"), m_bFixedColumns);
	pPrefs->WriteProfileInt(szKey, _T("HideEmptyColumns"), m_bHideEmptyColumns);
	pPrefs->WriteProfileInt(szKey, _T("ShowParents"), m_bShowParents);
	pPrefs->WriteProfileInt(szKey, _T("SortSubtaskBelowParent"), m_bSortSubtaskBelowParent);

	// column defs
	int nNumDefs = m_aColumnDefs.GetSize();
	pPrefs->WriteProfileInt(szKey, _T("FixedColumnCount"), nNumDefs);

	for (int nDef = 0; nDef < nNumDefs; nDef++)
	{
		const KANBANCOLUMN& colDef = m_aColumnDefs.GetData()[nDef];
		CString sColKey = Misc::MakeKey(_T("ColumnDef%d"), nDef, szKey);

		pPrefs->WriteProfileString(sColKey, _T("Title"), colDef.sTitle);
		pPrefs->WriteProfileString(sColKey, _T("Value"), Misc::FormatArray(colDef.aAttribValues));
		pPrefs->WriteProfileInt(sColKey, _T("MaxItems"), colDef.nMaxTaskCount);
	}
}

void CKanbanPreferencesPage::LoadPreferences(const IPreferences* pPrefs, LPCTSTR szKey) 
{
	m_nAttrib = (IUI_ATTRIBUTEEDIT)pPrefs->GetProfileInt(szKey, _T("Attribute"), IUI_STATUS);
	m_sCustomAttribID = pPrefs->GetProfileString(szKey, _T("CustomAttributeID"));
	
	m_bFixedColumns = pPrefs->GetProfileInt(szKey, _T("FixedColumns"), FALSE);
	m_bHideEmptyColumns = pPrefs->GetProfileInt(szKey, _T("HideEmptyColumns"), FALSE);
	m_bShowParents = pPrefs->GetProfileInt(szKey, _T("ShowParents"), FALSE);
	m_bSortSubtaskBelowParent = pPrefs->GetProfileInt(szKey, _T("SortSubtaskBelowParent"), TRUE);

	// column defs
	int nNumDefs = pPrefs->GetProfileInt(szKey, _T("FixedColumnCount"));
	m_aColumnDefs.SetSize(nNumDefs);

	for (int nDef = 0; nDef < nNumDefs; nDef++)
	{
		KANBANCOLUMN& colDef = m_aColumnDefs[nDef];
		CString sColKey = Misc::MakeKey(_T("ColumnDef%d"), nDef, szKey);
			
		colDef.sTitle = pPrefs->GetProfileString(sColKey, _T("Title"));
		colDef.nMaxTaskCount = pPrefs->GetProfileInt(sColKey, _T("MaxItems"));

		Misc::Split(pPrefs->GetProfileString(sColKey, _T("Value")), colDef.aAttribValues);
	}
}

void CKanbanPreferencesPage::OnChangeColumnType() 
{
	UpdateData();
	
	m_lcColumnDefs.EnableWindow(m_bFixedColumns);
	GetDlgItem(IDC_HIDEEMPTYCOLS)->EnableWindow(m_bFixedColumns);

	if (m_toolbar.GetSafeHwnd())
		m_toolbar.RefreshButtonStates();
}

void CKanbanPreferencesPage::OnSelchangeAttribute() 
{
	m_nAttrib = (IUI_ATTRIBUTEEDIT)CDialogHelper::GetSelectedItemData(m_cbAttributes);
	
	GetDlgItem(IDC_CUSTOMATTRIBID)->EnableWindow(m_nAttrib == IUI_CUSTOMATTRIB);
}

void CKanbanPreferencesPage::OnMoveColDown() 
{
	VERIFY(MoveSelectedColumnRow(FALSE));
}

void CKanbanPreferencesPage::OnUpdateMoveColDown(CCmdUI* pCmdUI) 
{
	int nRow = m_lcColumnDefs.GetCurSel();

	pCmdUI->Enable(CanMoveSelectedColumnRow(FALSE));
}

void CKanbanPreferencesPage::OnMoveColUp() 
{
	VERIFY(MoveSelectedColumnRow(TRUE));
}

BOOL CKanbanPreferencesPage::CanMoveSelectedColumnRow(BOOL bUp) const
{
	if (!m_bFixedColumns)
		return FALSE;

	int nRow = m_lcColumnDefs.GetCurSel();
	int nNumRows = (m_lcColumnDefs.GetItemCount() - 1);
	
	if ((nRow < 0) || (nRow >= nNumRows))
		return FALSE;
	
	if (bUp)
		nRow--;
	else
		nRow++;

	return ((nRow >= 0) && (nRow < nNumRows));
}

BOOL CKanbanPreferencesPage::MoveSelectedColumnRow(BOOL bUp)
{
	if (!CanMoveSelectedColumnRow(bUp))
		return FALSE;

	int nRow = m_lcColumnDefs.GetCurSel();

	CString sTitle = m_lcColumnDefs.GetItemText(nRow, 0);
	CString sValue = m_lcColumnDefs.GetItemText(nRow, 1);
	CString sMaxTasks = m_lcColumnDefs.GetItemText(nRow, 2);
		
	m_lcColumnDefs.DeleteItem(nRow);
		
	int nNewRow = (nRow + (bUp ? -1 : 1));

	nRow = m_lcColumnDefs.InsertItem(nNewRow, sTitle);
	m_lcColumnDefs.SetItemText(nRow, 1, sValue);
	m_lcColumnDefs.SetItemText(nRow, 2, sMaxTasks);
		
	m_lcColumnDefs.SetCurSel(nRow);

	return TRUE;
}

void CKanbanPreferencesPage::OnUpdateMoveColUp(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(CanMoveSelectedColumnRow(TRUE));
}

void CKanbanPreferencesPage::OnItemchangedColumndefs(NMHDR* /*pNMHDR*/, LRESULT* pResult) 
{
	if (m_toolbar.GetSafeHwnd())
		m_toolbar.RefreshButtonStates();
	
	*pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////
// CKanbanPreferencesDlg dialog

CKanbanPreferencesDlg::CKanbanPreferencesDlg(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_PREFERENCES_DIALOG, pParent),
	m_hIcon(NULL)
{
	//{{AFX_DATA_INIT(CKanbanPreferencesDlg)
	//}}AFX_DATA_INIT

	m_ppHost.AddPage(&m_page);
}

BEGIN_MESSAGE_MAP(CKanbanPreferencesDlg, CDialog)
	//{{AFX_MSG_MAP(CKanbanPreferencesDlg)
	//}}AFX_MSG_MAP
	ON_WM_DESTROY()
END_MESSAGE_MAP()

BOOL CKanbanPreferencesDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_ppHost.Create(IDC_PPHOST, this);

	// shrink the ppHost by 1 pixel to allow the border to show
	CRect rHost;
	m_ppHost.GetWindowRect(rHost);
	ScreenToClient(rHost);

	rHost.DeflateRect(1, 1);
	m_ppHost.MoveWindow(rHost, FALSE);
	
	// Replace icon
	m_hIcon = AfxGetApp()->LoadIcon(IDR_KANBAN);
	SendMessage(WM_SETICON, ICON_SMALL, (LPARAM)m_hIcon);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CKanbanPreferencesDlg::OnOK()
{
	CDialog::OnOK();

	m_ppHost.OnOK();
}

void CKanbanPreferencesDlg::OnDestroy()
{
	CDialog::OnDestroy();
	
	::DestroyIcon(m_hIcon);
}
