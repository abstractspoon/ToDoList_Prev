// KanbanStruct.cpp: implementation of the CKanbanStruct class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "KanbanStruct.h"

#include "..\shared\DateHelper.h"
#include "..\shared\graphicsMisc.h"
#include "..\shared\misc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////

KANBANITEM::KANBANITEM(DWORD dwID) 
	: 
	crText(CLR_NONE), 
	dwTaskID(dwID), 
	bDone(FALSE), 
	bGoodAsDone(FALSE)
{

}

KANBANITEM::KANBANITEM(const KANBANITEM& ki)
{
	*this = ki;
}

KANBANITEM& KANBANITEM::operator=(const KANBANITEM& ki)
{
	dwTaskID = ki.dwTaskID;
	sTitle = ki.sTitle;
	sPath = ki.sPath;
	crText = ki.crText;
	sTimeEst = ki.sTimeEst;
	sTimeSpent = ki.sTimeSpent;
	bDone = ki.bDone;
	bGoodAsDone = ki.bGoodAsDone;

	Misc::Copy(ki.mapAttribValues, mapAttribValues);
	
	return (*this);
}

BOOL KANBANITEM::operator==(const KANBANITEM& ki) const
{
	return ((dwTaskID == ki.dwTaskID) &&
			(sTitle == ki.sTitle) && 
			(sPath == ki.sPath) &&
			(crText == ki.crText) &&
			(sAllocTo == ki.sAllocTo) &&
			(sTimeEst == ki.sTimeEst) &&
			(sTimeSpent == ki.sTimeSpent) &&
			(bDone == ki.bDone) &&
			(bGoodAsDone == ki.bGoodAsDone) &&
			Misc::MatchAll(mapAttribValues, ki.mapAttribValues));
}

KANBANITEM::~KANBANITEM()
{
	
}

void KANBANITEM::SetAttributeValue(LPCTSTR szAttrib, LPCTSTR szValue)
{
	ASSERT(szAttrib && szAttrib[0]);

	if (!szValue || !szValue[0])
		mapAttribValues.RemoveKey(szAttrib);
	else
		mapAttribValues[szAttrib] = szValue;
}

CString KANBANITEM::GetAttributeValue(LPCTSTR szAttrib) const
{
	ASSERT(szAttrib && szAttrib[0]);
	
	CString sValue;
	mapAttribValues.Lookup(szAttrib, sValue);
		
	return sValue;
}

//////////////////////////////////////////////////////////////////////

CKanbanItemMap::~CKanbanItemMap()
{
	RemoveAll();
}

void CKanbanItemMap::RemoveAll()
{
	DWORD dwTaskID = 0;
	KANBANITEM* pKI = NULL;
	
	POSITION pos = GetStartPosition();
	
	while (pos)
	{
		GetNextAssoc(pos, dwTaskID, pKI);
		ASSERT(pKI);
		
		delete pKI;
	}
	
	CMap<DWORD, DWORD, KANBANITEM*, KANBANITEM*&>::RemoveAll();
}

BOOL CKanbanItemMap::RemoveKey(DWORD dwKey)
{
	KANBANITEM* pKI = NULL;
	
	if (Lookup(dwKey, pKI))
	{
		delete pKI;
		return CMap<DWORD, DWORD, KANBANITEM*, KANBANITEM*&>::RemoveKey(dwKey);
	}
	
	// else
	return FALSE;
}

KANBANITEM* CKanbanItemMap::GetItem(DWORD dwTaskID) const
{
	KANBANITEM* pKI = NULL;
	
	if (Lookup(dwTaskID, pKI))
		ASSERT(pKI);

	return pKI;
}

BOOL CKanbanItemMap::HasItem(DWORD dwTaskID) const
{
	return (GetItem(dwTaskID) != NULL);
}

KANBANITEM* CKanbanItemMap::NewItem(DWORD dwTaskID, const CString& sTitle)
{
	ASSERT(!sTitle.IsEmpty());

	if (sTitle.IsEmpty())
		return NULL;

	KANBANITEM* pKI = GetItem(dwTaskID);
	ASSERT(pKI == NULL);

	if (!pKI)
	{
		pKI = new KANBANITEM(dwTaskID);
		SetAt(dwTaskID, pKI);
	}

	pKI->sTitle = sTitle;

	return pKI;
}

int CKanbanItemMap::BuildTempItemArrays(LPCTSTR szAttribID, CKanbanItemArrayMap& map, CStringArray& aAttribValues) const
{
	ASSERT(szAttribID && szAttribID[0]);

	map.RemoveAll();
	aAttribValues.RemoveAll();

	DWORD dwTaskID = 0;
	KANBANITEM* pKI = NULL;

	POSITION pos = GetStartPosition();

	while (pos)
	{
		GetNextAssoc(pos, dwTaskID, pKI);
		ASSERT(pKI);

		CKanbanItemArray* pKItems = NULL;
		CString sAttribValue = pKI->GetAttributeValue(szAttribID);
			
		if (!map.Lookup(sAttribValue, pKItems))
		{
			pKItems = new CKanbanItemArray;
			map[sAttribValue] = pKItems;

			aAttribValues.Add(sAttribValue);
		}
		else
		{
			ASSERT(pKItems);
		}

		const KANBANITEM* pCKI = pKI;
		pKItems->Add(pCKI);
	}
	ASSERT(map.GetCount() == aAttribValues.GetSize());

	return map.GetCount();
}

//////////////////////////////////////////////////////////////////////

CKanbanItemArrayMap::~CKanbanItemArrayMap()
{
	RemoveAll();
}

void CKanbanItemArrayMap::RemoveAll()
{
	CKanbanItemArray* pArr;
	CString sStatus;

	POSITION pos = GetStartPosition();

	while (pos)
	{
		GetNextAssoc(pos, sStatus, pArr);
		ASSERT(pArr);

		delete pArr;
	}

	CMap<CString, LPCTSTR, CKanbanItemArray*, CKanbanItemArray*&>::RemoveAll();
}

//////////////////////////////////////////////////////////////////////

KANBANCOLUMN::KANBANCOLUMN() 
	: 
	nMaxTaskCount(0), 
	crBackground(GetSysColor(COLOR_WINDOW)), 
	crExcess(255) 
{

}

KANBANCOLUMN::KANBANCOLUMN(const KANBANCOLUMN& kc)
{
	*this = kc;
}
	
KANBANCOLUMN& KANBANCOLUMN::operator=(const KANBANCOLUMN& kc)
{
	sTitle = kc.sTitle;
	sAttribID = kc.sAttribID;
	aAttribValues.Copy(kc.aAttribValues);
	nMaxTaskCount = kc.nMaxTaskCount;
	crBackground = kc.crBackground;
	crExcess = kc.crExcess;

	return *this;
}

BOOL KANBANCOLUMN::operator==(const KANBANCOLUMN& kc) const
{
	return ((sTitle == kc.sTitle) &&
			(sAttribID == kc.sAttribID) &&
			Misc::MatchAll(aAttribValues, kc.aAttribValues) &&
			(nMaxTaskCount == kc.nMaxTaskCount) &&
			(crBackground == kc.crBackground) &&
			(crExcess == kc.crExcess));
}

// BOOL KANBANCOLUMN::AttributeMatches(const KANBANCOLUMN& kc) const
// {
// 	return ((sAttribID == kc.sAttribID) && (aAttribValues == kc.aAttribValues));
// }

//////////////////////////////////////////////////////////////////////
