// tdlhelpbutton.cpp : implementation file
//

#include "stdafx.h"
#include "winhelpbutton.h"
#include "dlgunits.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

HICON CWinHelpButton::s_hHelpIcon = NULL;

/////////////////////////////////////////////////////////////////////////////
// CWinHelpButton

CWinHelpButton::CWinHelpButton(UINT nHelpID, BOOL bAutoHandleClick) 
	: 
	m_nHelpID(nHelpID),
	m_bAutoHandleClick(bAutoHandleClick)
{
	ASSERT(m_nHelpID);
	ASSERT(s_hHelpIcon);

	CIconButton::SetIcon(s_hHelpIcon, FALSE);
}

CWinHelpButton::~CWinHelpButton()
{
}

BEGIN_MESSAGE_MAP(CWinHelpButton, CIconButton)
	//{{AFX_MSG_MAP(CWinHelpButton)
	//}}AFX_MSG_MAP
	ON_WM_SHOWWINDOW()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinHelpButton message handlers

BOOL CWinHelpButton::Create(UINT nID, CWnd* pParent, CRect rPos)
{
	CRect rButton(rPos);

	if (rButton.IsRectNull())
	{
		CDlgUnits dlu(this);
		
		pParent->GetClientRect(rButton);
		
		rButton.DeflateRect(dlu.ToPixelsX(7), dlu.ToPixelsY(7));;
		rButton.top = (rButton.bottom - dlu.ToPixelsY(14));
		rButton.right = (rButton.left + dlu.ToPixelsX(16));
	}
	
	return CIconButton::Create(_T(""), (WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON), rButton, pParent, nID);
}

BOOL CWinHelpButton::SetIcon(UINT nIconID)
{
	ASSERT(s_hHelpIcon == NULL);

	if (s_hHelpIcon)
		::DestroyIcon(s_hHelpIcon);

	s_hHelpIcon = AfxGetApp()->LoadIcon(nIconID);

	return (s_hHelpIcon != NULL);
}

void CWinHelpButton::PreSubclassWindow()
{
	CIconButton::PreSubclassWindow();

	if (!m_tooltip.GetSafeHwnd())
	{
		CRect rect; 
		GetClientRect(rect);
		
		m_tooltip.Create(this);
		m_tooltip.AddTool(this, _T("Online Help"), rect, 1);
	}
}

BOOL CWinHelpButton::PreTranslateMessage(MSG* pMsg)
{
	m_tooltip.RelayEvent(pMsg);

	return CIconButton::PreTranslateMessage(pMsg);
}

BOOL CWinHelpButton::DoAction()
{
	if (m_bAutoHandleClick)
	{
		AfxGetApp()->WinHelp(m_nHelpID);
		return TRUE;
	}

	// else parent handles
	return FALSE;
}

void CWinHelpButton::CalcExtraSpace(const CRect& rClient, CRect& rExtra) const
{
	// since we have no text, we want the icon to be centred
	rExtra = rClient;
 	rExtra.DeflateRect(((rExtra.Width() - 16) / 2), ((rExtra.Height() - 16) / 2));
}
