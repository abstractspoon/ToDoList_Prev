// autocombobox.cpp : implementation file
//

#include "stdafx.h"
#include "autocombobox.h"
#include "holdredraw.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

void AFXAPI DDX_AutoCBString(CDataExchange* pDX, int nIDC, CString& value)
{
	HWND hWndCtrl = pDX->PrepareCtrl(nIDC);

	if (pDX->m_bSaveAndValidate)
	{
		DDX_CBString(pDX, nIDC, value);
	}
	else
	{
		// try exact first
		int nIndex = (int)::SendMessage(hWndCtrl, CB_FINDSTRINGEXACT, (WPARAM)-1,
										(LPARAM)(LPCTSTR)value);

		// then partial
		if (nIndex == CB_ERR)
			nIndex = ::SendMessage(hWndCtrl, CB_SELECTSTRING, (WPARAM)-1, (LPARAM)(LPCTSTR)value);

		if (nIndex == CB_ERR)
		{
			// just set the edit text (will be ignored if DROPDOWNLIST)
			SetWindowText(hWndCtrl, value);
		}
		else
		{
			// select it
			SendMessage(hWndCtrl, CB_SETCURSEL, nIndex, 0L);
		}
	}
}


/////////////////////////////////////////////////////////////////////////////
// CAutoComboBox

CAutoComboBox::CAutoComboBox()
{
}

CAutoComboBox::~CAutoComboBox()
{
}


BEGIN_MESSAGE_MAP(CAutoComboBox, CComboBox)
	//{{AFX_MSG_MAP(CAutoComboBox)
	ON_CONTROL_REFLECT_EX(CBN_KILLFOCUS, OnKillfocus)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAutoComboBox message handlers

BOOL CAutoComboBox::OnKillfocus() 
{
	CString sText;
	GetWindowText(sText);

	AddUniqueItem(sText);

	return FALSE; // continue routing
}

int CAutoComboBox::AddUniqueItem(const CString& sItem)
{
	int nFind = FindStringExact(-1, sItem, TRUE); // case sensitive

    if (!sItem.IsEmpty())
    {
    	if (nFind != CB_ERR)
            DeleteString(nFind); // remove original

        return CComboBox::AddString(sItem); // re-add at end
	}

	return CB_ERR; // invalid item
}

int CAutoComboBox::FindStringExact(int nIndexStart, const CString& sItem, BOOL bCaseSensitive) const
{
	int nFind = CB_ERR; // default

	if (!sItem.IsEmpty())
	{
		nFind = CComboBox::FindStringExact(-1, sItem);
		
		if (nFind != CB_ERR && bCaseSensitive)
        {
		    // also test for real exactness because FindStringExact is not case sensitive
            CString sFind;
            GetLBText(nFind, sFind);
        
            if (sItem != sFind) // differ in case
                nFind = CB_ERR;
        }
	}

	return nFind;
}

int CAutoComboBox::InsertUniqueItem(int nIndex, const CString& sItem)
{
	int nFind = FindStringExact(-1, sItem, TRUE); // case sensitive

    if (!sItem.IsEmpty())
    {
    	if (nFind != CB_ERR)
            DeleteString(nFind); // remove original

        return CComboBox::InsertString(nFind, sItem); // re-insert
	}

	return CB_ERR; // invalid item
}

void CAutoComboBox::OnSize(UINT nType, int cx, int cy) 
{
	CWnd* pEdit = GetDlgItem(1001);

	// if the edit control does not have the focus then hide the selection
	if (pEdit && pEdit != GetFocus())
	{
		CHoldRedraw hr(*pEdit);
		CComboBox::OnSize(nType, cx, cy);
	
		pEdit->SendMessage(EM_SETSEL, -1, 0);
	}
	else
		CComboBox::OnSize(nType, cx, cy);
}

int CAutoComboBox::AddUniqueItems(const CStringArray& aItems)
{
    int nItem = aItems.GetSize(), nCount = 0;

    while (nItem--)
    {
        if (AddUniqueItem(aItems[nItem]) >= 0)
            nCount++;
    }

    return nCount;
}

int CAutoComboBox::AddUniqueItems(const CAutoComboBox& cbItems)
{
    CStringArray aItems;

    if (cbItems.GetItems(aItems))
        return AddUniqueItems(aItems);

    // else
    return 0;
}

int CAutoComboBox::GetItems(CStringArray& aItems) const
{
    int nItem = GetCount();

    aItems.RemoveAll();
    aItems.SetSize(nItem);

    while (nItem--)
    {
        CString sItem;
		GetLBText(nItem, sItem);

        aItems.SetAt(nItem, sItem); // maintain order
    }

    return aItems.GetSize();
}

int CAutoComboBox::CalcMaxTextWidth(CDC* pDC, int nMin)
{
	CString sText;
	int nMaxWidth = nMin;
	int nItem = GetCount();
	
	while (nItem--)
	{
		GetLBText(nItem, sText);
		
		int nWidth = pDC->GetTextExtent(sText).cx;
		nMaxWidth = max(nMaxWidth, nWidth);
	}

	// check window text too
	GetWindowText(sText);


	int nWidth = pDC->GetTextExtent(sText).cx;
	nMaxWidth = max(nMaxWidth, nWidth);
	
	return nMaxWidth;
}

