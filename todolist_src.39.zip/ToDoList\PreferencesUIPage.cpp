// PreferencesUIPage.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "PreferencesUIPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUIPage property page

IMPLEMENT_DYNCREATE(CPreferencesUIPage, CPropertyPage)

CPreferencesUIPage::CPreferencesUIPage() : 
	CPropertyPage(CPreferencesUIPage::IDD), 
			m_eToolbarImagePath(FES_COMBOSTYLEBTN, "Image Files (*.bmp, *.gif)|*.bmp;*.gif||")
{
	//{{AFX_DATA_INIT(CPreferencesUIPage)
	//}}AFX_DATA_INIT

	// load settings
	m_bShowCtrlsAsColumns = AfxGetApp()->GetProfileInt("Preferences", "ShowCtrlsAsColumns", FALSE);
	m_bShowCommentsAlways = AfxGetApp()->GetProfileInt("Preferences", "ShowCommentsAlways", FALSE);
	m_bAutoReposCtrls = AfxGetApp()->GetProfileInt("Preferences", "AutoReposCtrls", TRUE);
	m_bSpecifyToolbarImage = AfxGetApp()->GetProfileInt("Preferences", "SpecifyToolbarImage", FALSE);
	m_sToolbarImagePath = AfxGetApp()->GetProfileString("Preferences", "ToolbarImagePath");
	m_bSharedCommentsHeight = AfxGetApp()->GetProfileInt("Preferences", "SharedCommentsHeight", TRUE);
	m_bAutoHideTabbar = AfxGetApp()->GetProfileInt("Preferences", "AutoHideTabbar", TRUE);
	m_bStackTabbarItems = AfxGetApp()->GetProfileInt("Preferences", "StackTabbarItems", FALSE);
	m_bRightAlignLabels = AfxGetApp()->GetProfileInt("Preferences", "RightAlignLabels", FALSE);
}

CPreferencesUIPage::~CPreferencesUIPage()
{
}

void CPreferencesUIPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesUIPage)
	DDX_Control(pDX, IDC_TOOLBARIMAGEPATH, m_eToolbarImagePath);
	DDX_Check(pDX, IDC_SHOWCTRLSASCOLUMNS, m_bShowCtrlsAsColumns);
	DDX_Check(pDX, IDC_SHOWCOMMENTSALWAYS, m_bShowCommentsAlways);
	DDX_Check(pDX, IDC_AUTOREPOSCTRLS, m_bAutoReposCtrls);
	DDX_Check(pDX, IDC_SPECIFYTOOLBARIMAGE, m_bSpecifyToolbarImage);
	DDX_Text(pDX, IDC_TOOLBARIMAGEPATH, m_sToolbarImagePath);
	DDX_Check(pDX, IDC_SHAREDCOMMENTSHEIGHT, m_bSharedCommentsHeight);
	DDX_Check(pDX, IDC_AUTOHIDETABBAR, m_bAutoHideTabbar);
	DDX_Check(pDX, IDC_STACKTABBARITEMS, m_bStackTabbarItems);
	DDX_Check(pDX, IDC_RIGHTALIGNLABELS, m_bRightAlignLabels);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPreferencesUIPage, CPropertyPage)
	//{{AFX_MSG_MAP(CPreferencesUIPage)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_SPECIFYTOOLBARIMAGE, OnSpecifytoolbarimage)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesUIPage message handlers

BOOL CPreferencesUIPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	GetDlgItem(IDC_TOOLBARIMAGEPATH)->EnableWindow(m_bSpecifyToolbarImage);
		
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreferencesUIPage::OnOK() 
{
	CPropertyPage::OnOK();
	
	// save settings
	AfxGetApp()->WriteProfileInt("Preferences", "ShowCtrlsAsColumns", m_bShowCtrlsAsColumns);
	AfxGetApp()->WriteProfileInt("Preferences", "ShowCommentsAlways", m_bShowCommentsAlways);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoReposCtrls", m_bAutoReposCtrls);
	AfxGetApp()->WriteProfileInt("Preferences", "SpecifyToolbarImage", m_bSpecifyToolbarImage);
	AfxGetApp()->WriteProfileString("Preferences", "ToolbarImagePath", m_sToolbarImagePath);
	AfxGetApp()->WriteProfileInt("Preferences", "SharedCommentsHeight", m_bSharedCommentsHeight);
	AfxGetApp()->WriteProfileInt("Preferences", "AutoHideTabbar", m_bAutoHideTabbar);
	AfxGetApp()->WriteProfileInt("Preferences", "StackTabbarItems", m_bStackTabbarItems);
	AfxGetApp()->WriteProfileInt("Preferences", "RightAlignLabels", m_bRightAlignLabels);
//	AfxGetApp()->WriteProfileInt("Preferences", "", m_b);
}

void CPreferencesUIPage::OnSpecifytoolbarimage() 
{
	UpdateData();	

	GetDlgItem(IDC_TOOLBARIMAGEPATH)->EnableWindow(m_bSpecifyToolbarImage);
}

