// XmlFile.h: interface for the CXmlFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_XMLFILE_H__54045703_1A98_41AB_B1A1_0B165C350AA0__INCLUDED_)
#define AFX_XMLFILE_H__54045703_1A98_41AB_B1A1_0B165C350AA0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>

// global fns for translating text to/from xml representations eg '&lt;' becomes '<' and vice versa
CString& XML2TXT(CString& xml);
CString& TXT2XML(CString& txt);
CString& TXT2HTML(CString& txt);

const LPCTSTR CDATA = "![CDATA[";

class CXmlItem
{
public:
	CXmlItem(const CXmlItem* pParent = NULL, LPCTSTR szName = NULL, LPCTSTR szValue = NULL);
	CXmlItem(const CXmlItem& xi, const CXmlItem* pParent = NULL);
	virtual ~CXmlItem();

	void Reset();

	const CXmlItem* GetItem(CString sItemName, LPCTSTR szSubItemName = NULL) const;
	CXmlItem* GetItem(CString sItemName, LPCTSTR szSubItemName = NULL);

	const CXmlItem* FindItem(LPCTSTR szItemName, LPCTSTR szItemValue, BOOL bSearchChildren = TRUE) const;
	CXmlItem* FindItem(LPCTSTR szItemName, LPCTSTR szItemValue, BOOL bSearchChildren = TRUE);

	inline LPCTSTR GetName() const { return m_sName; }
	inline LPCTSTR GetValue() const { return m_sValue; }
	inline int GetValueLen() const { return m_sValue.GetLength(); }

	LPCTSTR GetItemValue(CString sItemName, LPCTSTR szSubItemName = NULL) const;
	inline int GetItemCount() const { return m_mapItems.GetCount(); }

	inline int GetValueI() const { return atoi(m_sValue); }
	int GetItemValueI(CString sItemName, LPCTSTR szSubItemName = NULL) const { return atoi(GetItemValue(sItemName, szSubItemName)); }

	inline double GetValueF() const { return (double)atof(m_sValue); }
	double GetItemValueF(CString sItemName, LPCTSTR szSubItemName = NULL) const { return (double)atof(GetItemValue(sItemName, szSubItemName)); }

	CXmlItem* AddItem(CString sName, LPCTSTR sValue = NULL);
	CXmlItem* AddItem(CString sName, int nValue);
	CXmlItem* AddItem(CString sName, const double& fValue);
	CXmlItem* AddItem(const CXmlItem& xi); // item and all attributes are copied

	void SetValue(LPCTSTR sValue);
	void SetValue(int nValue);
	void SetValue(const double& fValue);

	BOOL DeleteItem(const CXmlItem* pXIChild); // must be a direct child
	void DeleteAllItems() { Reset(); }

	inline const CXmlItem* GetParent() const { return m_pParent; }
	inline const CXmlItem* GetSibling() const { return m_pSibling; }
	inline CXmlItem* GetSibling() { return m_pSibling; }

	inline BOOL IsAttribute(int nMaxAttribLen = 8192) const 
	{ 
		return (GetValueLen() <= nMaxAttribLen && !m_mapItems.GetCount() && !IsCDATA()); 
	}

	BOOL IsCDATA() const;

	POSITION GetFirstItemPos() const;
	const CXmlItem* GetNextItem(POSITION& pos) const;
	CXmlItem* GetNextItem(POSITION& pos);

	// matching helpers
	BOOL NameMatches(const CXmlItem* pXITest) const;
	BOOL ValueMatches(const CXmlItem* pXITest, BOOL bIgnoreCase = TRUE) const;
	BOOL ItemValueMatches(const CXmlItem* pXITest, CString sItemName, BOOL bIgnoreCase = TRUE) const;

protected:
	CString m_sName;
	CString m_sValue;

	const CXmlItem* m_pParent;
	CXmlItem* m_pSibling;

	CMap<CString, LPCTSTR, CXmlItem*, CXmlItem*&> m_mapItems; // children

protected:
	BOOL AddSibling(CXmlItem* pXI); // must share the same name and parent
	const CXmlItem* GetItemEx(CString sItemName, LPCTSTR szSubItemName = NULL) const;
	const CXmlItem* FindItemEx(LPCTSTR szItemName, LPCTSTR szItemValue, BOOL bSearchChildren = TRUE) const;
};

// v simple interface for exporting to multiple formats
class IXmlExporter
{
public:
	virtual CString& Export(const CXmlItem* pItem, int nDepth, int nPos, CString& sOutput) const = 0;
};

class IXmlParse
{
public:
	// return TRUE to continue parsing
	virtual BOOL Continue(LPCTSTR szItem, LPCTSTR szValue) const = 0;
};

enum XF_OPEN 
{
	XF_READ,
	XF_WRITE,
	XF_READWRITE,
};

enum // load errors
{
	XFL_NONE,
	XFL_CANCELLED,
	XFL_MISSINGROOT,
	XFL_BADFILE,
};

class CXmlFile : protected CStdioFile  
{
public:
	CXmlFile(LPCTSTR szRootItemName = NULL);
	virtual ~CXmlFile();
	inline void Reset() { m_xiRoot.Reset(); }

	BOOL Load(LPCTSTR szFilePath, LPCTSTR szRootItemName = NULL, IXmlParse* pCallback = NULL);
	BOOL Save(LPCTSTR szFilePath, int nMaxAttribLen = 8192);

	// extended interface
	BOOL Open(LPCTSTR szFilePath, XF_OPEN nOpenFlags);
	virtual BOOL SaveEx(int nMaxAttribLen = 8192);
	virtual BOOL LoadEx(LPCTSTR szRootItemName = NULL, IXmlParse* pCallback = NULL);
	void Close() { CStdioFile::Close(); }
	int GetLastLoadError() { return m_nLoadError; }

	inline const CXmlItem* Root() const { return &m_xiRoot; }
	inline CXmlItem* Root() { return &m_xiRoot; }

	inline const CXmlItem* GetItem(CString sItemName) const { return m_xiRoot.GetItem(sItemName); } 
	inline CXmlItem* GetItem(CString sItemName) { return m_xiRoot.GetItem(sItemName); }

	inline const CXmlItem* FindItem(LPCTSTR szItemName, LPCTSTR szItemValue, BOOL bSearchChildren = TRUE) const
		{ return m_xiRoot.FindItem(szItemName, szItemValue, bSearchChildren); }

	inline CXmlItem* FindItem(LPCTSTR szItemName, LPCTSTR szItemValue, BOOL bSearchChildren = TRUE)
		{ return m_xiRoot.FindItem(szItemName, szItemValue, bSearchChildren); }

	inline CXmlItem* AddItem(CString sName, LPCTSTR szValue = "") { return m_xiRoot.AddItem(sName, szValue); }
	inline CXmlItem* AddItem(CString sName, int nValue) { return m_xiRoot.AddItem(sName, nValue); }
	inline CXmlItem* AddItem(CString sName, const double& fValue) { return m_xiRoot.AddItem(sName, fValue); }

	inline BOOL DeleteItem(const CXmlItem* pXI) { return m_xiRoot.DeleteItem(pXI); }

	inline LPCTSTR GetItemValue(CString sItemName, LPCTSTR szSubItemName = NULL) const { return m_xiRoot.GetItemValue(sItemName, szSubItemName); }
	inline int GetItemValueI(CString sItemName, LPCTSTR szSubItemName = NULL) const { return m_xiRoot.GetItemValueI(sItemName, szSubItemName); }
	inline double GetItemValueF(CString sItemName, LPCTSTR szSubItemName = NULL) const { return m_xiRoot.GetItemValueF(sItemName, szSubItemName); }

	inline CString GetFilePath() { return CStdioFile::GetFilePath(); }
	inline const HANDLE GetFileHandle() { return (HANDLE)CStdioFile::m_hFile; }

	inline LPCTSTR GetHeader() { return m_sHeader; }
	inline void SetHeader(LPCTSTR szHeader) { m_sHeader = szHeader; m_sHeader.MakeLower(); }

	void Trace() const;

protected:
	CXmlItem m_xiRoot;
	CString m_sHeader;
	IXmlParse* m_pCallback;
	int m_nLoadError;
	
	// this is a built-in exporter for saving to disk
	class CExportToXml : protected IXmlExporter
	{
	public:
		CExportToXml(int nMaxAttribLen = 8192) : m_nMaxAttribLen(nMaxAttribLen) { }
		virtual CString& Export(const CXmlItem* pItem, int nDepth, int nPos, CString& sOutput) const;

	protected:
		BOOL m_nMaxAttribLen;

	protected:
		CString ExportAsAttribute(const CXmlItem* pItem) const;
	};

protected:
	BOOL ParseItem(CXmlItem& xi, LPCTSTR& sFile); // returns false if the callback stopped it
	BOOL ParseRootItem(LPCTSTR szRootItemName, LPCTSTR& sFile);
	virtual CString GetNextItem(LPCTSTR& sFile);
	virtual CString GetNextValue(LPCTSTR& sFile, int nItemType);
	void PreProcessItem(CString& sItem, CString& sAttributes, BOOL& bHasEndTag);
	void PreProcessCDATA(CString& sItem, CString& sData);
	void PreProcessComment(CString& sItem, CString& sComment);
	BOOL ProcessAttributes(CXmlItem& xi, CString& sItem); // returns false if the callback stopped it
	inline ContinueParsing(LPCTSTR szItem, LPCTSTR szValue) 
		{ return (!m_pCallback || m_pCallback->Continue(szItem, szValue)); }
	int GetItemType(const CString& sItem);
};

#endif // !defined(AFX_XMLFILE_H__54045703_1A98_41AB_B1A1_0B165C350AA0__INCLUDED_)
