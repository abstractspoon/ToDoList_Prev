// TimeEdit.h: interface for the CTimeEdit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TIMEEDIT_H__2CCFE44D_9578_4E38_B2BF_091C172C85A5__INCLUDED_)
#define AFX_TIMEEDIT_H__2CCFE44D_9578_4E38_B2BF_091C172C85A5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "enedit.h"

const UINT WM_TEN_UNITSCHANGE = ::RegisterWindowMessage("WM_TEN_UNITSCHANGE"); // wParam == <HWND>

enum 
{
	TEU_HOURS	= 'H',
	TEU_DAYS	= 'D',
	TEU_WEEKS	= 'W',
	TEU_MONTHS	= 'M',
	TEU_YEARS	= 'Y',
};

class CTimeEdit : public CEnEdit  
{
public:
	CTimeEdit(int nUnits = TEU_HOURS);
	virtual ~CTimeEdit();

	double GetTime() const;
	double GetTime(int nUnits) const;
	static double GetTime(double dTime, int nFromUnits, int nToUnits);

	void SetTime(double dTime); // 2 decimal places
	void SetTime(double dTime, int nDecPlaces);
	void SetTime(double dTime, int nUnits, int nDecPlaces);

	int GetUnits() const { return m_nUnits; }
	void SetUnits(int nUnits);

	CString FormatTime(int nDecPlaces, BOOL bUnits) const; // number only
	static CString FormatTime(double dTime, int nDecPlaces); // number only
	static CString FormatTime(double dTime, int nUnits, int nDecPlaces);

protected:
	int m_nUnits;

protected:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTimeEdit)
	//}}AFX_VIRTUAL
	virtual void PreSubclassWindow();
	virtual void OnBtnClick(UINT nID);
	virtual void OnSetReadOnly(BOOL bReadOnly);

// Implementation

	// Generated message map functions
protected:
	//{{AFX_MSG(CTimeEdit)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

	static BOOL Compare(int nFromUnits, int nToUnits); // 0=same, -1=nFrom < nTo else 1
};

#endif // !defined(AFX_TIMEEDIT_H__2CCFE44D_9578_4E38_B2BF_091C172C85A5__INCLUDED_)
