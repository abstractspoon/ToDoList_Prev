// GoogleDocsStorage.h: interface for the CGoogleDocsStorageApp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GOOGLEDOCSSTORAGE_H__5F11BF5E_53BB_4128_A800_6DB0DD8B63DA__INCLUDED_)
#define AFX_GOOGLEDOCSSTORAGE_H__5F11BF5E_53BB_4128_A800_6DB0DD8B63DA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

class CGoogleDocsStorageApp : public CWinApp  
{
public:
	CGoogleDocsStorageApp();

};

#endif // !defined(AFX_GOOGLEDOCSSTORAGE_H__5F11BF5E_53BB_4128_A800_6DB0DD8B63DA__INCLUDED_)
