#if !defined(AFX_GANTTCHARTWND_H__1571B442_7ED5_45D8_A040_C359EAE9FDE1__INCLUDED_)
#define AFX_GANTTCHARTWND_H__1571B442_7ED5_45D8_A040_C359EAE9FDE1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GanttChartWnd.h : header file
//

#include "..\Shared\IUIExtension.h"

/////////////////////////////////////////////////////////////////////////////
// CGanttChartWnd window

class CGanttChartWnd : public CStatic, public IUIExtensionWindow
{
// Construction
public:
	CGanttChartWnd();

	BOOL Create(DWORD dwStyle, const RECT &rect, CWnd* pParentWnd, UINT nID);
	void Release();

	// IUIExtensionWindow
	LPCTSTR GetTypeID() const;
	HICON GetIcon() const { return m_hIcon; }
	LPCTSTR GetMenuText() const;

	void SetReadOnly(bool bReadOnly) {}
	HWND GetHwnd() const { return GetSafeHwnd(); }
	void SetUITheme(const UITHEME* pTheme);

	BOOL GetLabelEditRect(LPRECT pEdit) const;

	void LoadPreferences(const IPreferences* pPrefs, LPCTSTR szKey);
	void SavePreferences(IPreferences* pPrefs, LPCTSTR szKey) const;

	void UpdateTasks(const ITaskList* pTasks, DWORD dwFlags, int nEditAttribute);
	bool WantUpdate(int nAttribute) const;

	bool ProcessMessage(MSG* pMsg);

protected:
	HICON m_hIcon;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGanttChartWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGanttChartWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CGanttChartWnd)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GANTTCHARTWND_H__1571B442_7ED5_45D8_A040_C359EAE9FDE1__INCLUDED_)
