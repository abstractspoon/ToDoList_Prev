// GanttChartWnd.cpp : implementation file
//

#include "stdafx.h"
#include "GanttChartExt.h"
#include "GanttChartWnd.h"
#include "resource.h"

#include "..\shared\misc.h"
#include "..\shared\wclassdefines.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGanttChartWnd

CGanttChartWnd::CGanttChartWnd() : m_hIcon(NULL)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_GANTTCHART);
}

CGanttChartWnd::~CGanttChartWnd()
{
}


BEGIN_MESSAGE_MAP(CGanttChartWnd, CWnd)
	//{{AFX_MSG_MAP(CGanttChartWnd)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CGanttChartWnd message handlers

BOOL CGanttChartWnd::Create(DWORD dwStyle, const RECT &rect, CWnd* pParentWnd, UINT nID)
{
	return CStatic::CreateEx(0, WC_STATIC, NULL, dwStyle | SS_SUNKEN | SS_CENTER | SS_CENTERIMAGE, rect, pParentWnd, nID);
}

void CGanttChartWnd::SavePreferences(IPreferences* pPrefs, LPCTSTR szKey) const 
{
	CString sKey(szKey);
	sKey += _T("\\GanttChart");

}

void CGanttChartWnd::LoadPreferences(const IPreferences* pPrefs, LPCTSTR szKey) 
{
	CString sKey(szKey);
	sKey += _T("\\GanttChart");

}

void CGanttChartWnd::SetUITheme(const UITHEME* pTheme)
{
// 	if (CThemed::IsThemeActive())
// 	{
// 	}
}

LPCTSTR CGanttChartWnd::GetMenuText() const
{
	return _T("Calendar");
}

LPCTSTR CGanttChartWnd::GetTypeID() const
{
	static CString sID;

	Misc::GuidToString(GANTT_TYPEID, sID); 

	return sID;
}

bool CGanttChartWnd::ProcessMessage(MSG* pMsg) 
{
	if (!IsWindowEnabled())
		return false;

	// process editing shortcuts
	// TODO

	return false;
}

BOOL CGanttChartWnd::GetLabelEditRect(LPRECT pEdit) const
{
	// else
	return FALSE;
}

bool CGanttChartWnd::WantUpdate(int nAttribute) const
{
// 	switch (nAttribute)
// 	{
// 	case TDCA_TASKNAME:
// 	case TDCA_DONEDATE:
// 	case TDCA_DUEDATE:
// 	case TDCA_STARTDATE:
// 	case TDCA_PERCENT:
// 	case TDCA_TIMEEST:
// 	case TDCA_TIMESPENT:
// 		return true;
// 	}

	// all else 
	return false;
}

void CGanttChartWnd::UpdateTasks(const ITaskList* pTasks, DWORD dwFlags, int nEditAttribute)
{
	// TODO
}

void CGanttChartWnd::Release()
{
	if (GetSafeHwnd())
		DestroyWindow();
	
	delete this;
}

