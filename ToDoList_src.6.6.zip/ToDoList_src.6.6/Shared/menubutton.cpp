// menubutton.cpp : implementation file
//

#include "stdafx.h"
#include "menubutton.h"
#include "graphicsmisc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMenuButton

CMenuButton::CMenuButton(UINT nMenuID, int nSubMenu, MENUBTN_STYLE nStyle) 
: m_nMenuID(nMenuID), m_nSubMenu(nSubMenu), m_nStyle(nStyle)
{
}

CMenuButton::~CMenuButton()
{
}


BEGIN_MESSAGE_MAP(CMenuButton, CCustomButton)
	//{{AFX_MSG_MAP(CMenuButton)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMenuButton message handlers

void CMenuButton::DoExtraPaint(CDC* pDC, const CRect& rExtra)
{
	switch (m_nStyle)
	{
	case MBS_DOWN:
		GraphicsMisc::DrawSymbol(pDC, 0x36, rExtra, DT_CENTER, &GraphicsMisc::Marlett());
		break;

	case MBS_RIGHT:
		GraphicsMisc::DrawSymbol(pDC, 0x34, rExtra, DT_CENTER, &GraphicsMisc::Marlett());
		break;

	default:
		ASSERT(0);
	}
}

BOOL CMenuButton::DoAction()
{
	CMenu menu;

	if (menu.LoadMenu(m_nMenuID))
	{
		CPoint pt;
		CRect rWindow;
		GetWindowRect(rWindow);

		switch (m_nStyle)
		{
		case MBS_DOWN:
			pt.x = rWindow.left;
			pt.y = rWindow.bottom;
			break;

		case MBS_RIGHT:
			pt.x = rWindow.right;
			pt.y = rWindow.top;
			break;

		default:
			ASSERT(0);
			return FALSE;
		}

		CMenu* pPopup = menu.GetSubMenu(m_nSubMenu);
		PrepareState(pPopup);

		return pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON, pt.x, pt.y, GetParent());
	}

	// else
	return FALSE;
}

void CMenuButton::PrepareState(CMenu* pMenu)
{
	// prepare menu items state
	CCmdUI state;
	state.m_pMenu = pMenu;
	state.m_nIndexMax = pMenu->GetMenuItemCount();
	
	for (state.m_nIndex = 0; state.m_nIndex < state.m_nIndexMax; state.m_nIndex++)
	{
		state.m_nID = pMenu->GetMenuItemID(state.m_nIndex);
		
		if (state.m_nID == 0)
			continue; // menu separator or invalid cmd - ignore it
		
		if (state.m_nID == (UINT)-1)
			PrepareState(pMenu->GetSubMenu(state.m_nIndex));
		else
		{
			state.m_pSubMenu = NULL;
			state.DoUpdate(GetParent(), FALSE);  
		}
	}
}