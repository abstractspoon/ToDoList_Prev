// MouseWheelMgr.cpp: implementation of the CMouseWheelMgr class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MouseWheelMgr.h"
#include "winclasses.h"
#include "wclassdefines.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMouseWheelMgr::CMouseWheelMgr()
{

}

CMouseWheelMgr::~CMouseWheelMgr()
{

}

BOOL CMouseWheelMgr::Initialize()
{
	return GetInstance().InitHooks(HM_MOUSE);
}

void CMouseWheelMgr::Release()
{
	GetInstance().ReleaseHooks();
}

BOOL CMouseWheelMgr::OnMouseEx(UINT uMouseMsg, const MOUSEHOOKSTRUCTEX& info)
{
	if (uMouseMsg == WM_MOUSEWHEEL)
	{
		HWND hwndPt = ::WindowFromPoint(info.pt);
		int nNotches = (info.mouseData & 0xffff0000);
		
		if (info.hwnd != hwndPt)  // does the window under the mouse have the focus.
		{
			::PostMessage(hwndPt, WM_MOUSEWHEEL, nNotches, MAKELPARAM(info.pt.x, info.pt.y));
			return TRUE; // eat
		}
		else // special cases not natively supporting mouse wheel
		{
			CString sClass = CWinClasses::GetClass(hwndPt);
			
			if (CWinClasses::IsClass(sClass, WC_DATETIMEPICK) ||
				CWinClasses::IsClass(sClass, WC_MONTHCAL))
			{
				::PostMessage(hwndPt, WM_KEYDOWN, nNotches > 0 ? VK_UP : VK_DOWN, 0L);
			}
		}
	}
	
	// all else
	return FALSE;
}