//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OutlookImpExp.rc
//
#define IDD_IMPORT_DIALOG               2000
#define IDC_TASKLIST                    2000
#define IDI_OUTLOOK                     2001
#define IDC_REMOVEOUTLOOKTASKS          2002
#define IDI_NOTE                        2002
#define IDC_CHOOSEFOLDER                2003
#define IDI_TASK                        2003
#define IDC_CURFOLDER                   2005
#define IDI_CONTACT                     2005
#define IDI_FOLDER                      2006
#define IDC_HIDEUNFLAGGEDEMAIL          2006
#define IDI_JOURNAL                     2007
#define IDC_REFRESH                     2007
#define IDI_MAIL                        2008
#define IDI_APPOINTMENT                 2009
#define IDI_FLAGGEDMAIL                 2010
#define IDS_FOLDERNOITEMS               3006
#define IDS_UNABLETOCONNECT             3007
#define IDS_BUILDINGLIST                3008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2011
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         2008
#define _APS_NEXT_SYMED_VALUE           3107
#endif
#endif
