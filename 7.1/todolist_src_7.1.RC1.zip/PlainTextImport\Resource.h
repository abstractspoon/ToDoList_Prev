//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PlainTextImport.rc
//
#define IDD_OPTIONSDIALOG               1000
#define IDC_CBLABEL                     1000
#define IDC_PROJECTINCLUDED             1001
#define IDC_TABWIDTHS                   1029
#define IDS_IMPORTLABEL                 4002
#define IDS_EXPORTLABEL                 4003
#define IDS_IMPORTTITLE                 4004
#define IDS_EXPORTTITLE                 4005
#define IDS_IMPORTPROJECTLABEL          4006
#define IDS_EXPORTPROJECTLABEL          4007

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1008
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           4103
#endif
#endif
