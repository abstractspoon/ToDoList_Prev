// TreeSelectionHelper.h: interface for the CTreeSelectionHelper class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TREESELECTIONHELPER_H__098294B4_8B41_4369_8522_FE1637BA7EA1__INCLUDED_)
#define AFX_TREESELECTIONHELPER_H__098294B4_8B41_4369_8522_FE1637BA7EA1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>

class CHTIList : public CList<HTREEITEM, HTREEITEM>
{
public:
	CHTIList() {}
	CHTIList(const CHTIList& list) { Copy(list); }

	const CHTIList& CHTIList::operator=(const CHTIList& list)
	{
		Copy(list);
		return *this;
	}

	void Copy(const CHTIList& list)
	{
		RemoveAll();
		POSITION pos = list.GetHeadPosition();

		while (pos)
			AddTail(list.GetNext(pos));
	}
};

class CTreeSelectionHelper  
{
public:
	CTreeSelectionHelper(CTreeCtrl& tree);
	virtual ~CTreeSelectionHelper();

	// 1 = add, 0 = remove, -1 = toggle
	BOOL SetItems(HTREEITEM htiFrom, HTREEITEM htiTo, int nState, BOOL bRedraw = TRUE);
	BOOL SetItem(HTREEITEM hti, int nState, BOOL bRedraw = TRUE);

	inline BOOL AddItem(HTREEITEM hti, BOOL bRedraw = TRUE) { return SetItem(hti, 1, bRedraw); }
	inline BOOL RemoveItem(HTREEITEM hti, BOOL bRedraw = TRUE) { return SetItem(hti, 0, bRedraw); }
	inline BOOL ToggleItem(HTREEITEM hti, BOOL bRedraw = TRUE) { return SetItem(hti, -1, bRedraw); }

	BOOL RemoveAll(BOOL bRedraw = TRUE);
	BOOL AddItems(HTREEITEM htiFrom, HTREEITEM htiTo, BOOL bRedraw = TRUE);
	BOOL ToggleItems(HTREEITEM htiFrom, HTREEITEM htiTo, BOOL bRedraw = TRUE);

	inline HTREEITEM GetFirstItem() const { return GetCount() ? m_lstSelection.GetHead() : NULL; }
	inline HTREEITEM GetLastItem() const { return GetCount() ? m_lstSelection.GetTail() : NULL; }
	inline POSITION GetFirstItemPos() const { return m_lstSelection.GetHeadPosition(); }
	inline HTREEITEM GetNextItem(POSITION& pos) const { return m_lstSelection.GetNext(pos); }
	inline int GetCount() const { return m_lstSelection.GetCount(); }
	inline BOOL HasItem(HTREEITEM hti) const { return (m_lstSelection.Find(hti) != NULL); }

	inline void CopySelection(CHTIList& selection) { selection = m_lstSelection; }

	void InvalidateAll(BOOL bErase = TRUE);
	BOOL AnyItemsHaveChildren() const;

	// removes any items which are children of other items in the list
	void RemoveChildDuplicates();

	// get next/prev selectable items, NULL if none
	HTREEITEM GetNextPageItem(HTREEITEM hti) const;
	HTREEITEM GetPrevPageItem(HTREEITEM hti) const;
	HTREEITEM GetNextItem(HTREEITEM hti, BOOL bAllowChildren = TRUE) const;
	HTREEITEM GetPrevItem(HTREEITEM hti, BOOL bAllowChildren = TRUE) const;

	inline BOOL IsItemExpanded(HTREEITEM hti) const
		{ return (m_tree.GetItemState(hti, TVIS_EXPANDED) & TVIS_EXPANDED); }

	// history
	BOOL NextSelection();
	BOOL HasNextSelection() const;
	BOOL PrevSelection();
	BOOL HasPrevSelection() const;

protected:
	CTreeCtrl& m_tree;
	CHTIList m_lstSelection;
	CArray<CHTIList, CHTIList&> m_aHistory;
	int m_nCurSelection;

protected:
	int FindItem(HTREEITEM htiFind, HTREEITEM htiStart); // return -1 for above, 1 for below, 0 if same
	BOOL IsFullyVisible(HTREEITEM hti) const;

	void InvalidateItem(HTREEITEM hti);
};

#endif // !defined(AFX_TREESELECTIONHELPER_H__098294B4_8B41_4369_8522_FE1637BA7EA1__INCLUDED_)
