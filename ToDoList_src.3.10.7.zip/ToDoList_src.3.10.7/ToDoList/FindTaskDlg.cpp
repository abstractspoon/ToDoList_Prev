// FindTaskDlg.cpp : implementation file
//

#include "stdafx.h"
#include "todolist.h"
#include "FindTaskDlg.h"

#include "..\shared\deferwndmove.h"
#include "..\shared\dlgunits.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

enum { COL_TASK, COL_PATH, COL_TASKLIST };
const int TASKLIST_COLWIDTH = 100;

// static interface
BOOL CFindTaskDlg::Show(CWnd* pParent)
{
	CFindTaskDlg& fd = FindDlg(pParent);

	if (fd.GetSafeHwnd())
	{
		fd.ShowWindow(SW_SHOW);
		fd.SetForegroundWindow(); // give it the focus
		return TRUE;
	}

	return FALSE;
}

BOOL CFindTaskDlg::Hide()
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.GetSafeHwnd())
	{
		fd.ShowWindow(SW_HIDE);
		return TRUE;
	}

	return FALSE;
}

void CFindTaskDlg::AddResult(LPCTSTR szTask, LPCTSTR szPath, LPCTSTR szTaskList, DWORD dwItemData, int nTaskList)
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.GetSafeHwnd())
	{
		int nPos = fd.m_lcResults.GetItemCount();
		
		// add result
		int nIndex = fd.m_lcResults.InsertItem(nPos, szTask);
		fd.m_lcResults.SetItemText(nIndex, COL_PATH, szPath);
		fd.m_lcResults.SetItemText(nIndex, COL_TASKLIST, szTaskList);
		fd.m_lcResults.UpdateWindow();

		// map identifying data
		FTDRESULT result;
		result.dwItemData = dwItemData;
		result.nTaskList = nTaskList;

		fd.m_mapResults[nIndex] = result;
		
		// update 'found' count
		fd.m_sResultsLabel.Format("&Results (%d found):", nPos + 1);
		fd.UpdateData(FALSE);

		// focus first item added
        if (fd.m_lcResults.GetItemCount() == 1)
            fd.m_lcResults.SetItemState(nIndex, LVIS_FOCUSED | LVIS_SELECTED, 
												LVIS_FOCUSED | LVIS_SELECTED);

		// enable 'select all' button
		fd.GetDlgItem(IDC_SELECTALL)->EnableWindow(TRUE);
	}
}

CFindTaskDlg& CFindTaskDlg::FindDlg(CWnd* pParent)
{
	static CFindTaskDlg fd(pParent);

	if (!fd.GetSafeHwnd())
	{
		VERIFY(fd.Create(IDD_FIND_DIALOG, pParent));

		fd.CenterWindow();
	}
	else if (pParent && pParent != fd.GetParent())
		fd.SetParent(pParent);

	return fd;
}

BOOL CFindTaskDlg::GetSearchAllTasklists()
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.GetSafeHwnd())
	{
		fd.UpdateData();
		return fd.m_bAllTasklists;
	}

	return FALSE;
}

BOOL CFindTaskDlg::GetAutoSelectSingles()
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.GetSafeHwnd())
	{
		fd.UpdateData();
		return fd.m_bAutoSelectSingles;
	}

	return FALSE;
}

POSITION CFindTaskDlg::GetFirstResultPos()
{
	return FindDlg().m_mapResults.GetStartPosition();
}

BOOL CFindTaskDlg::GetNextResult(POSITION& pos, FTDRESULT& result)
{
	if (!pos)
		return FALSE;

	int nSel = -1;
	FindDlg().m_mapResults.GetNextAssoc(pos, nSel, result);
	
	return TRUE;
}

int CFindTaskDlg::GetResultCount()
{
	return FindDlg().m_mapResults.GetCount();
}

int CFindTaskDlg::GetResultCount(int nTaskList)
{
	int nCount = 0;

	POSITION pos = GetFirstResultPos();

	while (pos)
	{
		FTDRESULT result;
		GetNextResult(pos, result);

		if (result.nTaskList == nTaskList)
			nCount++;
	}

	return nCount;
}

BOOL CFindTaskDlg::GetIncludeDone()
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.GetSafeHwnd())
	{
		fd.UpdateData();
		return fd.m_bIncludeDone;
	}

	return FALSE;
}

CString CFindTaskDlg::GetText()
{
	CFindTaskDlg& fd = FindDlg();

	switch (fd.m_nFindOption)
	{
	case FW_TITLECOMMENTS:
		return fd.m_pageTitleComments.GetText();
		
	case FW_ALLOCTO:
		return fd.m_pageAllocTo.GetText();
		
	case FW_ALLOCBY:
		return fd.m_pageAllocBy.GetText();
		
	case FW_STATUS:
		return fd.m_pageStatus.GetText();
		
	case FW_CATEGORY:
		return fd.m_pageCategory.GetText();
	}

	ASSERT(0);
	return "";
}

BOOL CFindTaskDlg::GetMatchCase()
{
	CFindTaskDlg& fd = FindDlg();

	switch (fd.m_nFindOption)
	{
	case FW_TITLECOMMENTS:
		return fd.m_pageTitleComments.GetMatchCase();
		
	case FW_ALLOCTO:
		return fd.m_pageAllocTo.GetMatchCase();
		
	case FW_ALLOCBY:
		return fd.m_pageAllocBy.GetMatchCase();
		
	case FW_STATUS:
		return fd.m_pageStatus.GetMatchCase();
		
	case FW_CATEGORY:
		return fd.m_pageCategory.GetMatchCase();
	}

	ASSERT(0);
	return FALSE;
}

BOOL CFindTaskDlg::GetMatchWholeWord()
{
	CFindTaskDlg& fd = FindDlg();

	switch (fd.m_nFindOption)
	{
	case FW_TITLECOMMENTS:
		return fd.m_pageTitleComments.GetMatchWholeWord();
		
	case FW_ALLOCTO:
		return fd.m_pageAllocTo.GetMatchWholeWord();
		
	case FW_ALLOCBY:
		return fd.m_pageAllocBy.GetMatchWholeWord();
		
	case FW_STATUS:
		return fd.m_pageStatus.GetMatchWholeWord();
		
	case FW_CATEGORY:
		return fd.m_pageCategory.GetMatchWholeWord();
	}

	ASSERT(0);
	return FALSE;
}

FIND_WHAT CFindTaskDlg::GetFindWhat()
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.GetSafeHwnd())
	{
		fd.UpdateData();
		return fd.m_nFindOption;
	}

	return FW_NOTHING;
}

BOOL CFindTaskDlg::GetRange(COleDateTime& dateFrom, COleDateTime& dateTo)
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.m_nFindOption == FW_STARTDATE)
	{
		fd.m_pageStartDate.GetDateRange(dateFrom, dateTo);
		return TRUE;
	}
	else if (fd.m_nFindOption == FW_DUEDATE)
	{
		fd.m_pageDueDate.GetDateRange(dateFrom, dateTo);
		return TRUE;
	}
	else if (fd.m_nFindOption == FW_DONEDATE)
	{
		fd.m_pageDoneDate.GetDateRange(dateFrom, dateTo);
		return TRUE;
	}

	ASSERT(0);
	return FALSE;
}

BOOL CFindTaskDlg::GetRange(int& nFrom, int& nTo)
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.m_nFindOption == FW_PRIORITY)
	{
		fd.m_pagePriority.GetNumberRange(nFrom, nTo);
		return TRUE;
	}
	else if (fd.m_nFindOption == FW_PERCENTDONE)
	{
		fd.m_pagePercent.GetNumberRange(nFrom, nTo);
		return TRUE;
	}
	else if (fd.m_nFindOption == FW_TASKID)
	{
		fd.m_pageTaskID.GetNumberRange(nFrom, nTo);
		return TRUE;
	}

	ASSERT(0);
	return FALSE;
}

BOOL CFindTaskDlg::GetRange(double& dFrom, double& dTo)
{
	CFindTaskDlg& fd = FindDlg();

	if (fd.m_nFindOption == FW_TIMEEST)
	{
		fd.m_pageTimeEst.GetNumberRange(dFrom, dTo);
		return TRUE;
	}
	else if (fd.m_nFindOption == FW_TIMESPENT)
	{
		fd.m_pageTimeSpent.GetNumberRange(dFrom, dTo);
		return TRUE;
	}

	ASSERT(0);
	return FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// CFindTaskDlg dialog

CFindTaskDlg::CFindTaskDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFindTaskDlg::IDD, pParent), m_sResultsLabel("&Results"), 
	m_pageTimeEst(FALSE, FALSE), m_pageTimeSpent(FALSE, FALSE), m_pageTaskID(TRUE, FALSE)
{
	//{{AFX_DATA_INIT(CFindTaskDlg)
	m_bAutoSelectSingles = FALSE;
	//}}AFX_DATA_INIT

	m_bAllTasklists = AfxGetApp()->GetProfileInt("FindTasks", "SearchAllTaskLists", FALSE);
	m_bIncludeDone = AfxGetApp()->GetProfileInt("FindTasks", "IncludeDoneTasks", FALSE);
	m_nFindOption = (FIND_WHAT)max(FW_TITLECOMMENTS, (int)AfxGetApp()->GetProfileInt("FindTasks", "LastFindOption", FW_TITLECOMMENTS));
	m_bAutoSelectSingles = AfxGetApp()->GetProfileInt("FindTasks", "AutoSelectSingles", FALSE);

	m_host.AddPage(&m_pageTitleComments, "Titles and/or Comments", FW_TITLECOMMENTS);
	m_host.AddPage(&m_pagePriority, "Priorities", FW_PRIORITY);
	m_host.AddPage(&m_pagePercent, "Percentage Completions", FW_PERCENTDONE);
	m_host.AddPage(&m_pageTimeEst, "Time Estimates", FW_TIMEEST);
	m_host.AddPage(&m_pageTimeSpent, "Time Spent", FW_TIMESPENT);
	m_host.AddPage(&m_pageStartDate, "Start Dates", FW_STARTDATE);
	m_host.AddPage(&m_pageDueDate, "Due Dates", FW_DUEDATE);
	m_host.AddPage(&m_pageDoneDate, "Completion Dates", FW_DONEDATE);
	m_host.AddPage(&m_pageAllocTo, "Persons Allocated To", FW_ALLOCTO);
	m_host.AddPage(&m_pageAllocBy, "Persons Allocated By", FW_ALLOCBY);
	m_host.AddPage(&m_pageStatus, "Statuses", FW_STATUS);
	m_host.AddPage(&m_pageCategory, "Categories", FW_CATEGORY);
	m_host.AddPage(&m_pageTaskID, "Task IDs", FW_TASKID);
}

void CFindTaskDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFindTaskDlg)
	DDX_Control(pDX, IDC_FINDOPTION, m_cbFindOptions);
	DDX_Control(pDX, IDC_RESULTS, m_lcResults);
	DDX_CBIndex(pDX, IDC_TASKLISTOPTIONS, m_bAllTasklists);
	DDX_Text(pDX, IDC_RESULTSLABEL, m_sResultsLabel);
	DDX_Check(pDX, IDC_INCLUDEDONE, m_bIncludeDone);
	DDX_CBIndex(pDX, IDC_FINDOPTION, m_nSelFindIndex);
	DDX_Check(pDX, IDC_AUTOSELECTSINGLES, m_bAutoSelectSingles);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFindTaskDlg, CDialog)
	//{{AFX_MSG_MAP(CFindTaskDlg)
	ON_BN_CLICKED(IDC_FIND, OnFind)
	ON_WM_CLOSE()
	ON_CBN_SELCHANGE(IDC_TASKLISTOPTIONS, OnSelchangeTasklistoptions)
	ON_WM_SIZE()
	ON_NOTIFY(LVN_ITEMACTIVATE, IDC_RESULTS, OnItemActivated)
	ON_WM_DESTROY()
	ON_CBN_SELCHANGE(IDC_FINDOPTION, OnSelchangeFindoption)
	ON_WM_GETMINMAXINFO()
	ON_BN_CLICKED(IDC_SELECTALL, OnSelectall)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFindTaskDlg message handlers

void CFindTaskDlg::OnFind() 
{
	// add typed text to combobox
	UpdateData();

	// notify parent
	GetParent()->PostMessage(WM_FTD_FIND);

	// clear results and set focus to results
	m_mapResults.RemoveAll();
	m_lcResults.DeleteAllItems();
	m_lcResults.SetFocus();
	m_sResultsLabel = "&Results (0 found)";
	UpdateData(FALSE);

	GetDlgItem(IDC_SELECTALL)->EnableWindow(FALSE);
}

void CFindTaskDlg::OnClose() 
{
	CDialog::OnClose();

	// hide
	ShowWindow(SW_HIDE);
}

BOOL CFindTaskDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	CDialogHelper::SetFont(this, (HFONT)GetStockObject(DEFAULT_GUI_FONT), FALSE);

	m_host.Create(IDC_PAGEHOST, this);

	// build combobox of pages
	int nPage = m_host.GetPageCount();

	while (nPage--)
	{
		int nIndex = m_cbFindOptions.InsertString(0, m_host.GetPageTitle(nPage));
		m_cbFindOptions.SetItemDataPtr(nIndex, m_host.GetPage(nPage));

		// init active page
		if (m_nFindOption == (int)m_host.GetPageItemData(nPage))
		{
			m_nSelFindIndex = nIndex;
			m_cbFindOptions.SetCurSel(nIndex);
			m_host.SetActivePage(nPage);
		}
	}

	// gripper
	// position resize icon as close to bottom left as pos
	GetDlgItem(IDC_GRIPPER)->ModifyStyle(0, SBS_SIZEGRIP | SBS_SIZEBOXTOPLEFTALIGN | WS_CLIPSIBLINGS);
	CDeferWndMove(1).OffsetCtrl(this, IDC_GRIPPER, 1, 2);

	// setup up result list
	m_lcResults.InsertColumn(COL_TASK, "Task", LVCFMT_LEFT, 200);
	m_lcResults.InsertColumn(COL_PATH, "Path", LVCFMT_LEFT, 100);
	m_lcResults.InsertColumn(COL_TASKLIST, "Tasklist", LVCFMT_LEFT, 100);

	DWORD dwExStyle = m_lcResults.GetExtendedStyle() | 
						LVS_EX_ONECLICKACTIVATE | LVS_EX_TWOCLICKACTIVATE | LVS_EX_UNDERLINEHOT;
	m_lcResults.SetExtendedStyle(dwExStyle);

	// restore column widths
	m_lcResults.SetColumnWidth(COL_PATH, AfxGetApp()->GetProfileInt("FindTasks", "PathColWidth", 100));
	m_lcResults.SetColumnWidth(COL_TASKLIST, AfxGetApp()->GetProfileInt("FindTasks", "TaskListColWidth", 100));

	// restore dialog size
	DWORD dwSize = AfxGetApp()->GetProfileInt("FindTasks", "Size", 0);

	if (dwSize)
		MoveWindow(0, 0, LOWORD(dwSize), HIWORD(dwSize));

	GetDlgItem(IDC_SELECTALL)->EnableWindow(FALSE);

	ResizeDlg();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CFindTaskDlg::OnSelchangeTasklistoptions() 
{
	static int nColWidth = TASKLIST_COLWIDTH; // first time it will be shown

	// hide the tasklist column depending on the result
	UpdateData();

	if (m_bAllTasklists) // currently hidden
		m_lcResults.SetColumnWidth(COL_TASKLIST, nColWidth);
	else
	{
		nColWidth = m_lcResults.GetColumnWidth(COL_TASKLIST);
		m_lcResults.SetColumnWidth(COL_TASKLIST, 0);
	}
}

void CFindTaskDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);

	ResizeDlg(cx, cy);
}

void CFindTaskDlg::ResizeDlg(int cx, int cy)
{
	if (m_lcResults.GetSafeHwnd())
	{
		if (!cx && !cy)
		{
			CRect rClient;
			GetClientRect(rClient);

			cx = rClient.right;
			cy = rClient.bottom;

			// check again 
			if (!cx && !cy)
				return;
		}

		// we compare the new size with the lower right hand corner
		// of the gripper list
		int nBorder = 0;//CDlgUnits(*this).ToPixelsX(7);

		CRect rect;
		GetDlgItem(IDC_GRIPPER)->GetWindowRect(rect);
		ScreenToClient(rect);

		int nXOffset = cx - nBorder - rect.right;
		int nYOffset = cy - nBorder - rect.bottom;

		{
			CDeferWndMove dwm(5);
			
			dwm.ResizeCtrl(this, IDC_DIVIDER, nXOffset);
			dwm.ResizeCtrl(this, IDC_RESULTS, nXOffset, nYOffset);
			dwm.OffsetCtrl(this, IDC_GRIPPER, nXOffset, nYOffset);
			dwm.OffsetCtrl(this, IDC_SELECTALL, nXOffset);
			dwm.OffsetCtrl(this, IDC_AUTOSELECTSINGLES, 0, nYOffset);
		}

		// resize the column headers to fit the available space
		// provided it does not get less than 100
		int nFixed = m_lcResults.GetColumnWidth(COL_PATH) + m_lcResults.GetColumnWidth(COL_TASKLIST);
		
		if (!(m_lcResults.GetStyle() & WS_VSCROLL))
			nFixed += GetSystemMetrics(SM_CXVSCROLL);

		m_lcResults.GetClientRect(rect);
		m_lcResults.SetColumnWidth(COL_TASK, max(100, rect.Width() - nFixed));
	}	
}

void CFindTaskDlg::OnItemActivated(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	ASSERT (pNMListView->iItem >= 0);

	FTDRESULT result;

	if (m_mapResults.Lookup(pNMListView->iItem, result))
		GetParent()->SendMessage(WM_FTD_SELECTRESULT, pNMListView->iItem, (LPARAM)&result);
	
	*pResult = 0;
}

void CFindTaskDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	SaveSettings();
}

void CFindTaskDlg::SaveSettings()
{
	UpdateData();

	AfxGetApp()->WriteProfileInt("FindTasks", "SearchAllTaskLists", m_bAllTasklists);
	AfxGetApp()->WriteProfileInt("FindTasks", "IncludeDoneTasks", m_bIncludeDone);
	AfxGetApp()->WriteProfileInt("FindTasks", "LastFindOption", m_nFindOption);
	AfxGetApp()->WriteProfileInt("FindTasks", "AutoSelectSingles", m_bAutoSelectSingles);

	// save column widths
	AfxGetApp()->WriteProfileInt("FindTasks", "PathColWidth", m_lcResults.GetColumnWidth(COL_PATH));
	AfxGetApp()->WriteProfileInt("FindTasks", "TaskListColWidth", m_lcResults.GetColumnWidth(COL_TASKLIST));

	// save dialog size
	CRect rDialog;
	GetWindowRect(rDialog);
	AfxGetApp()->WriteProfileInt("FindTasks", "Size", MAKELONG(rDialog.Width(), rDialog.Height()));
}


void CFindTaskDlg::OnSelchangeFindoption() 
{
	UpdateData();

	m_nFindOption = (FIND_WHAT)m_host.GetPageItemData(m_nSelFindIndex);

	CPropertyPage* pPage = (CPropertyPage*)m_cbFindOptions.GetItemDataPtr(m_nSelFindIndex);
	ASSERT (pPage);

	m_host.SetActivePage(pPage, FALSE);	
}

void CFindTaskDlg::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	CDialog::OnGetMinMaxInfo(lpMMI);

	CDlgUnits dlu(*this);

	lpMMI->ptMinTrackSize.x = dlu.ToPixelsX(288);
	lpMMI->ptMinTrackSize.y = dlu.ToPixelsY(230);
}

BOOL CFindTaskDlg::PreTranslateMessage(MSG* pMsg) 
{
	// handle enter key if results list has the focus
	if (pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN && pMsg->hwnd == m_lcResults)
	{
		int nSel = m_lcResults.GetNextItem(-1, LVIS_FOCUSED | LVIS_SELECTED);

		if (nSel != -1)
		{
			FTDRESULT result;
			
			if (m_mapResults.Lookup(nSel, result))
				GetParent()->SendMessage(WM_FTD_SELECTRESULT, nSel, (LPARAM)&result);
			
			return TRUE;
		}
	}
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CFindTaskDlg::OnSelectall() 
{
	if (m_mapResults.GetCount())
		GetParent()->SendMessage(WM_FTD_SELECTALL);
}
