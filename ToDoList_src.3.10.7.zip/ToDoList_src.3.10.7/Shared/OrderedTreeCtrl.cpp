// ToDoCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "orderedtreeCtrl.h"

#include "..\shared\holdredraw.h"
#include "..\shared\themed.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COrderedTreeCtrl

const UINT MINGUTTER = 16;

#define WM_POSTSUBCLASS (WM_APP+1)

static CMap<int, int&, UINT, UINT&> g_mapWidths;

COrderedTreeCtrl::COrderedTreeCtrl() : 
	m_bShowingPosColumn(TRUE), m_bShowGridlines(TRUE), m_crGridlines(OTC_GRIDCOLOR)
{
	AddGutterColumn(OTC_POSCOLUMNID, "Pos"); // for the pos string

	EnableGutterColumnHeaderClicking(OTC_POSCOLUMNID, FALSE);
}

COrderedTreeCtrl::~COrderedTreeCtrl()
{
}

BEGIN_MESSAGE_MAP(COrderedTreeCtrl, CTreeCtrl)
	//{{AFX_MSG_MAP(COrderedTreeCtrl)
	ON_WM_SETTINGCHANGE()
	//}}AFX_MSG_MAP
	ON_WM_STYLECHANGED()
	ON_NOTIFY_REFLECT_EX(TVN_ITEMEXPANDED, OnItemexpanded)
	ON_NOTIFY_REFLECT_EX(NM_CUSTOMDRAW, OnCustomDraw)
	ON_NOTIFY_REFLECT_EX(NM_CLICK, OnClick)
	ON_NOTIFY_REFLECT(TVN_BEGINDRAG, OnBeginDrag)
	ON_MESSAGE(WM_POSTSUBCLASS, OnPostSubclass)
	ON_REGISTERED_MESSAGE(WM_NCG_GETFIRSTVISIBLETOPLEVELITEM, OnGutterGetFirstVisibleTopLevelItem)
	ON_REGISTERED_MESSAGE(WM_NCG_GETNEXTITEM, OnGutterGetNextItem)
	ON_REGISTERED_MESSAGE(WM_NCG_DRAWITEM, OnGutterDrawItem)
	ON_REGISTERED_MESSAGE(WM_NCG_RECALCCOLWIDTH, OnGutterRecalcColWidth)
	ON_REGISTERED_MESSAGE(WM_NCG_POSTNCDRAW, OnGutterPostNcDraw)
	ON_REGISTERED_MESSAGE(WM_NCG_GETITEMRECT, OnGutterGetItemRect)
	ON_REGISTERED_MESSAGE(WM_NCG_GETFIRSTCHILDITEM, OnGutterGetFirstChildItem)
	ON_REGISTERED_MESSAGE(WM_NCG_POSTDRAWITEM, OnGutterPostDrawItem)
	ON_REGISTERED_MESSAGE(WM_NCG_HITTEST, OnGutterHitTest)
	ON_REGISTERED_MESSAGE(WM_NCG_NOTIFYITEMCLICK, OnGutterNotifyItemClick)
	ON_REGISTERED_MESSAGE(WM_NCG_ISITEMSELECTED, OnGutterIsItemSelected)
	ON_REGISTERED_MESSAGE(WM_NCG_GETSELECTEDCOUNT, OnGutterGetSelectedCount)
	ON_REGISTERED_MESSAGE(WM_NCG_GETPARENTITEM, OnGutterGetParentID)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COrderedTreeCtrl message handlers

void COrderedTreeCtrl::PreSubclassWindow() 
{
	m_gutter.AddRecalcMessage(TVM_INSERTITEM);
	m_gutter.AddRecalcMessage(TVM_INSERTITEM);
	m_gutter.AddRecalcMessage(TVM_DELETEITEM);
	m_gutter.AddRecalcMessage(TVM_EXPAND);

	m_gutter.AddRedrawMessage(WM_KEYUP); // only way to catch keyboard navigation (at present)
	m_gutter.AddRedrawMessage(TVM_SELECTITEM);
	m_gutter.AddRedrawMessage(TVM_SORTCHILDREN);
	m_gutter.AddRedrawMessage(TVM_SORTCHILDRENCB);
	m_gutter.AddRedrawMessage(WM_COMMAND, EN_KILLFOCUS);

	CTreeCtrl::PreSubclassWindow();

	// note: its too early to initialize the gutter here because 
	// MFC hasn't done its bit yet, so we post a message instead
	PostMessage(WM_POSTSUBCLASS);
}

BOOL COrderedTreeCtrl::IsItemExpanded(HTREEITEM hItem) const
{
	return GetItemState(hItem, TVIS_EXPANDED) & TVIS_EXPANDED;
}

void COrderedTreeCtrl::ShowGutterPosColumn(BOOL bShow)
{
	if (m_bShowingPosColumn != bShow)
	{
		m_bShowingPosColumn = bShow;
		m_gutter.RecalcGutter();
	}
}

void COrderedTreeCtrl::ShowGridlines(BOOL bShow)
{
	if (m_bShowGridlines != bShow)
	{
		m_bShowGridlines = bShow;

		if (GetSafeHwnd())
		{
			m_gutter.Redraw();
			Invalidate();
		}
	}
}

void COrderedTreeCtrl::SetGridlineColor(COLORREF color)
{
	if (m_crGridlines != color)
	{
		m_crGridlines = color;

		if (GetSafeHwnd())
		{
			m_gutter.Redraw();
			Invalidate();
		}
	}
}

int COrderedTreeCtrl::AddGutterColumn(UINT nColID, LPCTSTR szTitle, UINT nWidth, UINT nTextAlign)
{
	return m_gutter.AddColumn(nColID, szTitle, nWidth, nTextAlign);
}

void COrderedTreeCtrl::PressGutterColumnHeader(UINT nColID, BOOL bPress)
{
	m_gutter.PressColumnHeader(nColID, bPress);
}

void COrderedTreeCtrl::SetGutterColumnHeaderTitle(UINT nColID, LPCTSTR szTitle, LPCTSTR szFont, BOOL bSymbolFont)
{
	m_gutter.SetColumnHeaderTitle(nColID, szTitle, szFont, bSymbolFont);
}

void COrderedTreeCtrl::SetGutterColumnSort(UINT nColID, NCGSORT nSortDir)
{
	m_gutter.SetColumnSort(nColID, nSortDir);
}

void COrderedTreeCtrl::EnableGutterColumnHeaderClicking(UINT nColID, BOOL bEnable)
{
	m_gutter.EnableColumnHeaderClicking(nColID, bEnable);
}

LRESULT COrderedTreeCtrl::OnGutterGetFirstVisibleTopLevelItem(WPARAM wParam, LPARAM lParam)
{
	return (LRESULT)GetFirstVisibleTopLevelItem(*((LPINT)lParam));
}

LRESULT COrderedTreeCtrl::OnGutterGetNextItem(WPARAM wParam, LPARAM lParam)
{
	return (LRESULT)GetNextItem((HTREEITEM)lParam, TVGN_NEXT);
}

LRESULT COrderedTreeCtrl::OnGutterGetFirstChildItem(WPARAM wParam, LPARAM lParam)
{
	HTREEITEM hti = (HTREEITEM)lParam;

	if (ItemHasChildren(hti) && (GetItemState(hti, TVIS_EXPANDED) & TVIS_EXPANDED))
		return (LRESULT)GetChildItem(hti);

	return 0;
}

LRESULT COrderedTreeCtrl::OnGutterDrawItem(WPARAM wParam, LPARAM lParam)
{
	NCGDRAWITEM* pNCGDI = (NCGDRAWITEM*)lParam;

	if (pNCGDI->nColID == OTC_POSCOLUMNID)
	{
		NcDrawItem(pNCGDI->pDC, pNCGDI->dwItem, pNCGDI->dwParentItem, 
					pNCGDI->nColID, CRect(pNCGDI->rItem), pNCGDI->nLevel, 
					pNCGDI->nItemPos, pNCGDI->bSelected, pNCGDI->rWindow);

		return TRUE; // we handled it
	}

	// else
	return FALSE;
}

LRESULT COrderedTreeCtrl::OnGutterPostDrawItem(WPARAM wParam, LPARAM lParam)
{
	NCGDRAWITEM* pNCGDI = (NCGDRAWITEM*)lParam;

	PostNcDrawItem(pNCGDI->pDC, pNCGDI->dwItem, pNCGDI->rItem, pNCGDI->nLevel);

	return FALSE; // to let our parent handle it too
}

LRESULT COrderedTreeCtrl::OnGutterPostNcDraw(WPARAM wParam, LPARAM lParam)
{
	NCGDRAWITEM* pNCGDI = (NCGDRAWITEM*)lParam;

	PostNcDraw(pNCGDI->pDC, pNCGDI->rWindow);

	return FALSE; // to let our parent handle it too
}

LRESULT COrderedTreeCtrl::OnGutterRecalcColWidth(WPARAM wParam, LPARAM lParam)
{
	NCGRECALCCOLUMN* pNCRC = (NCGRECALCCOLUMN*)lParam;

	return RecalcColumnWidth(pNCRC->pDC, pNCRC->nColID, pNCRC->nWidth);
}

LRESULT COrderedTreeCtrl::OnGutterGetItemRect(WPARAM wParam, LPARAM lParam)
{
	NCGITEMRECT* pNCGGI = (NCGITEMRECT*)lParam;

	return GetItemRect((HTREEITEM)pNCGGI->dwItem, &pNCGGI->rItem, TRUE);
}

LRESULT COrderedTreeCtrl::OnGutterGetParentID(WPARAM wParam, LPARAM lParam)
{
	return (DWORD)GetParentItem((HTREEITEM)lParam);
}

LRESULT COrderedTreeCtrl::OnGutterIsItemSelected(WPARAM wParam, LPARAM lParam)
{
	NCGITEMSELECTION* pNCGIS = (NCGITEMSELECTION*)lParam;

	HTREEITEM hti = (HTREEITEM)pNCGIS->dwItem;
	pNCGIS->bSelected = (GetItemState(hti, TVIF_STATE) & TVIS_SELECTED);

	return TRUE;
}

LRESULT COrderedTreeCtrl::OnGutterGetSelectedCount(WPARAM wParam, LPARAM lParam)
{
	int* pCount = (int*)lParam;
	*pCount = GetSelectedItem() ? 1 : 0;

	return TRUE;
}

LRESULT COrderedTreeCtrl::OnGutterHitTest(WPARAM wParam, LPARAM lParam)
{
	CPoint point(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));

	UINT nFlags = 0;
	HTREEITEM hti = HitTest(point, &nFlags);

	return (LRESULT)hti;
}

void COrderedTreeCtrl::PostNcDraw(CDC* pDC, const CRect& rWindow)
{
}

void COrderedTreeCtrl::NcDrawItem(CDC* pDC, DWORD dwItem, DWORD dwParentItem, UINT nColID, CRect& rItem, 
								  int nLevel, int nPos, BOOL bSelected, const CRect& rWindow)
{
	HTREEITEM hti = (HTREEITEM)dwItem;

	if (nColID == OTC_POSCOLUMNID) // this is all we deal with
	{
		// extract the parent pos
		CString sPos, sParentPos; 
		static CMap<DWORD, DWORD, CString, LPCTSTR> mapParentPos;

		if (dwParentItem)
			VERIFY(mapParentPos.Lookup(dwParentItem, sParentPos));

		BOOL bHasChildren = ItemHasChildren(hti);

		if (nPos == -1) // it means we have to figure it out for ourselves
			nPos = GetItemPos(hti, (HTREEITEM)dwParentItem);

		if (nLevel == -1) // likewise
			nLevel = GetItemLevel(hti);

		// default

		if (sParentPos.IsEmpty())
			sPos.Format("%d", nPos);
		else
			sPos.Format("%s.%d", sParentPos, nPos);

		// add to map for our children
		if (bHasChildren)
			mapParentPos[dwItem] = sPos;
		
		// modify for actual output
		if (bHasChildren && !IsItemExpanded(hti))
			sPos += "...";
		
		else if (nLevel == 0)
			sPos += ".";

		if (CRect().IntersectRect(rItem, rWindow)) // something to see
		{
			int nSaveDC = pDC->SaveDC();
			
			// fill background of selected item
			BOOL bFocused = HasFocus(/*!(GetStyle() & TVS_FULLROWSELECT)*/);
			BOOL bDropHilited = (GetItemState(hti, TVIS_DROPHILITED) & TVIS_DROPHILITED);
			
			if (bDropHilited)
				pDC->FillSolidRect(rItem, GetSysColor(COLOR_3DFACE));

			else if (bSelected)
			{
				if (bFocused)
					pDC->FillSolidRect(rItem, GetSysColor(COLOR_HIGHLIGHT));
				else
					pDC->FillSolidRect(rItem, GetSysColor(COLOR_3DFACE));
			}
			
			// draw pos
			COLORREF crTextColor = GetSysColor((bSelected && bFocused) ? COLOR_HIGHLIGHTTEXT : COLOR_WINDOWTEXT);
			
			pDC->SetTextColor(crTextColor);
			pDC->SetBkMode(TRANSPARENT);

			rItem.left += NCG_COLPADDING;
			pDC->DrawText(sPos, rItem, DT_SINGLELINE | DT_VCENTER | DT_LEFT);
			
			pDC->RestoreDC(nSaveDC);
		}
		
		// vertical divider
		if (!bSelected && m_bShowGridlines)
			pDC->FillSolidRect(rItem.right - 1, rItem.top, 1, rItem.Height(), m_crGridlines);
	}
}

int COrderedTreeCtrl::GetItemPos(HTREEITEM hti, HTREEITEM htiParent)
{
	ASSERT (GetParentItem(hti) == htiParent);

	int nPos = 1;
	HTREEITEM htiChild = GetChildItem(htiParent);

	while (htiChild && htiChild != hti)
	{
		nPos++;
		htiChild = GetNextItem(htiChild, TVGN_NEXT);
	}

	return nPos;
}

int COrderedTreeCtrl::GetItemLevel(HTREEITEM hti)
{
	int nLevel = 0;

	while (hti = GetParentItem(hti))
		nLevel++;

	return nLevel;
}

BOOL COrderedTreeCtrl::HasFocus(BOOL bIncEditing)
{
	CWnd* pFocus = GetFocus();
	
	return (pFocus && (pFocus == this || (bIncEditing && pFocus == GetEditControl())));
}

void COrderedTreeCtrl::PostNcDrawItem(CDC* pDC, DWORD dwItem, const CRect& rItem, int nLevel)
{
	if (nLevel == 0 && m_bShowGridlines)
		pDC->FillSolidRect(rItem.left, rItem.bottom - 1, rItem.Width(), 1, m_crGridlines);
}

BOOL COrderedTreeCtrl::OnItemexpanded(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

	m_gutter.RecalcGutter();
	
	// invalidate client area if expanding
	if (pNMTreeView->itemNew.state & TVIS_EXPANDED)
	{
		InvalidateItem(pNMTreeView->itemNew.hItem);
		UpdateWindow();
	}

	*pResult = 0;
	return FALSE;
}

void COrderedTreeCtrl::InvalidateItem(HTREEITEM hti, BOOL bChildren)
{
	CRect rItem;

	if (GetItemRect(hti, rItem, FALSE))
		InvalidateRect(rItem);

	if (bChildren)
	{
		HTREEITEM htiChild = GetChildItem(hti);

		while (htiChild)
		{
			InvalidateItem(htiChild, TRUE);
			htiChild = GetNextItem(htiChild, TVGN_NEXT);
		}
	}
}

BOOL COrderedTreeCtrl::OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMCUSTOMDRAW* pNMCD = (NMCUSTOMDRAW*)pNMHDR;

	if (pNMCD->dwDrawStage == CDDS_ITEMPREPAINT)
		*pResult |= CDRF_NOTIFYPOSTPAINT;
		
	else if (pNMCD->dwDrawStage == CDDS_ITEMPOSTPAINT)
	{
		CDC* pDC = CDC::FromHandle(pNMCD->hdc);
		NMTVCUSTOMDRAW* pTVCD = (NMTVCUSTOMDRAW*)pNMCD;

		HTREEITEM hti = (HTREEITEM)pTVCD->nmcd.dwItemSpec;

		// if the next visible item is a top level item then draw a horz line below us
		HTREEITEM htiNext = GetNextVisibleItem(hti);

		if (!GetParentItem(htiNext))
		{
			// but if the bottom of the text coincides with the bottom of the 
			// item and we have the then take care not to draw over the focus rect
			// but only if we do _not have TVS_FULLROWSELECT style
			if ((pNMCD->uItemState & CDIS_FOCUS) && !(GetStyle() & TVS_FULLROWSELECT))
			{
				HTREEITEM hti = (HTREEITEM)pTVCD->nmcd.dwItemSpec;

				CRect rText;
				GetItemRect(hti, rText, TRUE);

				if (rText.bottom == pNMCD->rc.bottom)
				{
					pDC->FillSolidRect(pNMCD->rc.left, pNMCD->rc.bottom - 1, rText.left - pNMCD->rc.left, 1, m_crGridlines);
					pDC->FillSolidRect(rText.right, pNMCD->rc.bottom - 1, pNMCD->rc.right - rText.right, 1, m_crGridlines);
				}
				else
					pDC->FillSolidRect(pNMCD->rc.left, pNMCD->rc.bottom - 1, pNMCD->rc.right - pNMCD->rc.left, 1, m_crGridlines);
			}
			else
				pDC->FillSolidRect(pNMCD->rc.left, pNMCD->rc.bottom - 1, pNMCD->rc.right - pNMCD->rc.left, 1, m_crGridlines);
		}

		*pResult |= CDRF_DODEFAULT;
	}

	return FALSE; // to continue routing
}

DWORD COrderedTreeCtrl::GetFirstVisibleTopLevelItem(int& nPos)
{
	CRect rClient;
	GetClientRect(rClient);

	HTREEITEM hti = GetNextItem(NULL, TVGN_CHILD), htiPrev = NULL;
	nPos = 1;

	if (hti)
	{
		// look for the first top level item whose children are visible
		do
		{
			CRect rItem;
			GetItemRect(hti, rItem, FALSE);

			if (rItem.top == 0) // coincides with the top
			{
				ASSERT (hti == GetFirstVisibleItem());
				return (DWORD)hti;
			}
			else if (rItem.bottom <= 0) // not visible
			{
				htiPrev = hti;
				hti = GetNextItem(hti, TVGN_NEXT);
				nPos++;
			}
			else // back peddle to the previous item
			{
				ASSERT (htiPrev);

				nPos--;
				return (DWORD)htiPrev;
			}
		}
		while (hti); 
	}

	// if we got here then either the are no items or we ran out
	// either way returning the previous item is correct
	if (htiPrev)
		nPos--;

	return (DWORD)htiPrev;
}

int COrderedTreeCtrl::RecalcColumnWidth(CDC* pDC, UINT nColID, UINT& nWidth)
{
	switch (nColID)
	{
	case OTC_POSCOLUMNID:
		if (m_bShowingPosColumn)
		{
			g_mapWidths.RemoveAll(); // to handle a font change
			HTREEITEM hti = GetNextItem(NULL, TVGN_CHILD);
			int nPos = 1;
			int nMaxWidth = 0;

			while (hti)
			{
				int nItemWidth = GetGutterWidth(hti, 0, nPos, pDC);
				nMaxWidth = max(nMaxWidth, nItemWidth);

				hti = GetNextItem(hti, TVGN_NEXT);
				nPos++;
			}

			nWidth = max(nMaxWidth, MINGUTTER);
		}
		else
			nWidth = 0;

		return TRUE;
	}

	return 0;
}

UINT COrderedTreeCtrl::GetGutterWidth(HTREEITEM hti, int nLevel, int nPos, CDC* pDC)
{
	UINT nMaxWidth = 0;

	if (GetItemState(hti, TVIS_EXPANDED) & TVIS_EXPANDED)
	{
		HTREEITEM htiChild = GetChildItem(hti);
		int nPosChild = 1;
		nLevel++;

		while (htiChild)
		{
			UINT nWidth = GetGutterWidth(htiChild, nLevel, nPosChild, pDC);
			nMaxWidth = max(nMaxWidth, nWidth);

			htiChild = GetNextItem(htiChild, TVGN_NEXT);
			nPosChild++;
		}
	}
	else if (ItemHasChildren(hti)/* && ShowingEllipsis(nLevel)*/)
	{
		nMaxWidth = GetWidth(-1, pDC); // ellipsis
	}

	return nMaxWidth + GetWidth(nPos, pDC);
}

BOOL COrderedTreeCtrl::OnClick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// make sure the selection is correctly set
	CPoint point(::GetMessagePos());
	ScreenToClient(&point);

	HTREEITEM htiHit = HitTest(point);

	if (htiHit)
		SelectItem(htiHit);

	*pResult = 0;

	return FALSE; // to continue routing
}

void COrderedTreeCtrl::OnBeginDrag(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NMTREEVIEW* pNMTV = (NMTREEVIEW*)pNMHDR;
	SelectItem(pNMTV->itemNew.hItem);

	m_gutter.Redraw();
}

UINT COrderedTreeCtrl::GetWidth(int nNumber, CDC* pDC)
{
	UINT nWidth = 0;

	if (g_mapWidths.Lookup(nNumber, nWidth))
		return nWidth;

	if (nNumber >= 0)
	{
		CString sNumber;
		sNumber.Format("%d.", nNumber);
		nWidth = pDC->GetTextExtent(sNumber).cx;
	}
	else if (nNumber == -1)
		nWidth = pDC->GetTextExtent("...").cx;

	g_mapWidths[nNumber] = nWidth;
	return nWidth;
}

LRESULT COrderedTreeCtrl::OnPostSubclass(WPARAM wParam, LPARAM lParam)
{
	// initialize the gutter
	m_gutter.Initialize(GetSafeHwnd());
	return 0;
}

LRESULT COrderedTreeCtrl::OnGutterNotifyItemClick(WPARAM wParam, LPARAM lParam)
{
	NCGITEMCLICK* pNGIC = (NCGITEMCLICK*)lParam;
	ASSERT (pNGIC);

	EndLabelEdit(FALSE); // always
	SelectItem((HTREEITEM)pNGIC->dwItem); // always

	switch (pNGIC->nMsgID)
	{
	case WM_NCLBUTTONDBLCLK:
		if (pNGIC->dwItem)
			Expand((HTREEITEM)pNGIC->dwItem, IsItemExpanded((HTREEITEM)pNGIC->dwItem) ? TVE_COLLAPSE : TVE_EXPAND);
		break;
	}

	return TRUE; // handled
}

void COrderedTreeCtrl::OnStyleChanged(int nStyleType, LPSTYLESTRUCT lpSS)
{
	if (nStyleType == GWL_STYLE)
	{
		BOOL bButtonsOld = lpSS->styleOld & TVS_HASBUTTONS;
		BOOL bButtonsNew = lpSS->styleNew & TVS_HASBUTTONS;

		if (bButtonsOld != bButtonsNew)
			RecalcGutter();

		else if (bButtonsNew)
		{
			UINT uStyleOld = lpSS->styleOld & (TVS_HASLINES | TVS_LINESATROOT);
			UINT uStyleNew = lpSS->styleNew & (TVS_HASLINES | TVS_LINESATROOT);

			if (uStyleOld != uStyleNew)
				RecalcGutter();
		}
	}

	CTreeCtrl::OnStyleChanged(nStyleType, lpSS);
}


void COrderedTreeCtrl::OnSettingChange(UINT uFlags, LPCTSTR lpszSection) 
{
	// there is the strangest 'bug' under XP using the default 96DPI font
	// setting, such that allowing the treectrl to receive this message
	// results in corrupted expansion icons.

	// to cause the minimum sideeffects we check for XP, theming and whether
	// buttons are visible
	if (!((GetStyle() & TVS_HASBUTTONS) && CThemed(this).AreControlsThemed()))
		CTreeCtrl::OnSettingChange(uFlags, lpszSection);
}
